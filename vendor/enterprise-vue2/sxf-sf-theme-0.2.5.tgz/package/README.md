## 主题颜色统一来源

### 安装
```
yarn add @sxf/sf-theme

```
**or**
```
npm install @sxf/sf-theme

```

### 如何使用？（以品牌4.0的主题色为例）
在 `pcss` 样式文件中使用：
```
@import "@sxf/sf-theme/dist/brand40.pcss";
```
在 `less` 样式文件中使用：
```
@import "@sxf/sf-theme/dist/brand40.less";
```
在`js`文件中使用：
```
import brand40Map from '@sxf/sf-theme/dist/brand40.esm.js';
```
**or**
```
let brand40Map = require('@sxf/sf-theme/dist/brand40.esm.js');
```

### 目前有以下四个主题色
- security（安全）
- cloud（云）
- brand（品牌，base.pcss 是品牌的基准色）
- brand40（品牌4.0，base40.pcss 是品牌4.0的基准色）


### 可供使用的样式文件格式
以品牌4.0的主题色为例，它一共提供四种文件
```
brand40.less // less 的变量文件，里面的变量形如：@color-belarus-green: #00b27a;
brand40.pcss // pcss 的变量文件，里面的变量形如：--color-belarus-green: #00b27a;
brand40.common.js // 用上面的 pcss 文件变量转化成了 js 的对象形式，用 module.exports 的方式暴露
brand40.esm.js // 用上面的 pcss 文件变量转化成了 js 的对象形式，用 export default 的方式暴露

```

### 主题色使用规范
- 基础色base只允许皮肤色（brand、cloud、sxx）调用，不允许产品线皮肤里面调用
- 三套皮肤色变量应该保持一致
- 产品线皮肤里面如果需要用到基础色系，应该先在项目皮肤中做过一层业务的中转，再进行使用。
- 皮肤色生成的js map 包含了所有的主题变量，但是在使用过程中不应该包含基础色变量，需要使用中转过的。