/**使用加密过得版本打包 */
var $ = require('./jquery-uglify');

require('jquery-mousewheel')($);

/**
 * 元素从页面移除时触发
 */
$.event.special.remove = {
    remove: function(o) {
        if (o.handler) {
            o.handler.apply(this, arguments);
        }
    }
};


/**
 * jquery-2-1-1 方法修复
 */

(function() {
    var rxhtmlTag = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi;
    var rtagName = /<([\w:]+)/;

    // We have to close these tags to support XHTML (#13200)
    var wrapMap = {
      // Support: IE 9
      option: [1, "<select multiple='multiple'>", '</select>'],

      thead: [1, '<table>', '</table>'],
      col: [2, '<table><colgroup>', '</colgroup></table>'],
      tr: [2, '<table><tbody>', '</tbody></table>'],
      td: [3, '<table><tbody><tr>', '</tr></tbody></table>'],

      _default: [0, '', ''],
    };

    // Support: IE 9
    wrapMap.optgroup = wrapMap.option;

    wrapMap.tbody = wrapMap.tfoot = wrapMap.colgroup = wrapMap.caption = wrapMap.thead;
    wrapMap.th = wrapMap.td;


    function getAll( context, tag ) {
        var ret = context.getElementsByTagName ? context.getElementsByTagName( tag || "*" ) :
                context.querySelectorAll ? context.querySelectorAll( tag || "*" ) :
                [];
    
        return tag === undefined || tag && jQuery.nodeName( context, tag ) ?
            jQuery.merge( [ context ], ret ) :
            ret;
    }
    

    /**
     * html函数在ie下卡死（RegExp.test），抢救一下
     */
    function testRnoInnerHtml (value) {
        value = value || '';
        return value.indexOf('<script') !== -1 || value.indexOf('<style') !== -1 || value.indexOf('<link') !== -1;
    }

    $.fn.html = function( value ) {
        return $.access( this, function( value ) {
            var elem = this[ 0 ] || {},
                i = 0,
                l = this.length;

            if ( value === undefined && elem.nodeType === 1 ) {
                return elem.innerHTML;
            }

            // See if we can take a shortcut and just use innerHTML
            if ( typeof value === "string" && !testRnoInnerHtml(value) &&
                !wrapMap[ ( rtagName.exec( value ) || [ "", "" ] )[ 1 ].toLowerCase() ] ) {

                value = value.replace( rxhtmlTag, "<$1></$2>" );

                try {
                    for ( ; i < l; i++ ) {
                        elem = this[ i ] || {};

                        // Remove element nodes and prevent memory leaks
                        if ( elem.nodeType === 1 ) {
                            jQuery.cleanData( getAll( elem, false ) );
                            elem.innerHTML = value;
                        }
                    }

                    elem = 0;

                // If using innerHTML throws an exception, use the fallback method
                } catch( e ) {}
            }

            if ( elem ) {
                this.empty().append( value );
            }
        }, null, value, arguments.length );
    }

} ());

$.version = require('./package.json').version;
module.exports = $;
// only for debug
(function(_$){
    typeof window !== 'undefined' ? window.jQuery = _$ : this.jQuery = _$;
})($);
