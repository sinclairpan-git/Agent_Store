# @sxf/jquery

> 基于jquery2.1.1，修复了一些方法，添加了mousewheel插件

### 改动
> 2021/10/22 当前使用的jq源代码中存在可辨别具体版本的信息，为隐藏版本信息 增加了加密过后的jquery源码版本
> 并在打包入口中引入了uglify的版本，后续如需改回正常版本，可在index.js中还原引入路径为jquery，重新打包。
> 加密的过程： 通过JSPacker算法加密，[加密网站](https://tool.css-js.com/)，后续如果需要修改，可以基于未加密版本
> 修改，然后通过该算法加密，生成一个新的加密过后的jq,重新打包 
> 修改version,发布v1.0.5

### 构建
```shell
# 安装依赖
npm install

# 构建代码
npm run build
```