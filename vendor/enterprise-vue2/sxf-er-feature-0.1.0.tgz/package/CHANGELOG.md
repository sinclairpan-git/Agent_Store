# @sxf/er-feature

## 0.1.0 (2025-07-18)

### Minor Changes

- chore: 统一更新主线版本

### Patch Changes

- 021b7ffc: feat: 更新国际化词条翻译（Can contain a maximum of {0} characters. -> Cannot exceed {0} characters.）

## 0.1.0-xaas-patch.2 (2025-03-29)

### Minor Changes

- 56d43166: feat(feature): 更新组件库词条

## 0.1.0-xaas-patch.1 (2025-03-19)

### Patch Changes

- chore: 合入 xaas 变更后更新版本号，统一升级

## 0.1.0-scp-6111-patch.2 (2025-03-28)

### Minor Changes

- edcd7a56: feat(feature): 更新组件库词条

## 0.1.0-scp-6111-patch.1 (2025-03-13)

### Minor Changes

- cced609b: refactor(config): 将词条迁移至 feature 包
- b524f19a: feat(feature): 新增 feature 包，存放样式前缀和组件全局配置
- 10e412d9: feat(feature): 新增 getPrefixCls 方法，用户获取处理好的样式前缀

### Patch Changes

- 9c6e7309: fix(feature): getPrefixedClassName 方法传入空值时直接返回空字符串
- 13dc7794: refactor(feature): 样式类名前缀配置字段变更为 classNamePrefix;新增 getPrefixedClassName 获取带前缀的样式类名;移除 getPrefixCls 方法
- f9d5dff4: refactor(feature): feature 包中不再提供 prefix.less
