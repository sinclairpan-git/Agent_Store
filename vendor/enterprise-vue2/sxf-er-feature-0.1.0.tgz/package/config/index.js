// packages/feature/config/index.ts
var defaultConfig = {
  /** 组件的全局配置 */
  componentConfig: {},
  classNamePrefix: null
};
var featureConfig = {
  ...defaultConfig
};
var updateFeatureConfig = (config) => {
  Object.assign(featureConfig, config);
};
var getPrefixedClassName = (className) => {
  if (!(className == null ? void 0 : className.trim())) {
    return "";
  }
  return featureConfig.classNamePrefix ? `${featureConfig.classNamePrefix}-${className} ${className}` : className;
};
export {
  featureConfig,
  getPrefixedClassName,
  updateFeatureConfig
};
