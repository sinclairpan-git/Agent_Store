interface FeatureConfig {
    componentConfig?: Record<string, any>;
    classNamePrefix?: string | null;
}
declare const featureConfig: FeatureConfig;
declare const updateFeatureConfig: (config: FeatureConfig) => void;
declare const getPrefixedClassName: (className: string) => string;

export { featureConfig, getPrefixedClassName, updateFeatureConfig };
