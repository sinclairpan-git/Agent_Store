import { VueI18nIntl } from '@sxf/vue-intl';

interface FeatureConfig {
    componentConfig?: Record<string, any>;
    classNamePrefix?: string | null;
}
declare const featureConfig: FeatureConfig;
declare const updateFeatureConfig: (config: FeatureConfig) => void;
declare const getPrefixedClassName: (className: string) => string;

declare const LANGUAGE: {
    readonly 'zh-CN': "zh-CN";
    readonly 'en-US': "en-US";
};
type LanguageValue = (typeof LANGUAGE)[keyof typeof LANGUAGE];
declare const addMessages: (i18nIntl: VueI18nIntl, locale?: LanguageValue) => void;

export { LANGUAGE, LanguageValue, addMessages, featureConfig, getPrefixedClassName, updateFeatureConfig };
