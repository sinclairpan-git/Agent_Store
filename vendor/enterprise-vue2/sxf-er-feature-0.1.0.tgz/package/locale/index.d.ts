import { VueI18nIntl } from '@sxf/vue-intl';

declare const LANGUAGE: {
    readonly 'zh-CN': "zh-CN";
    readonly 'en-US': "en-US";
};
type LanguageValue = (typeof LANGUAGE)[keyof typeof LANGUAGE];
declare const addMessages: (i18nIntl: VueI18nIntl, locale?: LanguageValue) => void;

export { LANGUAGE, LanguageValue, addMessages };
