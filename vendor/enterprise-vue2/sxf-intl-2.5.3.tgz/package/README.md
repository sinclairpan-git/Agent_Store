# `@sxf/intl`

一个用来格式化文本（可处理语言复数问题）、日期、时间以及数字的 i18n 库，可以用于 Vanilla JS。

## Contents

- [`@sxf/intl`](#sxfintl)
  - [Contents](#contents)
  - [Get Started](#get-started)
    - [Install](#install)
    - [Basic Example](#basic-example)
    - [Format Message](#format-message)
    - [Pluralization](#pluralization)
    - [Format Date](#format-date)
    - [Format Time](#format-time)
    - [Format Number](#format-number)
    - [Format RelativeTime](#format-relativetime)
    - [api](#api)
      - [createI18nIntl](#createi18nintl)
        - [options](#options)
      - [getConfig](#getconfig)
      - [getMessageById](#getmessagebyid)
      - [addMessages (deprecated)](#addmessages-deprecated)
  - [Polyfill](#polyfill)
    - [Install](#install-1)
    - [Usage](#usage)
  - [Typescript](#typescript)
    - [Version](#version)
    - [IDE Declaration Prompt](#ide-declaration-prompt)
  - [Compatibility](#compatibility)
  - [License](#license)

## Get Started

### Install

```powershell
npm i @sxf/intl -S

# or
yarn add @sxf/intl -S
```

### Basic Example

初始化: `createI18nIntl(cfg: I18nConfig): I18nIntlShape`

```typescript
import createI18nIntl from '@sxf/intl'

const { $i, $iDate, $it, $irt, $in } = createI18nIntl({
  flatten: false,  // 词条对象没有拍平为一层，需要设置为 false
  locale: 'en-US',
  timeZone: 'Asia/Shanghai',
  messages: {
    app: {
      home: {
        title: 'Hello, {name}!',
        price: '{price, number, CNY}',
        select: 'select {count, plural, one {one message} other {# messages}}.',
      },
    },
  },
})

$i('app.home.title', { name: 'World' }) // Hello, World!
$i('app.home.price', { price: 123456.78 }) // CN¥123,456.78
$i('app.home.select', { count: 1 }) // select one message.
$i('app.home.select', { count: 2 }) // select 2 messages.
$iDate('2021-03-17') // 3/17/2021
$it(new Date(0)) // 08:00:00
$irt(-24, 'hour') // 24 hours ago
$in(1000) // 1,000
```

在 node 中也可以使用如下方式加载:

```js
const createI18nIntl = require('@sxf/intl').default
```

### Format Message

如果文本中有变量，则将 `{variable}` 直接替换为字符串。

```js
// locale: en-US
$i('app.home.title', { name: 'World' }) // Hello, World!
```

### Pluralization

复数文本中使用的语法格式是一种国际通用的标准文本格式，可以跨编程语言使用。该语法格式名称为 [ICU Message](https://unicode-org.github.io/icu/userguide/format_parse/messages/)，使用的复数规则为 [CLDR](http://cldr.unicode.org/) 所定义。

```js
// locale: en-US
$i('app.home.select', { count: 0 }) // select 0 messages.
$i('app.home.select', { count: 1 }) // select one message.
$i('app.home.select', { count: 2 }) // select 2 messages.
```

### Format Date

对于日期来说，并不是每个语言地区的日期格式都是 `yyyy/MM/dd` 这样的年月日，所以返回的日期格式会按照 locale 的不同而自动变化。

格式化日期: `i18nDate(value: Date | number | string, opts?: FormatDateOptions)`

注: 仅支持公历

```js
// locale: zh-Hans
$iDate('2021-03-17') // 2021/3/17

// locale: en-US
$iDate('2021-03-17') // 3/17/2021
```

### Format Time

时间也是一样会根据 locale 的不同而自动变化，默认为 24 小时格式。

格式化时间: `i18nTime(value: Date | number | string, opts?: FormatDateOptions)`

```js
// locale: en-US
$it(new Date(0)) // 08:00:00
$it(new Date(0), { hour12: true }) // 08:00 AM

// locale: zh-Hans
$it(new Date(0)) // 08:00:00
$it(new Date(0), { hour12: true }) // 上午08:00
```

### Format Number

数字的格式重要的是分隔符，并不是每一个语言地区的数字分隔符都为 `,`，所以数字的格式也会根据 locale 的不同而自动变化。

数字经常会携带符号单位，`i18nNumber` 也提供了会根据 locale 的不同而自动变化的单位格式。

格式化数字: `i18nNumber(number?: number, opts?: FormatNumberOptions)`

```js
// locale: zh-Hans
$in(1000, {style: 'currency', currency: 'CNY'}) // ¥1,000.00
$in(1000, {style: 'currency', currency: 'USD'}) // US$1,000.00

// 1,000 kB
$in(1000, {
  style: 'unit',
  unit: 'kilobyte',
  unitDisplay: 'narrow',
})
```

### Format RelativeTime

相对时间格式化是一个非具体描述时间的格式，比如说 `24 hours ago`.

相对时间格式化: `i18nRelativeTime(value: number, unit?: string, opts?: FormatRelativeTimeOptions)`

```js
// locale: zh-Hans
$irt(-24, 'hour') // 24小时前

// locale: en-US
$irt(-24, 'hour') // 24 hours ago
```

### api

#### createI18nIntl

可以使用 `createI18nIntl` 创建 `intl` 对象获取多语言函数。

```js
const intl = createI18nIntl({
  locale: 'en-US',
  timeZone: 'Asia/Shanghai',
  messages: {},
})

const { $i } = intl
```

##### options

`createI18nIntl` 接收如下参数：

```ts
interface I18nIntlConfig {
  locale: I18nLocale                  // 语言
  messages: I18nIntlMessagesTree      // 词条对象
  timeZone?: string                   // 时区
  numberFormats?: I18nNumberFormats   // 数字格式
  dateTimeFormats?: {                 // 日期时间格式
    date: I18nDateTimeFormats
    time: I18nDateTimeFormats
  }
  defaultLocale?: I18nLocale          // 当前语言无法格式化时，回退的语言，默认为 en
  flatten?: boolean                   // 词条对象是否已拍平为一层，默认为 true
  onError?: OnErrorFn                 // 格式化过程发生错误时会调用此钩子
}
```

#### getConfig

`getConfig` 可以拿到当前的语言代码 `locale`、时区 `timeZone`、回退语言代码 `defaultLocale`、错误监听函数 `onError`

```js
const intl = createI18nIntl({
  locale: 'en-US',
  timeZone: 'Asia/Shanghai',
  messages: {},
})

intl.getConfig() // Object { locale, timeZone, defaultLocale, onError }
```

#### getMessageById

可以通过 `getMessageById` 来获取源词条。

```js
const intl = createI18nIntl({
  locale: 'en-US',
  timeZone: 'Asia/Shanghai',
  messages: {
    title: 'title'
  },
})

intl.getMessageById('title') // title
```

#### addMessages (deprecated)

**注意：该 api 已经在 `@sxf/intl v2.4.0` 弃用！**

`addMessages` 可以在 `createI18nIntl` 初始化后添加词条。

```js
const intl = createI18nIntl({
  locale: 'en-US',
  timeZone: 'Asia/Shanghai',
  messages: {},
})

intl.getMessageById('title') // undefined
intl.addMessages({ title: 'title' })
intl.getMessageById('title') // title
```

## Polyfill

因为 ECMA402-International 标准较新，且一直在更新，所以需要使用 polyfills， 请按下图顺序引入。

使用由 [formatjs](https://github.com/formatjs/formatjs) 维护的支持最新标准的 polyfill。

### Install

可以使用 `i18n-next` 维护的 polyfill: (@sxf/intl-polyfill)[http://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/tree/master/packages/intl-polyfill]

```powershell
npm i @sxf/intl-polyfill -S

# or
yarn add @sxf/intl-polyfill -S
```

node 环境下，版本在 v13 以下都需要安装 Intl polyfill:

```powershell
npm install full-icu -S

# or
yarn add full-icu -S
```

### Usage

按顺序引入相应垫片，按需引入。

```js
import '@sxf/intl-polyfill'
import '@sxf/intl-polyfill/dist/locale-data/en-US'
import '@sxf/intl-polyfill/dist/locale-data/zh-CN'
```

node 环境下，版本在 v13 以下都需要引入 full-icu:

```js
require('full-icu')
```

## Typescript

### Version

`Typescript` 版本必须为 `4.2` 及以上，用 `sfx2` 打包的话，`sfx2` 的 `typescript` 版本也得是 `4.2` 及以上。

### IDE Declaration Prompt

如有需要可以使用 `typescript@4.1.0` 版本及以上的字符串模板类型进行 IDE 提示。

推荐使用 vs code 插件：[i18n-assistant](http://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/tree/master/extension/i18n-assistant)

点击 [Typescript Playground](https://www.typescriptlang.org/play?#code/C4TwDgpgBAkgjADgHYGUD2BXATgYwgFSwmgF4oBvAKCigG0BrCEALigGdgsBLJAcwF1W8ZOmx5CxKAB92nHrwDclAL6VKoSLERIYSYABsUACwCGkADzDUmXASIQAfFDJUaXbQFkIbNid4QACi4AEyFtUVsJCAAFE2AjNktwm3F7BwBKVg5uPhU1DWgrAGE0JAAzLl4kkRS7YicXanZatjCasTqIPMpgiBx9EyIoMowkHGAuUqh3ZF0uYGrrDqiHAKacMt42pBLyysWI1PrKTK1ZvUNTCytDzod88GgAKTQecwBpABooaIaod6gEAAHsAIEhgmxZDleFAAPxNGjRQEgsEQqHyOEIqAAAwAJOR3sp8QByYnI0HgyFI2FQUlQVjEgB0xKJ5GiymxWNYSAgADcIFh6VAefysA9NDdalFYvFEvg-vhyajIZLlvZMTQaOQ6ACeFBGCA0GUoPhBP8lZT0XwNZrbXiCRzpFAXm8vmclpF7DKEuZ8LR3vwHPdbbbuXyBVjlAwmEaTfwhaS1DhShx3boDMYzKRpto5sAAq5mh1WhQsWYwKxC7ajGgALYQStY20TAwN2kt-QQYlNqDKT49kzBWs8RshzVIEz10djzUDABGEH0DPni+7M97PdUtq3G+U6TUVnTlyzjJmSC8Pj8gWJ5cZNfrjI7Xf3QA) 前往查看效果。

```typescript
type I18nSourceTree = {
  [key: string]: I18nSourceTree | string;
}

type I18nIntlShape<I18nSourceTree> = {
  i18nMessage(id: I18nSourceTreePaths<I18nSourceTree>): string
}

type I18nConfig<I18nSourceTree> = {
  sources: I18nSourceTree
}

declare function i18nInit<I18nSourceTree>(
  cfg: I18nConfig<I18nSourceTree>
): I18nIntlShape<I18nSourceTree>

type Join<K, P> = K extends string ?
    P extends string ?
    `${K}${'' extends P ? '' : '.'}${P}`
    : never : never

type I18nSourceTreePaths<T> = T extends I18nSourceTree ?
    { [K in keyof T]: K extends string ?
        `${K}` | Join<K, I18nSourceTreePaths<T[K]>>
        : never
    }[keyof T] : ''

const I18nIntlShape = i18nInit({
  sources: {
    app: {
      home: {
        title: 'title'
      },
      admin: {
        name: {
          label: 'label'
        }
      }
    }
  }
})

/* 
(method) i18nMessage(id: "app" | "app.home" | "app.admin" | "app.home.title" | "app.admin.name" | "app.admin.name.label"): string
*/
I18nIntlShape.i18nMessage('app.home.title')
```

## Compatibility

- Chrome 49
- Firefox 52
- Safari 11
- IE 11
- Edge 12
- node v14

## License

[MIT](http://opensource.org/licenses/MIT)