# Change Log

## 2.5.3

### Patch Changes

- 解决无法build，publish的问题

## 2.5.2

### Patch Changes

- fix: 修复 next-tool 工具在模板字符串与 vue 插值语法处理上的 bug&fix: 修复@sxf/intl webpack5 项目无法正常使用问题

## 2.5.1

### Patch Changes

- feat: 支持空字符串的词条

## 2.5.0

### Minor Changes

- 8979f61: 添加 addMessages 函数用于动态添加词条

## 2.4.10

### Patch Changes

- 7b7a4da: chore: release

  @sxf/intl、@sxf/vue-intl、@sxf/vue3-intl

  - 新增参数格式化钩子

  @sxf/i18n-next-tool

  - 新增 warning 信息过滤功能

## 2.4.9

### Patch Changes

- 60062f2: chore(release): publish

## 2.4.8

### Patch Changes

- 5d2a9c3: chore(release): update all packages

  1. 将 @formatjs/icu-messageformat-parser 包提取出来，放在 root 下
  2. 新增词条的参数检测

## 2.4.7

### Patch Changes

- chore(release): publish

## 2.4.6

### Patch Changes

- chore(release): pnpm publish

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [2.4.5](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/intl@2.4.4...@sxf/intl@2.4.5) (2021-09-16)

**Note:** Version bump only for package @sxf/intl

## [2.4.4](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/intl@2.4.3...@sxf/intl@2.4.4) (2021-09-16)

**Note:** Version bump only for package @sxf/intl

## [2.4.3](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/intl@2.4.2...@sxf/intl@2.4.3) (2021-07-20)

**Note:** Version bump only for package @sxf/intl

## [2.4.2](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/intl@2.4.1...@sxf/intl@2.4.2) (2021-07-20)

**Note:** Version bump only for package @sxf/intl

## [2.4.1](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/intl@2.4.0...@sxf/intl@2.4.1) (2021-07-20)

**Note:** Version bump only for package @sxf/intl

# [2.4.0](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/intl@2.3.0...@sxf/intl@2.4.0) (2021-07-16)

### Bug Fixes

- remover redundant pkg ([08d2f3e](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/08d2f3ece9915ea28a7ec29d5011417b6acb000a))

### Features

- **intl:** add flatten configuration ([016d686](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/016d6863d16f2e2044c7a17e706f81042a25b15e))
- **intl:** the \$i func supports array variables ([82d643b](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/82d643bfa0ab97cde0d697b1789a3429ce2d1bee))
- **intl | vue-intl:** optimiztion of build ([4b363a9](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/4b363a9177f262153e97fadff6e70c9dd6d85320))
- **vue3-intl:** add building config ([021bdac](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/021bdac661e44d66ef0c438ab88605a8356d3d85))
- add ts code transform ([ea5671a](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/ea5671ac5cc0da00bfb6db09911edf8d26b8fe70))

# [2.3.0](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/intl@2.2.3...@sxf/intl@2.3.0) (2021-05-18)

### Features

- **intl | vue-intl:** adding Default Parameters ([969935c](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/969935c56cc48e3fdea56995f3c3c43af9ec4c8d))

## [2.2.3](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/intl@2.2.2...@sxf/intl@2.2.3) (2021-04-27)

### Bug Fixes

- **intl:** fix a bug where core-js polyfill were not packed ([3a9e8fc](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/3a9e8fcddb3cf45f03bb2703c4510bee42e7ac61))

## [2.2.2](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/intl@2.2.1...@sxf/intl@2.2.2) (2021-04-23)

### Bug Fixes

- **intl | vue-intl:** fix unit test error ([f943dd7](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/f943dd74cb93f70fafffc487428c927f84c54ebe))

## [2.2.1](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/intl@2.2.0...@sxf/intl@2.2.1) (2021-04-21)

### Bug Fixes

- **intl | vue-intl:** fix parsing error of the ast parser under old Edge ([b521787](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/b521787ea6c86901dc7c649a38e3ba74118260d5))

# [2.2.0](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/intl@2.1.8...@sxf/intl@2.2.0) (2021-04-20)

### Features

- **all:** use new ast parser ([eee2b03](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/eee2b03a86abd5df0fad0034c1224a873d77107f))

## [2.1.8](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/intl@2.1.7...@sxf/intl@2.1.8) (2021-04-19)

**Note:** Version bump only for package @sxf/intl

## [2.1.7](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/intl@2.1.6...@sxf/intl@2.1.7) (2021-04-16)

### Bug Fixes

- **all:** fix build error ([9602fdc](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/9602fdc48b46b7d0abd21fe8e2ffd2a9bec3ec4c))

## [2.1.6](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/intl@2.1.5...@sxf/intl@2.1.6) (2021-04-15)

**Note:** Version bump only for package @sxf/intl

## [2.1.5](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/intl@2.1.4...@sxf/intl@2.1.5) (2021-04-15)

**Note:** Version bump only for package @sxf/intl

## [2.1.4](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/intl@2.1.3...@sxf/intl@2.1.4) (2021-04-12)

### Bug Fixes

- **@sxf/intl | @sxf/vue-intl:** fix spelling mistakes ([de0d28d](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/de0d28dd4367a0c2efc1fff94164922c4d5d1a4c))

## [2.1.3](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/intl@2.1.2...@sxf/intl@2.1.3) (2021-04-09)

**Note:** Version bump only for package @sxf/intl

## [2.1.2](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/intl@2.1.1...@sxf/intl@2.1.2) (2021-04-09)

**Note:** Version bump only for package @sxf/intl

## [2.1.1](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/intl@2.1.0...@sxf/intl@2.1.1) (2021-04-09)

**Note:** Version bump only for package @sxf/intl

# [2.1.0](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/intl@2.0.1...@sxf/intl@2.1.0) (2021-04-09)

### Features

- **all:** add onError hook ([17aaaba](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/17aaaba4131b90dfeb657607097ff94235b65b11))

## [2.0.1](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/intl@2.0.0...@sxf/intl@2.0.1) (2021-04-08)

**Note:** Version bump only for package @sxf/intl

# [2.0.0](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/intl@1.5.0...@sxf/intl@2.0.0) (2021-04-08)

### Features

- **intl | intl-polyfill:** @sxf/intl-polyfill@1.0.0 | @sxf/intl@1.6.0 ([26faf74](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/26faf749475d3aa1fd04630729fd1a8930d1ecd9))
- **intl | vue-intl:** change the Vue-intl code style to FP ([fced917](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/fced917a8c6a744981efabd40992cd3488f75eb9))

### BREAKING CHANGES

- **intl | intl-polyfill:** config of createI18nIntl: sources --> messages

# 1.5.0 (2021-03-31)

### Bug Fixes

- **@sfx/vue-intl:** fix global registration component naming error ([519a4f0](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/519a4f09d10b063245e28b81b18b1550e90db6ae))

### Features

- **@i18n/intl:** add the default formats for @i18n/intl ([fcd1169](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/fcd11697bbe4ded678625f95601bc397ddcd5176))
- **@i18n/intl:** add the default formats for @i18n/intl ([b43e567](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/b43e5671b0214dadb68f728c00c561a5ea5170fe))
- **@sfx/intl:** @sfx/intl v1.2.0 ([d2c4307](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/d2c43073a4bbaea26b80a503e3b51e6e1fe9860b))
- **@sfx/intl:** add BCP47 language area code ([b1d620e](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/b1d620ebe031ce606a12f31fc2bea37e2fa7debf))
- **@sfx/vue-intl:** @sfx/vue-intl init ([2ae9564](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/2ae95643a0dd733b1780ab2d71ebf0d278f3578a))
- **@sfx/vue-intl:** intl function and interpoltion component for vue2 ([c9aa5b2](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/c9aa5b2b4df24c57e5d19b144ddc8118e729cdb1))
- **@sfx/vue-intl:** modify interpolation component ([f5e9b5b](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/f5e9b5bd6c467c000a4620c51c632f4558592030))
- **all:** @sfx/vue-intl@1.2.0 ([a18f0b2](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/a18f0b21a47b56a3ca03500dcb65c6bad74d1813))
- **all:** change npm package name ([803771e](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/803771e9a0c17b656f0d1c15e42d7d839f5b472d))
- **all:** reset project configuration and lerna init ([a7e643b](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/a7e643b227f7de8f69deb3f4c9693a140b16cd3d))
- **All:** add the jest configuration ([d349849](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/d349849cccf53d32357845491f7176111ddf92fa))
- @i18n/intl init ([cbf8a91](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/cbf8a91db46b0088d664e42bbf69de3a111be2a2))
- project init ([28ab7fd](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/28ab7fd9e7e48e39cf026438713db9ec86eabe9b))

### Reverts

- **all:** revert @sfx/intl v1.2.0 ([e7a5737](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/e7a57373456ae00487dda9b482194b554b209ada))

## [1.4.1](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sfx/intl@1.4.0...@sfx/intl@1.4.1) (2021-03-30)

### Bug Fixes

- **@sfx/vue-intl:** fix global registration component naming error ([519a4f0](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/519a4f09d10b063245e28b81b18b1550e90db6ae))

# [1.4.0](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sfx/intl@1.3.0...@sfx/intl@1.4.0) (2021-03-30)

### Features

- **all:** @sfx/vue-intl@1.2.0 ([a18f0b2](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/a18f0b21a47b56a3ca03500dcb65c6bad74d1813))

# [1.3.0](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sfx/intl@1.2.0...@sfx/intl@1.3.0) (2021-03-29)

### Features

- **@sfx/vue-intl:** @sfx/vue-intl init ([2ae9564](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/2ae95643a0dd733b1780ab2d71ebf0d278f3578a))
- **@sfx/vue-intl:** intl function and interpolation component for vue2 ([c9aa5b2](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/c9aa5b2b4df24c57e5d19b144ddc8118e729cdb1))

# [1.2.0](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sfx/intl@1.1.1...@sfx/intl@1.2.0) (2021-03-22)

### Features

- **@sfx/intl:** add BCP47 language area code ([b1d620e](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/b1d620ebe031ce606a12f31fc2bea37e2fa7debf))

## [1.1.1](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sfx/intl@1.2.1...@sfx/intl@1.1.1) (2021-03-19)

### Reverts

- **all:** revert @sfx/intl v1.2.0 ([e7a5737](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/e7a57373456ae00487dda9b482194b554b209ada))

# 1.1.0 (2021-03-18)

### Features

- **@i18n/intl:** add the default formats for @i18n/intl ([fcd1169](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/fcd11697bbe4ded678625f95601bc397ddcd5176))
- **@i18n/intl:** add the default formats for @i18n/intl ([b43e567](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/b43e5671b0214dadb68f728c00c561a5ea5170fe))
- **all:** reset project configuration and lerna init ([a7e643b](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/a7e643b227f7de8f69deb3f4c9693a140b16cd3d))
- **All:** add the jest configuration ([d349849](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/d349849cccf53d32357845491f7176111ddf92fa))
- @i18n/intl init ([cbf8a91](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/cbf8a91db46b0088d664e42bbf69de3a111be2a2))
- project init ([28ab7fd](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/28ab7fd9e7e48e39cf026438713db9ec86eabe9b))
