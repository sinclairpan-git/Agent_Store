import { $i, globalConfig } from '@sxf/er-config';
import format from '@sxf/er-utils/format';
import { localeCompare } from '@sxf/er-utils/sort';
import $ from 'jquery';
import { getPrefixedClassName } from '@sxf/er-feature';
import XTpl from '@sxf/er-lib/xtpl';
import { debounce } from '@sxf/er-utils/delay';
import observable from '@sxf/er-utils/observable';
import { extend } from '@sxf/er-utils/oop';
import uuid from '@sxf/er-utils/uuid';
import { when } from '@sxf/er-utils/when';
import { fixscrollbar } from '@sxf/er-widget/scrollbar';
const DEFAULT_GROUP_CLS = "iconfont vtv-icon-file";
const DEFAULT_NODE_CLS = "iconfont vtv-icon-browse";
const M_MULTI_SELECTABLE_CLS = "multi-selectable";
const M_IGNORE_ITEM_SELECT_CLS = "ignore-item-select";
const M_TREE_ITEM_MENU_CLS = "tree-item-menu-btn";
const getTreeDefaultConfig = () => {
  var _a, _b, _c;
  return {
    idField: "id",
    nameField: "name",
    nodeIdField: "id",
    groupIdField: "id",
    nodeNameField: "name",
    groupNameField: "name",
    descField: "",
    descLineHeight: "20px",
    childrenField: "data",
    uuidSeparator: ".",
    namePathSeparator: "/",
    uuidField: null,
    isGroupFn: function(d) {
      return d.type === "group";
    },
    renNameFn: function(name) {
      const cls = this.options.autoScrollX ? "" : "ellipsis";
      return format.format('<div title="{0}" class="{1}">{0}</div>', format.htmlEncode(name), cls);
    },
    renNameTextFn: function(name) {
      return name;
    },
    renRowExtraContent: function() {
      return "";
    },
    tipFn: function() {
      return "";
    },
    cls: "",
    viewCls: "",
    searchString: $i("scp.vt_component.common.widget.Tree.search_placeholder"),
    searchLimit: (_a = globalConfig.search) == null ? void 0 : _a.limit,
    searchUseUTF8Len: (_c = (_b = globalConfig.search) == null ? void 0 : _b.useUTF8Len) != null ? _c : true,
    showRoot: true,
    rootInfo: {
      id: "all",
      name: "/",
      type: "group"
    },
    treeHeight: "auto",
    treeMaxHeight: "",
    treeMinHeight: "",
    treeBgColor: "",
    treeDottedStyle: true,
    indentWidth: "25px",
    lineHeight: "32px",
    showNode: true,
    isSort: true,
    groupSortFn: function(d1, d2) {
      return localeCompare(d1.__name, d2.__name);
    },
    pushTheDftGrpLast: true,
    theDftGrpId: "default",
    nodeSortFn: function(d1, d2) {
      return localeCompare(d1.__name, d2.__name);
    },
    multiSelect: false,
    pushCheckboxLeftSide: false,
    selectAlone: false,
    selectSimple: false,
    toggleGroupWhenDblclick: true,
    toggleGroupWhenClick: false,
    bindViewRClick: false,
    nodeDraggable: false,
    ignoreItemFn: null,
    autoScrollX: false,
    groupIconCls: function() {
      return DEFAULT_GROUP_CLS;
    },
    nodeIconCls: function() {
      return DEFAULT_NODE_CLS;
    },
    searchCaseSensitive: false,
    disableCheckFn: function() {
      return false;
    },
    unselectableCheckFn: function() {
      return false;
    },
    autoExpandAll: false,
    needHeader: true,
    isOnlyOneTreeHeaderBtn: true,
    hasMenu: false,
    isShowMenu: function() {
      return true;
    }
  };
};
function setInputLimit($el, options) {
  var _a, _b, _c, _d;
  options = Object.assign(
    {
      useUTF8Len: (_b = (_a = globalConfig.search) == null ? void 0 : _a.useUTF8Len) != null ? _b : true,
      limit: (_d = (_c = globalConfig.search) == null ? void 0 : _c.limit) != null ? _d : 100
    },
    options
  );
  $el.off("input.input-limit").on("input.input-limit", function() {
    const value = $el.val();
    const limit = options.limit;
    let len = value.length;
    if (limit) {
      if (options.useUTF8Len) {
        len = format.utf8Length(value);
      }
      if (len > limit) {
        $el.val(format.limitString(value, limit, options.useUTF8Len));
      }
    }
  });
}
var itemTpl = `<div class="{[values.getPrefixedClassName('tree-item')]} {cls} <tpl if="hasChild">{[values.getPrefixedClassName('has-child')]}</tpl> <tpl if="isGroup">{[values.getPrefixedClassName('is-group')]}<tpl else>{[values.getPrefixedClassName('is-node')]}</tpl> <tpl if="disabled">{[values.getPrefixedClassName('disabled')]}</tpl>"
data-uuid="{uuid}"
data-id="{id}"
data-name="{name}"
data-name-lowercase="{[values.name.toLowerCase()]}"
data-deep="{deep}"
selectable="{selectable}"
<tpl if="draggable">draggable="true"</tpl>>

<div class="{[values.getPrefixedClassName('name-line')]}" style="line-height:{lineHeight};">
    <tpl if="pushCheckboxLeftSide">
        <div class="{[values.getPrefixedClassName('selected-check-wrap')]}" style="height:{lineHeight};">
            <div class="{[values.getPrefixedClassName('selected-check')]}"></div>
        </div>
    </tpl>
    <div class="{[values.getPrefixedClassName('deep-block-wrap')]}" style="height:{deepHeight};">
        <tpl for="deepBlocks">
            <div class="{[parent.getPrefixedClassName('deep-block')]} <tpl if="noVerticalDotted">{[parent.getPrefixedClassName('no-vertical-dotted')]}</tpl>" style="width:{width};height:{height};"></div>
        </tpl>
    </div>
    <div class="{[values.getPrefixedClassName('expand-btn-wrap')]}" style="height:{lineHeight};">
        <tpl if="hasChild">
            <div class="{[values.getPrefixedClassName('expand-btn')]} {[values.getPrefixedClassName('ignore-item-select')]}">
                <i class="{[values.getPrefixedClassName('ignore-item-select')]} {[values.getPrefixedClassName('expand-btn')]} pull-left iconfont vtv-icon-plus {[values.getPrefixedClassName('expand-btn__plus-icon')]}"></i>
                <i class="{[values.getPrefixedClassName('ignore-item-select')]} {[values.getPrefixedClassName('expand-btn')]} pull-left iconfont vtv-icon-minus {[values.getPrefixedClassName('expand-btn__minus-icon')]}"></i>
            </div>
        </tpl>
    </div>
    <tpl if="!pushCheckboxLeftSide">
        <div class="{[values.getPrefixedClassName('selected-check-wrap')]}" style="height:{lineHeight};">
            <div class="{[values.getPrefixedClassName('selected-check')]}"></div>
        </div>
    </tpl>
    <tpl if="itemIconCls">
        <div class="{[values.getPrefixedClassName('name-adorn-icon-wrap')]}" style="height:{lineHeight};">
            <tpl if="isSymbolIcon">
                <svg class="{[values.getPrefixedClassName('name-adorn-icon')]} {[values.getPrefixedClassName('name-adorn-icon--svg')]}" aria-hidden="true">
                    <use xlink:href="{itemIconCls}"></use>
                </svg>
            </tpl>
            <tpl if="!isSymbolIcon">
                <div class="{[values.getPrefixedClassName('name-adorn-icon')]} {itemIconCls}"></div>
            </tpl>
        </div>
    </tpl>
    <div class="{[values.getPrefixedClassName('text-wrap')]}" style="width:{textWidth}">
        <div class="{[values.getPrefixedClassName('tree-item-name')]} {[!values.autoScrollX && 'ellipsis' || '']} {[values.tip ? values.getPrefixedClassName('has-tip') : '']}">
            {nameHtml}
            <tpl if="tip">
                <i class="{[values.getPrefixedClassName('tree-item-tip')]} {[values.getPrefixedClassName('icon')]} icon-tip {[values.getPrefixedClassName('hover')]}" data-hint="{tip}"></i>
            </tpl>
        </div>
        <tpl if="desc">
            <div class="{[values.getPrefixedClassName('tree-item-desc')]} {[!values.autoScrollX && 'ellipsis' || '']}" title="{desc}" style="line-height:{descLineHeight};">{desc}</div>
        </tpl>
    </div>

    <tpl if="showMenu">
        <span class="{[values.getPrefixedClassName('tree-item-menu-btn')]} iconfont vtv-icon-more"></span>
    </tpl>

    {extraNameLineContent}
</div>

<tpl if="hasChild">
    <div class="{[values.getPrefixedClassName('group-children')]}">{childrenHtml}</div>
</tpl>
</div>`;
var treeTpl = `<div class="{[values.getPrefixedClassName('sfis-tree')]} {cls}" id="{id}">
    <tpl if="needHeader">
        <div class="{[values.getPrefixedClassName('sfis-tree-header')]} vmp-subtoolbar">
            <ul class="{[values.getPrefixedClassName('toolbar-btns')]}">
                <li class="pull-left btn btn-icon {[values.getPrefixedClassName('icon-tree-expand')]}"
                    action="expandAll"
                    title="{[this.expandAll]}">
                    <i class="iconfont vtv-icon-tree-folded"></i>
                </li>
                <li class="pull-left btn btn-icon {[values.getPrefixedClassName('icon-tree-wrap')]}"
                    action="collapseAll"
                    title="{[this.collapseAll]}">
                    <i class="iconfont vtv-icon-tree-expanded"></i>
                </li>
                <li class="pull-right {[values.getPrefixedClassName('search-wrap')]}">
                    <input type="text" style-key="input" trigger-type="search" class="{[values.getPrefixedClassName('search-input')]}" placeholder="{searchString}">
                    <span class="iconfont vtv-icon-search {[values.getPrefixedClassName('search-icon')]}"></span>
                </li>
            </ul>
        </div>
    </tpl>

    <div class="{[values.getPrefixedClassName('load-empty-msg')]}">{[this.noDataTip]}</div>
    <div class="{[values.getPrefixedClassName('searched-empty-msg')]}">{[this.noMatchTip]}</div>
    <div class="{[values.getPrefixedClassName('sfis-tree-view')]} {treeStyle} {multiSelectableCls} {viewCls}" style="height:{treeHeight};max-height:{treeMaxHeight};min-height:{treeMinHeight};background-color:{treeBgColor};">

    </div>

    <tpl if="autoScrollX">
        <div class="{[values.getPrefixedClassName('sfis-tree-scrollbar-x')]}"></div>
        <div class="{[values.getPrefixedClassName('sfis-tree-scrollbar-y')]}"></div>
    </tpl>
</div>`;
const M_CLS = {
  UNSEARCHED: "unsearched-hidden"
};
const M_TREE_ITEM_XTPL = new XTpl(itemTpl);
const Tree = extend(observable, {
  constructor: function(options) {
    this.id = uuid("sfis-tree");
    const defaults = getTreeDefaultConfig();
    this.options = $.extend(true, {}, defaults, options);
    this.listeners = this.options.listeners;
    this.options.itemActiveCls = "item-active";
    this.options.itemHalfActiveCls = "item-half-active";
    delete this.options.idField;
    delete this.options.nameField;
    this.options.nodeIdField = options.nodeIdField || options.idField || defaults.nodeIdField;
    this.options.groupIdField = options.groupIdField || options.idField || defaults.groupIdField;
    this.options.nodeNameField = options.nodeNameField || options.nameField || defaults.nodeNameField;
    this.options.groupNameField = options.groupNameField || options.nameField || defaults.groupNameField;
    this.options.indentWidth = this.options.treeDottedStyle ? "22px" : this.options.indentWidth;
    if (this.options.pushTheDftGrpLast) {
      const theDftGrpId = this.options.theDftGrpId;
      const groupSortFn = this.options.groupSortFn;
      this.options.groupSortFn = function(d1, d2) {
        if (d1.__id === theDftGrpId) {
          return 1;
        }
        if (d2.__id === theDftGrpId) {
          return -1;
        }
        return groupSortFn(d1, d2);
      };
    }
    this.addEvents(
      "item-select",
      "item-active",
      "item-inactive",
      "hand-toggle-group",
      "hand-toggle-all-group",
      "search-done",
      "end-search",
      "view-r-click",
      "redraw-done",
      "load-data",
      "fn-toggle-group",
      "fn-toggle-all-group",
      "tree-menu-click",
      "update-tree-header"
    );
    this.init();
    Tree.superclass.constructor.apply(this, arguments);
  },
  init: function() {
    this.rendered = false;
    this.expandedGroup = {};
    this.searchValue = "";
    this.sourceDataHash = null;
    this.activeItemUuid = {};
    this.halfActiveItemUuid = {};
    this.createTpl();
    this.initEvents();
    this.initGetItemRdFn();
    this.initDataSortFn();
    this.updateTreeHeader();
  },
  initScrollbar: function() {
    if (this.options.autoScrollX) {
      const $scrollContainer = this.$view.parent();
      fixscrollbar.call(this.$view, {
        scrollbarContainer: $scrollContainer.get(0),
        scrollbarXRailContainer: $scrollContainer.find(".sfis-tree-scrollbar-x").get(0),
        scrollbarYRailContainer: $scrollContainer.find(".sfis-tree-scrollbar-y").get(0)
      });
    }
  },
  updateScrollbar: debounce(function() {
    if (this.$view) {
      fixscrollbar.call(this.$view, "update");
    }
  }, 50),
  createTpl: function() {
    const options = this.options;
    let cls = options.cls;
    cls += " " + getPrefixedClassName(options.autoScrollX ? "sfis-tree-with-scrollbar" : "");
    cls += " " + getPrefixedClassName(!options.needHeader ? "sfis-tree-without-header" : "");
    cls += " " + getPrefixedClassName(options.hasMenu ? "sfis-tree-with-menu" : "");
    const rd = {
      id: this.id,
      cls,
      searchString: options.searchString || $i("scp.vt_component.common.widget.Tree.search_placeholder"),
      needHeader: options.needHeader,
      treeHeight: options.treeHeight,
      treeMaxHeight: options.treeMaxHeight,
      treeMinHeight: options.treeMinHeight,
      treeBgColor: options.treeBgColor,
      treeStyle: this.options.treeDottedStyle ? "dotted-style" : "",
      viewCls: options.viewCls,
      autoScrollX: options.autoScrollX,
      getPrefixedClassName
    };
    if (options.multiSelect) {
      rd.multiSelectableCls = getPrefixedClassName(M_MULTI_SELECTABLE_CLS);
    }
    const tpl = new XTpl(treeTpl, {
      expandAll: $i("scp.vt_component.common.widget.Tree.expand_all"),
      collapseAll: $i("scp.vt_component.common.widget.Tree.collapse_all"),
      noDataTip: $i("scp.vt_component.common.widget.Tree.no_data_tip"),
      noMatchTip: $i("scp.vt_component.common.widget.Tree.no_match_tip")
    }).apply(rd);
    this.$el = $(tpl);
    this.$view = $(".sfis-tree-view", this.$el);
    this.$bar = $(".vmp-subtoolbar", this.$el);
    this.$loadEmptyTip = this.$el.find(".load-empty-msg");
    this.$searchEmptyTip = this.$el.find(".searched-empty-msg");
    if (options.needHeader) {
      this.$treeExpand = this.$el.find(".sfis-tree-header .icon-tree-expand");
      this.$treeWrap = this.$el.find(".sfis-tree-header .icon-tree-wrap");
    }
  },
  show: function() {
    this.$el.show();
  },
  hide: function() {
    this.$el.hide();
  },
  initEvents: function() {
    const me = this;
    $(this.$el).delegate(".name-line", "mouseover", function() {
      me.emit("mouseover-item");
    });
    this.$el.delegate(
      ".tree-item.is-group.has-child > .name-line > .expand-btn-wrap > .expand-btn",
      "click",
      function() {
        const $group = $(this).closest(".tree-item");
        const node = me.sourceDataHash[$group.attr("data-uuid")];
        const eventName = $group.hasClass("expanded") ? "before-collapse" : "before-expand";
        if (me.emit(eventName, node, $group.find(".name-line").eq(0)) === false) {
          return;
        }
        me.toggleItemExpanded($group);
        me.emit("hand-toggle-group", $group);
      }
    );
    this.$bar.delegate(".btn[action]", "click", function() {
      const action = $(this).attr("action");
      switch (action) {
        case "expandAll":
          me.expandAll();
          break;
        case "collapseAll":
          me.collapseAll();
          break;
      }
      me.emit("hand-toggle-all-group");
    });
    const $search = this.$bar.find(".search-input").keyup(function(e) {
      if (e.keyCode === 27) {
        me.endSearch();
      } else {
        me.search($(this).val());
      }
    });
    if (me.options.searchLimit) {
      setInputLimit($search, {
        limit: me.options.searchLimit,
        useUTF8Len: me.options.searchUseUTF8Len
      });
    }
    this.$bar.find(".search-icon").click(function() {
      me.search($(".search-input", me.$bar).val());
    });
    this.$view.delegate(".tree-item .name-line", "click", function(e) {
      if ($(e.target).hasClass(M_IGNORE_ITEM_SELECT_CLS)) {
        return;
      }
      if (me.options.multiSelect && me.options.selectSimple && !$(e.target).hasClass("selected-check")) {
        return;
      }
      const uuid2 = $(this).closest(".tree-item").attr("data-uuid");
      const item = me.sourceDataHash[uuid2];
      if (!item.__selectable || item.__disabled) {
        return;
      }
      if ($.isFunction(me.options.beforeSelect)) {
        when(me.options.beforeSelect(item)).then(function(res) {
          if (res !== false) {
            me.handleTreeItemSelect(uuid2);
          }
        });
        return;
      }
      me.handleTreeItemSelect(uuid2);
    });
    if (this.options.toggleGroupWhenDblclick || this.options.toggleGroupWhenClick) {
      const eventType = this.options.toggleGroupWhenClick ? "click" : "dblclick";
      this.$view.delegate(".tree-item.is-group.has-child > .name-line", eventType, function(e) {
        if ($(e.target).hasClass("expand-btn") || $(e.target).hasClass("selected-check")) {
          return;
        }
        const $group = $(this).closest(".tree-item");
        me.toggleItemExpanded($group);
        me.emit("hand-toggle-group", $group);
      });
    }
    if (this.options.hasMenu) {
      this.bindMenuEvent();
    }
    if (this.options.bindViewRClick) {
      this.$view[0].oncontextmenu = function(e) {
        e.preventDefault();
        me.emit("view-r-click", e);
      };
    }
    this.hasSetExpand = false;
    if (this.options.autoExpandAll) {
      this.on("load-data", function(data) {
        if (me.hasSetExpand) {
          return;
        }
        const remoteData = me.options.showRoot ? data[0][me.options.childrenField] : data;
        if (!remoteData.length) {
          return;
        }
        this.hasSetExpand = true;
        this.expandAll();
      });
    }
    if (this.options.autoScrollX) {
      this.on(
        "fn-toggle-group fn-toggle-all-group hand-toggle-group hand-toggle-all-group load-data search-done",
        this.updateTreeItemWidth.bind(this)
      );
    }
  },
  handleTreeItemSelect: function(uuid2) {
    const me = this, selectAlone = me.options.selectAlone, isSelected = me.activeItemUuid[uuid2];
    if (!me.options.multiSelect) {
      me.setItemActive(uuid2, {
        inactivateOthers: true
      });
      me.emit("item-select", me.sourceDataHash[uuid2]);
      return;
    }
    if (isSelected) {
      me.setItemInactive(uuid2, {
        inactiveAllChildren: !selectAlone
      });
    } else {
      me.setItemActive(uuid2, {
        activeAllChildren: !selectAlone
      });
    }
    if (!selectAlone) {
      me.setParentStatus(uuid2);
    }
    me.emit(isSelected ? "item-unselect" : "item-select", me.sourceDataHash[uuid2]);
  },
  updateTreeItemWidth: function() {
    const lastTreeItemWidth = this.lastTreeItemWidth || 0;
    const viewWidth = this.$view.get(0).scrollWidth;
    let viewID = this.viewID;
    if (!viewID) {
      viewID = this.$view.attr("id");
      if (!viewID) {
        viewID = uuid("tree-view-");
        this.$view.attr("id", viewID);
      }
      this.viewID = viewID;
    }
    if (!this.$viewStyle) {
      this.$viewStyle = $(format.format('<style id="tree-view-id-{0}" type="text/css"></style>', this.viewID)).appendTo(
        "head"
      );
    }
    if (lastTreeItemWidth < viewWidth) {
      let cssText = [];
      cssText.push(format.format("#{0} .tree-item", viewID));
      cssText.push(format.format("{ width: {0}px; }", viewWidth));
      cssText = cssText.join("");
      this.$viewStyle.html(cssText);
      this.lastTreeItemWidth = viewWidth;
      this.lastViewStyle = cssText;
    }
    this.updateScrollbar();
  },
  updateViewStyle: function(style) {
    if (!this.$viewStyle) {
      return;
    }
    const lastCssText = this.lastViewStyle || "";
    style = lastCssText + (style || "");
    if (style !== this.lastUpdateStyle) {
      this.$viewStyle.html(style);
      this.lastUpdateStyle = style;
    }
  },
  setItemActive: function(uuid2, opt) {
    opt = opt || {};
    const me = this;
    if (!me.sourceDataHash[uuid2]) {
      return;
    }
    const itemActiveCls = me.options.itemActiveCls;
    const prefixItemActiveCls = getPrefixedClassName(itemActiveCls);
    const itemHalfActiveCls = me.options.itemHalfActiveCls;
    const prefixItemHalfActiveCls = getPrefixedClassName(itemHalfActiveCls);
    const $item = $('.tree-item[data-uuid="' + uuid2 + '"]', me.$view);
    let $tmp;
    if (opt.inactivateOthers) {
      me.activeItemUuid = {};
      me.halfActiveItemUuid = {};
      $(".tree-item", me.$view).removeClass(prefixItemActiveCls).removeClass(prefixItemHalfActiveCls);
    }
    me.activeItemUuid[uuid2] = true;
    $item.addClass(prefixItemActiveCls);
    if (opt.emitSelectEvent) {
      me.emit("item-select", me.sourceDataHash[uuid2]);
    }
    delete me.halfActiveItemUuid[uuid2];
    $item.removeClass(prefixItemHalfActiveCls);
    if (opt.activeAllChildren) {
      $tmp = $item.find('.tree-item[selectable="true"]:not(.disabled)');
      if ($tmp.length) {
        $tmp.each(function(idx, dom) {
          me.setItemActive($(dom).attr("data-uuid"));
        });
      }
    }
    if (opt.updateParentStatus && !me.options.selectAlone) {
      me.setParentStatus(uuid2);
    }
    me.emit("item-active", me.sourceDataHash[uuid2]);
  },
  setItemInactive: function(uuid2, opt) {
    opt = opt || {};
    const me = this;
    if (!me.sourceDataHash[uuid2]) {
      return;
    }
    const itemActiveCls = me.options.itemActiveCls;
    const prefixItemActiveCls = getPrefixedClassName(itemActiveCls);
    const itemHalfActiveCls = me.options.itemHalfActiveCls;
    const prefixItemHalfActiveCls = getPrefixedClassName(itemHalfActiveCls);
    const $item = $('.tree-item[data-uuid="' + uuid2 + '"]', me.$view);
    let $tmp;
    delete me.activeItemUuid[uuid2];
    $item.removeClass(prefixItemActiveCls);
    delete me.halfActiveItemUuid[uuid2];
    $item.removeClass(prefixItemHalfActiveCls);
    if (opt.inactiveAllChildren) {
      $tmp = $item.find(".tree-item:not(.disabled)");
      if ($tmp.length) {
        $tmp.each(function(idx, dom) {
          me.setItemInactive($(dom).attr("data-uuid"));
        });
      }
    }
    if (opt.updateParentStatus && !me.options.selectAlone) {
      me.setParentStatus(uuid2);
    }
    me.emit("item-inactive", me.sourceDataHash[uuid2]);
  },
  updateSearchString: function(placeholder) {
    $("#" + this.id).find('[trigger-type="search"]').attr("placeholder", placeholder);
  },
  setItemHalfActive: function(uuid2) {
    const me = this;
    if (!me.sourceDataHash[uuid2]) {
      return;
    }
    const itemActiveCls = me.options.itemActiveCls;
    const prefixItemActiveCls = getPrefixedClassName(itemActiveCls);
    const itemHalfActiveCls = me.options.itemHalfActiveCls;
    const $item = $('.tree-item[data-uuid="' + uuid2 + '"]', me.$view);
    delete me.activeItemUuid[uuid2];
    $item.removeClass(prefixItemActiveCls);
    me.halfActiveItemUuid[uuid2] = true;
    $item.addClass(getPrefixedClassName(itemHalfActiveCls));
  },
  setParentStatus: function(uuid2) {
    const me = this;
    const $item = $('.tree-item[data-uuid="' + uuid2 + '"]', me.$view);
    const $siblings = $item.siblings().add($item);
    const $parent = $item.closest(".group-children").closest(".tree-item");
    if (!$parent.length) {
      return;
    }
    const parentUuid = $parent.attr("data-uuid");
    const itemActiveCls = me.options.itemActiveCls;
    const itemHalfActiveCls = me.options.itemHalfActiveCls;
    let allActive = true, someActive = false;
    $siblings.each(function(idx, dom) {
      const $dom = $(dom);
      if ($dom.hasClass("disabled") || $dom.attr("selectable") === "false") {
        return;
      }
      if ($dom.hasClass(itemActiveCls)) {
        someActive = true;
      } else if ($dom.hasClass(itemHalfActiveCls)) {
        allActive = false;
        someActive = true;
      } else {
        allActive = false;
      }
      if (!allActive && someActive) {
        return false;
      }
    });
    me.setItemInactive(parentUuid);
    if (allActive) {
      me.setItemActive(parentUuid);
    } else if (someActive) {
      me.setItemHalfActive(parentUuid);
    }
    me.setParentStatus(parentUuid);
  },
  getAllParentsRecord: function(uuid2) {
    const ret = [];
    const sourceDataHash = this.sourceDataHash;
    let item = sourceDataHash[uuid2];
    while (item && item.__parentUuid && (item = sourceDataHash[item.__parentUuid])) {
      ret.push(item);
    }
    return ret;
  },
  getAllDescendantRecord: function(uuid2, opt) {
    opt = opt || {};
    const ret = [];
    const onlyNode = opt.onlyNode;
    const onlyGroup = opt.onlyGroup;
    const data = this.sourceDataHash[uuid2];
    const childrenField = this.options.childrenField;
    if (!data || !data.__isGroup || !data.__descendantGroupCount && !data.__descendantNodeCount) {
      return ret;
    }
    const get = function(d) {
      const children = d[childrenField];
      const length = children && children.length || 0;
      let item;
      for (let i = 0; i < length; i++) {
        item = children[i];
        if (onlyGroup && item.__isGroup || onlyNode && !item.__isGroup || !onlyNode && !onlyGroup) {
          ret.push(item);
        }
        if (item[childrenField]) {
          get(item);
        }
      }
    };
    get(data);
    return ret;
  },
  getAllDescendantNodeRecord: function(uuid2) {
    return this.getAllDescendantRecord(uuid2, {
      onlyNode: true
    });
  },
  getAllDescendantGroupRecord: function(uuid2) {
    return this.getAllDescendantRecord(uuid2, {
      onlyGroup: true
    });
  },
  getItemRecord: function(uuid2) {
    return uuid2 && this.sourceDataHash[uuid2] || false;
  },
  getItemRecordByDom: function(dom) {
    const uuid2 = this.getUuidByItem($(dom));
    return this.getItemRecord(uuid2);
  },
  getSelectedValue: function() {
    const ret = [], activeItemUuid = this.activeItemUuid, sourceDataHash = this.sourceDataHash;
    for (const uuid2 in activeItemUuid) {
      if (activeItemUuid.hasOwnProperty(uuid2) && activeItemUuid[uuid2] && sourceDataHash[uuid2]) {
        ret.push(sourceDataHash[uuid2]);
      }
    }
    return ret;
  },
  getItemStatus: function(uuid2) {
    if (!this.sourceDataHash[uuid2]) {
      return;
    }
    const $item = $('.tree-item[data-uuid="' + uuid2 + '"]', this.$view);
    const ret = {
      isTop: false,
      isBottom: false,
      isSelected: false,
      isAllLabel: false,
      deep: null
    };
    ret.isTop = !$item.prev().length;
    ret.isBottom = !$item.next().length;
    ret.isSelected = $item.hasClass(this.options.itemActiveCls);
    ret.isAllLabel = this.options.showRoot && !$item.parents(".tree-item").length;
    ret.deep = +$item.attr("data-deep");
    return ret;
  },
  setSelectedValue: function(uuids) {
    if (!uuids) {
      return;
    }
    uuids = $.isArray(uuids) ? uuids : [uuids];
    if (!this.options.multiSelect) {
      this.setItemActive(uuids[0], {
        inactivateOthers: true
      });
      return;
    }
    const selectAlone = this.options.selectAlone;
    for (let i = 0, length = uuids.length; i < length; i++) {
      this.setItemActive(uuids[i], {
        activeAllChildren: !selectAlone
      });
      if (!selectAlone) {
        this.setParentStatus(uuids[i]);
      }
    }
  },
  getUuidById: function(ids) {
    if (!ids) {
      return;
    }
    ids = $.isArray(ids) ? ids : [ids];
    const $items = $(".tree-item", this.$view);
    const uuids = ids.map(function(id) {
      return $items.filter('[data-id="' + id + '"]').attr("data-uuid");
    });
    return uuids.length > 1 ? uuids : uuids[0];
  },
  unSelectAll: function() {
    $(".tree-item", this.$view).removeClass(getPrefixedClassName(this.options.itemActiveCls)).removeClass(getPrefixedClassName(this.options.itemHalfActiveCls));
    this.activeItemUuid = {};
    this.halfActiveItemUuid = {};
  },
  toggleItemExpanded: function($item, stateVal, opt) {
    const me = this;
    if (!me.isTreeItem($item)) {
      return;
    }
    opt = opt || {};
    me.setItemExpanded($item, stateVal);
    if (opt.affectParents) {
      $item.parents(".sfis-tree-view .tree-item").each(function(idx, dom) {
        me.setItemExpanded($(dom), stateVal);
      });
    }
    if (opt.affectChildren) {
      $item.find(".tree-item.is-group.has-child").each(function(idx, dom) {
        me.setItemExpanded($(dom), stateVal);
      });
    }
    me.updateTreeHeader();
  },
  setItemExpanded: function($item, stateVal) {
    const uuid2 = this.getUuidByItem($item);
    if (typeof stateVal !== "boolean") {
      stateVal = !$item.hasClass("expanded");
    }
    if ($item.hasClass("has-child")) {
      $item.toggleClass(getPrefixedClassName("expanded"), stateVal);
      this.expandedGroup[uuid2] = stateVal;
    }
  },
  updateTreeHeader: function() {
    if (!this.options.isOnlyOneTreeHeaderBtn) {
      return;
    }
    const $tree = this.$el;
    const $allGroups = $tree.find(".tree-item.is-group.has-child");
    let isExpanded = false;
    $allGroups.each(function(idx, dom) {
      if ($(dom).is(".expanded")) {
        isExpanded = true;
        return;
      }
    });
    if (!this.options.needHeader) {
      this.emit("update-tree-header", isExpanded);
      return;
    }
    if (isExpanded) {
      this.$treeExpand.hide();
      this.$treeWrap.show();
    } else {
      this.$treeWrap.hide();
      this.$treeExpand.show();
    }
  },
  expand: function(uuid2, expandAllParents, expandAllChildren) {
    this.expandItem(this.getItemByUuid(uuid2), {
      affectParents: expandAllParents,
      affectChildren: expandAllChildren
    });
    this.emit("fn-toggle-group");
  },
  expandItem: function($item, opt) {
    this.toggleItemExpanded($item, true, opt);
  },
  expandItemByUuid: function(uuid2, opt) {
    this.expandItem(this.getItemByUuid(uuid2), opt);
  },
  isItemVisibleInView: function($item) {
    if (!this.isTreeItem($item) || !$item.is(":visible")) {
      return false;
    }
    const posTop = $item.offset().top - this.$view.offset().top;
    return posTop >= 0 && posTop <= this.$view.height() - $item.find(".name-line").height();
  },
  expandToItem: function($item, opt) {
    if (!this.isTreeItem($item)) {
      return;
    }
    opt = opt || {};
    const isExpanded = $item.hasClass("expanded");
    this.expandItem($item, {
      affectParents: true
    });
    if (!isExpanded && !opt.expandSelf) {
      this.collapseItem($item);
    }
  },
  expandToItemByUuid: function(uuid2, opt) {
    this.expandToItem(this.getItemByUuid(uuid2), opt);
  },
  collapse: function(uuid2, collapseAllChildren) {
    this.collapseItem(this.getItemByUuid(uuid2), {
      affectChildren: collapseAllChildren
    });
    this.emit("fn-toggle-group");
  },
  collapseItem: function($item, opt) {
    this.toggleItemExpanded($item, false, opt);
  },
  collapseItemByUuid: function(uuid2, opt) {
    this.collapseItem(this.getItemByUuid(uuid2), opt);
  },
  expandAll: function() {
    const me = this;
    $(".tree-item.has-child", this.$view).each(function(idx, dom) {
      const uuid2 = $(dom).attr("data-uuid");
      me.expandedGroup[uuid2] = true;
      $(dom).addClass(getPrefixedClassName("expanded"));
    });
    this.emit("fn-toggle-all-group");
    this.updateTreeHeader();
  },
  collapseAll: function() {
    $(".tree-item.has-child", this.$view).removeClass(getPrefixedClassName("expanded"));
    this.expandedGroup = {};
    this.emit("fn-toggle-all-group");
    this.updateTreeHeader();
  },
  expandNthDeep: function(deep, expandAllParents) {
    deep = Number(deep);
    if (isNaN(deep) || deep < 0) {
      return;
    }
    if (expandAllParents) {
      this.expandNthDeep(deep - 1, expandAllParents);
    }
    const me = this;
    const $items = $('.tree-item.has-child[data-deep="' + deep + '"]', me.$view);
    $items.each(function(idx, dom) {
      me.expandItem($(dom));
    });
    this.emit("fn-toggle-group");
  },
  collapseNthDeep: function(deep, collapseAllChildren) {
    deep = Number(deep);
    if (isNaN(deep) || deep < 0) {
      return;
    }
    const me = this;
    const $items = $('.tree-item.has-child[data-deep="' + deep + '"]', me.$view);
    $items.each(function(idx, dom) {
      me.collapseItem($(dom), {
        affectChildren: collapseAllChildren
      });
    });
    this.emit("fn-toggle-group");
  },
  getItem: function(opt) {
    return $(getItemSel(opt), this.$view);
  },
  getItemByUuid: function(uuid2) {
    return this.getItem({
      uuid: uuid2
    });
  },
  getUuidByItem: function($item) {
    if (!this.isTreeItem($item)) {
      return;
    }
    return $item.attr("data-uuid");
  },
  isTreeItem: function($item) {
    if (!$item || !($item instanceof $) || !$item.length) {
      return false;
    }
    if (!$item.hasClass("tree-item") || !$item.closest(this.$view).length) {
      return false;
    }
    return true;
  },
  scrollToItem: function($item, opt) {
    opt = opt || {};
    if (!this.isTreeItem($item)) {
      return;
    }
    const $view = this.$view;
    if (!$item.is(":visible")) {
      if (!opt.autoExpand) {
        return;
      }
      this.expandToItem($item);
    }
    let scrollTop = $item.offset().top + $view.scrollTop() - $view.offset().top;
    scrollTop += Number(opt.offsetTop) || 0;
    $view.scrollTop(scrollTop);
  },
  scrollToItemByUuid: function(uuid2, opt) {
    return this.scrollToItem(this.getItemByUuid(uuid2), opt);
  },
  search: function(str) {
    let selector;
    const me = this;
    str = (str || "").trim();
    if (!str) {
      this.endSearch();
      return;
    }
    const safeStr = str.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
    if (this.options.searchCaseSensitive) {
      selector = '.tree-item[data-name*="' + safeStr + '"]';
    } else {
      str = str.toLowerCase();
      selector = '.tree-item[data-name-lowercase*="' + safeStr.toLowerCase() + '"]';
    }
    this.lastSearchValue = this.searchValue;
    this.searchValue = str;
    const $searched = $(selector, this.$view).filter(function() {
      return $(this).data("uuid") !== me.options.rootInfo[me.options.groupIdField];
    });
    $(".tree-item", this.$view).addClass(getPrefixedClassName(M_CLS.UNSEARCHED));
    $searched.removeClass(getPrefixedClassName(M_CLS.UNSEARCHED)).parents(".sfis-tree-view .tree-item").removeClass(getPrefixedClassName(M_CLS.UNSEARCHED));
    $searched.find(".group-children .tree-item").removeClass(getPrefixedClassName(M_CLS.UNSEARCHED));
    if (this.lastSearchValue !== this.searchValue) {
      $searched.each(function(idx, dom) {
        me.collapseItem($(dom));
      });
      $searched.parents(".sfis-tree-view .tree-item").each(function(idx, dom) {
        me.expandItem($(dom));
      });
    }
    this.$searchEmptyTip.toggle(!$searched.length);
    this.$loadEmptyTip.hide();
    this.emit("search-done", str, $searched);
  },
  endSearch: function() {
    this.searchValue = "";
    this.$searchEmptyTip.hide();
    this.$loadEmptyTip.toggle(!this.sourceData.length);
    $(".tree-item", this.$view).removeClass(getPrefixedClassName(M_CLS.UNSEARCHED));
    $(".search-input", this.$bar).val("");
    this.emit("end-search");
  },
  render: function(parent) {
    if (this.rendered) {
      return;
    }
    this.rendered = true;
    $(parent).append(this.$el);
    this.initScrollbar();
  },
  loadData: function(data) {
    data = copyObj(data);
    if (this.options.showRoot) {
      const all = copyObj(this.options.rootInfo);
      all[this.options.childrenField] = data;
      data = [all];
    }
    this.sourceData = data;
    this.redraw();
    this.$loadEmptyTip.toggle(!data.length);
    this.emit("load-data", data);
  },
  redraw: function() {
    const self = this;
    const data = this.sourceData;
    const options = this.options;
    if (!data) {
      return;
    }
    this.sourceDataHash = this.transformToHash(data);
    this.$view.html(this.getTreeHtml(data));
    if (options.renderElem) {
      const $treeItemList = this.$view.find(".tree-item");
      Object.keys(this.sourceDataHash).forEach(function(uuid2) {
        const record = self.sourceDataHash[uuid2];
        const elem = options.renderElem(record);
        if (elem === false) {
          return;
        }
        let $treeItem = $treeItemList.filter('[data-uuid="' + record.__uuid + '"]').eq(0);
        if (!$treeItem.length) {
          return;
        }
        $treeItem = $treeItem.find(".tree-item-name");
        $treeItem.html("").append(elem);
        $treeItem.on("remove", function() {
          $(elem).detach();
        });
      });
    }
    if (this.searchValue) {
      this.search(this.searchValue);
    }
    this.emit("redraw-done");
  },
  transformToHash: function(treeData) {
    if (!treeData) {
      return treeData;
    }
    const me = this;
    const ret = {};
    const isGroupFn = this.options.isGroupFn;
    const nodeIdField = this.options.nodeIdField;
    const groupIdField = this.options.groupIdField;
    const nodeNameField = this.options.nodeNameField;
    const groupNameField = this.options.groupNameField;
    const childrenField = this.options.childrenField;
    const uuidField = this.options.uuidField;
    const descField = this.options.descField;
    const uuidSeparator = this.options.uuidSeparator;
    const namePathSeparator = this.options.namePathSeparator;
    const ignoreItemFn = $.isFunction(this.options.ignoreItemFn) ? this.options.ignoreItemFn : null;
    const disableCheckFn = $.isFunction(this.options.disableCheckFn) ? this.options.disableCheckFn : null;
    const unselectableCheckFn = $.isFunction(this.options.unselectableCheckFn) ? this.options.unselectableCheckFn : null;
    const getId = function(d, isGroup) {
      return isGroup ? d[groupIdField] : d[nodeIdField];
    };
    const getName = function(d, isGroup) {
      return isGroup ? d[groupNameField] : d[nodeNameField];
    };
    const getUuid = function(d, id, parentUuid) {
      if (uuidField) {
        return d[uuidField];
      }
      return parentUuid ? parentUuid + uuidSeparator + id : id;
    };
    const getDesc = function(d) {
      return descField && d[descField] || "";
    };
    const transform = function(data, parentUuid, deep) {
      let id, name, desc, uuid2, isGroup, childrenNodeCount = 0, childrenGroupCount = 0, descendantNodeCount = 0, descendantGroupCount = 0;
      data = data || [];
      deep = deep || 0;
      for (let i = 0; i < data.length; i++) {
        isGroup = isGroupFn(data[i]);
        id = getId(data[i], isGroup);
        name = getName(data[i], isGroup);
        desc = getDesc(data[i]);
        uuid2 = getUuid(data[i], id, parentUuid);
        data[i].__id = id;
        data[i].__name = name;
        data[i].__desc = desc;
        data[i].__uuid = uuid2;
        data[i].__deep = deep;
        data[i].__parentUuid = parentUuid;
        data[i].__isGroup = isGroup;
        data[i].__idPath = parentUuid ? ret[parentUuid].__idPath + uuidSeparator + id : id;
        data[i].__namePath = parentUuid ? ret[parentUuid].__namePath + namePathSeparator + name : name;
        data[i].__isRoot = me.options.showRoot ? !parentUuid : false;
        if (ignoreItemFn && ignoreItemFn(data[i])) {
          data.splice(i, 1);
          i--;
          continue;
        }
        ret[uuid2] = data[i];
        if (!isGroup) {
          childrenNodeCount++;
          descendantNodeCount++;
        } else {
          childrenGroupCount++;
          descendantGroupCount++;
          transform(data[i][childrenField], uuid2, deep + 1);
          descendantNodeCount += ret[uuid2].__descendantNodeCount || 0;
          descendantGroupCount += ret[uuid2].__descendantGroupCount || 0;
        }
        data[i].__disabled = disableCheckFn ? disableCheckFn(data[i]) : false;
        data[i].__selectable = unselectableCheckFn ? !unselectableCheckFn(data[i]) : true;
      }
      if (parentUuid) {
        ret[parentUuid].__childrenNodeCount = childrenNodeCount;
        ret[parentUuid].__childrenGroupCount = childrenGroupCount;
        ret[parentUuid].__descendantNodeCount = descendantNodeCount;
        ret[parentUuid].__descendantGroupCount = descendantGroupCount;
      }
    };
    transform(treeData);
    return ret;
  },
  getTreeHtml: function(treeData) {
    if (!treeData) {
      return "";
    }
    const me = this, options = me.options;
    const showNode = options.showNode, childrenField = options.childrenField;
    const getHtml = function(data, isLastFlagArr) {
      const html = [];
      let item;
      let deep;
      let rd;
      if (!data || !data.length) {
        return "";
      }
      data = me._dataSortFn(data);
      isLastFlagArr = isLastFlagArr || [];
      const lastGrpIdx = me._getLastGrpIdx(data);
      for (let i = 0, length = data.length; i < length; i++) {
        item = data[i];
        deep = item.__deep;
        isLastFlagArr[deep] = showNode ? i === length - 1 : i === lastGrpIdx;
        if (!showNode && !item.__isGroup) {
          continue;
        }
        rd = me._getItemRd(item, isLastFlagArr);
        if (rd.isGroup && rd.hasChild) {
          rd.childrenHtml = getHtml(item[childrenField], isLastFlagArr);
        }
        html.push(
          M_TREE_ITEM_XTPL.apply(
            $.extend({}, rd, {
              name: format.htmlEncode(rd.name),
              getPrefixedClassName
            })
          )
        );
      }
      return html.join("");
    };
    return getHtml(treeData);
  },
  _getLastGrpIdx: function(data) {
    for (let i = data.length - 1; i >= 0; i--) {
      if (data[i].__isGroup) {
        return i;
      }
    }
  },
  initGetItemRdFn: function() {
    const me = this, options = me.options;
    const showNode = options.showNode, itemActiveCls = options.itemActiveCls, itemHalfActiveCls = options.itemHalfActiveCls, multiSelect = options.multiSelect, pushCheckboxLeftSide = options.pushCheckboxLeftSide, renName = options.renNameFn, renNameText = options.renNameTextFn, tipFn = options.tipFn, indentWidth = options.indentWidth, lineHeight = options.lineHeight, descLineHeight = options.descLineHeight, autoScrollX = options.autoScrollX, nodeDraggable = options.nodeDraggable, groupIconCls = options.groupIconCls, nodeIconCls = options.nodeIconCls, renRowExtraContent = options.renRowExtraContent, isShowMenu = options.isShowMenu;
    const deepHeightWithDesc = parseInt(lineHeight, 10) + parseInt(descLineHeight, 10) + "px";
    const getIcon = function(d) {
      if (d.__isGroup) {
        return $.isFunction(groupIconCls) ? groupIconCls(d, groupIconCls) : groupIconCls;
      } else {
        return $.isFunction(nodeIconCls) ? nodeIconCls(d, nodeIconCls) : nodeIconCls;
      }
    };
    const getTextWidth = function(d) {
      if (autoScrollX) {
        return "none";
      }
      const deep = d.__deep || 0;
      let othersWidth = 0;
      othersWidth += deep * parseInt(indentWidth, 10);
      othersWidth += 14;
      if (getIcon(d)) {
        othersWidth += 30;
      }
      if (multiSelect) {
        othersWidth += 22;
      }
      return format.format("calc(100% - {0}px)", othersWidth);
    };
    me._getItemRd = function(item, isLastFlagArr) {
      var _a;
      const itemIcon = (_a = getIcon(item)) != null ? _a : "";
      const uuid2 = item.__uuid, deep = item.__deep, rd = {
        id: item.__id,
        name: item.__name,
        uuid: uuid2,
        nameHtml: renName.call(this, renNameText.call(this, item.__name, item), item),
        tip: tipFn(item.__name, item) || "",
        desc: item.__desc,
        deep: item.__deep,
        deepHeight: !item.__desc ? lineHeight : deepHeightWithDesc,
        lineHeight,
        descLineHeight,
        textWidth: getTextWidth(item),
        selectable: item.__selectable,
        disabled: item.__disabled,
        pushCheckboxLeftSide,
        itemIconCls: itemIcon,
        isSymbolIcon: itemIcon.startsWith("#"),
        draggable: !item.__isGroup && nodeDraggable,
        isGroup: item.__isGroup,
        autoScrollX: this.options.autoScrollX,
        extraNameLineContent: renRowExtraContent.call(this, item),
        showMenu: options.hasMenu && isShowMenu.call(this, item)
      };
      rd.hasChild = !showNode ? item.__childrenGroupCount : item.__childrenGroupCount + item.__childrenNodeCount;
      rd.cls = [
        getPrefixedClassName(me.expandedGroup[uuid2] ? "expanded" : ""),
        getPrefixedClassName(me.activeItemUuid[uuid2] ? itemActiveCls : ""),
        getPrefixedClassName(me.halfActiveItemUuid[uuid2] ? itemHalfActiveCls : "")
      ].join(" ");
      rd.deepBlocks = [];
      for (let i = 0; i < deep; i++) {
        rd.deepBlocks[i] = {
          width: indentWidth,
          noVerticalDotted: i < deep - 1 && isLastFlagArr[i + 1]
        };
      }
      if (deep && isLastFlagArr[deep]) {
        rd.deepBlocks[deep - 1].height = parseInt(lineHeight, 10) / 2 + "px";
      }
      return rd;
    };
  },
  initDataSortFn: function() {
    const me = this, options = me.options;
    const isSort = options.isSort, groupSortFn = options.groupSortFn, nodeSortFn = options.nodeSortFn;
    const localSortFn = function(data, key, direct, sortFn) {
      data.sort(function(data1, data2) {
        return sortFn.call(me, data1, data2, direct);
      });
    };
    const sortDataFn = function(data) {
      const groups = [], nodes = [];
      for (let i = 0, length = data.length; i < length; i++) {
        if (data[i].__isGroup) {
          groups.push(data[i]);
        } else {
          nodes.push(data[i]);
        }
      }
      if ($.isFunction(groupSortFn)) {
        localSortFn(groups, "__name", "ASC", groupSortFn);
      }
      if ($.isFunction(nodeSortFn)) {
        localSortFn(nodes, "__name", "ASC", nodeSortFn);
      }
      return groups.concat(nodes);
    };
    this._dataSortFn = function(data) {
      return isSort ? sortDataFn(data) : data;
    };
  },
  isRoot: function(record) {
    return record.__isRoot;
  },
  getNodeId: function(node) {
    return node.__id;
  },
  getFirstItemRecord: function(opt) {
    const $item = this.getItem(opt);
    if (!$item.length) {
      return false;
    }
    return this.getItemRecordByDom($item[0]);
  },
  bindMenuEvent: function() {
    const me = this;
    $(this.$el).delegate(".name-line ." + M_TREE_ITEM_MENU_CLS, "click", function(e) {
      me.emit("tree-menu-click", e);
    });
  },
  showMenuBtn: function(target) {
    this.hideMenuBtn();
    $(target).addClass(getPrefixedClassName("active"));
  },
  hideMenuBtn: function() {
    $(this.$el).find("." + M_TREE_ITEM_MENU_CLS + ".active").removeClass(getPrefixedClassName("active"));
  },
  setTreeHeight: function(height) {
    if (this.$view && height) {
      this.$view.css({
        height
      });
    }
  },
  getTreeEl: function() {
    return this.$view.get(0);
  },
  onDestroy: function() {
  },
  destroy: function() {
    this.onDestroy();
    fixscrollbar.call(this.$view, "destroy");
    this.$el.remove();
    this.$el = null;
    this.$bar = null;
    this.$view = null;
    this.$searchEmptyTip = null;
    this.$loadEmptyTip = null;
    this.$viewStyle = null;
    this.purgeListeners();
    delete this.options;
    delete this.sourceData;
    delete this.sourceDataHash;
    delete this.activeItemUuid;
    delete this.expandedGroup;
    delete this.events;
    this._dataSortFn = $.noop;
    this._getItemRd = $.noop;
  }
});
function copyObj(obj) {
  return obj && JSON.parse(JSON.stringify(obj));
}
function getItemSel(opt) {
  const sprintf = format.format;
  opt = opt || {};
  return [
    ".tree-item",
    opt.getGroup ? ".is-group" : "",
    opt.getNode ? ".is-node" : "",
    opt.selectable ? '[selectable="true"]' : "",
    opt.unselectable ? '[selectable="false"]' : "",
    opt.enable ? ":not(.disabled)" : "",
    opt.disable ? ".disabled" : "",
    opt.expanded ? ".expanded" : "",
    opt.collapsed ? ":not(.expanded)" : "",
    opt.searched ? ":not(.unsearched-hidden)" : "",
    opt.unsearched ? ".unsearched-hidden" : "",
    opt.hasChild ? ".has-child" : "",
    opt.uuid ? sprintf('[data-uuid="{0}"]', opt.uuid) : "",
    typeof opt.deep !== "undefined" ? sprintf('[data-deep="{0}"]', opt.deep) : ""
  ].join("");
}
const M_ALIGN_POS_TPL = '<div class="{triggerCls}" style="width: 1px;height: 1px;margin: 0;opacity: 0;visibility: hidden;"></div>';
const initRClick = function(opt) {
  if (!opt || !opt.tree || !opt.triggerCls) {
    return;
  }
  const rClickFn = function(e) {
    if ($.isFunction(opt.onBeforeAction) && (false === opt.onBeforeAction(e) || !opt.onBeforeAction(e))) {
      return;
    }
    const tpl = format.xformat(M_ALIGN_POS_TPL, opt), $pos = $(tpl), $target = $(e.target), position = $target.css("position");
    if (position !== "absolute" && position !== "relative" && position !== "fixed") {
      $target.css("position", "relative");
    }
    $target.append($pos);
    $pos.offset({
      left: e.clientX + $(document).scrollLeft(),
      top: e.clientY + $(document).scrollTop()
    });
    $("body").click();
    $pos.click();
  };
  opt.tree.on("view-r-click", rClickFn);
  return function clearRClick() {
    opt.tree.off("view-r-click", rClickFn);
  };
};
const getHandleViewScroll = function(opt) {
  if (!opt || !opt.tree || !opt.tree.menu) {
    return function() {
    };
  }
  const tree = opt.tree;
  const menu = tree.menu;
  return function() {
    if (!menu.isActive()) {
      return;
    }
    if (tree.isItemVisibleInView(menu.oprEl.closest(".tree-item"))) {
      menu.reLocation();
    } else {
      menu.endActive();
    }
  };
};
const getHandleDocScroll = function(opt) {
  if (!opt || !opt.tree || !opt.tree.menu) {
    return function() {
    };
  }
  const tree = opt.tree;
  const menu = tree.menu;
  return function() {
    if (!menu.isActive()) {
      return;
    }
    const $item = menu.oprEl.closest(".tree-item");
    if (!tree.isItemVisibleInView($item)) {
      tree.scrollToItem($item);
    }
    menu.reLocation();
  };
};
const updateMenuBtnPosition = function(opt) {
  if (!opt || !opt.tree || !opt.menuCls) {
    return;
  }
  const tree = opt.tree;
  const menuCls = opt.menuCls;
  const updateBtnPosition = function() {
    const btnWidth = opt.btnWidth || tree.$el.find("." + menuCls).eq(0).width() || 0;
    const btnLeft = tree.$el.width() + tree.$view.get(0).scrollLeft - btnWidth;
    tree.updateViewStyle(
      [
        format.format("#{0} ." + menuCls, tree.viewID),
        format.format("{ left: {0}px;}", btnLeft),
        format.format(".ps--active-y #{0} ." + menuCls, tree.viewID)
      ].join("")
    );
  };
  const updateFn = updateBtnPosition.bind(this, tree);
  const debounceUpdateFn = debounce(updateBtnPosition, 50);
  tree.on(
    "fn-toggle-group fn-toggle-all-group hand-toggle-group hand-toggle-all-group load-data mouseover-item",
    updateFn
  );
  tree.$view.on("scroll", debounceUpdateFn);
  $(document).on("scroll", debounceUpdateFn);
  return function clearPositionFn() {
    tree.off(
      "fn-toggle-group fn-toggle-all-group hand-toggle-group hand-toggle-all-group load-data mouseover-item",
      updateFn
    );
    tree.$view.off("scroll", debounceUpdateFn);
    $(document).off("scroll", debounceUpdateFn);
  };
};
var util = {
  initRClick,
  getHandleViewScroll,
  getHandleDocScroll,
  updateMenuBtnPosition
};
Tree.IGNORE_ITEM_SELECT_CLS = M_IGNORE_ITEM_SELECT_CLS;
Tree.TREE_ITEM_MENU_CLS = M_TREE_ITEM_MENU_CLS;
export { Tree as default, getTreeDefaultConfig, util as treeUtil };
