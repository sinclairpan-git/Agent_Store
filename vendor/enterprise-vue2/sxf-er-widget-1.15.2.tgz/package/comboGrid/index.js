import $ from 'jquery';
import { $i } from '@sxf/er-config';
import { getPrefixedClassName } from '@sxf/er-feature';
import XTpl from '@sxf/er-lib/xtpl';
import apply from '@sxf/er-utils/apply';
import { getScrollWidth } from '@sxf/er-utils/dom';
import Logger from '@sxf/er-utils/logger';
import Observable from '@sxf/er-utils/observable';
import oop from '@sxf/er-utils/oop';
import uuid from '@sxf/er-utils/uuid';
import Grid, { Resizeable, Selection, Tree, CheckSelection, RadioSelection, gridEventName } from '@sxf/er-widget/grid';
const getDefaultConfigs = () => {
  return {
    displayField: "text",
    width: 300,
    cls: "",
    autoSelectFirst: true,
    disabled: false,
    data: [],
    autoClear: true,
    clearable: false,
    autoLoad: false,
    listParent: null,
    selectID: null,
    size: "normal",
    notHideTargets: []
  };
};
const defaultGridConfigs = {
  width: "100%",
  height: "auto",
  minHeight: 120,
  maxHeight: 300,
  forcePreventDefault: true
};
const comboGridEvent = {
  render: "render",
  afterRender: "afterrender",
  collapse: "collapse",
  expand: "expand",
  beforeExpand: "beforeexpand",
  load: "load",
  select: "select",
  change: "change",
  value: "value",
  input: "input",
  unSelect: "unselect",
  selectAll: "selectall",
  unSelectAll: "unselectall",
  clear: "clear"
};
var comboTpl = `
<div id="{id}" class="{[values.getPrefixedClassName('sfis-combogrid')]} {[values.getPrefixedClassName('sfis-combogrid--' + values.size)]}">
    <tpl if="selectID">
            <select id="{selectID}" style-key="select" class="{[values.getPrefixedClassName('sfis-combogrid-select')]}"></select>
    <tpl else>
        <select id="{id}-select" style-key="select" class="{[values.getPrefixedClassName('sfis-combogrid-select')]}"></select>
    </tpl>
    <input style-key="input" type="hidden" id="{id}-hidden" />
    <input style-key="input" readonly id="{id}-input" type="text" class="{[values.getPrefixedClassName('sfis-combogrid-input')]} ellipsis" />
     <span id="{id}-clear" class="clear iconfont vtv-icon-unsupported {[values.getPrefixedClassName('sfis-combogrid-clear')]} {[values.getPrefixedClassName('sfis-combogrid-clear--hidden')]}"></span>
    <span id="{id}-caret" class="caret {[values.getPrefixedClassName('sfis-combogrid-caret')]}"></span>
</div>
`;
const ComboGridLogger = Logger("ComboGrid");
const TIP_FOCUS_HIDDEN_KEY = "data-hint-focus-hidden";
const LIST_SHOW_ATTR_KEY = "data-list-show";
const { selection: selectionEvent, store: storeEvent } = gridEventName;
const ComboGrid = oop.extend(Observable, {
  constructor: function(options) {
    this.options = {
      ...getDefaultConfigs(),
      ...options
    };
    this.options.data = $.makeArray(this.options.data);
    this.idList = [];
    const plugins = this.options.gridConfig.plugins = $.makeArray(this.options.gridConfig.plugins).concat(
      new Resizeable({
        reInitColumnWidthOnResize: false
      })
    );
    let selectionIndex = -1;
    plugins.forEach(function(plugin, i) {
      if ([Selection, CheckSelection, RadioSelection].includes(plugin) || plugin instanceof Selection) {
        selectionIndex = i;
      }
    });
    if (selectionIndex < 0) {
      plugins.push(Selection);
    }
    const store = this.options.gridConfig.store;
    if (!this.options.hasOwnProperty("ajax") && store && store.lastOption && !$.isEmptyObject(store.lastOption)) {
      this.options.ajax = store.lastOption;
    }
    this.listeners = this.options.listeners;
    this.init();
    const { render, afterRender, collapse, expand, beforeExpand, load, select, change, value } = comboGridEvent;
    this.addEvents(render, afterRender, collapse, expand, beforeExpand, load, select, change, value);
    ComboGrid.superclass.constructor.apply(this, arguments);
  },
  init: function() {
    this.id = uuid("sfis-combogrid-");
    this.parseOptions();
    this.createTpl();
    this.createGrid();
  },
  parseOptions: function() {
    this.gridOption();
  },
  updateData: function(data) {
    this.options.data = $.makeArray(data || []);
  },
  createTpl: function() {
    let tpl = this.options.tpl;
    if (!tpl) {
      tpl = comboTpl;
    }
    if (!(tpl instanceof XTpl)) {
      tpl = new XTpl(tpl);
    }
    this.options.tpl = tpl;
    return this.options.tpl;
  },
  gridOption: function() {
    if (!this.options.gridConfig) {
      ComboGridLogger.error("can not find grid config");
      return;
    }
    const config = this.options.gridConfig;
    config.width = config.width || defaultGridConfigs.width;
    config.height = config.hasOwnProperty("height") ? config.height : defaultGridConfigs.height;
    config.minHeight = Math.max(config.minHeight || 0, defaultGridConfigs.minHeight);
    config.maxHeight = config.maxHeight || defaultGridConfigs.maxHeight;
    config.forcePreventDefault = defaultGridConfigs.forcePreventDefault;
  },
  createGrid: function() {
    let sm;
    if (!this.grid) {
      this.grid = new Grid(this.options.gridConfig);
      this.store = this.grid.store;
      if (this.store.options.data && !this.grid.isPluginExist("PagingBar")) {
        this.store.initDataHash(this.store.options.data);
      }
      sm = this.grid.getPlugin(Selection);
      if (!sm) {
        ComboGridLogger.error("can not find Selection in Grid");
      }
      sm.on({
        scope: this,
        [selectionEvent.select]: this.selectRecord,
        [selectionEvent.unselect]: this.unSelectRecord,
        [selectionEvent.selectAll]: this.selectAllRecord,
        [selectionEvent.unselectAll]: this.unSelectAllRecord
      });
      const treePlugin = this.grid.getPlugin(Tree);
      const checkPlugin = this.grid.getPlugin(CheckSelection);
      this.multi = !!checkPlugin && !this.grid.getPlugin(RadioSelection);
      this.isMultiTreeSelect = treePlugin && checkPlugin && checkPlugin.options.checkboxInTreeField;
      this.grid.store.on({
        scope: this,
        [storeEvent.beforeLoad]: function() {
          if (this.rendered) {
            this.comboGridEl.addClass(getPrefixedClassName("loading"));
          }
        },
        [storeEvent.load]: function() {
          const me = this, valueField = this.grid.store.options.idProperty, data = [];
          let old, isSameData = true;
          if (this.rendered) {
            this.comboGridEl.removeClass(getPrefixedClassName("loading"));
          }
          if (this.options.autoClear) {
            old = this.getValue();
            old.forEach(function(item) {
              const record = me.grid.store.get(item[valueField]);
              if (record) {
                data.push(record.data);
              } else {
                isSameData = false;
              }
            });
            if (!isSameData) {
              this.setValue(data);
            }
          }
          if (!this.getValue().length && me.grid.store.dataList.length) {
            if (this.options.data.length && !(this.options.data.length === 1 && !this.options.data[0])) {
              this.setValue(this.options.data);
            } else if (this.options.autoSelectFirst) {
              $.each(me.grid.store.dataList, function(idx, key) {
                const r = me.grid.store.get(key);
                if (r.selectAble !== false) {
                  me.setValue([r.data]);
                  me.emit(comboGridEvent.input, me.idList);
                  return false;
                }
              });
            }
          }
        },
        [storeEvent.beforeInitData]: function(store, data) {
          if (!$.isFunction(this.options.processData)) {
            return;
          }
          let result = this.options.processData({
            combo: this,
            data
          });
          result = $.makeArray(result);
          if (result !== data) {
            data.splice(0);
            data.push.apply(data, result);
          }
        },
        [storeEvent.loadError]: function() {
          if (this.rendered) {
            this.comboGridEl.removeClass(getPrefixedClassName("loading"));
          }
        }
      });
    }
    return this.grid;
  },
  render: function(sel) {
    this.$el = $(this.getHtml());
    $(sel).append(this.$el);
    this.initEl();
    this.emit(comboGridEvent.render, this);
    this.onRender();
    this.emit(comboGridEvent.afterRender, this);
    this.bindEvent();
    if (this.options.autoLoad) {
      this.load();
    }
  },
  getHtml: function() {
    const ret = this.options.tpl.apply({
      id: this.id,
      selectID: this.options.selectID,
      size: this.options.size,
      getPrefixedClassName
    });
    return ret;
  },
  initEl: function() {
    this.comboGridEl = this.$el;
    this.selectEl = this.options.selectID ? this.$el.find("#" + this.options.selectID) : this.$el.find("#" + this.id + "-select");
    this.inputEl = this.$el.find("#" + this.id + "-input");
    this.hiddenEl = this.$el.find("#" + this.id + "-hidden");
    this.caretEl = this.$el.find("#" + this.id + "-caret");
    this.clearEl = this.$el.find("#" + this.id + "-clear");
    this.comboGridEl.css({
      width: this.options.width
    });
    this.inputEl.css({
      width: this.options.width
    });
    this.inputEl.attr("placeholder", this.options.placeholder);
    if (this.options.disabled) {
      this.inputEl.prop("disabled", true);
      this.selectEl.prop("disabled", true);
    }
    this.comboGridEl.addClass(this.options.cls);
    this.rendered = true;
    if (this.options.data.length) {
      this.setValue(this.options.data);
    }
  },
  onRender: function() {
  },
  bindEvent: function() {
    const me = this;
    this.comboGridEl.delegate(
      ".sfis-combogrid-input, .sfis-combogrid-caret",
      "click",
      this.clickFn = function() {
        if (me.options.disabled) {
          return;
        }
        me.toggle();
      }
    );
    this.clearEl.get(0).addEventListener(
      "click",
      this.clearableFn = function() {
        if (me.options.disabled) {
          return;
        }
        me.setValue("");
        me.emit(comboGridEvent.clear, me);
      }
    );
    document.documentElement.addEventListener(
      "mousedown",
      this.mouseDownFn = function(e) {
        if (!me.expanded && !me.__isClickExpanding()) {
          return;
        }
        const t = $(e.target);
        if (t.parents("#" + me.id).length || t.parents("#" + me.id + "-grid").length || t.id === me.id || t.id === me.id + "-grid") {
          return;
        }
        const isClickNotHideTargets = (me.options.notHideTargets || []).some(
          (notHideTarget) => notHideTarget.contains(e.target)
        );
        if (isClickNotHideTargets) {
          return;
        }
        if (!me.expanded) {
          me.abort();
          return;
        }
        me.collapse();
      },
      true
    );
    $(document.body).bind(
      "mousewheel",
      this.mouseWheelFn = function(e) {
        if (!me.expanded) {
          return;
        }
        const t = $(e.target);
        if (t.parents("#" + me.id + "-grid").length || t.id === me.id + "-grid") {
          return;
        }
        me.collapse();
      }
    );
    $(window).resize(
      this.windowResizeFn = function() {
        me.collapse();
      }
    );
  },
  toggle: function() {
    if (this.expanded) {
      this.collapse();
    } else {
      this.__setClickExpanding(true);
      this.emit(comboGridEvent.beforeExpand, this);
      this.expand();
    }
  },
  __setClickExpanding: function(status) {
    this.__clickExpanding = status;
  },
  __isClickExpanding: function() {
    return this.__clickExpanding;
  },
  collapse: function() {
    if (!this.expanded) {
      return;
    }
    this.inputEl.removeAttr(TIP_FOCUS_HIDDEN_KEY);
    this.inputEl.removeAttr(LIST_SHOW_ATTR_KEY);
    this.listEl.hide();
    this.expanded = false;
    this.toggleExpandStatus();
    this.emit(comboGridEvent.collapse, this);
  },
  expand: function() {
    const expandFn = function() {
      this.inputEl.attr(TIP_FOCUS_HIDDEN_KEY, true);
      this.inputEl.attr(LIST_SHOW_ATTR_KEY, true);
      this.listEl.show();
      this.renderGrid();
      this.expanded = true;
      this.toggleExpandStatus();
      this.emit(comboGridEvent.expand, this);
      this.selectGrid();
      this.updateListElPosition();
      this.__setClickExpanding(false);
    };
    if (this.expanded) {
      return;
    }
    this.createListEl();
    if (this.options.ajax) {
      if (this.grid.store.isLoading()) {
        return;
      }
      this.load(function(...args) {
        var _a;
        const xhrRes = (_a = args[2]) == null ? void 0 : _a[0];
        const isAbort = (xhrRes == null ? void 0 : xhrRes.statusText) === "abort";
        if (isAbort) {
          this.__setClickExpanding(false);
          return;
        }
        expandFn.call(this);
      });
    } else {
      expandFn.call(this);
    }
  },
  disable: function() {
    this.options.disabled = true;
    if (this.rendered) {
      this.inputEl.prop("disabled", true);
      this.selectEl.prop("disabled", true);
    }
  },
  enable: function() {
    this.options.disabled = false;
    if (this.rendered) {
      this.inputEl.prop("disabled", false);
      this.selectEl.prop("disabled", false);
    }
  },
  toggleClearable: function(status = this.options.clearable) {
    if (status !== this.options.clearable) {
      this.options.clearable = status;
    }
    status && !!this.inputEl.prop("value") ? this.clearEl.removeClass(getPrefixedClassName("sfis-combogrid-clear--hidden")) : this.clearEl.addClass(getPrefixedClassName("sfis-combogrid-clear--hidden"));
  },
  updateOptions: function(config) {
    this.options = $.extend(true, this.options, config);
  },
  load: function(callback, option) {
    const me = this;
    if (!option && !this.options.ajax) {
      return;
    }
    if (option) {
      this.options.ajax = option;
    }
    const cb = this.options.ajax.callback;
    const o = apply({}, this.options.ajax);
    o.callback = function() {
      if (typeof cb === "function") {
        cb.apply(me, arguments);
      }
      if (typeof callback === "function") {
        callback.apply(me, arguments);
      }
      me.emit(comboGridEvent.load, me);
    };
    this.grid.store.load(o);
  },
  abort: function() {
    if (this.grid.store.isLoading()) {
      this.grid.store.stop();
    }
  },
  toggleExpandStatus: function() {
    if (!this.rendered) {
      return;
    }
    if (this.expanded) {
      this.inputEl.addClass("focus");
    } else {
      this.inputEl.removeClass("focus");
    }
  },
  selectGrid: function() {
    const data = this.getValue(), valueField = this.grid.store.options.idProperty, records = [], sm = this.grid.getPlugin(Selection);
    if ($.isArray(data)) {
      data.forEach(function(item) {
        records.push(item[valueField]);
      });
    }
    this.suspendSelectEvent = true;
    sm.unSelectAll();
    sm.select(records);
    this.suspendSelectEvent = false;
  },
  getAppendParent: function() {
    let $listParent = this.options.listParent;
    if (!$listParent || $listParent.size()) {
      const $container = this.$el.closest(".sf-popover-vtip");
      if ($container.size()) {
        $listParent = $container;
      }
    }
    return $($listParent || document.body);
  },
  createListEl: function() {
    const { gridConfig, searchPlaceholder } = this.options;
    const comboUtid = this.getComboUtid();
    const searchUtidBase = "combo-search-input";
    const searchUtid = comboUtid ? `${comboUtid}-${searchUtidBase}` : searchUtidBase;
    const searchEl = (gridConfig == null ? void 0 : gridConfig.search) ? `
    <div class="${getPrefixedClassName("sfis-combogrid-grid-search")}">
      <i class="${getPrefixedClassName("sfis-combogrid-grid-search-icon")} iconfont vtv-icon-comp-search" />
      <input class="${getPrefixedClassName(
      "sfis-combogrid-grid-search-value"
    )}" utid="${searchUtid}" style-key="input" type="text" placeholder="${searchPlaceholder}"/>
    </div>` : "";
    if (!this.listEl) {
      this.listEl = $(
        [
          '<div style="display: none;" id="' + this.id + `-grid" class="${getPrefixedClassName("sfis-combogrid-grid-wrap")}">`,
          searchEl,
          "</div>"
        ].join("")
      );
      if (!gridConfig || !gridConfig.width || gridConfig.width === "100%") {
        this.listEl.css({
          width: this.options.width === "100%" ? this.comboGridEl.outerWidth() : this.options.width
        });
      }
      this.getAppendParent().append(this.listEl);
      if (gridConfig == null ? void 0 : gridConfig.search) {
        this.listEl.delegate(".sfis-combogrid-grid-search > input", "input", (e) => {
          this.grid.store.search(e.target.value);
        });
      }
    }
  },
  updateListElPosition: function() {
    if (!this.rendered && this.listEl) {
      return;
    }
    let left, top;
    const padding = 10;
    const rect = this.comboGridEl.get(0).getBoundingClientRect();
    const gridRect = this.listEl.get(0).getBoundingClientRect();
    const screenWidth = document.documentElement.clientWidth;
    const availWidth = screenWidth - rect.left - rect.width;
    const screenHeight = document.documentElement.clientHeight;
    const availHeight = screenHeight - rect.top - rect.height - padding;
    if (availWidth < gridRect.width && rect.left > gridRect.width) {
      left = rect.left + rect.width - gridRect.width;
    } else {
      left = rect.left;
    }
    if (availHeight < gridRect.height) {
      top = rect.top - gridRect.height;
      if (top < 0) {
        if (rect.top - padding < availHeight) {
          top = rect.top + rect.height;
          this.grid.setHeight(availHeight);
        } else {
          top = padding;
          this.grid.setHeight(rect.top - padding);
        }
      }
    } else {
      top = rect.top + rect.height;
    }
    this.listEl.css({
      left,
      top
    });
  },
  renderGrid: function() {
    if (this.grid.rendered) {
      return;
    }
    this.grid.render(this.listEl);
  },
  flatGroupItems: function(r) {
    const dataHash = this.grid.store.dataHash;
    let list = [];
    const children = r.get("__children");
    children.forEach(function(item) {
      if (dataHash[item].get("__isGroup")) {
        list = list.concat(this.flatGroupItems(dataHash[item]));
        return;
      }
      list.push(item);
    }, this);
    return list;
  },
  multiTreeSelectGroup: function(r) {
    const sm = this.grid.getPlugin(Selection);
    let itemList = this.flatGroupItems(r);
    itemList = itemList.filter((item) => !this.idList.includes(item));
    sm.select(itemList, { noEvent: true });
    const old = this.getValue().slice();
    const data = old.slice();
    itemList.forEach((item) => {
      if (this.grid.store.dataHash.hasOwnProperty(item)) {
        const r2 = this.grid.store.dataHash[item];
        if (r2.selectAble !== false) {
          data.push(r2.data);
        }
      }
    });
    this.setValue(data);
    this.emit(comboGridEvent.select, this, data);
    this.emit(comboGridEvent.change, this, data, old);
    this.emit(comboGridEvent.input, this.idList);
  },
  multiTreeUnSelectGroup: function(r) {
    const sm = this.grid.getPlugin(Selection);
    const itemList = this.flatGroupItems(r);
    const key = this.grid.store.options.idProperty;
    const old = this.getValue().slice();
    const data = old.filter((item) => item.selectAble === false || !itemList.includes(item[key]));
    sm.unSelect(itemList, { noEvent: true });
    this.setValue(data);
    this.emit(comboGridEvent.unSelect, this, data);
    this.emit(comboGridEvent.change, this, data, old);
    this.emit(comboGridEvent.input, this.idList);
  },
  setMultiTreeParentSelected: function(r) {
    if (!this.isMultiTreeSelect) {
      return;
    }
    this.grid.getPlugin(Tree).setParentSelected(r);
  },
  selectRecord: function(r) {
    if (this.suspendSelectEvent) {
      this.setMultiTreeParentSelected(r);
      return;
    }
    const isGroup = r.get("__isGroup");
    if (this.isMultiTreeSelect && isGroup) {
      this.multiTreeSelectGroup(r);
      return;
    }
    let data;
    const old = this.getValue().slice();
    if (this.multi) {
      data = old.slice();
      data.push(r.data);
      this.setValue(data);
    } else {
      data = [r.data];
      this.setValue(data);
      this.collapse();
    }
    this.emit(comboGridEvent.select, this, [r]);
    this.emit(comboGridEvent.change, this, data, old);
    this.emit(comboGridEvent.input, this.idList);
  },
  unSelectRecord: function(r) {
    if (this.suspendSelectEvent) {
      return;
    }
    if (!this.multi) {
      return;
    }
    const isGroup = r.get("__isGroup");
    if (this.isMultiTreeSelect && isGroup) {
      this.multiTreeUnSelectGroup(r);
      return;
    }
    const key = this.grid.store.options.idProperty;
    const old = this.getValue().slice();
    const data = old.slice();
    let index = -1;
    data.forEach(function(item, i) {
      if (item[key] === r.get(key)) {
        index = i;
      }
    });
    if (index !== -1) {
      data.splice(index, 1);
      this.setValue(data);
      this.emit(comboGridEvent.unSelect, this, [r]);
      this.emit(comboGridEvent.change, this, data, old);
      this.emit(comboGridEvent.input, this.idList);
    }
  },
  selectAllRecord: function() {
    if (this.suspendSelectEvent) {
      return;
    }
    if (!this.multi) {
      return;
    }
    const data = [];
    const old = this.getValue().slice();
    for (const key in this.grid.store.dataHash) {
      if (this.grid.store.dataHash.hasOwnProperty(key)) {
        const r = this.grid.store.dataHash[key];
        if (r.selectAble !== false) {
          data.push(r.data);
        }
      }
    }
    this.setValue(data);
    this.emit(comboGridEvent.selectAll, this);
    this.emit(comboGridEvent.change, this, data, old);
    this.emit(comboGridEvent.input, this.idList);
  },
  unSelectAllRecord: function() {
    if (this.suspendSelectEvent) {
      return;
    }
    if (!this.multi) {
      return;
    }
    const old = this.getValue().slice();
    const data = [];
    this.setValue(data);
    this.emit(comboGridEvent.unSelectAll, this);
    this.emit(comboGridEvent.change, this, data, old);
    this.emit(comboGridEvent.input, this.idList);
  },
  getValue: function() {
    return (this.currentData || []).slice();
  },
  getSelectedRecords: function() {
    const sm = this.grid.getPlugin(Selection);
    const getRecordDisabled = sm.getRecordDisabled.bind(sm);
    return this.grid.store.toModels(this.getValue()).map((record) => {
      return { data: record.data, disabled: getRecordDisabled(record) };
    });
  },
  setValue: function(data) {
    const valueField = this.grid.store.options.idProperty, displayField = this.options.displayField, idList = [], textList = [], d = [], me = this;
    data = data || [];
    if (!$.isArray(data)) {
      data = [data];
    }
    data.forEach(function(item) {
      let record;
      if (typeof item === "string" || typeof item === "number") {
        record = me.grid.store.dataHash[item];
        item = record && record.data;
      }
      if (item) {
        if (typeof me.options.renderer === "function") {
          textList.push(me.options.renderer.call(me, item[displayField], item));
        } else {
          textList.push(item[displayField]);
        }
        idList.push(item[valueField]);
        d.push(item);
      }
    });
    this.idList = idList;
    this.currentData = d;
    if (this.rendered) {
      this.inputEl.val(textList.join($i("scp.vt_component.common.widget.ComboGrid.text_list_character")));
      this.hiddenEl.val(idList.join(","));
    }
    this.emit(comboGridEvent.value, {
      data: this.currentData
    });
    this.setDataTip(textList.join($i("scp.vt_component.common.widget.ComboGrid.data_tip_character")));
    this.toggleClearable(this.options.clearable);
  },
  setDataTip: function(tip) {
    const clientWidth = this.inputEl.get(0).clientWidth, scrollWidth = getScrollWidth(this.inputEl.get(0)), $wrap = this.inputEl.parent();
    if (scrollWidth > clientWidth) {
      $wrap.attr("data-tip", tip);
      $wrap.attr("data-hint-pos", "r");
    } else {
      $wrap.removeAttr("data-tip");
    }
  },
  selectFirst: function() {
    const me = this;
    if (me.grid.store.dataList.length) {
      $.each(me.grid.store.dataList, function(idx, key) {
        const r = me.grid.store.get(key);
        if (r.selectAble !== false) {
          me.setValue([r.data]);
          return false;
        }
      });
    }
  },
  setPlaceholder: function(v) {
    this.inputEl.attr("placeholder", v);
  },
  getComboEl: function() {
    return this.$el;
  },
  setInputElValue: function(value) {
    this.inputEl.val(value);
  },
  select: function(record) {
    const sm = this.grid.getPlugin(Selection);
    sm.select.call(sm, record);
  },
  unSelect: function(record) {
    const sm = this.grid.getPlugin(Selection);
    sm.unSelect.call(sm, record);
  },
  getComboUtid: function() {
    return this.options.utid;
  },
  destroy: function() {
    const me = this;
    if (this.comboGridEl) {
      this.comboGridEl.unbind("click", this.clickFn);
    }
    if (this.mouseDownFn) {
      document.documentElement.removeEventListener("mousedown", this.mouseDownFn, true);
    }
    if (this.mouseWheelFn) {
      $(document.body).unbind("mousewheel", this.mouseWheelFn);
    }
    if (this.windowResizeFn) {
      $(window).unbind("resize", this.windowResizeFn);
    }
    ["grid", "listEl", "comboGridEl"].forEach(function(item) {
      if (me[item]) {
        if (me[item].destroy) {
          me[item].destroy();
        } else if (me[item].remove) {
          me[item].remove();
        }
        me[item] = null;
      }
    });
    this.clear();
  }
});
const pluginName = "sfis-plugin-combogrid";
function fixcombogrid(options) {
  if (typeof options === "string") {
    const arg = arguments[1], arg2 = arguments[2];
    switch (options) {
      case "option":
        return this.map(function(idx, dom) {
          return get(dom);
        });
      case "value":
        if (arg === void 0 || arg === null) {
          return this.map(function(idx, dom) {
            const combo = get(dom);
            return combo && combo.getValue();
          });
        }
        return this.each(function(idx, dom) {
          const combo = get(dom);
          return combo && combo.setValue(arg);
        });
      case "disable":
        return this.each(function(idx, dom) {
          const combo = get(dom);
          return combo && combo.disable();
        });
      case "enable":
        return this.each(function(idx, dom) {
          const combo = get(dom);
          return combo && combo.enable();
        });
      case "updateOptions":
        return this.each(function(idx, dom) {
          const combo = get(dom);
          return combo && combo.updateOptions(arg, arg2);
        });
      case "load":
        return this.each(function(idx, dom) {
          const combo = get(dom);
          return combo && combo.load(arg, arg2);
        });
      case "expand":
        return this.each(function(idx, dom) {
          const combo = get(dom);
          return combo && combo.expand();
        });
      case "collapse":
        return this.each(function(idx, dom) {
          const combo = get(dom);
          return combo && combo.collapse();
        });
      case "empty":
      case "clear":
        return this.each(function(idx, dom) {
          const combo = get(dom);
          return combo && combo.setValue([]);
        });
      case "destroy":
        return this.each(function(idx, dom) {
          const combo = get(dom);
          if (combo) {
            combo.destroy();
          }
        });
    }
  } else {
    return this.each(function() {
      const combo = $(this).data(pluginName);
      let plugin;
      if (!combo) {
        plugin = createComboGrid(this, options);
        return $(this).data(pluginName, plugin);
      }
    });
  }
}
function get(dom) {
  const combo = $(dom).data(pluginName);
  if (!combo) {
    return;
  }
  return combo;
}
function createComboGrid(dom, options) {
  options = parseOptions(dom, options);
  const combo = new ComboGrid(options);
  wrap(dom, combo);
  autoLoadSelectOption(dom, combo);
  combo.on({
    change: function(comp, data) {
      if (data && data.length) {
        const value = data[0][combo.grid.store.options.idProperty];
        if ($("option", dom).size()) {
          $(dom).val(value);
        } else {
          $(dom).attr("_value", value);
        }
      }
    },
    load: function() {
      if (!combo.multi) {
        loadDataToDom(dom, combo);
      }
      const value = $(dom).attr("_value");
      if (value) {
        $(dom).val(value).removeAttr("_value");
      }
    }
  });
  return combo;
}
function parseOptions(dom, options) {
  const $dom = $(dom), w = parseInt($dom.css("width"), 10), placeholder = $dom.attr("placeholder");
  options = options || {};
  options.width = options.width || w;
  options.placeholder = options.placeholder || placeholder;
  if ($(dom).is(":disabled")) {
    options.disabled = true;
  }
  return options;
}
function loadDataToDom(dom, combo) {
  const html = [];
  combo.grid.store.dataList.forEach(function(key) {
    html.push('<option value="' + key + '"></option>');
  });
  $(dom).html(html.join(""));
}
function wrap(dom, combo) {
  const n = $(dom).wrapAll(function() {
    return wrapFunc.call(this);
  });
  combo.render(n.parent());
}
function wrapFunc() {
  const target = $(this);
  const styles = [];
  ["margin-left", "margin-right", "margin-top", "margin-bottom"].forEach(function(css) {
    styles.push(css + ":" + target.css(css));
  });
  return `<span class="${getPrefixedClassName("sfis-combogrid-wrap")}" style="` + styles.join(";") + '"></span>';
}
function autoLoadSelectOption(dom, combo) {
  const valueField = combo.grid.store.options.idProperty, displayField = combo.options.displayField, data = [], old = $(dom).val();
  let v = null;
  $(dom).children().each(function(idx, d) {
    const item = {};
    item[valueField] = $(d).attr("value");
    item[displayField] = $(d).html();
    data.push(item);
    if (old && item[valueField] === old) {
      v = item;
    }
  });
  combo.grid.store.loadData(data);
  if (v) {
    combo.setValue(v);
  }
}
export { ComboGrid as default, fixcombogrid };
