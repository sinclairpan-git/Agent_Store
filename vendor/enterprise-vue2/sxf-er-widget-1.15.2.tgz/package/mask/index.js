import $ from 'jquery';
import { $i } from '@sxf/er-config';
import { featureConfig, getPrefixedClassName } from '@sxf/er-feature';
import { isInstanceofAjax } from '@sxf/er-utils/ajax';
import DelayedTask from '@sxf/er-utils/delayedTask';
import Observable from '@sxf/er-utils/observable';
import { isNumber } from 'lodash-es';
const DEFER_DEFAULT = 300;
const getLoadMaskConfig = () => {
  var _a, _b;
  const globalConfigDefer = (_b = (_a = featureConfig.componentConfig) == null ? void 0 : _a.mask) == null ? void 0 : _b.defer;
  const defer = isNumber(globalConfigDefer) ? globalConfigDefer : DEFER_DEFAULT;
  return {
    loadingMsg: $i("scp.vt_component.common.widget.LoadMask.loading_msg"),
    submitMsg: $i("scp.vt_component.common.widget.LoadMask.submit_msg"),
    defer
  };
};
const getMaskCls = () => getPrefixedClassName("v-loadmask");
const getLoadingCls = () => getPrefixedClassName("v-loadmask-loading");
const getMsgCls = () => getPrefixedClassName("v-loadmask-msg");
const getPositionCls = () => getPrefixedClassName("v-loadmask-position");
const MASK_MSG_CLS = "v-loadmask-msg";
class LoadMask {
  constructor(target, options = {}) {
    const loadMaskConfig = getLoadMaskConfig();
    this.target = $(target);
    this.observable = new Observable();
    this.options = options;
    this._showCount = 0;
    this.defer = "defer" in options ? options.defer : loadMaskConfig.defer;
    this.msg = options.msg || loadMaskConfig.loadingMsg;
    this.cls = `${getMaskCls()} ${options.cls || ""}`;
    this.loadingCls = `${getLoadingCls()} ${options.loadingCls || ""}`;
    this.msgCls = `${getMsgCls()} ${options.msgCls || ""}`;
    this.alignCls = getPrefixedClassName(options.align === "horizontal" ? "align-horizontal" : "");
    if (this.defer > 0) {
      this.delayer = new DelayedTask(this.show, this, [true]);
    }
  }
  on(...args) {
    this.observable.on(...args);
  }
  init() {
    const target = this.target;
    if (!target || !target.size()) {
      return this;
    }
    const loadingHtml = this.__getLoadingHtml();
    this.el = $(`<div class="unselectable ${this.cls}">${loadingHtml}</div>`);
    target.append(this.el);
    this.textEl = this.el.find(`.${MASK_MSG_CLS}`);
    this.hide();
    this.init = () => false;
    return this;
  }
  __getLoadingHtml() {
    return `
      <div class="${getPrefixedClassName("v-loadmask-content")} ${this.alignCls}">
       <svg fill="none" version="1.1" width="16" height="16" viewBox="0 0 16 16" 
            class="${getPrefixedClassName("v-loadmask-loading__path")} ${this.loadingCls}">
          <defs>
            <clipPath id="master_svg0_13643_36285"><rect x="0" y="0" width="16" height="16" rx="0"/></clipPath>
          </defs>
          <g>
            <g clip-path="url(#master_svg0_13643_36285)">
              <g>
                <path d="M10.352002919921874,14.595048604774474C13.143092919921875,13.599148604774475,15.004992919921875,10.954078604774475,15.000992919921876,7.990648604774475C14.996992919921874,5.027208604774476,13.127792919921875,2.3872286047744753,10.334002919921875,1.3990002047744752C9.809522919921875,1.2004996047744751,9.224372919921874,1.472014604774475,9.037312919921876,2.000678604774475C8.850242919921875,2.529338604774475,9.134402919921875,3.108458604774475,9.667002919921876,3.2839986047744754C11.662992919921875,3.9898486047744752,12.998392919921875,5.875818604774475,13.001292919921875,7.992908604774475C13.004192919921875,10.110008604774475,11.673992919921876,11.999648604774475,9.680002919921876,12.711048604774476C9.160022919921875,12.896748604774475,8.888952919921875,13.468748604774476,9.074462919921874,13.988848604774475C9.259962919921875,14.508948604774474,9.831832919921874,14.780248604774474,10.352002919921874,14.595048604774474ZM5.648002919921875,14.595048604774474C2.856902919921875,13.599148604774475,0.994957389921875,10.954078604774475,0.998999774451875,7.990648604774475C1.003041739921875,5.027208604774476,2.8721929199218748,2.3872286047744753,5.666002919921875,1.3990002047744752C6.191682919921875,1.196319604774475,6.780942919921875,1.4677006047744752,6.968622919921875,1.998916604774475C7.156312919921875,2.5301286047744753,6.868322919921875,3.111458604774475,6.332002919921875,3.2839986047744754C4.3361129199218755,3.9900586047744753,3.000882919921875,5.876168604774475,2.998182919921875,7.993268604774475C2.995492919921875,10.110358604774476,4.325912919921874,11.999848604774476,6.320002919921875,12.711048604774476C6.839872919921875,12.896848604774474,7.110822919921875,13.468748604774476,6.925352919921875,13.988748604774475C6.739872919921875,14.508748604774475,6.168122919921875,14.780148604774475,5.648002919921875,14.595048604774474Z" fill="#596A80" fill-opacity="1"/>
              </g>
            </g>
          </g>
        </svg>
        <div class="unselectable ${this.msgCls}">
          ${this.msg}
        </div>
      </div>
    `;
  }
  show(options) {
    const target = this.target;
    if (!$.isPlainObject(options)) {
      options = {
        force: options
      };
    }
    const force = options.force;
    if (!force && this.delayer) {
      this.delayer.delay(this.defer, null, null, [
        $.extend({}, options, {
          force: true
        })
      ]);
      return true;
    }
    this.init();
    if (target) {
      target.addClass(getPositionCls());
    }
    if (this.el) {
      this.el.css("display", "");
    }
    if (options.hasOwnProperty("text") && this.textEl) {
      this.textEl.text(options.text);
    }
    this.observable.emit("show");
  }
  multiShow(...args) {
    if (!this._showCount) {
      this.show(...args);
    }
    this._showCount += 1;
  }
  hide() {
    if (this.delayer) {
      this.delayer.cancel();
    }
    if (this.el) {
      this.el.css("display", "none");
    }
    if (this.target) {
      this.target.removeClass(getPositionCls());
    }
    if (this.textEl) {
      this.textEl.text(this.msg);
    }
    this._showCount = 0;
  }
  multiHide(...args) {
    this._showCount = Math.max(this._showCount - 1, 0);
    if (!this._showCount) {
      this.hide(...args);
    }
  }
  text(text, type) {
    this.msg = text;
    this.toggleStatus(type);
    if (this.textEl) {
      this.textEl.text(text);
    }
  }
  html(html) {
    if (this.textEl) {
      this.textEl.html(html);
    }
  }
  destroy() {
    this.hide();
    if (this.el) {
      this.textEl.remove();
      this.el.remove();
    }
    this.el = this.textEl = this.target = null;
  }
  toggleStatus(type) {
    if (typeof type === "undefined") {
      return;
    }
    const isError = type === "error";
    if (this.el) {
      this.el[isError ? "addClass" : "removeClass"](
        `${getPrefixedClassName("v-loadmask-error")} ${getPrefixedClassName("is-error")}`
      );
    }
  }
  detectRequestProgress(defer, type, text, forceShow, options) {
    const loadMaskConfig = getLoadMaskConfig();
    options = options || {};
    type = type || "load";
    const textMap = {
      load: loadMaskConfig.loadingMsg,
      submit: loadMaskConfig.submitMsg
    };
    text = text || textMap[type];
    this.text(text, "loading");
    this.show(forceShow);
    if ($.isArray(defer)) {
      $.each(defer, function(idx, item) {
        if (isInstanceofAjax(item)) {
          defer[idx] = item.promise();
        }
      });
      defer = $.when.apply($, defer);
    }
    defer.done(() => {
      if (options.keepLoadMask) {
        return;
      }
      this.hide();
    }).fail(() => {
      if (type === "load") {
        this.text(
          $i("scp.vt_component.common.widget.LoadMask.failed_to_load_data"),
          "error"
        );
      } else {
        this.hide();
      }
    });
    if (defer.error) {
      defer.error(() => {
        if (type === "load") {
          this.text(
            $i("scp.vt_component.common.widget.LoadMask.failed_to_loading_data"),
            "error"
          );
        } else {
          this.hide();
        }
      });
    }
    return defer;
  }
}
export { LoadMask as default };
