import $ from 'jquery';
(function($$1) {
  var supportedCSS, styles = document.getElementsByTagName("head")[0].style, toCheck = "transformProperty WebkitTransform OTransform msTransform MozTransform".split(" ");
  for (var a = 0; a < toCheck.length; a++)
    if (styles[toCheck[a]] !== void 0)
      supportedCSS = toCheck[a];
  var IE = eval('"v"=="\v"');
  $.fn.extend({
    rotate: function(parameters) {
      if (this.length === 0 || typeof parameters == "undefined")
        return;
      if (typeof parameters == "number")
        parameters = { angle: parameters };
      var returned = [];
      for (var i = 0, i0 = this.length; i < i0; i++) {
        var element = this.get(i);
        if (!element.Wilq32 || !element.Wilq32.PhotoEffect) {
          var paramClone = $$1.extend(true, {}, parameters);
          var newRotObject = new Wilq32.PhotoEffect(element, paramClone)._rootObj;
          returned.push($$1(newRotObject));
        } else {
          element.Wilq32.PhotoEffect._handleRotation(parameters);
        }
      }
      return returned;
    },
    getRotateAngle: function() {
      var ret = [];
      for (var i = 0, i0 = this.length; i < i0; i++) {
        var element = this.get(i);
        if (element.Wilq32 && element.Wilq32.PhotoEffect) {
          ret[i] = element.Wilq32.PhotoEffect._angle;
        }
      }
      return ret;
    },
    stopRotate: function() {
      for (var i = 0, i0 = this.length; i < i0; i++) {
        var element = this.get(i);
        if (element.Wilq32 && element.Wilq32.PhotoEffect) {
          clearTimeout(element.Wilq32.PhotoEffect._timer);
        }
      }
    }
  });
  var Wilq32 = window.Wilq32 || {};
  Wilq32.PhotoEffect = function() {
    if (supportedCSS) {
      return function(img, parameters) {
        img.Wilq32 = {
          PhotoEffect: this
        };
        this._img = this._rootObj = this._eventObj = img;
        this._handleRotation(parameters);
      };
    } else {
      return function(img, parameters) {
        this._img = img;
        this._rootObj = document.createElement("span");
        this._rootObj.style.display = "inline-block";
        this._rootObj.Wilq32 = {
          PhotoEffect: this
        };
        img.parentNode.insertBefore(this._rootObj, img);
        if (img.complete) {
          this._Loader(parameters);
        } else {
          var self = this;
          $(this._img).bind("load", function() {
            self._Loader(parameters);
          });
        }
      };
    }
  }();
  Wilq32.PhotoEffect.prototype = {
    _setupParameters: function(parameters) {
      this._parameters = this._parameters || {};
      if (typeof this._angle !== "number")
        this._angle = 0;
      if (typeof parameters.angle === "number")
        this._angle = parameters.angle;
      this._parameters.animateTo = typeof parameters.animateTo === "number" ? parameters.animateTo : this._angle;
      this._parameters.step = parameters.step || this._parameters.step || null;
      this._parameters.easing = parameters.easing || this._parameters.easing || function(x, t, b, c, d) {
        return -c * ((t = t / d - 1) * t * t * t - 1) + b;
      };
      this._parameters.duration = parameters.duration || this._parameters.duration || 1e3;
      this._parameters.callback = parameters.callback || this._parameters.callback || function() {
      };
      if (parameters.bind && parameters.bind != this._parameters.bind)
        this._BindEvents(parameters.bind);
    },
    _handleRotation: function(parameters) {
      this._setupParameters(parameters);
      if (this._angle == this._parameters.animateTo) {
        this._rotate(this._angle);
      } else {
        this._animateStart();
      }
    },
    _BindEvents: function(events) {
      if (events && this._eventObj) {
        if (this._parameters.bind) {
          var oldEvents = this._parameters.bind;
          for (var a2 in oldEvents)
            if (oldEvents.hasOwnProperty(a2))
              $(this._eventObj).unbind(a2, oldEvents[a2]);
        }
        this._parameters.bind = events;
        for (var a2 in events)
          if (events.hasOwnProperty(a2))
            $(this._eventObj).bind(a2, events[a2]);
      }
    },
    _Loader: function() {
      if (IE) {
        return function(parameters) {
          var width = this._img.width;
          var height = this._img.height;
          this._img.parentNode.removeChild(this._img);
          this._vimage = this.createVMLNode("image");
          this._vimage.src = this._img.src;
          this._vimage.style.height = height + "px";
          this._vimage.style.width = width + "px";
          this._vimage.style.position = "absolute";
          this._vimage.style.top = "0px";
          this._vimage.style.left = "0px";
          this._container = this.createVMLNode("group");
          this._container.style.width = width;
          this._container.style.height = height;
          this._container.style.position = "absolute";
          this._container.setAttribute("coordsize", width - 1 + "," + (height - 1));
          this._container.appendChild(this._vimage);
          this._rootObj.appendChild(this._container);
          this._rootObj.style.position = "relative";
          this._rootObj.style.width = width + "px";
          this._rootObj.style.height = height + "px";
          this._rootObj.setAttribute("id", this._img.getAttribute("id"));
          this._rootObj.className = this._img.className;
          this._eventObj = this._rootObj;
          this._handleRotation(parameters);
        };
      } else {
        return function(parameters) {
          this._rootObj.setAttribute("id", this._img.getAttribute("id"));
          this._rootObj.className = this._img.className;
          this._width = this._img.width;
          this._height = this._img.height;
          this._widthHalf = this._width / 2;
          this._heightHalf = this._height / 2;
          var _widthMax = Math.sqrt(this._height * this._height + this._width * this._width);
          this._widthAdd = _widthMax - this._width;
          this._heightAdd = _widthMax - this._height;
          this._widthAddHalf = this._widthAdd / 2;
          this._heightAddHalf = this._heightAdd / 2;
          this._img.parentNode.removeChild(this._img);
          this._aspectW = (parseInt(this._img.style.width, 10) || this._width) / this._img.width;
          this._aspectH = (parseInt(this._img.style.height, 10) || this._height) / this._img.height;
          this._canvas = document.createElement("canvas");
          this._canvas.setAttribute("width", this._width);
          this._canvas.style.position = "relative";
          this._canvas.style.left = -this._widthAddHalf + "px";
          this._canvas.style.top = -this._heightAddHalf + "px";
          this._canvas.Wilq32 = this._rootObj.Wilq32;
          this._rootObj.appendChild(this._canvas);
          this._rootObj.style.width = this._width + "px";
          this._rootObj.style.height = this._height + "px";
          this._eventObj = this._canvas;
          this._cnv = this._canvas.getContext("2d");
          this._handleRotation(parameters);
        };
      }
    }(),
    _animateStart: function() {
      if (this._timer) {
        clearTimeout(this._timer);
      }
      this._animateStartTime = +new Date();
      this._animateStartAngle = this._angle;
      this._animate();
    },
    _animate: function() {
      var actualTime = +new Date();
      var checkEnd = actualTime - this._animateStartTime > this._parameters.duration;
      if (checkEnd && !this._parameters.animatedGif) {
        clearTimeout(this._timer);
      } else {
        if (this._canvas || this._vimage || this._img) {
          var angle = this._parameters.easing(
            0,
            actualTime - this._animateStartTime,
            this._animateStartAngle,
            this._parameters.animateTo - this._animateStartAngle,
            this._parameters.duration
          );
          this._rotate(~~(angle * 10) / 10);
        }
        if (this._parameters.step) {
          this._parameters.step(this._angle);
        }
        var self = this;
        this._timer = setTimeout(function() {
          self._animate.call(self);
        }, 10);
      }
      if (this._parameters.callback && checkEnd) {
        this._angle = this._parameters.animateTo;
        this._rotate(this._angle);
        this._parameters.callback.call(this._rootObj);
      }
    },
    _rotate: function() {
      var rad = Math.PI / 180;
      if (IE) {
        return function(angle) {
          this._angle = angle;
          this._container.style.rotation = angle % 360 + "deg";
        };
      } else if (supportedCSS) {
        return function(angle) {
          this._angle = angle;
          this._img.style[supportedCSS] = "rotate(" + angle % 360 + "deg)";
        };
      } else {
        return function(angle) {
          this._angle = angle;
          angle = angle % 360 * rad;
          this._canvas.width = this._width + this._widthAdd;
          this._canvas.height = this._height + this._heightAdd;
          this._cnv.translate(this._widthAddHalf, this._heightAddHalf);
          this._cnv.translate(this._widthHalf, this._heightHalf);
          this._cnv.rotate(angle);
          this._cnv.translate(-this._widthHalf, -this._heightHalf);
          this._cnv.scale(this._aspectW, this._aspectH);
          this._cnv.drawImage(this._img, 0, 0);
        };
      }
    }()
  };
  if (IE) {
    Wilq32.PhotoEffect.prototype.createVMLNode = function() {
      document.createStyleSheet().addRule(".rvml", "behavior:url(#default#VML)");
      try {
        !document.namespaces.rvml && document.namespaces.add("rvml", "urn:schemas-microsoft-com:vml");
        return function(tagName) {
          return document.createElement("<rvml:" + tagName + ' class="rvml">');
        };
      } catch (e) {
        return function(tagName) {
          return document.createElement("<" + tagName + ' xmlns="urn:schemas-microsoft.com:vml" class="rvml">');
        };
      }
    }();
  }
})($);
var clockFaceImg = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAOnAAADpwBB5RT3QAAABx0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzIENTNui8sowAACAASURBVHic7Z15nBxVufe/p6rXmZ59wkz2hUDYgoFggChIXFBAUIMCmsxkgih49VUvon4gJLclRF43rttVUSCzJICsIi8iXpGwRQhbICRkT8i+TGaf6bXqvH90CAlkqrp7qrp7Juf7Tz7pOnXO09PnV3WW5zyPkFKiUCiOjpZvAxSKQkYJRKGwQAlEobBACUShsEAJRKGwQAlEobBACUShsEAJRKGwQAlEobBACUShsEAJRKGwQAlEobBACUShsEAJRKGwQAlEobBACUShsEAJRKGwQAlEobDA42RlQggnqxtSfP2H95dFg5GxminGmshKIbVhIIdJSQUQABBID0JUI2WrRCQBNE30mVK2C8QBIeReiWjTNLFF9MW23/3Tr3bn9UsVME4dJRdOnklXAoHZN7UM1zzmFCHFZCk5TcCpCI4Hylxorh3BBky5Wgre0oS2SiQSKxffdvV+F9oaVCiBFAgN4cVTpKGfj2QagvOB0fm2CdiI5CUp5HJd15ctDs9ek2+Dco0SSJ6ov7GpCi+fxBSXCMGFQE2+bUqDnUj5D6nxpKHpTywNz+7Kt0FuowSSQ+pvbKoSXvF5IfmShE/g8Nwtx8SBJ6WQD5Hg/zXfNudAvg1yAyUQl7kg/LRnjLntEk2KuRIuYXCLoj/iwGNSyLu2aWP+d1l4RjLfBjmFEohLzJ1392ip6ddJxBxgZL7tySG7gT8ZhvjDkh/X7c63MQNFCcRh5oZbzjST8noEVzI03xbpkkTyZ80jbl8crnst38ZkixKIQ9TNb/6YBv8FzHC3JYmRiGImoql/k3GkkcA0Ekjz4MhGSkwjjqb74ODfUuheNN2LpnkQHh+6N4jmDaB7A+6am+JxgfhJ48K653LRmJMogQyQhnlLzpGa+WNcEIaRiJCMdJKM9pCM9ZCMdmMkIuDo31pD8wXx+EN4AiV4/CG8wTI0d4TztDC1mxoXzX7RjcrdQAkkSxpuXnqCFMZ/k5p4O4IR6yXW00qir51EXwdmMuZU1RmjeQP4isrxFlXgC1Wj+4qcrP4hpPnDplsbNjlZqRsogWTIrPCSUo9hzAfxXQY6x5CSWE8r8e59xHtaMRJRZ4x0Ad0XxFdcjb+0Bl9x5aGh2wBICsSvE7r4USHvpyiBZEDDguY6KbkdqM6+Fkm85wCxrr3EuvZiGgnH7MsVmu7FX1qDv2w4vuIKYEC/106E+E7TLXUPOWSeoyiBpMHceXePNjXvHSAvyrYOIxEl2rGTaPuOgn5TZIruCxIoH0mwfOQA5y3iCc1MXLt40dXbHTPOAZRAbGiY33ydhJ8Apdncn+jroO/AVmJd+4AhnGRICAKltQSrxuANlmdbS5cQfKvxlvoWJ00bCEog/dAQXlwuDc/dIL+Qzf2x7v30tW4m0dfhtGkFjzdYTvGwCfhKhmVZg3jEo8euuSt8TZujhmWBEshRqF/QNENIloAYkem98e799OzfSDJSsPPOnOEJlhI67gR8oaymbDs0U1y5eFHdcqftygQlkPcxZ37zD4DbyPCUZCLSSc+etcfkG8MOX6iKUM0kPIGSTG+NS+SNzQvn3O6GXemgBHKQr4fvKIong3fLlItI2pjJOD171xHt2E2u5xiTTjiestISVry68ojPNU1j8iknMXHCWAzTZN/+Vl5duYpYLJ5T+45EECgfTqh2UmqHPzMeELpR3xiem/PVDSUQYFZ4yShPUj6GkFPSv0sSadtOz971SNNwz7j3UVtzHGdPncKEcWM45aQTeG75Cprve2+F1O/38d1vXMOevftYvuJVNCGYedlF1NYM49d/WMymLe/kzNajIXQPoZpJBCtGktHysOAVoRmXNobn7nHNuKPgVL8etEEb5sxvPNVjmP/ORBxGrJf2LS/TvfvtnIoDIBKJsGHzFl5duQohBInkkfsoF31qBiccP46nnn2BDZu2sG7jZu5svpfioiLqrpyZU1uPhjSSdO9aTfuWFRjxSAY3cpY09Jcb5i+Z7J517jEoBdJwc8sFoC0HRqV7T+TAO7RtWk6ir909wyzo7OpmzdoN/b4JKstTS6zBgP/QZ/tbU4tBlZVZL786TqKvg7ZNLxBpz2jbY5TEXD53Xst0t+xyi0EnkDkLWi6RQj5JmvsbphGnY9trdO9Zi5Smy9Zlz70PPsqtP/s1GzZtPfTZiNrUad4dOwvreIY0Dbp3raHjnVcz8SgImZr83zkLWhzzgcsFg0ogDQuaL0XKh4G0ZouJvnbaNi4n3l34QT4i0Shbt+049P9gIMCcr3yRtvYO7n3w0Txa1j/xntbUWznSme4tRUj5cP2Cpqz2qPLBoBHInAUtl0vJg6QpjkjbNjq2vpJXz9psEEJw7rQzufH6b7J2wybCt/032wvsDXI4ZiJKx5YVRNrSHnL5hBT3NSxovtRNu5xiUAhkzoKWS5DyHtIQh5Qm3btWpybiBTykOhqjRg7nu//xVSrLy1n0i9/wyGN/py+SwYQ4T0hp0r17Dd2715DmkrlPSh4cDMOtgj9aOndey3RTyvtJRxymQef2lcR7WnNgWXZ4vak/eTAYPOLzc846g1lXfoHnlq8gaRhc8NFzj7i+dv1G3tm+M2d2ZkOkbTtGvI+y0WcgNN2uuA8pH264ueXTjbfWLcuBeVlR0PsgDfOXTJaYz5PGhNw04nS882rBuoqMHF7L+R+ZxsmTTmBEbQ2mafLK62/y6spVvLpyFT+66XpGDq/t9/57H/wrTz3zfA4tzh5PsJTysVPT3VjsAnN608KG1U7aMOQ3ChvCi2ulob9MGku5RiJKx9aXMeJ9luVGjqjlO9+4hp6eXn7x2zvo7bUu7yRer4dg4INu5YlkkkgkSqi4CE3rf8QbjcWIx909gyKE4D++NodJJ0yk+d4HeOW1N7Kuy+MvpmzsWemend+R1LVzl4Zn77Avmh5DWiAN4cUBaXieBznVrqyRiNKx5aW0zmr857e+zqdmnA/Ab/+4mL89+dTAjR1CnHTiRG6/LQzAlne28c3rbxpQfbo3QPn4s9MVyet+PfLRP4avdeSpNbR30pN6o9PiAHh73YbUfYbB5jy7bhQiu/bspasrFTB+/cbNA64vw9/njFgycOeAG3WYgnuDzJnfcgPIn9mVM414yu0h1ptR/RMnjKOvL8KuPXuztnEoU1pawpiRI1i9dr1jT2HdG6RiwjlonnTmJOL7TQvrfj7QNofkEKt+ftO5ArEMmxUraRq0b11RsBNyxQfxBEupGDctndUtE9Oc0bSo4dmBtDfkhlhfDd9ZKUhnI1DSue11JY5BRjLSRef2lensTWlo4t6G8OKCcEArGIEkDf+d6ZwE7N79NvHeIRmQfMgT72mlZ/fbaZQUIzD0RrftSYeCEEjDgua6dM6QR9q2Z+LSoChAIu07iLRtsy0n4XMNC5q/lgOTLMn7HGRWeMkoj2GuxmYzMBHppGPLikHnPqL4IEJolI87C29RhV3RrqSunZrN/siQmYPohnkHNuIwjUS641fFIEBKk87tb2AatkeJSw/2j7yRV4HU39z0RQEX25Xr2vEm5hAK2qYAMxmja8cq23ICLk4NwfND3gQyK7ykVAh+ZVcu0r6joJ0PFdkT72ml74D9hq2U/HxWeElWAQAHSt4E4jHNsN2qlRGP0LNnbY4sUuSD3r3rMeK2m73HpQKP5568TNKvDi+dYBjGOizd7SXtW1aoeFXHAN6icirGT8MmWkrS0MXJS8J1G9Opc1BP0pOG8TNszqJE2ncqcRwjJPo60lm+9+iG/GUu7DmcnAukfl7TNAGWcWzeDeqmOHbo2bseM2m7qnVJw7wl5+TCnnfJuUCELn5hV6Zn7zqkMWQyEivSQJpGWg9FqZu2jqxOklOBzJ3XMh3JR63KJKPdB8OBKo41oh277X3sJB+tn9ds2YecJKcCMTVutiuTWrUawvk4FBZIuvfY+2oJXSzKgTFADgXSEF48xS7TU7ynlXhv3lNLKPJIoq/DPo6ZlOen+pP75EwgpqF/365Mz74NuTBFUeD07LdfyZWG/sMcmJIbgTSEF9cKuMKqTLynVZ3xUACpsyMx+2iYX5wVXpJ2bOZsyYlApKF/A5t9j959R0+9/aUvXMpj9zcRvumGvGewUmRG3Ze/yGP3N3HDt6/L+N6+/bZn4j1ew/hGVoZlgOsCuSD8tAf4ulWZRKSDROTom4KXXXwhuq4zbeoUxo0Z7YaJCpe4/HOXoOs6H//YRykvy8yVyqpPvIuEhoP9yzVcF8i45I5PAv1HRANLh7Wnn0ulutuwaQvbd+5y1DaFuzzz3L8BeHP123QejJaSCX2tW21KiBFjkts+k7ll6eO6L9ac+c0PApf3d4+ZjNG6/hmwsKO0JERvXwTDyG3SG8XAKSstpbMr27mloPrE8y3zuEv4W/PC+g/E+B0UvlhfDd9ZCVhG8Y6077AUB0BXd48SxyAle3EASCId1vGIBVx4sJ+5gqsCMUzfJVhGKZFE2ws7ILMiv0Tad2CzcewxDO/n3WrfVYGYkqusrif6OjAShR/eX5E/zETUdvNYIr7sVvuuCWRWeEmpgE9albF7fSoUANFOW9+8C9waZrkmEK9hXozV8EpK4l373GpeMYSId+2zm6d6DMN3oRttuyYQU1oHY4j3tWWSAFJxDGMaCeK91nEJTJvFoGxxTSBCyE9YXY915jSvvGKQE7MZbdgN57PFFYHMDS85xS4gQ7xHhQ9VpE/MPrLNcfXhptOdbtcVgUjT/IjVdSMeUatXiowwE1HbVBfCEBc43a4rAjElF1hdV3GuFNlg9xaRcLbTbboiEAGWB+vjfepQlCJzEjb7IQLOd7pNxwXy5fA91cAEqzKJ3nanm1UcAyQinXZFRjWEF1s6xmaK4wLxJhOWRyHNZAwzGXO6WcUxgJmM2eY7lEnh6ETdcYFoQpxmdT2Np4BC0S9Jm/4jEB9ysj3HBSLhDKvryWjm5wIUindJRq29g6XQCvsNguAUq8vq3LliINg+YKW07H+Z4rxAJBOtLiczTNusUBxOMtZjXUBYLxBliqMC+VL4/hBgmZ3UVBuEigGQmqRbOi6WO5lLxFGBFNNrGYbFSERVGjXFwJASI2G9CqphjnGqOWeHWEnd8vWm0qgpnMBuFKInKVCBCJvhldr/UDiAafMGMYV07PCU05P046wuppH/QaGwxS47roaodqotR4NumVBjFfswjbS/imOEU08+kTMmn0pxcRE9Pb28unIVazccPbrm+7F70JrC+qhFJjgqEIGstsozZzfEGj92NNOnTaW0tIS29g5eeOkVduxUuUKGGlfPvpKSkmLue/Cv9EUiXHzhx7nh29ey9P5HePpgsDkrbB+0UlY5ZKqzQyyJKLK8bvYf2+riC2dww/+5ljfXrOWulvvYsWs3C37wHc6ddqaTJiryzIkTJzD97Kls3LSVvftb6e7p5YG/PE48nmDmZRelFX85jexj/UeayxBHBSLs6uvn4P3x48cy89KL+PtTy1i1ei3xeIIXXnyFF156hfqrvkhlheXcXzEIOVwIpmnSF4kQDATw+bwDr9vBfu3wJF1YDtlkPxs8Hz9/OgBvrTkyR91rb7yF1+vh3A+rt8hQYf3GzXx//iIe/8e/Dn1WXFREWWkJGzZtJRazn6f214/ew7ofZoLTkbEtdzBlP1FMKisqAIhEj5yj7NufOrd+/PixTtimKBDaO1IeuSWhYkpLSrj8cxexees2/ufOprTu768fHYZjO+lOC8TSE1HoR3999vb1AVBdVcGeve9Fr+iLpDaEnHjtKgqP73/7Oiory+no7OKpZc8Ti6W3T9ZfPzoMxzxiHRaItJw9iX5WuP694lWmTD6FC2ecz+q31x+KzD129EgA+iJqB34osuDHqYzg48eO5ltfb2DGedNZ9Ivf2A6z+utH72HdDzPBUYFIMLPJAfXqylW88OIrfOScs7jx+m+yZu16jhtWTWlJCEDlBRnibHlnO0898zwzL72IGedN5+//XDag+iQ45vDn9E665aNe6P3rcfHS+/nFb//ImnUbiMbiPPHPZWx5ZzsAr7+52lkrFXlj1MjhTD7lpA983nogFaegqrLCtg6rfgQgkH3ZWfdBnN0oFLRbLTBoNmPHt9dt5O11qQynfr+Pcz58Jms3bFKbhUOI+qsuZ8K4MXz3xh/R0/Pe2aBhVSn3qV179trWoekWGTUAiXAsrpSz+yCSHZaNefzp1SMEV828DK/Hw13N9zlim6Iw2L1nH4lEkt7e9x7yZaUlfGrGeezavZcXXnzZtg67fqSBvcrSxGFfLNlqNYGyUz5AdVUlV828lFEjh/PTX//h0JKgYmjQct9DmNLkpu99i7XrNxIIBDjj9FN5c/Va/vzwY8Tj9gHNNY9tP3IsbYCjAtGkaJMWs3TN27/yqysr+MoVn2dEbQ3PLV/BHY1LSSQcW4xQFAhJw6Dpngfx+bwMq6pCaIL7H3kso9/adiQisU6PmwHOzkE82lZp9L+AoHmD/V7r7u3lngcepfWAirp4LBCPJ9i5O7sI/1ZJPQHwGLZJ1tPFUYHEYYdVhbrXD0Ic1ScrFosTiylxKKwRQkO3EUgvxZZz4UxwdJK+NDy7C6xeb8L2yykUVliNQg7S8UD4CpvQJxm051RFh5BYvt48/pDjTSqOHTz+YusCgo1OtudC4DixxuqyJ1DieJOKYwdP0MYPUWLZ/zLFcYEIab5pdd0TcMzRUnEMYveAFfC6k+25EJtXvmF13RMsc7pJxTGE16b/mFK+5WR7zr9BPNLyDaJ7A2nvqCsUh6N5/LZ9R3qEZf/LuE0nKwNoDM/dA9YuJ3ZPAYXiaHiLbR0ZN7eE6x3bRQe3knjCs1bXvcWOxfVSHEP4iqz7jYQXnW7TrRyFL1ld94cci+ulOIbw2fQbTbDM6TbdeYPocpnVdd1fbO8uoFAchu4NovusNwmFpr3gdLuuCKQ5POdNbDwq1VtEkQm+kF0sOLlrcXi2o3sg4JJAACT80+q6v7TGraYVQxB/mXXyWinFU26065pANHjM6rqvuMr2hKFCAamTqHYTdE3wN1fadqNSAF2P/wPo38lfCHyllsHgFQqAVD+xDkkaT+ja4BLIXeFr2sB6VSFQNtyt5hVDiGD5SMvrEv550JPccVwTCIBA3mt13VdcqVazFJbo3iDeIpvYzELe71b7rgpE1xN/wWqYhSBYYZnWUHGME6gYiVVKDSDu1RKW892B4KpA7gpf0ybhH1ZlUq/PbMLNKYY8Iq0H6GMHh/Ou4KpAAJDy95YGeAP4M5isBwMBhlU7lh9FkUOCgUBGqSz8pTW2zolCijsHapcVrgtkm2fM30Faxg4tqh6XVl0V5WXc9bvbabrjV1x60aecME+RI0bU1tBy529o+dNvmHH+R9K6p6jKNqr/nq2eUZb7bQPFdYEsC89ICmi0KuMNluMN2j9ZTjpxIuVlqQNX50yb6oh9itww+bSTKQoGEUJwbhq/XZp94o/LwjNcjQ3l/hALSOj677GcrEPRMMsU6wCsfHM1b61Zy4G2dh557AmnzFPkgJdefo216zeyv/UAjz7+pG354uOOtyuSFLphOXx3AiH7SYuWVWUWmzlz5jffC1xldX/b5n+TjLiynK0YRHiCpVROONeyjIR7mhfWz+r3ukP9OidvEAChGz+xKxMaNjEXpigKnNBxJ9iW0XXxixyYkjuBNIbnrkQIy4NUvpJh9ptCiiGNr7jS9twHiCcWh+tey4U9ORMIgDTkPLsyJbUnM5T2RXRv8Khr+bo3SKBsOJrHR1H1uA9E69D01Of6u4HShCBQNpxQzSSKh01At4sPNSgRhGo/mDvk/UhT/jgHxgA5FkjzovrnETxvVcYTLCVQPnR8tEwjTqh20gdcaoqqx6H7gmge/8FOf+Sk1F9WS6hmEro/lXq+dOTp+MuGY8R7AUHFuGlD7mx/oHy4fdw0wfPNi+ot+5CT5FQgAMLQvm9XJlQzCaHpuTDHdaRpEOvce6RjphD4S2uItO8EIBnrwVtUfsR3DpQNJxntPlQ+UFZL5/bXibTvoHf/Jnr2rsdXMiyXX8VVhO4hVDPJtpw05PdyYM4hci6QxkWzXwT5V6symsdHqObEXJnkOn3t2wiUjzj0f19xFcloN2byYFZXKYn3tB4ae+veANI0MN9NdywliUgnZaNOx1cyDKHpRDt20rvP0SibeSVUM8k274eEh5sXzVmRI5OAPAgEwNC172GzLxKsHD1kJuzJSBcCcSgucbByNJG2bUeUiXbsPvSW8ZfWEu3YecT1jq2vkIx2UzzseKpP+jhlY84cMoHAvUXlBCusXdqBpEfXbUcfTpMXgSwJ120E+UvrUoLSkachRF5MdJxI+3YC5SPQdC+eQCmxniPT6MX72vAGyxCajr+0hlj3/kPXhNAQmk7v/s20b36R1nXLMOK9lIycnOuv4ThC0ykdeTq2CzOC39wdnuVY3o90yVvvS+r6QmwCO+i+YoqHyFAr2rkbf2kN/rLhRDt2fTBHipTEeloJVo7BTMaQ5nsvWE+wjPJxZ/FuJ5JGgmjHrvdWuAYxodqTbKOVgNyV1LRwLux5P3kTyNLw7C4huMGuXFHVWHyhwT8ZNZPx1BCpejzR9qMHnox17qb4uIlEO4/M6pvo68BMxigfdxbBilEUVY2jdORk+treyYXpruELVad1HkhKvuPWiUE7cuZq0h/185sfF3CxVRnTiNO2cfl7k9pBiscfwltUTuQwgWgeH75QdeqtIgRFlWOJtG9Hmgb+slqSfZ0YiUhq5auk5uDSriTWvZ9EX3v+vswA0bwBKo+fbhu4Q8LfmhfWX5Jp/U71a0dTsGWDoWvXegxzNdBvXgRN91E2+kN0bH0FKfvPgVjoJGM9JGNHJj8yk/GUOACkpO/A1kPXYp2H5fCTkljXHmJd2eX1KySE0CgbPSWdqDZdhq5dmwub+iPvM+Cl4dk70hlqeYsqCNXar5MrCp9Q7UlpbXIKwbeWhmc7lm8wG/IuEIDGW+r/JOBRu3LByjHqDPsgJ1g5mmDl6DRKikcab6lvcd0gGwpCIADoRoPdyUOA0PCT03BmUxQivuIqSoafnEZJucujx65x3aA0KBiBNIbndmDKLwOWk4x3x6+2ueoUBYUnWErZmDNIwxE1biJmuhmIIRMKRiAATYsangXxQ7tyQtMpHzN1SOwDHAvo/mLKx05N079OzGtZWG+ZPiOXFJRAAJoW1v0caR1wDlLLo+Xjpw3I3aK4uIizzzqTYGBouGy4wemnncKYUbZuIP2iewOUjz0LTbf2swIQkj83Laz7edaNuUDel3mPht8TvSZmBE8CzrAqp3sDlI8/m44tL2Ekohm1oes6v/rpQkbU1rB5yzt86wbboyrHHFfMvIyGWVdgGAY3zLuFdRs2ZXT/u79Peg8x8SqeZENWhrpIwb1BAP4YvrYvqWuXYZPrEN77EWwTzL8Pn9fL8JpUPK5Ro0bYlD42OX58KuyOruuMHG6dfuD96N5gBuJgh9CTn20Mz83sKZcDClIgkNofAfMzgK2LQUok0zKauEeiUf7nT428vW4Dv/79XQMx1TW8Xg9+v/3QxC2alt7P62+8xb+eeZ7n/52+l7knWErF8eekK44ugXbxweSvBUfeXU3saLi55QIp5JOAbU+RpkHn9teJ9xxw3I5cMnXKZGacP51gIMDS+x9h89Zt9jcVCL5QNWWjp6R74K1PM8WnFi+qW+60HU7164IXCMCcBS2XIOXDpCESkHTvfptI23ZXbHETv9/HtXNnMayqiub7HmLDpi35NikjghWjCA0/Od0jCnGEmNl0S93jbthyTAkEoGFB86VS8iBpiQQibdvp2bN20PhuaZrG9799HQG/j//7y98Ri8XzbVLaCKERqp1EsHJMurfEEeIrTbfUPeSWTYMuLtZAabyl/jEp5FVAWj0nWDma8vHTBk3+kc9++hNMnDCWu5feP6jEoXn8KTf8DMQhBF90UxxOMmgEAtB8y5xHEGIm0JdOeW+wjMrjpxe8a4rf7+PTn/gYa9ZtYM/efUw+5STOnXZmxitHucZXMozKidPxFlWke0scIWY23lLvWj4Ppxk0Q6zDmTuvZbqpySeBULr3RNq307NnHdI0XLQsOyafehLfue5q1qzdgNfroaOzizGjRlBz3DCeeeFFlvz5EceGDE4ghEao5kSC9tHXD6dLSPG5xlvrlrlk1hEMmfMg2bB4Ud3yOfMbzwHt70Ba7r3BitH4iqvp2vkmib4Oly3MjIkH9xv27NvPvQ8+ipQSj67ztYav8LGPnMO27bt45oUX82xlCm9RBaUjTs00cN0OMD/TeGvDarfscotBNcQ6nKaFDauFbnwYwSvp3qP7glSMn0bJiFMReuE8G4qLU53ttTfeOvTkSxoGjz6eSs414zzrQM65QGg6JcNPpmL8hzMThxQrk7p2btPCwScOGMQCAWgMz90jNOM84IH070ql9ao64byDsaryH+Y0kUjFv9K1I3+OPftSkU3KSm2iDbqKIFA+gqoTzj84EU//7yUkf/Z7+j6S70NPA6FwHqNZctA94Yr6+U3XC8RtpLkMrOk+SkdOpqhqHD171+V1c3HrtlT/qa6qPOJzrzf183R2defcJkjFq0r39N/7MIEbG2+t/6kLZuWUQf0GOZzmhXNuF6b2MdLw3zocT6CE8rFnUT52at7OmKxavZZYLM6Uyacc8fm4MamTdy+/9kZO7fEESykfcyYV48/OQhxylxTyk00LB784YAgJBFJhTT16/EMgHsn0Xl+omsoJ51I+5sy00sE5SV8kwj0P/oVTTz6RqVNSweBCoWKumnkpGzZt5cmnnsmJHd6icsrGnEnlhHOzjPsrHhG6eWrzLXOedty4PDEol3nToWFBc52U/BaLaClWJCIdRA5sI9q154NB3lzi5EkT+eQFH0UgCAT8rFy1hn898wJJw82lNu4FFwAAA0dJREFUaYG/9DiKqsYNJNRrl4AfNi6s/4OTlg2EY87VJBvmzrt7tKl57wB5UbZ1mIkokY6dRDt2YsQjTpqXV3RvgEDFKALlIwcY41c8oZmJaxcvurqgnN+UQDJgzoKWy5HyV0D2R+OQxHvbiXXuJta1973I64MITfemwp+W1uALVTHAFbxWIbi+ECKPHA0lkAyZFV5S6jXkf0nktxno6p2UxHvbiHXtJd7bWtBvFt0bwBeqxldyHP5QNQz8N0qC/GVS1xfmKxxoOiiBZMmcmxuPR2g/AS53qk4j3ke8p5VEXzvxvg7MDI//Oonm8eMtKsdbVIE/VO10qrbHhdT/s/HWWRucrNQNlEAGSMO8JedIzfwxMMPpus1ElESkMxVqNNpNMtaDGY8463ovBLo3iCdQgscfwhMI4QmWuRXp5Wlhajelkh8NDpRAHKJhfst5EvlDIOMAyZliJKKYiShGIoJMxjHNJKaRQB6WSco04qkIIAf/lkLzoOlehO5F8/jQvQE0b+DgxNr1v/fTJvyoZWF9btaZHUQJxGHmhlvONJPyegRXMgQ8DAZAEsmfNY+4PVeplt1ACcQlZt/UMlzX5XXA14Chk27Xnp0SWnQz+btCW7LNBiUQl7kg/LRnjLntU0KKrwKXkqaP1yAjKeBxU8jF27Qxjy8Lz7DMGzmYUALJIfU3NlXh5bNCisuBTzO4xZIU8JQUPCAT8i/Nt80Z3CFg+kEJJE/MCi8p1U3jImHyaYS4kAFtPuaMvVLyDzT5OAn+OVRFcThKIAXC3PCSUwzDuEBIMR3B2cDEfNsEbEfyLIIVQjeebQzPXZlvg3KNEkiBMvfGu4dJr3eKKc3JQnIamjgVyQlA2pENMqATySYJq4XgLSnkKjOprVzy47rd9rcObZRABhlX/+CuElnkH22acrxAVkopaiSyShOiwjRlEYBAehCiGilbJeLdCXNUCNpB7JfC3A90oLElEAm+88efXNGZv29U2BSkQBSKocaQOjClUDiNEohCYYESiEJhgRKIQmGBEohCYYESiEJhgRKIQmGBEohCYYESiEJhgRKIQmGBEohCYYESiEJhgRKIQmGBEohCYYESiEJhgRKIQmGBEohCYcH/B4q+AQTPY1qyAAAAAElFTkSuQmCC";
var clockFaceHighResImg = "2d06fa3c2b1d84b6.png";
var hourHandImg = "b8d406408eeeb947.png";
var hourHandHighResImg = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAADICAYAAADhnmEjAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyJpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBNYWNpbnRvc2giIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NDdDODZCRUUzRjY4MTFFMjgxNzA5MzVFNjZGQUI3NjUiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NDdDODZCRUYzRjY4MTFFMjgxNzA5MzVFNjZGQUI3NjUiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDpBQ0VDMEY0RDNGNjMxMUUyODE3MDkzNUU2NkZBQjc2NSIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDpBQ0VDMEY0RTNGNjMxMUUyODE3MDkzNUU2NkZBQjc2NSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PgjjFnMAAAD0SURBVHja7JdRDsIgEAWL8V6LJ/do2JpqDFnaJfZhY4afkgLzMU06IZVSpmWklKZ6zGv3de3mrD2fl+nL8XtA2nFQ1rX0xw5ODJgtZ2+OxMGA3JgjcSTAGnMkDuvCqwnvjdUGuqAGeB1otQGJQkAOvkOiEmDBd0iUdaFugtcGuqAEbN0NvDUkigA5eIdAohJgwTsEEmVdaDWhbgNdUAG2mtDag0QBIAfO8BXUAAucMSQqu7DXhM820AUFINIEby8SDwbkjnN8BRXAOs4ZEhVdWH40vWeReBDgWltFIgAAAAAAAAAAAAAAAAAAAAAAwAkBDwEGAOL8ZtAVWs1HAAAAAElFTkSuQmCC";
var minuteHandImg = "4c78b2c2b706ca18.png";
var minuteHandHighResImg = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAEQCAYAAAC5hPTVAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyJpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBNYWNpbnRvc2giIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NDdDODZCRjIzRjY4MTFFMjgxNzA5MzVFNjZGQUI3NjUiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NDdDODZCRjMzRjY4MTFFMjgxNzA5MzVFNjZGQUI3NjUiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo0N0M4NkJGMDNGNjgxMUUyODE3MDkzNUU2NkZBQjc2NSIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo0N0M4NkJGMTNGNjgxMUUyODE3MDkzNUU2NkZBQjc2NSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PsZ7ke8AAAFESURBVHja7NntDcIgFIXh0jgATgAjMIJO7kh1A+wPPypyb081/tGXpAmB9jHhKp62odY63FoIYVi2ee50HT824/f+OHzYfgDYrcyXT4H4B4sI8E1g/skeen0WEWArEJWdaRT3w0IVAN4FktGXgWz0qQJA90/0fjTjU320ybomWGG7NmJYTBK2ASSgF+usqMciAnhAVG9Cxw23vIUqAGwFkjhmAlkcowoAdsxrIt5L1FuNeW3Ea6MeMQ9gFfCe3PXmWEQAC/DeKUQF8N5qFKoAoALJOT8pQHaATBUApJhnRLynqOfGPCviLaMeMQ/ABbyIZ53DIgL0gChcEz2gCEChCgBrQBKuSR6QBSBTBYCX0NWEsknYF8/zsbeAqn4wVQBYtp31BWERAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAvgdcBBgAY8/OTGuji98AAAAASUVORK5CYII=";
var secondHandImg = "148d4aecbf4cc4cc.png";
var secondHandHighResImg = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAEoCAYAAABRrXEVAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyJpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBNYWNpbnRvc2giIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6QUNFQzBGNEIzRjYzMTFFMjgxNzA5MzVFNjZGQUI3NjUiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6QUNFQzBGNEMzRjYzMTFFMjgxNzA5MzVFNjZGQUI3NjUiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDpBQ0VDMEY0OTNGNjMxMUUyODE3MDkzNUU2NkZBQjc2NSIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDpBQ0VDMEY0QTNGNjMxMUUyODE3MDkzNUU2NkZBQjc2NSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Pu45uv8AAAKTSURBVHja7NvdbtJgGAfwtwXG50GTTROSxdVkZ3oAXgG7AjlxUYmKMR6rVwDcgcTPxJgRDWrwhDuAo2mWuHABS9YEE4ZjsXFYSIHi82BjHKNYnFGn/yYvUPr8f337vi0pJEjCYdlbXE7QU8VeXZl/v1WdVCeLIy4A/nkggTH4tYD6xwHMAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAI4XsHRUQMUg/jeA12nD7tkzirfbHb02Tp5YEqWtiXXS9yvFlyVVkqQMtfSk4uFwWKCWS11a1Q4BhWfFJAXXZFlWvF6v8Hg8B8KDwUD0+31hWZZOyPX01VT5G/DkaSFB4YrP5xPBYHDqMXc6HdHr9bg3KzdvpKvSvQePFdrbdiAQUCKRiKuBa7fbotvt6tSr0zI93KZuKeFw2PXIcy1nOCtTd65x1+kQXANcyxnKnmdApe7PPP+coWxM7pkmD8jMAGc4K49G1LJmByjDWdk0Tb1jn3GzLJzhLPXArDZ3dmYGOMNZAvr5VqsldF13HeZaznDWs7HxVovHz6nND83YwsK88Pv9U8P7+5/E5uY7Oq17hUcP7+dHlzMNxp2OYdTerK+Ler3uGOZtXMO1nDl0NV5OXcnS9GRCoZCIRqN0ssyJrzswRaPREIZh8EmUe1F8np14OfNyYfWiSkjyVPtzJjCwFH7v45xP2w0G8hQuvy690lwN1N7icoXa0G5ZfCoDAAAAAAAAAAAAOF6ANOEWN0lPt6jFqCn223x/XKOWH/87ijQW5h9etqd916AWJ0RzOoT0D3qsjNdgGgEAAAAAAAAAfz9QdZEpOwL2HdjdKeEc1dQO3KX9zM/imEYAAAAAAAAAAAAAAAAAAPDbgC8CDACr6BFPCZ/HfAAAAABJRU5ErkJggg==";
let clockWidthHeight;
let clockDiv;
let secondHand;
let minuteHand;
let hourHand;
let imgsLoaded;
let secondHandSpeed;
let smoothRotation = false;
let useSecondHand = true;
let imagesToLoad;
let retina = false;
const defaultImgsConfig = {
  clockFaceImg,
  hourHandImg,
  minuteHandImg,
  secondHandImg,
  clockFaceHighResImg,
  hourHandHighResImg,
  minuteHandHighResImg,
  secondHandHighResImg
};
const html5Clock = function(config) {
  config = $.extend(true, defaultImgsConfig, config);
  imgsLoaded = 0;
  imagesToLoad = 4;
  clockDiv = $("#" + config.divId);
  clockWidthHeight = config.clockWidthAndHeight;
  secondHandSpeed = config.secondHandSpeed;
  if (config.useSecondHand == "false") {
    useSecondHand = false;
    imagesToLoad = 3;
  }
  if (config.smoothRotation == "true" && useSecondHand) {
    smoothRotation = true;
  }
  clockDiv.css({ height: clockWidthHeight + "px", width: clockWidthHeight + "px" });
  retina = config.retina === true || window.devicePixelRatio > 1;
  if (retina) {
    clockDiv.append(
      "<img id='bg' src=" + config.clockFaceHighResImg + " height=" + clockWidthHeight + " width=" + clockWidthHeight + " />"
    );
    clockDiv.append("<img id='hourHand' src=" + config.hourHandHighResImg + " />");
    clockDiv.append("<img id='minuteHand' src=" + config.minuteHandHighResImg + " />");
    if (useSecondHand) {
      clockDiv.append("<img id='secondHand' src=" + config.secondHandHighResImg + " />");
    }
  } else {
    clockDiv.append(
      "<img id='bg' src=" + config.clockFaceImg + " /><img id='hourHand' src=" + config.hourHandImg + " /><img id='minuteHand' src=" + config.minuteHandImg + " />"
    );
    if (useSecondHand) {
      clockDiv.append("<img id='secondHand' src=" + config.secondHandImg + " />");
    }
  }
  if (useSecondHand) {
    secondHand = $("#secondHand");
  }
  minuteHand = $("#minuteHand");
  hourHand = $("#hourHand");
  $("#bg").load(function() {
    checkIfImagesLoaded();
  });
  if (useSecondHand) {
    secondHand.load(function() {
      checkIfImagesLoaded();
    });
  }
  minuteHand.load(function() {
    checkIfImagesLoaded();
  });
  hourHand.load(function() {
    checkIfImagesLoaded();
  });
  const handIds = $("#" + config.divId + " #bg, #hourHand, #minuteHand, #secondHand");
  handIds.css({ position: "absolute", display: "none" });
};
function destroy() {
  clockWidthHeight = null;
  clockDiv = null;
  secondHand = null;
  minuteHand = null;
  hourHand = null;
  imgsLoaded = null;
  secondHandSpeed = null;
  imagesToLoad = null;
}
function checkIfImagesLoaded() {
  imgsLoaded++;
  if (imgsLoaded == imagesToLoad) {
    if (retina) {
      if (useSecondHand) {
        secondHand.css({ height: secondHand.height() / 2, width: secondHand.width() / 2 });
      }
      minuteHand.css({ height: minuteHand.height() / 2, width: minuteHand.width() / 2 });
      hourHand.css({ height: hourHand.height() / 2, width: hourHand.width() / 2 });
    }
    if (useSecondHand) {
      secondHand.css({
        left: (clockWidthHeight - secondHand.width()) / 2 + "px",
        top: (clockWidthHeight - secondHand.height()) / 2 + "px"
      });
    }
    minuteHand.css({
      left: (clockWidthHeight - minuteHand.width()) / 2 + "px",
      top: (clockWidthHeight - minuteHand.height()) / 2 + "px"
    });
    hourHand.css({
      left: (clockWidthHeight - hourHand.width()) / 2 + "px",
      top: (clockWidthHeight - hourHand.height()) / 2 + "px"
    });
    if (useSecondHand) {
      setSecondStart();
    }
    clockDiv.find("img").fadeIn();
  }
}
function setSecondStart() {
  const now = new Date();
  const secondAngle = 6 * now.getSeconds();
  secondHand.rotate(secondAngle, "abs");
}
function rotateHands(date) {
  const now = date || new Date();
  const secondAngle = 6 * now.getSeconds();
  if (useSecondHand) {
    if (smoothRotation) {
      const smoothSecondAngle = now.getMilliseconds() / 1e3 * 6 + secondAngle;
      secondHand.rotate(smoothSecondAngle, "abs");
    } else {
      if (secondAngle == 0) {
        secondHand.rotate(-6, "abs");
      }
      secondHand.rotate({ animateTo: secondAngle, duration: secondHandSpeed }, "abs");
    }
  }
  const minuteAngle = 6 * now.getMinutes() + secondAngle / 60;
  minuteHand.rotate(minuteAngle, "abs");
  const hourAngle = 360 / 12 * now.getHours();
  hourHand.rotate((hourAngle + minuteAngle / 12) % 360, "abs");
}
var clock = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  destroy,
  html5Clock,
  rotateHands
});
export { clock as default };
