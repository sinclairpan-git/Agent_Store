import $ from 'jquery';
import XTpl from '@sxf/er-lib/xtpl';
var progressTpl = `<div class="sfis-progress {cls}" style="height:{height};line-height:{height}">
    <div class="sfis-progress-bg" style="background-color:{bgColor};width:{bgWidth};height:{bgHeight};margin-top:{bgMarginTop}">
        <div class="sfis-progress-bar" style="background-color:{barColor};width:{ratio}%"></div>
    </div>
    <tpl if="tip">
        <div class="sfis-progress-text ellipsis" style="left:{bgWidth}" data-hint="{tip}">{text}</div>
    <tpl else>
        <div class="sfis-progress-text ellipsis" style="left:{bgWidth}">{text}</div>
    </tpl>
</div>`;
function styleInject(css, ref) {
  if (ref === void 0)
    ref = {};
  var insertAt = ref.insertAt;
  if (!css || typeof document === "undefined") {
    return;
  }
  var head = document.head || document.getElementsByTagName("head")[0];
  var style = document.createElement("style");
  style.type = "text/css";
  if (insertAt === "top") {
    if (head.firstChild) {
      head.insertBefore(style, head.firstChild);
    } else {
      head.appendChild(style);
    }
  } else {
    head.appendChild(style);
  }
  if (style.styleSheet) {
    style.styleSheet.cssText = css;
  } else {
    style.appendChild(document.createTextNode(css));
  }
}
var css_248z = ".sfis-progress {\n  position: relative;\n}\n\n.sfis-progress-bg {\n  position: absolute;\n  left: 0;\n  top: 50%;\n}\n\n.sfis-progress-bar {\n  position: absolute;\n  left: 0;\n  top: 0;\n  height: 100%;\n}\n\n.sfis-progress-text {\n  position: absolute;\n  top: 0;\n  padding-left: 5px;\n  white-space: nowrap;\n}\n";
styleInject(css_248z);
const progressXtpl = new XTpl(progressTpl);
const defaults = {
  cls: "",
  height: "20px",
  bgColor: "#ccc",
  bgWidth: "80px",
  bgHeight: "14px",
  barColor: "#0c6",
  ratio: "0",
  text: "",
  tip: ""
};
function getBar(options) {
  const opt = $.extend(true, {}, defaults, options);
  opt.bgMarginTop = -parseInt(opt.bgHeight, 10) / 2 + "px";
  opt.text = opt.text || opt.ratio + " %";
  return progressXtpl.apply(opt);
}
export { getBar };
