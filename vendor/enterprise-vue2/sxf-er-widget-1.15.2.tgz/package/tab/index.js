import $ from 'jquery';
import { getPrefixedClassName } from '@sxf/er-feature';
import Xtpl from '@sxf/er-lib/xtpl';
import Tip from '@sxf/er-widget/tip';
var indexTpl = `<ul class="{[values.getPrefixedClassName('list-unstyled')]} {[values.getPrefixedClassName('vmp-tabs')]}">
<tpl for="data">
    <li data-href="{href}" data-tip="{[values.contentElem ? undefined : values.content]}" class="{[parent.getPrefixedClassName('vmp-tab')]}" {[values.disabled ? 'disabled' : '']} data-parent="{parentKey}" utid="{parent.utidPrefix}tab-{href}" {[values.parentKey ? 'hidden is-child' : '']} {[values.childrenKeys && values.childrenKeys.length ? 'has-children' : '']}>
        <tpl if="!parent.noIcon && (icon || parent.defaultIcon)">
            <em class="{[parent.getPrefixedClassName('vmp-tab-icon')]} iconfont {[values.icon || parent.defaultIcon]}"></em>
        </tpl>
        <span class="{[parent.getPrefixedClassName('vmp-tab-text')]}">{content}</span>
        <tpl if="childrenKeys && childrenKeys.length">
            <i class="{[parent.getPrefixedClassName('vmp-tab-collapse-icon')]} iconfont {[parent.collapseIcon]}"/>
        </tpl>
    </li>
</tpl>
<div class="{[values.getPrefixedClassName('vmp-tabs__active-bar')]} {[values.animation ? values.getPrefixedClassName('vmp-tabs__active-bar_animation') : '']}"></div>
</ul>`;
const TAB_EXPAND_ATTR = "is-active";
const TABS_COLLAPSED_CLS = "vmp-tabs-collapsed";
function Tabs(target, opt) {
  const $target = $(target);
  this.opt = Object.assign(
    {
      pages: ".tab-page",
      parent: $target.parent(),
      autoActivatePage: false,
      aligns: "horizontal",
      type: "page",
      border: false,
      hasMargin: true,
      getPrefixedClassName
    },
    opt
  );
  const isVertical = this.opt.aligns === "vertical";
  this.opt.defaultIcon = this.opt.defaultIcon || isVertical ? "vtv-icon-view-grid-brand" : "";
  if (this.opt.autoActivatePage && !$.isFunction(this.opt.change)) {
    this.opt.change = this.activePage.bind(this);
  }
  this.target = $target.data("tabs", this);
  this._initTarget = $target;
  this.init();
  this.tip = new Tip({
    hideOnClick: false,
    bindDocScroll: false,
    anchorSize: 8,
    cls: "v-qtip",
    align: "rl-bt",
    offsets: [-10, 15]
  });
}
Tabs.prototype.init = function() {
  const tabsAligns = this.opt.aligns;
  const tabsType = tabsAligns === "vertical" ? "normal" : this.opt.type;
  const tabsBorderCls = {
    "horizontal-page": "vmp-page-border-bottom",
    "vertical-normal": "vmp-vertical-border"
  };
  let activeTab = this.opt.activeTab || 0;
  let tabs2 = this.target;
  if ($.isArray(this.opt.data)) {
    this.target = $(new Xtpl(indexTpl).apply(this.opt));
    this.target.appendTo(tabs2);
    tabs2 = this.target;
    this.dataMap = {};
    this.opt.data.forEach((item, i) => {
      const $tab = this.target.find(".vmp-tab").eq(i), pageContent = this.getPage(i);
      item = $.extend(
        true,
        {
          meta: {},
          hasPadding: false,
          hasBorder: false
        },
        item
      );
      this.opt.data[i] = item;
      this.dataMap[item.href] = item;
      if (item.hasPadding) {
        pageContent.addClass(getPrefixedClassName("tab-" + tabsType + "--" + tabsAligns + "-padding"));
      }
      if (item.hasBorder) {
        pageContent.addClass(getPrefixedClassName("tab-" + tabsType + "--" + tabsAligns + "-border"));
      }
      if (item.hasShadow) {
        pageContent.parent().addClass(getPrefixedClassName("tab-" + tabsType + "--" + tabsAligns + "-shadow"));
      }
      if (item.active) {
        activeTab = item.href;
      }
      if (item.contentElem) {
        const icon = item.icon || this.opt.defaultIcon;
        const hasPrepended = $(item.contentElem).children().first().hasClass("vmp-tab-icon iconfont");
        if (icon && !this.opt.noIcon && !hasPrepended) {
          $(item.contentElem).children().prepend(`<em class="${getPrefixedClassName("vmp-tab-icon")} iconfont ` + icon + '"></em>');
        }
        this.target.find('.vmp-tab[data-href="' + item.href + '"]').html("").append(item.contentElem);
      }
      if (item.hidden) {
        $tab.hide();
      }
    });
  }
  const tabSelector = this.tabSelector;
  const self = this;
  tabs2.addClass(getPrefixedClassName("vmp-tabs")).delegate(tabSelector, "click", function() {
    const tab = $(this);
    const tabCollapseIcon = isCollapseTab(tab);
    if (tabCollapseIcon) {
      if (tabs2.hasClass(TABS_COLLAPSED_CLS)) {
        if (tab.attr("child-active")) {
          return;
        }
        const key = tab.attr("data-href");
        const firstContentTab = getFirstContentTab(key);
        if (firstContentTab) {
          self.active(firstContentTab, true);
        }
        return;
      }
      if (isTabCollapseClose(tab)) {
        expandTab(this);
      } else {
        closeTab(this);
      }
      return;
    }
    self.active(this);
  });
  tabs2.delegate(tabSelector, "mouseover", function() {
    const key = $(this).attr("data-href");
    if (!key) {
      return;
    }
    const { content, tabTip, tabTipOffsetX, tabTipOffsetY } = self.dataMap[key];
    if (tabs2.hasClass(TABS_COLLAPSED_CLS)) {
      self.tip.update(content);
      self.tip.show();
      self.tip.alignTo(this);
      return;
    }
    if (tabTip) {
      self.tip.offsets = [tabTipOffsetX, tabTipOffsetY];
      self.tip.update(tabTip);
      self.tip.show();
      self.tip.alignTo(this, "bt-rl");
    }
  });
  tabs2.delegate(tabSelector, "mouseleave", function() {
    self.tip.hide();
  });
  tabs2.delegate(tabSelector, "mouseenter", function() {
    const key = $(this).attr("data-href");
    if (key) {
      self.opt.mouseEnterTab(self.dataMap[key]);
    }
  });
  if (this.opt.cls) {
    tabs2.addClass(this.opt.cls);
  }
  if (!this.opt.hasMargin) {
    tabs2.addClass(getPrefixedClassName("vmp-tabs-no-margin"));
  }
  if (tabsAligns) {
    tabs2.addClass(getPrefixedClassName("vmp-tabs-" + tabsAligns));
  }
  if (tabsType) {
    tabs2.addClass(getPrefixedClassName("vmp-tabs-" + tabsType));
  }
  if (this.opt.border && tabsBorderCls[tabsAligns + "-" + tabsType]) {
    tabs2.addClass(getPrefixedClassName(tabsBorderCls[tabsAligns + "-" + tabsType]));
  }
  tabs2.children("li").addClass(getPrefixedClassName("vmp-tab"));
  if (this.opt.defaultExpandAll) {
    this.expandAllTabs();
  }
  this.active(activeTab);
};
Tabs.prototype.expandAllTabs = function() {
  this.target.find(".vmp-tab").each((index, tab) => {
    expandTab(tab);
  });
};
Tabs.prototype.tabSelector = "li.vmp-tab";
Tabs.prototype.destroy = function() {
  this.target.removeData("tabs").undelegate(this.tabSelector, "click").undelegate(this.tabSelector, "mouseover").undelegate(this.tabSelector, "mouseenter").undelegate(this.tabSelector, "mouseleave");
  this._initTarget.removeData("tabs");
  this.target.find(".vmp-tab").removeData("href");
  this.target = this._initTarget = this.opt = this.currentTab = null;
  this.tip.destroy();
  this.tip = null;
};
Tabs.prototype.getTab = function(idx) {
  if (!idx && idx !== 0) {
    return;
  }
  idx = idx || 0;
  let tab = typeof idx === "number" ? this.target.children().eq(idx) : $(idx);
  if (!tab.is(this.tabSelector) && typeof idx === "string") {
    tab = this.target.children(this.tabSelector).filter('[data-href="' + idx + '"]');
  }
  if (!tab.is(this.tabSelector)) {
    return null;
  }
  return tab;
};
Tabs.prototype.active = async function(idx, noAutoExpand) {
  const tab = this.getTab(idx);
  if (!tab) {
    return;
  }
  if (tab.attr("disabled")) {
    return;
  }
  const activeClass = "active", activeSelector = "." + activeClass;
  if (tab.hasClass(activeClass)) {
    return;
  }
  const change = this.opt.change;
  const oldTab = tab.siblings(activeSelector);
  const newTab = tab;
  const eventData = [newTab[0], oldTab[0], this.getData(newTab), this.getData(oldTab)];
  if (typeof this.opt.before === "function") {
    const eventParams = {
      newTab: newTab[0],
      oldTab: oldTab[0],
      newData: this.getData(newTab),
      oldData: this.getData(oldTab)
    };
    const beforeHandlerRes = await this.opt.before(eventParams);
    if (beforeHandlerRes === false) {
      return;
    }
  }
  this.realignActiveBar(idx);
  const prevActiveTabs = tab.siblings(activeSelector);
  prevActiveTabs.removeClass(getPrefixedClassName(activeClass));
  const oldTabRoot = getRootTab(prevActiveTabs.attr("data-parent"));
  if (oldTabRoot) {
    oldTabRoot.removeAttr("child-active");
  }
  tab.addClass(getPrefixedClassName(activeClass));
  const parentKey = tab.attr("data-parent");
  if (parentKey && !noAutoExpand) {
    expandActiveTab(tab);
  }
  const newRootTab = getRootTab(parentKey);
  if (newRootTab) {
    newRootTab.attr("child-active", tab.attr("data-href"));
  }
  this.currentTab = tab;
  if (change) {
    change.call(this.target.get(0), newTab.get(0), prevActiveTabs.get(0));
  }
  this.target.trigger("after.sf.tabs", eventData);
};
Tabs.prototype.realignActiveBar = function(idx) {
  const tab = this.getTab(idx);
  if (!tab) {
    return;
  }
  const activeBar = this.target.find(".vmp-tabs__active-bar");
  if (!activeBar.length) {
    return;
  }
  const position = tab.position();
  const width = tab.width();
  const height = tab.height();
  const left = position.left || 0;
  const top = position.top || 0;
  const PADDING = 16;
  const barHight = activeBar[0].clientHeight || 0;
  activeBar.width(width + PADDING).css({
    left,
    top: top + height - barHight
  });
};
Tabs.prototype.getCurrentTab = function() {
  return this.currentTab;
};
Tabs.prototype.isCurrentTab = function(id) {
  return this.currentTab && this.currentTab.is(this.getTab(id));
};
Tabs.prototype.getCurrentTabData = function() {
  return this.getData(this.currentTab);
};
Tabs.prototype.activePage = function(tab) {
  tab = this.getTab(tab);
  if (!tab) {
    return;
  }
  this.getPage().hide();
  this.getPage(tab.data("href")).show();
};
Tabs.prototype.getPage = function(id) {
  const $parent = $(this.opt.parent);
  let $pages = $parent.find(this.opt.pages);
  if ($.isArray(this.opt.pages)) {
    $pages = $(this.opt.pages);
  } else {
    $pages = $parent.find(this.opt.pages);
  }
  if (!arguments.length) {
    return $pages;
  }
  return $pages.filter(function(i, elem) {
    if (typeof id === "number") {
      return id === i;
    }
    const $elem = $(elem);
    if (typeof id === "string") {
      return $elem.is(id) || $elem.is('[data-id="' + id + '"]');
    }
    return elem === $(id)[0];
  });
};
Tabs.prototype.enable = function(idx) {
  const tab = this.getTab(idx);
  if (tab) {
    tab.removeAttr("disabled");
    __setData(this, tab.data("href"), "disabled", false);
  }
};
Tabs.prototype.disable = function(idx) {
  const tab = this.getTab(idx);
  if (tab) {
    tab.attr("disabled", "disabled");
    __setData(this, tab.data("href"), "disabled", true);
  }
};
Tabs.prototype.getData = function(id) {
  const $tab = $(this.getTab(id));
  return this.dataMap ? $.extend(true, {}, this.dataMap[$tab.data("href")]) : null;
};
function __setData(tabsInstance, id, key, val) {
  if (!tabsInstance || !tabsInstance.dataMap || !tabsInstance.dataMap[id]) {
    return;
  }
  tabsInstance.dataMap[id][key] = val;
}
Tabs.prototype.toggle = function(ids, isShow) {
  ids = $.makeArray(ids);
  if (!ids.length) {
    return;
  }
  ids.forEach((id) => {
    const $tab = this.getTab(id), data = this.getData(id), isCurrentTab = this.isCurrentTab(id);
    if ($tab) {
      $tab.toggle(isShow);
    }
    if (data) {
      data.__hidden = !isShow;
      __setData(this, id, "hidden", !isShow);
    }
    if (isCurrentTab && !isShow) {
      this.active(
        this.target.find(".vmp-tab").filter((item, index) => {
          const tabData = this.getData(index);
          return !tabData.hidden && !tabData.disabled;
        })[0]
      );
    }
  });
  this.target.trigger("toggle.sf.tabs", [isShow, ids]);
};
Tabs.prototype.show = function(ids) {
  return this.toggle(ids, true);
};
Tabs.prototype.showAll = function() {
  return this.toggle(Object.keys(this.dataMap), true);
};
Tabs.prototype.hide = function(ids) {
  return this.toggle(ids, false);
};
Tabs.prototype.hideAll = function() {
  return this.toggle(Object.keys(this.dataMap), false);
};
Tabs.prototype.expand = function() {
  expandActiveTab(this.currentTab);
  this.target.removeClass(getPrefixedClassName(TABS_COLLAPSED_CLS));
};
Tabs.prototype.collapse = function() {
  this.target.find(".vmp-tab").each((index, tab) => {
    closeTab(tab);
  });
  this.target.addClass(getPrefixedClassName(TABS_COLLAPSED_CLS));
};
function isTabCollapseClose(tab) {
  if (!tab) {
    return true;
  }
  return !tab.is(`[${TAB_EXPAND_ATTR}]`);
}
function getChildrenTabs(parentKey) {
  if (!parentKey) {
    return [];
  }
  return $(`.vmp-tab[data-parent="${parentKey}"]`);
}
function getRootTab(parentKey) {
  if (!parentKey) {
    return null;
  }
  let key = parentKey;
  let tab = null;
  while (key) {
    tab = getTab(key);
    key = tab.attr("data-parent");
  }
  return tab;
}
function getFirstContentTab(parentKey) {
  if (!parentKey) {
    return null;
  }
  let tab = getChildrenTabs(parentKey).eq(0);
  while (tab && isCollapseTab(tab)) {
    const key = tab.attr("data-href");
    tab = getChildrenTabs(key).eq(0);
  }
  return tab;
}
function getTab(tabKey) {
  if (!tabKey) {
    return null;
  }
  return $(`.vmp-tab[data-href="${tabKey}"]`);
}
function isCollapseTab(tab) {
  if (!tab || !tab.length) {
    return false;
  }
  const tabCollapseIcon = tab.find(".vmp-tab-collapse-icon");
  return !!tabCollapseIcon.length;
}
function showTab(tabEl) {
  if (!tabEl) {
    return;
  }
  $(tabEl).removeAttr("hidden");
}
function hiddenTab(tabEl) {
  if (!tabEl) {
    return;
  }
  tabEl.setAttribute("hidden", "");
}
function expandActiveTab(tabEl) {
  if (!tabEl) {
    return;
  }
  const tab = $(tabEl);
  let parentKey = tab.attr("data-parent");
  while (parentKey) {
    const parentTab = getTab(parentKey);
    const siblingTabs = getChildrenTabs(parentKey);
    parentKey = parentTab.attr("data-parent");
    if (isCollapseTab(parentTab) && isTabCollapseClose(parentTab)) {
      parentTab.attr(TAB_EXPAND_ATTR, "");
    }
    [...Array.from(siblingTabs), parentTab].forEach((tabItem) => {
      showTab(tabItem);
    });
  }
}
function recoverExpandedTab(tabEl) {
  if (!tabEl) {
    return;
  }
  const tab = $(tabEl);
  if (!isCollapseTab(tab) || isTabCollapseClose(tab)) {
    return;
  }
  const childrenTabs = getChildrenTabs(tab.attr("data-href"));
  childrenTabs.each((_, childTab) => {
    showTab(childTab);
    recoverExpandedTab(childTab);
  });
}
function expandTab(tabEl) {
  if (!tabEl) {
    return;
  }
  const tab = $(tabEl);
  const childrenTabs = getChildrenTabs(tab.attr("data-href"));
  if (isCollapseTab(tab)) {
    tab.attr(TAB_EXPAND_ATTR, "");
  }
  childrenTabs.each((_, childTab) => {
    showTab(childTab);
    recoverExpandedTab(childTab);
  });
}
function closeTab(tabEl, needCloseCollapse = true) {
  if (!tabEl) {
    return;
  }
  const tab = $(tabEl);
  const childrenTabs = getChildrenTabs(tab.attr("data-href"));
  if (needCloseCollapse && isCollapseTab(tab)) {
    tab.removeAttr(TAB_EXPAND_ATTR);
  }
  if (!childrenTabs.length) {
    return;
  }
  Array.from(childrenTabs).forEach((childTab) => {
    hiddenTab(childTab);
    closeTab(childTab, false);
  });
}
function tabs(...args) {
  const [firstArg, secondArg] = args;
  switch (typeof firstArg) {
    case "function": {
      const opt = { change: firstArg };
      this.each(function() {
        new Tabs(this, opt);
      });
      break;
    }
    case "object": {
      const opt = firstArg || {};
      this.each(function() {
        new Tabs(this, opt);
      });
      break;
    }
    case "string": {
      this.each(function() {
        exec.call(this, firstArg, secondArg);
      });
      break;
    }
  }
  return this;
}
function exec(cmd, val) {
  const tabs2 = $(this).data("tabs");
  if (!tabs2) {
    return;
  }
  switch (cmd) {
    case "destroy":
      tabs2.destroy();
      break;
    case "active":
    case "disable":
    case "enable":
      tabs2[cmd](val);
      break;
  }
}
export { Tabs as Tab, tabs };
