import $ from 'jquery';
const KEYMAP = {
  esc: 27,
  del: 46,
  enter: 13,
  space: 32,
  backspace: 8
};
for (let i = 65; i < 91; i++) {
  KEYMAP[String.fromCharCode(i)] = KEYMAP[String.fromCharCode(i + 32)] = i;
}
function keymap(key, fn, scope) {
  const options = {};
  if (typeof key === "string") {
    key = parseKey(key);
    key.fn = fn;
    options.scope = scope;
    options[key.key] = key;
  } else {
    $.each(key, function(k, v) {
      if (key === "scope") {
        options.scope = v;
      } else {
        k = parseKey(k);
        k.fn = v;
        options[k.key] = k;
      }
    });
  }
  const _scope = options.scope;
  const self = $(this);
  $.each(options, function(k, v) {
    if (k !== "scope") {
      self.bind(v.event || "keydown", createTrigger(v, _scope));
    }
  });
}
function parseKey(key) {
  const m = {};
  $.each(key.split("+"), function(i, k) {
    k = $.trim(k).toLowerCase();
    switch (k) {
      case "ctrl":
      case "shift":
      case "alt":
        m[k] = true;
        break;
      default:
        m.key = k;
        m.which = KEYMAP[k];
    }
  });
  return m;
}
function createTrigger(opt, scope) {
  return function(evt) {
    if (opt.shift && !evt.shiftKey) {
      return;
    }
    if (opt.alt && !evt.altKey) {
      return;
    }
    if (opt.ctrl && !evt.ctrlKey) {
      return;
    }
    if (opt.which !== evt.which) {
      return;
    }
    opt.fn.call(scope || this, opt);
  };
}
export { keymap };
