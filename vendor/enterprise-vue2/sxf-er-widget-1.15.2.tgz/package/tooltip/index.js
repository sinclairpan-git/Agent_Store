import $ from 'jquery';
import { getScrollParent, ScrollManager } from '@sxf/er-utils/dom';
import format from '@sxf/er-utils/format';
import textMetrics from '@sxf/er-utils/textMetrics';
import ua from '@sxf/er-utils/ua';
import Tip from '@sxf/er-widget/tip';
import { throttle } from '@sxf/er-utils/delay';
const TIP_DATA_KEY = "data-hint";
const TEXT_DATA_KEY = "data-tip";
const TIP_ALIGN_KEY = "data-hint-pos";
const TIP_STYLE_KEY = "data-hint-style";
const TIP_OFFSET_KEY = "data-hint-offsets";
const TIP_ANCHOR_OFFSET_KEY = "data-hint-anchor-offset";
const TIP_AUTO_KEY = "data-hint-auto";
const TIP_FOCUS_HIDDEN_KEY = "data-hint-focus-hidden";
const TIP_ANCHOR_HIDE_KEY = "data-hint-anchor-hide";
const TIP_CLS_KEY = "data-hint-cls";
const CONFIG = {
  maxHeight: 320,
  maxWidth(isErrorStyle) {
    return isErrorStyle ? 480 : 320;
  },
  paneColor: "",
  textMarginRight: 22
};
const SHOW_BUFFER = 650;
const ERROR_SHOW_BUFFER = 100;
const HIDE_BUFFER = 200;
const THROTTLE_TIME = 200;
const VISIBLE_STATE = {
  hidden: 0,
  hiding: 1,
  showing: 2,
  visible: 3
};
const LOCATE_DEPTH = 3;
const CLICK_OUTSIDE_TIME = 200;
const OVERFLOW_TARGET_CLS = "v-qtip-hide-title";
var jquery_nanoscrollerExports = {};
var jquery_nanoscroller = {
  get exports() {
    return jquery_nanoscrollerExports;
  },
  set exports(v) {
    jquery_nanoscrollerExports = v;
  }
};
(function(module, exports) {
  (function(factory) {
    {
      return module.exports = factory($, window, document);
    }
  })(function($2, window2, document2) {
    var BROWSER_IS_IE7, BROWSER_SCROLLBAR_WIDTH, DOMSCROLL, DOWN, DRAG, ENTER, MOUSEDOWN, MOUSEENTER, MOUSEMOVE, MOUSEUP, MOUSEWHEEL, NanoScroll, PANEDOWN, RESIZE, SCROLL, TOUCHMOVE, UP, WHEEL, cAF, defaults2, getBrowserScrollbarWidth, hasTransform, isFFWithBuggyScrollbar2, rAF, transform, _elementStyle, _prefixStyle, _vendor;
    defaults2 = {
      paneClass: "nano-pane",
      sliderClass: "nano-slider",
      contentClass: "nano-content",
      enabledClass: "has-scrollbar",
      flashedClass: "flashed",
      activeClass: "active",
      iOSNativeScrolling: false,
      preventPageScrolling: false,
      disableResize: false,
      alwaysVisible: false,
      flashDelay: 1500,
      sliderMinHeight: 20,
      sliderMaxHeight: null,
      documentContext: null,
      windowContext: null
    };
    SCROLL = "scroll";
    MOUSEDOWN = "mousedown";
    MOUSEENTER = "mouseenter";
    MOUSEMOVE = "mousemove";
    MOUSEWHEEL = "mousewheel";
    MOUSEUP = "mouseup";
    RESIZE = "resize";
    DRAG = "drag";
    ENTER = "enter";
    UP = "up";
    PANEDOWN = "panedown";
    DOMSCROLL = "DOMMouseScroll";
    DOWN = "down";
    WHEEL = "wheel";
    TOUCHMOVE = "touchmove";
    BROWSER_IS_IE7 = window2.navigator.appName === "Microsoft Internet Explorer" && /msie 7./i.test(window2.navigator.appVersion) && window2.ActiveXObject;
    BROWSER_SCROLLBAR_WIDTH = null;
    rAF = window2.requestAnimationFrame;
    cAF = window2.cancelAnimationFrame;
    _elementStyle = document2.createElement("div").style;
    _vendor = function() {
      var i, transform2, vendors, _i, _len;
      vendors = ["t", "webkitT", "MozT", "msT", "OT"];
      for (i = _i = 0, _len = vendors.length; _i < _len; i = ++_i) {
        vendors[i];
        transform2 = vendors[i] + "ransform";
        if (transform2 in _elementStyle) {
          return vendors[i].substr(0, vendors[i].length - 1);
        }
      }
      return false;
    }();
    _prefixStyle = function(style) {
      if (_vendor === false) {
        return false;
      }
      if (_vendor === "") {
        return style;
      }
      return _vendor + style.charAt(0).toUpperCase() + style.substr(1);
    };
    transform = _prefixStyle("transform");
    hasTransform = transform !== false;
    getBrowserScrollbarWidth = function() {
      var outer, outerStyle, scrollbarWidth;
      outer = document2.createElement("div");
      outerStyle = outer.style;
      outerStyle.position = "absolute";
      outerStyle.width = "100px";
      outerStyle.height = "100px";
      outerStyle.overflow = SCROLL;
      outerStyle.top = "-9999px";
      document2.body.appendChild(outer);
      scrollbarWidth = outer.offsetWidth - outer.clientWidth;
      document2.body.removeChild(outer);
      return scrollbarWidth;
    };
    isFFWithBuggyScrollbar2 = function() {
      var isOSXFF, ua2, version;
      ua2 = window2.navigator.userAgent;
      isOSXFF = /(?=.+Mac OS X)(?=.+Firefox)/.test(ua2);
      if (!isOSXFF) {
        return false;
      }
      version = /Firefox\/\d{2}\./.exec(ua2);
      if (version) {
        version = version[0].replace(/\D+/g, "");
      }
      return isOSXFF && +version > 23;
    };
    NanoScroll = function() {
      function NanoScroll2(el, options) {
        this.el = el;
        this.options = options;
        BROWSER_SCROLLBAR_WIDTH || (BROWSER_SCROLLBAR_WIDTH = getBrowserScrollbarWidth());
        this.$el = $2(this.el);
        this.doc = $2(this.options.documentContext || document2);
        this.win = $2(this.options.windowContext || window2);
        this.body = this.doc.find("body");
        this.$content = this.$el.children("." + this.options.contentClass);
        this.$content.attr("tabindex", this.options.tabIndex || 0);
        this.content = this.$content[0];
        this.previousPosition = 0;
        if (this.options.iOSNativeScrolling && this.el.style.WebkitOverflowScrolling != null) {
          this.nativeScrolling();
        } else {
          this.generate();
        }
        this.createEvents();
        this.addEvents();
        this.reset();
      }
      NanoScroll2.prototype.preventScrolling = function(e, direction) {
        if (!this.isActive) {
          return;
        }
        if (e.type === DOMSCROLL) {
          if (direction === DOWN && e.originalEvent.detail > 0 || direction === UP && e.originalEvent.detail < 0) {
            e.preventDefault();
          }
        } else if (e.type === MOUSEWHEEL) {
          if (!e.originalEvent || !e.originalEvent.wheelDelta) {
            return;
          }
          if (direction === DOWN && e.originalEvent.wheelDelta < 0 || direction === UP && e.originalEvent.wheelDelta > 0) {
            e.preventDefault();
          }
        }
      };
      NanoScroll2.prototype.nativeScrolling = function() {
        this.$content.css({
          WebkitOverflowScrolling: "touch"
        });
        this.iOSNativeScrolling = true;
        this.isActive = true;
      };
      NanoScroll2.prototype.updateScrollValues = function() {
        var content, direction;
        content = this.content;
        this.maxScrollTop = content.scrollHeight - content.clientHeight;
        this.prevScrollTop = this.contentScrollTop || 0;
        this.contentScrollTop = content.scrollTop;
        direction = this.contentScrollTop > this.previousPosition ? "down" : this.contentScrollTop < this.previousPosition ? "up" : "same";
        this.previousPosition = this.contentScrollTop;
        if (direction !== "same") {
          this.$el.trigger("update", {
            position: this.contentScrollTop,
            maximum: this.maxScrollTop,
            direction
          });
        }
        if (!this.iOSNativeScrolling) {
          this.maxSliderTop = this.paneHeight - this.sliderHeight;
          this.sliderTop = this.maxScrollTop === 0 ? 0 : this.contentScrollTop * this.maxSliderTop / this.maxScrollTop;
        }
      };
      NanoScroll2.prototype.setOnScrollStyles = function() {
        var cssValue;
        if (hasTransform) {
          cssValue = {};
          cssValue[transform] = "translate(0, " + this.sliderTop + "px)";
        } else {
          cssValue = {
            top: this.sliderTop
          };
        }
        if (rAF) {
          if (cAF && this.scrollRAF) {
            cAF(this.scrollRAF);
          }
          this.scrollRAF = rAF(
            function(_this) {
              return function() {
                _this.scrollRAF = null;
                return _this.slider.css(cssValue);
              };
            }(this)
          );
        } else {
          this.slider.css(cssValue);
        }
      };
      NanoScroll2.prototype.createEvents = function() {
        this.events = {
          down: function(_this) {
            return function(e) {
              _this.isBeingDragged = true;
              _this.offsetY = e.pageY - _this.slider.offset().top;
              if (!_this.slider.is(e.target)) {
                _this.offsetY = 0;
              }
              _this.pane.addClass(_this.options.activeClass);
              _this.doc.bind(MOUSEMOVE, _this.events[DRAG]).bind(MOUSEUP, _this.events[UP]);
              _this.body.bind(MOUSEENTER, _this.events[ENTER]);
              return false;
            };
          }(this),
          drag: function(_this) {
            return function(e) {
              _this.sliderY = e.pageY - _this.$el.offset().top - _this.paneTop - (_this.offsetY || _this.sliderHeight * 0.5);
              _this.scroll();
              if (_this.contentScrollTop >= _this.maxScrollTop && _this.prevScrollTop !== _this.maxScrollTop) {
                _this.$el.trigger("scrollend");
              } else if (_this.contentScrollTop === 0 && _this.prevScrollTop !== 0) {
                _this.$el.trigger("scrolltop");
              }
              return false;
            };
          }(this),
          up: function(_this) {
            return function(e) {
              _this.isBeingDragged = false;
              _this.pane.removeClass(_this.options.activeClass);
              _this.doc.unbind(MOUSEMOVE, _this.events[DRAG]).unbind(MOUSEUP, _this.events[UP]);
              _this.body.unbind(MOUSEENTER, _this.events[ENTER]);
              return false;
            };
          }(this),
          resize: function(_this) {
            return function(e) {
              _this.reset();
            };
          }(this),
          panedown: function(_this) {
            return function(e) {
              _this.sliderY = (e.offsetY || e.originalEvent.layerY) - _this.sliderHeight * 0.5;
              _this.scroll();
              _this.events.down(e);
              return false;
            };
          }(this),
          scroll: function(_this) {
            return function(e) {
              _this.updateScrollValues();
              if (_this.isBeingDragged) {
                return;
              }
              if (!_this.iOSNativeScrolling) {
                _this.sliderY = _this.sliderTop;
                _this.setOnScrollStyles();
              }
              if (e == null) {
                return;
              }
              if (_this.contentScrollTop >= _this.maxScrollTop) {
                if (_this.options.preventPageScrolling) {
                  _this.preventScrolling(e, DOWN);
                }
                if (_this.prevScrollTop !== _this.maxScrollTop) {
                  _this.$el.trigger("scrollend");
                }
              } else if (_this.contentScrollTop === 0) {
                if (_this.options.preventPageScrolling) {
                  _this.preventScrolling(e, UP);
                }
                if (_this.prevScrollTop !== 0) {
                  _this.$el.trigger("scrolltop");
                }
              }
            };
          }(this),
          wheel: function(_this) {
            return function(e) {
              var delta;
              if (e == null) {
                return;
              }
              delta = e.delta || e.wheelDelta || e.originalEvent && e.originalEvent.wheelDelta || -e.detail || e.originalEvent && -e.originalEvent.detail;
              if (delta) {
                _this.sliderY += -delta / 3;
              }
              _this.scroll();
              return false;
            };
          }(this),
          enter: function(_this) {
            return function(e) {
              var _ref;
              if (!_this.isBeingDragged) {
                return;
              }
              if ((e.buttons || e.which) !== 1) {
                return (_ref = _this.events)[UP].apply(_ref, arguments);
              }
            };
          }(this)
        };
      };
      NanoScroll2.prototype.addEvents = function() {
        var events;
        this.removeEvents();
        events = this.events;
        if (!this.options.disableResize) {
          this.win.bind(RESIZE, events[RESIZE]);
        }
        if (!this.iOSNativeScrolling) {
          this.slider.bind(MOUSEDOWN, events[DOWN]);
          this.pane.bind(MOUSEDOWN, events[PANEDOWN]).bind("" + MOUSEWHEEL + " " + DOMSCROLL, events[WHEEL]);
        }
        this.$content.bind("" + SCROLL + " " + MOUSEWHEEL + " " + DOMSCROLL + " " + TOUCHMOVE, events[SCROLL]);
      };
      NanoScroll2.prototype.removeEvents = function() {
        var events;
        events = this.events;
        this.win.unbind(RESIZE, events[RESIZE]);
        if (!this.iOSNativeScrolling) {
          this.slider.unbind();
          this.pane.unbind();
        }
        this.$content.unbind("" + SCROLL + " " + MOUSEWHEEL + " " + DOMSCROLL + " " + TOUCHMOVE, events[SCROLL]);
      };
      NanoScroll2.prototype.generate = function() {
        var cssRule, currentPadding, options, pane, paneClass, sliderClass;
        options = this.options;
        paneClass = options.paneClass, sliderClass = options.sliderClass, options.contentClass;
        if (!(pane = this.$el.children("." + paneClass)).length && !pane.children("." + sliderClass).length) {
          this.$el.append('<div class="' + paneClass + '"><div class="' + sliderClass + '" /></div>');
        }
        this.pane = this.$el.children("." + paneClass);
        this.slider = this.pane.find("." + sliderClass);
        if (BROWSER_SCROLLBAR_WIDTH === 0 && isFFWithBuggyScrollbar2()) {
          currentPadding = window2.getComputedStyle(this.content, null).getPropertyValue("padding-right").replace(/[^0-9.]+/g, "");
          cssRule = {
            right: -14,
            paddingRight: +currentPadding + 14
          };
        } else if (BROWSER_SCROLLBAR_WIDTH) {
          cssRule = {
            right: -BROWSER_SCROLLBAR_WIDTH
          };
          this.$el.addClass(options.enabledClass);
        }
        if (cssRule != null) {
          this.$content.css(cssRule);
        }
        return this;
      };
      NanoScroll2.prototype.restore = function() {
        this.stopped = false;
        if (!this.iOSNativeScrolling) {
          this.pane.show();
        }
        this.addEvents();
      };
      NanoScroll2.prototype.reset = function() {
        var content, contentHeight, contentPosition, contentStyle, contentStyleOverflowY, paneBottom, paneHeight, paneOuterHeight, paneTop, parentMaxHeight, right, sliderHeight;
        if (this.iOSNativeScrolling) {
          this.contentHeight = this.content.scrollHeight;
          return;
        }
        if (!this.$el.find("." + this.options.paneClass).length) {
          this.generate().stop();
        }
        if (this.stopped) {
          this.restore();
        }
        content = this.content;
        contentStyle = content.style;
        contentStyleOverflowY = contentStyle.overflowY;
        if (BROWSER_IS_IE7) {
          this.$content.css({
            height: this.$content.height()
          });
        }
        contentHeight = content.scrollHeight + BROWSER_SCROLLBAR_WIDTH;
        parentMaxHeight = parseInt(this.$el.css("max-height"), 10);
        if (parentMaxHeight > 0) {
          this.$el.height("");
          this.$el.height(content.scrollHeight > parentMaxHeight ? parentMaxHeight : content.scrollHeight);
        }
        paneHeight = this.pane.outerHeight(false);
        paneTop = parseInt(this.pane.css("top"), 10);
        paneBottom = parseInt(this.pane.css("bottom"), 10);
        paneOuterHeight = paneHeight + paneTop + paneBottom;
        sliderHeight = Math.round(paneOuterHeight / contentHeight * paneHeight);
        if (sliderHeight < this.options.sliderMinHeight) {
          sliderHeight = this.options.sliderMinHeight;
        } else if (this.options.sliderMaxHeight != null && sliderHeight > this.options.sliderMaxHeight) {
          sliderHeight = this.options.sliderMaxHeight;
        }
        if (contentStyleOverflowY === SCROLL && contentStyle.overflowX !== SCROLL) {
          sliderHeight += BROWSER_SCROLLBAR_WIDTH;
        }
        this.maxSliderTop = paneOuterHeight - sliderHeight;
        this.contentHeight = contentHeight;
        this.paneHeight = paneHeight;
        this.paneOuterHeight = paneOuterHeight;
        this.sliderHeight = sliderHeight;
        this.paneTop = paneTop;
        this.slider.height(sliderHeight);
        this.events.scroll();
        this.pane.show();
        this.isActive = true;
        if (content.scrollHeight === content.clientHeight || this.pane.outerHeight(true) >= content.scrollHeight && contentStyleOverflowY !== SCROLL) {
          this.pane.hide();
          this.isActive = false;
        } else if (this.el.clientHeight === content.scrollHeight && contentStyleOverflowY === SCROLL) {
          this.slider.hide();
        } else {
          this.slider.show();
        }
        this.pane.css({
          opacity: this.options.alwaysVisible ? 1 : "",
          visibility: this.options.alwaysVisible ? "visible" : ""
        });
        contentPosition = this.$content.css("position");
        if (contentPosition === "static" || contentPosition === "relative") {
          right = parseInt(this.$content.css("right"), 10);
          if (right) {
            this.$content.css({
              right: "",
              marginRight: right
            });
          }
        }
        return this;
      };
      NanoScroll2.prototype.scroll = function() {
        if (!this.isActive) {
          return;
        }
        this.sliderY = Math.max(0, this.sliderY);
        this.sliderY = Math.min(this.maxSliderTop, this.sliderY);
        this.$content.scrollTop(this.maxScrollTop * this.sliderY / this.maxSliderTop);
        if (!this.iOSNativeScrolling) {
          this.updateScrollValues();
          this.setOnScrollStyles();
        }
        return this;
      };
      NanoScroll2.prototype.scrollBottom = function(offsetY) {
        if (!this.isActive) {
          return;
        }
        this.$content.scrollTop(this.contentHeight - this.$content.height() - offsetY).trigger(MOUSEWHEEL);
        this.stop().restore();
        return this;
      };
      NanoScroll2.prototype.scrollTop = function(offsetY) {
        if (!this.isActive) {
          return;
        }
        this.$content.scrollTop(+offsetY).trigger(MOUSEWHEEL);
        this.stop().restore();
        return this;
      };
      NanoScroll2.prototype.scrollTo = function(node) {
        if (!this.isActive) {
          return;
        }
        this.scrollTop(this.$el.find(node).get(0).offsetTop);
        return this;
      };
      NanoScroll2.prototype.stop = function() {
        if (cAF && this.scrollRAF) {
          cAF(this.scrollRAF);
          this.scrollRAF = null;
        }
        this.stopped = true;
        this.removeEvents();
        if (!this.iOSNativeScrolling) {
          this.pane.hide();
        }
        return this;
      };
      NanoScroll2.prototype.destroy = function() {
        if (!this.stopped) {
          this.stop();
        }
        if (!this.iOSNativeScrolling && this.pane.length) {
          this.pane.remove();
        }
        if (BROWSER_IS_IE7) {
          this.$content.height("");
        }
        this.$content.removeAttr("tabindex");
        if (this.$el.hasClass(this.options.enabledClass)) {
          this.$el.removeClass(this.options.enabledClass);
          this.$content.css({
            right: ""
          });
        }
        return this;
      };
      NanoScroll2.prototype.flash = function() {
        if (this.iOSNativeScrolling) {
          return;
        }
        if (!this.isActive) {
          return;
        }
        this.reset();
        this.pane.addClass(this.options.flashedClass);
        setTimeout(
          function(_this) {
            return function() {
              _this.pane.removeClass(_this.options.flashedClass);
            };
          }(this),
          this.options.flashDelay
        );
        return this;
      };
      return NanoScroll2;
    }();
    $2.fn.nanoScroller = function(settings) {
      return this.each(function() {
        var options, scrollbar;
        if (!(scrollbar = this.nanoscroller)) {
          options = $2.extend({}, defaults2, settings);
          this.nanoscroller = scrollbar = new NanoScroll(this, options);
        }
        if (settings && typeof settings === "object") {
          $2.extend(scrollbar.options, settings);
          if (settings.scrollBottom != null) {
            return scrollbar.scrollBottom(settings.scrollBottom);
          }
          if (settings.scrollTop != null) {
            return scrollbar.scrollTop(settings.scrollTop);
          }
          if (settings.scrollTo) {
            return scrollbar.scrollTo(settings.scrollTo);
          }
          if (settings.scroll === "bottom") {
            return scrollbar.scrollBottom(0);
          }
          if (settings.scroll === "top") {
            return scrollbar.scrollTop(0);
          }
          if (settings.scroll && settings.scroll instanceof $2) {
            return scrollbar.scrollTo(settings.scroll);
          }
          if (settings.stop) {
            return scrollbar.stop();
          }
          if (settings.destroy) {
            return scrollbar.destroy();
          }
          if (settings.flash) {
            return scrollbar.flash();
          }
        }
        return scrollbar.reset();
      });
    };
    $2.fn.nanoScroller.Constructor = NanoScroll;
  });
})(jquery_nanoscroller);
const defaults = {
  paneWidth: 8,
  paneColor: "",
  paneBackground: "transparent"
};
function fixscroll(options) {
  options = $.extend({}, defaults, options);
  this.each(function(ind, el) {
    const $el = $(el);
    $el.css({
      width: $el.width(),
      height: $el.height()
    });
    $el.addClass("nano");
    $el.wrapInner('<div class="nano-content"></div>');
    $el.nanoScroller(options);
  });
}
function getBrowserScrollbarValue() {
  const outer = document.createElement("div");
  const outerStyle = outer.style;
  outerStyle.position = "absolute";
  outerStyle.width = "100px";
  outerStyle.height = "100px";
  outerStyle.overflow = "scroll";
  outerStyle.top = "-9999px";
  document.body.appendChild(outer);
  const scrollbarWidth = outer.offsetWidth - outer.clientWidth;
  const scrollbarHeight = outer.offsetHeight - outer.clientHeight;
  document.body.removeChild(outer);
  return {
    width: scrollbarWidth,
    height: scrollbarHeight
  };
}
function isFFWithBuggyScrollbar() {
  const ua2 = window.navigator.userAgent;
  const isOSXFF = /(?=.+Mac OS X)(?=.+Firefox)/.test(ua2);
  if (!isOSXFF) {
    return false;
  }
  let version = /Firefox\/\d{2}\./.exec(ua2);
  if (version) {
    version = version[0].replace(/\D+/g, "");
  }
  return isOSXFF && +version > 23;
}
$.fn.nanoScroller.Constructor.prototype.generate = function() {
  let cssRule, currentPadding, options, pane, paneClass, sliderClass, scrollBarValue, BROWSER_SCROLLBAR_WIDTH, browser_scrollbar_height;
  options = this.options;
  paneClass = options.paneClass, sliderClass = options.sliderClass, options.contentClass;
  scrollBarValue = getBrowserScrollbarValue();
  BROWSER_SCROLLBAR_WIDTH = scrollBarValue.width;
  browser_scrollbar_height = scrollBarValue.height;
  if (!(pane = this.$el.children("." + paneClass)).length && !pane.children("." + sliderClass).length) {
    this.$el.append('<div class="' + paneClass + '"><div class="' + sliderClass + '" /></div>');
  }
  this.pane = this.$el.children("." + paneClass);
  this.slider = this.pane.find("." + sliderClass);
  this.pane.css({
    width: options.paneWidth,
    background: options.paneBackground
  });
  if (options.paneColor) {
    this.slider.css({
      background: options.paneColor
    });
  }
  if (BROWSER_SCROLLBAR_WIDTH === 0 && isFFWithBuggyScrollbar()) {
    currentPadding = window.getComputedStyle(this.content, null).getPropertyValue("padding-right").replace(/[^0-9.]+/g, "");
    cssRule = {
      right: -14,
      paddingRight: +currentPadding + 14
    };
  } else if (BROWSER_SCROLLBAR_WIDTH) {
    if (!ua.isGecko || this.$el.height() > browser_scrollbar_height * 2) {
      cssRule = {
        right: -BROWSER_SCROLLBAR_WIDTH
      };
    }
    if (ua.isGecko && ua.firefoxVersion >= 52) {
      cssRule = {
        right: -BROWSER_SCROLLBAR_WIDTH
      };
    }
    this.$el.addClass(options.enabledClass);
  }
  if (cssRule != null) {
    this.$content.css(cssRule);
  }
  return this;
};
class ElementObserver {
  constructor() {
    this.activeTarget = null;
    this.currentViewAncestor = null;
    this.lastMousePosition = null;
    this.observer = null;
    this.handlers = null;
  }
  initObserver(handlers) {
    this.handlers = handlers;
    const triggerHandler = throttle(this.triggerHandler.bind(this), 100);
    this.observer = new MutationObserver(() => {
      triggerHandler();
    });
  }
  triggerHandler() {
    var _a;
    if (this.lastMousePosition) {
      const elementAtPoint = document.elementFromPoint(this.lastMousePosition.x, this.lastMousePosition.y);
      if (elementAtPoint && ((_a = this.handlers) == null ? void 0 : _a.onElementMutation)) {
        this.handlers.onElementMutation(elementAtPoint);
      }
    }
  }
  updateTarget(target) {
    var _a, _b;
    if (!target || target === this.activeTarget) {
      return;
    }
    const gridViewAncestor = (_a = target.closest) == null ? void 0 : _a.call(target, ".sfis-grid-view");
    if (gridViewAncestor !== this.currentViewAncestor) {
      (_b = this.observer) == null ? void 0 : _b.disconnect();
      this.activeTarget = target;
      this.currentViewAncestor = gridViewAncestor;
      if (gridViewAncestor) {
        this.observer.observe(gridViewAncestor, {
          childList: true,
          subtree: false
        });
      }
    }
  }
  updateMousePosition(x, y) {
    this.lastMousePosition = { x, y };
  }
  clearTarget() {
    var _a;
    (_a = this.observer) == null ? void 0 : _a.disconnect();
    this.activeTarget = null;
    this.currentViewAncestor = null;
  }
  destroy() {
    var _a;
    (_a = this.observer) == null ? void 0 : _a.disconnect();
    this.activeTarget = null;
    this.currentViewAncestor = null;
    this.lastMousePosition = null;
    this.observer = null;
    this.handlers = null;
  }
}
function setQstyle(el, target) {
  const qstyle = $(target).attr("qstyle");
  if (qstyle) {
    $(target).get(0).style.cssText += ";" + qstyle;
  }
}
function inClient(el) {
  const scrollParent = getScrollParent(el);
  const elRect = el.getBoundingClientRect();
  const pRect = scrollParent.getBoundingClientRect();
  return elRect.top < pRect.top + pRect.height;
}
function hasAttr(target, attr) {
  return typeof $(target).attr(attr) !== "undefined";
}
const getStyle = (el, key) => {
  var _a;
  if (!(el instanceof Element) || !key) {
    return;
  }
  return (_a = window.getComputedStyle(el)) == null ? void 0 : _a[key];
};
function isOverflow(el) {
  var _a, _b, _c, _d;
  if (!el) {
    return;
  }
  if (el.clientWidth < el.scrollWidth) {
    return true;
  }
  if (el.clientWidth === el.scrollWidth) {
    const clientWidth = ((_b = (_a = el.getBoundingClientRect) == null ? void 0 : _a.call(el)) == null ? void 0 : _b.width) || 0;
    const range = document.createRange();
    range.selectNodeContents(el);
    const rangeWidth = ((_d = (_c = range.getBoundingClientRect) == null ? void 0 : _c.call(range)) == null ? void 0 : _d.width) || 0;
    const paddingLeft = parseInt(getStyle(el, "paddingLeft"), 10) || 0;
    const paddingRight = parseInt(getStyle(el, "paddingRight"), 10) || 0;
    const padding = paddingLeft + paddingRight;
    const scrollWidth = rangeWidth + padding;
    const diff = Math.abs(el.scrollWidth - scrollWidth);
    if (clientWidth < scrollWidth && diff < 1) {
      return true;
    }
  }
  if (el instanceof Element) {
    const clientHeight = el.clientHeight;
    const scrollHeight = el.scrollHeight;
    const lineClampValue = Number(window.getComputedStyle(el).getPropertyValue("-webkit-line-clamp"));
    if (lineClampValue > 1 && clientHeight < scrollHeight) {
      return true;
    }
  }
  return false;
}
function isSvgElement(target) {
  return /svg/i.test(Object.prototype.toString.call(target));
}
function exec(cmd, target) {
  switch (cmd) {
    case "clear":
      target.removeAttr("data-hint");
      break;
    case "error":
    case "warning":
      target.attr("data-hint-style", cmd);
      break;
    case "no-style":
    case "no-error":
    case "no-warning":
      target.removeAttr("data-hint-style");
      break;
    case "left":
    case "right":
    case "top":
    case "bottom":
      target.attr("data-hint-pos", cmd.charAt(0));
      break;
    case "nowrap":
      break;
    default:
      target.attr("data-hint", cmd);
  }
}
const hint = function() {
  const self = this;
  const args = [].slice.call(arguments, 0);
  $.each(args, function(idx, name) {
    exec(name, self);
  });
  return self;
};
class Tooltip {
  constructor() {
    this.tip = null;
    this.tipTarget = null;
    this.tipContent = "";
    this.lastTarget = null;
    this.lastContent = null;
    this.isText = false;
    this.showTid = "";
    this.hideTid = "";
    this._state = VISIBLE_STATE.hidden;
    this.clickOutsideTid = null;
    this.focusErrorElement = null;
    this.overflowTargets = [];
    this._boundFocusElements = /* @__PURE__ */ new Set();
    this.elementObserver = new ElementObserver();
    this._focusHandler = this.focusHandler.bind(this);
    this._blurElementHandler = this.blurElementHandler.bind(this);
    this.bindDomEvent();
    this._setupRemovalTracking();
    this._scrollManager = new ScrollManager({
      onScroll: this._scrollHandler.bind(this),
      throttleTime: THROTTLE_TIME
    });
  }
  init() {
    const tip = this.getTip();
    if (tip) {
      tip.destroy();
    }
    const tipTarget = this.tipTarget;
    let offsets = $(tipTarget).attr(TIP_OFFSET_KEY);
    const anchorOffset = $(tipTarget).attr(TIP_ANCHOR_OFFSET_KEY);
    const anchorHide = $(tipTarget).attr(TIP_ANCHOR_HIDE_KEY) !== void 0;
    const customCls = $(tipTarget).attr(TIP_CLS_KEY);
    if (offsets) {
      offsets = offsets.split(",").map(function(v) {
        return Number(v);
      });
    } else {
      if (this.isErrorStyle(tipTarget)) {
        offsets = [0, -6];
      }
    }
    this._scrollManager.updateScrollParents(tipTarget);
    const newTip = new Tip({
      hideOnClick: false,
      bindDocScroll: false,
      anchorSize: 8,
      anchorOffset: Number(anchorOffset) || 1,
      cls: customCls ? `v-qtip ${customCls}` : "v-qtip",
      align: "bt-rl",
      offsets: offsets || [0, 0],
      anchorHide
    });
    this.setTip(newTip);
  }
  toggleTip(target) {
    var _a, _b;
    let $target = $(target);
    let data = $target.attr(TIP_DATA_KEY);
    if (!data) {
      data = $target.attr(TEXT_DATA_KEY);
    }
    if (this.overflowTargets && this.overflowTargets.length) {
      this.overflowTargets.forEach((el) => {
        $(el).removeClass(OVERFLOW_TARGET_CLS);
      });
      this.overflowTargets = [];
    }
    if (isOverflow(target)) {
      this.overflowTargets.push(target);
    }
    if (!data) {
      let _target = target, _data = null;
      let deep = LOCATE_DEPTH;
      while (_target && !_data && deep--) {
        _target = _target.parentNode;
        _data = $(_target).attr(TIP_DATA_KEY);
        if (isOverflow(_target)) {
          this.overflowTargets.push(_target);
        }
        if (!_data) {
          _data = $(_target).attr(TEXT_DATA_KEY);
        }
        if (_data) {
          target = _target;
          $target = $(_target);
          data = _data;
        }
      }
    }
    this.isText = !$target.attr(TIP_DATA_KEY) && $target.attr(TEXT_DATA_KEY);
    if (ua.isSafari && data && this.overflowTargets && this.overflowTargets.length) {
      this.overflowTargets.forEach((el) => {
        $(el).addClass(OVERFLOW_TARGET_CLS);
      });
    }
    if ($target.is(":focus")) {
      if (data && this.isErrorStyle(target)) {
        this.focusErrorElement = target;
        $target.off("blur", this._blurElementHandler).on("blur", this._blurElementHandler);
      } else {
        this.focusErrorElement = null;
      }
    }
    if (this.focusErrorElement && hasAttr(this.focusErrorElement, TIP_FOCUS_HIDDEN_KEY)) {
      $(this.focusErrorElement).off("blur", this._blurElementHandler);
      this.focusErrorElement = null;
    }
    if (this.focusErrorElement && !this.focusErrorElement.contains(target)) {
      return;
    }
    if (data) {
      this.cancelHide();
      this.tipTarget = target;
      this.tipContent = data;
      this.show();
    } else {
      const tip = this.getTip();
      if (tip && ((_b = (_a = $target.closest(tip.el)) == null ? void 0 : _a.size) == null ? void 0 : _b.call(_a))) {
        this.cancelHide();
        this._state = VISIBLE_STATE.visible;
      } else if (this._state !== VISIBLE_STATE.hiding) {
        this.hide();
      }
    }
  }
  show() {
    const $tipTarget = $(this.tipTarget);
    const tipTarget = this.tipTarget;
    if (!tipTarget || !$tipTarget.is(":visible") || this.isErrorStyle(tipTarget) && !inClient(tipTarget)) {
      return;
    }
    const needAuto = hasAttr(tipTarget, TIP_AUTO_KEY) || $tipTarget.text().trim() === String(this.tipContent).trim();
    if (needAuto && !this.overflowTargets.length) {
      this.hide();
      return;
    }
    this.cancelHide();
    if (this.lastTarget === tipTarget && this.lastContent === this.tipContent && this._state === VISIBLE_STATE.visible) {
      return;
    }
    this.cancelShow();
    if (this._state < VISIBLE_STATE.showing) {
      this._state = VISIBLE_STATE.showing;
      this.showTid = setTimeout(this.show.bind(this), this.isErrorStyle() ? ERROR_SHOW_BUFFER : SHOW_BUFFER);
      return;
    }
    this.init();
    const tip = this.getTip();
    const maxWidth = CONFIG.maxWidth(this.isErrorStyle());
    const $tipBody = $(".v-tip-body", tip.el).css("max-width", maxWidth + "px"), $tipInfo = $tipBody.find(".v-tip-info"), padLeft = parseInt($tipInfo.css("padding-left"), 10), padRight = parseInt($tipInfo.css("padding-right"), 10), padWidth = padRight ? padLeft + padRight : 0;
    const textsize = textMetrics.measure(
      $tipBody,
      this.isText ? format.htmlTextEncode(this.tipContent) : format.htmlDecode(this.tipContent),
      maxWidth - padWidth + "px"
    );
    $tipBody.width(Math.min(maxWidth, textsize.width) + padWidth);
    $tipBody.height(textsize.height > CONFIG.maxHeight ? CONFIG.maxHeight : "auto");
    setQstyle($tipBody, tipTarget);
    if (this.isText) {
      tip.text(this.tipContent);
    } else {
      tip.update(format.htmlDecode(this.tipContent));
    }
    tip.el.attr("data-hint-style", this.parseStyle());
    tip.show();
    tip.alignTo(tipTarget, this.parseAlign());
    try {
      tip.el.get(0).offsetWidth = tip.el.get(0).offsetWidth;
    } catch (e) {
    }
    this.lastTarget = tipTarget;
    this.lastContent = this.tipContent;
    this._state = VISIBLE_STATE.visible;
    fixscroll.call($tipInfo, {
      paneColor: CONFIG.paneColor
    });
    if ($tipInfo.height() > CONFIG.maxHeight) {
      $tipInfo.find(".nano-content").css("paddingRight", CONFIG.textMarginRight);
    }
  }
  hide(force) {
    this.cancelShow();
    const tip = this.getTip();
    if (!tip) {
      return;
    }
    if (this._state === VISIBLE_STATE.hidden) {
      this.resetTipData();
      return;
    }
    if (!force && this._state === VISIBLE_STATE.visible) {
      this._state = VISIBLE_STATE.hiding;
      this.hideTid = setTimeout(this.hide.bind(this), HIDE_BUFFER);
      return;
    }
    this.cancelHide();
    tip.hide();
    this._state = VISIBLE_STATE.hidden;
    this.resetTipData();
  }
  resetTipData() {
    this.tipTarget = this.tipContent = this.lastTarget = this.lastContent = this.focusErrorElement = null;
    this.elementObserver.clearTarget();
    this._scrollManager.clear();
  }
  _setupRemovalTracking() {
    this._removalObserver = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        mutation.removedNodes.forEach((node) => {
          if (node.nodeType === 1) {
            this._boundFocusElements.forEach((element) => {
              if (node === element || node.contains(element)) {
                this._unbindFocusEvent(element);
              }
            });
          }
        });
      });
    });
    this._removalObserver.observe(document.documentElement, {
      childList: true,
      subtree: true
    });
  }
  _bindFocusEvent(element) {
    if (!this._boundFocusElements.has(element)) {
      $(element).on("focus", this._focusHandler);
      this._boundFocusElements.add(element);
    }
  }
  _unbindFocusEvent(element) {
    if (this._boundFocusElements.has(element)) {
      $(element).off("focus", this._focusHandler);
      this._boundFocusElements.delete(element);
    }
  }
  bindDomEvent() {
    this.elementObserver.initObserver({
      onElementMutation: (elementAtPoint) => {
        const target = elementAtPoint;
        if (isSvgElement(target)) {
          return;
        }
        if (this.tipTarget) {
          this._unbindFocusEvent(this.tipTarget);
        }
        if (target) {
          this._bindFocusEvent(target);
        }
        this.toggleTip(target);
      }
    });
    $(document).on("mouseover", (evt) => {
      const target = evt.target;
      const relatedTarget = evt.relatedTarget;
      this.elementObserver.updateMousePosition(evt.clientX, evt.clientY);
      if (isSvgElement(target)) {
        return;
      }
      if (relatedTarget) {
        this._unbindFocusEvent(relatedTarget);
      }
      if (target) {
        this._bindFocusEvent(target);
        this.elementObserver.updateTarget(target);
      }
      this.toggleTip(target);
    });
  }
  getTip() {
    return this.tip;
  }
  setTip(tip) {
    this.tip = tip;
    return this.tip;
  }
  blurElementHandler(evt) {
    if (this.focusErrorElement) {
      $(this.focusErrorElement).off("blur", this._blurElementHandler);
    }
    this.focusErrorElement = null;
    if (this.clickOutsideTid) {
      clearTimeout(this.clickOutsideTid);
      this.clickOutsideTid = null;
    }
    this.clickOutsideTid = setTimeout(() => {
      this.toggleTip(evt.relatedTarget);
    }, CLICK_OUTSIDE_TIME);
  }
  focusHandler(evt) {
    this.toggleTip(evt.target);
  }
  _scrollHandler() {
    this.focusErrorElement = null;
    const tip = this.getTip();
    if (!tip) {
      return;
    }
    if (tip.autoHide) {
      tip.hide();
    } else {
      tip.realign();
    }
  }
  cancelShow() {
    if (this.showTid) {
      clearTimeout(this.showTid);
      this.showTid = "";
    }
  }
  cancelHide() {
    if (this.hideTid) {
      clearTimeout(this.hideTid);
      this.hideTid = "";
    }
  }
  isErrorStyle(target) {
    return $(target || this.tipTarget).attr(TIP_STYLE_KEY) === "error";
  }
  parseAlign() {
    let defAlign = "bt-rl";
    const isAlignRegex = /^[tblr]{2}-[tblrc]{2}/i;
    if (!this.tipTarget) {
      return defAlign;
    }
    if (this.isErrorStyle(this.tipTarget)) {
      defAlign = "tb-rl";
    }
    let align = $(this.tipTarget).attr(TIP_ALIGN_KEY);
    align = {
      t: "tb-rl",
      l: "lr-bt",
      r: "rl-bt",
      b: "bt-rl",
      bl: "bt-lr",
      bc: "bt-cc"
    }[align] || align;
    if (!isAlignRegex.test(align)) {
      align = defAlign;
    }
    return align;
  }
  parseStyle() {
    const defStyle = "";
    if (!this.tipTarget) {
      return defStyle;
    }
    return $(this.tipTarget).attr(TIP_STYLE_KEY) || defStyle;
  }
}
const toolTip = (() => {
  if (!window.erGlobalTooltip) {
    window.erGlobalTooltip = new Tooltip();
  }
  return window.erGlobalTooltip;
})();
const toggleTip = toolTip.toggleTip.bind(toolTip);
const hide = toolTip.hide.bind(toolTip);
export { fixscroll, hide, hint, toggleTip };
