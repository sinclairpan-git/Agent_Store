import $ from 'jquery';
import { getPrefixedClassName } from '@sxf/er-feature';
import { $i } from '@sxf/er-config';
import { ajax, getAjaxMessage } from '@sxf/er-utils/ajax';
import uuid from '@sxf/er-utils/uuid';
import Tree from '@sxf/er-widget/tree';
const getTreeSelectDefaultConfig = () => ({
  renFieldTextFn: null,
  treeCfg: null,
  width: null,
  listWidth: null,
  value: null,
  autoSelect: null,
  listeners: null,
  listCls: "",
  listExtTpl: "",
  refuseInvalidValue: false,
  clearOnRefused: false,
  autoSelectOnRefuesd: false,
  wrap: null,
  size: ""
});
const load = function(wrap, nextFn, params) {
  const options = wrap.data("options");
  const cfg = options.initOptions;
  const ajaxOptions = $.extend({}, cfg.ajax);
  ajaxOptions.data = $.extend(ajaxOptions.data || {}, params);
  wrap.triggerHandler("data.beforeload", ajaxOptions);
  wrap.data("loaded", false).data("loading", true);
  wrap.addClass(getPrefixedClassName("loading"));
  const callback = ajaxOptions.callback;
  ajaxOptions.callback = function(success, json, xhrArgs) {
    var _a;
    options.loadingAjx = null;
    const removeStatus = function() {
      wrap.removeClass(getPrefixedClassName("loading"));
      wrap.data("loaded", true).data("loading", false);
    };
    if (wrap.data("destroyed") || !wrap.data("options")) {
      return;
    }
    const isAbort = ((_a = xhrArgs == null ? void 0 : xhrArgs[0]) == null ? void 0 : _a.statusText) === "abort";
    if (isAbort) {
      removeStatus();
      if (nextFn) {
        nextFn({
          isSuccess: false,
          isAbort: true
        });
      }
      return;
    }
    loadFormAjax(wrap, json, options);
    removeStatus();
    wrap.triggerHandler("data.load", {
      options,
      treeData: options.treeData,
      json
    });
    if (nextFn) {
      nextFn();
    }
    if (callback) {
      callback.apply(this, arguments);
    }
  };
  options.loadingAjx = ajax(ajaxOptions);
};
const abort = function(wrap) {
  const options = wrap.data("options");
  const ajx = options && options.loadingAjx;
  if (ajx) {
    ajx.abort();
  }
};
function loadFormAjax(wrap, json, options) {
  options._treeData = null;
  options.treeData = null;
  options.errMsg = null;
  if (json && json.data) {
    const cfg = options.initOptions;
    const root = cfg.ajax.root || "data";
    const processData = cfg.processData;
    let data = json[root];
    options._treeData = data;
    if (processData) {
      data = processData(data);
    }
    options.treeData = data;
  } else {
    options.errMsg = getAjaxMessage(json == null ? void 0 : json.message, {
      defaultMessage: $i("scp.vt_component.common.plugins.jquery.fixtreeselect.proxy.update_error")
    });
  }
  wrap.triggerHandler("data.changed", {
    options,
    treeData: options.treeData,
    json
  });
}
const exists = function(v) {
  return v !== void 0 && v !== null;
};
var requestAnimationFrame = window.requestAnimationFrame || window.mozRequestAnimationFrame || window.webkitRequestAnimationFrame || function(fn) {
  return window.setTimeout(fn, 20);
};
var cancelAnimationFrame = window.cancelAnimationFrame || window.mozCancelAnimationFrame || window.webkitCancelAnimationFrame || window.clearTimeout;
function forEachElement(elements, callback) {
  var elementsType = Object.prototype.toString.call(elements);
  var isCollectionTyped = "[object Array]" === elementsType || "[object NodeList]" === elementsType || "[object HTMLCollection]" === elementsType || "[object Object]" === elementsType || "undefined" !== typeof jQuery && elements instanceof jQuery || "undefined" !== typeof Elements && elements instanceof Elements;
  var i = 0, j = elements.length;
  if (isCollectionTyped) {
    for (; i < j; i++) {
      callback(elements[i]);
    }
  } else {
    callback(elements);
  }
}
function ResizeSensor(element, callback) {
  function EventQueue() {
    var q = [];
    this.add = function(ev) {
      q.push(ev);
    };
    var i, j;
    this.call = function() {
      for (i = 0, j = q.length; i < j; i++) {
        q[i].call();
      }
    };
    this.remove = function(ev) {
      var newQueue = [];
      for (i = 0, j = q.length; i < j; i++) {
        if (q[i] !== ev)
          newQueue.push(q[i]);
      }
      q = newQueue;
    };
    this.length = function() {
      return q.length;
    };
  }
  function attachResizeEvent(element2, resized) {
    if (!element2)
      return;
    if (element2.resizedAttached) {
      element2.resizedAttached.add(resized);
      return;
    }
    element2.resizedAttached = new EventQueue();
    element2.resizedAttached.add(resized);
    element2.resizeSensor = document.createElement("div");
    element2.resizeSensor.className = "resize-sensor";
    var style = "position: absolute; left: -10px; top: -10px; right: 0; bottom: 0; overflow: hidden; z-index: -1; visibility: hidden;";
    var styleChild = "position: absolute; left: 0; top: 0; transition: 0s;";
    element2.resizeSensor.style.cssText = style;
    element2.resizeSensor.innerHTML = '<div class="resize-sensor-expand" style="' + style + '"><div style="' + styleChild + '"></div></div><div class="resize-sensor-shrink" style="' + style + '"><div style="' + styleChild + ' width: 200%; height: 200%"></div></div>';
    element2.appendChild(element2.resizeSensor);
    if (element2.resizeSensor.offsetParent !== element2) {
      element2.style.position = "relative";
    }
    var expand = element2.resizeSensor.childNodes[0];
    var expandChild = expand.childNodes[0];
    var shrink = element2.resizeSensor.childNodes[1];
    var dirty, rafId, newWidth, newHeight;
    var lastWidth = element2.offsetWidth;
    var lastHeight = element2.offsetHeight;
    var reset = function() {
      expandChild.style.width = "100000px";
      expandChild.style.height = "100000px";
      expand.scrollLeft = 1e5;
      expand.scrollTop = 1e5;
      shrink.scrollLeft = 1e5;
      shrink.scrollTop = 1e5;
    };
    var waitReset = function() {
      element2.resizeWaitResetID = requestAnimationFrame(function() {
        if (expand.scrollHeight) {
          reset();
        } else {
          waitReset();
        }
      });
    };
    if (!expand.scrollHeight) {
      waitReset();
    } else {
      reset();
    }
    var onResized = function() {
      rafId = 0;
      if (!dirty)
        return;
      lastWidth = newWidth;
      lastHeight = newHeight;
      if (element2.resizedAttached) {
        element2.resizedAttached.call();
      }
    };
    var onScroll = function() {
      newWidth = element2.offsetWidth;
      newHeight = element2.offsetHeight;
      dirty = newWidth != lastWidth || newHeight != lastHeight;
      if (dirty && !rafId) {
        rafId = requestAnimationFrame(onResized);
      }
      reset();
    };
    var addEvent = function(el, name, cb) {
      if (el.attachEvent) {
        el.attachEvent("on" + name, cb);
      } else {
        el.addEventListener(name, cb);
      }
    };
    addEvent(expand, "scroll", onScroll);
    addEvent(shrink, "scroll", onScroll);
  }
  forEachElement(element, function(elem) {
    attachResizeEvent(elem, callback);
  });
  this.detach = function(ev) {
    ResizeSensor.detach(element, ev);
  };
}
ResizeSensor.detach = function(element, ev) {
  forEachElement(element, function(elem) {
    if (!elem)
      return;
    if (elem.resizeWaitResetID) {
      cancelAnimationFrame(elem.resizeWaitResetID);
    }
    if (elem.resizedAttached && typeof ev == "function") {
      elem.resizedAttached.remove(ev);
      if (elem.resizedAttached.length())
        return;
    }
    if (elem.resizeSensor) {
      if (elem.contains(elem.resizeSensor)) {
        elem.removeChild(elem.resizeSensor);
      }
      delete elem.resizeSensor;
      delete elem.resizedAttached;
    }
  });
};
const createWrap = function(cfg) {
  const $wrap = cfg.wrap ? $(cfg.wrap) : $("<div>");
  const isSmallSize = cfg.size === "small";
  $wrap.attr("id", uuid("fix-tree-select-"));
  $wrap.addClass(getPrefixedClassName("fix-tree-select-wrap"));
  $wrap.toggleClass(getPrefixedClassName("fix-tree-select-wrap--resize"), !!cfg.resizeWidth);
  $wrap.toggleClass(getPrefixedClassName("sf-tree-select-wrap--small"), isSmallSize);
  return cfg.wrap ? void 0 : $wrap;
};
const createCaret = function() {
  return "<span class='caret'></span>";
};
const resizeWrap = function($wrap) {
  const options = $wrap.data("options"), $target = options.target;
  $target.attr("readonly", true).css("padding-right", "20px");
  $target.css("width", options.initOptions.width);
  $.each(["margin-left", "margin-right", "margin-top", "margin-bottom"], function(i, key) {
    $wrap.css(key, $target.css(key));
    $target.css(key, "0");
  });
};
const expandList = function(wrap) {
  const list = initList(wrap);
  const target = wrap.data("options").target;
  if (list.data("expanding") || list.data("expanded")) {
    return;
  }
  wrap.triggerHandler("before.expand");
  list.data("expanding", true);
  load(wrap, function(opt) {
    list.data("expanding", false);
    wrap.data("__clickExpanding", false);
    if (opt && opt.isAbort) {
      return;
    }
    if (!wrap.data("options")) {
      return;
    }
    if (!target.is(":visible")) {
      return;
    }
    list.show();
    alignToWrap(wrap, list);
    list.data("expanded", true);
    wrap.triggerHandler("list.show", {
      list
    });
  });
};
const collapseList = function(wrap) {
  if (!wrap.data("options")) {
    return;
  }
  const list = wrap.data("options").list;
  if (list) {
    list.hide();
    list.data("expanded", false);
    wrap.triggerHandler("list.hide", {
      list
    });
  }
  wrap.data("list.hover", false);
};
const updateList = function(wrap) {
  initList(wrap);
  const options = wrap.data("options");
  const list = options.list;
  const tree = options.tree;
  if (options.errMsg) {
    list.find(".error-msg").text(options.errMsg).show();
    tree.hide();
  } else {
    list.find(".error-msg").text("").hide();
    tree.show();
    tree.loadData(options.treeData);
  }
};
const initList = function(wrap) {
  const options = wrap.data("options");
  const cfg = options.initOptions;
  if (!options.list) {
    const treeCfg = cfg.treeCfg || {};
    const cssText = [];
    const list = $(
      `<div class="${getPrefixedClassName("tree-select-list")} ` + (cfg.listCls || "") + '" style="' + cssText.join(";") + `"><span class="${getPrefixedClassName("error-msg")}"></span></div>`
    ).appendTo(getListParent(wrap));
    const reAlignToWrap = function() {
      alignToWrap(wrap, list);
    };
    treeCfg.listeners = {
      "item-select": function(d) {
        postValue(wrap, d);
      },
      "hand-toggle-group": reAlignToWrap,
      "hand-toggle-all-group": reAlignToWrap,
      "search-done": reAlignToWrap,
      "end-search": reAlignToWrap
    };
    treeCfg.treeBgTheme = treeCfg.treeBgTheme || "bright-theme";
    const tree = new Tree(treeCfg);
    tree.render(list);
    if (cfg.listExtTpl) {
      list.append(`<div class="${getPrefixedClassName("select-list-footer")}">` + cfg.listExtTpl + "</div>");
    }
    list.hide();
    options.list = list;
    options.tree = tree;
    options.sensor = new ResizeSensor(wrap, function() {
      options.list.css({
        width: cfg.listWidth || parseInt(wrap.css("width"), 10)
      });
    });
  }
  options.list.css({
    width: cfg.listWidth || parseInt(wrap.css("width"), 10)
  });
  return options.list;
};
const selectValue = function(wrap, value) {
  if (value === void 0 || value === null) {
    clearValue(wrap);
    return;
  }
  const options = wrap.data("options");
  const initOptions = options && options.initOptions || {};
  const tree = options.tree;
  if (!wrap.data("loaded")) {
    options.target.val("").attr("title", "");
    options.value = value;
    return false;
  }
  if (options.errMsg) {
    return;
  }
  const data = typeof value === "string" ? tree.sourceDataHash[value] : value;
  if (!data) {
    clearValue(wrap);
    return;
  }
  if (initOptions.refuseInvalidValue && (data.__disabled || !data.__selectable)) {
    if (initOptions.clearOnRefused) {
      clearValue(wrap);
    } else if (initOptions.autoSelectOnRefuesd) {
      selectFirst(wrap);
    }
    return;
  }
  tree.unSelectAll();
  tree.setSelectedValue(data.__uuid);
  const expandParents = true;
  tree.expand(data.__parentUuid, expandParents);
  postValue(wrap, data);
};
function postValue(wrap, data) {
  const options = wrap.data("options");
  const oldData = options.value;
  const cfg = options.initOptions;
  let text = data.__namePath;
  text = text.replace("//", "/");
  if ($.isFunction(cfg.renFieldTextFn)) {
    text = cfg.renFieldTextFn(text, data);
  }
  options.value = data;
  options.target.val(text).attr("title", text);
  wrap.triggerHandler("item.select", {
    data: $.extend(true, {}, data)
  });
  collapseList(wrap);
  if (!oldData || oldData.__uuid !== data.__uuid) {
    emitChange(wrap, data, oldData);
  }
  wrap.triggerHandler("value", {
    data,
    oldData
  });
}
function emitChange(wrap, newData, oldData) {
  wrap.triggerHandler("change", {
    data: newData,
    oldData
  });
}
const clearValue = function(wrap) {
  const options = wrap.data("options");
  const tree = options.tree;
  options.target.val("").attr("title", "");
  delete options.value;
  if (tree) {
    tree.unSelectAll();
  }
  wrap.triggerHandler("clear");
};
const selectFirst = function(wrap) {
  initList(wrap);
  const data = findFirstValue(wrap);
  if (data) {
    postValue(wrap, data);
  } else {
    clearValue(wrap);
  }
};
function findFirstValue(wrap) {
  const options = wrap.data("options");
  const tree = options.tree;
  const $items = $(".tree-item", tree.$view);
  const sourceDataHash = tree.sourceDataHash;
  let uuid2;
  let item;
  for (let i = 0, len = $items.length; i < len; i++) {
    uuid2 = $($items[i]).attr("data-uuid");
    item = sourceDataHash[uuid2];
    if (item.__selectable && !item.__disabled) {
      return item;
    }
  }
  return false;
}
function getListParent(wrap) {
  const parent = wrap.data("options").initOptions.listParent;
  if (typeof parent === "function") {
    return parent(wrap);
  }
  return parent || $("body");
}
function alignToWrap(wrap, list) {
  const $treeView = list.find(".sfis-tree-view");
  $treeView.css("max-height", "");
  const listHeight = list.outerHeight(true);
  const wrapPos = wrap[0].getBoundingClientRect();
  const wrapHeight = $.css(wrap[0], "height", true);
  const field = wrap.data("options").target[0];
  const borderBottomWidth = $.css(field, "border-bottom-width", true);
  const viewHeight = document.documentElement.clientHeight;
  const bottomAvailHeight = viewHeight - wrap[0].getBoundingClientRect().top - wrapHeight;
  list.css("left", wrapPos.left + "px");
  let top = wrapHeight + wrapPos.top - borderBottomWidth;
  const topAvailHeight = top - wrapHeight;
  if (bottomAvailHeight < listHeight) {
    const borderTopWidth = $.css(field, "border-top-width", true);
    if (topAvailHeight >= listHeight) {
      top = top - listHeight - borderBottomWidth - wrapHeight + borderTopWidth;
    } else {
      const treeViewSpace = listHeight - $.css($treeView[0], "height", true);
      if (bottomAvailHeight >= topAvailHeight) {
        $treeView.css("max-height", bottomAvailHeight - treeViewSpace - borderBottomWidth);
      } else {
        $treeView.css("max-height", topAvailHeight - treeViewSpace - borderTopWidth);
        top = 0;
      }
    }
  }
  list.css("top", top + "px");
}
const destroyList = function(wrap) {
  collapseList(wrap);
  const options = wrap.data("options");
  let list = options.list;
  let tree = options.tree;
  if (tree) {
    tree.destroy();
    tree = null;
  }
  if (list) {
    list.hide();
    list.remove();
    list = null;
  }
};
const TIP_FOCUS_HIDDEN_KEY = "data-hint-focus-hidden";
const LIST_SHOW_ATTR_KEY = "data-list-show";
const listeners = {};
listeners["item.select"] = function() {
};
listeners.change = function() {
};
listeners.value = function() {
};
listeners.clear = function() {
};
listeners["data.beforeload"] = function() {
};
listeners["data.load"] = function(evt) {
  const wrap = $(evt.target);
  const options = wrap.data("options");
  updateList(wrap);
  if (exists(options.value)) {
    selectValue(wrap, options.value);
  }
};
listeners["data.clear"] = function(evt) {
  clearValue($(evt.target));
};
listeners["data.changed"] = function() {
};
listeners["list.show"] = function(evt) {
  const wrap = $(evt.target);
  const $input = wrap.data("options").target;
  if ($input) {
    $input.attr(TIP_FOCUS_HIDDEN_KEY, true);
    $input.attr(LIST_SHOW_ATTR_KEY, true);
  }
  if (wrap.data("doc-attached")) {
    return;
  }
  const list = wrap.data("options").list;
  const tree = wrap.data("options").tree;
  function willNotCollapse(e) {
    return $.contains(wrap[0], e.target) || !list || list[0] === e.target || $.contains(list[0], e.target);
  }
  const attachMouseWheelFn = function(e) {
    const isInSelectBox = $.contains(wrap[0], e.target);
    const isInList = list && (list[0] === e.target || $.contains(list[0], e.target));
    if (isInSelectBox && !isInList) {
      collapseList(wrap);
      return;
    }
    if (willNotCollapse(e)) {
      e.stopImmediatePropagation();
      const lb = tree.$view[0];
      if (!$.contains(lb, e.target) || !lb.scrollTop && e.deltaY > 0 || (e.deltaY < 0 && lb.scrollHeight - lb.clientHeight) === lb.scrollTop) {
        e.preventDefault();
      }
      return;
    }
    collapseList(wrap);
  };
  const attachMouseDownFn = function(e) {
    if (willNotCollapse(e)) {
      return;
    }
    collapseList(wrap);
  };
  wrap.data("doc-attached", {
    mousedown: attachMouseDownFn,
    mousewheel: attachMouseWheelFn
  });
  $("html").mousedown(attachMouseDownFn).mousewheel(attachMouseWheelFn).click(attachMouseDownFn);
};
listeners["list.hide"] = function(evt) {
  const wrap = $(evt.target);
  const $input = wrap.data("options").target;
  if ($input) {
    $input.removeAttr(TIP_FOCUS_HIDDEN_KEY);
    $input.removeAttr(LIST_SHOW_ATTR_KEY);
  }
  const attachFn = wrap.data("doc-attached");
  if (attachFn) {
    $("html").unbind("mousedown", attachFn.mousedown).unmousewheel(attachFn.mousewheel).off("click", attachFn.mousedown);
    wrap.data("doc-attached", null);
  }
  abort(wrap);
};
const M_HAS_FIXED_FLAG_KEY = "__tree_select_has_fixed";
function init(node, cfg) {
  const $el = $(node);
  if ($el.data(M_HAS_FIXED_FLAG_KEY)) {
    return;
  }
  $el.data(M_HAS_FIXED_FLAG_KEY, true);
  $el.toggleClass(getPrefixedClassName("fix-tree-select_input--resize"), !!cfg.resizeWidth);
  $el.addClass(getPrefixedClassName("sf-tree-select_input"));
  $el.addClass("ellipsis");
  $el.wrap(createWrap(cfg)).after(createCaret());
  const $wrap = $el.parent();
  const options = {};
  options.initOptions = cfg;
  options.target = $el;
  options.trigger = $wrap.children(".caret");
  if (exists(cfg.value)) {
    options.value = cfg.value;
  }
  $wrap.data("options", options);
  $wrap.data("destroyed", 0);
  resizeWrap($wrap);
  $.each(listeners, function(key, val) {
    $wrap.bind(key, val);
  });
  if (cfg.listeners) {
    $.each(cfg.listeners, function(key, val) {
      $wrap.bind(key, val);
    });
  }
  options.trigger.click(doTrigger);
  options.target.click(doTrigger);
  const mouseDownFn = (e) => {
    handleBlur($wrap, e);
  };
  $wrap.data("mouseDownFn", mouseDownFn);
  document.documentElement.addEventListener("mousedown", mouseDownFn, true);
  if (cfg.autoSelect || cfg.autoSelectValue) {
    load($wrap, function() {
      if (exists(options.value)) {
        selectValue($wrap, options.value);
      } else if (cfg.autoSelect) {
        selectFirst($wrap);
      }
    });
  }
}
function doTrigger() {
  const wrap = $(this).parent();
  const input = wrap.children("input");
  if (!input.is(":focus")) {
    input.focus();
  }
  if (input.is(":disabled")) {
    return false;
  }
  const list = wrap.data("options").list;
  if (list && list.is(":visible")) {
    collapseList(wrap);
  } else {
    wrap.data("__clickExpanding", true);
    expandList(wrap);
  }
}
function handleBlur(treeSelectWrap, e) {
  var _a;
  const options = treeSelectWrap.data("options");
  const isClickExpanding = treeSelectWrap.data("__clickExpanding") === true;
  const isClickInWrap = $.contains(treeSelectWrap[0], e.target);
  if (isClickExpanding && !isClickInWrap) {
    (_a = options == null ? void 0 : options.loadingAjx) == null ? void 0 : _a.abort();
  }
}
function action(arg1, arg2, arg3) {
  const secArgIsStr = typeof arg2 === "string";
  switch (arg1) {
    case "option":
      return this.map(function(i, elem) {
        if (!$(elem).data(M_HAS_FIXED_FLAG_KEY)) {
          return null;
        }
        const $wrap = $(elem).parent();
        return !arg2 || !secArgIsStr ? $wrap.data("options") : $wrap.data("options")[secArgIsStr];
      });
    case "value":
      if (arguments.length === 2) {
        return this.each(function(i, elem) {
          selectValue($(elem).parent(), arg2);
        });
      }
      return this.map(function(i, elem) {
        const options = $(elem).parent().data("options");
        return options && options.value;
      });
    case "enable":
      return this.each(function(i, elem) {
        const options = $(elem).parent().data("options");
        $(options.target).prop("disabled", false);
      });
    case "disable":
      return this.each(function(i, elem) {
        const options = $(elem).parent().data("options");
        $(options.target).prop("disabled", true);
      });
    case "load":
      if ($.isFunction(arg2)) {
        load($(this[0]).parent(), arg2, {});
        return this;
      }
      load($(this[0]).parent(), arg3, arg2 || {});
      return this;
    case "abort":
      abort($(this[0]).parent());
      return this;
    case "selectfirst":
      selectFirst($(this[0]).parent());
      return this;
    case "expandList":
      expandList($(this[0]).parent());
      return this;
    case "collapseList":
      collapseList($(this[0]).parent());
      return this;
    case "destroy":
      this.each(function(i, elem) {
        const el = $(elem);
        if (!el.data(M_HAS_FIXED_FLAG_KEY)) {
          return;
        }
        el.data(M_HAS_FIXED_FLAG_KEY, false);
        destroy(el.parent());
      });
      break;
  }
}
function destroy(wrap) {
  if (wrap.data("destroyed")) {
    return;
  }
  const options = wrap.data("options");
  const cfg = options.initOptions;
  if (options.sensor) {
    options.sensor.detach();
  }
  $.each(listeners, function(key, val) {
    wrap.unbind(key, val);
  });
  const mouseDownFn = wrap.data("mouseDownFn");
  if (mouseDownFn) {
    document.documentElement.removeEventListener("mousedown", mouseDownFn, true);
  }
  if (cfg.listeners) {
    $.each(cfg.listeners, function(key, val) {
      wrap.unbind(key, val);
    });
  }
  options.trigger.unbind("click").remove();
  options.target.unbind("click", doTrigger);
  destroyList(wrap);
  wrap.data("options", null).data("destroyed", 1).data("doc-attached", null);
  if (!cfg.wrap) {
    options.target.unwrap();
  }
}
const fixtreeselect = function(arg) {
  if (!arg) {
    return;
  }
  const argType = typeof arg;
  if (argType === "string") {
    return action.apply(this, arguments);
  } else if (argType === "object") {
    return this.each(function(idx, dom) {
      init(dom, {
        ...getTreeSelectDefaultConfig(),
        ...arg
      });
    });
  }
};
export { fixtreeselect, listeners };
