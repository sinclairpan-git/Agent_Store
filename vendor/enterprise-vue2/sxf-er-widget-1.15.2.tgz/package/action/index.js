import $ from 'jquery';
const M_PLUGIN_NAME = "fixAction";
const map = {
  init: fixAction,
  destroy: destroyAction,
  toggle: toggleEnable,
  toggleElEnable,
  on: addAction,
  off: removeAction,
  options: getCfg
};
function fixaction(cmd, cfg, arg) {
  let fn = cmd;
  let args = cfg || {};
  if (typeof cmd !== "string") {
    fn = "init";
    args = cmd;
  }
  this.each(function() {
    const el = $(this);
    if (map[fn]) {
      map[fn].call(el, el, args, arg);
    }
  });
}
const defaultConfig = {
  events: "click",
  actionCls: "[action]",
  disabledCls: "[disabled]"
};
function fixAction(el, cfg) {
  cfg = $.extend(
    true,
    {
      delegateTarget: el
    },
    defaultConfig,
    cfg
  );
  if (!el.data(M_PLUGIN_NAME)) {
    el.delegate(cfg.actionCls, cfg.events, cfg, actionFn);
  }
  el.data(M_PLUGIN_NAME, cfg);
}
function destroyAction(el, isKeepData) {
  const cfg = el.data(M_PLUGIN_NAME);
  if (cfg) {
    el.undelegate(cfg.actionCls, cfg.events, actionFn);
    if (!isKeepData) {
      el.removeData(M_PLUGIN_NAME);
    }
  }
}
function actionFn(e) {
  const el = $(this);
  const cfg = e.data;
  const action = el.attr("action");
  if (el.is(cfg.disabledCls)) {
    return;
  }
  const fn = cfg[action ? action : "fn"];
  if (typeof fn === "function") {
    fn.call(cfg.scope || el, el, cfg, e);
  }
}
function toggleElEnable(el, targetEl, isEnable) {
  let disabledCls = el.data(M_PLUGIN_NAME).disabledCls;
  let fn = ["attr", "removeAttr"];
  const isCls = disabledCls.charAt(0) === ".";
  if (isCls) {
    disabledCls = disabledCls.replace(".", "");
    fn = ["addClass", "removeClass"];
  }
  if (isEnable) {
    targetEl[fn[0]](isCls ? "attr" : disabledCls, isCls ? null : disabledCls);
  } else {
    targetEl[fn[1]](disabledCls);
  }
}
function toggleEnable(el, isEnable) {
  const cfg = el.data(M_PLUGIN_NAME);
  if (isEnable) {
    fixAction(el, cfg);
  } else {
    destroyAction(el, true);
  }
}
function addAction(el, name, fn) {
  const cfg = el.data(M_PLUGIN_NAME);
  if (cfg) {
    if (typeof name === "string") {
      cfg[name] = fn;
    } else if (typeof name === "object") {
      $.extend(cfg, name);
    }
  }
}
function removeAction(el) {
  const cfg = el.data(M_PLUGIN_NAME);
  const arg = Array.prototype.slice.call(arguments, 1);
  $.each(arg, function() {
    const item = this;
    if (cfg && cfg[item]) {
      delete cfg[item];
    }
  });
}
function getCfg(el) {
  return el.data(M_PLUGIN_NAME);
}
export { fixaction };
