import $ from 'jquery';
import { $i } from '@sxf/er-config';
import { extend } from '@sxf/er-utils/oop';
import msgBox from '@sxf/er-widget/messageBox';
import WindowConstructor from '@sxf/er-widget/window';
import { getPrefixedClassName } from '@sxf/er-feature';
import Xtpl from '@sxf/er-lib/xtpl';
import { when } from '@sxf/er-utils/when';
const eventName = {
  next: "next.sf.steps",
  prev: "prev.sf.steps",
  before: "before.sf.steps",
  after: "after.sf.steps",
  toggle: "toggle.sf.steps",
  disabled: "disabled.sf.steps"
};
var defaultTpl = `<div class="{[values.getPrefixedClassName('sf-steps--default')]} unselectable {[values.contentDesc || values.contentDescElem ? values.getPrefixedClassName('has-description') : '']}">
<ul class="{[values.getPrefixedClassName('sf-steps_list--default')]} list-unstyled">
    <tpl for="data">
        <li
            class="{[parent.getPrefixedClassName('sf-steps_step')]} {[parent.getPrefixedClassName('sf-steps_step--default')]} {[values.__hidden ? 'hidden' : '']}"
            data-href="{href}">
            <div class="{[parent.getPrefixedClassName('sf-steps_step-line-wrapper')]}">
                <div class="{[parent.getPrefixedClassName('sf-steps_step-line')]}"></div>
            </div>
            <div class="{[parent.getPrefixedClassName('sf-steps_step-icon--default')]}">
                <i class="{[parent.getPrefixedClassName('sf-steps_step-done-icon--default')]} iconfont vtv-icon-comp-notify-ok"></i>
                <i class="{[parent.getPrefixedClassName('sf-steps_step-done-icon--error')]} iconfont vtv-icon-win-tip-brand"></i>
                <span class="{[parent.getPrefixedClassName('sf-steps_step-normal-icon--default')]}">{[values.__index + 1]}</span>
            </div>
            <div class="{[parent.getPrefixedClassName('sf-steps_step-text')]}">
                <div class="{[parent.getPrefixedClassName('sf-steps_content')]} {[parent.getPrefixedClassName('sf-steps_content--default')]} {[parent.getPrefixedClassName('sf-steps_content-title')]}" data-tip="{content}">{content}</div>
                <tpl if="!values.contentDescElem && values.contentDesc">
                    <div class="{[parent.getPrefixedClassName('sf-steps_content')]} {[parent.getPrefixedClassName('sf-steps_content-description')]}">{contentDesc}</div>
                </tpl>
            </div>
        </li>
    </tpl>
</ul>
</div>`;
var progressThemeTpl = `<div class="{[values.getPrefixedClassName('sf-steps--progress')]} unselectable {[values.hasTopContent ? values.getPrefixedClassName('has-top-content') : '']}">
    <ul class="{[values.getPrefixedClassName('sf-steps_list--progress')]} list-unstyled clearfix">
        <tpl for="data">
            <tpl if="xindex !== 1">
                <tpl if="xindex === 2">
                    <li class="{[parent.getPrefixedClassName('sf-steps_bar--progress')]}"
                        style="width: calc({[100 / (xcount - 1)]}% - 34px); left: 35px">
                        <div class="{[parent.getPrefixedClassName('sf-steps_bar-inner--progress')]}"></div>
                    </li>
                <tpl else>
                    <li class="{[parent.getPrefixedClassName('sf-steps_bar--progress')]}"
                        style="width: calc({[100 / (xcount - 1)]}% - 34px); left: calc({[100 / (xcount -1) * (xindex - 2)]}% + 35px)">
                        <div class="{[parent.getPrefixedClassName('sf-steps_bar-inner--progress')]}"></div>
                    </li>
                </tpl>
            </tpl>

            <li class="{[parent.getPrefixedClassName('sf-steps_step')]} {[parent.getPrefixedClassName('sf-steps_step--progress')]}
                       {[values.__hidden ? 'hidden' : '']}
                       {[xindex === 1 ? parent.getPrefixedClassName('is-first') : '']}
                       {[xindex === xcount ? parent.getPrefixedClassName('is-last') : '']}"
                data-href="{href}"
                style="width: {[xindex === 1 || xindex === xcount ? '120px' : (100 / xcount + '%')]}; left: {[xindex === 1 ? 0 : 100 / (xcount - 1) * (xindex -1)]}%">
                <div class="{[parent.getPrefixedClassName('sf-steps_step-icon--progress')]}">
                    <div class="{[parent.getPrefixedClassName('sf-steps_step-icon--progress-inner')]}">
                        <i class="{[parent.getPrefixedClassName('sf-steps_active-icon--progress')]} iconfont vtv-icon-enable"></i>
                        <i class="{[parent.getPrefixedClassName('sf-steps_current-icon--progress')]}">
                            {[xindex]}
                        </i>
                    </div>
                </div>
                <div class="{[parent.getPrefixedClassName('sf-steps_step-text')]}">
                    <div class="{[parent.getPrefixedClassName('sf-steps_content')]} {[parent.getPrefixedClassName('sf-steps_content--progress')]} ellipsis {[parent.getPrefixedClassName('sf-steps_content-title')]}" data-tip="{content}">
                        {content}
                    </div>
                    <tpl if="!values.contentDescElem && values.contentDesc">
                        <div class="{[parent.getPrefixedClassName('sf-steps_content')]} {[parent.getPrefixedClassName('sf-steps_content--progress')]} ellipsis {[parent.getPrefixedClassName('sf-steps_content-description')]}" data-tip="{contentDesc}">
                            {contentDesc}
                        </div>
                    </tpl>
                </div>
                <div class="{[parent.getPrefixedClassName('sf-steps_top-content--progress')]} ellipsis" data-tip="{topContent}">
                    {topContent}
                </div>
            </li>
        </tpl>
    </ul>
</div>`;
const tpl = {
  default: defaultTpl,
  progress: progressThemeTpl
};
const stepDescClassNames = {
  default: [getPrefixedClassName("sf-steps_content"), getPrefixedClassName("sf-steps_content-description")].join(" "),
  progress: [
    "ellipsis",
    getPrefixedClassName("sf-steps_content"),
    getPrefixedClassName("sf-steps_content--progress"),
    getPrefixedClassName("sf-steps_content-description")
  ].join(" ")
};
class Steps {
  constructor(elem, options) {
    this.options = Object.assign(
      {
        parent: $(elem).parent(),
        pages: ".tab-page",
        data: [],
        theme: "default",
        mode: "page",
        direction: "horizontal",
        extendCls: "",
        getPrefixedClassName
      },
      options
    );
    if (!this.options.activeTab && this.options.activeTab !== 0) {
      const activeTab = this.options.data.filter((item) => item.active)[0];
      this.options.activeTab = activeTab && activeTab.href;
    }
    this.setData(this.options.data);
    this.$wrap = $(elem).data("sf.steps", this);
    this.stepIndex = 0;
    this.init();
  }
  setData(data) {
    this.dataMap = {};
    const widthPercent = 100 / data.length;
    data.forEach((item, i) => {
      item = data[i] = $.extend({ hidden: false, meta: {} }, item);
      item.__hidden = item.hidden;
      item.__width = this.options.direction === "horizontal" ? widthPercent + "%" : "100%";
      this.dataMap[item.href] = item;
    });
    this.options.data = data;
  }
  setPages(pages) {
    this.options.pages = pages;
  }
  init() {
    this.redraw();
    this.active(this.options.activeTab, true);
  }
  redraw() {
    let index = 0;
    let hasTopContent = false;
    this.options.data.forEach(function(item) {
      if (!item.__hidden) {
        item.__index = index;
        index += 1;
      } else {
        item.__index = -1;
      }
      if (item.topContent || item.topContent === "0") {
        hasTopContent = true;
      }
    });
    if (hasTopContent) {
      this.options.hasTopContent = true;
    }
    const $elem = $(new Xtpl(tpl[this.options.theme]).apply(this.options));
    if (this.$elem) {
      this.$elem.replaceWith($elem);
    } else {
      this.$wrap.append($elem);
    }
    this.$elem = $elem;
    let hasContentDesc = false;
    this.options.data.forEach((item) => {
      if (item.contentElem) {
        this.$elem.find(`.sf-steps_step[data-href="${item.href}"] .sf-steps_content-title`).html("").append(item.contentElem);
      }
      if (item.contentDescElem) {
        this.$elem.find(`.sf-steps_step[data-href="${item.href}"] .sf-steps_step-text`).append(item.contentDescElem);
        $(item.contentDescElem).addClass(stepDescClassNames[this.options.theme]);
        hasContentDesc = true;
      }
      if (item.isError) {
        this.$elem.find(`.sf-steps_step[data-href="${item.href}"]`).addClass(getPrefixedClassName("error"));
      }
      if (item.disabled) {
        this.setDisabled(item.href, true, false);
      }
      item.topContent = item.topContent || item.topContent === "0" ? item.topContent : "";
    });
    this.$elem.toggleClass(getPrefixedClassName("has-description"), hasContentDesc);
    this.activeTab(this.stepIndex);
    this.activePage(this.stepIndex);
    if (this.options.direction) {
      this.$elem.addClass(getPrefixedClassName(`sf-steps--${this.options.direction}`));
    }
    if (this.options.mode) {
      this.$elem.addClass(getPrefixedClassName(`sf-steps--${this.options.mode}`));
    }
    if (this.options.extendCls) {
      this.$elem.addClass(this.options.extendCls);
    }
  }
  active(id, focus = false) {
    const $newTab = this.getTab(id);
    if (!$newTab.length) {
      return;
    }
    const beforeEvent = $.Event(eventName.before);
    const activeClass = "active";
    const activeSelector = `.${activeClass}`;
    if (!focus && $newTab.hasClass(activeClass)) {
      return;
    }
    const $tabs = this.$elem.find(".sf-steps_step");
    const $oldTab = $tabs.filter(activeSelector);
    const newData = this.getData($newTab);
    const oldData = this.getData($oldTab);
    const eventData = [$newTab[0], $oldTab[0], newData, oldData];
    this.$wrap.trigger(beforeEvent, eventData);
    let actionEvent;
    if ($oldTab.length) {
      actionEvent = $.Event(newData.__index > oldData.__index ? eventName.next : eventName.prev);
      this.$wrap.trigger(actionEvent, eventData);
    }
    if (beforeEvent.isDefaultPrevented() || actionEvent && actionEvent.isDefaultPrevented()) {
      return;
    }
    when(beforeEvent.result, actionEvent && actionEvent.result).then((beforeResult, actionResult) => {
      if (typeof beforeResult !== "undefined" && !beforeResult || typeof actionResult !== "undefined" && !actionResult) {
        return;
      }
      this.activeTab($newTab);
      this.activePage($newTab);
      this.$wrap.trigger(eventName.after, eventData);
    });
  }
  activeTab(id) {
    const $tabs = this.$elem.find(".sf-steps_step"), $newTab = this.getTab(id), index = $tabs.index($newTab);
    if (!$newTab.length) {
      return;
    }
    if (this.options.theme === "progress") {
      this.$elem.find(".sf-steps_bar-inner--progress").hide();
      this.$elem.find(".sf-steps_bar-inner--progress:lt(" + index + ")").show();
    }
    $tabs.removeClass([getPrefixedClassName("done"), getPrefixedClassName("active")].join(" "));
    $newTab.addClass(getPrefixedClassName("active"));
    $newTab.prevAll(".sf-steps_step").addClass(getPrefixedClassName("done"));
    this.stepIndex = $tabs.index($newTab);
    this.href = $newTab.data("href");
  }
  activePage(tab) {
    const $tab = this.getTab(tab);
    if (!$tab.length) {
      return;
    }
    this.getPage().hide();
    this.getPage($tab.data("href")).show();
  }
  next() {
    const stepData = this.options.data.slice(this.stepIndex + 1).filter(function(item) {
      return !item.__disabled;
    })[0] || {};
    this.active(stepData.href);
  }
  prev() {
    let stepData = this.options.data.slice(0, this.stepIndex).filter(function(item) {
      return !item.__disabled;
    });
    stepData = stepData[stepData.length - 1] || {};
    this.active(stepData.href);
  }
  inFirst() {
    let firstIndex = 0;
    $.each(this.options.data, function(i, item) {
      if (!item.__disabled) {
        firstIndex = i;
        return false;
      }
    });
    return this.stepIndex === firstIndex;
  }
  inEnd() {
    let endIndex = 0;
    $.each(this.options.data, function(i, item) {
      if (!item.__disabled) {
        endIndex = i;
      }
    });
    return this.stepIndex === endIndex;
  }
  getTab(id) {
    const $tabs = this.$elem.find(".sf-steps_step");
    if (!arguments.length) {
      return $tabs;
    }
    return $tabs.filter(function(i, elem) {
      if (typeof id === "number") {
        return id === i;
      }
      const $elem = $(elem);
      if (typeof id === "string") {
        return $elem.is('[data-href="' + id + '"]');
      }
      return elem === $(id)[0];
    });
  }
  getData(id) {
    const $tab = this.getTab(id);
    if (arguments[1]) {
      return this.dataMap[$tab.data("href")];
    }
    return $.extend(
      true,
      {
        meta: {}
      },
      this.dataMap[$tab.data("href")]
    );
  }
  getPage(id) {
    const $parent = $(this.options.parent);
    let $pages;
    if ($.isArray(this.options.pages)) {
      $pages = $(this.options.pages);
    } else {
      $pages = $parent.find(this.options.pages);
    }
    if (!arguments.length) {
      return $pages;
    }
    return $pages.filter(function(i, elem) {
      if (typeof id === "number") {
        return id === i;
      }
      const $elem = $(elem);
      if (typeof id === "string") {
        return $elem.is(id) || $elem.is('[data-id="' + id + '"]');
      }
      return elem === $(id)[0];
    });
  }
  toggle(ids, isShow) {
    ids = $.makeArray(ids);
    if (!ids.length) {
      return;
    }
    ids.forEach((id) => {
      const data = this.getData(id, true) || {};
      data.__hidden = !isShow;
    });
    this.redraw();
    this.setDisabled(ids, !isShow);
    this.$wrap.trigger(eventName.toggle, [isShow, ids]);
  }
  show(ids) {
    return this.toggle(ids, true);
  }
  showAll() {
    return this.toggle(Object.keys(this.dataMap), true);
  }
  hide(ids) {
    return this.toggle(ids, false);
  }
  hideAll() {
    return this.toggle(Object.keys(this.dataMap), false);
  }
  setDisabled(ids, disabled, emitEvent) {
    emitEvent = typeof emitEvent === "undefined" ? true : emitEvent;
    ids = $.makeArray(ids);
    if (!ids.length) {
      return;
    }
    ids.forEach((id) => {
      const $tab = this.getTab(id), stepData = this.getData($tab, true) || {};
      $tab.toggleClass(getPrefixedClassName("disabled"), disabled);
      stepData.__disabled = disabled;
    });
    if (emitEvent) {
      this.$wrap.trigger(eventName.disabled, [disabled, ids]);
    }
  }
  disable(ids) {
    this.setDisabled(ids, true);
  }
  disabledAll() {
    this.setDisabled(Object.keys(this.dataMap), true);
  }
  enable(ids) {
    this.setDisabled(ids, false);
  }
  enableAll() {
    this.setDisabled(Object.keys(this.dataMap), false);
  }
  isDisabled(id) {
    const href = this.getTab(id).data("href"), tabData = this.dataMap[href];
    return Boolean(tabData.__disabled);
  }
  destroy() {
    this.$wrap.removeData("sf.steps");
  }
}
const StepWindow = extend(WindowConstructor, {
  constructor: function(options) {
    this.options = $.extend(
      true,
      {
        steps: {
          data: []
        }
      },
      options
    );
    if (!options.steps.elem || !this.options.steps.data.length) {
      return new WindowConstructor(options);
    }
    StepWindow.superclass.constructor.apply(this, arguments);
  },
  init: function() {
    const stepCount = this.options.steps.data.length;
    if (!this.options.buttons) {
      this.options.buttons = [
        {
          text: $i("scp.vt_component.common.widget.step_window.prev_btn"),
          action: "prev",
          cls: "hidden"
        },
        {
          text: $i("scp.vt_component.common.widget.step_window.next_btn"),
          action: "next",
          cls: "btn-primary " + (stepCount > 1 ? "" : "hidden")
        },
        {
          text: $i("scp.vt_component.common.widget.step_window.submit_btn"),
          action: "submit",
          cls: stepCount > 1 ? "hidden" : ""
        },
        {
          text: $i("scp.vt_component.common.widget.step_window.cancel_btn"),
          action: "cancel"
        }
      ];
    }
    StepWindow.superclass.init.apply(this, arguments);
  },
  initEvent: function() {
    StepWindow.superclass.initEvent.apply(this, arguments);
    this.addEvents(eventName.before, eventName.next, eventName.prev, eventName.after);
  },
  renderBody: function() {
    const stepsOption = this.options.steps;
    StepWindow.superclass.renderBody.apply(this, arguments);
    if (!this.rendered) {
      return;
    }
    const $step = this.bodyEl.find(stepsOption.elem);
    this.$step = $step;
    $step.on(eventName.before, (...args) => {
      if (!this.hasListener(eventName.before)) {
        return;
      }
      args[0] = eventName.before;
      this.emit.apply(this, args);
      return this.events[eventName.before].result;
    });
    $step.on(eventName.prev, (...args) => {
      if (!this.hasListener(eventName.prev)) {
        return;
      }
      args[0] = eventName.prev;
      this.emit.apply(this, args);
      return this.events[eventName.prev].result;
    });
    $step.on(eventName.next, (...args) => {
      const [e, newTab, oldTab, data, oldData] = args;
      let valid = true;
      if (oldTab && $.isFunction(stepsOption.validMethod)) {
        valid = stepsOption.validMethod(oldData);
      }
      return $.when(valid).then((valid2) => {
        if ($.isArray(valid2)) {
          msgBox.showErr(valid2.join("\n") || $i("scp.vt_component.common.widget.step_window.error_msg"));
        }
        if (valid2 !== true) {
          return false;
        }
        if (this.hasListener(eventName.next)) {
          args[0] = eventName.next;
          this.emit.apply(this, args);
          return this.events[eventName.next].result;
        }
      });
    });
    $step.on(eventName.disabled, () => {
      this._updateStepButton();
    });
    $step.on(eventName.after, (...args) => {
      this._updateStepButton();
      if (!this.hasListener(eventName.after)) {
        return;
      }
      args[0] = eventName.after;
      this.emit.apply(this, args);
      return this.events[eventName.after].result;
    });
    new Steps($step, stepsOption);
    const step = $step.data("sf.steps");
    this.step = step;
    this.winEl.on("click", ".sfis-window-footer [action]", function() {
      const $btn = $(this), action = $btn.attr("action");
      switch (action) {
        case "prev":
          step.prev();
          break;
        case "next":
          step.next();
          break;
      }
    });
  },
  prev: function() {
    this.step.prev.apply(this.step, arguments);
  },
  next: function() {
    this.step.next.apply(this.step, arguments);
  },
  _updateStepButton: function() {
    const step = this.$step.data("sf.steps");
    const inFirst = step.inFirst();
    const inEnd = step.inEnd();
    this.footerEl.find("[action=prev]").toggleClass("hidden", inFirst);
    this.footerEl.find("[action=next]").toggleClass("hidden", inEnd);
    this.footerEl.find("[action=submit]").toggleClass("hidden", !inEnd);
    this.updatePosition();
  },
  destroy: function() {
    StepWindow.superclass.destroy.apply(this, arguments);
    if (!this.isStepDestroyed) {
      if (this.emit("beforedestroy", this) !== false) {
        this.isStepDestroyed = true;
        this.step.destroy();
      }
    }
  }
});
function steps(options) {
  return this.each(function(i, elem) {
    new Steps(elem, options);
  });
}
export { StepWindow, Steps, steps };
