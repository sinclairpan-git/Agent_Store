var DOM = {};
DOM.create = function(tagName, className) {
  var element = document.createElement(tagName);
  element.className = className;
  return element;
};
DOM.appendTo = function(child, parent) {
  parent.appendChild(child);
  return child;
};
function cssGet(element, styleName) {
  return window.getComputedStyle(element)[styleName];
}
function cssSet(element, styleName, styleValue) {
  if (typeof styleValue === "number") {
    styleValue = styleValue.toString() + "px";
  }
  element.style[styleName] = styleValue;
  return element;
}
function cssMultiSet(element, obj) {
  for (var key in obj) {
    var val = obj[key];
    if (typeof val === "number") {
      val = val.toString() + "px";
    }
    element.style[key] = val;
  }
  return element;
}
DOM.css = function(element, styleNameOrObject, styleValue) {
  if (typeof styleNameOrObject === "object") {
    return cssMultiSet(element, styleNameOrObject);
  } else {
    if (typeof styleValue === "undefined") {
      return cssGet(element, styleNameOrObject);
    } else {
      return cssSet(element, styleNameOrObject, styleValue);
    }
  }
};
DOM.matches = function(element, query) {
  if (typeof element.matches !== "undefined") {
    return element.matches(query);
  } else {
    return element.msMatchesSelector(query);
  }
};
DOM.remove = function(element) {
  if (typeof element.remove !== "undefined") {
    element.remove();
  } else {
    if (element.parentNode) {
      element.parentNode.removeChild(element);
    }
  }
};
DOM.queryChildren = function(element, selector) {
  return element.querySelectorAll(selector);
};
const toInt = function(x) {
  return parseInt(x, 10) || 0;
};
const isEditable = function(el) {
  return DOM.matches(el, "input,[contenteditable]") || DOM.matches(el, "select,[contenteditable]") || DOM.matches(el, "textarea,[contenteditable]") || DOM.matches(el, "button,[contenteditable]");
};
const removePsClasses = function(element) {
  for (var i = 0; i < element.classList.length; i++) {
    var className = element.classList[i];
    if (className.indexOf("ps-") === 0) {
      element.classList.remove(className);
    }
  }
};
const outerWidth = function(element) {
  return toInt(DOM.css(element, "width")) + toInt(DOM.css(element, "paddingLeft")) + toInt(DOM.css(element, "paddingRight")) + toInt(DOM.css(element, "borderLeftWidth")) + toInt(DOM.css(element, "borderRightWidth"));
};
function psClasses(axis) {
  var classes = ["ps--in-scrolling"];
  var axisClasses;
  if (typeof axis === "undefined") {
    axisClasses = ["ps--x", "ps--y"];
  } else {
    axisClasses = ["ps--" + axis];
  }
  return classes.concat(axisClasses);
}
const startScrolling = function(element, axis) {
  var classes = psClasses(axis);
  for (var i = 0; i < classes.length; i++) {
    element.classList.add(classes[i]);
  }
};
const stopScrolling = function(element, axis) {
  var classes = psClasses(axis);
  for (var i = 0; i < classes.length; i++) {
    element.classList.remove(classes[i]);
  }
};
const env = {
  isWebKit: typeof document !== "undefined" && "WebkitAppearance" in document.documentElement.style,
  supportsTouch: typeof window !== "undefined" && ("ontouchstart" in window || window.DocumentTouch && document instanceof window.DocumentTouch),
  supportsIePointer: typeof window !== "undefined" && window.navigator.msMaxTouchPoints !== null
};
var _ = {
  toInt,
  isEditable,
  removePsClasses,
  outerWidth,
  startScrolling,
  stopScrolling,
  env
};
function defaultSettings() {
  return {
    handlers: ["click-rail", "drag-scrollbar", "keyboard", "wheel", "touch"],
    maxScrollbarLength: null,
    minScrollbarLength: null,
    scrollXMarginOffset: 0,
    scrollYMarginOffset: 0,
    suppressScrollX: false,
    suppressScrollY: false,
    swipePropagation: true,
    swipeEasing: true,
    useBothWheelAxes: false,
    wheelPropagation: false,
    wheelSpeed: 1,
    theme: "default",
    scrollbarContainer: null,
    scrollbarXRailContainer: null,
    scrollbarYRailContainer: null
  };
}
var EventElement = function(element) {
  this.element = element;
  this.events = {};
};
EventElement.prototype.bind = function(eventName, handler) {
  if (typeof this.events[eventName] === "undefined") {
    this.events[eventName] = [];
  }
  this.events[eventName].push(handler);
  this.element.addEventListener(eventName, handler, false);
};
EventElement.prototype.unbind = function(eventName, handler) {
  var isHandlerProvided = typeof handler !== "undefined";
  this.events[eventName] = this.events[eventName].filter(function(hdlr) {
    if (isHandlerProvided && hdlr !== handler) {
      return true;
    }
    this.element.removeEventListener(eventName, hdlr, false);
    return false;
  }, this);
};
EventElement.prototype.unbindAll = function() {
  for (var name in this.events) {
    this.unbind(name);
  }
};
var EventManager = function() {
  this.eventElements = [];
};
EventManager.prototype.eventElement = function(element) {
  var ee = this.eventElements.filter(function(eventElement) {
    return eventElement.element === element;
  })[0];
  if (typeof ee === "undefined") {
    ee = new EventElement(element);
    this.eventElements.push(ee);
  }
  return ee;
};
EventManager.prototype.bind = function(element, eventName, handler) {
  this.eventElement(element).bind(eventName, handler);
};
EventManager.prototype.unbind = function(element, eventName, handler) {
  this.eventElement(element).unbind(eventName, handler);
};
EventManager.prototype.unbindAll = function() {
  for (var i = 0; i < this.eventElements.length; i++) {
    this.eventElements[i].unbindAll();
  }
};
EventManager.prototype.once = function(element, eventName, handler) {
  var ee = this.eventElement(element);
  var onceHandler = function(e) {
    ee.unbind(eventName, onceHandler);
    handler(e);
  };
  ee.bind(eventName, onceHandler);
};
function s4() {
  return Math.floor((1 + Math.random()) * 65536).toString(16).substring(1);
}
function uuid() {
  return s4() + s4() + "-" + s4() + "-" + s4() + "-" + s4() + "-" + s4() + s4() + s4();
}
var instances = {};
function Instance(element, userSettings) {
  var i = this;
  i.settings = defaultSettings();
  for (var key in userSettings) {
    i.settings[key] = userSettings[key];
  }
  i.containerWidth = null;
  i.containerHeight = null;
  i.contentWidth = null;
  i.contentHeight = null;
  i.isRtl = DOM.css(element, "direction") === "rtl";
  i.isNegativeScroll = function() {
    var originalScrollLeft = element.scrollLeft;
    var result = null;
    element.scrollLeft = -1;
    result = element.scrollLeft < 0;
    element.scrollLeft = originalScrollLeft;
    return result;
  }();
  i.negativeScrollAdjustment = i.isNegativeScroll ? element.scrollWidth - element.clientWidth : 0;
  i.event = new EventManager();
  i.ownerDocument = element.ownerDocument || document;
  function focus() {
    element.classList.add("ps--focus");
    if (i.customScrollbar) {
      i.scrollbarContainer.classList.add("ps--focus");
    }
  }
  function blur() {
    element.classList.remove("ps--focus");
    if (i.customScrollbar) {
      i.scrollbarContainer.classList.remove("ps--focus");
    }
  }
  i.customScrollbar = i.settings.scrollbarContainer;
  i.scrollbarContainer = i.settings.scrollbarContainer || element;
  i.scrollbarXRailContainer = i.settings.scrollbarXRailContainer || i.scrollbarContainer;
  i.scrollbarYRailContainer = i.settings.scrollbarYRailContainer || i.scrollbarContainer;
  i.scrollbarXRail = DOM.appendTo(DOM.create("div", "ps__scrollbar-x-rail"), i.scrollbarXRailContainer);
  i.scrollbarX = DOM.appendTo(DOM.create("div", "ps__scrollbar-x"), i.scrollbarXRail);
  i.scrollbarX.setAttribute("tabindex", 0);
  i.event.bind(i.scrollbarX, "focus", focus);
  i.event.bind(i.scrollbarX, "blur", blur);
  i.scrollbarXActive = null;
  i.scrollbarXWidth = null;
  i.scrollbarXLeft = null;
  i.scrollbarXBottom = _.toInt(DOM.css(i.scrollbarXRail, "bottom"));
  i.isScrollbarXUsingBottom = i.scrollbarXBottom === i.scrollbarXBottom;
  i.scrollbarXTop = i.isScrollbarXUsingBottom ? null : _.toInt(DOM.css(i.scrollbarXRail, "top"));
  i.railBorderXWidth = _.toInt(DOM.css(i.scrollbarXRail, "borderLeftWidth")) + _.toInt(DOM.css(i.scrollbarXRail, "borderRightWidth"));
  DOM.css(i.scrollbarXRail, "display", "block");
  i.railXMarginWidth = _.toInt(DOM.css(i.scrollbarXRail, "marginLeft")) + _.toInt(DOM.css(i.scrollbarXRail, "marginRight"));
  DOM.css(i.scrollbarXRail, "display", "");
  i.railXWidth = null;
  i.railXRatio = null;
  i.scrollbarYRail = DOM.appendTo(DOM.create("div", "ps__scrollbar-y-rail"), i.scrollbarYRailContainer);
  i.scrollbarY = DOM.appendTo(DOM.create("div", "ps__scrollbar-y"), i.scrollbarYRail);
  i.scrollbarY.setAttribute("tabindex", 0);
  i.event.bind(i.scrollbarY, "focus", focus);
  i.event.bind(i.scrollbarY, "blur", blur);
  i.scrollbarYActive = null;
  i.scrollbarYHeight = null;
  i.scrollbarYTop = null;
  i.scrollbarYRight = _.toInt(DOM.css(i.scrollbarYRail, "right"));
  i.isScrollbarYUsingRight = i.scrollbarYRight === i.scrollbarYRight;
  i.scrollbarYLeft = i.isScrollbarYUsingRight ? null : _.toInt(DOM.css(i.scrollbarYRail, "left"));
  i.scrollbarYOuterWidth = i.isRtl ? _.outerWidth(i.scrollbarY) : null;
  i.railBorderYWidth = _.toInt(DOM.css(i.scrollbarYRail, "borderTopWidth")) + _.toInt(DOM.css(i.scrollbarYRail, "borderBottomWidth"));
  DOM.css(i.scrollbarYRail, "display", "block");
  i.railYMarginHeight = _.toInt(DOM.css(i.scrollbarYRail, "marginTop")) + _.toInt(DOM.css(i.scrollbarYRail, "marginBottom"));
  DOM.css(i.scrollbarYRail, "display", "");
  i.railYHeight = null;
  i.railYRatio = null;
}
function getId(element) {
  return element.getAttribute("data-ps-id");
}
function setId(element, id) {
  element.setAttribute("data-ps-id", id);
}
function removeId(element) {
  element.removeAttribute("data-ps-id");
}
const add = function(element, userSettings) {
  var newId = uuid();
  setId(element, newId);
  instances[newId] = new Instance(element, userSettings);
  return instances[newId];
};
const remove = function(element) {
  delete instances[getId(element)];
  removeId(element);
};
const get = function(element) {
  return instances[getId(element)];
};
var psInstances = {
  add,
  remove,
  get
};
function destroy(element) {
  var i = psInstances.get(element);
  if (!i) {
    return;
  }
  i.event.unbindAll();
  DOM.remove(i.scrollbarX);
  DOM.remove(i.scrollbarY);
  DOM.remove(i.scrollbarXRail);
  DOM.remove(i.scrollbarYRail);
  _.removePsClasses(element);
  psInstances.remove(element);
}
var createDOMEvent = function(name) {
  var event = document.createEvent("Event");
  event.initEvent(name, true, true);
  return event;
};
function updateScroll(element, axis, value) {
  if (typeof element === "undefined") {
    throw "You must provide an element to the update-scroll function";
  }
  if (typeof axis === "undefined") {
    throw "You must provide an axis to the update-scroll function";
  }
  if (typeof value === "undefined") {
    throw "You must provide a value to the update-scroll function";
  }
  if (axis === "top" && value <= 0) {
    element.scrollTop = value = 0;
    element.dispatchEvent(createDOMEvent("ps-y-reach-start"));
  }
  if (axis === "left" && value <= 0) {
    element.scrollLeft = value = 0;
    element.dispatchEvent(createDOMEvent("ps-x-reach-start"));
  }
  var i = psInstances.get(element);
  if (axis === "top" && value >= i.contentHeight - i.containerHeight) {
    value = i.contentHeight - i.containerHeight;
    if (value - element.scrollTop <= 2) {
      value = element.scrollTop;
    } else {
      element.scrollTop = value;
    }
    element.dispatchEvent(createDOMEvent("ps-y-reach-end"));
  }
  if (axis === "left" && value >= i.contentWidth - i.containerWidth) {
    value = i.contentWidth - i.containerWidth;
    if (value - element.scrollLeft <= 2) {
      value = element.scrollLeft;
    } else {
      element.scrollLeft = value;
    }
    element.dispatchEvent(createDOMEvent("ps-x-reach-end"));
  }
  if (i.lastTop === void 0) {
    i.lastTop = element.scrollTop;
  }
  if (i.lastLeft === void 0) {
    i.lastLeft = element.scrollLeft;
  }
  if (axis === "top" && value < i.lastTop) {
    element.dispatchEvent(createDOMEvent("ps-scroll-up"));
  }
  if (axis === "top" && value > i.lastTop) {
    element.dispatchEvent(createDOMEvent("ps-scroll-down"));
  }
  if (axis === "left" && value < i.lastLeft) {
    element.dispatchEvent(createDOMEvent("ps-scroll-left"));
  }
  if (axis === "left" && value > i.lastLeft) {
    element.dispatchEvent(createDOMEvent("ps-scroll-right"));
  }
  if (axis === "top" && value !== i.lastTop) {
    element.scrollTop = i.lastTop = value;
    element.dispatchEvent(createDOMEvent("ps-scroll-y"));
  }
  if (axis === "left" && value !== i.lastLeft) {
    element.scrollLeft = i.lastLeft = value;
    element.dispatchEvent(createDOMEvent("ps-scroll-x"));
  }
}
function getThumbSize(i, thumbSize) {
  if (i.settings.minScrollbarLength) {
    thumbSize = Math.max(thumbSize, i.settings.minScrollbarLength);
  }
  if (i.settings.maxScrollbarLength) {
    thumbSize = Math.min(thumbSize, i.settings.maxScrollbarLength);
  }
  return thumbSize;
}
function updateCss(element, i) {
  var xRailOffset = { width: i.railXWidth };
  if (i.isRtl) {
    xRailOffset.left = i.negativeScrollAdjustment + element.scrollLeft + i.containerWidth - i.contentWidth;
  } else {
    xRailOffset.left = element.scrollLeft;
  }
  if (i.isScrollbarXUsingBottom) {
    xRailOffset.bottom = i.scrollbarXBottom - element.scrollTop;
  } else {
    xRailOffset.top = i.scrollbarXTop + element.scrollTop;
  }
  if (i.customScrollbar && i.settings.processXRailOffset) {
    xRailOffset = i.settings.processXRailOffset.call(i, xRailOffset);
  }
  DOM.css(i.scrollbarXRail, xRailOffset);
  var yRailOffset = { top: element.scrollTop, height: i.railYHeight };
  if (i.isScrollbarYUsingRight) {
    if (i.isRtl) {
      yRailOffset.right = i.contentWidth - (i.negativeScrollAdjustment + element.scrollLeft) - i.scrollbarYRight - i.scrollbarYOuterWidth;
    } else {
      yRailOffset.right = i.scrollbarYRight - element.scrollLeft;
    }
  } else {
    if (i.isRtl) {
      yRailOffset.left = i.negativeScrollAdjustment + element.scrollLeft + i.containerWidth * 2 - i.contentWidth - i.scrollbarYLeft - i.scrollbarYOuterWidth;
    } else {
      yRailOffset.left = i.scrollbarYLeft + element.scrollLeft;
    }
  }
  if (i.customScrollbar && i.settings.processYRailOffset) {
    yRailOffset = i.settings.processYRailOffset.call(i, yRailOffset);
  }
  DOM.css(i.scrollbarYRail, yRailOffset);
  var scrollbarXOffset = { left: i.scrollbarXLeft, width: i.scrollbarXWidth - i.railBorderXWidth };
  var scrollbarYOffset = { top: i.scrollbarYTop, height: i.scrollbarYHeight - i.railBorderYWidth };
  if (i.customScrollbar && i.settings.processScrollbarXOffset) {
    scrollbarXOffset = i.settings.processScrollbarXOffset.call(i, scrollbarXOffset);
  }
  if (i.customScrollbar && i.settings.processScrollbarYOffset) {
    scrollbarYOffset = i.settings.processScrollbarYOffset.call(i, yRailOffset);
  }
  DOM.css(i.scrollbarX, scrollbarXOffset);
  DOM.css(i.scrollbarY, scrollbarYOffset);
}
function updateGeometry(element) {
  var i = psInstances.get(element);
  i.containerWidth = element.clientWidth;
  i.containerHeight = element.clientHeight;
  i.contentWidth = element.scrollWidth;
  i.contentHeight = element.scrollHeight;
  if (!i.settings.suppressScrollX && i.containerWidth + i.settings.scrollXMarginOffset < i.contentWidth) {
    i.scrollbarXActive = true;
    i.railXWidth = i.containerWidth - i.railXMarginWidth;
    i.railXRatio = i.containerWidth / i.railXWidth;
    i.scrollbarXWidth = getThumbSize(i, _.toInt(i.railXWidth * i.containerWidth / i.contentWidth));
    i.scrollbarXLeft = _.toInt(
      (i.negativeScrollAdjustment + element.scrollLeft) * (i.railXWidth - i.scrollbarXWidth) / (i.contentWidth - i.containerWidth)
    );
  } else {
    i.scrollbarXActive = false;
  }
  if (!i.settings.suppressScrollY && i.containerHeight + i.settings.scrollYMarginOffset < i.contentHeight) {
    i.scrollbarYActive = true;
    i.railYHeight = i.containerHeight - i.railYMarginHeight;
    i.railYRatio = i.containerHeight / i.railYHeight;
    i.scrollbarYHeight = getThumbSize(i, _.toInt(i.railYHeight * i.containerHeight / i.contentHeight));
    i.scrollbarYTop = _.toInt(
      element.scrollTop * (i.railYHeight - i.scrollbarYHeight) / (i.contentHeight - i.containerHeight)
    );
  } else {
    i.scrollbarYActive = false;
  }
  if (i.scrollbarXLeft >= i.railXWidth - i.scrollbarXWidth) {
    i.scrollbarXLeft = i.railXWidth - i.scrollbarXWidth;
  }
  if (i.scrollbarYTop >= i.railYHeight - i.scrollbarYHeight) {
    i.scrollbarYTop = i.railYHeight - i.scrollbarYHeight;
  }
  updateCss(element, i);
  if (i.scrollbarXActive) {
    element.classList.add("ps--active-x");
    if (i.customScrollbar) {
      i.scrollbarContainer.classList.add("ps--active-x");
    }
  } else {
    element.classList.remove("ps--active-x");
    if (i.customScrollbar) {
      i.scrollbarContainer.classList.remove("ps--active-x");
    }
    i.scrollbarXWidth = 0;
    i.scrollbarXLeft = 0;
    updateScroll(element, "left", 0);
  }
  if (i.scrollbarYActive) {
    element.classList.add("ps--active-y");
    if (i.customScrollbar) {
      i.scrollbarContainer.classList.add("ps--active-y");
    }
  } else {
    element.classList.remove("ps--active-y");
    if (i.customScrollbar) {
      i.scrollbarContainer.classList.remove("ps--active-y");
    }
    i.scrollbarYHeight = 0;
    i.scrollbarYTop = 0;
    updateScroll(element, "top", 0);
  }
}
function bindClickRailHandler(element, i) {
  function pageOffset(el) {
    return el.getBoundingClientRect();
  }
  var stopPropagation = function(e) {
    e.stopPropagation();
  };
  i.event.bind(i.scrollbarY, "click", stopPropagation);
  i.event.bind(i.scrollbarYRail, "click", function(e) {
    var positionTop = e.pageY - window.pageYOffset - pageOffset(i.scrollbarYRail).top;
    var direction = positionTop > i.scrollbarYTop ? 1 : -1;
    updateScroll(element, "top", element.scrollTop + direction * i.containerHeight);
    updateGeometry(element);
    e.stopPropagation();
  });
  i.event.bind(i.scrollbarX, "click", stopPropagation);
  i.event.bind(i.scrollbarXRail, "click", function(e) {
    var positionLeft = e.pageX - window.pageXOffset - pageOffset(i.scrollbarXRail).left;
    var direction = positionLeft > i.scrollbarXLeft ? 1 : -1;
    updateScroll(element, "left", element.scrollLeft + direction * i.containerWidth);
    updateGeometry(element);
    e.stopPropagation();
  });
}
function clickRail(element) {
  var i = psInstances.get(element);
  bindClickRailHandler(element, i);
}
function bindMouseScrollXHandler(element, i) {
  var currentLeft = null;
  var currentPageX = null;
  function updateScrollLeft(deltaX) {
    var newLeft = currentLeft + deltaX * i.railXRatio;
    var maxLeft = Math.max(0, i.scrollbarXRail.getBoundingClientRect().left) + i.railXRatio * (i.railXWidth - i.scrollbarXWidth);
    if (newLeft < 0) {
      i.scrollbarXLeft = 0;
    } else if (newLeft > maxLeft) {
      i.scrollbarXLeft = maxLeft;
    } else {
      i.scrollbarXLeft = newLeft;
    }
    var scrollLeft = _.toInt(
      i.scrollbarXLeft * (i.contentWidth - i.containerWidth) / (i.containerWidth - i.railXRatio * i.scrollbarXWidth)
    ) - i.negativeScrollAdjustment;
    updateScroll(element, "left", scrollLeft);
  }
  var mouseMoveHandler = function(e) {
    updateScrollLeft(e.pageX - currentPageX);
    updateGeometry(element);
    e.stopPropagation();
    e.preventDefault();
  };
  var mouseUpHandler = function() {
    _.stopScrolling(element, "x");
    if (i.customScrollbar) {
      _.stopScrolling(i.scrollbarContainer, "x");
    }
    i.event.unbind(i.ownerDocument, "mousemove", mouseMoveHandler);
  };
  i.event.bind(i.scrollbarX, "mousedown", function(e) {
    currentPageX = e.pageX;
    currentLeft = _.toInt(DOM.css(i.scrollbarX, "left")) * i.railXRatio;
    _.startScrolling(element, "x");
    if (i.customScrollbar) {
      _.startScrolling(i.scrollbarContainer, "x");
    }
    i.event.bind(i.ownerDocument, "mousemove", mouseMoveHandler);
    i.event.once(i.ownerDocument, "mouseup", mouseUpHandler);
    e.stopPropagation();
    e.preventDefault();
  });
}
function bindMouseScrollYHandler(element, i) {
  var currentTop = null;
  var currentPageY = null;
  function updateScrollTop(deltaY) {
    var newTop = currentTop + deltaY * i.railYRatio;
    var maxTop = Math.max(0, i.scrollbarYRail.getBoundingClientRect().top) + i.railYRatio * (i.railYHeight - i.scrollbarYHeight);
    if (newTop < 0) {
      i.scrollbarYTop = 0;
    } else if (newTop > maxTop) {
      i.scrollbarYTop = maxTop;
    } else {
      i.scrollbarYTop = newTop;
    }
    var scrollTop = _.toInt(
      i.scrollbarYTop * (i.contentHeight - i.containerHeight) / (i.containerHeight - i.railYRatio * i.scrollbarYHeight)
    );
    updateScroll(element, "top", scrollTop);
  }
  var mouseMoveHandler = function(e) {
    updateScrollTop(e.pageY - currentPageY);
    updateGeometry(element);
    e.stopPropagation();
    e.preventDefault();
  };
  var mouseUpHandler = function() {
    _.stopScrolling(element, "y");
    if (i.customScrollbar) {
      _.stopScrolling(i.scrollbarContainer, "y");
    }
    i.event.unbind(i.ownerDocument, "mousemove", mouseMoveHandler);
  };
  i.event.bind(i.scrollbarY, "mousedown", function(e) {
    currentPageY = e.pageY;
    currentTop = _.toInt(DOM.css(i.scrollbarY, "top")) * i.railYRatio;
    _.startScrolling(element, "y");
    if (i.customScrollbar) {
      _.startScrolling(i.scrollbarContainer, "y");
    }
    i.event.bind(i.ownerDocument, "mousemove", mouseMoveHandler);
    i.event.once(i.ownerDocument, "mouseup", mouseUpHandler);
    e.stopPropagation();
    e.preventDefault();
  });
}
function dragScrollbar(element) {
  var i = psInstances.get(element);
  bindMouseScrollXHandler(element, i);
  bindMouseScrollYHandler(element, i);
}
function bindKeyboardHandler(element, i) {
  var hovered = false;
  i.event.bind(element, "mouseenter", function() {
    hovered = true;
  });
  i.event.bind(element, "mouseleave", function() {
    hovered = false;
  });
  var shouldPrevent = false;
  function shouldPreventDefault(deltaX, deltaY) {
    var scrollTop = element.scrollTop;
    if (deltaX === 0) {
      if (!i.scrollbarYActive) {
        return false;
      }
      if (scrollTop === 0 && deltaY > 0 || scrollTop >= i.contentHeight - i.containerHeight && deltaY < 0) {
        return !i.settings.wheelPropagation;
      }
    }
    var scrollLeft = element.scrollLeft;
    if (deltaY === 0) {
      if (!i.scrollbarXActive) {
        return false;
      }
      if (scrollLeft === 0 && deltaX < 0 || scrollLeft >= i.contentWidth - i.containerWidth && deltaX > 0) {
        return !i.settings.wheelPropagation;
      }
    }
    return true;
  }
  i.event.bind(i.ownerDocument, "keydown", function(e) {
    if (e.isDefaultPrevented && e.isDefaultPrevented() || e.defaultPrevented) {
      return;
    }
    var focused = DOM.matches(i.scrollbarX, ":focus") || DOM.matches(i.scrollbarY, ":focus");
    if (!hovered && !focused) {
      return;
    }
    var activeElement = document.activeElement ? document.activeElement : i.ownerDocument.activeElement;
    if (activeElement) {
      if (activeElement.tagName === "IFRAME") {
        activeElement = activeElement.contentDocument.activeElement;
      } else {
        while (activeElement.shadowRoot) {
          activeElement = activeElement.shadowRoot.activeElement;
        }
      }
      if (_.isEditable(activeElement)) {
        return;
      }
    }
    var deltaX = 0;
    var deltaY = 0;
    switch (e.which) {
      case 37:
        if (e.metaKey) {
          deltaX = -i.contentWidth;
        } else if (e.altKey) {
          deltaX = -i.containerWidth;
        } else {
          deltaX = -30;
        }
        break;
      case 38:
        if (e.metaKey) {
          deltaY = i.contentHeight;
        } else if (e.altKey) {
          deltaY = i.containerHeight;
        } else {
          deltaY = 30;
        }
        break;
      case 39:
        if (e.metaKey) {
          deltaX = i.contentWidth;
        } else if (e.altKey) {
          deltaX = i.containerWidth;
        } else {
          deltaX = 30;
        }
        break;
      case 40:
        if (e.metaKey) {
          deltaY = -i.contentHeight;
        } else if (e.altKey) {
          deltaY = -i.containerHeight;
        } else {
          deltaY = -30;
        }
        break;
      case 33:
        deltaY = 90;
        break;
      case 32:
        if (e.shiftKey) {
          deltaY = 90;
        } else {
          deltaY = -90;
        }
        break;
      case 34:
        deltaY = -90;
        break;
      case 35:
        if (e.ctrlKey) {
          deltaY = -i.contentHeight;
        } else {
          deltaY = -i.containerHeight;
        }
        break;
      case 36:
        if (e.ctrlKey) {
          deltaY = element.scrollTop;
        } else {
          deltaY = i.containerHeight;
        }
        break;
      default:
        return;
    }
    updateScroll(element, "top", element.scrollTop - deltaY);
    updateScroll(element, "left", element.scrollLeft + deltaX);
    updateGeometry(element);
    shouldPrevent = shouldPreventDefault(deltaX, deltaY);
    if (shouldPrevent) {
      e.preventDefault();
    }
  });
}
function keyboard(element) {
  var i = psInstances.get(element);
  bindKeyboardHandler(element, i);
}
function bindMouseWheelHandler(element, i) {
  var shouldPrevent = false;
  function shouldPreventDefault(deltaX, deltaY) {
    var scrollTop = element.scrollTop;
    if (deltaX === 0) {
      if (!i.scrollbarYActive) {
        return false;
      }
      if (scrollTop === 0 && deltaY > 0 || scrollTop >= i.contentHeight - i.containerHeight && deltaY < 0) {
        return !i.settings.wheelPropagation;
      }
    }
    var scrollLeft = element.scrollLeft;
    if (deltaY === 0) {
      if (!i.scrollbarXActive) {
        return false;
      }
      if (scrollLeft === 0 && deltaX < 0 || scrollLeft >= i.contentWidth - i.containerWidth && deltaX > 0) {
        return !i.settings.wheelPropagation;
      }
    }
    return true;
  }
  function getDeltaFromEvent(e) {
    var deltaX = e.deltaX;
    var deltaY = -1 * e.deltaY;
    if (typeof deltaX === "undefined" || typeof deltaY === "undefined") {
      deltaX = -1 * e.wheelDeltaX / 6;
      deltaY = e.wheelDeltaY / 6;
    }
    if (e.deltaMode && e.deltaMode === 1) {
      deltaX *= 10;
      deltaY *= 10;
    }
    if (deltaX !== deltaX && deltaY !== deltaY) {
      deltaX = 0;
      deltaY = e.wheelDelta;
    }
    if (e.shiftKey) {
      return [-deltaY, -deltaX];
    }
    return [deltaX, deltaY];
  }
  function shouldBeConsumedByChild(deltaX, deltaY) {
    var child = element.querySelector("textarea:hover, select[multiple]:hover, .ps-child:hover");
    if (child) {
      var style = window.getComputedStyle(child);
      var overflow = [style.overflow, style.overflowX, style.overflowY].join("");
      if (!overflow.match(/(scroll|auto)/)) {
        return false;
      }
      var maxScrollTop = child.scrollHeight - child.clientHeight;
      if (maxScrollTop > 0) {
        if (!(child.scrollTop === 0 && deltaY > 0) && !(child.scrollTop === maxScrollTop && deltaY < 0)) {
          return true;
        }
      }
      var maxScrollLeft = child.scrollLeft - child.clientWidth;
      if (maxScrollLeft > 0) {
        if (!(child.scrollLeft === 0 && deltaX < 0) && !(child.scrollLeft === maxScrollLeft && deltaX > 0)) {
          return true;
        }
      }
    }
    return false;
  }
  function mousewheelHandler(e) {
    var delta = getDeltaFromEvent(e);
    var deltaX = delta[0];
    var deltaY = delta[1];
    if (shouldBeConsumedByChild(deltaX, deltaY)) {
      return;
    }
    shouldPrevent = false;
    if (!i.settings.useBothWheelAxes) {
      updateScroll(element, "top", element.scrollTop - deltaY * i.settings.wheelSpeed);
      updateScroll(element, "left", element.scrollLeft + deltaX * i.settings.wheelSpeed);
    } else if (i.scrollbarYActive && !i.scrollbarXActive) {
      if (deltaY) {
        updateScroll(element, "top", element.scrollTop - deltaY * i.settings.wheelSpeed);
      } else {
        updateScroll(element, "top", element.scrollTop + deltaX * i.settings.wheelSpeed);
      }
      shouldPrevent = true;
    } else if (i.scrollbarXActive && !i.scrollbarYActive) {
      if (deltaX) {
        updateScroll(element, "left", element.scrollLeft + deltaX * i.settings.wheelSpeed);
      } else {
        updateScroll(element, "left", element.scrollLeft - deltaY * i.settings.wheelSpeed);
      }
      shouldPrevent = true;
    }
    updateGeometry(element);
    shouldPrevent = shouldPrevent || shouldPreventDefault(deltaX, deltaY);
    if (shouldPrevent) {
      e.stopPropagation();
      e.preventDefault();
    }
  }
  if (typeof window.onwheel !== "undefined") {
    i.event.bind(element, "wheel", mousewheelHandler);
  } else if (typeof window.onmousewheel !== "undefined") {
    i.event.bind(element, "mousewheel", mousewheelHandler);
  }
}
function wheel(element) {
  var i = psInstances.get(element);
  bindMouseWheelHandler(element, i);
}
function bindTouchHandler(element, i, supportsTouch, supportsIePointer) {
  function shouldPreventDefault(deltaX, deltaY) {
    var scrollTop = element.scrollTop;
    var scrollLeft = element.scrollLeft;
    var magnitudeX = Math.abs(deltaX);
    var magnitudeY = Math.abs(deltaY);
    if (magnitudeY > magnitudeX) {
      if (deltaY < 0 && scrollTop === i.contentHeight - i.containerHeight || deltaY > 0 && scrollTop === 0) {
        return !i.settings.swipePropagation;
      }
    } else if (magnitudeX > magnitudeY) {
      if (deltaX < 0 && scrollLeft === i.contentWidth - i.containerWidth || deltaX > 0 && scrollLeft === 0) {
        return !i.settings.swipePropagation;
      }
    }
    return true;
  }
  function applyTouchMove(differenceX, differenceY) {
    updateScroll(element, "top", element.scrollTop - differenceY);
    updateScroll(element, "left", element.scrollLeft - differenceX);
    updateGeometry(element);
  }
  var startOffset = {};
  var startTime = 0;
  var speed = {};
  var easingLoop = null;
  var inGlobalTouch = false;
  var inLocalTouch = false;
  function globalTouchStart() {
    inGlobalTouch = true;
  }
  function globalTouchEnd() {
    inGlobalTouch = false;
  }
  function getTouch(e) {
    if (e.targetTouches) {
      return e.targetTouches[0];
    } else {
      return e;
    }
  }
  function shouldHandle(e) {
    if (e.targetTouches && e.targetTouches.length === 1) {
      return true;
    }
    if (e.pointerType && e.pointerType !== "mouse" && e.pointerType !== e.MSPOINTER_TYPE_MOUSE) {
      return true;
    }
    return false;
  }
  function touchStart(e) {
    if (shouldHandle(e)) {
      inLocalTouch = true;
      var touch2 = getTouch(e);
      startOffset.pageX = touch2.pageX;
      startOffset.pageY = touch2.pageY;
      startTime = new Date().getTime();
      if (easingLoop !== null) {
        clearInterval(easingLoop);
      }
      e.stopPropagation();
    }
  }
  function touchMove(e) {
    if (!inLocalTouch && i.settings.swipePropagation) {
      touchStart(e);
    }
    if (!inGlobalTouch && inLocalTouch && shouldHandle(e)) {
      var touch2 = getTouch(e);
      var currentOffset = { pageX: touch2.pageX, pageY: touch2.pageY };
      var differenceX = currentOffset.pageX - startOffset.pageX;
      var differenceY = currentOffset.pageY - startOffset.pageY;
      applyTouchMove(differenceX, differenceY);
      startOffset = currentOffset;
      var currentTime = new Date().getTime();
      var timeGap = currentTime - startTime;
      if (timeGap > 0) {
        speed.x = differenceX / timeGap;
        speed.y = differenceY / timeGap;
        startTime = currentTime;
      }
      if (shouldPreventDefault(differenceX, differenceY)) {
        e.stopPropagation();
        e.preventDefault();
      }
    }
  }
  function touchEnd() {
    if (!inGlobalTouch && inLocalTouch) {
      inLocalTouch = false;
      if (i.settings.swipeEasing) {
        clearInterval(easingLoop);
        easingLoop = setInterval(function() {
          if (!psInstances.get(element)) {
            clearInterval(easingLoop);
            return;
          }
          if (!speed.x && !speed.y) {
            clearInterval(easingLoop);
            return;
          }
          if (Math.abs(speed.x) < 0.01 && Math.abs(speed.y) < 0.01) {
            clearInterval(easingLoop);
            return;
          }
          applyTouchMove(speed.x * 30, speed.y * 30);
          speed.x *= 0.8;
          speed.y *= 0.8;
        }, 10);
      }
    }
  }
  if (supportsTouch) {
    i.event.bind(window, "touchstart", globalTouchStart);
    i.event.bind(window, "touchend", globalTouchEnd);
    i.event.bind(element, "touchstart", touchStart);
    i.event.bind(element, "touchmove", touchMove);
    i.event.bind(element, "touchend", touchEnd);
  } else if (supportsIePointer) {
    if (window.PointerEvent) {
      i.event.bind(window, "pointerdown", globalTouchStart);
      i.event.bind(window, "pointerup", globalTouchEnd);
      i.event.bind(element, "pointerdown", touchStart);
      i.event.bind(element, "pointermove", touchMove);
      i.event.bind(element, "pointerup", touchEnd);
    } else if (window.MSPointerEvent) {
      i.event.bind(window, "MSPointerDown", globalTouchStart);
      i.event.bind(window, "MSPointerUp", globalTouchEnd);
      i.event.bind(element, "MSPointerDown", touchStart);
      i.event.bind(element, "MSPointerMove", touchMove);
      i.event.bind(element, "MSPointerUp", touchEnd);
    }
  }
}
function touch(element) {
  if (!_.env.supportsTouch && !_.env.supportsIePointer) {
    return;
  }
  var i = psInstances.get(element);
  bindTouchHandler(element, i, _.env.supportsTouch, _.env.supportsIePointer);
}
function bindSelectionHandler(element, i) {
  function getRangeNode() {
    var selection2 = window.getSelection ? window.getSelection() : document.getSelection ? document.getSelection() : "";
    if (selection2.toString().length === 0) {
      return null;
    } else {
      return selection2.getRangeAt(0).commonAncestorContainer;
    }
  }
  var scrollingLoop = null;
  var scrollDiff = { top: 0, left: 0 };
  function startScrolling2() {
    if (!scrollingLoop) {
      scrollingLoop = setInterval(function() {
        if (!psInstances.get(element)) {
          clearInterval(scrollingLoop);
          return;
        }
        updateScroll(element, "top", element.scrollTop + scrollDiff.top);
        updateScroll(element, "left", element.scrollLeft + scrollDiff.left);
        updateGeometry(element);
      }, 50);
    }
  }
  function stopScrolling2() {
    if (scrollingLoop) {
      clearInterval(scrollingLoop);
      scrollingLoop = null;
    }
    _.stopScrolling(element);
    if (i.customScrollbar) {
      _.stopScrolling(i.scrollbarContainer);
    }
  }
  var isSelected = false;
  i.event.bind(i.ownerDocument, "selectionchange", function() {
    if (element.contains(getRangeNode())) {
      isSelected = true;
    } else {
      isSelected = false;
      stopScrolling2();
    }
  });
  i.event.bind(window, "mouseup", function() {
    if (isSelected) {
      isSelected = false;
      stopScrolling2();
    }
  });
  i.event.bind(window, "keyup", function() {
    if (isSelected) {
      isSelected = false;
      stopScrolling2();
    }
  });
  i.event.bind(window, "mousemove", function(e) {
    if (isSelected) {
      var mousePosition = { x: e.pageX, y: e.pageY };
      var containerGeometry = {
        left: element.offsetLeft,
        right: element.offsetLeft + element.offsetWidth,
        top: element.offsetTop,
        bottom: element.offsetTop + element.offsetHeight
      };
      if (mousePosition.x < containerGeometry.left + 3) {
        scrollDiff.left = -5;
        _.startScrolling(element, "x");
        if (i.customScrollbar) {
          _.startScrolling(i.scrollbarContainer, "x");
        }
      } else if (mousePosition.x > containerGeometry.right - 3) {
        scrollDiff.left = 5;
        _.startScrolling(element, "x");
        if (i.customScrollbar) {
          _.startScrolling(i.scrollbarContainer, "x");
        }
      } else {
        scrollDiff.left = 0;
      }
      if (mousePosition.y < containerGeometry.top + 3) {
        if (containerGeometry.top + 3 - mousePosition.y < 5) {
          scrollDiff.top = -5;
        } else {
          scrollDiff.top = -20;
        }
        _.startScrolling(element, "y");
        if (i.customScrollbar) {
          _.startScrolling(i.scrollbarContainer, "y");
        }
      } else if (mousePosition.y > containerGeometry.bottom - 3) {
        if (mousePosition.y - containerGeometry.bottom + 3 < 5) {
          scrollDiff.top = 5;
        } else {
          scrollDiff.top = 20;
        }
        _.startScrolling(element, "y");
        if (i.customScrollbar) {
          _.startScrolling(i.scrollbarContainer, "y");
        }
      } else {
        scrollDiff.top = 0;
      }
      if (scrollDiff.top === 0 && scrollDiff.left === 0) {
        stopScrolling2();
      } else {
        startScrolling2();
      }
    }
  });
}
function selection(element) {
  var i = psInstances.get(element);
  bindSelectionHandler(element, i);
}
function bindNativeScrollHandler(element, i) {
  i.event.bind(element, "scroll", function() {
    updateGeometry(element);
  });
}
function nativeScrollHandler(element) {
  var i = psInstances.get(element);
  bindNativeScrollHandler(element, i);
}
var handlers = {
  "click-rail": clickRail,
  "drag-scrollbar": dragScrollbar,
  keyboard,
  wheel,
  touch,
  selection
};
function initialize(element, userSettings) {
  element.classList.add("ps");
  var scrollbarContainer = userSettings.scrollbarContainer;
  if (scrollbarContainer) {
    var theme = userSettings.theme || defaultSettings.theme;
    if (theme) {
      scrollbarContainer.classList.add("ps--theme_" + theme);
    }
    scrollbarContainer.classList.add("ps--custom-scrollbar");
    scrollbarContainer.classList.add("ps");
  }
  var i = psInstances.add(element, typeof userSettings === "object" ? userSettings : {});
  if (i.settings.theme) {
    element.classList.add("ps--theme_" + i.settings.theme);
  }
  i.settings.handlers.forEach(function(handlerName) {
    handlers[handlerName](element);
  });
  nativeScrollHandler(element);
  updateGeometry(element);
}
function update(element) {
  var i = psInstances.get(element);
  if (!i) {
    return;
  }
  i.negativeScrollAdjustment = i.isNegativeScroll ? element.scrollWidth - element.clientWidth : 0;
  DOM.css(i.scrollbarXRail, "display", "block");
  DOM.css(i.scrollbarYRail, "display", "block");
  i.railXMarginWidth = _.toInt(DOM.css(i.scrollbarXRail, "marginLeft")) + _.toInt(DOM.css(i.scrollbarXRail, "marginRight"));
  i.railYMarginHeight = _.toInt(DOM.css(i.scrollbarYRail, "marginTop")) + _.toInt(DOM.css(i.scrollbarYRail, "marginBottom"));
  DOM.css(i.scrollbarXRail, "display", "none");
  DOM.css(i.scrollbarYRail, "display", "none");
  updateGeometry(element);
  updateScroll(element, "top", element.scrollTop);
  updateScroll(element, "left", element.scrollLeft);
  DOM.css(i.scrollbarXRail, "display", "");
  DOM.css(i.scrollbarYRail, "display", "");
}
var ps = {
  initialize,
  update,
  destroy
};
function fixscrollbar(settingOrCommand) {
  return this.each(function() {
    if (typeof settingOrCommand === "object" || typeof settingOrCommand === "undefined") {
      const settings = settingOrCommand;
      if (!psInstances.get(this)) {
        ps.initialize(this, settings);
      }
    } else {
      const command = settingOrCommand;
      if (command === "update") {
        ps.update(this);
      } else if (command === "destroy") {
        ps.destroy(this);
      }
    }
  });
}
export { fixscrollbar };
