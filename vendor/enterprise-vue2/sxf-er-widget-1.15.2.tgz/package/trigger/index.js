import $ from 'jquery';
import { getPrefixedClassName } from '@sxf/er-feature';
import { globalConfig } from '@sxf/er-config';
import format from '@sxf/er-utils/format';
const ICON_CLS = {
  date: "vtv-icon-calendar",
  time: "vtv-icon-time",
  window: "vtv-icon-menu-more",
  browser: "vtv-icon-file-expand",
  search: "vtv-icon-search",
  list: "vtv-icon-view-list"
};
const WRAP_CLS = "v-trigger-field";
const PREFIXED_WRAP_CLS = () => getPrefixedClassName(WRAP_CLS);
const INPUT_CLS = "v-trigger-field-input";
const PREFIXED_INPUT_CLS = () => getPrefixedClassName(INPUT_CLS);
const TRIGGER_CLS = "v-trigger-field-ghost";
const PREFIXED_TRIGGER_CLS = () => getPrefixedClassName(TRIGGER_CLS);
function fixtrigger(callback) {
  const argType = typeof (callback || void 0);
  this.each(function() {
    const node = $(this);
    switch (argType) {
      case "string":
        if (callback === "destroy") {
          destroy(node);
        }
        if ($.inArray(callback, ["loading", "end-loading"]) > -1) {
          setNodeStatus(node, callback);
        }
        break;
      case "function":
      case "undefined":
        init(node, callback);
        break;
    }
  });
  return this;
}
function init(node, fn) {
  if (node.data("wrapped")) {
    return;
  }
  const triggerType = node.attr("trigger-type");
  const typeCls = ICON_CLS[triggerType] || "";
  const triggerCls = [PREFIXED_TRIGGER_CLS()].concat(typeCls ? ["iconfont", typeCls] : []).join(" ");
  node.addClass(PREFIXED_INPUT_CLS()).data("wrapped", 1).wrapAll(function() {
    const styles = [];
    ["margin-left", "margin-right", "margin-top", "margin-bottom"].forEach(function(key) {
      styles.push(key + ":" + node.css(key));
    });
    return "<span class='" + PREFIXED_WRAP_CLS() + "' style='" + styles.join(";") + "'></span>";
  }).after('<button type="button" class="' + triggerCls + '"></button>');
  if (fn) {
    node.closest("." + WRAP_CLS).bind("click", function(evt) {
      if (node.is(":disabled")) {
        return null;
      }
      if (node.prop("readonly") || $(evt.target).is("." + TRIGGER_CLS)) {
        fn.apply(node[0], arguments);
      }
      if (node.prop("readonly")) {
        node.blur();
      }
    });
  }
}
function destroy(node) {
  if (!node.data("wrapped")) {
    return;
  }
  node.closest("." + WRAP_CLS).unbind("click").remove();
  node.removeData("wrapped").unwrap();
}
function setNodeStatus(node, status) {
  if (!node.data("wrapped")) {
    return;
  }
  switch (status) {
    case "loading":
      node.attr("disabled", "disabled").next().addClass("loading");
      break;
    case "end-loading":
      node.removeAttr("disabled", "disabled").next().removeClass("loading");
      break;
  }
}
function setInputLimit($el, options) {
  var _a, _b, _c, _d;
  options = Object.assign(
    {
      useUTF8Len: (_b = (_a = globalConfig.search) == null ? void 0 : _a.useUTF8Len) != null ? _b : true,
      limit: (_d = (_c = globalConfig.search) == null ? void 0 : _c.limit) != null ? _d : 100
    },
    options
  );
  $el.off("input.input-limit").on("input.input-limit", function() {
    const value = $el.val();
    const limit = options.limit;
    let len = value.length;
    if (limit) {
      if (options.useUTF8Len) {
        len = format.utf8Length(value);
      }
      if (len > limit) {
        $el.val(format.limitString(value, limit, options.useUTF8Len));
      }
    }
  });
}
function searchInputLimit(options = {}) {
  setInputLimit.call(this, this, options);
  return this;
}
export { fixtrigger, searchInputLimit };
