import $ from 'jquery';
import { $i, globalConfig } from '@sxf/er-config';
import { getPrefixedClassName } from '@sxf/er-feature';
import apply from '@sxf/er-utils/apply';
import lang from '@sxf/er-utils/lang';
import { getScrollWidth, getScrollParent } from '@sxf/er-utils/dom';
import { isInstanceofAjax, ajax } from '@sxf/er-utils/ajax';
import format from '@sxf/er-utils/format';
import string from '@sxf/er-utils/string';
import { when } from '@sxf/er-utils/when';
import { setInputLimit } from '@sxf/er-widget/_private/inputLimit';
var defs = {
  itemCls: "list-item",
  focusCls: "focus"
};
const ALL_OPTION_CHECK_STATUS = {
  ALL: "all",
  PART: "part",
  NONE: "none"
};
const ALL_OPTION = {
  id: "_sf_select_all_id"
};
const PREFIX_TYPE = {
  image: "image",
  icon: "icon"
};
const SELECT_ITEM_TIP_CLS = "select-option-tip";
const extractOptionsData = function(el) {
  const data = [];
  el.children("option").each(function(i, opt) {
    opt = $(opt);
    const obj = {
      disabled: !!opt.attr("disabled"),
      text: opt.text().trim(),
      value: opt.attr("value")
    };
    if (opt.attr("selected")) {
      obj.selected = 1;
    }
    data.push(obj);
  });
  return data;
};
const extractOptgroupData = function(el) {
  const data = [];
  el.children("optgroup").each(function(i, grp) {
    const group2 = $(grp);
    const subData = extractOptionsData(group2);
    subData.gindex = i;
    data.push({
      label: group2.attr("label"),
      options: subData
    });
  });
  return data;
};
function createOptionPrefix(path, type) {
  return type === PREFIX_TYPE.image ? `<img src="${path}" class="select-list-item-prefix" />` : `<i class="${path}"></i>`;
}
const parseOptionsHtml = function(wrap, options) {
  const opt = options.initOptions;
  const selectLimit = opt.selectLimit;
  const itemCls = ["unselectable", getPrefixedClassName(defs.itemCls), opt.listItemCls || ""].join(" ");
  const renderer = opt.renderer;
  let html = "";
  const values = toMap(options.value);
  const unCheckedNeedDisabled = lang.isNumber(selectLimit) && Object.keys(values).length >= selectLimit;
  const unCheckedNeedDisabledTip = string.format(opt.selectLimitText, selectLimit);
  $.each(options.records, function(i, d) {
    var _a, _b;
    const multipleDisabledOthers = !values[d.value] && unCheckedNeedDisabled;
    const tip = d.tip || (multipleDisabledOthers ? unCheckedNeedDisabledTip : "");
    const isShowPrefix = ((_a = d.json) == null ? void 0 : _a.prefix) && ((_b = d.json) == null ? void 0 : _b.prefixType);
    html += `<li class="${itemCls} ${d.disabled || multipleDisabledOthers ? getPrefixedClassName("disabled") : ""} ${isShowPrefix ? getPrefixedClassName("list-item_prefix") : ""}"
          data-value="${format.htmlEncode(d.value)}"
          data-idx="${i}"
          data-tip="${tip}"
          data-hint-offsets="${opt.tipOffsetX}, ${opt.tipOffsetY}"
          data-hint-cls="${SELECT_ITEM_TIP_CLS}"
          ${values[d.value] ? "checked" : ""}>
        ${isShowPrefix ? createOptionPrefix(d.json.prefix, d.json.prefixType) : ""}
        ${renderer ? renderer(d.text, d, opt) : format.htmlTextEncode(d.text)}
      </li>`;
  });
  if (html && opt.multiple && opt.showCheckAll) {
    const checkAllStatus = wrap.data("checkAllStatus");
    const allOptionsDisabled = options.records.every((record) => record.disabled);
    const checkAllOptionData = {
      value: checkAllStatus,
      text: opt.checkAllLabel,
      id: ALL_OPTION.id
    };
    html = `<li class="${itemCls} ${allOptionsDisabled ? getPrefixedClassName("disabled") : ""}"
        data-value="${checkAllOptionData.value}"
        data-idx="${checkAllOptionData.id}"
        data-check-status=${checkAllStatus}>
        ${format.htmlTextEncode(checkAllOptionData.text)}
    </li>` + html;
  }
  return html;
};
const parseOptgroupHtml = function(wrap, options) {
  const opt = options.initOptions;
  const selectLimit = opt.selectLimit;
  const itemCls = ["unselectable", getPrefixedClassName(defs.itemCls), opt.listItemCls || ""].join(" ");
  const values = toMap(options.value);
  const renderer = opt.renderer;
  let html = "";
  const unCheckedNeedDisabled = lang.isNumber(selectLimit) && Object.keys(values).length >= selectLimit;
  const unCheckedNeedDisabledTip = string.format(opt.selectLimitText, selectLimit);
  const hasGroupTitle = options.records.some((item) => item.label);
  $.each(options.records, function(gi, rd) {
    const title = rd.label ? `<h3 class='unselectable ${getPrefixedClassName("select-group-item-title")}'>${rd.label}</h3>` : "";
    const className = `${getPrefixedClassName("select-group-item")} ${!hasGroupTitle && getPrefixedClassName("select-group-item--no-title")} ${opt.showCheckAll && gi === 0 && getPrefixedClassName("select-group-item-group-all")}`;
    html += `<li class='${className}'>` + title + "<ul>";
    $.each(rd.options, function(i, d) {
      var _a, _b;
      const multipleDisabledOthers = !values[d.value] && unCheckedNeedDisabled;
      const tip = d.tip || (multipleDisabledOthers ? unCheckedNeedDisabledTip : "");
      const isShowPrefix = ((_a = d.json) == null ? void 0 : _a.prefix) && ((_b = d.json) == null ? void 0 : _b.prefixType);
      html += `<li class="${itemCls} ${d.disabled || multipleDisabledOthers ? getPrefixedClassName("disabled") : ""} ${isShowPrefix ? getPrefixedClassName("list-item_prefix") : ""}"
            data-idx="${i}"
            data-gidx="${gi}"
            data-value="${d.value}"
            data-tip="${tip}"
            data-hint-offsets="${opt.tipOffsetX}, ${opt.tipOffsetY}"
            ${values[d.value] ? " checked" : ""}>
            ${isShowPrefix ? createOptionPrefix(d.json.prefix, d.json.prefixType) : ""}
            ${renderer ? renderer(d.text, d, opt) : format.htmlTextEncode(d.text)}
        </li>`;
    });
    html += "</ul></li>";
  });
  if (html && opt.multiple && opt.showCheckAll) {
    const checkAllStatus = getAllSelectionStatus(options);
    const allOptionsDisabled = options.records.every(
      (record) => record.options ? record.options.every((option) => option.disabled) : record.disabled
    );
    const checkAllOptionData = {
      value: checkAllStatus,
      text: opt.checkAllLabel,
      id: ALL_OPTION.id
    };
    html = `<li class="${itemCls} ${allOptionsDisabled ? getPrefixedClassName("disabled") : ""}"
        data-value="${checkAllOptionData.value}"
        data-idx="${checkAllOptionData.id}"
        data-check-status="${checkAllStatus}">
        ${format.htmlTextEncode(checkAllOptionData.text)}
    </li>` + html;
  }
  return html;
};
const extractData = function(options) {
  const select = options.target;
  const isGroup = !!select.children("optgroup").size();
  return isGroup ? extractOptgroupData(select) : extractOptionsData(select);
};
const parseHtml = function(wrap, options) {
  const isEmpty = options.isEmpty;
  if (isEmpty) {
    return `<div class="${getPrefixedClassName("sf-select-empty")}">${options.records}</div>`;
  }
  if (typeof options.records === "string") {
    return `<div class="${getPrefixedClassName("select-list-error-msg")}">${options.records}</div>`;
  }
  options.initOptions.isGroup = options.initOptions.groupBy || !!$("optgroup", wrap).size();
  return options.initOptions.isGroup ? parseOptgroupHtml(wrap, options) : parseOptionsHtml(wrap, options);
};
const exists$1 = function(v2) {
  return v2 !== void 0 && v2 !== null;
};
const escapeRegex = function(s) {
  return s.replace(/([\-.*+?\^${}()|\[\]\/\\])/g, "\\$1");
};
const group = function(records, cfg) {
  const rdMap = {};
  const unKnown = "$unknow";
  const field = cfg.field;
  const renderer = cfg.renderer;
  $.each(records, function(idx, rd) {
    const json = rd.json;
    let label = "";
    if (!json || !exists$1(json[field])) {
      label = unKnown;
    } else {
      label = json[field];
    }
    rdMap[label] = rdMap[label] || [];
    rdMap[label].push(rd);
  });
  const results = [];
  let hasUnknown = false;
  $.each(rdMap, function(k, v2) {
    const label = renderer(k, v2);
    if (label === false) {
      return;
    }
    const temp = {
      label,
      options: v2
    };
    if (k === unKnown) {
      hasUnknown = temp;
    } else {
      results.push(temp);
    }
  });
  if (hasUnknown) {
    results.push(hasUnknown);
  }
  return results;
};
function toMap(vs) {
  vs = vs || [];
  vs = Array.isArray(vs) ? vs : [vs];
  const map = {};
  $.each(vs, function(i, v2) {
    map[v2.value] = 1;
  });
  return map;
}
function scrollToLeft($elem) {
  const $wrap = $elem.parent();
  const opts = $wrap.data("options").initOptions || {};
  if (opts.editable) {
    return;
  }
  setTimeout(function() {
    if ($elem.get(0)) {
      $elem.get(0).scrollLeft = 0;
    }
  }, 0);
}
const val = function(elem) {
  const $elem = $(elem), args = $.makeArray(arguments).slice(1);
  let result;
  if ($elem.is("input, select")) {
    result = $elem.val.apply($elem, args);
    scrollToLeft($elem);
  } else {
    result = $elem.html.apply($elem, args);
  }
  const $wrap = $elem.parent();
  const opts = $wrap.data("options").initOptions || {};
  const targetEl = $wrap.data("options").target && $wrap.data("options").target[0];
  const elemTargetEl = $elem[0];
  const isSelectEl = elemTargetEl && targetEl && elemTargetEl !== targetEl;
  if (!opts.tip && isSelectEl) {
    const clientWidth = $elem.get(0).clientWidth;
    const scrollWidth = getScrollWidth($elem.get(0));
    if (args[0] && scrollWidth > clientWidth) {
      $wrap.attr("data-tip", filterNoHtmlText(args[0]));
      $wrap.attr("data-hint-pos", "r");
    } else {
      $wrap.removeAttr("data-tip");
    }
  }
  return result;
};
const groupBy = function(conf) {
  if (typeof v === "string") {
    conf = {
      field: conf,
      renderer: function(v2) {
        return v2;
      }
    };
  }
  return conf;
};
const isOpenMultipleCheckAll = function(options) {
  if (!options || !options.initOptions) {
    return false;
  }
  return options.initOptions.multiple && options.initOptions.showCheckAll;
};
function getAllSelectionStatus(options) {
  if (!options || !Array.isArray(options.records)) {
    return ALL_OPTION_CHECK_STATUS.NONE;
  }
  const normalRecords = [];
  const disabledRecordMap = {};
  const list = options.initOptions.isGroup ? options.records.map((item) => item.options).flat() : options.records;
  (list || []).forEach((rd) => {
    if (!rd.disabled) {
      normalRecords.push(rd);
    } else {
      disabledRecordMap[rd.value] = 1;
    }
  });
  const checkedValuesMap = (options.value || []).reduce((map, option) => {
    if (!option.disabled && !disabledRecordMap[option.value]) {
      map.set(option.value, option);
    }
    return map;
  }, /* @__PURE__ */ new Map());
  let checkedStatus = "";
  if (!checkedValuesMap.size) {
    checkedStatus = ALL_OPTION_CHECK_STATUS.NONE;
  } else {
    let allChecked = true;
    let someChecked = false;
    for (const normalRecord of normalRecords) {
      if (checkedValuesMap.has(normalRecord.value)) {
        someChecked = true;
      } else {
        allChecked = false;
      }
      if (someChecked && !allChecked) {
        break;
      }
    }
    if (allChecked) {
      checkedStatus = ALL_OPTION_CHECK_STATUS.ALL;
    } else if (someChecked) {
      checkedStatus = ALL_OPTION_CHECK_STATUS.PART;
    } else {
      checkedStatus = ALL_OPTION_CHECK_STATUS.NONE;
    }
  }
  return checkedStatus;
}
const filterNoHtmlText = (text) => {
  if (!text || typeof text !== "string") {
    return text;
  }
  return text.replace(/<\/?[^>]+(>|$)/g, "");
};
const loadByArray = (wrap, nextFn, params) => {
  const options = wrap.data("options");
  wrap.triggerHandler("data.beforeload");
  if (wrap.data("destroyed")) {
    return;
  }
  const json = {
    success: 1,
    data: params,
    _local_data: 1
  };
  loadFromAjax(wrap, json, options);
  wrap.data("loaded", true);
  wrap.triggerHandler("data.load", {
    options,
    records: options.records,
    json
  });
  if (nextFn) {
    nextFn(true);
  }
};
const loadByAjaxInstance = (wrap, nextFn, params) => {
  const options = wrap.data("options");
  wrap.triggerHandler("data.beforeload");
  wrap.data("loaded", false).data("loading", true);
  wrap.addClass(getPrefixedClassName("loading"));
  params.always(function(success, json) {
    if (wrap.data("destroyed")) {
      return;
    }
    loadFromAjax(wrap, json, options);
    wrap.removeClass(getPrefixedClassName("loading"));
    wrap.data("loaded", true).data("loading", false);
    wrap.triggerHandler("data.load", {
      options,
      records: options.records,
      json
    });
    if (nextFn) {
      nextFn(true);
    }
  });
};
const loadByLocal = (wrap, nextFn) => {
  const options = wrap.data("options");
  const cfg = options.initOptions;
  let dirty = false;
  if (!wrap.data("loaded") || cfg.forceReload) {
    wrap.triggerHandler("data.beforeload");
    loadFromDom(wrap, options);
    wrap.data("loaded", true);
    wrap.triggerHandler("data.load", {
      options,
      records: options.records
    });
    dirty = true;
  }
  if (nextFn) {
    nextFn(dirty);
  }
};
const loadByAjax = (wrap, nextFn, params) => {
  const options = wrap.data("options");
  const cfg = options.initOptions;
  const dirty = true;
  if (options.loadDefer) {
    options.loadDefer.abort();
  }
  const ajaxOptions = $.extend({}, cfg.ajax);
  if (typeof ajaxOptions.data === "function") {
    ajaxOptions.data = ajaxOptions.data();
  }
  const limitParams = {};
  if (cfg.scrollLoad) {
    limitParams[cfg.scrollNumberKey] = Number(cfg.scrollNumber) * Number(wrap.data("scroll-count") || 1);
  }
  ajaxOptions.data = $.extend(ajaxOptions.data || {}, params, limitParams);
  wrap.triggerHandler("data.beforeload", ajaxOptions);
  wrap.data("loaded", false).data("loading", true);
  wrap.addClass(getPrefixedClassName("loading"));
  const callback = ajaxOptions.callback;
  ajaxOptions.callback = function(success, json, xhrArgs) {
    var _a;
    const removeStatus = function() {
      wrap.removeClass(getPrefixedClassName("loading"));
      wrap.data("loaded", true).data("loading", false);
    };
    if (wrap.data("destroyed")) {
      return;
    }
    const isAbort = ((_a = xhrArgs == null ? void 0 : xhrArgs[0]) == null ? void 0 : _a.statusText) === "abort";
    if (isAbort) {
      removeStatus();
      if (nextFn) {
        nextFn(dirty, {
          isSuccess: false,
          isAbort: true,
          json
        });
      }
      return;
    }
    if (ajaxOptions.preCallback) {
      ajaxOptions.preCallback(success, json);
    }
    loadFromAjax(wrap, json, options);
    removeStatus();
    wrap.triggerHandler("data.load", {
      options,
      records: options.records,
      json
    });
    if (nextFn) {
      nextFn(dirty, {
        isSuccess: success,
        json
      });
    }
    if (callback) {
      callback.apply(this, arguments);
    }
  };
  options.loadDefer = ajax(ajaxOptions);
};
const load = function(wrap, nextFn, params) {
  const options = wrap.data("options");
  const cfg = options.initOptions;
  if ($.isArray(params)) {
    loadByArray(wrap, nextFn, params);
    return;
  }
  if (isInstanceofAjax(params)) {
    loadByAjaxInstance(wrap, nextFn, params);
    return;
  }
  if (!cfg.ajax) {
    loadByLocal(wrap, nextFn);
    return;
  }
  loadByAjax(wrap, nextFn, params);
};
const clear = function(wrap) {
  const options = wrap.data("options");
  options.records = options._records = [];
  wrap.data("loaded", false);
  wrap.triggerHandler("data.clear", []);
};
function loadFromDom(wrap, options) {
  const initOptions = options.initOptions;
  const processData = initOptions.processData;
  const filter = initOptions.filter;
  let records = extractData(options);
  options._records = records;
  if (processData) {
    records = processData(records, options);
  }
  if (filter) {
    records = records.filter(filter);
  }
  options.records = records;
  if (!exists$1(options.value)) {
    if (initOptions.multiple) {
      const values = [];
      $.each(records, function(idx, rd) {
        if (rd.selected) {
          values.push(rd.value);
        }
      });
      options.value = values;
    } else {
      $.each(records, function(idx, rd) {
        if (rd.selected) {
          options.value = rd.value;
          return false;
        }
      });
    }
  }
  wrap.triggerHandler("data.changed", {
    options,
    records: options.records,
    json: null
  });
}
function loadFromAjax(wrap, json, options) {
  options.isEmpty = false;
  options.isError = false;
  if (json && json.data) {
    const cfg = options.initOptions;
    const root = cfg.ajax && cfg.ajax.root || "data";
    const df = cfg.displayField;
    const vf = cfg.valueField;
    const dfk = cfg.disabledField;
    const tipField = cfg.tipField;
    let records = [];
    let data = null;
    const processData = cfg.processData;
    const filter = cfg.filter;
    switch (typeof root) {
      case "string":
        data = json[root];
        break;
      case "function":
        data = root(json, options);
        break;
      default:
        data = [json];
    }
    data = [].concat(data || []);
    if (!wrap.data("search-loading") && cfg.addEmptyItem && data.length === 0) {
      records = typeof cfg.addEmptyItem === "string" ? cfg.addEmptyItem : $i("scp.vt_component.common.plugins.jquery.fixselect.proxy.no_data");
      options._records = records;
      options.records = records;
      wrap.triggerHandler("data.changed", {
        options,
        records: options.records,
        json
      });
      return;
    }
    $.each(data, function(i, it) {
      records.push({
        index: i,
        text: it[df],
        value: it[vf],
        json: $.extend({}, it),
        disabled: it[dfk],
        tip: it[tipField] || it[df]
      });
    });
    if (cfg.groupBy) {
      records = group(records, cfg.groupBy);
    }
    options._records = records;
    if (processData) {
      records = processData(records, options);
    }
    if (filter) {
      records = records.filter(filter);
    }
    options.records = records;
    if (cfg.addEmptyItem && records.length === 0) {
      records = typeof cfg.addEmptyItem === "string" ? cfg.addEmptyItem : $i("scp.vt_component.common.plugins.jquery.fixselect.proxy.no_data");
      options._records = records;
      options.records = records;
      options.isEmpty = true;
    }
  } else {
    options.records = $i("scp.vt_component.common.plugins.jquery.fixselect.proxy.no_data");
    options.isError = true;
  }
  wrap.triggerHandler("data.changed", {
    options,
    records: options.records,
    json
  });
}
const BODY = $("body");
const isArray = lang.isArray;
const isObject = lang.isObject;
const createSelect = function(el, options) {
  return `<div id="${idseed()}" class="${getPrefixedClassName("select")} ${options.cls || ""}"></div>`;
};
const createInput = function(el, opt) {
  opt = opt || {};
  const attrs = {}, mapper = {
    value: "data-value"
  }, inputTagName = opt.width === "auto" || opt.icon || opt.showSelectedPrefix ? "div" : "input";
  const isInput = inputTagName === "input";
  const $input = $("<" + inputTagName + ">");
  if (opt.icon) {
    $input.addClass("vtv-icon-" + opt.icon);
  }
  if (opt.readOnly && !opt.editable && isInput) {
    attrs.readOnly = "readOnly";
  }
  $.each(["disabled", "placeholder", "value"], function(i, name) {
    name = mapper[name] || name;
    const tmp = el.attr(name);
    if (tmp !== void 0) {
      attrs[name] = tmp;
    }
  });
  if (isInput) {
    attrs.type = "text";
    attrs["style-key"] = "input";
    $input.addClass([getPrefixedClassName("select_trigger"), getPrefixedClassName("select_input")].join(" "));
  } else {
    $input.addClass([getPrefixedClassName("select_trigger"), "input", getPrefixedClassName("select_div")].join(" "));
  }
  return $input.attr(attrs);
};
const resizeWrap = function(wrap) {
  if (!wrap.data("options")) {
    return;
  }
  const options = wrap.data("options"), initOptions = options.initOptions, target = options.target, field = options.field, targetWidth = pixelSize(target, "width");
  let maxWidthConfig = initOptions.maxWidth;
  let widthConfig = initOptions.width;
  widthConfig = widthConfig === "auto" ? "auto" : widthConfig || targetWidth;
  if (typeof widthConfig === "number") {
    widthConfig = widthConfig + "px";
  }
  field.css("width", widthConfig);
  wrap.css("width", widthConfig);
  if (maxWidthConfig === "width") {
    maxWidthConfig = targetWidth;
  }
  if (typeof maxWidthConfig === "number") {
    maxWidthConfig = maxWidthConfig + "px";
  }
  if (maxWidthConfig) {
    field.css("max-width", maxWidthConfig);
    wrap.css("max-width", maxWidthConfig);
  }
  $.each(["margin-left", "margin-right", "margin-top", "margin-bottom"], function(i, key) {
    wrap.css(key, target.css(key));
  });
};
const initeList = function(wrap) {
  const options = wrap.data("options");
  if (!options) {
    return;
  }
  if (!options.list) {
    const cfg = options.initOptions;
    const cssText = [];
    let mul = "";
    const wrapWidth = getWrapWidth(wrap);
    const width = cfg.listWidth || wrapWidth;
    cssText.push("width:" + (isFinite(width) ? width + "px" : width));
    if (typeof cfg.minListWidth !== "undefined") {
      cssText.push("min-width:" + cfg.minListWidth + "px");
    } else if (width === "auto") {
      cssText.push("min-width:" + wrapWidth + "px");
    }
    if (cfg.multiple) {
      mul = "multiple";
    }
    const sizeTypeClass = `${getPrefixedClassName(`select-list--size-${cfg.size || ""}`)} `;
    const list = $(
      `<div class="${getPrefixedClassName("select-list")} ${sizeTypeClass} ${cfg.listWrapCls || ""}" ${mul} style="${cssText.join(";")}"></div>`
    ).appendTo(getListParent(wrap)).hide();
    list.click(function(evt) {
      processListClick(evt, wrap);
    }).hover(
      function() {
        wrap.data("list.hover", true);
      },
      function() {
        wrap.data("list.hover", false);
      }
    );
    if (cfg.search) {
      monitorForSearch(list, wrap, cfg);
    }
    list._windowWidth = $(window).width();
    list._changeWidth = function(force) {
      if (!force && !list._resized) {
        return;
      }
      list._resized = false;
      const listWidth = cfg.listWidth || getWrapWidth(wrap);
      list.css("width", isFinite(listWidth) ? listWidth + "px" : listWidth);
    };
    list._resizeFn = function() {
      if (list._resized) {
        return;
      }
      const winWidth = $(window).width();
      if (winWidth === list._windowWidth) {
        return;
      }
      list._windowWidth = winWidth;
      list._resized = true;
      collapseList(wrap);
    };
    $(window).on("resize", list._resizeFn);
    options.list = list;
  }
  if ($(wrap).closest("[utid]").length) {
    $(options.list).attr("utid", $(wrap).closest("[utid]").attr("utid") + "-select-list");
  }
  return options.list;
};
const createCaret = function() {
  return `<span class="caret"></span>`;
};
const createClearDom = function() {
  return `<span class="${getPrefixedClassName(
    "clearable"
  )} iconfont vtv-icon-unsupported" style='display: none'></span>`;
};
const expandList = function(wrap) {
  const list = initeList(wrap);
  if (list.data("expanding") || list.data("expanded")) {
    return;
  }
  list.data("expanding", true);
  wrap.data("scroll-count", 0);
  wrap.data("scroll-total", 0);
  if (list._changeWidth) {
    list._changeWidth();
  }
  load(wrap, function(dirty, opt) {
    list.data("expanding", false);
    wrap.data("__clickExpanding", false);
    if (opt && opt.isAbort) {
      return;
    }
    updateList(wrap, true);
    if (isOpenMultipleCheckAll(wrap.data("options"))) {
      updateAllOptionItemCheckStatus(wrap);
    }
    if (wrap.is(":hidden")) {
      return;
    }
    list.show();
    alignToWrap(wrap, list);
    list.data("expanded", true);
    wrap.triggerHandler("list.show", {
      list
    });
    wrap.data("block-blur", 1);
    const input = $(".select-list-search > input", list);
    if (input.size()) {
      input.focus();
    }
    setTimeout(function() {
      wrap.removeData("block-blur");
    }, 0);
  });
};
const collapseList = function(wrap, callback) {
  if (!wrap.data("options")) {
    return;
  }
  const options = wrap.data("options");
  const initOptions = options.initOptions;
  const list = options.list;
  if (!list) {
    wrap.data("list.hover", false);
    return;
  }
  if (!list.is(":visible")) {
    return;
  }
  if (initOptions.beforelisthide && initOptions.beforelisthide() === false) {
    return;
  }
  list.hide();
  list.data("expanded", false);
  wrap.triggerHandler("list.hide", {
    list
  });
  if (typeof callback === "function") {
    callback();
  }
  if (initOptions.destroyOnHide) {
    wrap.triggerHandler("list.destroy", {
      list
    });
    destroyList(wrap);
    options.list = null;
  }
};
const toggleList = function(wrap) {
  const options = wrap.data("options");
  const list = options.list;
  if (list && list.is(":visible")) {
    collapseList(wrap);
  } else {
    expandList(wrap);
  }
};
const focusField = function(wrap) {
  const options = wrap.data("options");
  const field = options.field;
  field.focus();
};
const updateList = function(wrap, force) {
  if (!wrap.data("options") || wrap.is(":hidden")) {
    return;
  }
  const list = wrap.data("options").list;
  if (list && (!list.data("rendered") || force)) {
    _updateList(wrap);
    list.data("rendered", true);
  }
};
const destroyList = function(wrap) {
  if (!wrap.data("options")) {
    return;
  }
  const list = wrap.data("options") && wrap.data("options").list;
  if (list) {
    list.hide();
    wrap.triggerHandler("list.destroy", { list });
    list.off();
    list.unbind();
    list.undelegate();
    if (list._resizeFn) {
      $(window).off("resize", list._resizeFn);
      list._resizeFn = null;
    }
    list._changeWidth = null;
    list._windowWidth = null;
    list._resized = null;
    list.removeData();
    list.remove();
  }
};
const selectValue = function(value, wrap) {
  if (value === void 0 || value === null) {
    clearValue(wrap);
    return;
  }
  if (!wrap.data("options")) {
    return;
  }
  const options = wrap.data("options"), initOptions = options.initOptions;
  if (!wrap.data("loaded")) {
    options.value = value;
    return false;
  }
  const multiple = initOptions.multiple;
  const keepNotFound = false !== initOptions.keepNotFound;
  const data = multiple ? findMulValue(value, wrap, keepNotFound) : findValue(value, wrap, keepNotFound, initOptions.refuseInvalidValue);
  if (initOptions.refuseInvalidValue && !data) {
    if (initOptions.clearOnRefused) {
      clearValue(wrap);
    } else if (initOptions.autoSelectOnRefused) {
      selectFirst(wrap);
    }
    return;
  }
  if (multiple) {
    setMulValue(data, wrap);
  } else {
    if (data) {
      postValue(data, wrap);
    } else {
      clearValue(wrap);
    }
  }
};
const clearValue = function(wrap) {
  if (!wrap.data("options")) {
    return;
  }
  const options = wrap.data("options");
  val(options.field, "");
  val(options.target, "");
  delete options.value;
  updateListIf(wrap);
  wrap.triggerHandler("clear");
};
const selectFirst = function(wrap) {
  const data = findFirstValue(wrap);
  if (data) {
    postValue(data, wrap);
  } else {
    clearValue(wrap);
  }
};
function processListClick(evt, wrap) {
  const target = $(evt.target);
  const options = wrap.data("options");
  if (!options) {
    return;
  }
  if (options.initOptions.search) {
    if (target.is(".select-list-search > input")) {
      return;
    }
    if (target.is(".select-list-search")) {
      $("input", target).focus();
      return;
    }
  }
  const selector = "li." + defs.itemCls;
  let optionsDom = target;
  if (!optionsDom.is(selector)) {
    while (optionsDom.size() && !optionsDom.is(selector)) {
      optionsDom = optionsDom.parent();
    }
    if (!optionsDom.is(selector)) {
      optionsDom = target.parent(selector);
    }
  }
  const li = target.is(selector) ? target : optionsDom;
  options.field.focus();
  wrap.triggerHandler("list.click", {
    list: options.list,
    evtTarget: target
  });
  if (li.size() === 0) {
    return;
  }
  if (li.hasClass("disabled")) {
    return;
  }
  let oldData = null;
  let data = options.records;
  const idx = li.attr("data-idx");
  const gidx = li.attr("data-gidx");
  data = locateValue(idx, gidx, data);
  const multiple = options.initOptions.multiple;
  const extendData = $.extend({}, data);
  const isSelectAllOption = idx === ALL_OPTION.id;
  if (multiple) {
    oldData = $.extend(true, [], options.value);
    if (wrap.triggerHandler("before.multiple.checked", { data: extendData }) === false) {
      return;
    }
    when(_fixBefore(options.initOptions.beforeSelect || true, oldData, extendData)).then(function(result) {
      if (result === false) {
        return;
      }
      if (isSelectAllOption) {
        const oldCheckAllStatus = wrap.data("checkAllStatus");
        const newCheckAllStatus = ALL_OPTION_CHECK_STATUS.ALL === oldCheckAllStatus ? ALL_OPTION_CHECK_STATUS.NONE : ALL_OPTION_CHECK_STATUS.ALL;
        wrap.data("checkAllStatus", newCheckAllStatus);
        li.attr("data-check-status", newCheckAllStatus);
        postMulCheckAllValue(wrap, newCheckAllStatus);
        emitUpdateCheckedAllStatus(wrap, newCheckAllStatus);
      } else {
        const checked = li.attr("checked");
        li.attr("checked", !checked);
        postMulValue(data, wrap, !checked);
        if (isOpenMultipleCheckAll(options)) {
          updateAllOptionItemCheckStatus(wrap);
        }
        dealMultipleDisabled(options, li);
      }
    });
  } else {
    oldData = options.value;
    if (wrap.triggerHandler("before.item.select", { data: extendData }) === false) {
      return;
    }
    when(_fixBefore(options.initOptions.beforeSelect || true, oldData, extendData)).then(function(result) {
      if (result === false) {
        return;
      }
      postValue(data, wrap);
      wrap.triggerHandler("item.select", {
        data: $.extend({}, data)
      });
    });
    collapseList(wrap);
  }
}
function updateAllOptionItemCheckStatus(wrap) {
  const options = wrap.data("options");
  if (!options) {
    return;
  }
  const checkedStatus = getAllSelectionStatus(options);
  emitUpdateCheckedAllStatus(wrap, checkedStatus);
  wrap.data("checkAllStatus", checkedStatus);
  const cfg = options.initOptions;
  const listWrap = cfg.listContentEl ? cfg.listContentEl(wrap, options) : options.list;
  if (!listWrap) {
    return;
  }
  const allOption = listWrap.find(`.list-item[data-idx="${ALL_OPTION.id}"]`);
  if (!allOption.length) {
    return;
  }
  allOption.attr("data-check-status", checkedStatus);
}
function emitUpdateCheckedAllStatus(wrap, checkedStatus) {
  wrap.triggerHandler("update-checked-all-status", {
    checkedAll: checkedStatus === ALL_OPTION_CHECK_STATUS.ALL,
    checkedStatus
  });
}
function emitChange(wrap, newData, oldData) {
  wrap.triggerHandler("change", {
    data: newData,
    oldData
  });
}
function createPrefix(optionInfo) {
  const { prefix, prefixType } = optionInfo;
  return prefixType === PREFIX_TYPE.image ? `<img src=${prefix} class="${getPrefixedClassName("select_div-prefix")}" />` : `<i class="${prefix}"></i>`;
}
function postValue(data, wrap) {
  var _a, _b;
  if (!wrap.data("options")) {
    return;
  }
  const options = wrap.data("options");
  const oldData = options.value;
  let text = data.text;
  if (options.initOptions.displayTextFormatter) {
    text = options.initOptions.displayTextFormatter(data, oldData, options);
  }
  if (options.initOptions.showSelectedPrefix) {
    text = ((_a = data.json) == null ? void 0 : _a.prefix) && ((_b = data.json) == null ? void 0 : _b.prefixType) ? `${createPrefix(data.json)}${format.htmlTextEncode(text)}` : format.htmlTextEncode(text);
  }
  val(options.field, text);
  val(options.target, data.value);
  options.value = data;
  if (oldData && oldData.value !== data.value) {
    emitChange(wrap, data, oldData);
  }
  const oldValue = typeof oldData === "string" ? oldData : oldData == null ? void 0 : oldData.value;
  wrap.triggerHandler("value", {
    data,
    oldData,
    changed: data.value !== oldValue
  });
}
function postMulCheckAllValue(wrap, checkStatus) {
  const options = wrap.data("options");
  if (!options || !checkStatus) {
    return;
  }
  const oldData = $.extend(true, [], options.value);
  let currData = options.value || [];
  if (checkStatus === ALL_OPTION_CHECK_STATUS.NONE) {
    currData = currData.filter((checkedData) => checkedData.disabled);
    val(options.field, "");
  } else {
    const checkedValuesMap = toMap(currData);
    options.records.forEach((record) => {
      if (!checkedValuesMap[record.value] && !record.disabled) {
        const value = options.initOptions.isGroup ? record.options : [record];
        currData.push(...value);
      }
    });
    val(options.field, options.initOptions.checkAllLabel);
  }
  currData.sort((a, b) => a.index - b.index);
  const values = [];
  currData.forEach((cData) => {
    values.push(cData.value);
  });
  val(options.target, values.join(","));
  options.value = currData;
  updateListChecked(options, wrap);
  const changed = isMulValueChanged(currData, oldData);
  if (changed) {
    emitChange(wrap, currData, oldData);
  }
  wrap.triggerHandler("value", {
    data: currData,
    oldData,
    changed
  });
}
function postMulValue(data, wrap, checked) {
  if (!wrap.data("options")) {
    return;
  }
  const options = wrap.data("options");
  const oldData = $.extend(true, [], options.value);
  let vs = options.value || [];
  vs = isArray(vs) ? vs : [vs];
  let names = [];
  const values = [];
  const v2 = data.value;
  if (checked) {
    vs.push(data);
  } else {
    vs = vs.filter((item) => item.value !== v2);
  }
  vs.sort((a, b) => {
    return a.index - b.index;
  });
  vs.forEach((item) => {
    names.push(item.text);
    values.push(item.value);
  });
  if (options.initOptions.displayTextFormatter) {
    const text = options.initOptions.displayTextFormatter(data, oldData, options);
    names = isArray(text) ? text : [text];
  }
  options.value = vs;
  const isCheckedAll = getAllSelectionStatus(options) === ALL_OPTION_CHECK_STATUS.ALL;
  if (isCheckedAll && options.initOptions.checkAllLabel) {
    val(options.field, options.initOptions.checkAllLabel);
  } else {
    multipleSetFieldVal(options, names.join(","));
  }
  val(options.target, values.join(","));
  const changed = isMulValueChanged(vs, oldData);
  if (changed) {
    emitChange(wrap, vs, oldData);
  }
  wrap.triggerHandler("value", {
    data: vs,
    oldData,
    changed
  });
}
function setMulValue(data, wrap) {
  if (!wrap.data("options")) {
    return;
  }
  const options = wrap.data("options");
  const oldData = options.value;
  let names = [];
  const values = [];
  const vs = [];
  $.each(data, function(idx, v2) {
    vs.push(v2);
    names.push(v2.text);
    values.push(v2.value);
  });
  if (options.initOptions.displayTextFormatter) {
    const text = options.initOptions.displayTextFormatter(data, oldData, options);
    names = isArray(text) ? text : [text];
  }
  multipleSetFieldVal(options, names.join(","));
  val(options.target, values.join(","));
  options.value = vs;
  if (isOpenMultipleCheckAll(options)) {
    updateAllOptionItemCheckStatus(wrap);
    if (wrap.data("checkAllStatus") === ALL_OPTION_CHECK_STATUS.ALL) {
      val(options.field, options.initOptions.checkAllLabel);
    }
  }
  updateListChecked(options, wrap);
  const changed = isMulValueChanged(vs, oldData);
  if (changed) {
    emitChange(wrap, vs, oldData);
  }
  wrap.triggerHandler("value", {
    data: vs,
    oldData,
    changed
  });
}
function multipleSetFieldVal(options, valStr) {
  const isTagMode = options.initOptions.multipleDisplayType === "tag";
  if (isTagMode) {
    val(options.field, "");
    if (valStr) {
      $(options.field).attr("placeholder", "");
    } else {
      const placeholder = options.target.attr("placeholder");
      $(options.field).attr("placeholder", placeholder);
    }
  } else {
    val(options.field, valStr);
  }
}
function findValue(value, wrap, keepNotFound, noCache) {
  if (!noCache && isObject(value) && exists(value.value) && exists(value.text)) {
    return value;
  }
  if (!wrap.data("options")) {
    return;
  }
  const data = parseValue(value, wrap);
  let records = wrap.data("options").records;
  records = isArray(records) ? records : [];
  let hit = false;
  $.each(records, function(i, rd) {
    if (rd.options) {
      $.each(rd.options, function(j, d) {
        if (d.value === data.value) {
          hit = d;
          return false;
        }
      });
      if (hit) {
        return false;
      }
    } else if (rd.value === data.value) {
      hit = rd;
      return false;
    }
  });
  if (!hit && keepNotFound) {
    hit = data;
  }
  return hit;
}
function findMulValue(values, wrap, keepNotFound) {
  if (!wrap.data("options")) {
    return;
  }
  let records = wrap.data("options").records;
  records = isArray(records) ? records : [];
  values = isArray(values) ? values : values ? [values] : [];
  const hits = [];
  let vmapLen = 0;
  const vmap = function(vs) {
    const m = {};
    $.each(vs, function(i, v2) {
      if (isObject(v2) && exists(v2.value) && exists(v2.text)) {
        hits[i] = v2;
        return;
      }
      m[v2] = i;
      vmapLen++;
    });
    return m;
  }(values);
  if (vmapLen) {
    $.each(records, function(i, rd) {
      if (rd.options) {
        $.each(rd.options, function(j, d) {
          if (exists(vmap[d.value])) {
            hits[vmap[d.value]] = d;
          }
        });
      } else if (exists(vmap[rd.value])) {
        hits[vmap[rd.value]] = rd;
      }
    });
  }
  if (hits.filter(exists).length !== values.length && keepNotFound) {
    $.each(values, function(idx, v2) {
      v2 = parseValue(v2, wrap);
      if (v2 && !hits.find((item) => item && item.value === v2.value)) {
        hits[idx] = v2;
      }
    });
  }
  return hits.filter(exists);
}
function parseValue(v2, wrap) {
  if (!wrap.data("options")) {
    return;
  }
  v2 = v2 && v2.json || v2;
  let data = { json: v2 };
  const initOptions = wrap.data("options").initOptions;
  const displayField = initOptions.displayField;
  const valueField = initOptions.valueField;
  if (isObject(v2)) {
    data.text = v2[displayField];
    data.value = v2[valueField];
    data.json = v2;
  } else if (exists(v2)) {
    data.text = data.value = v2;
    data.json = {};
    data.json[displayField] = data.json[valueField] = v2;
  } else {
    data = null;
  }
  return data;
}
function findFirstValue(wrap) {
  if (!wrap.data("options")) {
    return;
  }
  const records = wrap.data("options").records;
  let data;
  if (isArray(records)) {
    for (let i = 0, len = records.length; i < len; i++) {
      if (!records[i].disabled) {
        data = records[i];
        break;
      }
    }
  }
  return (data && data.options ? data.options[0] : data) || null;
}
function locateValue(idx, gidx, data) {
  if (typeof gidx !== "undefined") {
    data = data[gidx].options;
  }
  return data[idx];
}
function isMulValueChanged(newData, oldData) {
  const newValue = newData.map((item) => item.value);
  const formattedOldData = Array.isArray(oldData) ? oldData : [oldData];
  const oldValue = formattedOldData.map((item) => {
    if (isObject(item)) {
      return item.value;
    }
    return item;
  });
  return newValue.join(",") !== oldValue.join(",");
}
const createAddBtn = function(wrapUtid) {
  const addItemUtidBase = "add-item";
  const addItemUtid = wrapUtid ? `${wrapUtid}-${addItemUtidBase}` : addItemUtidBase;
  const btnCls = `${getPrefixedClassName("el-button")} ${getPrefixedClassName(
    "el-button--small"
  )} ${getPrefixedClassName("select-list-add-btn")}`;
  return `<div class="${getPrefixedClassName("select-list-add-container")}">
    <button type="button"
            class="${btnCls}"
            utid="${addItemUtid}">
      <i class="iconfont vtv-icon-add ${getPrefixedClassName("sf-button_left-icon")}"></i>
      <span class="${getPrefixedClassName("sf-button_span")} ${getPrefixedClassName("sf-button__content")}">
        ${$i("scp.vt_component.common.plugins.jquery.fixselect.view.add_option_item_btn")}
      </span>
    </button>
  </div>`;
};
function _updateList(wrap) {
  if (!wrap.data("options")) {
    return;
  }
  const options = wrap.data("options");
  const cfg = options.initOptions;
  const listWrap = cfg.listContentEl ? cfg.listContentEl(wrap, options) : options.list;
  const regex = /select-list--size-\S*/g;
  listWrap[0].className = listWrap[0].className.replace(regex, `select-list--size-${cfg.size || ""}`);
  const listBody = `<ul class="${getPrefixedClassName("select-list-body")} ${cfg.listCls ? cfg.listCls : ""}">${parseHtml(wrap, options)}</ul>`;
  let listEmpty = "", listFooter = "", searchToolbar = "", scrollLoadFooter = "";
  const searchCfg = options.initOptions.search;
  const isEmpty = typeof options.records === "string";
  if (searchCfg) {
    const searchPlaceholder = searchCfg.placeholder || $i("scp.vt_component.common.plugins.jquery.fixselect.view.search_placeholder");
    const inputCls = `${getPrefixedClassName("select-list-search-value")}`;
    searchToolbar = `
      <div class="${getPrefixedClassName("select-list-search")}">
        <i class="${getPrefixedClassName("select-list-search-icon")} iconfont vtv-icon-comp-search" />
        <input class="${inputCls}" style-key="input" type="text" placeholder="${searchPlaceholder}"/>
      </div>`;
    if (!isEmpty) {
      const hasRecords = options.records && options.records.length;
      const hiddenClass = hasRecords ? "hidden" : "";
      listEmpty = `
        <div class="${getPrefixedClassName("select-list-search-empty")} ${hiddenClass}">
          ${$i("scp.vt_component.common.plugins.jquery.fixselect.proxy.no_data")}
        </div>`;
    }
  }
  if (cfg.listExtTpl) {
    listFooter = `<div class="${getPrefixedClassName("select-list-footer")}">` + cfg.listExtTpl + "</div>";
  }
  if (options.initOptions.scrollLoad) {
    scrollLoadFooter = `<div class="${getPrefixedClassName("select-list-loading")} hidden">` + $i("scp.vt_component.common.plugins.jquery.fixselect.view.update_list_loading") + "</div>";
  }
  if (options.initOptions.scrollLoad) {
    scrollLoadFooter = `<div class="${getPrefixedClassName("select-list-loading")} hidden">` + $i("scp.vt_component.common.plugins.jquery.fixselect.view.update_lists_loading") + "</div>";
  }
  const wrapUtid = $(wrap).closest("[utid]").attr("utid");
  const footerAddBtn = cfg.showAddBtn ? createAddBtn(wrapUtid) : "";
  listWrap.html(searchToolbar + listBody + listEmpty + listFooter + scrollLoadFooter + footerAddBtn);
  if (footerAddBtn) {
    $(".select-list-add-btn").click(function() {
      wrap.triggerHandler("item.add");
    });
  }
  if (searchCfg && searchCfg.limit) {
    const $searchInput = listWrap.find(".select-list-search-value");
    setInputLimit($searchInput, searchCfg);
  }
}
function updateListIf(wrap) {
  if (!wrap.data("options")) {
    return;
  }
  const list = wrap.data("options").list;
  if (list && list.is(":visible")) {
    updateList(wrap, true);
  }
}
function getListParent(wrap) {
  if (!wrap.data("options")) {
    return;
  }
  const parent = wrap.data("options").initOptions.listParent;
  if (typeof parent === "function") {
    return parent(wrap);
  }
  return parent || BODY;
}
function getWrapWidth(wrap) {
  const wrapEl = wrap.get(0);
  let width = 0;
  if (wrapEl) {
    const rect = wrapEl.getBoundingClientRect();
    width = rect.width || parseFloat(wrap.css("width"));
  }
  return width;
}
function alignToWrap(wrap, list) {
  if (!wrap.data("options")) {
    return;
  }
  const listHeight = $.css(list[0], "height", true);
  let isDown = true;
  const wrapPos = wrap[0].getBoundingClientRect();
  const element = wrap[0];
  const wrapHeight = element.getBoundingClientRect().height;
  const options = wrap.data("options");
  const initOptions = options.initOptions;
  const field = options.field[0];
  const borderBottomWidth = $.css(field, "border-bottom-width", true);
  const viewHeight = document.documentElement.clientHeight;
  const bottomAvailHeight = viewHeight - wrap[0].getBoundingClientRect().top - wrapHeight;
  const listWidth = list.outerWidth();
  const diffWidth = wrapPos.width - listWidth;
  let listLeft = wrapPos.left;
  if (initOptions.align === "right") {
    listLeft = listLeft + diffWidth;
  } else if (initOptions.align === "center") {
    listLeft = listLeft + diffWidth / 2;
  }
  listLeft += initOptions.offsetX || 0;
  if (diffWidth) {
    listLeft = listLeft - Math.max(listLeft + listWidth - $(window).width(), 0);
    listLeft = Math.max(listLeft, 0);
  }
  list.css("left", listLeft + "px");
  let top = wrapHeight + wrapPos.top;
  if (bottomAvailHeight < listHeight && top - wrapHeight >= listHeight) {
    top = top - listHeight - borderBottomWidth - wrapHeight;
    isDown = false;
  }
  list.toggleClass("is-upward", !isDown);
  top += initOptions.offsetY || 0;
  list.css("top", top + "px");
  resizeList(list);
}
function resizeList(list) {
  list.css("height", "");
  const listPos = list[0].getBoundingClientRect();
  const windowBottom = $(window).height();
  if (listPos.bottom > windowBottom) {
    list.height(windowBottom - listPos.top - 10);
  }
}
function monitorForSearchLoad(list, wrap, cfg) {
  function searchDomReady() {
    $(".select-list-body", list).empty();
    $(".select-list-loading", list).removeClass("hidden");
  }
  list.delegate(".select-list-search > input", "keydown", function(e) {
    if (e.keyCode === 13) {
      searchDomReady();
      wrap.data("search-loading", true);
      wrap.data("scroll-count", 0);
      const value = $(this).val().trim();
      const params = {};
      params[cfg.searchKey] = value;
      load(
        wrap,
        function(dirty, ret) {
          const retJson = ret && ret.json;
          wrap.data("scroll-total", retJson && retJson[cfg.scrollTotalKey]);
          wrap.data("search-loading", false);
          $(".select-list-search > input", list).val(value).focus();
        },
        params
      );
    }
    if (e.keyCode === 27) {
      searchDomReady();
      $(".select-list-search > input", list).val("");
      load(wrap, function() {
        $(".select-list-search > input", list).focus();
      });
    }
  });
}
function monitorForSearch(list, wrap, cfg) {
  if (cfg.scrollLoad && cfg.searchLoad) {
    monitorForSearchLoad(list, wrap, cfg);
    return;
  }
  list.delegate(".select-list-search > input", "input", function() {
    let hasMatched = false;
    const val2 = $(this).val();
    const searchRegex = createSearchRegex(val2);
    $("li.list-item", list).each(function(idx, li) {
      let isMatched = !val2;
      if ($(li).attr("data-idx") !== ALL_OPTION.id) {
        isMatched = searchRegex.test($(li).text());
      }
      $(li)[isMatched ? "removeClass" : "addClass"]("hidden");
      hasMatched = hasMatched || isMatched;
    });
    $(".select-list-search-empty", list)[hasMatched ? "addClass" : "removeClass"]("hidden");
    alignToWrap(wrap, list);
  });
}
function createSearchRegex(val2) {
  return new RegExp(
    $.map($.trim(val2).split(/\s+/g), function(v2) {
      return escapeRegex(v2);
    }).join(".*?"),
    "i"
  );
}
function idseed() {
  idseed.seed = idseed.seed || 1;
  return "fixselect-" + idseed.seed++;
}
function exists(v2) {
  return exists$1(v2);
}
function _fixBefore(value, oldData, newData) {
  return typeof value === "boolean" ? value : value(oldData, newData);
}
const _boxSizingReliable = $.support.boxSizingReliable();
function pixelSize(el, attr) {
  return !_boxSizingReliable && el[attr] ? el[attr]() : parseInt(el.css(attr), 10);
}
function dealMultipleDisabled(options, target) {
  const selectLimit = options.initOptions.selectLimit;
  if (!lang.isNumber(selectLimit)) {
    return;
  }
  if (options.initOptions.groupBy) {
    dealGroupMultipleDisabled(options, target);
    return;
  }
  dealBaseMultipleDisabled(options, target);
}
function dealGroupMultipleDisabled(options, target) {
  const selectLimit = options.initOptions.selectLimit;
  const checkedNum = options.value.length;
  const allLiItem = target.closest(".select-list-body").find(".list-item");
  const allData = $.extend(true, [], options.records);
  if (checkedNum >= selectLimit) {
    allLiItem.not("[checked]").not(".disabled").each((i, item) => {
      const gidx = $(item).attr("data-gidx");
      const idx = $(item).attr("data-idx");
      const curData = allData[gidx].options[idx];
      const tip = curData.tip || string.format(options.initOptions.selectLimitText, selectLimit);
      $(item).addClass(getPrefixedClassName("disabled")).attr("data-tip", tip);
    });
  } else {
    allLiItem.each((i, item) => {
      const gidx = $(item).attr("data-gidx");
      const idx = $(item).attr("data-idx");
      const curData = allData[gidx].options[idx];
      if (!curData.disabled) {
        $(item).removeClass(getPrefixedClassName("disabled")).attr("data-tip", curData.tip);
      }
    });
  }
}
function dealBaseMultipleDisabled(options, target) {
  const selectLimit = options.initOptions.selectLimit;
  const checkedNum = options.value.length;
  if (checkedNum >= selectLimit) {
    target.closest(".select-list-body").find(".list-item").not("[checked]").not(".disabled").each((i, item) => {
      const idx = $(item).attr("data-idx");
      const curData = options.records[idx];
      const tip = curData.tip || string.format(options.initOptions.selectLimitText, selectLimit);
      $(item).addClass(getPrefixedClassName("disabled")).attr("data-tip", tip);
    });
  } else {
    target.parent().children().each((i, item) => {
      const idx = $(item).attr("data-idx");
      const curData = options.records[idx];
      if (!curData.disabled) {
        $(item).removeClass(getPrefixedClassName("disabled")).attr("data-tip", curData.tip);
      }
    });
  }
}
function updateListChecked(options, wrap) {
  var _a;
  const cfg = options.initOptions;
  const listWrap = cfg.listContentEl ? cfg.listContentEl(wrap, options) : options.list;
  if (!listWrap) {
    return;
  }
  const values = ((_a = options.value) == null ? void 0 : _a.map((item) => item.value)) || [];
  listWrap.find(".list-item").each((i, item) => {
    const idx = $(item).attr("data-idx");
    const gidx = $(item).attr("data-gidx");
    const data = locateValue(idx, gidx, options.records);
    if (values.includes(data == null ? void 0 : data.value)) {
      $(item).attr("checked", true);
    } else {
      $(item).attr("checked", false);
    }
  });
}
function updateSize(wrap, v2) {
  const options = wrap.data("options");
  options.initOptions.size = v2;
}
const TIP_FOCUS_HIDDEN_KEY = "data-hint-focus-hidden";
const LIST_SHOW_ATTR_KEY = "data-list-show";
const LIST_SHOW_CLASS = "active";
const DOC = $("html");
const listeners = {};
listeners.trigger = function() {
};
listeners.focus = function(evt) {
  const wrap = $(evt.target);
  wrap.addClass(defs.focusCls);
  wrap.data("options").field.addClass("focus");
};
listeners.blur = function(evt) {
  const wrap = $(evt.target);
  const options = wrap.data("options");
  options.field.removeClass("focus");
  wrap.removeClass(defs.focusCls);
};
listeners["item.select"] = function() {
};
listeners.change = function() {
};
listeners.value = function() {
};
listeners.clear = function() {
};
listeners["item.add"] = function() {
};
listeners["data.beforeload"] = function() {
};
listeners["data.load"] = function(evt) {
  const wrap = $(evt.target);
  const options = wrap.data("options");
  if (exists$1(options.value)) {
    selectValue(options.value, wrap);
  }
  if (isOpenMultipleCheckAll(options)) {
    const allOptionCheckedStatus = getAllSelectionStatus(options);
    wrap.data("checkAllStatus", allOptionCheckedStatus);
  }
  updateList(wrap, true);
};
listeners["data.clear"] = function(evt) {
  clearValue($(evt.target));
};
listeners["data.changed"] = function() {
};
listeners["list.scroll"] = function() {
};
listeners["list.downScroll"] = function(evt, options) {
  const wrap = $(evt.target);
  const list = options.list;
  const opt = wrap.data("options").initOptions;
  if (wrap.data("loading")) {
    return;
  }
  const hasSearch = opt.search && opt.searchLoad;
  const searchValue = hasSearch && $(".select-list-search > input", list).val().trim();
  const searchParams = {};
  if (hasSearch && searchValue) {
    searchParams[opt.searchKey] = searchValue;
  }
  const listBody = $(".select-list-body", list)[0];
  const scrollTop = listBody.scrollTop;
  const scrollHeight = listBody.scrollHeight;
  const viewHeight = listBody.clientHeight;
  const childHeight = listBody.firstChild.clientHeight;
  const scrollTotal = wrap.data("scroll-total");
  let scrollCount = wrap.data("scroll-count") || 1;
  const isEnd = scrollTotal && scrollTotal <= scrollCount * opt.scrollNumber;
  if (scrollHeight - scrollTop - viewHeight < childHeight && !isEnd) {
    wrap.data("scroll-count", ++scrollCount);
    $(".select-list-loading", list).removeClass("hidden");
    load(
      wrap,
      function(dirty, ret) {
        wrap.data("options").list.find(".select-list-body").scrollTop(scrollTop);
        hasSearch && $(".select-list-search > input", list).val(searchValue).focus();
        wrap.data("scroll-total", ret && ret.json && ret.json[opt.scrollTotalKey]);
      },
      searchParams
    );
  }
};
listeners["list.show"] = function(evt) {
  const wrap = $(evt.target);
  const $input = wrap.data("options").field;
  if ($input) {
    $input.attr(TIP_FOCUS_HIDDEN_KEY, true);
    $input.attr(LIST_SHOW_ATTR_KEY, true);
    $input.addClass(getPrefixedClassName(LIST_SHOW_CLASS));
  }
  if (wrap.data("doc-attached")) {
    return;
  }
  const initOptions = wrap.data("options").initOptions;
  const list = wrap.data("options").list;
  function willNotCollapse(e) {
    const inInput = $.contains(wrap[0], e.target);
    const noList = !list;
    const isFirst = list[0] === e.target;
    const inList = $.contains(list[0], e.target);
    const isSelectionTip = $(e.target).closest(".v-qtip").hasClass(SELECT_ITEM_TIP_CLS);
    return inInput || noList || isFirst || inList || isSelectionTip;
  }
  const attachMouseWheelFn = function(e) {
    const isPerfectScrollEvent = e.type === "ps-scroll-y" || e.type === "ps-scroll-x";
    const hasScrollDelta = e.deltaY || e.deltaX;
    if (!isPerfectScrollEvent && !hasScrollDelta) {
      return;
    }
    if (willNotCollapse(e)) {
      e.stopImmediatePropagation();
      const lb = $(".select-list-body", list)[0];
      let listScroll = true;
      if (!$.contains(lb, e.target) || initOptions.preventPageScrolling && !lb.scrollTop && e.deltaY > 0) {
        listScroll = false;
      }
      if ((e.deltaY < 0 && lb.scrollHeight - lb.clientHeight) === lb.scrollTop) {
        if (initOptions.scrollLoad) {
          wrap.triggerHandler("list.downScroll", {
            list
          });
          return;
        }
        listScroll = false;
      }
      if (listScroll) {
        wrap.triggerHandler("list.scroll", {
          list
        });
      }
      return;
    }
    collapseList(wrap);
    $input.focus();
  };
  const attachMouseDownFn = function(e) {
    if (willNotCollapse(e)) {
      return;
    }
    collapseList(wrap, () => {
      $input.blur();
    });
  };
  const lastScrollParent = getScrollParent(evt.target);
  wrap.data("doc-attached", {
    mousedown: attachMouseDownFn,
    mousewheel: attachMouseWheelFn,
    scroll: attachMouseWheelFn,
    scrollParent: lastScrollParent
  });
  DOC.mousedown(attachMouseDownFn).mousewheel(attachMouseWheelFn);
  $(window).on("scroll ps-scroll-y ps-scroll-x", attachMouseWheelFn);
  $(lastScrollParent).on("scroll", attachMouseWheelFn);
};
listeners["list.hide"] = function(evt) {
  const wrap = $(evt.target);
  const $input = wrap.data("options").field;
  if ($input) {
    $input.removeAttr(TIP_FOCUS_HIDDEN_KEY);
    $input.removeAttr(LIST_SHOW_ATTR_KEY);
    $input.removeClass(getPrefixedClassName(LIST_SHOW_CLASS));
  }
  const attachFn = wrap.data("doc-attached");
  if (attachFn) {
    if (attachFn.mousedown) {
      DOC.unbind("mousedown", attachFn.mousedown);
    }
    if (attachFn.mousewheel) {
      DOC.unmousewheel(attachFn.mousewheel);
    }
    if (attachFn.scroll) {
      $(window).off("scroll", attachFn.scroll);
      $(attachFn.scrollParent).off("scroll", attachFn.scroll);
    }
    wrap.data("doc-attached", null);
  }
};
listeners["list.click"] = function() {
};
listeners["list.destroy"] = function() {
};
const getSelectDefaultConfig = () => ({
  displayField: "text",
  disabledField: null,
  tipField: null,
  valueField: "id",
  listWidth: null,
  cls: "",
  listWrapCls: "",
  listCls: "",
  listItemCls: "",
  listContentEl: null,
  readOnly: true,
  editable: false,
  commitEditValue: null,
  renderer: null,
  filter: null,
  search: false,
  defaultSearchOptions: {},
  addEmptyItem: true,
  processData: null,
  listeners: null,
  multiple: false,
  groupBy: null,
  ajax: null,
  autoLoad: false,
  forceReload: false,
  autoSelect: void 0,
  keepNotFound: void 0,
  value: void 0,
  beforelisthide: null,
  listExtTpl: "",
  displayTextFormatter: null,
  align: "left",
  offsetX: 0,
  offsetY: 0,
  refuseInvalidValue: false,
  clearOnRefused: false,
  autoSelectOnRefused: false,
  preventPageScrolling: true,
  width: false,
  maxWidth: false,
  beforeSelect: null,
  icon: "",
  searchLoad: false,
  searchKey: "search",
  scrollLoad: false,
  scrollNumber: 50,
  scrollNumberKey: "limit",
  scrollTotalKey: "total",
  selectLimit: null,
  selectLimitText: $i("scp.vt_component.sf_widget.packages.select.src.select.select_limit"),
  tipOffsetX: 50,
  tipOffsetY: 50
});
const attachedFlag = "__fixed_attached";
function create(node, options) {
  var _a, _b, _c, _d;
  const opt = apply({}, options, getSelectDefaultConfig());
  if (opt.multiple) {
    opt.editable = false;
    opt.readOnly = true;
  }
  if (opt.editable) {
    opt.readOnly = false;
  }
  if (opt.search) {
    opt.search = typeof opt.search === "object" ? opt.search : {};
    opt.search = Object.assign(
      {},
      {
        useUTF8Len: (_b = (_a = globalConfig.search) == null ? void 0 : _a.useUTF8Len) != null ? _b : opt.defaultSearchOptions.useUTF8Len,
        limit: (_d = (_c = globalConfig.search) == null ? void 0 : _c.limit) != null ? _d : opt.defaultSearchOptions.limit
      },
      opt.search
    );
  }
  return node.each(function(idx, item) {
    initSelect.call(node, item, opt);
  });
}
function action(arg1, arg2, arg3) {
  const secArgIsStr = typeof arg2 === "string";
  switch (arg1) {
    case "option":
      return this.map(function(i, elem) {
        let el = $(elem);
        if (!el.data(attachedFlag)) {
          return null;
        }
        el = el.parent();
        return !arg2 || !secArgIsStr ? el.data("options") : el.data("options")[secArgIsStr];
      });
    case "value":
      if (arguments.length === 2) {
        return this.each(function(i, elem) {
          const wrap = $(elem).parent();
          selectValue(arg2, wrap);
        });
      }
      return this.map(function(i, elem) {
        const options = $(elem).parent().data("options");
        return options && options.value;
      });
    case "empty":
      return this.each(function(i, elem) {
        const wrap = $(elem).parent();
        clear(wrap);
      });
    case "enable":
      return this.each(function(i, elem) {
        const options = $(elem).parent().data("options");
        if (options.field) {
          options.field.removeAttr("disabled");
        }
        if (options.target) {
          options.target.removeAttr("disabled");
        }
      });
    case "disable":
      return this.each(function(i, elem) {
        const options = $(elem).parent().data("options");
        if (options.field) {
          options.field.attr("disabled", "disabled");
        }
        if (options.target) {
          options.target.attr("disabled", "disabled");
        }
      });
    case "placeholder":
      return this.each(function(i, elem) {
        const options = $(elem).parent().data("options");
        options.field.attr("placeholder", arg2);
      });
    case "load":
      this.each(function(i, elem) {
        const wrap = $(elem).parent();
        let params = arg2, callback = arg3;
        if ($.isFunction(params)) {
          callback = params;
          params = null;
        }
        load(wrap, callback, params || {});
      });
      return this;
    case "status":
      this.each(function(i, elem) {
        const wrap = $(elem).parent();
        const isLoading = arg2 === "loading";
        wrap.data("loaded", !isLoading).data("loading", isLoading);
        wrap.toggleClass(getPrefixedClassName("loading"), isLoading);
      });
      return this;
    case "selectfirst":
      this.each(function(i, elem) {
        selectFirst($(elem).parent());
      });
      return this;
    case "expandList":
      expandList($(this[0]).parent());
      return this;
    case "collapseList":
      collapseList($(this[0]).parent());
      return this;
    case "toggleList":
      toggleList($(this[0]).parent());
      return this;
    case "focusField":
      focusField($(this[0]).parent());
      return this;
    case "destroy":
      return this.each(function(i, elem) {
        const el = $(elem);
        if (!el.data(attachedFlag)) {
          return;
        }
        el.data(attachedFlag, false);
        destroy(el.parent());
      });
    case "size":
      updateSize($(this[0]).parent(), arg2);
      return this;
  }
}
function initSelect(item, cfg) {
  const el = $(item);
  if (el.data(attachedFlag)) {
    return false;
  }
  if (el.is("input[type=hidden]")) {
    el.attr("type", "text");
  }
  el.data(attachedFlag, true);
  el.addClass(getPrefixedClassName("select_target"));
  const wrappedEl = el.wrap(createSelect(el, cfg));
  if (cfg.clearable) {
    wrappedEl.after(createClearDom());
  }
  wrappedEl.after(createCaret()).after(createInput(el, cfg));
  const selectWrap = el.parent();
  const options = {};
  options.initOptions = cfg;
  options.target = el.css("opacity", 0);
  options.field = selectWrap.children(".select_trigger");
  options.trigger = selectWrap.children("span.caret");
  options.clearBtn = selectWrap.children("span.clearable");
  options.list = null;
  if (options.groupBy) {
    options.groupBy = groupBy(options.groupBy);
  }
  if (exists$1(cfg.value)) {
    options.value = cfg.value;
  }
  selectWrap.data("options", options);
  if (cfg.multiple && cfg.showCheckAll) {
    selectWrap.data("checkAllStatus", ALL_OPTION_CHECK_STATUS.NONE);
  }
  resizeWrap(selectWrap);
  $.each(listeners, function(key, val2) {
    selectWrap.bind(key, val2);
  });
  if (cfg.listeners) {
    $.each(cfg.listeners, function(key, val2) {
      selectWrap.bind(key, val2);
    });
  }
  options.trigger.click(clickTrigger).hover(
    function() {
      selectWrap.data("trigger.hover", true);
    },
    function() {
      selectWrap.data("trigger.hover", false);
    }
  );
  selectWrap.hover(
    function() {
      selectWrap.data("wrap.hover", true);
    },
    function() {
      selectWrap.data("wrap.hover", false);
    }
  );
  options.clearBtn.click(function() {
    hoverOutInput.call(el);
    action.call(el, "value", "");
  });
  options.field.focus(focusInput).blur(blurInput).click(clickInput);
  if (cfg.clearable) {
    selectWrap.hover(hoverInInput.bind(el), hoverOutInput.bind(el));
  }
  const mouseDownFn = (e) => {
    const isClickingTip = !!$(e.target).closest(".v-tip").length;
    if (isClickingTip) {
      selectWrap.data("tip-clicking", true);
      setTimeout(() => {
        selectWrap.data("tip-clicking", false);
      }, 100);
      return;
    }
    handlerSelectBlur(selectWrap, e);
  };
  selectWrap.data("mouseDownFn", mouseDownFn);
  document.documentElement.addEventListener("mousedown", mouseDownFn, true);
  if (cfg.editable) {
    options.field.keydown(function(e) {
      if (e.keyCode === 13) {
        blurInput.call(this, true);
        $(this).blur();
      } else {
        $(this).prop("dirty", true);
      }
    });
  }
  const autoSelect = cfg.autoSelect !== false;
  if (cfg.data) {
    load(
      selectWrap,
      function() {
        if (!exists$1(options.value) && autoSelect) {
          selectFirst(selectWrap);
        }
      },
      cfg.data
    );
  } else if (cfg.autoLoad) {
    load(selectWrap, function() {
      if (!exists$1(options.value) && autoSelect) {
        selectFirst(selectWrap);
      }
    });
  } else if (!cfg.ajax && autoSelect) {
    load(selectWrap, function() {
      if (!exists$1(options.value)) {
        selectFirst(selectWrap);
      }
    });
  }
}
function handlerSelectBlur(selectWrap, e) {
  var _a;
  const options = selectWrap.data("options");
  const isClickExpanding = selectWrap.data("__clickExpanding") === true;
  const isClickInWrap = $.contains(selectWrap[0], e.target);
  if (isClickExpanding && !isClickInWrap) {
    (_a = options == null ? void 0 : options.loadDefer) == null ? void 0 : _a.abort();
  }
}
function clickTrigger() {
  const selectWrap = $(this).parent();
  selectWrap.data("__clickExpanding", true);
  doTrigger(selectWrap);
}
function destroy(wrap) {
  collapseList(wrap);
  destroyList(wrap);
  const options = wrap.data("options");
  if (options) {
    const cfg = options.initOptions;
    if (cfg && cfg.listeners) {
      $.each(cfg.listeners, function(key, val2) {
        wrap.unbind(key, val2);
      });
    }
    if (cfg) {
      cfg.listParent = null;
      cfg.listeners = null;
      cfg.beforelisthide = null;
      cfg.beforeSelect = null;
      cfg.commitEditValue = null;
      cfg.displayTextFormatter = null;
      cfg.listContentEl = null;
      Object.keys(cfg).forEach((key) => {
        if (typeof cfg[key] === "function") {
          cfg[key] = null;
        }
      });
    }
    if (options.trigger) {
      options.trigger.unbind().remove();
    }
    if (options.clearBtn) {
      options.clearBtn.unbind().remove();
    }
    if (options.field) {
      options.field.unbind().remove();
    }
    options.records = null;
    options.value = null;
    options.list = null;
    options.initOptions = null;
    options.target = null;
    options.field = null;
    options.trigger = null;
    options.clearBtn = null;
  }
  wrap.unbind();
  const mouseDownFn = wrap.data("mouseDownFn");
  if (mouseDownFn) {
    document.documentElement.removeEventListener("mousedown", mouseDownFn, true);
  }
  wrap.removeData();
  wrap.data("destroyed", 1);
  wrap.find("select").unwrap();
  if (options && options.loadDefer) {
    options.loadDefer.abort();
  }
}
function focusInput() {
  $(this).parent().triggerHandler("focus");
}
function blurInput(forceBlur) {
  const field = $(this);
  const wrap = field.parent();
  const eventMarks = [
    "block-blur",
    "list.hover",
    "trigger.hover",
    "wrap.hover",
    "tip-clicking"
  ];
  if (forceBlur !== true && hasWrapDataMark(wrap, eventMarks)) {
    return;
  }
  const options = wrap.data("options");
  const initOptions = options.initOptions;
  if (initOptions.editable && field.prop("dirty")) {
    const newValue = $.trim(field.val());
    const interceptor = initOptions.commitEditValue;
    if (!$.isFunction(interceptor) || false !== interceptor(newValue)) {
      selectValue(newValue, wrap);
    }
  }
  collapseList(wrap);
  field.removeData("bluring").prop("dirty", false);
  wrap.data("trigger.hover", false).triggerHandler("blur");
}
const hasWrapDataMark = (wrap, marks) => {
  return !!marks.find((mark) => {
    return !!wrap.data(mark);
  });
};
function clickInput() {
  const $input = $(this), wrap = $input.parent();
  if (!$input.is("input") || this.readOnly) {
    wrap.data("__clickExpanding", true);
    doTrigger(wrap);
  }
}
function isReactHoverEvent() {
  const data = action.call(this, "value")[0];
  const hasValue = !lang.isEmpty(data == null ? void 0 : data.value);
  const isDisabled = this.attr("disabled");
  return hasValue && !isDisabled;
}
function hoverInInput() {
  if (isReactHoverEvent.call(this)) {
    const options = this.parent().data("options");
    options.clearBtn.show();
    options.trigger.hide();
  }
}
function hoverOutInput() {
  if (isReactHoverEvent.call(this)) {
    const options = this.parent().data("options");
    options.clearBtn.hide();
    options.trigger.show();
  }
}
function doTrigger(wrap) {
  const input = wrap.children(".select_trigger");
  if (input.is("[disabled]")) {
    return false;
  }
  const isInputFocus = input.is(":focus");
  if (!isInputFocus) {
    input.focus();
  }
  toggleList(wrap);
  wrap.triggerHandler("trigger");
}
function fixselect(arg1) {
  const firstArgType = typeof arg1;
  if (!arg1 || firstArgType === "object") {
    return create(this, arg1);
  } else if (firstArgType === "string") {
    return action.apply(this, arguments);
  }
}
export { fixselect };
