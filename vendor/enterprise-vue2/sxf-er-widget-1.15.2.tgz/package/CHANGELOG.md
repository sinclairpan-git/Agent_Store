# @sxf/er-widget

## 1.15.2 (2026-01-27)

### Patch Changes

- e7c8d051: fix(widget:grid): 修复页面销毁瞬间列表组件报错问题

## 1.15.1 (2026-01-21)

### Patch Changes

- 43a63233: feat(comp:cover-window,comp:window,comp:tab,comp:nav-menu,comp:alert-list,widget:tab,widget:window,pro:page-steps,pro:transfer-selecat): 修正组件库 utid

## 1.15.0 (2026-01-09)

### Minor Changes

- 51c205dc: refactor: 组件内部声明的 utid 属性支持拼接使用组件时传入的 utid 属性

## 1.14.1 (2025-12-26)

### Patch Changes

- 79ee385b: feat(widget:grid): 修复列表的 diffData 问题以及支持全局配置列表 store
- 1ade4a52: feat(widget:grid) 列表高度不变更的情况下跳过高度设置

## 1.14.0 (2025-12-25)

### Minor Changes

- 766c3b79: feat: 处理组件库内存泄漏问题

### Patch Changes

- Updated dependencies [766c3b79]
  - @sxf/er-utils@1.4.0

## 1.13.2 (2025-12-10)

### Patch Changes

- 7a55975d: fix(comp:grid): 表格最后一列 rowspan 的样式错乱修正

## 1.13.1 (2025-11-13)

### Patch Changes

- 4176d2d0: fix(widget:grid): 修复树形表格清除选中状态时引用错误对象的问题
- feat(comp/widget/pro): 支持设置自定义 utid

## 1.13.0 (2025-10-29)

### Minor Changes

- 7ce2c84e: feat(widget:group):表格分组插件增加懒加载子节点功能

### Patch Changes

- a90ccc41: fix(widget:select): 修复下拉选项列表展开状态未按预期收起的问题

## 1.12.3 (2025-10-22)

### Patch Changes

- sync: 6112 改动合入主线发版

## 1.12.2 (2025-10-21)

### Patch Changes

- eb39ea19: fix(comp:grid): 修复树形表格单选模式下选择状态清除错误的问题
- afbc9b8c: fix(widget:select): 修复点击弹窗内下拉框判断为持续展开的问题

## 1.12.1 (2025-09-15)

### Patch Changes

- 2887a2c7: fix(widget:select): 修复本地过滤时无数据提示显示逻辑

## 1.12.0 (2025-09-02) (2025-09-02)

### Minor Changes

- 95151b54: feat(comp: select): 添加下拉框分组全选功能

### Patch Changes

- Updated dependencies [caaadbb0]
  - @sxf/er-utils@1.3.0

## 1.11.0 (2025-07-18)

### Minor Changes

- chore: 统一更新主线版本

### Patch Changes

- f172d51b: 优化全选选项的禁用状态处理
- 945344c7: fix(select): 修复点击提示时下拉框意外关闭的问题
- f6cf3631: 在分组表格中，对于没有子项的行，添加一个类名，并增加背景色白色的样式表
- 4374e205: feat(widget:grid): 为表格行添加唯一标识属性
- 661a36ea: feat(select): 1.补充遗漏 less 2.修复前缀图片被挤没了 3.修复已选择悬浮 tip 将塞入的 dom 节点渲染成文本

## 1.10.2 (2025-05-20)

### Patch Changes

- a0c9b9c4: fix(comp-select): 修复 jq 场景下的 select 组件缺失 tip 默认值导致悬浮提示异常的问题

## 1.10.0-xaas-patch.4 (2025-05-07)

### Patch Changes

- 07d37e36: feat(comp:combo): 增加 clearable 属性和 clear 事件
  feat(widget:combo): 增加 clearable 属性和 clear 事件

## 1.10.0-xaas-patch.3 (2025-04-15)

### Patch Changes

- e2c48273: fix(widget:grid): 修复手动触发 loading 状态表格存在固定列阴影没隐藏的问题

## 1.10.0-xaas-patch.2 (2025-03-20)

### Patch Changes

- 64a62909: fix(widget:grid): 修复树表格配置前缀后无法展开收起

## 1.10.0-xaas-patch.1 (2025-03-19)

### Patch Changes

- chore: 合入 xaas 变更后更新版本号，统一升级

## 1.7.0-scp-6112-patch.1 (2025-09-26)

### Minor Changes

- e5eeb383: feat(widget:grid): 表格插件 plugins 的 Group 插件，增加配置 isHideGroupColumnWhenNoGroup

### Patch Changes

- a5f0d289: fix(widget:treeSelect): 修复树形下拉框在鼠标悬浮在下拉框进行滚动时候，浮窗没有关闭的问题。

## 1.7.0-scp-6111-patch.47 (2025-04-21)

### Patch Changes

- de88e22a: fix(widget:tip): 修复 tip 直接监听 dom 滚动事件导致不合理的触发隐藏

## 1.7.0-scp-6111-patch.46 (2025-04-18)

### Patch Changes

- 1678f327: fix(widget:select): 修复被 sf-scrollbar 包裹后，页面滚动时下拉框浮层不隐藏

## 1.7.0-scp-6111-patch.45 (2025-04-11)

### Patch Changes

- b652acd4: fix(widget:grid): 修复手动触发 loading 状态表格存在固定列阴影没隐藏的问题

## 1.7.0-scp-6111-patch.44 (2025-04-07)

### Patch Changes

- 5bc2eab3: feat(widget:grid): 优化列宽调整功能

  定义：列 A = 非操作列的最后一列

  1. 拖拽的时候，会将宽度分配给 列 A

     - 向左拖会增大 列 A 的宽度
     - 向右拖会减少 列 A 的宽度
     - 列 A 最小宽度为 `96px`

  2. 默认情况下列的最小拖拽宽度为 40px，除非业务有设置列的 minWidth

  3. 操作列、列 A 不可拖动（除非只剩下两列的情况）

  4. 拖拽后的列，在排序、窗口大小改变等情况会保留拖拽后的列宽

  5. 增大鼠标悬浮上去的拖拽范围（原来的 2px 调整为 6px）

  6. 减少自定义列的宽度 （32px -> 24px）

## 1.7.0-scp-6111-patch.43 (2025-03-20)

### Patch Changes

- b560e24d: fix(widget:grid): 修复树表格配置前缀后无法展开收起

## 1.7.0-scp-6111-patch.42 (2025-03-14)

### Patch Changes

- 96d26cc8: fix(widget:messageBox):补充 messageBox 中添加样式前缀的逻辑

## 1.7.0-scp-6111-patch.41 (2025-03-13)

### Minor Changes

- 96daaed5: refactor(comp:select): 支持样式类名前缀配置并迁移至 LESS
- 579d6d36: refactor(comp:combo): 支持样式类名前缀配置并迁移至 LESS
- 03309e30: refactor(widget:mask): 支持样式类名前缀配置并优化样式文件结构
  widget 下增加自定义 class 前缀支持，\_global/mask/style 增加 less 前缀变量，components/loading 增加前缀自动化用例
- 16a47a48: refactor(comp:tree-select): 支持样式类名前缀配置并迁移至 LESS
- ba7008d6: refactor(comp:grid): 支持样式类名前缀配置并迁移至 LESS
- ab2dc999: refactor(comp:tabs): widget/tabs、comp/tabs 支持样式类名前缀配置并优化样式文件结构
- e9d118e1: refactor(comp:step): 支持样式类名前缀配置并迁移至 LESS
- a5044929: feat(comp:\*): 组件全局配置改为从 feature 包中获取
- 478c25ee: refactor(comp:window): 支持样式类名前缀配置并迁移至 LESS
- b36cd956: refactor(widget:window): windowMgr 作为 utils 包的独立模块对外提供
- 788b8a24: refactor(comp:tree): 支持样式类名前缀配置并迁移至 LESS
- fea0efd5: refactor(comp:trigger): 支持样式类名前缀配置并迁移至 LESS

## 1.10.0-scp-6112-patch.3 (2025-03-04)

### Patch Changes

- 4e3f0db9: fix(comp:grid): 自定义列插件的单元格 rowspan 与最后一列的 rowspan 保持一致

## 1.10.0-scp-6112-patch.2 (2025-02-20)

### Patch Changes

- 4fcbd803: fix: 修复 checkNoNotify 逻辑容错
- Updated dependencies [4fcbd803]
  - @sxf/er-utils@1.1.0

## 1.10.0-scp-6112-patch.1 (2025-02-20)

### Patch Changes

- 202cc597: fix: 修复高版本控制台报错问题

## 1.10.1 (2025-03-04)

### Patch Changes

- 7c2b0e41: fix(comp:tree): 修复 tree-table 收起时无法自动隐藏 menu 的 bug
- 30792309: fix(comp:select): 修复 Select 组件 placeholder 无法动态修改的问题

## 1.10.0 (2025-02-13)

### Minor Changes

- 14788914: chore: 更新主线包发布版本号

### Patch Changes

- dbd0f03e: feat: release/scc-devops 分支合入主线更新版本号

## 1.9.0 (2024-12-19)

### Minor Changes

- f755b276: feat: 添加 select 组件选中是否展示前缀图片配置

### Patch Changes

- 3c9b454e: fix: 修复 select 用例报错
- f41befee: fix(comp:popover): 修复有悬浮提示时某些情况下点击页面控制台报错
- d79a5a3f: fix(widget:select): 修复 select 组件中 HTML 特殊字符导致组件渲染异常

## 1.8.1 (2024-11-26)

### Patch Changes

- 6bc705ea: fix(comp:popover,tooltip): 修复有悬浮提示时某些情况下点击页面控制台报错

## 1.8.0-aipaas-patch.4 (2024-11-27)

### Minor Changes

- 0993fbd0: feat(widget:tooltip): 新增允许配置自定义样式类

## 1.8.0-aipaas-patch.3 (2024-11-20)

### Minor Changes

- 889f4dde: feat: 添加下拉框前缀类型属性配置

### Patch Changes

- e56741ec: fix(comp:select): 调整 Select 下拉框, 满足 x6 节点放大缩小的场景

## 1.8.0-aipaas-patch.2 (2024-11-18)

### Minor Changes

- e1deaab8: feat: select 添加前缀图片配置

## 1.8.0-aipaas-patch.1 (2024-11-08)

### Minor Changes

- 16cadcf9: feat(comp:grid): 支持表格头部右侧自定义内容

## 1.8.0-scc-devops-patch.3 (2024-12-31)

### Patch Changes

- 86b32bea: feat(widget:grid): 补充 ts 声明和 API 文档说明
- 29f2cf4b: fix(widget:grid): 修复列宽更新问题

## 1.8.0-scc-devops-patch.2 (2024-12-29)

### Minor Changes

- 72ac514f: feat(widget:grid): 支持一次仅展开一个详细信息

## 1.8.0-scc-devops-patch.1 (2024-12-06)

### Patch Changes

- 3a400b45: fix(widget:grid): 修复嵌套表格场景下，内部表格滚动条和外部表格滚动条之间的冲突

## 1.8.0 (2024-10-28)

### Minor Changes

- 6634213b: feat(comp:tabs):tabs 组件新增 animation 属性
- 70c48878: fix(pro:transfer-select): 支持非法数据触发 select 回显至右侧已选表格
- 189c2d3b: feat(comp:treeTable):treeTable 组件新增 tree-item-hover 事件

### Patch Changes

- aadc4668: feat(widget:notify): 限制消息堆叠高度并添加滚动条

## 1.7.0-scp-6111-patch.40 (2025-01-07)

### Minor Changes

- d1f27830: refactor: scrollManager 移动到 utils 包 dom 目录下对外导出
- 40287701: fix(comp:tree-select): 修复 tree 插件计算错误的问题

## 1.7.0-scp-6111-patch.39 (2025-01-06)

### Patch Changes

- 683b76be: fix(widget:grid): 修复 autoFit 列在 sortable 场景下的重叠问题
- e041999d: fix(widget:grid): 修复 autoFit 列在 slot 场景下的宽度计算问题
- 983ae682: fix(widget:grid): 修复 resizeable 插件在所有列固定时的行为

## 1.7.0-scp-6111-patch.38 (2025-01-05)

### Patch Changes

- 0b5a1213: fix(grid): 修复表格数据刷新会导致更多菜单消失或者显示错误菜单内容

## 1.7.0-scp-6111-patch.37 (2025-01-04)

### Patch Changes

- 8fa9b943: feat(comp:window): 支持过滤 '[er-no-notify]' 前缀
- ddd41397: fix(widget:grid): 切换 tab 后 mask 置空
- ddd41397: fix(widget:tab): 异常处理：const key = $(this).attr('data-href');tabs 插件中的 key 是 undefined

## 1.7.0-scp-6111-patch.36 (2025-01-04)

### Patch Changes

- 30eb278e: fix(widget:tab): 异常处理：const key = $(this).attr('data-href');tabs 插件中的 key 是 undefined
- 30eb278e: fix(widget:grid): 切换 tab 后不用立即将 mask 置空，在 destroy 中去将 mask 置空

## 1.7.0-scp-6111-patch.35 (2025-01-03)

### Patch Changes

- fe418dec: fix(widget:tooltip): 修复悬浮 tip 边界溢出判断逻辑

## 1.7.0-scp-6111-patch.34 (2025-01-03)

### Patch Changes

- 4e6b9fa1: fix(comp:grid): 修复表格横向滚动条显示逻辑

## 1.7.0-scp-6111-patch.33 (2025-01-02)

### Patch Changes

- ad35fc6d: fix(widget:tooltip): 修复悬浮 tip 边界溢出问题 (#728)
- 26472e3f: fix(comp:grid): 修复表格横向滚动条宽度计算问题

## 1.7.0-scp-6111-patch.32 (2024-12-31)

### Patch Changes

- 69b4af4f: fix(widget:tooltip): 修复 tooltip 组件横向溢出判断逻辑

## 1.7.0-scp-6111-patch.31 (2024-12-30)

### Minor Changes

- b44ee702: fix(comp): 统一整改内存泄露问题

### Patch Changes

- aa85ca25: feat(comp:grid): 新增方法 支持修改自定义列的顺序

## 1.7.0-scp-6111-patch.30 (2024-12-26)

### Patch Changes

- 857a0e29: fix(comp:step): 去除 step 组件的 clearfix 类

## 1.7.0-scp-6111-patch.29 (2024-12-25)

### Patch Changes

- 03192f67: fix(widget:grid): 修复表格横向滚动条计算兼容性问题

## 1.7.0-scp-6111-patch.28 (2024-12-25)

### Minor Changes

- ce148144: feat: page-tabs 增加 defaultExpandAll 属性以支持默认展开所有标签页

## 1.7.0-scp-6111-patch.27 (2024-12-25)

### Patch Changes

- 11180478: fix(widget:tooltip): 修复内容更新时提示信息错误显示的问题

## 1.7.0-scp-6111-patch.26 (2024-12-24)

### Minor Changes

- 1ea568d7: feat(widget:notify): 增加关闭操作回调功能 & 优化 er-no-notify 逻辑

## 1.7.0-scp-6111-patch.25 (2024-12-21)

### Minor Changes

- 29504756: feat(notify): 扩展通知功能，支持自定义徽标和静默通知

### Patch Changes

- 3035cc5f: fix(widget:grid): 修复表格列宽分配与固定列相关问题

## 1.7.0-scp-6111-patch.24 (2024-12-21) (2024-12-21)

### Patch Changes

- 7d038cb6: fix(widget:grid): 修复表格 tip 插槽在使用自定义列插件时会错误渲染的问题

## 1.7.0-scp-6111-patch.23 (2024-12-19)

### Patch Changes

- cbd002ae: fix(comp:grid): 修复表格只剩下固定列的场景下的拖动问题

## 1.7.0-scp-6111-patch.22 (2024-12-19)

### Patch Changes

- fc85ebc6: feat(comp:grid): 增加表格加载遮罩功能

## 1.7.0-scp-6111-patch.21 (2024-12-18)

### Minor Changes

- 61d944be: feat(pro:page-tabs): 支持自定义 label 插槽

## 1.7.0-scp-6111-patch.20 (2024-12-17)

### Patch Changes

- dcb6d1f4: fix(comp:grid): 修复隐藏状态下表格列宽计算问题

## 1.7.0-scp-6111-patch.19 (2024-12-16)

### Patch Changes

- dfbec95c: feat(widget:mask): mask 支持 globalConfig 全局配置 defer
- dd8ac77c: fix(widget:grid): 修复列宽计算时的元素判空问题

## 1.7.0-scp-6111-patch.18 (2024-12-14)

### Patch Changes

- 3e8c61e2: fix(widget:grid): 修复批量应用样式时的判空问题

## 1.7.0-scp-6111-patch.17 (2024-12-13)

### Patch Changes

- 506e0a90: fix(widget:tooltip): 修复滚动时 tip 被不合理的隐藏，限制执行范围
- 4a8e3c23: fix(comp:grid): 确保未自适应列宽时也调用

## 1.7.0-scp-6111-patch.16 (2024-12-12)

### Patch Changes

- b38696cc: fix(comp:grid): 优化表格列自适应和固定列性能

## 1.7.0-scp-6111-patch.15 (2024-12-07)

### Minor Changes

- 0f2e7e37: feat(notify)：添加 er-webc-\*的转换规则

### Patch Changes

- Updated dependencies [0f2e7e37]
  - @sxf/er-utils@1.1.0

## 1.7.0-scp-6111-patch.14 (2024-12-04)

### Minor Changes

- e21baeb3: feat(comp:tabs): tab 组件暴露 hover 事件

## 1.7.0-scp-6111-patch.13 (2024-11-30)

### Patch Changes

- 7a6cab45: feat(widget:notify): 限制消息堆叠高度并添加滚动条

## 1.7.0-scp-6111-patch.12 (2024-11-28)

### Patch Changes

- 84a8fd1c: fix: 补充表格展开异常处理&自定义项销毁异常处理

## 1.7.0-scp-6111-patch.11 (2024-11-27)

### Minor Changes

- b6fc08ef: feat(widget:grid): 增加分组单选表格选中功能

### Patch Changes

- bff16d6a: feat(widget:grid): 更新表格初始化加载时的 loading 效果

## 1.7.0-scp-6111-patch.10 (2024-11-23)

### Patch Changes

- 093e6863: fix(widget:grid): 修复 resizeable 插件在固定列情况下的计算错误

## 1.7.0-scp-6111-patch.9 (2024-11-23)

### Patch Changes

- 54a02f2d: fix(widget:grid): 修复无数据时固定列的显示问题
- 1c55ea8a: fix(widget:grid): 修复 resizeable 插件在自定义列的情况下计算错误
- f8d543b1: fix(widget:grid): 修复 resizeable 插件在固定列情况下的计算错误

## 1.7.0-scp-6111-patch.8 (2024-11-22)

### Patch Changes

- 9e99f836: feat(comp:tree): 增加节点滚动和加载子节点功能

  - 增加 scrollToNode 方法，支持滚动到指定节点并根据选项展开或激活节点。
  - 增加 shouldLoadNodeChildren 配置项，用于判断是否需要加载节点的子项。

## 1.7.0-scp-6111-patch.7 (2024-11-20)

### Minor Changes

- 68f69e9f: feat(comp:select): 调整下拉框选项文本超长时的显示效果 改为溢出省略+悬浮提示
- 05bdad0b: feat(comp:combo): 添加搜索规范

## 1.7.0-scp-6111-patch.6 (2024-11-13)

### Minor Changes

- 25732f78: tab 组件添加悬浮气泡提示

### Patch Changes

- ec50b8e7: fix(comp:tabs): 修复手动调用 active 方法时的激活状态错误

## 1.7.0-scp-6111-patch.5 (2024-11-10)

### Patch Changes

- 6cb9806b: fix(comp:tabs): 修复 beforeHandler 异步拦截逻辑

## 1.7.0-scp-6111-patch.4 (2024-11-09)

### Patch Changes

- d9559b0a: fix(comp:tabs): 修复 beforeHandler 异步拦截逻辑

## 1.7.0-scp-6111-patch.3 (2024-11-08)

### Patch Changes

- 4bad1618: fix(comp:tabs): 修复 beforeHandler 参数传递错误

## 1.7.0-scp-6111-patch.2 (2024-11-08)

### Minor Changes

- ce44b955: feat(pro:page-tabs): 支持 tab 切换拦截功能

### Patch Changes

- 6a8a3a12: fix(comp:tabs): 修复 beforeHandler 测试用例错误

## 1.7.0-scp-6111-patch.1 (2024-10-31)

### Minor Changes

- 6634213b: feat(comp:tabs):tabs 组件新增 animation 属性
- 70c48878: fix(pro:transfer-select): 支持非法数据触发 select 回显至右侧已选表格
- 70390b01: feat(pro:page-tabs): 添加 page-tabs content 类型
- 189c2d3b: feat(comp:treeTable):treeTable 组件新增 tree-item-hover 事件

### Patch Changes

- fb7373a0: 修复分组表格开启 colspan 配置搭配自定义列使用，表格项对齐问题

## 1.7.0 (2024-10-18)

### Minor Changes

- ad3c9a9a: feat(widget:grid): 分组插件新增 expand,expandAll,collapse,collapseAll,change 几个事件

### Patch Changes

- 710e1f02: ## '@sxf/er-widget': patch

  fix(widget:grid): 修复云主机设置勾选值。明明页面没有勾选了。但是 getSelections()还是能获取到勾选值

- 6ad96c2a: fix(widget:grid): 修复 group 插件需要勾选 2 次才能取消的问题
- 399d7598: fix(widget:grid): 修复树形分组表格，勾选父组，然后进行刷新，获取 getSelections()的结果会去掉父组的问题

## 1.6.5 (2024-09-29)

### Patch Changes

- dd84bb35: fix(widget:grid):给 Group 插件提供获取分组展开/收起状态函数：getGroupToggleIconStatus

## 1.6.4

### Patch Changes

- ce1e24bc: fix(widget:window): 修复 options.maxHeight 为负数的问题

## 1.6.3 (2024-09-11)

### Patch Changes

- cc4643ca: fix(widget:grid): 处理 ceilTip 为 true 时，替换空格时未考虑空值的情况

## 1.6.2 (2024-09-10)

### Patch Changes

- 743c1f2e: fix(widget:grid): 修复 tip 为 true 的时候，tip 英文单词被截断的问题
- Updated dependencies [8ab40be1]
  - @sxf/er-config@1.2.2
  - @sxf/er-lib@1.0.1
  - @sxf/er-utils@1.0.5

## 1.6.1 (2024-08-28)

### Patch Changes

- e05dad89: fix(widget:tree): 修复 FireFox 下, transfer-select 树节点文本不显示的问题

## 1.6.0 (2024-08-26)

### Minor Changes

- 7eb91fe4: feat(widget:tree): 在 widget 中增加树节点彩色图标的支持， 在 component 中增加 Symbol 彩色图标的样式

### Patch Changes

- 974a756e: fix(widget:select): 修复 fixselect 全选显示空的问题

## 1.5.2 (2024-08-23)

### Patch Changes

- 42c4975f: fix(comp:grid): 修复多选分组表格中分组行不可选时样式有误

## 1.5.1 (2024-08-22)

### Patch Changes

- a3ab6506: fix(widget:grid): 修复树形表格由于宽度溢出导致在 FireFox 下显示异常

## 1.5.0 (2024-08-22)

### Minor Changes

- fcbb1c2a: feat(widget:grid): Group 插件新增 groupOnlyField 配置，用于标识是否将数据项只作为分组

### Patch Changes

- d10ab6cf: feat(comp:popover): 新增 appendToBody 配置，配置 false 时 tip 被创建到当前的父级
- 06ee7795: fix(widget:window): 修复 messagebox 类弹窗出现两种滚动条的问题
- a8f442cf: fix(comp:grid): 调整树形表格样式，修复分组行缩进问题 #459
- Updated dependencies [a381787a]
  - @sxf/er-config@1.1.1

## 1.4.2 (2024-08-16)

### Patch Changes

- d926bc8c: feat(widget:select): 远程加载请求失败时，搜索下拉框展示 `暂无数据`

## 1.4.1 (2024-08-15)

### Patch Changes

- b559c64e: fix(widget:grid): 修复使用 Group 插件后表格 store 中 selectedIDs、selectedHash 会残留已删除的数据

## 1.4.0 (2024-08-14)

### Minor Changes

- b81b53f9: feat(widget:grid): store 新增 diffData 配置，用于判断数据是否更新，减少重复渲染

## 1.3.1 (2024-08-12)

### Patch Changes

- b8747506: fix(widget:select): 修复多选情况数量匹配机制问题

## 1.3.0 (2024-08-09)

### Minor Changes

- 3e3b5946: feat(pro:page-tabs): 新增侧栏展开收起功能，依赖 @sxf/vtv-icon@1.0.181 及 @uedc/sf-layout@1.6.0

### Patch Changes

- e1db866c: fix(widget:grid): 修复分组表格在使用 Resizeable 插件时会出现异常的横向滚动条
- 1b16bd52: fix(widget:select): 修复初始化回填全选时 tag 没有隐藏

## 1.2.0 (2024-08-05)

### Minor Changes

- 34efacf9: feat(widget:grid): checkSelection/radioSelection 插件添加 beforeSelect 配置

## 1.1.1 (2024-08-01)

### Patch Changes

- fe7e3406: fix(comp:select): 修复远程加载时全选显示异常

## 1.1.0 (2024-07-29)

### Minor Changes

- 6073c06b: feat(comp:tree-table): 新增事件，事件名和 tree 保持一致

  - hand-toggle-group 点击节点按钮展开/收起触发
  - hand-toggle-all-group 点击全部展开/全部收起按钮触发
  - fn-toggle-group 调用展开/收起方法触发
  - fn-toggle-all-group 调用全部展开/全部收起方法触发

## 1.0.7 (2024-07-19)

### Patch Changes

- c8eef378: fix(widget:select): 修复远程搜索配合多选使用场景下，选中的值会被重置
- b3ad8355: fix(widget:grid): 移除表格头筛选时添加的 current-filter-show 类名

## 1.0.6 (2024-07-08)

### Patch Changes

- f5cc4a35: fix(widget:select): 修复选择器标签模式下显示异常，issue413

## 1.0.5 (2024-07-02)

### Patch Changes

- ea5c25ad: fix(widget:select): 修复选择器在开启全选、远程加载数据为空时打开面板报错
- ea5c25ad: fix(comp:window): 修复弹窗 no-close 配置不支持响应式

## 1.0.4 (2024-06-07)

### Patch Changes

- 8f85e285: fix(widget:grid): 修复点击 Detail 插件的展开收起按钮会触发表格选中

## 1.0.3 (2024-06-06)

### Patch Changes

- e39f5f05: fix(widget:select): 修复 select 选择下拉选项的 id 为 0 时，组件的清空功能失效的问题

## 1.0.2 (2024-06-01)

### Patch Changes

- 8b9487c0: fix(widget:select): 修复搜索无数据时搜索框消失
- c1f14608: fix(widget:select): 修复滚动加载失去焦点，但是下拉框边框还是蓝色的
- 52243bfb: fix(widget:grid):修复表格初始化不设置默认数据会导致空数据状态没有背景颜色
- Updated dependencies [8b9487c0]
  - @sxf/er-config@1.1.0

## 1.0.1 (2024-05-16)

### Patch Changes

- 91824af6: fix(comp:grid): 修复 tree-table tree-table-select 样式异常

## 1.0.0 (2024-05-13)

### Major Changes

- 7875a24a: feat: eresh1.0 正式版发布

### Minor Changes

- 9ab15bd4: feat(widget:grid): selection 组件新增以 selectedHash 为标识，实现服务端跨页勾选且回显
- 340fbf0a: feat(comp:select): SfSelect 支持多选结果以标签显示
- ccb9d0b1: feat(comp:select): 选择器搜索框新增图标，样式调整
- ab8d5223: fix(comp:grid):给 grid 头部支持筛选过滤
- 2068d4e7: feat(comp:grid): 表格 Pagingbar 插件使用 SfPagination 组件
- afc6eefe: feat(comp:grid): 表格分页器插件由从 components 包对外导出

  - **Breaking:** Pagingbar 插件无法从 `@sxf/er-widget/grid` 中获取，升级时需要业务同步替换原来的引用路径为 `import { PagingBar } from '@sxf/er-components/grid'`

- b9af929b: feat(comp:select): 选择器下拉框添加“新增”按钮,调整选择器分组的分割线样式
- 4fc7947f: feat(widgt:tab): 增加 tab 嵌套支持
- 974a4171: feat(widget:grid): plugins 新增树选择组件多选框相关处理
  feat(widget:comboGrid): 新增树选择组件多选操作和事件内容
- cc37b1aa: feat(widget:tooltip): dataTip 支持隐藏小三角；最大宽度调整

  - error 样式下最大宽度调整为 480
  - 普通样式下最大宽度调整为 320

- 9099a218: feat(comp:combo): combo 支持多选标签显示模式
- 178e5a4b: feat (widget: grid) 修改表格 sortable 里面的 clearSortCfg 方法，补充远程排序时候需要清空表格的排序参数的逻辑
- d2607c2b: feat(comp:grid): 分组表格展开收起按钮单独占用一列
- f53b15b0: feat(comp:tabs): 标签页新增投影卡片类型

  - `type` 新增 `projection-card` 类型，为无边框的投影卡片标签页

- 2327d438: steps 步骤条组件新增错误样式

### Patch Changes

- 2af59f99: fix(comp:select): 调整 select 的触发选中的元素
- 2a3e4504: fix: (widget: select) 修复 select 下拉框新增按钮配置的时候，无法点击卡死页面问题
- 27619a2f: fix(comp:select):修改 select 新增按钮样式使其居中，对 select 增加 size 的动态响应
- 42a5301a: fix(widget:select): 修复 select 滚动加载搜索时没有重置 limit
- 9ba2738b: feat(widget:grid): grid 的自动 mask 默认改为水展示
- 2ce08330: fix(comp:steps): 修复步骤条图标错误和调整样式
- 4dcd108d: fix(widget:notify):修复 feedback 类名问题
- 6260bb87: fix(comp:select): 根据交互规范修复 select 样式，文案
- 9b919361: fix(comp:tabs): 按规范调整标签页的样式
- 4953065a: feat(widget:tree): 树组件默认行高改为 32
- ba60dc70: fix(widget:grid): 修复打包后分页器无法正常渲染
- c1256828: fix(widget:grid): 修复表格分页器在部分情况下无法正常显示
- 64b604c2: fix(widget:grid): 修复 PagingBar 因为插件引入顺序导致的报错
- cc4d2bf2: fix(comp:grid): 树形表格同样显示斑马纹
- 6ee618c0: fix(widget:tab): 修改图标显示效果和增加标注子节点来支持 page-tabs 的效果
- 0238b816: fix(widget:grid): 修复表格必选项响应点击事件，以及 change 事件入参不包含必选项的问题
- eb88cdca: fix(widget:grid): 修复本地分页时无法使用轮询
- 4b78d4ed: fix(comp:grid): 修复按需加载场景下表格分页加载 pagination 组件报错
- ba60dc70: fix(widget:grid): 修复分页器改变 pageSize 后重复触发表格数据加载
- 7b2e95ae: fix(comp:grid): 表格分页器 simple 模式下高度为 32px
- c99513d4: fix(widget:grid): 修复表格多选 select 方法报错，关联 issue#351
- d2607c2b: feat(widget:grid): 勾选列默认宽度调整为 40px
- 33927303: fix(comp:grid): 基础表格 small 尺寸取消单元格竖向分割线，调整表头文本颜色，斑马线背景颜色
- 40e1e10f: fix(widget:tab): 修复标题栏分隔线样式
- 386ea7fa: sync(widget:window): 同步主线修改：修复弹窗关闭后没有移除 noscroll 类名
- d2607c2b: fix(comp:grid): 修复树形表格点击分组行也会触发 item-select 事件
- e692c2cc: fix(widget:tooltip): 修复 tooltip 因为修改 svg 元素只读属性导致的报错
- 77719cfb: feat(widget:mask): 调整 mask 的动画效果
- 387fc9b5: fix(widget:grid): 修复调用 pagingaBar moveFirst 方法可能会不触发表格重新加载的问题
- 5d247376: fix(widget:grid): 修复表格 getPlugin 方法在未配置插件时调用报错的问题
- 9f3d0c43: fix(widget: grid): 新增 checkboxInTreeField 属性下,隐藏表头 checkbox 列, 修改 header 插槽间距样式
- e19e9265: fix(widget:grid): 修复 selection 所影响的自动化测试用例
- fc78b913: fix(widget:select): 修复选择器组件多选模式下 change 事件触发两次
- 1f45755a: fix(widget:grid): 修复使用 group 插件，展开收起时模板不更新的问题
- 4f470494: fix(comp:tree-select): 树选择样式调整，包括 tree-select 和 tree-table-select
- cb7bc047: fix(comp:select): 修复多选模式下不使用 v-model 时选中回显值顺序错乱
- fc78b913: fix(widget:select): 修复表单场景中，选择器在多选模式下一加载就会触发校验
- Updated dependencies [ba95de09]
- Updated dependencies [8197c813]
- Updated dependencies [db191806]
- Updated dependencies [77719cfb]
- Updated dependencies [6e39bddc]
- Updated dependencies [6260bb87]
- Updated dependencies [59e243b3]
- Updated dependencies [b049d503]
- Updated dependencies [a3ae5ee0]
- Updated dependencies [e86f9574]
- Updated dependencies [6533c596]
- Updated dependencies [63818025]
- Updated dependencies [95ed3396]
- Updated dependencies [72650ffa]
- Updated dependencies [d97114b4]
- Updated dependencies [7875a24a]
- Updated dependencies [0a66303a]
- Updated dependencies [4145c62f]
  - @sxf/er-config@1.0.0
  - @sxf/er-lib@1.0.0
  - @sxf/er-utils@1.0.0

## 1.0.0-beta.23 (2024-05-13)

### Patch Changes

- 0745dfba: fix(widget:select): 修复 select 滚动加载搜索时没有重置 limit

## 1.0.0-beta.22 (2024-05-08)

### Patch Changes

- d5507d98: fix(widget:grid): 修复表格多选 select 方法报错，关联 issue#351
- b97805ee: fix(widget:tooltip): 修复 tooltip 因为修改 svg 元素只读属性导致的报错

## 1.0.0-beta.21 (2024-04-30)

### Patch Changes

- f60330db: fix(comp:select): 修复多选模式下不使用 v-model 时选中回显值顺序错乱

## 1.0.0-beta.20 (2024-04-26)

### Patch Changes

- 9f9249ef: fix(widget:select): 修复选择器组件多选模式下 change 事件触发两次
- f75d6eba: fix(widget:grid): 修复使用 group 插件，展开收起时模板不更新的问题
- 9f9249ef: fix(widget:select): 修复表单场景中，选择器在多选模式下一加载就会触发校验

## 1.0.0-beta.19 (2024-04-21)

### Minor Changes

- da632a39: feat(comp:select): 选择器搜索框新增图标，样式调整

### Patch Changes

- 1a5d3dd1: fix: (widget: select) 修复 select 下拉框新增按钮配置的时候，无法点击卡死页面问题

## 1.0.0-beta.18 (2024-04-17)

### Minor Changes

- 33cefc44: feat (widget: grid) 修改表格 sortable 里面的 clearSortCfg 方法，补充远程排序时候需要清空表格的排序参数的逻辑

### Patch Changes

- Updated dependencies [d01213a3]
- Updated dependencies [c8273926]
  - @sxf/er-config@1.0.0-beta.10

## 1.0.0-beta.17 (2024-04-12)

### Minor Changes

- 18b5fa93: feat(widget:tooltip): dataTip 支持隐藏小三角；最大宽度调整

  - error 样式下最大宽度调整为 480
  - 普通样式下最大宽度调整为 320

### Patch Changes

- 21aac2fa: fix(comp:select): 调整 select 的触发选中的元素
- aaf549a1: fix(widget:grid): 修复表格必选项响应点击事件，以及 change 事件入参不包含必选项的问题
- Updated dependencies [a64cebe9]
  - @sxf/er-config@1.0.0-beta.9

## 1.0.0-beta.16 (2024-04-09)

### Minor Changes

- 10479df0: feat(comp:grid): 表格分页器插件由从 components 包对外导出

  - **Breaking:** Pagingbar 插件无法从 `@sxf/er-widget/grid` 中获取，升级时需要业务同步替换原来的引用路径为 `import { PagingBar } from '@sxf/er-components/grid'`

### Patch Changes

- 18c20ed7: fix(comp:grid): 修复按需加载场景下表格分页加载 pagination 组件报错
- add69a4d: fix(comp:grid): 表格分页器 simple 模式下高度为 32px
- d4237b07: fix(widget: grid): 新增 checkboxInTreeField 属性下,隐藏表头 checkbox 列, 修改 header 插槽间距样式
- Updated dependencies [3e64fa3e]
  - @sxf/er-config@1.0.0-beta.8

## 1.0.0-beta.15 (2024-04-03)

### Minor Changes

- 59aa7425: feat(comp:combo): combo 支持多选标签显示模式

### Patch Changes

- Updated dependencies [022cdffd]
- Updated dependencies [1e25c394]
  - @sxf/er-config@1.0.0-beta.7

## 1.0.0-beta.14 (2024-03-26)

### Minor Changes

- 1738ab6c: feat(widget:grid): selection 组件新增以 selectedHash 为标识，实现服务端跨页勾选且回显
- db1033cd: fix(comp:grid):给 grid 头部支持筛选过滤
- c078f73c: feat(comp:grid): 分组表格展开收起按钮单独占用一列

### Patch Changes

- 25030f68: fix(comp:select):修改 select 新增按钮样式使其居中，对 select 增加 size 的动态响应
- 2867bd2e: feat(widget:grid): grid 的自动 mask 默认改为水展示
- 53581415: fix(widget:notify):修复 feedback 类名问题
- ad4e5664: fix(comp:select): 根据交互规范修复 select 样式，文案
- 188904da: fix(comp:grid): 树形表格同样显示斑马纹
- c078f73c: feat(widget:grid): 勾选列默认宽度调整为 40px
- c078f73c: fix(comp:grid): 修复树形表格点击分组行也会触发 item-select 事件
- e65d886b: feat(widget:mask): 调整 mask 的动画效果
- 99f1c815: fix(widget:grid): 修复表格 getPlugin 方法在未配置插件时调用报错的问题
- 81af775c: fix(widget:grid): 修复 selection 所影响的自动化测试用例
- Updated dependencies [e65d886b]
- Updated dependencies [ad4e5664]
- Updated dependencies [d9c180c3]
- Updated dependencies [93687b6f]
  - @sxf/er-config@1.0.0-beta.5

## 1.0.0-beta.13 (2024-03-21)

### Patch Changes

- 84158357: feat(widget:tree): 树组件默认行高改为 32

## 1.0.0-beta.12 (2024-03-18)

### Minor Changes

- 3496b223: feat(comp:select): 选择器下拉框添加“新增”按钮,调整选择器分组的分割线样式

### Patch Changes

- 2a72af10: fix(comp:tabs): 按规范调整标签页的样式
- 853e8e91: fix(comp:tree-select): 树选择样式调整，包括 tree-select 和 tree-table-select
- Updated dependencies [064e2ef1]
  - @sxf/er-config@1.0.0-beta.4

## 1.0.0-beta.11 (2024-03-15)

### Patch Changes

- 4db30f00: fix(comp:steps): 修复步骤条图标错误和调整样式

## 1.0.0-beta.10 (2024-03-11)

### Patch Changes

- f249357c: fix(widget:tab): 修改图标显示效果和增加标注子节点来支持 page-tabs 的效果
- Updated dependencies [f4bc459f]
- Updated dependencies [3ce96289]
  - @sxf/er-config@1.0.0-beta.3

## 1.0.0-beta.9 (2024-03-07)

### Minor Changes

- d95ae0ed: feat(widgt:tab): 增加 tab 嵌套支持
- c57a6391: feat(widget:grid): plugins 新增树选择组件多选框相关处理
  feat(widget:comboGrid): 新增树选择组件多选操作和事件内容
- 5d0420d3: steps 步骤条组件新增错误样式

## 1.0.0-beta.8 (2024-03-06)

### Minor Changes

- 63974d03: feat(comp:tabs): 标签页新增投影卡片类型

  - `type` 新增 `projection-card` 类型，为无边框的投影卡片标签页

### Patch Changes

- 07e3045a: fix(comp:grid): 基础表格 small 尺寸取消单元格竖向分割线，调整表头文本颜色，斑马线背景颜色
- Updated dependencies [e1bef167]
  - @sxf/er-config@1.0.0-beta.2
  - @sxf/er-lib@1.0.0-beta.1
  - @sxf/er-utils@1.0.0-beta.1

## 1.0.0-beta.7 (2024-03-01)

### Patch Changes

- f09b46ad: fix(widget:tab): 修复标题栏分隔线样式
- Updated dependencies [d7bb078d]
- Updated dependencies [38763c7f]
  - @sxf/er-config@1.0.0-beta.1

## 1.0.0-beta.6 (2024-01-31)

### Patch Changes

- 96d997ae: fix(widget:grid): 修复表格分页器在部分情况下无法正常显示

## 1.0.0-beta.5 (2024-01-22)

### Minor Changes

- 3a3977ba: feat(comp:select): SfSelect 支持多选结果以标签显示

### Patch Changes

- c088354e: sync(widget:window): 同步主线修改：修复弹窗关闭后没有移除 noscroll 类名

## 1.0.0-beta.4 (2024-01-18)

### Patch Changes

- 686257d9: fix(widget:grid): 修复本地分页时无法使用轮询

## 1.0.0-beta.3 (2024-01-18)

### Patch Changes

- b22237b6: fix(widget:grid): 修复 PagingBar 因为插件引入顺序导致的报错

## 1.0.0-beta.2 (2024-01-18)

### Patch Changes

- 5d0adcae: fix(widget:grid): 修复打包后分页器无法正常渲染
- 5d0adcae: fix(widget:grid): 修复分页器改变 pageSize 后重复触发表格数据加载

## 1.0.0-beta.1 (2024-01-17)

### Patch Changes

- b16c3777: fix(widget:grid): 修复调用 pagingaBar moveFirst 方法可能会不触发表格重新加载的问题

## 1.0.0-beta.0 (2024-01-17)

### Major Changes

- 0b0e74eb: chore: init beta version release

### Minor Changes

- 0b0e74eb: feat(comp:grid): 表格 Pagingbar 插件使用 SfPagination 组件

### Patch Changes

- Updated dependencies [0b0e74eb]
  - @sxf/er-config@1.0.0-beta.0
  - @sxf/er-lib@1.0.0-beta.0
  - @sxf/er-utils@1.0.0-beta.0

## 0.16.0 (2024-04-21)

### Minor Changes

- 5b8205ec: feat(widget:grid): tree 插件新增方法 batchUpdateTreeNodeData：支持批量给树的某个节点添加孩子数据

## 0.15.0 (2024-04-17)

### Minor Changes

- 7210e65b: feat(widget:grid): tree 插件新增 hasChildrenFn 配置项

  - hasChildrenFn 是 hasChildrenField 的函数版，返回 true 表示该节点有子节点，优先级高于 hasChildrenField

## 0.14.0 (2024-03-29)

### Minor Changes

- ebec205b: feat(comp:tree): treeTable 异步加载重构

  - 解决连续展开子节点可能导致数据丢失的问题
  - 修复连续展开子节点时子节点 loading 状态异常

## 0.13.5 (2024-03-18)

### Patch Changes

- 68feb48b: fix(widget:grid): 修复嵌套表格使用自定义列以及样式问题

## 0.13.4 (2024-03-05)

### Patch Changes

- c8e8f698: fix(widget:grid): 修复表格分组子项全部取消选中后，分组的选中状态没有变更的问题

## 0.13.3 (2024-03-01)

### Patch Changes

- 554a2a17: fix(widget:tree): 优化树搜索时空数据文案隐藏逻辑
- 42f50e56: fix(widget:tree):下拉选择树当数据为空&不显示 root 时进行搜索，无数据和无匹配数据文案重叠

## 0.13.2 (2024-02-28)

### Patch Changes

- fix(widget:grid): 修复表格滚动条异常

## 0.13.1 (2024-02-23)

### Patch Changes

- fb4444e4: fix(widget:tooltip): tooltip 处理 data-hint 时需要做一次 htmlDecode
- fb4444e4: fix(widget:grid): 修复 tipFn 返回 html 字符串渲染异常
- Updated dependencies [b670da5e]
  - @sxf/er-utils@0.5.1

## 0.13.0 (2024-02-02)

### Minor Changes

- 4f9fec3d: feat(widget:notify): notify 查看详情按钮点击回调支持自定义

## 0.12.0 (2024-01-29)

### Minor Changes

- a3de0353: feat(widget:notify): notify 支持配置显示查看详情

### Patch Changes

- 6d8258b0: fix(widget:messageBox): 修复 jQuery messageBox 内容超长滚动异常的问题

## 0.11.5 (2024-01-23)

### Patch Changes

- bc167ffe: fix(comp:grid): 修复表格在数据为空时没有正确销毁单元格内容
- Updated dependencies [33f33ab5]
  - @sxf/er-utils@0.5.0

## 0.11.4 (2024-01-22)

### Patch Changes

- c17f587c: fix(widget:window): 修复弹窗关闭后没有移除 noscroll 类名

## 0.11.3 (2024-01-11)

### Patch Changes

- 92bfe351: fix(comp:grid): 修复嵌套表格场景子表格闪动的问题
- Updated dependencies [78c91e53]
  - @sxf/er-config@0.3.0
  - @sxf/er-lib@1.0.0
  - @sxf/er-utils@1.0.0

## 0.11.2 (2024-01-06)

### Patch Changes

- b0190505: fix(comp:grid): 修复表格在隐藏最后一列时的边框样式问题

## 0.11.1 (2023-12-23)

### Patch Changes

- b3664c74: fix(widget:grid): 修复表格边框异常，避免底部出现双重边框

## 0.11.0 (2023-12-08)

### Minor Changes

- c9f5e0cf: feat(widget:\*): jquery 和 Eresh 子包之间的依赖全部声明成 peer

### Patch Changes

- c9f5e0cf: fix(widget:tooltip): 修复 tooltip 可能重复监听 dom 事件导致存在多个实例的问题
- Updated dependencies [c9f5e0cf]
  - @sxf/er-utils@0.3.0

## 0.10.5 (2023-12-05)

### Patch Changes

- 25226739: fix(widget:notify): 修复 notify 在不传入 title 时不显示 msg 中的换行符

## 0.10.4 (2023-12-01)

### Patch Changes

- 175a0336: fix(widget:\*): 修复 select 和 treeSelect 失焦中断可能失效的问题
- fc7f2751: fix(widget:grid): 表格销毁时清除 Resizeable 插件中的延时任务

## 0.10.3 (2023-11-29)

### Patch Changes

- f035dff6: fix(widget:comboGrid): 修复 comboGrid 失焦中断加载仍然会触发 expand、collapse 事件
- f035dff6: fix(widget:select): Select 加载过程中失焦中断列表展开
- f035dff6: fix(widget:treeSelect): TreeSelect 加载过程中失焦中断列表展开

## 0.10.2 (2023-11-28)

### Patch Changes

- 79eab47c: fix(widget:comboGrid): 修复 comboGrid 动态修改列 hidden 可能导致报错的问题
- bc829aef: fix(widget:grid): 修复 sf-tree-table-select 设置 treeHeight 报错
- 3eb55edf: fix(widget:comboGrid): loading 过程中失焦中断列表展开

## 0.10.1 (2023-11-24)

### Patch Changes

- 55af86e7: fix(widget:notify): nofity 不需要单例
- c8d6bb26: fix(widget:date): pikady 主题色与当前主题色保持一致
- 4dd80aab: fix(widget:grid): 修复可伸缩表格在窗口尺寸变化时列宽异常的问题
- Updated dependencies [542ae705]
  - @sxf/er-config@0.2.1
  - @sxf/er-lib@0.1.2
  - @sxf/er-utils@0.2.2

## 0.10.0 (2023-11-20)

### Minor Changes

- 8cabfdb5: feat(widget:grid): 增加表格自定义可选分页

### Patch Changes

- 501455ea: fix(widget: grid): 修复表格固定列占位阴影高度会大于表格实际内容高度的问题

## 0.9.1 (2023-11-16)

### Patch Changes

- ef9793f3: fix(comp:grid): 表格固定列阴影效果只在触发固定效果时显示，调整阴影颜色

## 0.9.0 (2023-11-14)

### Minor Changes

- 43ab54d4: feat(widget:grid): 表格树插件新增设置节点 loading 状态的方法

### Patch Changes

- 9cadc3af: fix(widget:notify): 修复 ok, fail 等常用方法的参数类型

## 0.8.0 (2023-11-10)

### Minor Changes

- 76761469: ---

  ## '@sxf/er-widget': minor

  feat(widget): 渲染表格列头部提示里修改小 i 的渲染逻辑，让小 i 始终保持展示

## 0.7.1 (2023-11-08)

### Patch Changes

- dade9cb6: fix(comp:select): 修复 SfSelect 使用前缀图标无法正确显示部分文本、图标和文本不对齐

## 0.7.0 (2023-10-20)

### Minor Changes

- e7816b8: feat(widget:mask): LoadMask 构造函数参数 target 添加类型 Element

### Patch Changes

- Updated dependencies [1c89619]
- Updated dependencies [700ab67]
- Updated dependencies [a01675b]
  - @sxf/er-config@0.2.0

## 0.6.0 (2023-10-17)

### Minor Changes

- 61e9910: feat(widget:grid): rowTip 支持通过配置 useHint 使用 data-hint 渲染

### Patch Changes

- 61e9910: fix(widget:grid): 修复 rowTip 在表格列配置了 renderer 时可能失效的问题
- Updated dependencies [15c540c]
  - @sxf/er-lib@0.1.1

## 0.5.1 (2023-10-12)

### Patch Changes

- 729ac15: fix(widget:grid): 修复表格列头内容没有溢出时出现悬浮提示

## 0.5.0 (2023-09-19)

### Minor Changes

- 1bf60af: feat(widget:grid): 表格 store 新增事件 afterLoadData

### Patch Changes

- 5584c3a: fix(comp:select): 修复 Select 修改 v-model 校验失败
- b8e08a6: fix(comp:select): 修复 Select 多选模式下校验失败
- 1bf60af: fix(comp:grid): 修复表格在指定高度情况下，初始化时隐藏高度为 0 导致数据无法渲染

## 0.4.0 (2023-09-11)

### Minor Changes

- 458272b: feat: 表格新增不可选的行内提示

### Patch Changes

- 458272b: fix: 修复 combo 传入多选插件的判断问题

## 0.3.0 (2023-08-18)

### Minor Changes

- b597743: build: er-config 和 er-style 改为 peer 依赖

### Patch Changes

- Updated dependencies [b597743]
  - @sxf/er-utils@0.1.0
  - @sxf/er-lib@0.1.0

## 0.2.5 (2023-07-27)

### Patch Changes

- c8162dd: fix(comp:step): 修复 step 在动态切换显示的场景下不正常的情况

  1. 覆盖两个场景，配置 `hidden` 与 `v-if` 类的情况

  2. 原先 step 变化的时候部分值没有重置，导致有问题

## 0.2.4 (2023-07-26)

### Patch Changes

- dbb94fa: feat(comp:window): 新增 getContainer prop
- e7b0bf4: fix(widget:grid): 修复 autoRefresh api 命名问题
- a9f8da5: fix(widget:grid): 修复 field 重复时导致的问题

## 0.2.3 (2023-07-12)

### Patch Changes

- fd66168: fix: pkg 中的依赖补全
- Updated dependencies [fd66168]
  - @sxf/er-lib@0.0.5

## 0.2.1 (2023-07-11)

### Patch Changes

- 696bcb1: fix(widget:grid): 表头 data-hint 渲染行为和 vt 组件库保持一致
- 5f48871: feat: 修改 workspace 依赖包版本
- Updated dependencies [5f48871]
  - @sxf/er-utils@0.0.15

## 0.2.0 (2023-07-10)

### Minor Changes

- ce56585: fix(widget:grid): 由于业务中有相关使用且数量较多，表格表头恢复标签渲染

## 0.1.1 (2023-07-05)

### Patch Changes

- 2eb4bbd: fix(widget:grid): 由于业务中有使用 autoSelectRecordFn，恢复该方法

## 0.1.0 (2023-06-28)

### Minor Changes

- ee3c4ff: fix(widget:grid): 修复表格勾选项在数据删除后依然保留的问题

  ### 详细

  - 表格 store 新增配置项 keepLostSelectedData (默认 false)，用于处理服务端分页场景下跨页勾选功能会导致勾选项中可能有删除的数据
  - selection 插件移除配置项 autoSelectLastRecord

### Patch Changes

- 9ba3d17: fix: 修改 ajax 的实例判断

  针对子应用非共享包的场景，不能使用 instanceof 的判断

- Updated dependencies [9ba3d17]
  - @sxf/er-utils@0.0.14

## 0.0.25 (2023-06-09)

### Patch Changes

- fix(widget): 修复发包问题

## 0.0.24 (2023-06-09)

### Patch Changes

- 07aa079: fix(widget:grid): 修复表格分页第一次点击下一页没有反应

## 0.0.23 (2023-06-09)

### Patch Changes

- c979fa4: fix(widget:grid): 修复表格分页器 change 事件错误触发
- Updated dependencies [4701fcb]
  - @sxf/er-config@0.0.9
  - @sxf/er-utils@0.0.13

## 0.0.22 (2023-06-08)

### Patch Changes

- 36fcf16: fix(widget:grid): 表格数据分割仅在分页场景下进行

## 0.0.21 (2023-06-08)

### Patch Changes

- 20e9830: fix(widget:grid): 修复通过表格 store 事件插入数据后，表格数据展示不完整
- 6195e40: fix(comp:\*): 修复组件问题

  - SfCascader: 禁用项支持配置 tip 显示
  - SfGrid: 修复 CheckSelection 插件在有禁用勾选项时，表头顶部勾选框失效的问题

## 0.0.20 (2023-06-02)

### Patch Changes

- bd9f87d: fix(widget:select): 修复 SfSelect value 初始是 undefined 时第一次选中不触发 change 事件的问题
- 01f7268: fix(widget:select): select change 事件触发机制恢复，改回原逻辑
- bbe548e: fix(comp:select): 修复多选模式下 setValue 无法更新 v-model

## 0.0.19 (2023-05-31)

### Patch Changes

- 44dc306: fix: 修复表头和内容错位的问题

## 0.0.18 (2023-05-25)

### Patch Changes

- a3812d0: fix(widget:grid): 修复宽度计算问题

## 0.0.17 (2023-05-25)

### Patch Changes

- c54c7c0: fix(widget:grid): 调整 resizeable 插件对 autofit 的宽度计算

## 0.0.16 (2023-05-18)

### Patch Changes

- 5e4c404: fix(widget:messageBox): 修复 icon, BTNS 的导出

## 0.0.15 (2023-05-17)

### Patch Changes

- 0407920: fix(widget:step): stepWindow event 参数不正确的问题
- 19a3fd0: fix(widget:messageBox): 修复 error 弹窗标题错误

## 0.0.14 (2023-05-17)

### Patch Changes

- 8f767b9: fix(widget:select): 修复 select 调用函数出错

## 0.0.13 (2023-05-15)

### Patch Changes

- e4dab5f: refactor(comp:window): 完善组件的测试用例，重构掉 mgr
- 33935a7: fix(widget:notify): 修复空白符问题
- 33935a7: fix(widget:notify): 修复提示隐藏太快的问题
- 25abf45: refactor(comp:form): 表单校验重构

  - SfForm 取消绑定 vtype，实现脱离 dom 元素校验
  - 各表单组件校验失败的红显逻辑放在组件内部实现

- Updated dependencies [57f95f2]
- Updated dependencies [25abf45]
- Updated dependencies [e4dab5f]
  - @sxf/er-utils@0.0.10

## 0.0.12 (2023-05-12)

### Patch Changes

- 168fc4e: fix(widget:notify): 修复 notify 疯狂弹出存在内存泄漏问题
- 73a6082: fix(widget:grid): 修复合并参数的问题
- 3513bd3: feat(widget:tooltip): qtip 兼容 -webkit-line-clamp 多行省略号场景
- a119fa7: feat: before 之类的钩子，兼容 Promise 返回值

  - drawer: beforeClose
  - coverWindow: beforeSubmit, beforeCancel, beforeHide
  - window: beforeSubmit, beforeCancel
  - poppover: beforeSubmit,
  - navMenu: before,
  - select: beforeSelect
  - tree: beforeSelect
  - step: before

- Updated dependencies [a119fa7]
  - @sxf/er-utils@0.0.9

## 0.0.11 (2023-04-23)

### Patch Changes

- 1a21a99: fix(widget:window): 修复 body 高度计算出现 NaN 导致高度设置失败的问题

## 0.0.10 (2023-04-23)

### Patch Changes

- 7e2d09e: refactor(widget:\*): 修改 jQuery 插件的挂载方式，需要由业务使用处手动引入挂载，组件库内部不再直接挂载到 jQuery 上
- Updated dependencies [7e2d09e]
  - @sxf/er-config@0.0.7
  - @sxf/er-utils@0.0.8

## 0.0.9 (2023-04-21)

### Patch Changes

- 67de488: fix: 修复一些问题

  - 修复表格 col 元素导致的树表格宽度异常
  - 修复表格 group 由于覆盖 store 的 initDataHash 导致数据重新加载时勾选项丢失的问题
  - widget/grid 新增 isPluginExist 方法用于判断插件列表中是否存在指定插件
  - widget/grid/plugins 中各个插件构造函数上新增 pluginId 属性
  - 同步 vt 组件库嵌套子表格相关更改

## 0.0.8 (2023-04-18)

### Patch Changes

- 731f76c: fix: 修复一些问题

  - 指定 layer props autoScrollbar 默认值为 undefined
  - setInputLimit 增加传参
  - 删除移动到业务的样式文件
  - 补充 SfButton 组件样式

## 0.0.7 (2023-04-17)

### Patch Changes

- Updated dependencies [b1158d4]
  - @sxf/er-config@0.0.6
  - @sxf/er-utils@0.0.7

## 0.0.6 (2023-04-14)

### Patch Changes

- Updated dependencies [9e25dc7]
  - @sxf/er-utils@0.0.6

## 0.0.5 (2023-04-13)

### Patch Changes

- Updated dependencies [80ecd83]
  - @sxf/er-config@0.0.5
  - @sxf/er-utils@0.0.5

## 0.0.4 (2023-04-12)

### Patch Changes

- 3deb7f3: refactor(widget:\*): pick 部分业务有使用的 jq 插件

  - fixaction
  - fixcombogrid
  - fixfieldset
  - keymap

- 0e57fc4: refactor(widget:clock): pick clock（原来的 clock2）, date
- eab5ae6: refactor: 提供业务的全局配置接口

  1. `globalConfig.search` 参数对组件全覆盖
  2. 业务中使用到了的 `$.searchInputLimit` 放到 `trigger` 组件来注册
  3. 表格 `headerCeilTip`
  4. `validator` 包提供 `extendValidator` 方法扩展 `vtype`

- c769e65: refactor(utils:typeof): pick typeof

  - typeof 仅保留业务中使用的 isNull，放在 utils/lang 中提供
  - widget/tip 统一 cfg 处理方式

- 95ce2b0: refactor(utils:dom): pick dom utils

  - 调整 @er/utils/dom 文件结构
  - 搬运依赖到的 dom utils：fireEvent, getSubmitData
  - 修复 setSubmitData 针对 radio 无法正确设置值的 bug
  - repaint 内置到 fixfieldset 中

- 00e2312: fix: 修复图片构建问题
- 5596dff: refactor(widget:\*): pick 部分业务中有依赖的 widget

  - form
  - progress
  - tree 对外以 treeUtil 具名导出 util
  - tip 增加 onBeforeShow, onAfterShow, onBeforeHide, onAfterHide 四个回调
  - ps: common/widget/VTip/vtip 就是在 tip 基础上加了上面的四个回调，直接写进去了，不单独作为模块

- Updated dependencies [bde581a]
- Updated dependencies [9876ea5]
- Updated dependencies [9dedad4]
- Updated dependencies [dfce2dc]
- Updated dependencies [c769e65]
- Updated dependencies [95ce2b0]
- Updated dependencies [be1fa10]
- Updated dependencies [dfce2dc]
  - @sxf/er-utils@0.0.4
  - @sxf/er-config@0.0.4

## 0.0.3 (2023-04-03)

### Patch Changes

- 1daafc1: refactor: 去除所有的全局 VMP 与 install 接口
- 419340c: refactor: 将所有获取国际化词条的配置内容不在初始化执行
- 6d928ef: fix: 修复配置修改导致的错误
- Updated dependencies [f467d2f]
- Updated dependencies [1daafc1]
- Updated dependencies [419340c]
  - @sxf/er-config@0.0.3
  - @sxf/er-utils@0.0.3

## 0.0.2 (2023-03-29)

### Patch Changes

- release
- Updated dependencies
  - @sxf/er-config@0.0.2
  - @sxf/er-utils@0.0.2

## 0.0.1 (2023-03-29)

### Patch Changes

- chore: release
- Updated dependencies
  - @sxf/er-config@0.0.1
  - @sxf/er-utils@0.0.1
