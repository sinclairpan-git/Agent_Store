import $ from 'jquery';
import uuid from '@sxf/er-utils/uuid';
const getWrapCls = function(node) {
  return node.type.toLowerCase() + "-wrap";
};
const willWrap = function(node) {
  return /input/i.test(node.tagName) && /checkbox|radio/i.test(node.type) && !$(node).data("fixcheckbox");
};
const doWrap = function(node) {
  const wrapCls = getWrapCls(node);
  if (!node.id) {
    node.id = uuid();
  }
  const n = $(`<label class="${wrapCls}" for="${node.id}"></label>'`);
  ["margin-left", "margin-right", "margin-top", "margin-bottom"].forEach(function(key) {
    const v = parseInt($(node).css(key), 10) || 0;
    n.css(key, v);
  });
  n.insertAfter(node);
  $(node).data("fixcheckbox", true).addClass("hidden");
};
const fixcheckbox = function() {
  this.each(function() {
    if (willWrap(this)) {
      doWrap(this);
    }
  });
  return this;
};
export { fixcheckbox };
