import $ from 'jquery';
import { ScrollManager } from '@sxf/er-utils/dom';
import uuid from '@sxf/er-utils/uuid';
const config = {
  defAnchorSize: 8,
  defAnchorOffset: 1
};
const TIP_BASE_CLS = "v-tip";
const TIP_BODY_CLS = TIP_BASE_CLS + "-body";
const TIP_INFO_CLS = TIP_BASE_CLS + "-info";
const TIP_ANCHOR_CLS = TIP_BASE_CLS + "-anchor";
const ANCHOR_TOP_CLS = TIP_ANCHOR_CLS + "-top";
const ANCHOR_LEFT_CLS = TIP_ANCHOR_CLS + "-left";
const ANCHOR_RIGHT_CLS = TIP_ANCHOR_CLS + "-right";
const ANCHOR_BOTTOM_CLS = TIP_ANCHOR_CLS + "-bottom";
const TIP_TEMPLATE = [
  '<div class="' + TIP_BASE_CLS + '">',
  '<div class="' + TIP_BODY_CLS + '">',
  '<div class="' + TIP_INFO_CLS + '"></div>',
  "</div>",
  '<div class="' + TIP_ANCHOR_CLS + '"></div>',
  "</div>"
].join("");
const DEF_ALIGN = "rl-bt";
function Tip(cfg = {}) {
  const cls = cfg.cls || "";
  const $template = $(TIP_TEMPLATE);
  this.anchorHide = !!cfg.anchorHide;
  this.autoRemoveEl = cfg.autoRemoveEl !== false;
  this.autoDestroy = !!cfg.autoDestroy;
  this.autoHide = false !== cfg.autoHide;
  this.hideOnClick = false !== cfg.hideOnClick;
  this.bindDocScroll = false !== cfg.bindDocScroll;
  this.anchorOffset = cfg.anchorOffset || config.defAnchorOffset;
  this.anchorSize = typeof cfg.anchorSize === "number" ? cfg.anchorSize : config.defAnchorSize;
  this.offsets = cfg.offsets || [0, 0];
  this.target = getDom(cfg.target);
  this.scrollParent = getDom(cfg.scrollParent);
  this.parent = getDom(cfg.parent || $("body"));
  this.align = cfg.align || "rl-bt";
  this.id = uuid();
  this.overTop = cfg.overTop;
  if (this.anchorHide) {
    $template.find("." + TIP_ANCHOR_CLS).hide();
  }
  this.el = $template.appendTo(this.parent).hide().attr("id", this.id);
  if (cls) {
    this.el.addClass(cls);
  }
  if (this.target) {
    setTimeout(() => {
      this.alignTo(this.target);
      this.show();
    }, 15);
  }
  if (this.overTop) {
    const $overtop = $(this.overTop);
    this.el.css({
      "z-index": Number($overtop.css("z-index")) + 1
    });
  }
  this.onBeforeShow = cfg.onBeforeShow;
  this.onAfterShow = cfg.onAfterShow;
  this.onBeforeHide = cfg.onBeforeHide;
  this.onAfterHide = cfg.onAfterHide;
}
function isOverflowY(el) {
  if (!el) {
    return false;
  }
  return el.clientHeight < el.scrollHeight;
}
Tip.prototype.alignTo = function(target, align) {
  target = target || this.lastTarget || this.target;
  align = align || this.align;
  if (!target || !$(target).is(":visible")) {
    return this;
  }
  const tip = this.el;
  const alignArgs = parseAlign.call(this, target, align);
  const os = offset(this.parent);
  alignArgs.left = alignArgs.left + os.left;
  alignArgs.top = alignArgs.top + os.top;
  applyAlign(tip, alignArgs);
  this.lastTarget = target;
  const tipInfoEl = tip.find("." + TIP_INFO_CLS);
  tipInfoEl.toggleClass(TIP_INFO_CLS + "--has-scrollbar", isOverflowY(tipInfoEl.get(0)));
  return this;
};
Tip.prototype.realign = function() {
  const el = this.el;
  if (!el || !el.is(":visible")) {
    return;
  }
  if (this.lastTarget) {
    this.alignTo(this.lastTarget);
  }
};
Tip.prototype.isShown = function() {
  return this.el && this.el.is(":visible");
};
Tip.prototype.getBodyEl = function() {
  return this.el.find("." + TIP_BODY_CLS);
};
Tip.prototype.getBodyInfoEl = function() {
  return this.el.find("." + TIP_INFO_CLS);
};
Tip.prototype.show = function() {
  const el = this.el;
  if (!el || el.is(":visible")) {
    return;
  }
  if (typeof this.onBeforeShow === "function") {
    this.onBeforeShow.call(this);
  }
  if (this.autoHide) {
    if (this.hideOnClick) {
      const handleMousedown = (e) => {
        const $et = $(e.target);
        const isInQtip = $et.parents(".v-qtip").length;
        if ($et.closest(el).size() || isInQtip) {
          return;
        }
        this.hide();
      };
      document.documentElement.addEventListener("mousedown", handleMousedown, true);
      this.handleMousedown = handleMousedown;
    }
  }
  const handleMouseWheel = (e) => {
    if ($(e.target).closest(el).size()) {
      e.stopImmediatePropagation();
      return;
    }
    if (this.autoHide) {
      this.hide();
    } else {
      this.realign();
    }
  };
  if (this.bindDocScroll) {
    if (this.scrollParent) {
      $(this.scrollParent).bind("scroll", handleMouseWheel);
    } else {
      this.scrollManager = new ScrollManager({ onScroll: handleMouseWheel, throttleTime: 0 });
      this.scrollManager.updateScrollParents(el[0]);
    }
    this.handleMouseWheel = handleMouseWheel;
  }
  $(window).bind(
    "resize",
    this.handleWinResize = () => {
      this.realign();
    }
  );
  this.el.show();
  if (typeof this.onAfterShow === "function") {
    this.onAfterShow.call(this);
  }
  return this;
};
Tip.prototype.hide = function() {
  if (!this.el || !this.el.is(":visible")) {
    return;
  }
  if (typeof this.onBeforeHide === "function") {
    this.onBeforeHide.call(this);
  }
  if (this.autoHide) {
    if (this.hideOnClick) {
      document.documentElement.removeEventListener("mousedown", this.handleMousedown, true);
    }
    this.handleMousedown = null;
  }
  if (this.handleMouseWheel) {
    if (this.scrollParent) {
      $(this.scrollParent).unbind("scroll", this.handleMouseWheel);
    } else {
      this.scrollManager.removeScrollEvent();
    }
    this.handleMouseWheel = null;
  }
  $(window).unbind("resize", this.handleWinResize);
  this.handleWinResize = null;
  this.el.hide();
  if (this.autoDestroy) {
    this.destroy();
  }
  if (typeof this.onAfterHide === "function") {
    this.onAfterHide.call(this);
  }
  this.lastTarget = null;
  return this;
};
Tip.prototype.update = function(el) {
  $("." + TIP_INFO_CLS, this.el).empty().append(el);
  this.realign();
  return this;
};
Tip.prototype.text = function(text) {
  $("." + TIP_INFO_CLS, this.el).text(text);
  this.realign();
  return this;
};
Tip.prototype.updateCls = function(newCls, oldCls) {
  $(this.el).removeClass(oldCls).addClass(newCls);
};
Tip.prototype.destroy = function() {
  if (this.destroying || this.isDestroyed) {
    return;
  }
  this.destroying = true;
  if (this.el) {
    this.hide();
    if (this.autoRemoveEl) {
      this.el.remove();
    }
  }
  if (this.scrollManager) {
    this.scrollManager.destroy();
    this.scrollManager = null;
  }
  this.el = null;
  this.target = null;
  this.parent = null;
  this.lastTarget = null;
  this.handleMousedown = null;
  this.handleMouseWheel = null;
  this.handleWinResize = null;
  this.destroying = false;
  this.isDestroyed = true;
};
function parseVisibleRect(target, dRect) {
  let rect = { width: 0, height: 0, top: 0, left: 0, right: 0, bottom: 0 };
  if (!target) {
    return rect;
  }
  let _rect = target.getBoundingClientRect();
  rect = {
    top: _rect.top,
    left: _rect.left,
    right: Math.min(dRect.width, _rect.right),
    bottom: Math.min(dRect.height, _rect.height),
    width: _rect.width,
    height: _rect.height
  };
  let ttl = 2;
  while (ttl-- && (target = target.parentNode)) {
    _rect = target.getBoundingClientRect();
    if (rect.width >= _rect.width) {
      rect.left = _rect.left;
      rect.width = _rect.width;
    }
    if (rect.height >= _rect.height) {
      rect.top = _rect.top;
      rect.height = _rect.height;
    }
  }
  rect.right = rect.left + rect.width;
  rect.bottom = rect.top + rect.height;
  return rect;
}
function parseAlign(target, align) {
  const tip = this.el;
  const doc = document.documentElement;
  const offsets = this.offsets;
  const anchorOffset = this.anchorOffset;
  const anchorSize = this.anchorHide ? 0 : this.anchorSize;
  const dRect = {
    width: doc.clientWidth,
    height: doc.clientHeight
  };
  const rect = parseVisibleRect(target, dRect);
  tip.css({
    left: 0,
    top: 0
  });
  const tipHeight = parseInt($.css(tip[0], "height"), 10);
  const tipWidth = parseInt($.css(tip[0], "width"), 10);
  let top = 0, left = 0;
  let anchor = "";
  const anchorPos = {
    left: "auto",
    right: "auto",
    top: "auto",
    bottom: "auto"
  };
  let topAvail = rect.top;
  let bottomAvail = dRect.height - rect.bottom;
  let leftAvail = rect.left;
  let rightAvail = dRect.width - rect.right;
  align = (align || DEF_ALIGN).split("-");
  switch (align[0]) {
    case "bt":
      if (bottomAvail >= tipHeight + anchorSize || bottomAvail >= topAvail) {
        anchor = "top";
        top = topAvail + rect.height + anchorSize + offsets[1];
      } else {
        anchor = "bottom";
        top = topAvail - anchorSize - tipHeight - offsets[1];
      }
      break;
    case "tb":
      if (topAvail >= tipHeight + anchorSize || bottomAvail <= topAvail) {
        anchor = "bottom";
        top = topAvail - anchorSize - tipHeight - offsets[1];
      } else {
        anchor = "top";
        top = topAvail + rect.height + anchorSize + offsets[1];
      }
      break;
    case "rl":
      if (rightAvail >= tipWidth + anchorSize || rightAvail >= leftAvail) {
        anchor = "left";
        left = leftAvail + rect.width + anchorSize + offsets[0];
      } else {
        anchor = "right";
        left = leftAvail - tipWidth - anchorSize - offsets[0];
      }
      break;
    case "lr":
      if (leftAvail >= tipWidth + anchorSize || rightAvail <= leftAvail) {
        anchor = "right";
        left = leftAvail - tipWidth - anchorSize - offsets[0];
      } else {
        anchor = "left";
        left = leftAvail + rect.width + anchorSize + offsets[0];
      }
      break;
    default:
      throw "unknow align > " + align.join(",");
  }
  anchorPos[anchor] = -anchorSize;
  if (align[1] === "cc") {
    const halfWidth = (tipWidth - rect.width) / 2;
    if (leftAvail >= halfWidth && rightAvail >= halfWidth) {
      left = leftAvail - halfWidth - offsets[0];
      anchorPos.left = tipWidth / 2 - anchorSize * 3 / 2 + anchorOffset;
    } else if (["lr", "rl"].indexOf(align[0]) !== -1) {
      align[1] = "bt";
    } else {
      align[1] = "lr";
    }
  }
  topAvail += rect.height;
  bottomAvail += rect.height;
  leftAvail += rect.width;
  rightAvail += rect.width;
  switch (align[1]) {
    case "bt":
      if (bottomAvail >= tipHeight + anchorSize || bottomAvail >= topAvail) {
        top = rect.top + offsets[1] - anchorSize;
        anchorPos.top = anchorOffset;
      } else {
        top = rect.bottom - tipHeight - offsets[1] + anchorSize;
        anchorPos.bottom = anchorOffset;
      }
      break;
    case "tb":
      if (topAvail >= tipHeight + anchorSize || bottomAvail <= topAvail) {
        top = rect.bottom - tipHeight - offsets[1];
        anchorPos.bottom = anchorOffset;
      } else {
        top = rect.top + offsets[1];
        anchorPos.top = anchorOffset;
      }
      break;
    case "rl":
      if (rightAvail >= tipWidth + anchorSize || rightAvail >= leftAvail) {
        left = rect.left + offsets[0];
        anchorPos.left = anchorOffset;
      } else {
        left = rect.right - tipWidth - offsets[0];
        anchorPos.right = anchorOffset;
      }
      break;
    case "lr":
      if (leftAvail >= tipWidth + anchorSize || rightAvail <= leftAvail) {
        left = rect.right - tipWidth - offsets[0];
        anchorPos.right = anchorOffset;
      } else {
        left = rect.left + offsets[0];
        anchorPos.left = anchorOffset;
      }
      break;
    case "cc":
      break;
    default:
      throw "unknow align > " + align.join(",");
  }
  const finalPos = {
    anchor,
    anchorPos,
    left,
    top
  };
  const isTooltip = tip.hasClass("v-qtip");
  if (isTooltip) {
    return adjustPositionInViewport(finalPos, tipWidth, tipHeight, dRect);
  }
  return finalPos;
}
function adjustPositionInViewport(position, tipWidth, tipHeight, viewportRect) {
  const minMargin = 4;
  const left = parseFloat(position.left) || 0;
  const top = parseFloat(position.top) || 0;
  const maxLeft = Math.max(0, viewportRect.width - tipWidth - minMargin);
  const maxTop = Math.max(0, viewportRect.height - tipHeight - minMargin);
  const adjustedLeft = Math.min(Math.max(left, minMargin), maxLeft);
  const adjustedTop = Math.min(Math.max(top, minMargin), maxTop);
  return {
    ...position,
    left: adjustedLeft,
    top: adjustedTop
  };
}
function applyAlign(tip, align) {
  tip.css("left", align.left).css("top", align.top).children("." + TIP_ANCHOR_CLS).removeClass([ANCHOR_BOTTOM_CLS, ANCHOR_LEFT_CLS, ANCHOR_RIGHT_CLS, ANCHOR_TOP_CLS].join(" ")).addClass(TIP_ANCHOR_CLS + "-" + align.anchor).css(align.anchorPos);
}
function getDom(el) {
  return el && (el.tagName ? el : el.get(0));
}
function offset(n) {
  const root = document.documentElement;
  const body = document.body;
  const offsetPos = /absolute|relative/i;
  let pos = position(n), left = (body.scrollLeft || root.scrollLeft) + pos.left, top = (body.scrollTop || root.scrollTop) + pos.top;
  while (n && n !== body && (n = n.parentNode)) {
    pos = position(n);
    left += n.offsetLeft;
    top += n.offsetTop;
    left = left - n.scrollLeft + $.css(n, "borderLeftWidth", true);
    top = top - n.scrollTop + $.css(n, "borderTopWidth", true);
    if (pos.position === "fixed") {
      break;
    }
  }
  return {
    left,
    top
  };
  function position(node) {
    const pos2 = $(node).css("position");
    let left2 = 0, top2 = 0;
    if (offsetPos.test(pos2)) {
      left2 = node.offsetLeft;
      top2 = node.offsetTop;
    }
    return { left: left2, top: top2, position: pos2 };
  }
}
Tip.defaults = config;
export { Tip as default };
