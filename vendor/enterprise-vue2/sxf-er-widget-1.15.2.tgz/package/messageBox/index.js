import { globalConfig, $i } from '@sxf/er-config';
import { ajax } from '@sxf/er-utils/ajax';
import { encrypt } from '@sxf/er-utils/rsa';
import $ from 'jquery';
import { getPrefixedClassName } from '@sxf/er-feature';
import XTpl from '@sxf/er-lib/xtpl';
import { fixcheckbox } from '@sxf/er-widget/checkbox';
import LoadMask from '@sxf/er-widget/mask';
import notify from '@sxf/er-widget/notify';
import Window from '@sxf/er-widget/window';
const messageBoxConfig = {
  verifyPasswordUrl: "/users/verify-password",
  verifyPasswordData: (password) => {
    return {
      user: {
        password
      }
    };
  }
};
const getVerifyPasswordApi = () => {
  var _a;
  if ((_a = globalConfig.messageBox) == null ? void 0 : _a.verifyPasswordApi) {
    return globalConfig.messageBox.verifyPasswordApi;
  }
  return function(opts = {}) {
    return ajax({
      url: messageBoxConfig.verifyPasswordUrl,
      type: "POST",
      data: messageBoxConfig.verifyPasswordData(encrypt(opts.password))
    });
  };
};
var template = `<div class="{cls} {[values.getPrefixedClassName('messagebox-inner')]}">
    <i class="iconfont {[values.getPrefixedClassName('messagebox-inner-icon')]} {iconCls}"></i>
    <div class="{[values.getPrefixedClassName('messagebox-info')]}">
        <div class="{[values.getPrefixedClassName('messagebox-info-content')]}">
            <tpl if="subTitle">
                <div class="{[values.getPrefixedClassName('sub-title')]}">{subTitle}</div>
                <tpl if="msg">
                    <div class="{[values.getPrefixedClassName('messagebox-detail')]} {[values.getPrefixedClassName('messagebox-msg-wrapper')]}">{msg:this.renderMsg}</div>
                </tpl>
            <tpl else>
                <div class="{[values.getPrefixedClassName('messagebox-detail')]} {[values.getPrefixedClassName('messagebox-msg-wrapper')]}">{msg:this.renderMsg}</div>
            </tpl>
            <tpl if="withOK">
                <div class="{[values.getPrefixedClassName('messagebox-detail')]} {[values.getPrefixedClassName('messagebox-detail-confirm')]}">
                    {[this.okTip]}
                </div>
                <input class="{[values.getPrefixedClassName('messagebox-detail')]} {[values.getPrefixedClassName('messagebox-detail-ok')]} {[values.getPrefixedClassName('sfc-input-small')]}" style-key="input" placeholder="{[this.inputOkTip]}"/>
            </tpl>
            <tpl if="withPswd">
                <div class="{[values.getPrefixedClassName('messagebox-detail')]} {[values.getPrefixedClassName('messagebox-detail-confirm')]} {[values.getPrefixedClassName('messagebox-detail-confirm-pwd')]}">
                    {userNameTip}
                </div>
                <input type="password" class="{[values.getPrefixedClassName('messagebox-detail')]} {[values.getPrefixedClassName('messagebox-detail-pswd')]} {[values.getPrefixedClassName('sfc-input-small')]}" style-key="input" placeholder="{[this.passwordTip]}">
            </tpl>
            <tpl if="withCheckbox">
                <div class="{[values.getPrefixedClassName('messagebox-detail')]} {[values.getPrefixedClassName('messagebox-detail-confirm')]}">
                    <input type="checkbox" class="{[values.getPrefixedClassName('messagebox-detail-checkbox')]} {[values.getPrefixedClassName('sfc-input-small')]}" style-key="checkbox" id="{winid}-messagebox-detail-checkbox">
                    <label for="{winid}-messagebox-detail-checkbox">{checkboxLabel}</label>
                </div>
            </tpl>
        </div>
    </div>
</div>`;
const INFO = "sfis-window-inner-info";
const WARNING = "sfis-window-inner-warning";
const ERROR = "sfis-window-inner-error";
const QUESTION = "sfis-window-inner-question";
const SUCCESS = "sfis-window-inner-success";
const ICON_MAP = {};
ICON_MAP[INFO] = "vtv-icon-win-info";
ICON_MAP[WARNING] = "vtv-icon-win-tip";
ICON_MAP[ERROR] = "vtv-icon-win-fail";
ICON_MAP[QUESTION] = "vtv-icon-win-tip";
ICON_MAP[SUCCESS] = "vtv-icon-done";
const getBtnConfig = () => ({
  DEFAULTS: [{ text: $i("scp.vt_component.common.widget.MessageBox.default_btn_cancel"), action: "cancel" }],
  CONFIRM: [
    { text: $i("scp.vt_component.common.widget.MessageBox.confirm_btn_submit"), action: "submit" },
    { text: $i("scp.vt_component.common.widget.MessageBox.confirm_btn_cancel"), action: "cancel" }
  ],
  CONFIRM_DANGER: [
    { text: $i("scp.vt_component.common.widget.MessageBox.confirm_danger_btn_submit"), action: "submit" },
    { text: $i("scp.vt_component.common.widget.MessageBox.confirm_danger_btn_cancel"), action: "cancel" }
  ],
  CONFIRM_DELETE: [
    { text: $i("scp.vt_component.common.widget.MessageBox.confirm_delete_btn_submit"), action: "submit" },
    { text: $i("scp.vt_component.common.widget.MessageBox.confirm_delete_btn_cancel"), action: "cancel" }
  ]
});
let win;
const getRenderData = function(option) {
  const globalUsername = globalConfig.username;
  const userName = globalUsername === "admin@vtp" ? "admin" : globalUsername;
  const userNameTip = $i("scp.vt_component.common.widget.MessageBox.username_tip", {
    0: userName || ""
  });
  return {
    winid: win.id,
    cls: getPrefixedClassName(option.icon),
    iconCls: ICON_MAP[option.icon],
    msg: option.msg,
    subTitle: option.subTitle,
    withOK: option.withOK,
    withPswd: option.withPswd,
    withCheckbox: option.withCheckbox,
    checkboxLabel: option.checkboxLabel || "",
    userNameTip,
    getPrefixedClassName
  };
};
const parseParams = function(msg, title, callback, scope) {
  let option;
  if (typeof msg === "string" || typeof msg === "number") {
    option = {
      msg: String(msg),
      title,
      callback,
      scope
    };
  } else {
    option = msg;
  }
  return option;
};
const parseWindowOption = function(option) {
  option = $.extend(true, {}, option);
  const size = option.size || "normal";
  const buttonConfig = getBtnConfig();
  option.nl2br = typeof option.nl2br === "undefined" ? true : Boolean(option.nl2br);
  option.cls = (option.cls || "") + ` ${getPrefixedClassName("sfis-window-messagebox")} ` + getPrefixedClassName("sfis-window-messagebox--" + size);
  option.title = option.title || $i("scp.vt_component.common.widget.MessageBox.parse_window_title");
  option.width = option.width || "auto";
  option.height = option.height || "auto";
  option.maxHeight = option.maxHeight || 600;
  option.minHeight = option.minHeight || 212;
  option.buttons = option.buttons || buttonConfig.DEFAULTS;
  option.buttonAlign = option.buttonAlign || "right";
  option.multiple = option.multiple || false;
  option.autoDestroy = true;
  option.autoclose = option.autoclose === void 0 ? true : option.autoclose;
  delete option.listeners;
  if (typeof option.callback === "function") {
    const oldSubmitFn = option.submitFn;
    const oldCancelFn = option.cancelFn;
    option.submitFn = function() {
      if (typeof oldSubmitFn === "function") {
        oldSubmitFn.call(option.scope || this);
      }
      option.callback.call(option.scope || this, "ok");
    };
    option.cancelFn = function() {
      if (typeof oldCancelFn === "function") {
        oldCancelFn.call(option.scope || this);
      } else {
        if (!option.multiple) {
          win.hide();
        }
      }
      option.callback.call(option.scope || this, "cancel");
    };
  }
  if (option.withPswd) {
    const submitFn = option.submitFn, autoclose = option.autoclose, actualSubmit = function() {
      submitFn.call(win);
      if (autoclose) {
        win.hide();
      }
    };
    option.autoclose = false;
    option.submitFn = function() {
      if (option.pswdControlSelector && !$(option.pswdControlSelector).prop("checked")) {
        actualSubmit();
        return;
      }
      checkPswd().done(function() {
        actualSubmit();
      });
    };
  }
  return option;
};
const show = function(option) {
  option = parseWindowOption(option);
  const oldWin = win;
  _show(option);
  const newWin = win;
  win = oldWin;
  if (option.multiple) {
    return newWin;
  }
  if (win && !win.isDestroyed) {
    win.destroy();
  }
  win = newWin;
  return win;
};
function _show(option) {
  win = new Window(option);
  win.show();
  win.renderBody(
    new XTpl(template, {
      renderMsg: function(msg) {
        msg = msg || "";
        return option.nl2br ? String(msg).replace(/\r?\n/g, "<br />") : msg;
      },
      okTip: $i("scp.vt_component.common.widget.MessageBox.confirm.ok_tip"),
      inputOkTip: $i("scp.vt_component.common.widget.MessageBox.confirm.input_ok_tip"),
      passwordTip: $i("scp.vt_component.common.widget.MessageBox.confirm.password_tip")
    }).apply(getRenderData(option))
  );
  fixcheckbox.call(win.winEl.find('input[type="checkbox"]'));
  const height = 16 + 16 + 8;
  win.winEl.find(".messagebox-inner .messagebox-msg-wrapper").css("max-height", `calc(${win.bodyEl.css("max-height")} - ${height}px)`);
  win.updatePosition();
  const $submit = $('.btn[action="submit"]', win.footerEl);
  if (option.withOK) {
    $submit.attr("disabled", true);
    const $okInput = $(".messagebox-detail-ok", win.bodyEl).focus();
    $okInput.on("keyup change input", function() {
      const right = $(this).val().toLowerCase() === "ok";
      $submit.attr("disabled", !right);
      $okInput.toggleClass("invalid", !right);
    });
  }
  if (option.withCheckbox) {
    const $checkbox = $(".messagebox-detail-checkbox", win.bodyEl);
    $checkbox.prop("checked", !!option.dftChecked);
    if (!option.permitSubmit) {
      $submit.attr("disabled", true);
      $checkbox.change(function() {
        $submit.attr("disabled", !$(this).prop("checked"));
      }).change();
    }
  }
  if (option.withPswd) {
    $(".messagebox-detail-pswd", win.bodyEl).focus();
    if (option.pswdControlSelector) {
      const $pwdEl = win.winEl.find(".messagebox-detail-pswd, .messagebox-detail-confirm-pwd");
      $pwdEl.toggle($(option.pswdControlSelector).prop("checked"));
      $(option.pswdControlSelector).on("change", function() {
        $pwdEl.toggle($(this).prop("checked"));
      });
    }
  }
}
const confirm = function(msg, title, callback, scope) {
  const buttonConfig = getBtnConfig();
  const option = parseParams(msg, title, callback, scope);
  option.icon = option.icon || QUESTION;
  option.buttons = option.buttons || buttonConfig.CONFIRM;
  option.buttonAlign = option.buttonAlign || "right";
  return show(option);
};
const confirmDelete = function(msg, title, callback, scope) {
  const buttonConfig = getBtnConfig();
  const option = parseParams(msg, title, callback, scope);
  option.icon = WARNING;
  option.buttons = option.buttons || buttonConfig.CONFIRM_DELETE;
  option.buttonAlign = option.buttonAlign || "right";
  return show(option);
};
const confirmDeleteWithOK = function(msg, title, callback, scope) {
  const buttonConfig = getBtnConfig();
  const option = parseParams(msg, title, callback, scope);
  option.icon = WARNING;
  option.buttons = option.buttons || buttonConfig.CONFIRM_DELETE;
  option.buttonAlign = option.buttonAlign || "right";
  option.withOK = true;
  return show(option);
};
const showErr = function(msg, title, callback, scope) {
  const option = parseParams(msg, title, callback, scope);
  option.icon = option.icon || ERROR;
  option.title = option.title || $i("scp.vt_component.common.widget.MessageBox.error_window_title");
  return show(option);
};
const showInfo = function(msg, title, callback, scope) {
  const option = parseParams(msg, title, callback, scope);
  option.icon = option.icon || INFO;
  option.title = option.title || $i("scp.vt_component.common.widget.MessageBox.info_window_title");
  return show(option);
};
const showWarn = function(msg, title, callback, scope) {
  const option = parseParams(msg, title, callback, scope);
  option.icon = option.icon || WARNING;
  return show(option);
};
const destroy = function() {
  if (win && !win.isDestroyed) {
    win.destroy();
  }
};
const getEl = function() {
  return win && !win.isDestroyed && win.winEl;
};
function checkPswd() {
  const defer = $.Deferred();
  const pswd = $(".messagebox-detail-pswd", win.bodyEl).val().trim();
  if (!pswd) {
    notify.fail($i("scp.vt_component.common.widget.MessageBox.none_password_fail_msg"));
    defer.reject();
    return defer.promise();
  }
  const mask = new LoadMask(win.winEl, {
    msg: $i("scp.vt_component.common.widget.MessageBox.checking_password_msg")
  });
  mask.show();
  const api = getVerifyPasswordApi();
  api({ password: pswd }).always(function(isSuccess, json) {
    mask.destroy();
    if (!isSuccess) {
      notify.fail(json && json.message || $i("scp.vt_component.common.widget.MessageBox.checked_password_fail_msg"));
      defer.reject();
      return;
    }
    defer.resolve();
  });
  return defer.promise();
}
const BTNS = Object.defineProperties(
  {},
  {
    DEFAULTS: {
      get() {
        return getBtnConfig().DEFAULTS;
      }
    },
    CONFIRM: {
      get() {
        return getBtnConfig().CONFIRM;
      }
    },
    CONFIRM_DANGER: {
      get() {
        return getBtnConfig().CONFIRM_DANGER;
      }
    },
    CONFIRM_DELETE: {
      get() {
        return getBtnConfig().CONFIRM_DELETE;
      }
    }
  }
);
var messageBox = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  BTNS,
  ERROR,
  INFO,
  QUESTION,
  SUCCESS,
  WARNING,
  confirm,
  confirmDelete,
  confirmDeleteWithOK,
  destroy,
  getEl,
  showErr,
  showInfo,
  showWarn
});
export { BTNS, ERROR, INFO, QUESTION, SUCCESS, WARNING, confirm, confirmDelete, confirmDeleteWithOK, messageBox as default, destroy, getEl, getVerifyPasswordApi, showErr, showInfo, showWarn };
