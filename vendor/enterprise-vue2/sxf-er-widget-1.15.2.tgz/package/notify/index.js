import $ from 'jquery';
import { $i } from '@sxf/er-config';
import { checkNoNotify, getHttpErrorMessage } from '@sxf/er-utils/ajax';
import format from '@sxf/er-utils/format';
import { xssFilter } from '@sxf/er-utils/xss';
import VTip from '@sxf/er-widget/tip';
const closeableClass = "notify-bubble-closable";
const ICON_MAP = {
  fail: "vtv-icon-win-fail",
  ok: "vtv-icon-done",
  warn: "vtv-icon-win-tip",
  info: "vtv-icon-win-info",
  email: "vtv-icon-email"
};
function __show(el) {
  $(el).stop(true, false).css("opacity", 1);
}
function __hide(el) {
  $(el).animate({ opacity: 0 }, function() {
    rebuildFeedback(this);
    $(this).remove();
  });
}
function __hideDelay(el) {
  __hide($(el).delay(5e3));
}
const ct = (options) => {
  let _ct = $(document.body).find(".notify-bubble-ct")[0];
  if (!_ct) {
    _ct = $("<div class='notify-bubble-ct'></div>").appendTo(document.body).on("click", ".notify-bubble", function() {
      if (!$(this).hasClass(closeableClass)) {
        __hide($(this).stop(true, false));
      }
    }).on("mouseenter", ".notify-bubble", function() {
      if (!$(this).hasClass(closeableClass)) {
        __show(this);
      }
    }).on("mouseleave", ".notify-bubble", function() {
      if (!$(this).hasClass(closeableClass)) {
        __hideDelay(this);
      }
    });
  }
  $(_ct).on("click", ".notify-bubble > .notify-bubble-close", function() {
    __hide($(this).parent(".notify-bubble"));
    if (typeof options.closeHandler === "function") {
      options.closeHandler();
    }
  });
  return _ct;
};
const add = function(n, closeable, type, autoRemove, options) {
  const { feedback, forceDetail, onDetailClick } = options;
  const animate = typeof options.animate === "undefined" ? true : options.animate;
  let top = Math.floor($(window).height() * 0.15);
  $(".notify-bubble-ct .notify-bubble-feedback").each(function() {
    top += this.offsetHeight || 0;
    top += 20;
  });
  removeMsg({
    node: n,
    closeable,
    type,
    autoRemove,
    feedback,
    animate
  });
  const el = $(n).appendTo(ct(options)).css("opacity", animate ? 0 : 1).animate({ opacity: 1 }, function() {
    if (!closeable) {
      __hideDelay(el);
      return;
    }
  });
  if (closeable) {
    el.addClass(closeableClass);
  }
  if (feedback) {
    el.css("top", top);
  }
  const container = $(".notify-bubble-ct");
  container.scrollTop(container[0].scrollHeight);
  const $bubbleCont = $(".notify-bubble-content", el);
  const contentOverFlow = $bubbleCont.get(0).scrollHeight > $bubbleCont.get(0).clientHeight;
  const ellipsisCls = "showellipsis";
  const bindDetailClickEvent = (showDetail) => {
    if (showDetail) {
      $bubbleCont.siblings(".notify-bubble-detail").on("click", function(e) {
        if (onDetailClick) {
          onDetailClick.call(this);
        } else {
          const tip = new VTip({
            autoDestroy: true,
            autoHide: true,
            align: "lr-bt",
            cls: "notify-bubble-detail-tip"
          });
          $(".v-tip-body", tip.el).html(format.nl2br(xssFilter($(this).data("allmsg") || "")));
          tip.alignTo(e.target).show();
        }
      });
    }
  };
  if (forceDetail) {
    $bubbleCont.siblings(".notify-bubble-detail").toggle(true);
    $bubbleCont.toggleClass(ellipsisCls, contentOverFlow);
    bindDetailClickEvent(true);
  } else {
    let toggle = contentOverFlow;
    if (feedback) {
      toggle = false;
    }
    $bubbleCont.siblings(".notify-bubble-detail").toggle(toggle);
    $bubbleCont.toggleClass(ellipsisCls, toggle);
    bindDetailClickEvent(toggle);
  }
  return el;
};
const show = function(opt) {
  var _a;
  opt = opt && typeof opt === "object" ? opt : { msg: opt };
  let msg = ((_a = opt.msg) == null ? void 0 : _a.trim()) || "";
  if (typeof checkNoNotify === "function" && checkNoNotify(msg)) {
    return;
  }
  msg = opt.autoEncode !== false ? xssFilter(msg) : msg;
  const type = opt.type || "ok";
  const isHttpError = msg === getHttpErrorMessage();
  const feedbackCls = opt.feedback ? "notify-bubble-feedback" : "";
  const closable = opt.feedback ? false : type !== "ok" && type !== "warn" && !isHttpError;
  const message2 = msg ? format.nl2br(msg) : "";
  let content = message2;
  if (opt.title && !opt.feedback) {
    const titleHtml = `<div class='notify-bubble-title'>${xssFilter(opt.title)}</div>`;
    const messageHtml = message2 ? `<div class='notify-bubble-message'>${message2}</div>` : "";
    content = titleHtml + messageHtml;
  }
  let detailMsg = "";
  if (opt.detailMsg !== false) {
    const viewDetail = $i("scp.vt_component.common.widget.Notifier.view_details");
    const detailBadge = opt.detailBadge || "";
    detailMsg = `
      <div class='btn btn-sm notify-bubble-detail' data-allmsg='${opt.detailMsg || msg}'>
      ${viewDetail}${detailBadge}
      </div>
    `;
  }
  const closeBtn = closable ? "<div class='notify-bubble-close'><i class='iconfont vtv-icon-win-close'></i></div>" : "";
  const iconHtml = `<i class='notify-bubble-icon iconfont ${ICON_MAP[type]}'></i>`;
  const contentHtml = `<div class='notify-bubble-content'>${content}</div>`;
  const html = `<div class='notify-bubble notify-bubble-${type} ${feedbackCls}'>${iconHtml}${contentHtml}${detailMsg}${closeBtn}</div>`;
  const forceDetail = !!opt.detailMsg || typeof opt.onDetailClick === "function";
  return add(html, closable, type, isHttpError, {
    ...opt,
    forceDetail
  });
};
const ok = function(msg, opt) {
  return show({
    msg,
    title: opt == null ? void 0 : opt.title,
    feedback: opt == null ? void 0 : opt.feedback
  });
};
const fail = function(msg, opt = {}) {
  return show({
    type: "fail",
    msg,
    ...opt
  });
};
const info = function(msg, opt = {}) {
  return show({
    type: "info",
    msg,
    ...opt
  });
};
const warn = function(msg, opt) {
  return show({
    msg,
    title: opt == null ? void 0 : opt.title,
    type: "warn",
    feedback: opt == null ? void 0 : opt.feedback
  });
};
const message = function(msg, title) {
  let options;
  if ($.isPlainObject(msg)) {
    options = {
      type: "email",
      ...msg
    };
  } else {
    options = {
      type: "email",
      msg,
      title
    };
  }
  return show(options);
};
function removeMsg(options = {}) {
  const { node, closeable, type, autoRemove, feedback, animate } = options;
  if (!autoRemove && !closeable && !feedback) {
    return;
  }
  const $nodeText = $(node).find(".notify-bubble-content").text();
  $(".notify-bubble-ct .notify-bubble").each(function() {
    if (this.className.indexOf(type) !== -1 && $(this).find(".notify-bubble-content").text() === $nodeText) {
      if (autoRemove) {
        rebuildFeedback(this);
        $(this).remove();
      } else if (animate) {
        $(this).animate(
          {
            opacity: 0
          },
          function() {
            rebuildFeedback(this);
            $(this).remove();
          }
        );
      } else {
        rebuildFeedback(this);
        $(this).remove();
      }
    }
  });
}
function rebuildFeedback($el) {
  const removeHeight = parseInt($($el).css("height"), 10);
  let flag = false;
  $(".notify-bubble-ct .notify-bubble-feedback").each(function() {
    if (flag) {
      let top = parseInt($(this).css("top"), 10);
      top -= removeHeight + 20;
      $(this).css("top", top);
    }
    if ($el === this) {
      flag = true;
    }
  });
}
var notify = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  fail,
  info,
  message,
  ok,
  removeMsg,
  show,
  warn
});
export { notify as default, fail, info, message, ok, removeMsg, show, warn };
