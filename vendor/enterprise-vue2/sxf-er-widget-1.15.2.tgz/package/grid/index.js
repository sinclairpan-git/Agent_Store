import { $i } from '@sxf/er-config';
import $ from 'jquery';
import { getPrefixedClassName, featureConfig } from '@sxf/er-feature';
import XTpl from '@sxf/er-lib/xtpl';
import Format from '@sxf/er-utils/format';
import Lang from '@sxf/er-utils/lang';
import Logger from '@sxf/er-utils/logger';
import Observable from '@sxf/er-utils/observable';
import oop, { extend } from '@sxf/er-utils/oop';
import ua from '@sxf/er-utils/ua';
import uuid from '@sxf/er-utils/uuid';
import LoadMask from '@sxf/er-widget/mask';
import { get, isPlainObject } from 'lodash-es';
import { ajax } from '@sxf/er-utils/ajax';
import apply from '@sxf/er-utils/apply';
import DelayedTask from '@sxf/er-utils/delayedTask';
import { when } from '@sxf/er-utils/when';
import { localeCompare } from '@sxf/er-utils/sort';
import { cascadeTree } from '@sxf/er-utils/walk';
const SIZE_CONFIG = {
  normal: {
    rowHeight: 41,
    maxRows: 10,
    minRows: 1
  },
  small: {
    rowHeight: 33,
    maxRows: 10,
    minRows: 1
  },
  large: {
    rowHeight: 57
  },
  xlarge: {
    rowHeight: 77
  },
  xxlarge: {
    rowHeight: 97
  }
};
const SIZE_LIST = Object.keys(SIZE_CONFIG);
const defaultScrollWidth = function() {
  const outer = document.createElement("div");
  outer.style.visibility = "hidden";
  outer.style.width = "100px";
  outer.style.position = "absolute";
  outer.style.top = "-9999px";
  document.body.appendChild(outer);
  const widthNoScroll = outer.offsetWidth;
  outer.style.overflow = "scroll";
  const inner = document.createElement("div");
  inner.style.width = "100%";
  outer.appendChild(inner);
  const widthWithScroll = inner.offsetWidth;
  outer.parentNode.removeChild(outer);
  return widthNoScroll - widthWithScroll;
}();
const getDefaultConfigs$d = () => ({
  width: "auto",
  height: "100%",
  cls: "",
  rowHeight: SIZE_CONFIG.normal.rowHeight,
  size: "",
  headerSize: "",
  encodeWhiteSpace: false,
  enableRowDblClick: false,
  dftColumnText: "",
  noDataText: $i("scp.vt_component.common.widget.Grid.empty_text"),
  noDataTextEncode: true,
  colBorder: true,
  search: null,
  autoLoadMask: true,
  noHeader: false,
  noColumnHeader: false,
  rowCls: "",
  noBufferView: false,
  alwaysRenderView: true,
  renderSlotLimit: 40,
  scrollWidth: defaultScrollWidth,
  headerGroup: null
});
const pluginId = {
  action: "Action",
  autoRefresh: "AutoRefresh",
  detail: "Detail",
  selection: "Selection",
  resizeable: "Resizeable",
  checkSelection: "CheckSelection",
  radioSelection: "RadioSelection",
  fixedColumn: "FixedColumn",
  group: "Group",
  sortable: "Sortable",
  radioGroupSelection: "RadioGroupSelection",
  pagingBar: "PagingBar",
  tree: "Tree",
  customColumn: "CustomColumn"
};
const functionalColumnOrder = {
  [pluginId.checkSelection]: 2,
  [pluginId.group]: 0,
  [pluginId.detail]: 1
};
const gridEvent = {
  render: "render",
  afterRender: "afterrender",
  afterRenderHeaderColumn: "after-render-header-column",
  onGenerateHeaderRow: "on-generate-header-row",
  onGridColFragmentCreated: "on-grid-col-fragment-created",
  onHeaderColumnCreated: "on-header-column-created",
  onGenerateViewRow: "on-generate-view-row",
  onGenerateViewTd: "on-generate-view-td",
  beforeCreateViewTr: "before-create-view-tr",
  renderFooter: "render-footer",
  updateOption: "updateoption",
  renderGridRecords: "render-grid-records",
  viewReady: "viewready",
  afterRenderScroll: "after-render-scroll",
  afterInitEl: "after-init-el",
  scrollXscroll: "scroll-xscroll",
  rowDblClick: "rowdblclick",
  searchEnd: "search.end",
  search: "search",
  searchInput: "search.input",
  headerHeightChange: "header-height-change",
  afterRenderDetail: "after-render-detail"
};
const modelEvent = {
  selectedStatusChange: "selected-status-change",
  dataChange: "datachange"
};
const selectionEvent = {
  beforeSelect: "beforeselect",
  select: "select",
  unselect: "unselect",
  selectAll: "selectall",
  unselectAll: "unselectall",
  change: "change"
};
const checkSelectionEvent = Object.assign({}, selectionEvent, {
  beforeSelect: "beforeselect",
  change: "change"
});
const detailEvent = {
  expandDetail: "expanddetail"
};
const groupEvent = {
  collapse: "collapse",
  collapseAll: "collapseAll",
  expand: "expand",
  expandAll: "expandAll",
  change: "change"
};
const radioSelectionEvent = Object.assign({}, checkSelectionEvent, {
  beforeSelect: "beforeselect"
});
const sortableEvent = {
  beforeSort: "beforesort",
  afterSort: "aftersort"
};
const treeEvent = {
  expand: "expand",
  treeMenuClick: "tree-menu-click",
  treeItemHover: "tree-item-hover",
  handToggleGroup: "hand-toggle-group",
  fnToggleGroup: "fn-toggle-group",
  fnToggleAllGroup: "fn-toggle-all-group"
};
const storeEvent = {
  dataChange: "datachange",
  search: "search",
  endSearch: "end-search",
  loadError: "loaderror",
  beforeLoad: "beforeload",
  load: "load",
  beforeInitData: "beforeinitdata",
  afterLoadData: "afterloaddata",
  initData: "initdata",
  beforeDataChange: "beforedatachange",
  add: "add",
  remove: "remove",
  afterCleanSelectedData: "afterCleanSelectedData"
};
const event = {
  grid: gridEvent,
  store: storeEvent,
  model: modelEvent,
  selection: selectionEvent,
  checkSelection: checkSelectionEvent,
  radioSelection: radioSelectionEvent,
  sortable: sortableEvent,
  tree: treeEvent,
  detail: detailEvent,
  group: groupEvent
};
function elementToString(el) {
  return Format.htmlDecode(el.outerHTML);
}
function noticePluginAddContent({ grid, eventName, eventParams }, callback) {
  const addByPlugins = [];
  grid.emit(eventName, addByPlugins, eventParams);
  const { start, end } = addByPlugins.reduce(
    (current, node) => {
      node.atEnd ? current.end.push(node) : current.start.push(node);
      return current;
    },
    { start: [], end: [] }
  );
  const sortedStartContent = start.sort((node1, node2) => node1.order - node2.order);
  const sortedEndContent = end.sort((node1, node2) => node1.order - node2.order);
  callback({ atStart: sortedStartContent, atEnd: sortedEndContent });
}
class BoundingRectCache {
  constructor(maxCacheSize = 100) {
    this.cache = /* @__PURE__ */ new Map();
    this.maxCacheSize = maxCacheSize;
  }
  getBoundingRect(element) {
    const content = element.textContent;
    const cacheKey = content;
    if (this.cache.has(cacheKey)) {
      return this.cache.get(cacheKey);
    }
    const rect = element.getBoundingClientRect();
    if (rect.width > 0 && rect.height > 0) {
      this.cache.set(cacheKey, rect);
      if (this.cache.size > this.maxCacheSize) {
        const firstKey = this.cache.keys().next().value;
        this.cache.delete(firstKey);
      }
    }
    return rect;
  }
  getRectWidth(element) {
    if (!element) {
      return 0;
    }
    const rect = this.getBoundingRect(element);
    return (rect == null ? void 0 : rect.width) || 0;
  }
  getCellPadding(element) {
    if (!element) {
      return 0;
    }
    const cacheKey = $(element).attr("class");
    if (this.cache.has(cacheKey)) {
      return this.cache.get(cacheKey);
    }
    const SPACE_PROPS = [
      "paddingLeft",
      "paddingRight",
      "borderLeftWidth",
      "borderRightWidth",
      "marginLeft",
      "marginRight"
    ];
    const styles = window.getComputedStyle(element);
    const total = SPACE_PROPS.reduce((sum, prop) => sum + Math.ceil(parseFloat(styles[prop]) || 0), 0);
    if (total > 0 && cacheKey) {
      this.cache.set(cacheKey, total);
      if (this.cache.size > this.maxCacheSize) {
        const firstKey = this.cache.keys().next().value;
        this.cache.delete(firstKey);
      }
    }
    return total;
  }
  clear() {
    this.cache.clear();
  }
}
const getPrefixedClassList = (className) => {
  const prefixedClassName = getPrefixedClassName(className);
  if (!prefixedClassName) {
    return [];
  }
  return prefixedClassName.split(" ");
};
function buildGroupedHeaderStructure(cfg, grid) {
  const dataIndexToID = grid.options.column.reduce((pre, item) => {
    pre[item.dataIndex] = item.id;
    return pre;
  }, {});
  for (const item of cfg) {
    item.leave = [];
    findLeaves(item, item.leave, grid.columnMap, dataIndexToID);
  }
  let queue = [...cfg];
  let cache = [];
  const headerRows = [];
  let currentRow = [];
  while (queue.length) {
    const item = queue.shift();
    if (typeof item === "object") {
      currentRow.push({ header: item.title, colspan: item.leafNum });
      cache.push(
        ...item.children.map((config) => {
          if (typeof config === "string") {
            return dataIndexToID[config];
          }
          return config;
        })
      );
    } else {
      currentRow.push(item);
    }
    if (queue.length === 0 && cache.length !== 0) {
      queue = cache;
      cache = [];
      headerRows.push(currentRow);
      currentRow = [];
    }
  }
  headerRows.push(currentRow);
  const firstRow = headerRows[0];
  let pivot = 0;
  const firstRowLeave = cfg.map((item) => item.leave);
  let firstRowLeaveIndex = 0;
  const column = grid.options.column;
  for (let index = 0, len = column.length; index < len; index++) {
    if (!(firstRowLeaveIndex < firstRowLeave.length)) {
      firstRow.splice(pivot, 0, ...column.slice(index).map((item) => item.id));
      break;
    }
    if (firstRowLeave[firstRowLeaveIndex][0] === column[index].id) {
      for (let i = 1; i < firstRowLeave[firstRowLeaveIndex].length; i++) {
        index++;
      }
      firstRowLeaveIndex++;
      pivot++;
    } else {
      firstRow.splice(pivot, 0, column[index].id);
      pivot++;
    }
  }
  return headerRows;
}
function findLeaves(scope, leafBucket, columnMap, dataIndexToID) {
  if (typeof scope !== "object" || !Array.isArray(scope.children)) {
    const columnId = dataIndexToID[scope];
    leafBucket.push(columnId);
    if (columnMap[columnId].hidden) {
      return 0;
    }
    return 1;
  }
  let leafNum = 0;
  for (const item of scope.children) {
    leafNum += findLeaves(item, leafBucket, columnMap, dataIndexToID);
  }
  scope.leafNum = leafNum;
  return leafNum;
}
function getHeaderGroupKeeperElement(cellInfo, className) {
  const groupKeeperEl = document.createElement("td");
  groupKeeperEl.colSpan = cellInfo.colspan;
  groupKeeperEl.classList.add(...getPrefixedClassList(className));
  groupKeeperEl.textContent = cellInfo.header;
  return groupKeeperEl;
}
const defaults = {};
const gridMgrLogger = Logger("GridMgr");
const GridMgr = oop.extend(Observable, {
  constructor: function(options) {
    this.options = $.extend(true, {}, defaults, options);
    this.listeners = this.options.listeners;
    this.init();
    GridMgr.superclass.constructor.apply(this, arguments);
  },
  init: function() {
    if (!this.options.grid) {
      gridMgrLogger.error("can't not found grid");
      return;
    }
  },
  destroy: function() {
    this.clear();
    delete this.options;
  }
});
var gridTpl = `<div id="{id}" class="{gridCls}">
<div id="{id}-header" class="{[values.getPrefixedClassName('sfis-grid-header')]}">
    <div class="{[values.getPrefixedClassName('vmp-subtoolbar')]}"><ul id="{id}-tbar" class="{[values.getPrefixedClassName('sfis-grid-tbar')]}"></ul></div>
    <div class="{[values.getPrefixedClassName('sfis-grid-column-header-wrapper')]}">
        <div id="{id}-column-header" class="{[values.getPrefixedClassName('sfis-grid-column-header')]}"></div>

        <tpl if="isFixRightColumn">
            <div id="{id}-fix-right-column-header-wrapper" class="{[values.getPrefixedClassName('sfis-grid-fix-right-wrapper')]}">
                <div id="{id}-fix-right-column-header" class="{[values.getPrefixedClassName('sfis-grid-column-header')]}"></div>
            </div>
        </tpl>
    </div>
    <div id="{id}-header-other" class="{[values.getPrefixedClassName('sfis-grid-header-other')]}"></div>
</div>
<div id="{id}-body" class="{[values.getPrefixedClassName('sfis-grid-body')]}">
    <div id="{id}-body-view" class="{[values.getPrefixedClassName('sfis-grid-view')]}">

    </div>

    <tpl if="isFixRightColumn">
        <div id="{id}-fix-right-body-view-wrapper" class="{[values.getPrefixedClassName('sfis-grid-fix-right-wrapper')]}">
            <div id="{id}-fix-right-body-view" class="{[values.getPrefixedClassName('sfis-grid-view')]}">
            </div>
        </div>
    </tpl>

    <div id="{id}-scroll-x" class="{[values.getPrefixedClassName('sfis-grid-scroll-x')]}">
        <div id={id}-scroll-x-inner class="{[values.getPrefixedClassName('sfis-grid-scroll-x-inner')]}"></div>
    </div>
    <div id="{id}-scroll-y" class="{[values.getPrefixedClassName('sfis-grid-scroll-y')]}">
        <div id={id}-scroll-y-inner class="{[values.getPrefixedClassName('sfis-grid-scroll-y-inner')]}"></div>
    </div>
    <div id="{id}-scroll-rb" class="{[values.getPrefixedClassName('sfis-grid-scroll-rb')]}"></div>
</div>
<div id="{id}-footer" class="{[values.getPrefixedClassName('sfis-grid-footer')]}">
    <div id="{id}-footer-other" class="{[values.getPrefixedClassName('sfis-grid-footer-other')]}"></div>
    <div id="{id}-bbar" class="{[values.getPrefixedClassName('sfis-grid-bbar')]}"></div>
</div>
</div>
`;
var searchTpl = `<li class="{cls} {[values.getPrefixedClassName('grid-search-wrap')]}">
<input type="text" class="{[values.getPrefixedClassName('grid-search-input')]}" placeholder="{text}"/>
<span class="{[values.getPrefixedClassName('grid-search-icon')]}"></span>
</li>
`;
const gridLogger = Logger("Grid");
const EMPTY_MIN_HEIGHT = 110;
const GRID_HEADER_COL_ELEMENT_COMMON_SUFFIX = "-grid-header-col";
const GRID_BODY_COL_ELEMENT_COMMON_SUFFIX = "-grid-body-col";
const GRID_HEADER_GROUP_COLUMN_CLASS_NAME = "sfis-grid-column-group-keeper";
const CEIL_ASIDE_CLASS_NAME = "sfis-grid-column-aside";
const HIDE_BORDER_COLUMN_CLASS = "sfis-grid-column-hide-border";
const NO_DATA_CLASS = "no-data";
const Grid = oop.extend(Observable, {
  constructor: function(options) {
    this.id = uuid("sfis-grid-id-");
    this.isShowMsg = true;
    options.column = options.column.filter(function(item) {
      return item;
    });
    this.GRID_HEADER_COL_ELEMENT_COMMON_SUFFIX = GRID_HEADER_COL_ELEMENT_COMMON_SUFFIX;
    this.GRID_BODY_COL_ELEMENT_COMMON_SUFFIX = GRID_BODY_COL_ELEMENT_COMMON_SUFFIX;
    this.options = $.extend(true, {}, getDefaultConfigs$d(), options);
    this.options.column = this.privFilter(this.options.column);
    this.options.tbar = this.privFilter(this.options.tbar);
    this.formatSize();
    this.listeners = this.options.listeners;
    this.init();
    this.initEvent();
    Grid.superclass.constructor.apply(this, arguments);
    this.createPluginSet();
    this.initPlugins();
    if (!ua.isWebKit) {
      this.options.scrollWidth = defaultScrollWidth;
    }
    if (typeof this._asideWidth === "undefined") {
      this._asideWidth = this.options.scrollWidth;
    }
    this.mgr = new GridMgr({
      grid: this
    });
  },
  init: function() {
    this.initStore();
    this.initColumn();
    this.initTopBar();
    this._buildColumnMap();
    this.initGridHeader();
    this._markLastVisibleColumn();
    this.createTpl();
  },
  initEvent: function() {
    const { render, afterRender, updateOption, viewReady, rowDblClick } = gridEvent;
    this.addEvents(render, afterRender, updateOption, viewReady, rowDblClick);
  },
  createPluginSet: function() {
    this.pluginSet = /* @__PURE__ */ new Set();
    if (!this.options.plugins) {
      return;
    }
    if (!Array.isArray(this.options.plugins)) {
      this.options.plugins = [this.options.plugins];
    }
    this.options.plugins.forEach((plugin) => {
      if (typeof (plugin == null ? void 0 : plugin.getId) === "function") {
        this.pluginSet.add(plugin.getId());
      } else if (typeof plugin === "function") {
        this.pluginSet.add(plugin.pluginId);
      } else {
        gridLogger.error("invalid plugin");
      }
    });
  },
  initPlugins: function() {
    const me = this;
    if (!this.options.plugins) {
      return;
    }
    this.options.plugins.forEach(function(plugin, idx) {
      if (typeof plugin === "function") {
        plugin = new plugin();
        me.options.plugins[idx] = plugin;
      }
      if (typeof plugin.init === "function") {
        plugin.init(me);
      }
    });
  },
  initStore: function() {
    const me = this;
    const loadingCls = getPrefixedClassName("sfis-grid-is-loading");
    if (!this.options.store) {
      gridLogger.error("can't find store");
      return;
    }
    this.store = this.options.store;
    this.store.on(`${storeEvent.dataChange} ${storeEvent.search} ${storeEvent.endSearch}`, function() {
      if (!me.rendered || me.destroying || me.isDestroyed) {
        return;
      }
      me.renderRecordKeys = [];
      me.renderView();
      if (me.options.noBufferView) {
        return;
      }
      me.resetScrollPosition();
    });
    this.store.on(storeEvent.loadError, function(msg) {
      me.isShowMsg = true;
      if (me.destroying || me.isDestroyed) {
        return;
      }
      me.showInfo(msg);
    });
    this.store.on(storeEvent.beforeLoad, function() {
      $(me.gridEl).addClass(loadingCls);
      if (me.options.autoLoadMask && !me.firstLoadDone) {
        me.__initMask();
        me.mask.on({
          show: function() {
            if (me.isShowMsg) {
              me.showInfo("");
            }
          }
        });
        me.mask.show();
      }
    });
    this.store.on(storeEvent.load, function() {
      $(me.gridEl).removeClass(loadingCls);
      if (me.options.autoLoadMask && !me.firstLoadDone) {
        if (me.mask) {
          me.mask.destroy();
          me.mask = null;
        }
        me.firstLoadDone = true;
      }
    });
    this.store.grid = this;
    this.renderRecordKeys = [];
  },
  initColumn: function() {
    const grid = this;
    if (!grid.options.column) {
      gridLogger.error("can't find column");
      return;
    }
    grid.options.column.forEach(function(column) {
      column.id = uuid("sfis-grid-column-");
      if (typeof column.dataIndex === "undefined" || column.dataIndex === null) {
        column.dataIndex = uuid("sfis-grid-column-default-dataindex-");
      }
      column.width = column.width || "auto";
      column.oriWidth = column.width;
      if (typeof column.spanCell === "function" && !grid.options.noBufferView) {
        grid.options.noBufferView = true;
      }
    });
  },
  initGridHeader: function() {
    const grid = this;
    const headerGroupConfig = grid.options.headerGroup;
    if (headerGroupConfig) {
      const cfg = $.extend(true, [], headerGroupConfig);
      grid.headerRows = buildGroupedHeaderStructure(cfg, grid);
      return;
    }
    grid.headerRows = [grid.options.column.map((column) => column.id)];
  },
  _buildColumnMap: function() {
    const grid = this;
    grid.columnMap = {};
    grid.options.column.forEach((column) => {
      grid.columnMap[column.id] = column;
    });
  },
  _markLastVisibleColumn: function() {
    let lastVisibleColumn = null;
    this.options.column.forEach((column) => {
      if (!column.hidden) {
        lastVisibleColumn = column;
      }
    });
    this._lastVisibleColumn = lastVisibleColumn;
  },
  _getLastVisibleColumn: function() {
    return this._lastVisibleColumn;
  },
  initTopBar: function() {
  },
  showInfo: function(msg) {
    const me = this;
    if (me.rendered && me.options) {
      if (me.options.noDataTextEncode) {
        msg = Format.htmlEncode(msg);
      }
      if (typeof me.options.renderEmpty === "function") {
        me.viewEl.html(me.options.renderEmpty(msg, msg && msg !== this.options.noDataText));
      } else {
        me.viewEl.html(
          `<table class="${getPrefixedClassName("sfis-grid-empty")}"><tr><td class="${getPrefixedClassName(
            "sfis-grid-empty-text"
          )}">${msg}</td></tr></table>`
        );
      }
      me.scrollXEl.hide();
      me.scrollYEl.hide();
      me.scrollRB.hide();
    } else {
      me.on(
        gridEvent.afterRender,
        function() {
          me.showInfo(msg);
        },
        this,
        {
          single: true
        }
      );
    }
  },
  createTpl: function() {
    let tpl = this.options.tpl;
    if (!tpl) {
      tpl = gridTpl;
    }
    if (!(tpl instanceof XTpl)) {
      tpl = new XTpl(tpl);
    }
    this.options.tpl = tpl;
  },
  render: function(sel) {
    const minHeight = this.options.minHeight;
    const maxHeight = this.options.maxHeight;
    if (minHeight && maxHeight && minHeight > maxHeight) {
      gridLogger.error("minimum height should not be greater than maximum height!");
    }
    const parent = $(sel);
    const $el = $(this.options.tpl.apply(this.getRenderData()));
    parent.append($el);
    this.initEl($el);
    this.rendered = true;
    this.emit(gridEvent.render, this);
    this.renderHeader();
    this.renderHeaderOther();
    this.renderFooter();
    this.renderFooterOther();
    this.updateElSize();
    this.onRender();
    this.renderView(0, this.getPageSize());
    this.emit(gridEvent.afterRender, this);
    this.bindEvent();
  },
  setScrollStyle: function() {
    const scrollWidth = this.options.scrollWidth;
    this.scrollRB.css({
      height: scrollWidth,
      width: scrollWidth
    });
  },
  setBorderStyle: function() {
    let hasBorder = this.options.border;
    const containers = [".sfis-window", ".sf-window", ".cover-window_body-inner"];
    if (typeof hasBorder === "undefined") {
      hasBorder = !!this.gridEl.parents(containers.join(",")).length;
    }
    this.gridEl.toggleClass(getPrefixedClassName("has-border"), hasBorder);
  },
  renderHeader: function() {
    this.renderHeaderColumn();
    this.renderHeaderColumnTip();
    this.renderHeaderRightContent();
    this.renderTBar();
  },
  renderHeaderOther: function() {
    let text = "";
    if (!this.options.renderHeaderOther) {
      return;
    }
    if (typeof this.options.renderHeaderOther === "string") {
      text = this.options.renderHeaderOther;
    } else if (typeof this.options.renderHeaderOther === "function") {
      text = this.options.renderHeaderOther.call(this);
    }
    this.gridEl.find("#" + this.getId() + "-header-other").html(text);
  },
  renderHeaderColumn: function() {
    if (!this.options.column) {
      gridLogger.error("cant't find column");
      return;
    }
    const html = this.getHeaderHtml();
    this.headerColumnEl.html(html);
    this.headerColumnEl.find(".sfis-grid-functional-column").last().addClass(getPrefixedClassName("sfis-grid-functional-column-last"));
    this.emit(gridEvent.afterRenderHeaderColumn, {
      html
    });
  },
  getHeaderHtml: function() {
    const html = [], me = this;
    html.push("<table>");
    const headerRowNum = me.headerRows.length;
    const colGroupEl = me.getHeaderColGroup();
    html.push(elementToString(colGroupEl));
    me.headerRows.forEach((row, rowIndex) => {
      const headerRowFragment = [];
      row.forEach((cell) => {
        if (typeof cell === "string") {
          const column = me.columnMap[cell];
          headerRowFragment.push(me.getHeaderColumnHtml(column, headerRowNum - rowIndex));
          return;
        }
        if (cell.colspan !== 0) {
          const groupKeeperEl = getHeaderGroupKeeperElement(cell, GRID_HEADER_GROUP_COLUMN_CLASS_NAME);
          headerRowFragment.push(elementToString(groupKeeperEl));
        }
      });
      if (rowIndex === 0) {
        headerRowFragment.push(this.getCeilAsideHtml(headerRowNum - rowIndex));
      }
      html.push("<tr>");
      noticePluginAddContent(
        {
          grid: me,
          eventName: gridEvent.onGenerateHeaderRow,
          eventParams: { row, rowIndex, headerRowNum }
        },
        ({ atStart, atEnd }) => {
          if (atStart.length) {
            const atStartContent = atStart.map((node) => node.html);
            html.push(...atStartContent);
          }
          html.push(...headerRowFragment);
          if (atEnd.length) {
            const atEndContent = atEnd.map((node) => node.html);
            html.push(...atEndContent);
          }
        }
      );
      html.push("</tr>");
    });
    html.push("</table>");
    return html.join("");
  },
  getHeaderColGroup: function() {
    const grid = this;
    return grid.getColGroup(grid.GRID_HEADER_COL_ELEMENT_COMMON_SUFFIX);
  },
  getBodyColGroup: function() {
    const grid = this;
    return grid.getColGroup(grid.GRID_BODY_COL_ELEMENT_COMMON_SUFFIX);
  },
  getColGroup: function(colSuffix) {
    const grid = this;
    const colgroupEl = document.createElement("colgroup");
    const colElFragment = document.createDocumentFragment();
    grid.options.column.forEach((column) => {
      const colEl = document.createElement("col");
      colEl.id = column.id + colSuffix;
      if (column.hidden === true) {
        colEl.style.display = "none";
      }
      colEl.style.width = column.width;
      colElFragment.append(colEl);
    });
    const asideColEl = document.createElement("col");
    asideColEl.id = this.getAsideColElId(colSuffix);
    colElFragment.append(asideColEl);
    noticePluginAddContent(
      { grid, eventName: gridEvent.onGridColFragmentCreated, eventParams: colSuffix },
      ({ atStart, atEnd }) => {
        if (atStart.length) {
          const tempFragment = document.createDocumentFragment();
          atStart.forEach((node) => tempFragment.append(node.element));
          colElFragment.insertBefore(tempFragment, colElFragment.firstChild);
        }
        if (atEnd.length) {
          const tempFragment = document.createDocumentFragment();
          atEnd.forEach((node) => tempFragment.append(node.element));
          colElFragment.append(tempFragment);
        }
        colgroupEl.append(colElFragment);
      }
    );
    return colgroupEl;
  },
  getAsideColElId: function(colSuffix) {
    return `${CEIL_ASIDE_CLASS_NAME}${colSuffix}-${this.getId()}`;
  },
  getHeaderColumnHtml: function(column, rowspan) {
    const grid = this;
    let headerCeilTip = "";
    const noBorderRight = column === grid._getLastVisibleColumn();
    if (typeof column.headerCeilTip === "string") {
      headerCeilTip = column.headerCeilTip;
    } else if (column.headerCeilTip !== false) {
      headerCeilTip = column.header;
    }
    if (headerCeilTip) {
      headerCeilTip = Format.htmlTextEncode(headerCeilTip);
    }
    column.headerAlign = column.headerAlign || column.align || "left";
    const tdEl = document.createElement("td");
    tdEl.classList.add(...getPrefixedClassList(`sfis-grid-column-align-${column.headerAlign}`));
    if (column.headerCls) {
      tdEl.classList.add(column.headerCls);
    }
    if (column.hidden === true) {
      tdEl.classList.add("hidden");
    }
    if (noBorderRight) {
      tdEl.classList.add(...getPrefixedClassList(HIDE_BORDER_COLUMN_CLASS));
    }
    tdEl.setAttribute("data-id", column.id);
    if (column.width) {
      tdEl.style.width = column.width;
    }
    if (rowspan) {
      tdEl.rowSpan = rowspan;
    }
    const tdContentEl = document.createElement("div");
    tdContentEl.classList.add(...getPrefixedClassList("sfis-grid-column-content"));
    if (column.isAutoFitWidth) {
      tdContentEl.classList.add(...getPrefixedClassList("is-auto-fit-width-column"));
    }
    if (headerCeilTip) {
      tdContentEl.setAttribute("data-hint", headerCeilTip);
    }
    tdContentEl.innerHTML = column.header || column.text;
    tdEl.appendChild(tdContentEl);
    grid.emit(gridEvent.onHeaderColumnCreated, { el: tdEl, column });
    return elementToString(tdEl);
  },
  renderHeaderColumnTip: function() {
    const me = this;
    this.options.column.forEach(function(column) {
      if (column.headerTipRef) {
        const $tdDom = me.headerColumnEl.find('[data-id="' + column.id + '"]');
        const $content = $tdDom.find(".sfis-grid-column-content");
        const pointerCls = column.headerTipRef.trigger === "click" ? "cursor-pointer" : "";
        const $icon = $(
          `<i class="${getPrefixedClassName("sfis-grid-column-tip-icon")} valign-middle iconfont ${pointerCls} ${column.headerTipIcon}"></i>`
        );
        const headerDiv = $(`<div class="${getPrefixedClassName("keep-header-tip-visible")}"></div>`);
        headerDiv.append($content, $icon);
        $tdDom.append(headerDiv);
        column.headerTipRef.bindTarget($icon);
        $icon.click(function(event2) {
          event2.stopPropagation();
        });
      }
      if (column.headerFilterRef) {
        const $tdDom = me.headerColumnEl.find('[data-id="' + column.id + '"]');
        const pointerCls = column.headerFilterRef.trigger === "click" ? "cursor-pointer" : "";
        const $icon = $(
          `<span class="${getPrefixedClassName("sfis-grid-column-filter-icon")} valign-middle iconfont ${pointerCls} ${column.headerFilterIcon}"></span>`
        );
        $tdDom.addClass(getPrefixedClassName("sfis-grid-column-keep-filter-visible"));
        $tdDom.append($icon);
        column.headerFilterRef.bindTarget($icon);
        $icon.click(function(event2) {
          event2.stopPropagation();
          $($(event2)[0].currentTarget).addClass(getPrefixedClassName("column-filter-active"));
        });
      }
    });
  },
  renderHeaderRightContent: function() {
    const me = this;
    this.options.column.forEach(function(column) {
      if (!column.headerContentRightRef) {
        return;
      }
      const $tdDom = me.headerColumnEl.find('[data-id="' + column.id + '"]');
      const $content = $tdDom.find(".sfis-grid-column-content");
      $content.append(column.headerContentRightRef);
    });
  },
  renderTBar: function() {
    const tbar = this.options.tbar;
    const $parent = this.tbarEl.parent();
    if (this.options.tbarWrap) {
      this.tbarEl = $(this.options.tbarWrap);
      $parent.replaceWith(this.tbarEl);
      return;
    }
    if (!tbar || tbar.hasOwnProperty("length") && !this.options.tbar.length) {
      $parent.hide();
      return;
    }
    this.gridEl.addClass(getPrefixedClassName("has-tbar"));
    this.tbarEl.html("").append($.isArray(tbar) ? this.getTBarHtml() : tbar);
  },
  getTBarHtml: function() {
    const html = [], tBarItems = [], me = this;
    let mustFloat = false, idx = 0;
    this.options.tbar.forEach(function(item, index) {
      if (item === "->") {
        mustFloat = true;
        idx = index;
      } else {
        if (typeof item !== "string") {
          item.type = item.type || "button";
          item.action = item.action || (item.type !== "text" ? "submit" : "");
        } else {
          item = {
            text: item,
            type: "text",
            action: ""
          };
        }
        item.__id = uuid();
        item.cls = item.cls || "";
        item.getPrefixedClassName = getPrefixedClassName;
        if (mustFloat) {
          item.cls += ` ${getPrefixedClassName("btn-float-right")}`;
        } else {
          tBarItems.push(item);
        }
      }
    });
    if (mustFloat) {
      Array.prototype.push.apply(tBarItems, this.options.tbar.slice(idx + 1).reverse());
    }
    tBarItems.forEach(function(item) {
      html.push(me.getTBarItemHtml(item));
    });
    html.push('<div class="clearfix"></div>');
    return html.join("");
  },
  getTBarItemHtml: function(item) {
    if (item.type === "text") {
      return '<li class="txt ' + item.cls + '" action="' + item.action + '" id="' + this.getId() + "-tbar-txt-" + item.__id + '">' + item.text + "</li>";
    } else if (item.type === "search") {
      return new XTpl(searchTpl).apply(item);
    }
    return '<li class="btn ' + (item.action ? "btn-" + item.action : " ") + " " + item.cls + '" id="' + this.getId() + "-tbar-btn-" + item.__id + '" action="' + item.action + '" title="' + (item.title || "") + '">' + (item.text || "") + "</li>";
  },
  renderFooter: function() {
    this.emit(gridEvent.renderFooter);
  },
  getPageStartIndex: function() {
    const store = this.store;
    return store.lastOption.data && store.lastOption.data.start || 0;
  },
  renderFooterOther: function() {
    let text = "";
    if (!this.options.renderFooterOther) {
      return;
    }
    if (typeof this.options.renderFooterOther === "string") {
      text = this.options.renderFooterOther;
    } else if (typeof this.options.renderFooterOther === "function") {
      text = this.options.renderFooterOther.call(this);
    }
    const $footer = this.gridEl.find("#" + this.getId() + "-footer-other");
    $footer.html(text);
    $footer.on("remove", function() {
      $(text).detach();
    });
  },
  formatStartLimit: function(start, limit) {
    if (this.options.noBufferView) {
      return {
        start: 0,
        limit: this.getStoreCount()
      };
    }
    const pageSize = this.getPageSize();
    if (start === null || typeof start === "undefined") {
      start = this.lastStart;
    }
    if (limit === null || typeof limit === "undefined") {
      limit = this.lastLimit;
    }
    start = start || 0;
    limit = limit || pageSize;
    if (start + limit - 2 > this.getStoreCount()) {
      limit = pageSize;
      start = Math.max(0, this.getStoreCount() - limit);
    }
    limit = Math.max(limit, pageSize);
    return {
      start,
      limit
    };
  },
  formatSize: function() {
    const size = this.options.size;
    if (size === "small") {
      this.options.headerSize = this.options.headerSize || "small";
      this.options.colBorder = false;
    }
    if (SIZE_LIST.indexOf(size) >= 0) {
      const sizeCfg = SIZE_CONFIG[size];
      const rowHeight = sizeCfg.rowHeight;
      const maxRows = sizeCfg.maxRows;
      const minRows = sizeCfg.minRows;
      this.options.rowHeight = rowHeight;
      this.options.maxRows = Lang.isNumber(this.options.maxRows) ? this.options.maxRows : maxRows;
      this.options.minRows = Lang.isNumber(this.options.minRows) ? this.options.minRows : minRows;
    }
    if (this.options.maxRows && !this.options.maxHeight) {
      this.options.maxHeight = this.options.rowHeight * this.options.maxRows;
    }
    if (this.options.minRows && !this.options.minHeight) {
      this.options.minHeight = this.options.rowHeight * this.options.minRows;
    }
  },
  updateOption: function(options, key) {
    if (options) {
      if (key) {
        this.options.column.forEach(function(column) {
          column.hidden = options.column.indexOf(column.dataIndex) === -1;
        });
      } else {
        this.options.column.forEach(function(column, index) {
          const correctIndex = typeof column.originIndex !== "undefined" ? column.originIndex : index;
          column.hidden = options.column[correctIndex].hidden;
        });
      }
    }
    this._buildColumnMap();
    this.initGridHeader();
    this._markLastVisibleColumn();
    if (!this.rendered) {
      return;
    }
    this.renderHeaderColumn();
    this.renderHeaderColumnTip();
    this.renderView();
    this.emit(gridEvent.updateOption, this, { options, key });
  },
  updateColumnOrder(options) {
    var _a, _b;
    const me = this;
    let newColumns = [];
    if (me.options.plugins && me.getPlugin(pluginId.customColumn)) {
      const customColumnPlugin = me.getPlugin(pluginId.customColumn);
      newColumns = options.map(
        (column) => customColumnPlugin._getGridColumnConfig().find((item) => item.columnKey === column)
      );
      customColumnPlugin.updateGridColumnView(newColumns);
      (_b = (_a = customColumnPlugin._getWorkbench()) == null ? void 0 : _a.updateColumnsConfig) == null ? void 0 : _b.call(_a, newColumns);
    }
  },
  getColumnByDom: function(dom) {
    const id = $(dom).data("id"), theColumn = this.options.column.filter(function(column) {
      return column.id === id;
    });
    return theColumn[0] || {};
  },
  __initMask: function() {
    if (this.mask) {
      return;
    }
    this.mask = new LoadMask(this.bodyEl, {
      cls: getPrefixedClassName("sfis-grid-mask"),
      align: "horizontal",
      defer: this.options.maskDefer || 0
    });
  },
  __renderGridRecords: function(options) {
    const { records, force } = options;
    const me = this;
    const emitRenderGridRecords = (recordKeys) => {
      const emitData = {
        store: me.store,
        recordKeys
      };
      me.emit(gridEvent.renderGridRecords, emitData);
      me.renderRecordKeys = recordKeys;
    };
    if (!records.length) {
      emitRenderGridRecords([]);
      return;
    }
    let hasNoRender = false;
    records.forEach(function(record) {
      const key = record.get(me.store.options.idProperty);
      if (me.renderRecordKeys.indexOf(key) === -1) {
        hasNoRender = true;
      }
    });
    if (force || hasNoRender) {
      const renderRecords = me.store.getVisibleRecords();
      const newRenderRecordKeys = renderRecords.map(function(record) {
        const key = record.get(me.store.options.idProperty);
        return key;
      });
      emitRenderGridRecords(newRenderRecordKeys);
    }
  },
  renderView: function(start, limit, needRenderGridRecords) {
    const me = this;
    let html;
    if (!this.rendered) {
      return;
    }
    if (!this.options.alwaysRenderView && this._renderViewed && this.gridEl.is(":hidden")) {
      return;
    }
    this._renderViewed = true;
    const startLimit = this.formatStartLimit(start, limit);
    start = startLimit.start;
    limit = startLimit.limit;
    const records = this.store.getRange(start, limit);
    if (this.store.lastMsg) {
      this.isShowMsg = true;
      this.showInfo(this.store.lastMsg);
      me.__renderGridRecords({ records: [] });
    } else if (!records.length) {
      this.isShowMsg = true;
      this.showInfo(this.options.noDataText);
      me.__renderGridRecords({ records: [] });
    } else {
      me.__renderGridRecords({ records, force: needRenderGridRecords });
      this.isShowMsg = false;
      html = this.getHtml(start, limit);
      const fragment = document.createDocumentFragment();
      $(fragment).append(html);
      this.viewEl.html(fragment);
      this.lastStart = start;
      this.lastLimit = limit;
      const columns = this.options.column;
      const $rows = this.viewEl.find("tr");
      const removeTip = (cell) => cell.removeAttr("data-tip").removeAttr("data-hint");
      records.forEach(function(record, row) {
        const $row = $rows.filter('[data-id="' + me.store.getAllKeys(record)[0] + '"]');
        columns.forEach(function(column, col) {
          let tip;
          if (!column.dataIndex) {
            return;
          }
          const $cell = $row.find('[data-column-id="' + column.id + '"]');
          if (!$cell.length) {
            return;
          }
          if (column.hidden) {
            $cell.closest("td").addClass("hidden");
            return;
          }
          if (column.renderer && record.__rowTip) {
            removeTip($cell);
          }
          if (column.renderElem) {
            $cell.html("");
            const mapCol = typeof column.originIndex === "undefined" ? col : column.originIndex;
            const value = record.get(column.dataIndex);
            const renderElem = column.renderElem.call(me, value, record, row + start, mapCol, me.store);
            if (renderElem) {
              $cell.append(renderElem);
            }
            if (record.__rowTip) {
              removeTip($cell);
            } else {
              if (column.ceilTip === "auto") {
                tip = $cell.text().trim();
                $cell.removeAttr("data-hint");
                $cell.attr("data-tip", tip === "-" ? "" : tip);
              } else if (typeof column.ceilTip === "function") {
                $cell.attr("data-hint", column.ceilTip.call(me, value, record, row + start, mapCol, me.store));
              }
            }
            $cell.on("remove", function() {
              $(renderElem).detach();
            });
          }
        });
        if (me.options.plugins && me.getPlugin(pluginId.detail)) {
          const selector = `[data-id="detail-${me.store.getAllKeys(record)[0]}"]`;
          const $rowDetail = $rows.filter(selector);
          const $detailTd = $rowDetail.find(".sfis-grid-detail-column");
          if (!$detailTd.length) {
            return;
          }
          $detailTd.html("");
          const detailHtml = me.options.renderDetail.call(me, record, row);
          $detailTd.html(detailHtml);
          me.emit(gridEvent.afterRenderDetail, selector);
          $detailTd.on("remove", function() {
            $(detailHtml).detach();
          });
        }
      });
      me.setAutoFitWidth();
    }
    const scrollElVisibility = this.renderScroll();
    this.gridEl.toggleClass(
      getPrefixedClassName("sfis-grid-view-full-height"),
      this.viewEl.find("table").height() >= this.__getBodyElHeight()
    );
    this.gridEl.toggleClass(getPrefixedClassName(NO_DATA_CLASS), !records.length);
    this.emit(gridEvent.viewReady, {
      html,
      scrollElVisibility
    });
  },
  autoCalcColumn() {
    const columnMaxWidthMap = /* @__PURE__ */ new Map();
    const $cols = this.viewEl.find(".is-auto-fit-width-column");
    const rectCache = this._rectCache || new BoundingRectCache();
    this._rectCache = rectCache;
    const columnWidths = Array.from($cols).map((col) => {
      return rectCache.getRectWidth(col);
    });
    $cols.each((index, col) => {
      const $cell = $(col);
      const $targetElement = $cell.closest("[data-column-id]");
      if (!$targetElement.length) {
        return;
      }
      const colId = $targetElement.attr("data-column-id");
      if (!colId) {
        return;
      }
      let $cellTdElement = $targetElement.closest("td");
      if (!$cellTdElement.length) {
        $cellTdElement = $targetElement;
      }
      const cellPadding = rectCache.getCellPadding($cellTdElement.get(0));
      const maxWidth = Math.ceil(columnWidths[index] + cellPadding);
      const oldMaxWidth = columnMaxWidthMap.get(colId) || 0;
      columnMaxWidthMap.set(colId, Math.max(oldMaxWidth, maxWidth));
    });
    columnMaxWidthMap.forEach((_, colId) => {
      const $headerTd = this.headerEl.find(`tr td[data-id="${colId}"]`);
      const $headerContent = $headerTd.find(".is-auto-fit-width-column");
      const headerContentWidth = rectCache.getRectWidth($headerContent.get(0));
      const maxWidth = headerContentWidth + rectCache.getCellPadding($headerTd.get(0)) + rectCache.getCellPadding($headerContent.get(0));
      const oldMaxWidth = columnMaxWidthMap.get(colId) || 0;
      columnMaxWidthMap.set(colId, Math.max(oldMaxWidth, maxWidth));
    });
    function areMapsEqual(map1, map2) {
      if (map1.size !== map2.size) {
        return false;
      }
      for (const [key, value] of map1) {
        if (map2.get(key) !== value) {
          return false;
        }
      }
      return true;
    }
    let needRerender = false;
    if (!this.columnMaxWidthMap) {
      needRerender = true;
    } else if (!areMapsEqual(columnMaxWidthMap, this.columnMaxWidthMap)) {
      needRerender = true;
    }
    this.columnMaxWidthMap = columnMaxWidthMap;
    return {
      needRerender,
      columnMaxWidthMap
    };
  },
  setAutoFitWidth() {
    const { needRerender, columnMaxWidthMap } = this.autoCalcColumn();
    if (!needRerender) {
      return;
    }
    const hasResizeablePlugin = this.isPluginExist(pluginId.resizeable);
    const updates = [];
    columnMaxWidthMap.forEach((maxWidth, id) => {
      const width = `${maxWidth}px`;
      const column = this.columnMap[id];
      Object.assign(column, {
        oriWidth: width,
        width,
        minWidth: width,
        maxWidth: width
      });
      if (!hasResizeablePlugin) {
        const widthStyles = {
          width,
          "min-width": width,
          "max-width": width
        };
        updates.push({
          id,
          styles: widthStyles
        });
      }
    });
    if (updates.length) {
      requestAnimationFrame(() => {
        if (this.isDestroyed) {
          return;
        }
        updates.forEach(({ id, styles }) => {
          let autoFitBodyContent = this.viewEl.find(`tr td[data-column-id="${id}"]`);
          if (!autoFitBodyContent.length) {
            autoFitBodyContent = this.viewEl.find(`tr [data-column-id="${id}"]`).parents("td");
          }
          const autoFitHeader = this.headerEl.find(`tr td[data-id="${id}"]`);
          const autoFitHeaderCol = this.headerEl.find(`#${id + this.GRID_HEADER_COL_ELEMENT_COMMON_SUFFIX}`);
          autoFitBodyContent.addClass(getPrefixedClassName("is-auto-fit-width-column-td"));
          autoFitBodyContent.css(styles);
          autoFitHeader.css(styles);
          autoFitHeaderCol.css("width", styles.width);
        });
        this.handleAfterAutoFitWidth();
      });
    } else {
      this.handleAfterAutoFitWidth();
    }
  },
  handleAfterAutoFitWidth() {
    const ResizeablePlugin = this.getPlugin(pluginId.resizeable);
    if (ResizeablePlugin && !this.headerEl.is(":hidden")) {
      ResizeablePlugin.reInitColumnWidth();
    }
    this.renderView(this.lastStart, this.lastLimit);
  },
  forceReload: function() {
    return this.store.forceReload.apply(this.store, arguments);
  },
  renderScroll: function() {
    const viewHeight = this.getViewHeight(), viewWidth = this.getViewWidth(), allDataHeight = this.getAllDataHeight(), allDataWidth = this.getAllDataWidth(), scrollWidth = this.options.scrollWidth;
    let showY = false, showX = false;
    let yHideToShow = false, yShowToHide = false;
    this.yHideToShow = false;
    this.yShowToHide = false;
    if (viewHeight < allDataHeight) {
      showY = true;
      showX = viewWidth < allDataWidth;
    } else if (viewHeight - scrollWidth < allDataHeight) {
      showX = showY = viewWidth < allDataWidth;
    } else {
      showY = false;
      showX = viewWidth < allDataWidth;
    }
    let h;
    if (this.options.height === "auto") {
      const isEmpty = !this.viewEl.find("table").length;
      let minHeight = parseInt(this.options.minHeight, 10) || 0;
      if (isEmpty) {
        minHeight = Math.max(EMPTY_MIN_HEIGHT, minHeight);
      }
      h = Math.max(minHeight, allDataHeight + (showX ? scrollWidth : 0));
      if (this.options.maxHeight) {
        if (this.options.maxHeight < h) {
          showY = true;
          h = this.options.maxHeight;
        } else {
          showY = false;
        }
      } else {
        showY = false;
      }
      this.bodyEl.css({
        height: h
      });
    }
    if (showY) {
      if (this.viewEl.is(":visible") && !this.scrollYEl.is(":visible")) {
        this.yHideToShow = true;
        yHideToShow = true;
      }
      this.scrollYEl.show().css({
        height: (h || viewHeight) - (showX ? scrollWidth : 0)
      });
      if (this.yHideToShow && viewHeight) {
        this.scrollYEl.scroll();
      }
      this.toggleCeilAsideVisibility(true);
      this.scrollYInnerEl.css({
        height: allDataHeight
      });
    } else {
      if (this.viewEl.is(":visible") && this.scrollYEl.is(":visible")) {
        this.yShowToHide = true;
        yShowToHide = true;
      }
      this.scrollYEl.hide();
      if (this.yShowToHide && viewHeight) {
        this.scrollYEl.scroll();
      }
      this.toggleCeilAsideVisibility(false);
    }
    if (showX) {
      this.scrollXEl.show().css({
        right: showY && scrollWidth ? `${scrollWidth}px` : 0
      });
      this.scrollXInnerEl.css({
        width: allDataWidth - (showY ? scrollWidth : 0)
      });
      this.scrollXEl.scroll();
      if (this.options.noBufferView) {
        this.viewEl.find("table").eq(0).css("margin-bottom", scrollWidth);
      }
    } else {
      this.scrollXEl.hide();
    }
    if (showX && showY) {
      this.scrollRB.show();
    } else {
      this.scrollRB.hide();
    }
    this.emit(gridEvent.afterRenderScroll, {
      showX
    });
    return { yHideToShow, yShowToHide };
  },
  toggleCeilAsideVisibility(visible) {
    let method = "hide";
    if (visible) {
      method = "show";
    }
    const gridId = this.getId();
    const ceilAsideSelector = `.${CEIL_ASIDE_CLASS_NAME}-${gridId}`;
    const headerCeilAsideColSelector = `#${this.getAsideColElId(GRID_HEADER_COL_ELEMENT_COMMON_SUFFIX)}`;
    const bodyCeilAsideColSelector = `#${this.getAsideColElId(GRID_BODY_COL_ELEMENT_COMMON_SUFFIX)}`;
    this.gridEl.find(ceilAsideSelector)[method]();
    this.gridEl.find(headerCeilAsideColSelector)[method]();
    this.gridEl.find(bodyCeilAsideColSelector)[method]();
  },
  resetScrollPosition: function() {
    const me = this;
    if (me.scrollYEl.is(":visible")) {
      const rowHeight = me.options.rowHeight;
      const current = me.scrollYEl.scrollTop();
      const target = (me.lastStart || 0) * me.options.rowHeight;
      if (target - current < rowHeight) {
        me.scrollYEl.scrollTop(current);
      } else {
        me.scrollYEl.scrollTop(target);
      }
    }
  },
  redraw: function() {
    this.updateElSize();
    this.renderView();
  },
  updateColumnWidth: function() {
    const ResizeablePlugin = this.getPlugin(pluginId.resizeable);
    if (ResizeablePlugin && !this.headerEl.is(":hidden")) {
      ResizeablePlugin.reInitColumnWidth();
      return;
    }
    const me = this, widthList = [], scrollWidth = this.options.scrollWidth;
    let totalWidth = 0;
    if (this.preventCalColumnWidth) {
      return;
    }
    const headerTDs = this.headerColumnEl.find(`td:not(.${GRID_HEADER_GROUP_COLUMN_CLASS_NAME})`);
    headerTDs.each(function() {
      const w = parseInt($(this).css("width"), 10) || 100;
      widthList.push(w);
      totalWidth += w;
    });
    if (this.yHideToShow) {
      widthList.forEach(function(width, idx) {
        if (idx === widthList.length - 1) {
          return;
        }
        widthList[idx] -= width * scrollWidth / (totalWidth - scrollWidth);
      });
    }
    headerTDs.each(function(idx) {
      $(this).css("width", widthList[idx]);
    });
    widthList.forEach(function(width, idx) {
      me.viewEl.find(
        [
          "tr.sfis-grid-body-item > td:nth-child(" + (idx + 1) + ")",
          "tr.sfis-grid-body-group-item > td:nth-child(" + (idx + 1) + ")"
        ].join(",")
      ).css("width", width);
    });
  },
  getAllDataHeight: function() {
    const count = this.getStoreCount();
    return count * this.options.rowHeight;
  },
  getAllDataWidth: function() {
    return $("table", this.headerColumnEl).get(0).clientWidth;
  },
  getViewHeight: function() {
    return this.viewEl.get(0).clientHeight || this.viewEl.parent().height();
  },
  getViewWidth: function() {
    return this.viewEl.get(0).clientWidth;
  },
  getRenderData: function() {
    const gridCls = ["sfis-grid"];
    if (this.options.headerSize) {
      gridCls.push("sfis-grid--" + this.options.headerSize);
    }
    if (!this.options.colBorder) {
      gridCls.push("sfis-grid--no-column-border");
    }
    let params = {
      id: this.getId(),
      gridCls: gridCls.map((cls) => getPrefixedClassName(cls)).join(" "),
      getPrefixedClassName
    };
    (this.options.plugins || []).forEach(function(plugin) {
      if (typeof plugin.getTplParams === "function") {
        params = $.extend(true, params, plugin.getTplParams());
      }
    });
    return params;
  },
  getData: function() {
    if (this.store) {
      return this.store.getData();
    }
    return [];
  },
  getId: function() {
    return this.id;
  },
  getGridEl: function() {
    if (this.gridEl) {
      return this.gridEl.get(0);
    }
  },
  onRender: function() {
  },
  initEl: function(el) {
    const $grid = $(el);
    this.gridEl = $grid;
    this.headerEl = $grid.find("#" + this.getId() + "-header");
    this.tbarEl = $grid.find("#" + this.getId() + "-tbar");
    this.headerColumnEl = $grid.find("#" + this.getId() + "-column-header");
    this.bodyEl = $grid.find("#" + this.getId() + "-body");
    this.viewEl = $grid.find("#" + this.getId() + "-body-view");
    this.scrollXEl = $grid.find("#" + this.getId() + "-scroll-x");
    this.scrollXInnerEl = $grid.find("#" + this.getId() + "-scroll-x-inner");
    this.scrollYEl = $grid.find("#" + this.getId() + "-scroll-y");
    this.scrollYInnerEl = $grid.find("#" + this.getId() + "-scroll-y-inner");
    this.scrollRB = $grid.find("#" + this.getId() + "-scroll-rb");
    this.footerEl = $grid.find("#" + this.getId() + "-footer");
    this.bbarEl = $grid.find("#" + this.getId() + "-bbar");
    this.gridEl.css({
      width: this.options.width,
      height: this.options.height
    });
    this.gridEl.addClass(this.options.cls);
    if (this.options.disabled) {
      this.gridEl.addClass(getPrefixedClassName("disabled"));
    }
    if (this.options.encodeWhiteSpace) {
      this.gridEl.addClass(getPrefixedClassName("encode-white-space"));
    }
    if (this.options.noHeader) {
      this.headerEl.hide();
    }
    if (this.options.noColumnHeader) {
      this.headerColumnEl.hide();
    }
    this.setScrollStyle();
    this.setBorderStyle();
    this.emit(gridEvent.afterInitEl);
  },
  setMinHeight: function(minHeight) {
    this.options.minHeight = minHeight;
    this.options.height = "auto";
    this.gridEl.css({
      height: "auto"
    });
    this.renderView();
  },
  getBodyElSize: function(gridElHeight) {
    const headerSize = this.headerEl.get(0).getBoundingClientRect(), footerSize = this.footerEl.get(0).getBoundingClientRect(), bodyHeight = (gridElHeight || this.gridEl.get(0).clientHeight) - headerSize.height - footerSize.height;
    return Math.floor(bodyHeight);
  },
  updateElSize: function() {
    if (this.options.height === "auto") {
      return;
    }
    const bodyHeight = this.getBodyElSize();
    if (bodyHeight) {
      this.bodyEl.css({
        height: bodyHeight
      });
    }
  },
  __getBodyElHeight() {
    return this.bodyEl.height();
  },
  __redrawIfNeed() {
    const need = this.rendered && !this.gridEl.is(":hidden") && this.__getBodyElHeight() <= 0;
    if (need) {
      this.redraw();
    }
  },
  getHtml: function(start, limit) {
    const records = this.store.getRange(start, limit), ret = [], me = this;
    ret.push("<table>");
    const bodyColGroupEl = me.getBodyColGroup();
    ret.push(elementToString(bodyColGroupEl));
    records.forEach(function(item, row) {
      ret.push(me.getRowHtml(item, row, records));
      noticePluginAddContent(
        {
          grid: me,
          eventName: gridEvent.onGenerateViewRow,
          eventParams: {
            record: item,
            rowIndex: row,
            records
          }
        },
        ({ atStart, atEnd }) => {
          if (atStart.length) {
            const atStartContent = atStart.map((node) => node.html);
            ret.unshift(...atStartContent);
          }
          if (atEnd.length) {
            const atEndContent = atEnd.map((node) => node.html);
            ret.push(...atEndContent);
          }
        }
      );
    });
    ret.push("</table>");
    return ret.join("");
  },
  getLastTdRowSpan(record, row) {
    const me = this;
    const lastColumn = me.options.column[me.options.column.length - 1];
    let rowspan = 1;
    if (typeof lastColumn.spanCell === "function") {
      const spanInfo = lastColumn.spanCell.call(lastColumn, row, record) || { rowspan: 1, colspan: 1 };
      rowspan = spanInfo.rowspan;
    }
    return rowspan;
  },
  getRowHtml: function(record, row, rs) {
    const ret = [];
    ret.push(this.getRowTrHtml(record, row, rs));
    ret.push(this.getRowTdHtml(record, row, rs));
    const lastRowSpan = this.getLastTdRowSpan(record, row);
    ret.push(this.getCeilAsideHtml(lastRowSpan));
    ret.push("</tr>");
    return ret.join("");
  },
  getRowTrHtml: function(record, rowIndex) {
    const me = this, key = record.get(me.store.options.idProperty), ret = [];
    let rowCls = this.options.rowCls;
    if (Lang.isFunction(rowCls)) {
      rowCls = rowCls(record, rowIndex);
    }
    const dataId = Format.htmlEncode(key);
    const index = this.lastStart + rowIndex;
    const rowHeight = me.options.rowHeight;
    const attrs = {
      index,
      "data-id": dataId
    };
    const classList = [getPrefixedClassName("sfis-grid-body-item"), rowCls];
    const style = {
      height: `${rowHeight}px`
    };
    me.emit(gridEvent.beforeCreateViewTr, { attrs, classList, style }, { record, rowIndex });
    const attrsStr = Object.keys(attrs).map((attrKey) => `${attrKey}="${attrs[attrKey]}"`).join(" ");
    const classStr = classList.filter(Boolean).join(" ");
    const styleStr = Object.keys(style).map((styleKey) => `${styleKey}:${style[styleKey]}`).join(";");
    const gridUtid = this.getGridUtid();
    const rowUtidBase = `sf-grid-row-${index}`;
    const rowUtid = gridUtid ? `${gridUtid}-${rowUtidBase}` : rowUtidBase;
    ret.push(`<tr ${attrsStr} class="${classStr}" style="${styleStr}" utid="${rowUtid}">`);
    return ret.join("");
  },
  getRowTdHtml: function(record, row, rs) {
    const me = this, ret = [];
    const groupPlugin = this.getPlugin(pluginId.group);
    me.options.column.forEach(function(column, col) {
      let ceilHtml;
      if (groupPlugin && record.get("__type") === "group") {
        ceilHtml = groupPlugin.getGroupCeilHtml.call(groupPlugin, record, column, row, col, rs);
      } else {
        ceilHtml = me.getCeilHtml(record, column, row, col, rs);
      }
      ret.push(ceilHtml);
    });
    noticePluginAddContent(
      {
        grid: me,
        eventName: gridEvent.onGenerateViewTd,
        eventParams: {
          record,
          rowIndex: row,
          records: rs
        }
      },
      ({ atStart, atEnd }) => {
        if (atStart.length) {
          const atStartContent = atStart.map((node) => node.html);
          ret.unshift(...atStartContent);
        }
        if (atEnd.length) {
          const atEndContent = atEnd.map((node) => node.html);
          ret.push(...atEndContent);
        }
      }
    );
    return ret.join("");
  },
  getCeilHtml: function(record, column, row, col) {
    var _a;
    const ret = [], me = this;
    const text = record.get(column.dataIndex), cls = column.ceilTipCls || "";
    let renderText = text, title = "";
    let rowspan = 1;
    let colspan = 1;
    const noBorderRight = me._getLastVisibleColumn() === column;
    if (typeof column.spanCell === "function") {
      const spanInfo = column.spanCell.call(column, row, record) || { rowspan: 1, colspan: 1 };
      rowspan = spanInfo.rowspan;
      colspan = spanInfo.colspan;
      if (rowspan === 0 || colspan === 0) {
        return "";
      }
    }
    if (typeof column.renderer === "function") {
      renderText = column.renderer.call(me, renderText, record, row, col, me.store);
    } else {
      renderText = Lang.isEmpty(renderText) ? me.options.dftColumnText : Format.htmlEncode(renderText);
    }
    if (column.ceilTip) {
      if (column.ceilTip === true) {
        title = (_a = Format.htmlTextEncode(Format.htmlEncode(text))) == null ? void 0 : _a.replace(/&nbsp;/g, " ");
      } else if (typeof column.ceilTip === "function") {
        title = column.ceilTip.call(me, text, record, row, col, me.store);
      } else if (column.ceilTip === "auto") {
        title = Format.htmlTextEncode(Format.htmlTextEncode($("<div>").html(renderText).text()));
      }
    }
    column.width = column.width || "auto";
    column.minWidth = column.minWidth || "auto";
    column.align = column.align || "left";
    let actualRenderColumnWidth = column.width;
    let actualRenderColumnMinWidth = column.minWidth;
    if (colspan !== 1) {
      actualRenderColumnWidth = "auto";
      actualRenderColumnMinWidth = "auto";
    }
    const tipPos = {
      left: "b",
      right: "bl",
      center: "bc"
    };
    let dataHintPos = [
      column.align !== "left" ? 'data-hint-pos="' + tipPos[column.align] + '"' : "",
      column.align === "right" ? 'data-hint-anchor-offset="8"' : ""
    ];
    dataHintPos = dataHintPos.join(" ");
    const tdClasslist = [getPrefixedClassName(`sfis-grid-column-align-${column.align}`)];
    const fixedPlugin = this.getPlugin(pluginId.fixedColumn);
    const fixed = fixedPlugin && !fixedPlugin.isAllFixed() ? column.fixed : "";
    if (column.cls) {
      tdClasslist.push(column.cls);
    }
    if (column.hidden) {
      tdClasslist.push("hidden");
    }
    if (noBorderRight) {
      tdClasslist.push(getPrefixedClassName(HIDE_BORDER_COLUMN_CLASS));
    }
    if (fixed) {
      tdClasslist.push(...[getPrefixedClassName("is-fixed-column"), getPrefixedClassName(`is-fixed-column-${fixed}`)]);
    }
    const tdClass = tdClasslist.join(" ");
    const dataIndex = column.dataIndex || "";
    const tdStyle = `width:${actualRenderColumnWidth};min-width:${actualRenderColumnMinWidth};`;
    if (title) {
      ret.push(`<td rowspan="${rowspan}" colspan="${colspan}" class="${tdClass}" style="${tdStyle}">`);
      ret.push(
        `<span class="${getPrefixedClassName(
          "sfis-grid-column-ceil-inner"
        )}" data-hint="${title}" data-hint-cls="${cls}" ${dataHintPos} data-index="${dataIndex}" data-column-id="${column.id}">`
      );
    } else {
      ret.push(
        `<td rowspan="${rowspan}" colspan="${colspan}" class="${tdClass}" style="${tdStyle}" ${dataHintPos} data-index="${dataIndex}" data-column-id="${column.id}">`
      );
    }
    ret.push(renderText);
    if (title) {
      ret.push("</span>");
    }
    ret.push("</td>");
    return ret.join("");
  },
  getCeilAsideHtml: function(rowspan) {
    if (rowspan === 0) {
      return "";
    }
    rowspan = Number(rowspan) || 1;
    const styleStr = `width:${this.options.scrollWidth}px;`;
    const classStr = `${getPrefixedClassName(CEIL_ASIDE_CLASS_NAME)} ${CEIL_ASIDE_CLASS_NAME}-${this.getId()}`;
    return `<td style="${styleStr}" class="${classStr}" ${rowspan ? `rowspan="${rowspan}"` : ""}></td>`;
  },
  bindEvent: function() {
    const rowHeight = this.options.rowHeight, me = this;
    this.scrollYEl.bind("scroll", function(e) {
      const top = $(this).scrollTop();
      if (me.options.forcePreventDefault) {
        e.preventDefault();
        e.stopPropagation();
      }
      if (me.options.noBufferView) {
        return me.viewEl.scrollTop(top);
      }
      const start = Math.ceil(top / rowHeight);
      const limit = me.getPageSize();
      if (start === me.lastStart && limit === me.lastLimit) {
        return;
      }
      me.preventCalColumnWidth = true;
      me.renderView(start, limit);
      me.preventCalColumnWidth = false;
    });
    this.scrollXEl.bind("scroll", function(e) {
      const left = $(this).scrollLeft();
      me.headerColumnEl.scrollLeft(left);
      me.viewEl.scrollLeft(left);
      if (me.options.forcePreventDefault) {
        e.preventDefault();
        e.stopPropagation();
      }
      me.emit(gridEvent.scrollXscroll, this);
    });
    this.viewEl.bind("mousewheel", function(e) {
      let old, offset;
      if (me.scrollYEl.is(":visible")) {
        old = me.scrollYEl.scrollTop();
        offset = -e.deltaY * (me.options.rowHeight || SIZE_CONFIG.normal.rowHeight);
        me.scrollYEl.scrollTop(old + offset);
        if (!(!old && offset < 0) && !(old === me.scrollYInnerEl.height() - me.scrollYEl.height() && offset > 0)) {
          e.preventDefault();
        }
      }
      const isNestedGrid = me.viewEl.closest("tr.sfis-grid-body-detail-content");
      if (isNestedGrid.length) {
        e.preventDefault();
        e.stopPropagation();
      }
      if (me.options.forcePreventDefault) {
        e.preventDefault();
      }
    });
    if (this.options.forcePreventDefault) {
      this.headerEl.bind("mousewheel", function(e) {
        e.preventDefault();
      });
    }
    if (this.options.enableRowDblClick) {
      this.gridEl.delegate(".sfis-grid-body-item", "dblclick", function(event2) {
        const key = Format.htmlDecode($(this).data("id"));
        const record = me.store.get(key);
        if (!record) {
          gridLogger.error("record is missing");
          return;
        }
        me.emit(gridEvent.rowDblClick, me, record, event2);
      });
    }
    me.tbarEl.find(".grid-search-input").keyup(function(e) {
      const $input = $(this), value = $input.val();
      if (e.keyCode === 27) {
        $input.val("");
        me.emit(gridEvent.searchEnd, value);
        me.endSearch();
      } else if (e.keyCode === 13) {
        me.emit(gridEvent.search, value);
        me.search(value);
      } else {
        me.emit(gridEvent.searchInput, value);
        me.search(value);
      }
    });
    me.tbarEl.find(".grid-search-icon").click(function() {
      me.emit(gridEvent.search, me.tbarEl.find(".grid-search-input").val());
      me.search(me.tbarEl.find(".grid-search-input").val());
    });
  },
  getPageSize: function() {
    const rowHeight = this.options.rowHeight;
    let count;
    if (this.options.height === "auto") {
      count = this.getStoreCount();
      if (this.options.maxHeight) {
        if (this.options.maxHeight < count * rowHeight) {
          return Math.ceil(this.options.maxHeight / rowHeight);
        }
      }
      return count;
    }
    return Math.ceil(this.getViewHeight() / rowHeight);
  },
  getStoreCount: function() {
    return this.store.getSinglePageCount();
  },
  setWidth: function(width) {
    if (typeof width === "number") {
      width = width + "px";
    }
    this.options.width = width;
    this.gridEl.css("width", width);
  },
  setHeight: function(height) {
    if (typeof height === "number") {
      height = height + "px";
    }
    if (typeof height === "string" && height.endsWith("px") && height === this.options.height) {
      return;
    }
    this.options.height = height;
    if (!this.rendered) {
      return;
    }
    this.gridEl.css("height", height);
    this.updateElSize();
    this.renderView(height === "auto" ? 0 : void 0, this.getPageSize());
    this.resetScrollPosition();
  },
  getPlugin: function(pluginId2) {
    let ret;
    if (!this.options.plugins) {
      return null;
    }
    this.options.plugins.forEach(function(plugin) {
      if (typeof pluginId2 === "string") {
        if (plugin.getId() === pluginId2) {
          ret = plugin;
        }
      } else {
        if (plugin instanceof pluginId2) {
          ret = plugin;
        }
      }
    });
    return ret;
  },
  isPluginExist: function(pluginId2) {
    if (!this.pluginSet) {
      return false;
    }
    return this.pluginSet.has(pluginId2);
  },
  add: function(records) {
    this.store.add(records);
    this.refresh();
  },
  insert: function(records, index) {
    this.store.insert(records, index);
    this.refresh();
  },
  remove: function(records) {
    this.store.remove(records);
    this.refresh();
  },
  refresh: function() {
    this.renderView();
  },
  disable: function() {
    this.options.disabled = true;
    if (this.rendered) {
      this.gridEl.addClass(getPrefixedClassName("disabled"));
    }
  },
  enable: function() {
    this.options.disabled = false;
    if (this.rendered) {
      this.gridEl.removeClass(getPrefixedClassName("disabled"));
    }
  },
  search: function() {
    return this.store.search.apply(this.store, arguments);
  },
  endSearch: function() {
    return this.store.endSearch.apply(this.store, arguments);
  },
  destroy: function() {
    const me = this;
    if (this.isDestroyed) {
      return;
    }
    this.destroying = true;
    this.columnMap = null;
    this.renderRecordKeys = null;
    this._rectCache = null;
    this.columnMaxWidthMap = null;
    if (this.store) {
      if (typeof this.store.destroy === "function") {
        this.store.destroy();
      }
      this.store = null;
    }
    if (this.options.plugins) {
      this.options.plugins.forEach(function(plugin) {
        if (typeof plugin.destroy === "function") {
          plugin.destroy();
        }
      });
      this.options.plugins = null;
    }
    if (this.gridEl) {
      this.gridEl.undelegate();
      this.gridEl.remove();
      this.gridEl = null;
    }
    this.purgeListeners();
    this.cleanMask();
    [
      "gridEl",
      "headerEl",
      "headerColumnEl",
      "bodyEl",
      "viewEl",
      "scrollXEl",
      "scrollXInnerEl",
      "scrollYEl",
      "scrollYInnerEl",
      "footerEl",
      "bbarEl",
      "tbarEl",
      "scrollRB",
      "mgr",
      "options",
      "store",
      "pluginSet"
    ].forEach(function(field) {
      delete me[field];
    });
    this.destroying = false;
    this.isDestroyed = true;
  },
  privFilter: function(data) {
    if ($.isArray(data)) {
      return data.filter(function(item) {
        return item.hasPriv || typeof item.hasPriv === "undefined";
      });
    }
    return data;
  },
  showMask: function() {
    var _a, _b;
    this.__initMask();
    this.mask.show();
    this.isPluginExist(pluginId.fixedColumn) && ((_b = (_a = this.getPlugin(pluginId.fixedColumn)).hiddenPlaceholder) == null ? void 0 : _b.call(_a));
  },
  hideMask: function() {
    var _a, _b, _c;
    (_a = this.mask) == null ? void 0 : _a.hide();
    this.mask = null;
    this.isPluginExist(pluginId.fixedColumn) && ((_c = (_b = this.getPlugin(pluginId.fixedColumn)).recoverTablePlaceholder) == null ? void 0 : _c.call(_b));
  },
  cleanMask: function() {
    var _a;
    (_a = this.mask) == null ? void 0 : _a.destroy();
    this.mask = null;
  },
  getGridUtid: function() {
    return this.options.utid;
  }
});
const Model = oop.extend(Observable, {
  constructor: function(options) {
    this.options = options;
    this.listeners = this.options.listeners;
    this.init();
    Model.superclass.constructor.apply(this, arguments);
    this.addEvents(modelEvent.dataChange, modelEvent.selectedStatusChange);
  },
  init: function() {
    const me = this;
    me.data = me.options.data;
    me._selected = false;
    Object.defineProperty(me, "selected", {
      set(val) {
        if (me._selected === val) {
          return;
        }
        me._selected = val;
        me.emit(modelEvent.selectedStatusChange, me, val);
      },
      get() {
        return !!me._selected;
      }
    });
  },
  get: function(key) {
    return this.data[key];
  },
  set: function(obj, value, suspend) {
    let key;
    if (typeof obj === "string") {
      key = obj;
      obj = {};
      obj[key] = value;
    }
    for (key in obj) {
      if (obj.hasOwnProperty(key)) {
        this.data[key] = obj[key];
      }
    }
    if (suspend) {
      this.suspendEvents();
    }
    this.emit(modelEvent.dataChange, this, this.data);
    if (suspend) {
      this.resumeEvents();
    }
  },
  destroy: function() {
    this.purgeListeners();
    delete this.data;
    delete this.options;
  }
});
const getDefaultConfigs$c = () => ({
  idProperty: "id",
  root: "data",
  totalProperty: "count",
  ajax: null,
  keepLostSelectedData: false,
  diffData: false
});
const storeLogger = Logger("Store");
const Store = oop.extend(Observable, {
  constructor: function(options) {
    this.options = {
      ...getDefaultConfigs$c(),
      ...get(featureConfig, "componentConfig.grid.store", {}),
      ...options
    };
    this.listeners = this.options.listeners;
    this.dataHash = {};
    this.dataList = [];
    this.snapshot = {};
    this.invisibleHash = {};
    this.oldData = null;
    this.isFirstLoadData = true;
    const { beforeInitData, afterLoadData, initData, beforeDataChange, dataChange, beforeLoad, load } = storeEvent;
    this.addEvents(
      beforeInitData,
      afterLoadData,
      initData,
      beforeDataChange,
      dataChange,
      beforeLoad,
      load
    );
    this.storeOptions(this.options.ajax);
    this.init();
    Store.superclass.constructor.apply(this, arguments);
  },
  init: function() {
    this.initSelected();
    if (this.options.data) {
      this.loadData(this.options.data);
    }
  },
  createCallback: function(type, option) {
    const me = this;
    return function(json) {
      me.loaded = true;
      me.loading = false;
      if (me.isDestroyed) {
        return;
      }
      switch (type) {
        case "success":
          me.jsonData = json;
          me.loadData(me.getRootData(json));
          break;
        case "failure":
          me.showErr(json && json.message || $i("scp.vt_component.common.widget.Grid.Store.error_loading_data"));
          break;
        case "error":
          if (json !== "abort") {
            me.showErr($i("scp.vt_component.common.widget.Grid.Store.network_connection_encountered_error"));
          }
          break;
        case "callback":
          delete me.lastAjax;
          me.emit(storeEvent.load, json, arguments[1], arguments[2]);
          break;
      }
      if (typeof option[type] === "function") {
        option[type].apply(option.scope || me, arguments);
      }
    };
  },
  load: function(option) {
    const me = this;
    option = apply({}, option);
    this.storeOptions(option);
    const ajaxOptions = apply({}, this.lastOption);
    $.each(["success", "failure", "error", "callback"], function(i, type) {
      ajaxOptions[type] = me.createCallback(type, option);
    });
    if (me.loading && me.lastAjax) {
      me.lastAjax.abort();
    }
    if (option.mask) {
      me.grid.showMask();
    }
    me.loading = true;
    this.emit(storeEvent.beforeLoad, this, ajaxOptions);
    this.lastAjax = ajax(ajaxOptions);
    return this.lastAjax.always(function() {
      delete me.lastAjax;
      me.grid.hideMask();
    });
  },
  reload: function(option, keepLastData) {
    if (keepLastData) {
      option = $.extend(true, {}, this.lastOption, option);
    } else {
      option = apply.applyIf(option || {}, this.lastOption);
    }
    return this.load(option);
  },
  storeOptions: function(options) {
    options = apply({}, options);
    delete options.success;
    delete options.failure;
    delete options.error;
    delete options.callback;
    delete options.scope;
    this.lastOption = options;
    return options;
  },
  setRootData: function(data) {
    let cur;
    const ret = {
      success: true
    }, keys = this.options.root.split(".");
    cur = ret;
    keys.forEach(function(key, i) {
      if (i === keys.length - 1) {
        cur[key] = data;
      } else {
        cur[key] = {};
        cur = cur[key];
      }
    });
    return ret;
  },
  getRootData: function(json) {
    const root = this.options.root;
    const fields = root.split(".");
    let ret = json;
    fields.forEach(function(field) {
      ret = ret[field];
    });
    return ret;
  },
  getTotalSize: function() {
    const total = this.options.totalProperty;
    const fields = total.split(".");
    let ret = this.jsonData;
    if (!ret) {
      return 0;
    }
    $.each(fields, function(idx, field) {
      if (!ret) {
        storeLogger.error("can't found totalProperty field: %s", total);
        return false;
      }
      ret = ret[field];
    });
    return parseInt(ret, 10) || this.getCount();
  },
  showErr: function(msg) {
    this.initDataHash([]);
    this.lastMsg = msg;
    this.emit(storeEvent.loadError, msg);
  },
  loadData: function(data) {
    const d = $.isArray(data) && $.extend(true, [], data) || [];
    this.oldData = this.oldData ? this.oldData : d;
    if (this.options.diffData && !this.isFirstLoadData && this.isSameData(d, this.oldData)) {
      return;
    }
    this.isFirstLoadData = false;
    this.oldData = d;
    this.jsonData = apply(this.setRootData(d), this.jsonData || {});
    this.initDataHash(d);
  },
  isSameData(newData, oldData) {
    if (newData.length !== oldData.length) {
      return false;
    }
    const generateHash = (obj) => {
      return JSON.stringify(obj, Object.keys(obj).sort());
    };
    const hashes1 = newData.map(generateHash);
    const hashes2 = oldData.map(generateHash);
    for (let i = 0; i < hashes1.length; i++) {
      if (hashes1[i] !== hashes2[i]) {
        return false;
      }
    }
    return true;
  },
  reloadData: function() {
    if (!this.jsonData) {
      storeLogger.warn("can't find last jsonData, reload data fail");
      return;
    }
    this.loadData(this.getRootData(this.jsonData));
  },
  forceReload: function(option, keepLastData) {
    const self = this;
    option = $.extend(true, {}, option, {
      data: {
        refresh: 1
      }
    });
    if (this.forceReloadAjax) {
      this.forceReloadAjax.abort();
    }
    this.forceReloadAjax = this.reload(option, keepLastData !== false).always(function() {
      delete self.lastOption.data.refresh;
    });
    return this.forceReloadAjax;
  },
  initDataHash: function(data) {
    const me = this, records = [];
    if (me.emit(storeEvent.beforeInitData, me, data) === false) {
      return;
    }
    if (me.emit(storeEvent.afterLoadData, me, data) === false) {
      return;
    }
    me.dataHash = {};
    me.snapshot = {};
    me.dataList = [];
    data.forEach(function(item) {
      const key = item[me.options.idProperty];
      if (key === null || typeof key === "undefined") {
        storeLogger.error("record has not %s field", me.options.idProperty);
        return false;
      }
      const d = me.dataHash[key];
      if (d) {
        storeLogger.error("record's id: %s is conflict", key);
        return false;
      }
      const model = new Model({
        data: item
      });
      model.on(modelEvent.selectedStatusChange, me.modelSelectedController, me);
      if (me.selectedIDs.has(key)) {
        model.selected = true;
      }
      me.dataHash[key] = model;
      me.snapshot[key] = model;
      me.dataList.push(key);
    });
    if (!me.shouldKeepLostSelectedData()) {
      me.cleanSelectedData();
    }
    me.emit(storeEvent.initData, me, data);
    if (this.events) {
      me.dataList.forEach(function(key) {
        records.push(me.dataHash[key]);
      });
      if (this.emit(storeEvent.beforeDataChange, me, records) !== false) {
        this.lastMsg = "";
        this.emit(storeEvent.dataChange, me, records);
      }
    }
  },
  add: function(model) {
    let id;
    const me = this;
    if (model instanceof Model) {
      id = model.get(this.options.idProperty);
      if (id === null || typeof id === "undefined") {
        storeLogger.error("record has not %s field", this.options.idProperty);
        return false;
      }
      if (this.dataHash[id]) {
        storeLogger.error("record's id: %s is conflict", id);
        return false;
      }
      model.on(modelEvent.selectedStatusChange, me.modelSelectedController, me);
      this.dataHash[id] = model;
      this.snapshot[id] = model;
      this.dataList.push(id);
      this.lastMsg = "";
      this.emit(storeEvent.add, model);
    } else if (Object.prototype.toString.call(model) === "[object Array]") {
      model.forEach(function(item) {
        me.add(item);
      });
    } else {
      storeLogger.error("record is not recognizable");
      return false;
    }
  },
  insert: function(model, index) {
    let id;
    const me = this;
    index = index || "";
    if (model instanceof Model) {
      id = model.get(this.options.idProperty);
      if (id === null || typeof id === "undefined") {
        storeLogger.error("record has not %s field", this.options.idProperty);
        return false;
      }
      if (this.dataHash[id]) {
        storeLogger.error("record's id: %s is conflict", id);
        return false;
      }
      model.on(modelEvent.selectedStatusChange, me.modelSelectedController, me);
      this.dataHash[id] = model;
      this.snapshot[id] = model;
      this.dataList.splice(this.dataList.indexOf(index) + 1, 0, id);
      this.lastMsg = "";
    } else if (Object.prototype.toString.call(model) === "[object Array]") {
      let pre = index;
      model.forEach(function(item) {
        pre = me.insert(item, pre);
      });
    } else {
      storeLogger.error("record is not recognizable");
      return false;
    }
    return id;
  },
  remove: function(model) {
    const me = this;
    let index, r;
    if (typeof model === "string" || typeof model === "number") {
      model = String(model);
      r = this.dataHash[model];
      delete this.dataHash[model];
      delete this.snapshot[model];
      index = this.dataList.indexOf(model);
      if (index !== -1) {
        this.dataList.splice(index, 1);
      }
      this.lastMsg = "";
      this.emit(storeEvent.remove, r);
    } else if (model instanceof Model) {
      this.remove(model.get(this.options.idProperty));
    } else if (Object.prototype.toString.call(model) === "[object Array]") {
      model.forEach(function(item) {
        me.remove(item);
      });
    }
  },
  get: function(key) {
    return this.dataHash[key];
  },
  getAllKeys: function(records) {
    const me = this;
    return $.makeArray(records).map(function(record) {
      if (record instanceof Model) {
        return record.get(me.options.idProperty);
      } else if ($.isPlainObject(record)) {
        return record[me.options.idProperty];
      }
      return record;
    });
  },
  getKeys: function(records) {
    const me = this;
    return this.getAllKeys(records).filter(function(key) {
      return me.dataHash[key];
    });
  },
  toModels: function(records) {
    const me = this;
    return me.getKeys(records).map(function(key) {
      return me.dataHash[key];
    });
  },
  toAllModels: function(records) {
    const me = this;
    return $.makeArray(records).map(function(record) {
      const key = me.getKeys(record)[0];
      if (key) {
        return me.dataHash[key];
      }
      if (record instanceof Model) {
        return record;
      }
      const model = new Model({
        data: record
      });
      model.on(modelEvent.selectedStatusChange, me.modelSelectedController, me);
      return model;
    });
  },
  clearData: function() {
    this.dataHash = {};
    this.snapshot = {};
  },
  getRange: function(start, limit) {
    return this.getVisibleRecords().slice(start, start + limit);
  },
  searchAgain: function() {
    this.search.apply(this, this.searchArguments);
  },
  doSearch: function(str, options) {
    const store = this, dataHash = store.dataHash;
    let record, matchList, key;
    options = $.extend(
      {
        matchCase: false,
        match: ["name"]
      },
      store.grid.options.search,
      options
    );
    str = $.trim(str || "");
    this.searchArguments = $.extend(true, [], arguments);
    this.clearInvisible();
    if (!str && !$.isFunction(options.match)) {
      return;
    }
    if ($.isArray(options.match)) {
      matchList = options.match;
      options.match = function(_record, _strReg) {
        return matchList.some(function(fieldName) {
          return _strReg.test(_record.get(fieldName));
        });
      };
    }
    const strReg = new RegExp(Format.escapeRegex(str), options.matchCase ? "" : "i");
    for (key in dataHash) {
      if (!dataHash.hasOwnProperty(key)) {
        continue;
      }
      record = dataHash[key];
      if (record.get("__type") === "group") {
        continue;
      }
      if (!options.match(record, strReg, str)) {
        this.addInvisible(record);
      }
    }
  },
  search: function() {
    this.doSearch.apply(this, arguments);
    this.emit(storeEvent.search);
  },
  endSearch: function() {
    this.doSearch();
    this.emit(storeEvent.endSearch);
  },
  clearInvisible: function() {
    this.invisibleHash = {};
  },
  addInvisible: function(record) {
    const me = this;
    me.getKeys(record).forEach(function(id) {
      me.invisibleHash[id] = true;
    });
  },
  getVisibleRecords: function() {
    const dataHash = this.dataHash;
    const invisibleHash = this.invisibleHash;
    const innerStart = this.getInnerStart();
    const innerLimit = this.getInnerLimit();
    if (innerStart !== void 0 && innerLimit !== void 0) {
      return this.dataList.filter((key) => !invisibleHash[key]).slice(innerStart, innerStart + innerLimit).map((key) => dataHash[key]);
    }
    return this.dataList.filter((key) => !invisibleHash[key]).map((key) => dataHash[key]);
  },
  getGlobalRecords: function() {
    const dataHash = this.dataHash;
    const invisibleHash = this.invisibleHash;
    return this.dataList.filter((key) => !invisibleHash[key]).map((key) => dataHash[key]);
  },
  getData: function() {
    return $.extend(
      true,
      [],
      Object.values(this.dataHash).map(function(item) {
        return item.data;
      })
    );
  },
  getCount: function() {
    const invisibleHash = this.invisibleHash;
    return this.dataList.filter(function(key) {
      return !invisibleHash[key];
    }).length;
  },
  getSinglePageCount: function() {
    return this.getVisibleRecords().length;
  },
  stop: function() {
    if (this.lastAjax) {
      this.lastAjax.abort();
    }
  },
  changePagingInfo: function(data) {
    const me = this;
    const records = [];
    me.setInnerStart(data.start);
    me.setInnerLimit(data.limit);
    const options = { data };
    apply.applyIf(options, me.lastOption);
    me.storeOptions(options);
    me.dataList.forEach(function(key) {
      records.push(me.dataHash[key]);
    });
    me.emit(storeEvent.dataChange, me, records);
  },
  initSelected: function() {
    if (!this.selectedIDs) {
      this.selectedIDs = /* @__PURE__ */ new Set();
    }
    if (!this.selectedHash) {
      this.selectedHash = {};
    }
  },
  modelSelectedController: function(record, selected) {
    const store = this;
    const recordID = record.get(store.options.idProperty);
    if (selected) {
      store.setSelectedRecord(recordID, record);
      return;
    }
    store.removeSelectedRecord(recordID);
  },
  setSelectedRecord: function(id, record) {
    this.selectedIDs.add(id);
    record.selected = true;
    this.selectedHash[id] = record;
  },
  removeSelectedRecord: function(id, record) {
    if (record) {
      record.selected = false;
    }
    this.selectedIDs.delete(id);
    this.selectedHash[id] = null;
    delete this.selectedHash[id];
  },
  getSelectedIDs: function() {
    const res = [];
    for (const id of this.selectedIDs.values()) {
      res.push(id);
    }
    return res;
  },
  isInvisible: function(record) {
    const key = this.getKeys(record)[0];
    return !!this.invisibleHash[key];
  },
  clearSelectionsGlobally: function() {
    const store = this;
    for (const selectionID of store.getSelectedIDs()) {
      store.selectedHash[selectionID].selected = false;
    }
  },
  selelectAllGlobally: function() {
    const store = this;
    const globalRecords = store.getGlobalRecords();
    for (const record of globalRecords) {
      if (record.selectAble === false || record.get("__disabled") || store.isInvisible(record)) {
        continue;
      }
      record.selected = true;
    }
  },
  reverseSelectionsGlobally: function() {
    const store = this;
    const globalRecords = store.getGlobalRecords();
    for (const record of globalRecords) {
      if (record.selectAble === false || record.get("__disabled") || store.isInvisible(record)) {
        continue;
      }
      record.selected = !record.selected;
    }
  },
  setInnerStart(val) {
    this.innerStart = val;
  },
  getInnerStart() {
    return this.innerStart;
  },
  setInnerLimit(val) {
    this.innerLimit = val;
  },
  getInnerLimit() {
    return this.innerLimit;
  },
  shouldKeepLostSelectedData() {
    return this.options.keepLostSelectedData;
  },
  cleanSelectedData() {
    let actuallyCleaned = false;
    const current = [...this.selectedIDs];
    current.forEach((id) => {
      if (!this.dataHash[id]) {
        this.removeSelectedRecord(id);
        actuallyCleaned = true;
      }
    });
    if (actuallyCleaned) {
      this.emit(storeEvent.afterCleanSelectedData);
    }
  },
  isLoading: function() {
    return this.loading;
  },
  getIdProperty: function() {
    return this.options.idProperty;
  },
  destroy: function() {
    this.purgeListeners();
    if (this.lastAjax) {
      this.lastAjax.abort();
      delete this.lastAjax;
    }
    delete this.dataList;
    delete this.dataHash;
    delete this.snapshot;
    delete this.options;
    delete this.selectedIDs;
    this.isDestroyed = true;
  },
  updateData(id, data = {}) {
    const idProperty = this.options.idProperty;
    const recordId = isPlainObject(id) ? id[idProperty] || "" : id;
    const record = this.dataHash[recordId];
    if (!record) {
      storeLogger.warn("can't find data id, update data fail");
      return;
    }
    for (const key in data) {
      if (data.hasOwnProperty(key) && key !== idProperty) {
        record.data[key] = data[key];
      }
    }
  }
});
const getDefaultConfigs$b = () => ({
  remoteSort: false,
  pluginId: pluginId.action
});
const mode$1 = {
  single: "single",
  multi: "multi"
};
const getDefaultConfigs$a = () => ({
  mode: mode$1.single,
  selectDisabledRecord: false,
  pluginId: pluginId.selection,
  noSelections: [],
  selectIllegalRecord: false
});
function parseSelectOptions(options) {
  if (!$.isPlainObject(options)) {
    options = {
      force: options
    };
  }
  return $.extend(
    {
      force: false,
      noEvent: false,
      redraw: true
    },
    options
  );
}
const { isArray, isFunction, isObject } = Lang;
const SelectionLogger = Logger("Selection");
const itemSel$1 = ".sfis-grid-body-item";
const selectedCls = "sfis-grid-body-item-selected";
const disabledCls$1 = "sfis-grid-body-item-disabled";
const Selection = oop.extend(Observable, {
  constructor: function(options) {
    this.options = {
      ...getDefaultConfigs$a(),
      ...options
    };
    this.listeners = this.options.listeners;
    const { beforeSelect, select, unselect, selectAll, unselectAll, change } = selectionEvent;
    this.addEvents(
      beforeSelect,
      select,
      unselect,
      selectAll,
      unselectAll,
      change
    );
    Selection.superclass.constructor.apply(this, arguments);
    if (this.options.noSelections && !isArray(this.options.noSelections)) {
      this.options.noSelections = [this.options.noSelections];
    }
  },
  init: function(grid) {
    const own = this;
    if (!grid) {
      SelectionLogger.error("cant't find grid, Selection do not work");
      return;
    }
    this.grid = grid;
    if (isArray(this.options.noSelections) && this.options.noSelections.length) {
      this.grid.store.on(
        storeEvent.beforeDataChange,
        function(store, rs) {
          if (!isArray(rs)) {
            return;
          }
          rs.forEach(function(r) {
            own.options.noSelections.forEach(function(obj) {
              if (obj.value && !isArray(obj.value)) {
                obj.value = [obj.value];
              }
              if (obj.value && obj.value.indexOf(r.get(obj.key)) !== -1 || isFunction(obj.checkFn) && obj.checkFn(r)) {
                r.selectAble = false;
                own.setRowTip(r, obj);
                if (isFunction(obj.renderer)) {
                  r.__renderer__ = obj.renderer;
                }
              }
            });
          });
        },
        this
      );
    }
    this.grid.on(gridEvent.afterRender, this.onAfterRender, this);
    this.grid.on(gridEvent.beforeCreateViewTr, ({ classList, attrs }, { record }) => {
      if (record.get("__type") === "group") {
        return;
      }
      const notAllowToSelect = record.selectAble === false || record.get("__disabled");
      if (record.selectAble !== false && record.selected || notAllowToSelect && record.selectDisabled) {
        classList.push(getPrefixedClassName(selectedCls));
      }
      if (record.get("__disabled")) {
        classList.push(getPrefixedClassName(disabledCls$1));
      }
      const rowTip = own.getRowTip(record);
      Object.assign(attrs, rowTip, { selectable: `${record.selectAble !== false}` });
    });
    this.grid.store.on(storeEvent.afterCleanSelectedData, () => {
      this.emit(selectionEvent.change, this, this.getSelections());
    });
  },
  getId: function() {
    return this.options.pluginId;
  },
  setRowTip: function(record, noSelectionObj) {
    const baseSetting = {
      "data-hint-pos": "bc"
    };
    if (isFunction(noSelectionObj.rowTip)) {
      record.__rowTip = { ...baseSetting };
      record.__rowTip["data-tip"] = noSelectionObj.rowTip(record);
      return;
    }
    if (isObject(noSelectionObj.rowTip)) {
      const rowTipType = noSelectionObj.rowTip.useHint === true ? "data-hint" : "data-tip";
      record.__rowTip = { ...baseSetting };
      record.__rowTip[rowTipType] = noSelectionObj.rowTip.render(record);
    }
  },
  getRowTip: function(record) {
    return record.__rowTip || {};
  },
  onAfterRender: function() {
    const me = this;
    this.grid.gridEl.delegate(itemSel$1, "click", function(event2) {
      const key = Format.htmlDecode($(this).data("id"));
      const record = me.grid.store.get(key);
      if (!record) {
        SelectionLogger.error("record is missing");
        return;
      }
      if (!me.options.selectDisabledRecord && (record.selectAble === false || record.get("__disabled"))) {
        return;
      }
      me.doRowClick(this, record, event2);
    });
  },
  doRowClick: function() {
    switch (this.options.mode) {
      case mode$1.single:
        this.doRowSingleClick.apply(this, arguments);
        break;
      case mode$1.multi:
        this.doRowMultiClick.apply(this, arguments);
        break;
    }
  },
  doRowSingleClick: function(dom, record) {
    this.unSelect(this.getSelections().concat(this.getDisabledSelect()));
    this.select(record, dom);
  },
  doRowMultiClick: function(dom, record) {
    if (record.selected) {
      this.unSelect(record);
    } else {
      this.select(record);
    }
  },
  setDisabled: function(record, disabled) {
    const me = this;
    disabled = typeof disabled === "undefined" ? true : disabled;
    $.makeArray(record).forEach(function(r) {
      if (typeof r === "string" || typeof r === "number") {
        r = me.grid.store.get(r);
      }
      if (!r) {
        return;
      }
      r.set("__disabled", disabled);
      if (me.grid.rendered) {
        $(
          itemSel$1 + '[data-id="' + String(r.get(me.grid.store.options.idProperty)).replace(/"/g, '\\"') + '"]',
          me.grid.gridEl
        ).toggleClass(getPrefixedClassName(disabledCls$1), disabled);
      }
    });
  },
  setTitle: function(records, title) {
    const me = this, store = me.grid.store;
    store.getKeys(records).map(function(record) {
      return typeof record === "object" ? record : store.get(record);
    }).forEach(function(record) {
      record.set("__selectionTitle", title);
    });
  },
  getSelectRecord: function(record, r) {
    const me = this;
    const dataHash = me.grid.store.dataHash;
    const selectedHash = me.grid.store.selectedHash;
    const idProperty = me.grid.store.getIdProperty();
    let result = dataHash[r];
    if (result) {
      return result;
    }
    if (selectedHash[r]) {
      result = selectedHash[r];
      return result;
    }
    if (!Array.isArray(record)) {
      record = [record];
    }
    const data = record.find((i) => i[idProperty] === r);
    if (data) {
      result = new Model({ data });
      return result;
    }
    return null;
  },
  getRecordDisabled: function(record) {
    const own = this;
    let disabled = false;
    if ($.isArray(own.options.noSelections) && own.options.noSelections.length) {
      own.options.noSelections.forEach((obj) => {
        disabled = own.getDisabled(record, obj);
      });
      if (disabled) {
        return disabled;
      }
    }
    own.options.disabled = $.makeArray(own.options.disabled);
    own.options.disabled.forEach(function(obj) {
      disabled = own.getDisabled(record, obj);
    });
    return disabled;
  },
  getDisabled: function(record, obj) {
    let disabled = false;
    obj.value = $.makeArray(obj.value);
    obj.checkFn = obj.checkFn || $.noop;
    if (obj.value.indexOf(record.get(obj.key)) >= 0 || obj.checkFn(record)) {
      disabled = true;
    }
    return disabled;
  },
  select: function(record, options) {
    if (!record) {
      return;
    }
    const me = this;
    options = parseSelectOptions(options);
    const toKeysRecord = me.grid.store.getAllKeys(record);
    toKeysRecord.forEach(function(r) {
      if (!me.options.selectIllegalRecord && (typeof r === "string" || typeof r === "number")) {
        if (!me.grid.store.get(r)) {
          SelectionLogger.error("can not find the record: ", r);
          return;
        }
      }
      if (me.grid.rendered) {
        const name = itemSel$1 + '[data-id="' + String(r).replace(/"/g, '\\"') + '"]';
        $(name, me.grid.gridEl).addClass(getPrefixedClassName(selectedCls));
      }
      const selectRecord = me.getSelectRecord(record, r);
      if (!(selectRecord instanceof Model)) {
        return;
      }
      const disabled = me.getRecordDisabled(selectRecord);
      if (!me.options.selectDisabledRecord && (selectRecord.selectAble === false || !options.force && disabled)) {
        return;
      }
      me.grid.store.setSelectedRecord(r, selectRecord);
      if (selectRecord.selectAble === false || disabled) {
        selectRecord.selectDisabled = true;
      }
      if (!options.noEvent) {
        me.emit(selectionEvent.select, selectRecord);
        me.emit(selectionEvent.change, me, me.getSelections());
      }
    });
  },
  unSelect: function(record, options) {
    if (!record) {
      return;
    }
    const me = this;
    options = parseSelectOptions(options);
    const toKeysRecord = me.grid.store.getAllKeys(record);
    toKeysRecord.forEach(function(r) {
      if (me.grid.rendered) {
        const name = itemSel$1 + '[data-id="' + String(r).replace(/"/g, '\\"') + '"]';
        $(name, me.grid.gridEl).removeClass(getPrefixedClassName(selectedCls));
      }
      const selectRecord = me.getSelectRecord(record, r);
      if (!(selectRecord instanceof Model)) {
        return;
      }
      const disabled = me.getRecordDisabled(selectRecord);
      if (!me.options.selectDisabledRecord && (selectRecord.selectAble === false || !options.force && disabled)) {
        return;
      }
      me.grid.store.removeSelectedRecord(r, selectRecord);
      if (selectRecord.selectAble === false || disabled) {
        selectRecord.selectDisabled = false;
      }
      if (!options.noEvent) {
        me.emit(selectionEvent.unselect, selectRecord);
        me.emit(selectionEvent.change, me, me.getSelections());
      }
    });
  },
  unSelectAll: function(options) {
    const currentPageRecords = this.grid.store.getVisibleRecords();
    options = parseSelectOptions(options);
    for (const record of currentPageRecords) {
      if (record.selectAble === false || !options.force && record.get("__disabled")) {
        continue;
      }
      record.selected = false;
    }
    if (!options.noEvent) {
      this.emit(selectionEvent.unselectAll);
      this.emit(selectionEvent.change, this, this.getSelections());
    }
    if (this.grid.rendered && options.redraw) {
      this.grid.renderView();
    }
  },
  selectAll: function(options) {
    const currentPageRecords = this.grid.store.getVisibleRecords();
    options = parseSelectOptions(options);
    for (const record of currentPageRecords) {
      if (record.selectAble === false || !options.force && record.get("__disabled") || this.grid.store.isInvisible(record)) {
        continue;
      }
      record.selected = true;
    }
    if (!options.noEvent) {
      this.emit(selectionEvent.selectAll);
      this.emit(selectionEvent.change, this, this.getSelections());
    }
    if (this.grid.rendered && options.redraw) {
      this.grid.renderView();
    }
  },
  getSelections: function() {
    const ret = [];
    for (const item of Object.values(this.grid.store.selectedHash)) {
      ret.push(item);
    }
    return ret;
  },
  getUnSelections: function() {
    const ret = [];
    let r;
    for (const key in this.grid.store.dataHash) {
      if (this.grid.store.dataHash.hasOwnProperty(key)) {
        r = this.grid.store.dataHash[key];
        if (!r.selected && r.selectAble !== false) {
          ret.push(r);
        }
      }
    }
    return ret;
  },
  getDisabledSelect: function() {
    const ret = [];
    let r;
    for (const key in this.grid.store.dataHash) {
      if (this.grid.store.dataHash.hasOwnProperty(key)) {
        r = this.grid.store.dataHash[key];
        if (r.selectDisabled) {
          ret.push(r);
        }
      }
    }
    return ret;
  },
  autoSelectRecordFn: function(lastSelections) {
    const store = this.grid.store;
    if (lastSelections && lastSelections.length) {
      const lostSelections = [];
      lastSelections.forEach(function(record) {
        const key = record.get(store.options.idProperty);
        if (!key || !store.get(key)) {
          lostSelections.push(record);
          return;
        }
        if (record.selectAble === false) {
          store.get(key).selectDisabled = true;
        } else {
          store.get(key).selected = true;
        }
      });
      if (lostSelections.length) {
        this.emit(selectionEvent.change, this, this.getSelections());
      }
    }
  },
  destroy: function() {
    this.purgeListeners();
  }
});
Selection.pluginId = pluginId.selection;
const ActionLogger = Logger("GridAction");
const Action = oop.extend(Observable, {
  constructor: function(options) {
    this.options = {
      ...getDefaultConfigs$b(),
      ...options
    };
    this.listeners = this.options.listeners;
    Action.superclass.constructor.apply(this, arguments);
  },
  init: function(grid) {
    if (!grid) {
      ActionLogger.error("cant't find grid, Sortable do not work");
      return;
    }
    this.grid = grid;
    grid.on(gridEvent.afterRender, this.onAfterRender, this);
  },
  getId: function() {
    return this.options.pluginId;
  },
  onAfterRender: function() {
    const me = this;
    this.grid.gridEl.delegate("[action]", "click", function(event2) {
      const actionName = $(this).attr("action");
      me.fireAction(actionName, event2);
    });
  },
  fireAction: function(actionName, event2) {
    const fn = this.grid.options["onGrid" + Format.capitalize(actionName)];
    let rs;
    if (typeof fn === "function") {
      rs = this.getSelections(event2);
      fn.call(this.grid, this.grid, rs, event2, actionName);
    }
  },
  getSelections: function(event2) {
    let selection, record, id;
    const item = $(event2.target).closest("tr[data-id]");
    if (item.length) {
      id = Format.htmlDecode(item.data("id"));
      record = this.grid.store.get(id);
      return record ? [record] : [];
    } else {
      selection = this.grid.getPlugin(Selection);
      if (selection) {
        return selection.getSelections();
      }
    }
    return [];
  },
  destroy: function() {
    if (this.grid && this.grid.gridEl) {
      this.grid.gridEl.undelegate("[action]", "click");
    }
    this.purgeListeners();
    delete this.grid;
  }
});
Action.pluginId = pluginId.action;
const getDefaultConfigs$9 = () => ({
  interval: 5 * 1e3,
  autoLoad: false,
  pluginId: pluginId.autoRefresh
});
const AutoRefreshLogger = Logger("AutoRefresh");
const AutoRefresh = oop.extend(Observable, {
  constructor: function(options) {
    this.options = {
      ...getDefaultConfigs$9(),
      ...options
    };
    this.listeners = this.options.listeners;
    AutoRefresh.superclass.constructor.apply(this, arguments);
  },
  init: function(grid) {
    if (!grid) {
      AutoRefreshLogger.error("cant't find grid, AutoRefresh do not work");
      return;
    }
    this.store = grid.store;
    this.task = new DelayedTask(this.load, this);
    if (this.options.autoLoad) {
      this.start();
    }
  },
  getId: function() {
    return this.options.pluginId;
  },
  reloadTask: function() {
    if (!this.task) {
      return;
    }
    this.task.delay(this.options.interval);
  },
  setTntervalTime: function(value) {
    return this.setIntervalTime(value);
  },
  setIntervalTime: function(value) {
    if (Number(value)) {
      this.options.interval = Number(value);
    }
  },
  load: function() {
    const me = this;
    if (this.suspended) {
      this.reloadTask();
      return;
    }
    if (this.store.lastAjax) {
      this.store.lastAjax.always(function() {
        me.reloadTask();
      });
      return;
    }
    this.store.reload({
      scope: this
    }).always(function() {
      me.reloadTask();
    });
  },
  start: function(delay) {
    this.suspended = false;
    if (delay) {
      this.reloadTask();
    } else {
      this.load();
    }
  },
  stop: function() {
    this.task.cancel();
    if (this.store.lastAjax) {
      this.store.lastAjax.abort();
    }
    this.suspended = true;
  },
  suspend: function() {
    this.suspended = true;
  },
  resume: function() {
    this.suspended = false;
  },
  destroy: function() {
    this.stop();
    this.task = null;
    this.clear();
  }
});
AutoRefresh.pluginId = pluginId.autoRefresh;
const mode = Object.assign(
  {
    simple: "simple"
  },
  mode$1
);
const getDefaultConfigs$8 = () => ({
  pluginId: pluginId.checkSelection,
  mode: mode.multi,
  width: "40px",
  canSelectAll: true,
  noSelections: [],
  tipFn: null,
  disabled: [],
  showSelectionBar: false,
  checkboxInTreeField: false,
  beforeSelect: () => true
});
const CheckSelectionLogger = Logger("CheckSelection");
const itemSel = "sfis-grid-body-item";
const headerCheckCls$1 = "sfis-grid-column-header-check";
const headerCheckAllCls$1 = "sfis-grid-column-header-check-all";
const columnCheckWrapCls$3 = "sfis-grid-column-ceil-wrap-check";
const columnCheckCls$3 = "sfis-grid-column-ceil-check";
const headerCheckPartCls$1 = "sfis-grid-column-header-check-part";
const CheckSelection = oop.extend(Selection, {
  constructor: function(options) {
    this.options = {
      ...getDefaultConfigs$8(),
      ...options
    };
    if (this.options.showSelectionBar) {
      this.checkSelectionBarFactory = this.options.checkSelectionBarFactory;
      delete this.options.checkSelectionBarFactory;
    }
    CheckSelection.superclass.constructor.apply(this, [this.options]);
    if (this.options.noSelections && !$.isArray(this.options.noSelections)) {
      this.options.noSelections = [this.options.noSelections];
    }
    this.options.disabled = $.makeArray(this.options.disabled);
  },
  init: function() {
    const own = this;
    CheckSelection.superclass.init.apply(this, arguments);
    if ($.isArray(this.options.noSelections) && this.options.noSelections.length) {
      this.grid.store.on(
        storeEvent.beforeDataChange,
        function(store, rs) {
          if (!$.isArray(rs)) {
            return;
          }
          rs.forEach(function(r) {
            own.options.noSelections.forEach(function(obj) {
              if (obj.renderer === "checkbox") {
                r.__renderCls__ = "no-selection-checkbox";
              } else if (obj.renderer === "radio") {
                r.__renderCls__ = "no-selection-radio";
              } else {
                r.__renderCls__ = "";
              }
              if (r.selectAble === false && typeof obj.renderer === "function") {
                r.__renderer__ = obj.renderer;
                return;
              }
              if (own.getDisabled(r, obj)) {
                r.selectAble = false;
                if (typeof obj.renderer === "function") {
                  r.__renderer__ = obj.renderer;
                }
              }
            });
          });
        },
        this
      );
    }
    if (this.options.disabled.length) {
      this.grid.store.on(
        storeEvent.beforeDataChange,
        function(store, rs) {
          $.makeArray(rs).forEach(function(r) {
            own.options.disabled.forEach(function(obj) {
              if (own.getDisabled(r, obj)) {
                r.set("__disabled", true);
              }
            });
          });
        },
        this
      );
    }
    this.grid.on(gridEvent.onGenerateHeaderRow, (moreTdElements, rowInfo) => {
      const { rowIndex, headerRowNum } = rowInfo;
      if (rowIndex === 0) {
        const rowspan = headerRowNum - rowIndex;
        const checkSelectionFragment = [];
        const tdClass = `${getPrefixedClassName("sfis-grid-column-check")} ${getPrefixedClassName(
          "sfis-grid-functional-column"
        )}`;
        checkSelectionFragment.push(`<td class="${tdClass}" style="width: ${own.options.width}" rowspan="${rowspan}">`);
        if (own.options.canSelectAll) {
          checkSelectionFragment.push('<div class="' + getPrefixedClassName(headerCheckCls$1) + '"></div>');
        }
        checkSelectionFragment.push("</td>");
        moreTdElements.push({
          order: functionalColumnOrder[pluginId.checkSelection],
          html: checkSelectionFragment.join("")
        });
      }
    });
    this.grid.on(gridEvent.onGridColFragmentCreated, (moreColElements, suffix) => {
      const fragment = document.createDocumentFragment();
      const checkColEl = document.createElement("col");
      checkColEl.id = "sfis-grid-column-check" + suffix;
      fragment.append(checkColEl);
      moreColElements.push({
        order: functionalColumnOrder[pluginId.checkSelection],
        element: fragment
      });
    });
    this.grid.on(gridEvent.onGenerateViewTd, (moreTdElements, rowInfo) => {
      const { record } = rowInfo;
      if (record.get("__type") === "group") {
        return;
      }
      const grid = own.grid;
      let selectionTitle = (record.get("__selectionTitle") || "").trim();
      if (!selectionTitle && typeof own.options.tipFn === "function") {
        selectionTitle = own.options.tipFn(record);
      }
      selectionTitle = Format.htmlEncode(selectionTitle);
      const isNoChildSelection = own.options.noChildSelection;
      const noChildSelectionHtml = `<td class="${getPrefixedClassName(columnCheckWrapCls$3)}" style="width:${own.options.width}; padding: 0;"></td>`;
      if (isNoChildSelection) {
        moreTdElements.push({
          order: functionalColumnOrder[pluginId.checkSelection],
          html: noChildSelectionHtml
        });
        return;
      }
      if (record.selectAble === false) {
        let text = "-";
        let isText = true;
        let textCls = "";
        if (typeof record.__renderer__ === "function") {
          text = record.__renderer__.call(grid, record) || "-";
        }
        isText = !/<[^>]+>/.test(text);
        if (isText) {
          textCls = getPrefixedClassName("no-selection-text");
        }
        const unSelectAbleHtml = `<td class="${getPrefixedClassName(columnCheckWrapCls$3)}" style="width:${own.options.width}"><div class="${getPrefixedClassName(columnCheckCls$3)} ${getPrefixedClassName(textCls)} ${getPrefixedClassName(
          record.__renderCls__
        )}" data-hint="${selectionTitle}">${text}</div></td>`;
        moreTdElements.push({
          order: functionalColumnOrder[pluginId.checkSelection],
          html: unSelectAbleHtml
        });
      } else {
        const selectAbleHtml = `<td class="${getPrefixedClassName(columnCheckWrapCls$3)}" style="width:${own.options.width}"><div class="${getPrefixedClassName(columnCheckCls$3)}" data-hint="${selectionTitle}"></div></td>`;
        moreTdElements.push({
          order: functionalColumnOrder[pluginId.checkSelection],
          html: selectAbleHtml
        });
      }
    });
    this.grid.on(
      gridEvent.viewReady,
      function() {
        const checkSelection = this;
        if (checkSelection.options.showSelectionBar && !checkSelection.getCheckSelectionBar()) {
          checkSelection.initCheckSelectionBar();
        }
        checkSelection.updateHeaderState();
        if (this.options.checkboxInTreeField) {
          this.hideCol();
          this.hideCheckColumn();
        }
      },
      this
    );
  },
  onAfterRender: function() {
    const me = this;
    if (this.options.mode === mode.simple) {
      this.grid.gridEl.delegate("." + columnCheckWrapCls$3, "click", function(event2) {
        const columnCheckWrap = this;
        const item = $(columnCheckWrap).parents("." + itemSel);
        if (!item.length) {
          return;
        }
        const key = Format.htmlDecode(item.data("id"));
        const record = me.grid.store.get(key);
        if (!record) {
          CheckSelectionLogger.error("record is missing");
          return;
        }
        me.doRowClick(item, record, event2);
      });
    } else {
      CheckSelection.superclass.onAfterRender.apply(this, arguments);
    }
    this.grid.gridEl.delegate("." + headerCheckCls$1, "click", function() {
      const headerCheck = this;
      if ($(headerCheck).hasClass(headerCheckAllCls$1)) {
        $(headerCheck).removeClass(getPrefixedClassName(headerCheckAllCls$1));
        me.unSelectAll();
      } else {
        $(headerCheck).addClass(getPrefixedClassName(headerCheckAllCls$1));
        me.selectAll();
      }
    });
  },
  doRowClick: function(el, record, event2) {
    const _this = this;
    const args = arguments;
    if (_this.options.noChildSelection) {
      return;
    }
    const unresponsive = record.get("__disabled") || record.selectAble === false;
    if (_this.emit(checkSelectionEvent.beforeSelect, record, event2) === false || unresponsive) {
      return;
    }
    when(_this.options.beforeSelect(record.data)).then(function(result) {
      if (result === false) {
        return;
      }
      if (_this.options.mode === mode.simple) {
        _this.doRowSimpleClick.apply(_this, args);
      } else {
        if (_this.options.mode === mode.single) {
          if ($(event2.target).hasClass(columnCheckCls$3) || $(event2.target).hasClass(columnCheckWrapCls$3)) {
            _this.doRowMultiClick.apply(_this, args);
            return;
          }
        }
        CheckSelection.superclass.doRowClick.apply(_this, args);
      }
    });
  },
  doRowSimpleClick: function() {
    if (this.options.noChildSelection) {
      return;
    }
    this.doRowMultiClick.apply(this, arguments);
  },
  select: function() {
    CheckSelection.superclass.select.apply(this, arguments);
    this.updateHeaderState();
  },
  unSelect: function() {
    CheckSelection.superclass.unSelect.apply(this, arguments);
    this.updateHeaderState();
  },
  selectAll: function() {
    CheckSelection.superclass.selectAll.apply(this, arguments);
    this.updateHeaderState();
  },
  unSelectAll: function() {
    CheckSelection.superclass.unSelectAll.apply(this, arguments);
    this.updateHeaderState();
  },
  updateHeaderState: function() {
    let hasSelected = false;
    let hasUnselected = false;
    let groupFlag = false;
    const currentPageRecords = this.grid.store.getVisibleRecords();
    const currentPageSelectAbleRecord = currentPageRecords.filter(
      (item) => item.selectAble !== false && !item.get("__disabled")
    );
    if (!this.grid.gridEl) {
      return;
    }
    const $header = this.grid.gridEl.find("." + headerCheckCls$1);
    for (const record of currentPageSelectAbleRecord) {
      groupFlag = record.get("__children") && !record.get("__isTreeGroup");
      if (groupFlag) {
        continue;
      }
      hasUnselected = hasUnselected || record.selected !== true;
      hasSelected = hasSelected || record.selected === true;
      if (hasUnselected && hasSelected) {
        break;
      }
    }
    $header.removeClass(getPrefixedClassName(headerCheckAllCls$1) + " " + getPrefixedClassName(headerCheckPartCls$1));
    if (hasSelected && hasUnselected) {
      $header.addClass(getPrefixedClassName(headerCheckPartCls$1));
    } else if (hasSelected) {
      $header.addClass(getPrefixedClassName(headerCheckAllCls$1));
    }
    this.renderCheckSelectionBar();
  },
  initCheckSelectionBar: function() {
    const me = this;
    if (typeof me.checkSelectionBarFactory !== "function") {
      CheckSelectionLogger.error("checkSelectionBarFactory is needed, when showSelectionBar is true");
      return;
    }
    const container = me.generateCheckSelectionBarContainer();
    me.checkSelectionBar = me.checkSelectionBarFactory(me, container);
  },
  generateCheckSelectionBarContainer: function() {
    const me = this;
    const grid = me.grid;
    const CHECK_SELECTION_BAR_CLASS_NAME = "sfis-header-check-selection-bar";
    const CHECK_SELECTION_BAR_ID = `${grid.getId()}-header-check-selection-bar`;
    const container = document.createElement("div");
    container.classList.add(...getPrefixedClassList(CHECK_SELECTION_BAR_CLASS_NAME));
    container.id = CHECK_SELECTION_BAR_ID;
    const $container = $(container);
    grid.headerEl.append($container);
    return $container;
  },
  getCheckSelectionBar: function() {
    return this.checkSelectionBar;
  },
  renderCheckSelectionBar: function() {
    const me = this;
    if (!me.options.showSelectionBar || !me.checkSelectionBar) {
      return;
    }
    const grid = me.grid;
    const store = grid.store;
    const selectedIDs = store.getSelectedIDs();
    this.checkSelectionBar.setCurrentSelections(selectedIDs);
  },
  globallyOperateSelections: function(operateType) {
    const me = this;
    const grid = me.grid;
    const store = grid.store;
    switch (operateType) {
      case "selectAll":
        store.selelectAllGlobally();
        break;
      case "reverseSelections":
        store.reverseSelectionsGlobally();
        break;
      case "clearSelections":
        store.clearSelectionsGlobally();
        break;
    }
    me.afterGloballyOperate();
  },
  afterGloballyOperate: function() {
    const me = this;
    const grid = me.grid;
    me.emit(checkSelectionEvent.change, me, me.getSelections());
    if (grid.rendered) {
      grid.renderView();
    }
  },
  checkSelectionBarVisibilityChanged: function() {
    const grid = this.grid;
    grid.emit(gridEvent.headerHeightChange);
  },
  destroyCheckSelectionBar: function() {
    if (this.checkSelectionBar) {
      if (typeof this.checkSelectionBar.destroy === "function") {
        this.checkSelectionBar.destroy();
      }
      this.checkSelectionBar = null;
    }
  },
  destroy: function() {
    this.destroyCheckSelectionBar();
    CheckSelection.superclass.destroy.apply(this, arguments);
  },
  hideCol() {
    const grid = this.grid;
    const headerColId = `#sfis-grid-column-check${grid.GRID_HEADER_COL_ELEMENT_COMMON_SUFFIX}`;
    const bodyColId = `#sfis-grid-column-check${grid.GRID_BODY_COL_ELEMENT_COMMON_SUFFIX}`;
    grid.headerColumnEl.find(headerColId).hide();
    grid.viewEl.find(bodyColId).hide();
  },
  hideCheckColumn() {
    const checkColumnClass = ".sfis-grid-column-check";
    this.grid.headerColumnEl.find(checkColumnClass).hide();
  }
});
CheckSelection.pluginId = pluginId.checkSelection;
const getDefaultConfigs$7 = () => ({
  pluginId: pluginId.detail,
  width: "40px",
  rowDetailCls: "",
  detailPadding: true,
  autoExpand: true,
  autoExpandAll: false,
  needToggleIcon: false,
  accordion: false
});
function insertToggleToHeader(opt) {
  opt = opt || {};
  let colID = opt.colID;
  if (!colID) {
    const firstCol = this.grid.options.column[0];
    if (!firstCol) {
      return;
    }
    colID = firstCol.id;
  }
  const $col = this.grid.headerEl.find('[data-id="' + colID + '"]');
  if (!$col.length) {
    return;
  }
  $col.addClass(getPrefixedClassName("sfis-grid-column-header-toggle"));
  const $toggle = $(`<i class="iconfont ${getPrefixedClassName("sfis-grid-header-toggle-icon")}">`);
  $col.prepend($toggle);
  function toggleClass(isExpand) {
    $toggle.toggleClass(getPrefixedClassName("is-expand"), !isExpand);
    $toggle.toggleClass("vtv-icon-tree-folded", isExpand);
    $toggle.toggleClass("vtv-icon-tree-expanded", !isExpand);
    $toggle.attr(
      "title",
      isExpand ? $i("scp.vt_component.common.widget.Grid.plugins.util.expand_all") : $i("scp.vt_component.common.widget.Grid.plugins.util.pack_up_all")
    );
  }
  toggleClass(!opt.autoExpandAll);
  $toggle.on("click", function(event2) {
    const isExpand = $toggle.hasClass("is-expand");
    toggleClass(isExpand);
    if (isExpand) {
      opt.collapseFn && opt.collapseFn();
    } else {
      opt.expandFn && opt.expandFn();
    }
    event2.stopPropagation();
  });
  return {
    toggleClass
  };
}
function getToggleStatus({ colID = "" } = {}) {
  if (!colID) {
    return {
      success: false,
      errorMsg: "colID is required!"
    };
  }
  const $col = this.grid.headerEl.find('[data-id="' + colID + '"]');
  const $toggle = $col.find(".sfis-grid-header-toggle-icon");
  return {
    success: true,
    isExpand: $toggle.hasClass("is-expand")
  };
}
const detailItemTdCls = "sfis-grid-body-detail-item-td";
const detailContentCls = "sfis-grid-body-detail-content";
const detailArwCls = "sfis-grid-detail-arw";
const detailExpandCls = "sfis-grid-detail-expanded";
const GridDetailLogger = Logger("GridDetail");
const Detail = oop.extend(Observable, {
  constructor: function(options) {
    this.options = {
      ...getDefaultConfigs$7(),
      ...options
    };
    this.options.expandedList = this.options.expandedList || [];
    this.listeners = this.options.listeners;
    this.detailColumnId = uuid("sfis-grid-column-");
    this.addEvents(detailEvent.expandDetail);
    Detail.superclass.constructor.apply(this, arguments);
  },
  init: function(grid) {
    const own = this;
    if (!grid) {
      GridDetailLogger.error("cant't find grid, Detail do not work");
      return;
    }
    this.grid = grid;
    this.grid.options.noBufferView = true;
    this.columnCount = this.grid.options.column.length;
    this.grid.getAllDataHeight = own.getAllDataHeightDetail.bind(this);
    this.registerGridHooks();
    this.bindGridStoreEvent();
    this.bindGridEvent();
  },
  bindGridStoreEvent: function() {
    const me = this;
    let hasSetExpand = false;
    this.grid.store.on(
      storeEvent.beforeInitData,
      function(store, data) {
        data.forEach(function(item) {
          const idProperty = me.grid.store.options.idProperty;
          item.__detailExpanded = false;
          if (me.options.autoExpand) {
            if (me.options.expandedList.indexOf(item[idProperty]) !== -1) {
              item.__detailExpanded = true;
            }
          }
        });
      },
      this
    );
    this.grid.store.on(storeEvent.dataChange, function() {
      if (me.options.autoExpandAll && !hasSetExpand) {
        hasSetExpand = true;
        me.expandAll();
      }
    });
  },
  bindGridEvent: function() {
    const me = this;
    this.grid.on(
      gridEvent.afterRender,
      function() {
        this.grid.gridEl.addClass(getPrefixedClassName("sfis-grid-detail")).addClass(getPrefixedClassName("sfis-grid--no-column-border"));
        if (this.options.needToggleIcon) {
          insertToggleToHeader.call(this, {
            colID: this.detailColumnId,
            collapseFn: this.collapseAll.bind(this),
            expandFn: this.expandAll.bind(this),
            autoExpandAll: this.options.autoExpandAll
          });
        }
        this.grid.gridEl.delegate("." + detailArwCls, "click", function(event2) {
          event2.stopPropagation();
          const $tr = $(this).parents(".sfis-grid-body-item"), recordId = Format.htmlDecode($tr.data("id"));
          if (me.options.accordion) {
            me.collapseAllExcept(recordId);
          }
          let index;
          if (!recordId) {
            return;
          }
          const record = me.grid.store.get(recordId), idProperty = me.grid.store.options.idProperty;
          if (!record) {
            return;
          }
          const expanded = !record.get("__detailExpanded");
          record.set("__detailExpanded", expanded);
          if (expanded) {
            me.options.expandedList.push(record.get(idProperty));
          } else {
            index = me.options.expandedList.indexOf(record.get(idProperty));
            if (index !== -1) {
              me.options.expandedList.splice(index, 1);
            }
          }
          me.emit(detailEvent.expandDetail, me, record, expanded);
          me.grid.renderView();
        });
      },
      this
    );
    this.grid.on(gridEvent.afterRenderScroll, function() {
      const count = me.getHeaderColumnCount();
      if (me.columnCount !== count) {
        me.columnCount = count;
        this.viewEl.find(".sfis-grid-detail-column").attr("colspan", count);
      }
    });
  },
  registerGridHooks: function() {
    const me = this;
    this.grid.on(gridEvent.onGenerateHeaderRow, (moreTdElements, rowInfo) => {
      const { rowIndex, headerRowNum } = rowInfo;
      if (rowIndex === 0) {
        const rowspan = headerRowNum - rowIndex;
        const detailFragment = [];
        const tdClass = `${getPrefixedClassName("sfis-grid-column-detail")} ${getPrefixedClassName(
          "sfis-grid-functional-column"
        )}`;
        detailFragment.push(
          `<td data-id="${me.detailColumnId}" class="${tdClass}" style="width: ${me.options.width}" rowspan="${rowspan}"></td>`
        );
        moreTdElements.push({
          order: functionalColumnOrder[pluginId.detail],
          html: detailFragment.join("")
        });
      }
    });
    this.grid.on(gridEvent.onGridColFragmentCreated, (colFragment, suffix) => {
      const fragment = document.createDocumentFragment();
      const detailColEl = document.createElement("col");
      detailColEl.id = "sfis-grid-column-detail" + suffix;
      fragment.append(detailColEl);
      colFragment.push({
        order: functionalColumnOrder[pluginId.detail],
        element: fragment
      });
    });
    this.grid.on(gridEvent.onGenerateViewRow, (moreContent, rowInfo) => {
      const { record, rowIndex, records } = rowInfo;
      if (record.get("__detailExpanded")) {
        const html = me.getRowHtmlDetail(record, rowIndex, records);
        moreContent.push({
          atEnd: true,
          order: 1,
          html
        });
      }
    });
    this.grid.on(gridEvent.onGenerateViewTd, (moreTdElements) => {
      const html = Format.format(
        '<td class="{0}" style="width: {1}"><div class="{2}"></div></td>',
        getPrefixedClassName(detailItemTdCls),
        me.options.width,
        getPrefixedClassName(detailArwCls)
      );
      moreTdElements.push({
        order: functionalColumnOrder[pluginId.detail],
        html
      });
    });
    this.grid.on(gridEvent.beforeCreateViewTr, ({ classList }, { record }) => {
      const isExpand = record.get("__detailExpanded");
      if (isExpand) {
        classList.push(getPrefixedClassName(detailExpandCls));
      }
    });
  },
  getHeaderColumnCount: function() {
    return this.grid.headerColumnEl.find("td").filter(function(index, el) {
      return getComputedStyle(el).display !== "none";
    }).length;
  },
  getRowHtmlDetail: function(record, rowIndex) {
    const ret = [], grid = this.grid, key = record.get(grid.store.options.idProperty), colCount = this.columnCount;
    let rowDetailCls = this.options.rowDetailCls;
    if ($.isFunction(rowDetailCls)) {
      rowDetailCls = rowDetailCls(record, rowIndex);
    }
    const index = `detail-${grid.lastStart + rowIndex}`;
    const dataId = `detail-${Format.htmlEncode(key)}`;
    const paddingCls = this.options.detailPadding ? getPrefixedClassName("has-padding") : "";
    ret.push(
      `<tr index="${index}" data-id="${dataId}" class="${getPrefixedClassName(detailContentCls)} ${rowDetailCls}">`
    );
    ret.push(
      `<td class="${getPrefixedClassName("sfis-grid-detail-column")} ${paddingCls}" colspan="${colCount}"></td>`
    );
    ret.push("</tr>");
    return ret.join("");
  },
  getAllDataHeightDetail: function() {
    const $table = this.grid.viewEl.find("table").get(0);
    if (!$table) {
      return 0;
    }
    return $table.clientHeight;
  },
  getId: function() {
    return this.options.pluginId;
  },
  expand: function(data) {
    const old = this.options.autoExpand;
    this.options.autoExpand = true;
    if (this.options.expandedList.indexOf(data) === -1) {
      this.options.expandedList.push(data);
      this.refresh();
    }
    this.options.autoExpand = old;
  },
  collapse: function(data) {
    const old = this.options.autoExpand;
    this.options.autoExpand = true;
    const index = this.options.expandedList.indexOf(data);
    if (index !== -1) {
      this.options.expandedList.splice(index, 1);
      this.refresh();
    }
    this.options.autoExpand = old;
  },
  expandAll: function() {
    const old = this.options.autoExpand;
    this.options.autoExpand = true;
    this.options.expandedList.length = 0;
    Array.prototype.push.apply(this.options.expandedList, this.grid.store.dataList);
    this.refresh();
    this.options.autoExpand = old;
  },
  getExpandList: function() {
    return this.options.expandedList || [];
  },
  collapseAll: function() {
    if (this.options.autoExpand) {
      this.options.expandedList.length = 0;
    }
    this.refresh();
  },
  collapseAllExcept: function(itemId) {
    this.options.expandedList.forEach((recordId) => {
      if (itemId === recordId) {
        return;
      }
      this.collapse(recordId);
    });
  },
  refresh: function() {
    const data = [], me = this;
    this.grid.store.dataList.forEach(function(key) {
      const record = me.grid.store.dataHash[key];
      data.push(record.data);
    });
    this.grid.store.loadData(data);
  },
  destroy: function() {
    this.clear();
    delete this.grid;
  }
});
Detail.detailItemTdCls = detailItemTdCls;
Detail.detailArwCls = detailArwCls;
Detail.pluginId = pluginId.detail;
const getDefaultConfigs$6 = () => ({
  pluginId: pluginId.fixedColumn
});
const FixedColumnLogger = Logger("FixedColumn");
const FixedColumn = extend(Observable, {
  constructor: function(options) {
    this.options = {
      ...getDefaultConfigs$6(),
      ...options
    };
    this.listeners = this.options.listeners;
    FixedColumn.superclass.constructor.apply(this, arguments);
  },
  init: function(grid) {
    if (!grid) {
      FixedColumnLogger.error(`cant't find grid, FixedColumn do not work`);
      return;
    }
    this.grid = grid;
    this.bindEvents();
  },
  getId: function() {
    return this.options.pluginId;
  },
  bindEvents() {
    this.grid.on("viewready", this.initFixedEl.bind(this));
    this.grid.on("scroll-xscroll", this.onScrollX.bind(this));
    this.grid.on("after-render-scroll", this.afterRenderScroll.bind(this));
    this.grid.on("header-height-change", this.redrawPlaceholderEl.bind(this));
    this.grid.on("header-resize", this.redrawPlaceholderEl.bind(this));
  },
  initFixedEl() {
    this.clearPlaceholderEl();
    if (this.grid.scrollXEl.is(":hidden")) {
      return;
    }
    if (this.isAllFixed()) {
      return;
    }
    this.grid.gridEl.addClass(getPrefixedClassName("sfis-grid-fixed-column"));
    this.setFixedHeaderEl();
    this.setFixedColumnOffset();
    this.setFixedCellBorder();
  },
  afterRenderScroll({ showX }) {
    if (!showX) {
      this.grid.gridEl.removeClass(
        `${getPrefixedClassName("is-scroll-not-left")} ${getPrefixedClassName("is-scroll-not-right")}`
      );
    }
  },
  onScrollX: function() {
    this.setPlaceholder();
  },
  setFixedHeaderEl() {
    let hasLeftFixed = false;
    let hasRightFixed = false;
    this.grid.options.column.forEach((column) => {
      if (!column.fixed) {
        return;
      }
      if (!hasLeftFixed && column.fixed === "left") {
        hasLeftFixed = true;
      }
      if (!hasRightFixed && column.fixed === "right") {
        hasRightFixed = true;
      }
      const $el = this.grid.headerEl.find('[data-id="' + column.id + '"]');
      $el.addClass(
        `${getPrefixedClassName("is-fixed-column")} ${getPrefixedClassName(`is-fixed-column-${column.fixed}`)}`
      );
    });
    if (hasLeftFixed) {
      this.grid.gridEl.find(".sfis-grid-column-ceil-wrap-check,.sfis-grid-column-check").addClass(`${getPrefixedClassName("is-fixed-column")} ${getPrefixedClassName("is-fixed-column-left")}`);
    }
    if (hasRightFixed) {
      this.grid.gridEl.find(".sfis-grid-column-aside:visible").addClass(`${getPrefixedClassName("is-fixed-column")} ${getPrefixedClassName("is-fixed-column-right")}`);
    }
  },
  setFixedColumnOffset: function() {
    const leftTds = this.grid.headerEl.find(".is-fixed-column-left");
    const rightTds = this.grid.headerEl.find(".is-fixed-column-right");
    const shadowOffsetSets = /* @__PURE__ */ new Set();
    const leftWidths = /* @__PURE__ */ new Map();
    const rightWidths = /* @__PURE__ */ new Map();
    leftTds.each(function() {
      if ($(this).is(":visible")) {
        leftWidths.set(this, $(this).outerWidth());
      }
    });
    rightTds.each(function() {
      if ($(this).is(":visible")) {
        rightWidths.set(this, $(this).outerWidth());
      }
    });
    const leftOffsets = /* @__PURE__ */ new Map();
    let leftAccOffset = 0;
    let visibleLeftCount = 0;
    Array.from(leftTds).forEach((td) => {
      if (!$(td).is(":visible")) {
        return;
      }
      visibleLeftCount++;
      leftOffsets.set(td, leftAccOffset);
      leftAccOffset += leftWidths.get(td);
    });
    const rightOffsets = /* @__PURE__ */ new Map();
    let rightAccOffset = 0;
    let visibleRightCount = 0;
    Array.from(rightTds).reverse().forEach((td) => {
      if (!$(td).is(":visible")) {
        return;
      }
      visibleRightCount++;
      rightOffsets.set(td, rightAccOffset);
      rightAccOffset += rightWidths.get(td);
    });
    if (visibleLeftCount > 0) {
      shadowOffsetSets.add(-leftAccOffset);
    }
    if (visibleRightCount > 0) {
      shadowOffsetSets.add(rightAccOffset);
    }
    requestAnimationFrame(() => {
      if (!this.grid) {
        return;
      }
      leftOffsets.forEach((offset, td) => {
        const columnId = $(td).attr("data-id");
        const elements = this.grid.gridEl.find(`[data-column-id='${columnId}']`);
        $(td).css("left", `${offset}px`);
        elements.closest(".is-fixed-column").css("left", `${offset}px`);
      });
      rightOffsets.forEach((offset, td) => {
        const columnId = $(td).attr("data-id");
        const elements = this.grid.gridEl.find(`[data-column-id='${columnId}']`);
        $(td).css("right", `${offset}px`);
        elements.closest(".is-fixed-column").css("right", `${offset}px`);
      });
    });
    this.generatePlaceholder({ shadowOffsetSets });
  },
  generatePlaceholder: function({ shadowOffsetSets }) {
    const bodyHeight = Math.min(this.grid.viewEl.find("table").outerHeight() || 0, this.grid.viewEl.outerHeight() || 0);
    const headerHeight = this.getHeaderHeight();
    const gridEl = this.grid.gridEl;
    const placeholderTopPosition = this.getPlaceHolderTopPosition();
    shadowOffsetSets.forEach(function(offset) {
      const $el = $("<div>");
      $el.addClass(
        `${getPrefixedClassName("fixed-column-shadow-placeholder")} ${getPrefixedClassName(
          `fixed-column-shadow-placeholder-${offset > 0 ? "right" : "left"}`
        )}`
      );
      const styles = {
        height: `${headerHeight + bodyHeight}px`,
        top: `${placeholderTopPosition}px`
      };
      Object.assign(styles, offset > 0 ? { right: `${offset}px` } : { left: `${-offset}px` });
      $el.css(styles);
      $el.appendTo(gridEl);
    });
    this.setPlaceholder();
  },
  getHeaderHeight: function() {
    const headerHeight = this.grid.headerEl.outerHeight() - this.grid.tbarEl.outerHeight() - this.getBorderWidth(this.grid.headerColumnEl, "borderTopWidth");
    return headerHeight;
  },
  getPlaceHolderTopPosition: function() {
    const headerTbarHeight = this.grid.tbarEl.outerHeight() || 0;
    const headerColumnElBorderBottomWidth = this.getBorderWidth(this.grid.headerColumnEl, "borderBottomWidth");
    return headerTbarHeight + headerColumnElBorderBottomWidth;
  },
  getBorderWidth: function($element, borderType) {
    const val = $element.css(borderType);
    if (val) {
      return Number(val.replace("px", ""));
    }
    return 0;
  },
  clearPlaceholderEl: function() {
    this.grid.gridEl.find(".fixed-column-border-placeholder,.fixed-column-shadow-placeholder").remove();
  },
  redrawPlaceholderEl: function() {
    this.clearPlaceholderEl();
    this.setFixedColumnOffset();
  },
  setPlaceholder: function() {
    const scrollXEl = this.grid.scrollXEl.get(0);
    const scrollLeft = scrollXEl.scrollLeft;
    const showLeft = scrollLeft !== 0;
    const showRight = scrollXEl.scrollLeft + scrollXEl.clientWidth !== scrollXEl.scrollWidth;
    const gridEl = this.grid.gridEl;
    gridEl.find(".fixed-column-shadow-placeholder-left")[showLeft ? "show" : "hide"]();
    gridEl.find(".fixed-column-shadow-placeholder-right")[showRight ? "show" : "hide"]();
  },
  hiddenPlaceholder: function() {
    var _a, _b;
    const headerHeight = this.getHeaderHeight();
    const gridEl = this.grid.gridEl;
    (_a = gridEl.find(".fixed-column-shadow-placeholder-left")) == null ? void 0 : _a.css("height", `${headerHeight}px`);
    (_b = gridEl.find(".fixed-column-shadow-placeholder-right")) == null ? void 0 : _b.css("height", `${headerHeight}px`);
  },
  recoverTablePlaceholder: function() {
    var _a, _b;
    const gridEl = this.grid.gridEl;
    const bodyHeight = Math.min(this.grid.viewEl.find("table").outerHeight() || 0, this.grid.viewEl.outerHeight() || 0);
    const headerHeight = this.getHeaderHeight();
    const placeHolderHeight = bodyHeight + headerHeight;
    (_a = gridEl.find(".fixed-column-shadow-placeholder-left")) == null ? void 0 : _a.css("height", `${placeHolderHeight}px`);
    (_b = gridEl.find(".fixed-column-shadow-placeholder-right")) == null ? void 0 : _b.css("height", `${placeHolderHeight}px`);
  },
  setFixedCellBorder: function() {
    this.grid.gridEl.addClass(getPrefixedClassName("is-scroll-not-left"));
    this.grid.gridEl.addClass(getPrefixedClassName("is-scroll-not-right"));
  },
  isAllFixed() {
    const allColumns = this.grid.options.column || [];
    const allFixed = allColumns.every((column) => column.hidden || !!column.fixed);
    return allFixed;
  },
  destroy: function() {
    this.clear();
    delete this.grid;
  }
});
FixedColumn.pluginId = pluginId.fixedColumn;
const defaultGroupArwLoadingMainCls = "sfis-grid-group-arw-loading";
const defaultGroupArwLoadingIconCls = ["iconfont", "vtv-icon-comp-loading", "sf-icon-rotate"];
const defaultGroupArwLoadingCls = [defaultGroupArwLoadingMainCls, ...defaultGroupArwLoadingIconCls].join(" ");
const getDefaultConfigs$5 = () => ({
  pluginId: pluginId.group,
  autoExpand: true,
  groupArwCol: 0,
  sortable: true,
  autoExpandAll: false,
  isTreeGroup: false,
  childrenField: "children",
  needToggleIcon: false,
  groupArwLoadingCls: defaultGroupArwLoadingCls,
  stepLoad: false,
  shouldLoadNodeChildren: (record, isNodeLoaded) => !isNodeLoaded
});
const sortDirection = {
  ASC: "ASC",
  DESC: "DESC"
};
const getDefaultConfigs$4 = () => ({
  remoteSort: false,
  pluginId: pluginId.sortable,
  sortKey: "sort",
  directionKey: "direct",
  sortDirection: sortDirection.ASC,
  defaultDirection: sortDirection.ASC,
  candidateField: [],
  candidateDirection: []
});
function compare(data1, data2, sort, direct, sortFn, scope) {
  if (typeof sortFn === "function") {
    return sortFn.call(scope, data1, data2, direct);
  } else {
    if (direct === sortDirection.ASC) {
      return localeCompare(data1[sort], data2[sort]);
    } else {
      return localeCompare(data2[sort], data1[sort]);
    }
  }
}
const localSortFn$2 = function(data, fields, direct, sortFns, scope, candidateDirection) {
  let fieldIndex, diff;
  data.sort(function(data1, data2) {
    fieldIndex = diff = 0;
    while (fieldIndex < fields.length && diff === 0) {
      diff = compare(
        data1,
        data2,
        fields[fieldIndex],
        fieldIndex > 0 ? candidateDirection[fieldIndex - 1] || direct : direct,
        sortFns[fieldIndex],
        scope
      );
      fieldIndex++;
    }
    return diff;
  });
};
const getDefaultConfigs$3 = () => ({
  pluginId: pluginId.resizeable,
  reInitColumnWidthOnResize: true
});
const ResizeableLogger = Logger("Resizeable");
const resizeableCls = "sfis-grid-column-resizeable";
const resizeableHandleCfg = { elementName: "em", elementCls: "resizeable" };
const resizeableHandleSelector = `${resizeableHandleCfg.elementName}.${resizeableHandleCfg.elementCls}`;
const MIN_LAST_COLUMN_WIDTH = 96;
const MIN_DRAGGED_COLUMN_WIDTH = 40;
const Resizeable = oop.extend(Observable, {
  constructor: function(options) {
    this.options = {
      ...getDefaultConfigs$3(),
      ...options
    };
    this.listeners = this.options.listeners;
    this.tasks = [];
    Resizeable.superclass.constructor.apply(this, arguments);
  },
  init: function(grid) {
    if (!grid) {
      ResizeableLogger.error("cant't find grid, Resizeable do not work");
      return;
    }
    this.grid = grid;
    grid.on(gridEvent.onHeaderColumnCreated, this.injectResizeHandle, this);
    grid.on(gridEvent.afterRender, this._setupDragHandlers, this);
    grid.on(gridEvent.updateOption, this.onUpdateOption, this);
    grid.on(gridEvent.viewReady, this.onViewReady, this);
    grid.on(gridEvent.afterRenderHeaderColumn, this.onAfterRenderHeader, this);
    this.resizeEvent = "resize." + this.grid.getId();
    if (this.options.reInitColumnWidthOnResize) {
      this.grid.on(gridEvent.render, () => {
        $(window).on(this.resizeEvent, () => {
          if (this.grid.gridEl.is(":hidden")) {
            return;
          }
          this.reInitColumnWidth();
          this.grid.renderView();
        });
      });
    }
  },
  getId: function() {
    return this.options.pluginId;
  },
  injectResizeHandle: function({ el, column }) {
    if (column.resizeable !== false) {
      el.classList.add(...getPrefixedClassList(resizeableCls));
      const firstChild = el.firstChild;
      const resizeableHandleEl = document.createElement(resizeableHandleCfg.elementName);
      resizeableHandleEl.classList.add(...getPrefixedClassList(resizeableHandleCfg.elementCls));
      el.insertBefore(resizeableHandleEl, firstChild);
    }
  },
  _setupDragHandlers() {
    const getBoundaryLimits = ({ startPageX, headerPageX, isLeft, isRight, fixColumnOffsetWidth, curColumn }) => ({
      maxOffset: () => {
        if (isLeft) {
          return headerPageX - startPageX - fixColumnOffsetWidth - 40;
        }
        if (isRight) {
          return startPageX - fixColumnOffsetWidth - 80;
        }
        return headerPageX - startPageX - 20;
      },
      minWidth: this._getColumnMinWidth(curColumn)
    });
    const getValidOffset = (deltaX, initialWidth, limits) => {
      if (deltaX < 0) {
        return Math.max(deltaX, limits.minWidth - initialWidth);
      }
      return Math.min(deltaX, limits.maxOffset());
    };
    this._dragState = {};
    const $splitEl = this.createSplitLing();
    const handleDragStart = (e) => {
      const $curSplitTd = $(e.target).parent();
      const columnId = $curSplitTd.data("id");
      const curColumnIndex = this.grid.options.column.findIndex((c) => c.id === columnId);
      const curColumn = this.grid.options.column.find((c) => c.id === columnId);
      if (!curColumn) {
        return;
      }
      const { left: headerLeft } = this.grid.headerColumnEl.offset();
      const headerWidth = this.grid.headerColumnEl.width();
      Object.assign(this._dragState, {
        isDown: true,
        startPageX: e.originalEvent.pageX,
        initialSplitLineLeft: $curSplitTd.position().left + $curSplitTd.outerWidth(),
        initialColumnWidth: $curSplitTd.outerWidth(),
        headerPageX: headerLeft + headerWidth,
        $curSplitTd,
        curColumn,
        curColumnIndex
      });
      this._dragState.limits = getBoundaryLimits({
        isLeft: this.hasFixedPlugin && curColumn.fixed === "left",
        isRight: this.hasFixedPlugin && curColumn.fixed === "right",
        startPageX: this._dragState.startPageX,
        headerPageX: this._dragState.headerPageX,
        curColumn,
        fixColumnOffsetWidth: this.getFixColumnOffsetWidth($curSplitTd, curColumn).width
      });
      $splitEl.css("left", this._dragState.initialSplitLineLeft).show();
      this.grid.gridEl.addClass(getPrefixedClassName("split-now"));
    };
    this.mouseMoveFn = (e) => {
      const { isDown, startPageX, initialColumnWidth, initialSplitLineLeft, limits } = this._dragState;
      if (!isDown) {
        return;
      }
      const deltaX = e.originalEvent.pageX - startPageX;
      const validOffset = getValidOffset(deltaX, initialColumnWidth, limits);
      $splitEl.css("left", initialSplitLineLeft + validOffset);
      e.preventDefault();
    };
    this.mouseUpFn = (e) => {
      const { $curSplitTd, isDown, startPageX, initialColumnWidth, limits } = this._dragState;
      if (!isDown) {
        return;
      }
      const deltaX = e.originalEvent.pageX - startPageX;
      const validOffset = getValidOffset(deltaX, initialColumnWidth, limits);
      $splitEl.hide();
      this.grid.gridEl.removeClass(getPrefixedClassName("split-now"));
      e.preventDefault();
      if (deltaX > 0 && validOffset <= 0) {
        return;
      }
      this._handleColumnResize($curSplitTd, validOffset);
      this.grid.emit("header-resize");
      this.grid.renderView();
      this._dragState = {};
    };
    const selector = `.${resizeableCls} ${resizeableHandleSelector}`;
    this.grid.headerColumnEl.delegate(selector, "mousedown", handleDragStart);
    $(document.body).mousemove(this.mouseMoveFn);
    $(document.body).mouseup(this.mouseUpFn);
  },
  getFixColumnOffsetWidth($curSplitTd, curColumn) {
    const defaultReturnValue = { width: 0, minWidth: 0 };
    if (!this.hasFixedPlugin) {
      return defaultReturnValue;
    }
    const fixed = curColumn.fixed;
    if (!fixed) {
      return defaultReturnValue;
    }
    if (fixed === "left") {
      let leftWidth = 0;
      let rightWidth = 0;
      let minWidthSum = 0;
      $curSplitTd.nextAll().each((index, tdEl) => {
        const $tdEl = $(tdEl);
        const dataId = $tdEl.data("id");
        const curCol = this.grid.options.column.find((c) => c.id === dataId);
        if (curCol && curCol.fixed === "left") {
          const width = $tdEl.outerWidth() || 0;
          leftWidth += width;
          minWidthSum += this._getColumnMinWidth(curCol);
        }
        if (curCol && curCol.fixed === "right") {
          const width = $tdEl.outerWidth() || 0;
          rightWidth += width;
          minWidthSum += this._getColumnMinWidth(curCol);
        }
      });
      rightWidth += this.asideWidth;
      return {
        width: leftWidth + rightWidth,
        minWidth: minWidthSum
      };
    }
    if (fixed === "right") {
      let leftWidth = 0;
      let rightWidth = 0;
      let minWidthSum = 0;
      $curSplitTd.prevAll().each((index, tdEl) => {
        const $tdEl = $(tdEl);
        const dataId = $tdEl.data("id");
        const curCol = this.grid.options.column.find((c) => c.id === dataId);
        if (curCol && curCol.fixed === "left") {
          const width2 = $tdEl.outerWidth() || 0;
          leftWidth += width2;
          minWidthSum += this._getColumnMinWidth(curCol);
        }
        if (curCol && curCol.fixed === "right") {
          const width2 = $tdEl.outerWidth() || 0;
          rightWidth += width2;
          minWidthSum += this._getColumnMinWidth(curCol);
        }
      });
      const width = leftWidth + rightWidth + $curSplitTd.outerWidth();
      return {
        width,
        minWidth: minWidthSum
      };
    }
    return defaultReturnValue;
  },
  _handleColumnResize($currentColumnEl, resizeOffset) {
    const { curColumn, curColumnIndex } = this._dragState;
    const $adjacentColumnElement = this.findLastColumn(curColumnIndex);
    if (!$adjacentColumnElement) {
      return;
    }
    const containerWidth = this.grid.headerColumnEl.width();
    const headerTableWidth = this.grid.headerColumnEl.children("table").width();
    const contentOverflowWidth = headerTableWidth - containerWidth;
    const currentColumnWidth = parseInt($currentColumnEl.css("width"), 10) || 0;
    const newColumnWidth = this._clampWidth(currentColumnWidth + resizeOffset, curColumn);
    const widthDelta = newColumnWidth - currentColumnWidth;
    const adjacentColumnOptions = this.grid.getColumnByDom($adjacentColumnElement);
    const adjacentColumnWidth = parseInt($adjacentColumnElement.css("width"), 10) || 0;
    const adjacentColumnNewWidth = this._clampWidth(
      Math.max(adjacentColumnWidth - widthDelta - contentOverflowWidth, MIN_LAST_COLUMN_WIDTH),
      adjacentColumnOptions
    );
    this.changeColumnWidth($adjacentColumnElement, adjacentColumnNewWidth, adjacentColumnOptions);
    curColumn.draggedWidth = newColumnWidth + "px";
    this.changeColumnWidth($currentColumnEl, newColumnWidth, curColumn);
  },
  _clampWidth(width, options) {
    const minWidth = this._getColumnMinWidth(options);
    return Math.max(width, minWidth);
  },
  _getColumnMinWidth(columnCfg) {
    const minWidth = parseInt(columnCfg.minWidth, 10) || MIN_DRAGGED_COLUMN_WIDTH;
    return minWidth;
  },
  changeColumnWidth: function($column, width, options) {
    $column.css("width", width);
    options.width = width + "px";
    const columnID = $column.data("id");
    this.updateColWidth(columnID, width + "px");
  },
  updateColWidth: function(columnID, width) {
    const grid = this.grid;
    grid.headerColumnEl.find(`#${columnID + grid.GRID_HEADER_COL_ELEMENT_COMMON_SUFFIX}`).css("width", width);
    grid.viewEl.find(`#${columnID + grid.GRID_BODY_COL_ELEMENT_COMMON_SUFFIX}`).css("width", width);
  },
  getUuidByColumnId: function(columnId) {
    const matchRes = columnId.match(/sfis-grid-column-(\d+)/);
    return +matchRes[1];
  },
  findLastColumn: function(curColumnIndex) {
    const grid = this.grid;
    const columnList = this.grid.options.column;
    let $column = null;
    for (let index = columnList.length - 1; index > curColumnIndex; index--) {
      const columnCfg = columnList[index];
      if (columnCfg.hidden === true) {
        continue;
      }
      $column = grid.headerColumnEl.find(`td[data-id=${columnCfg.id}]`);
      if (!columnCfg.isAction) {
        break;
      }
    }
    return $column;
  },
  disableResizeableColumn: function() {
    const grid = this.grid;
    const columnList = this.grid.options.column;
    for (let index = columnList.length - 1; index >= 0; index--) {
      const columnCfg = columnList[index];
      if (columnCfg.isAction) {
        const $column = grid.headerColumnEl.find(`td[data-id=${columnCfg.id}]`);
        $column.addClass(getPrefixedClassName("sfis-grid-column-resizeable-hidden"));
        continue;
      }
      if (!columnCfg.hidden && index !== 0) {
        const $column = grid.headerColumnEl.find(`td[data-id=${columnCfg.id}]`);
        $column.addClass(getPrefixedClassName("sfis-grid-column-resizeable-hidden"));
        break;
      }
    }
  },
  onAfterRenderHeader: function() {
    this.disableResizeableColumn();
    const fixedPlugin = this.grid.getPlugin(pluginId.fixedColumn);
    this.hasFixedPlugin = !!(fixedPlugin && !fixedPlugin.isAllFixed());
  },
  onViewReady: function(params) {
    const { yHideToShow, yShowToHide } = params.scrollElVisibility;
    if (this.hasResetColumn && !yHideToShow && !yShowToHide || this.grid.headerEl.is(":hidden")) {
      return;
    }
    this.resetColumnWidth();
    this.hasResetColumn = true;
  },
  onUpdateOption: function() {
    this.grid.headerEl.find(".sfis-grid-column-resizeable").each((idx, dom) => {
      const column = this.grid.getColumnByDom(dom);
      const width = column.oriWidth || "auto";
      $(dom).css("width", width);
      this.updateColWidth(column.id, width);
    });
    const taskId = setTimeout(() => {
      this.resetColumnWidth();
      this.grid.renderView();
    }, 10);
    this.tasks.push(taskId);
  },
  resetColumnWidth: function() {
    const grid = this.grid;
    const columnsOpt = grid.options.column;
    const gridHeader = grid.headerColumnEl;
    const gridHeaderWidthNum = parseInt(gridHeader.css("width"), 10);
    const columnsOptMap = {};
    columnsOpt.forEach((column) => {
      columnsOptMap[column.id] = column;
    });
    const asideWidth = grid._asideWidth || grid.options.scrollWidth;
    this.asideWidth = asideWidth;
    const noWidthCols = [];
    const normalCols = [];
    let overWidth = asideWidth;
    grid.headerColumnEl.find(".sfis-grid-column-resizeable").each(function(idx, dom) {
      const columnID = $(dom).data("id");
      const curColConfig = columnsOptMap[columnID];
      if (curColConfig.hidden || curColConfig.isAutoFitWidth) {
        return;
      }
      normalCols.push(curColConfig);
      const domWidth = $(dom).css("width");
      const domWidthNum = parseInt(domWidth, 10);
      const domMinWidthNum = parseInt(curColConfig.minWidth, 10);
      const ltMinWidth = domWidthNum < domMinWidthNum;
      if (ltMinWidth) {
        curColConfig.width = domMinWidthNum + "px";
        overWidth += domMinWidthNum - domWidthNum;
      } else {
        curColConfig.width = domWidth;
        if ((!curColConfig.oriWidth || curColConfig.oriWidth === "auto") && !curColConfig.draggedWidth) {
          noWidthCols.push(curColConfig);
        }
      }
    });
    if (noWidthCols.length) {
      let modNum = overWidth % noWidthCols.length;
      const ol = (overWidth - modNum) / noWidthCols.length;
      noWidthCols.forEach((noWidthColOpt) => {
        let factor = ol;
        if (modNum) {
          factor += 1;
          modNum--;
        }
        const width = Math.max(parseInt(noWidthColOpt.minWidth, 10) || 0, parseInt(noWidthColOpt.width, 10) - factor);
        noWidthColOpt.width = width + "px";
      });
    } else if (grid.scrollXEl.is(":hidden")) {
      this._allocateRemainingWidth(-asideWidth, normalCols);
    }
    let widthDiff = gridHeaderWidthNum;
    let hasAutoWidth = false;
    grid.options.column.forEach((column) => {
      if (column.hidden) {
        return;
      }
      if (typeof column.width === "undefined" || column.width === "auto") {
        hasAutoWidth = true;
        return;
      }
      widthDiff -= parseInt(column.width, 10);
    });
    if (!hasAutoWidth) {
      const pluginCustomColumn = grid.getPlugin(pluginId.customColumn);
      if (!grid.scrollYEl.is(":hidden") || pluginCustomColumn) {
        widthDiff -= asideWidth;
      }
      const pluginGroup = grid.getPlugin(pluginId.group);
      const pluginDetail = grid.getPlugin(pluginId.detail);
      const pluginCheckSelection = grid.getPlugin(pluginId.checkSelection) || grid.getPlugin(pluginId.radioSelection) || grid.getPlugin(pluginId.radioGroupSelection);
      if (pluginDetail) {
        widthDiff -= parseInt(pluginDetail.options.width, 10);
      }
      if (pluginCheckSelection) {
        widthDiff -= parseInt(pluginCheckSelection.options.width, 10);
      }
      if (pluginGroup) {
        widthDiff -= pluginGroup.groupArwWidth || 0;
      }
      if (widthDiff > 0) {
        const allocationCols = noWidthCols.length ? noWidthCols : normalCols;
        this._allocateRemainingWidth(widthDiff, allocationCols);
      }
    }
    grid.headerColumnEl.find(".sfis-grid-column-resizeable").each((idx, dom) => {
      const columnID = $(dom).data("id");
      const column = columnsOptMap[columnID];
      $(dom).css("width", column.width);
      $(dom).css("minWidth", column.minWidth || "auto");
      this.updateColWidth(columnID, column.width);
    });
  },
  _allocateRemainingWidth: function(remainingWidth, columns) {
    let modNum = remainingWidth % columns.length;
    const averageWidth = (remainingWidth - modNum) / columns.length;
    columns.forEach((column) => {
      let factor = averageWidth;
      if (modNum) {
        factor += 1;
        modNum--;
      }
      const width = (parseInt(column.width, 10) || 0) + factor;
      column.width = width + "px";
    });
  },
  reInitColumnWidth: function() {
    const grid = this.grid;
    grid.headerColumnEl.find(".sfis-grid-column-resizeable").each((idx, dom) => {
      const columnConfig = grid.getColumnByDom(dom);
      if (columnConfig.hidden) {
        return;
      }
      const widthToUse = columnConfig.draggedWidth || columnConfig.oriWidth;
      $(dom).css("width", widthToUse || "");
      grid.headerColumnEl.find(`#${columnConfig.id + grid.GRID_HEADER_COL_ELEMENT_COMMON_SUFFIX}`).css("width", widthToUse || "auto");
      columnConfig.width = widthToUse || "auto";
    });
    this.resetColumnWidth();
  },
  createSplitLing: function() {
    if (!this.splitEl) {
      this.splitEl = $(
        `<div id="${this.grid.getId()}-split-line" class="${getPrefixedClassName(
          "sfis-grid-split-line"
        )}" style="display:none;">`
      );
      this.splitEl.appendTo(this.grid.bodyEl);
    }
    this.splitEl.css("top", this.grid.headerColumnEl.height() * -1);
    return this.splitEl;
  },
  destroy: function() {
    if (this.mouseMoveFn) {
      $(document.body).unbind("mousemove", this.mouseMoveFn);
    }
    if (this.mouseUpFn) {
      $(document.body).unbind("mouseup", this.mouseUpFn);
    }
    if (this.splitEl) {
      this.splitEl.remove();
      delete this.splitEl;
    }
    this.tasks.forEach((taskId) => {
      clearTimeout(taskId);
    });
    this.tasks = null;
    $(window).off(this.resizeEvent);
    this.clear();
    delete this.grid;
    this.mouseUpFn = null;
    this.mouseMoveFn = null;
  }
});
Resizeable.pluginId = pluginId.resizeable;
const SortableLogger = Logger("Sortable");
const ASC_CLS = "sfis-grid-column-sort-asc";
const DESC_CLS = "sfis-grid-column-sort-desc";
const Sortable = oop.extend(Observable, {
  constructor: function(options) {
    this.options = {
      ...getDefaultConfigs$4(),
      ...options
    };
    this.listeners = this.options.listeners;
    this.options.candidateField = $.makeArray(this.options.candidateField);
    this.addEvents(sortableEvent.beforeSort, sortableEvent.afterSort);
    this.options.candidateDirection = $.makeArray(this.options.candidateDirection);
    Sortable.superclass.constructor.apply(this, arguments);
  },
  init: function(grid) {
    if (!grid) {
      SortableLogger.error("cant't find grid, Sortable do not work");
      return;
    }
    this.grid = grid;
    grid.on(gridEvent.afterRender, this.onAfterRender, this);
    grid.on(gridEvent.updateOption, this.onUpdateOptions, this);
    grid.on(gridEvent.afterRenderHeaderColumn, this.onAfterRenderHeaderColumn, this);
    this.bindGridStoreEvent();
  },
  getId: function() {
    return this.options.pluginId;
  },
  bindGridStoreEvent: function() {
    const me = this;
    if (this.options.remoteSort) {
      this.grid.store.on(storeEvent.beforeLoad, function(store, option) {
        if (me.options.sortField) {
          let fields = [me.options.sortField], directions = [me.options.sortDirection || sortDirection.ASC], candidateField = [], candidateDirection = [];
          if (me.options.candidateField.length) {
            candidateDirection = $.extend([], me.options.candidateDirection);
            candidateField = me.options.candidateField.filter(function(item, index) {
              if (!candidateDirection[index]) {
                candidateDirection.push(sortDirection.ASC);
              }
              if (item === me.options.sortField) {
                candidateDirection.splice(index, 1);
                return false;
              }
              return true;
            });
            fields = fields.concat(candidateField);
            directions = directions.concat(candidateDirection);
          }
          option.data = option.data || {};
          option.data[me.options.sortKey] = fields.join(",");
          option.data[me.options.directionKey] = directions.join(",");
        }
      });
    } else {
      this.grid.store.on(storeEvent.beforeInitData, function(store, data) {
        let sortFields, sortFns;
        if (!me.preventLoad) {
          if (me.options.sortDirection && me.options.sortField) {
            me.emit(sortableEvent.beforeSort, me, data);
            sortFields = [me.options.sortField].concat(me.options.candidateField);
            sortFns = me.getSortFnsByFields(sortFields);
            localSortFn$2(data, sortFields, me.options.sortDirection, sortFns, me.grid, me.options.candidateDirection);
            me.emit(sortableEvent.afterSort, me, data, {
              dataIndex: me.options.sortField,
              direction: me.options.sortDirection
            });
          }
        }
      });
    }
  },
  onAfterRender: function() {
    const me = this, resizeAble = this.grid.getPlugin(Resizeable);
    let $mouseDownTarget;
    this.grid.headerColumnEl.delegate(".sfis-grid-column-sortable", "mousedown", function(e) {
      $mouseDownTarget = $(e.target);
    });
    this.grid.headerColumnEl.delegate(".sfis-grid-column-sortable", "click", function(e) {
      let direction;
      if (resizeAble && ($(e.target).is(resizeableHandleSelector) || $mouseDownTarget.is(resizeableHandleSelector))) {
        return;
      }
      const id = $(this).data("id");
      const column = me.getColumnDataById(id);
      direction = $(this).attr("data-direction");
      if (direction === sortDirection.DESC) {
        direction = sortDirection.ASC;
      } else if (direction === sortDirection.ASC) {
        direction = sortDirection.DESC;
      } else {
        direction = me.options.defaultDirection;
      }
      me.sort(column.dataIndex, direction, column.sortFn);
    });
    this.onUpdateOptions();
  },
  onUpdateOptions: function() {
    const ids = [];
    this.grid.options.column.forEach(function(column) {
      if (column.sortable) {
        ids.push('.sfis-grid-column-header td[data-id="' + column.id + '"]');
      }
    });
    if (ids.length) {
      this.grid.gridEl.find(ids.join(",")).addClass(getPrefixedClassName("sfis-grid-column-sortable"));
    }
    this.updateHeaderSortState();
  },
  onAfterRenderHeaderColumn: function() {
    const ids = [];
    this.grid.options.column.forEach(function(column) {
      if (column.sortable) {
        ids.push('.sfis-grid-column-header td[data-id="' + column.id + '"]');
      }
    });
    if (ids.length) {
      const $columnEls = this.grid.gridEl.find(ids.join(","));
      $columnEls.each(function(idx, el) {
        $(el).append($("<span>").addClass(getPrefixedClassName("sfis-grid-column-sortable-caret")));
      });
    }
  },
  sort: function(dataIndex, direction, sortFn) {
    const me = this;
    let column;
    direction = direction || sortDirection.ASC;
    me.options.sortDirection = direction;
    me.options.sortField = dataIndex;
    if (me.grid.rendered) {
      this.updateHeaderSortState();
      column = me.getColumnDataByDataIndex(dataIndex);
      if (!column) {
        this.doSort(dataIndex, direction, sortFn);
        return;
      }
    }
    this.doSort(dataIndex, direction, sortFn);
  },
  updateHeaderSortState: function() {
    const me = this, column = me.getColumnDataByDataIndex(me.options.sortField);
    me.grid.gridEl.find(".sfis-grid-column-sortable").removeClass(getPrefixedClassName(ASC_CLS) + " " + getPrefixedClassName(DESC_CLS));
    if (!column) {
      return;
    }
    const columnDom = me.grid.headerColumnEl.find('td[data-id="' + column.id + '"]');
    if (me.options.sortDirection === sortDirection.ASC) {
      $(columnDom).addClass(getPrefixedClassName(ASC_CLS));
    } else {
      $(columnDom).addClass(getPrefixedClassName(DESC_CLS));
    }
    $(columnDom).attr("data-direction", me.options.sortDirection);
  },
  doSort: function(dataIndex, direction, sortFn) {
    const me = this;
    if (me.options.remoteSort) {
      me.doRemoteSort(dataIndex, direction);
    } else {
      me.doLocalSort(dataIndex, direction, sortFn);
    }
  },
  doRemoteSort: function(dataIndex, direction) {
    const me = this, lastParams = me.grid.store.lastOption && me.grid.store.lastOption.data || {}, d = {};
    d[me.options.sortKey] = dataIndex;
    d[me.options.directionKey] = direction;
    me.grid.store.reload({
      data: apply(lastParams, d)
    });
  },
  doLocalSort: function(dataIndex, direction) {
    const me = this;
    const d = [];
    me.grid.store.dataList.forEach(function(key) {
      const r = me.grid.store.dataHash[key];
      if (r.get("__type") === "group") {
        return;
      }
      delete r.data.__parent;
      d.push(r.data);
    });
    me.emit(sortableEvent.beforeSort, me, d);
    const sortFields = [dataIndex].concat(me.options.candidateField);
    const sortFns = me.getSortFnsByFields(sortFields);
    localSortFn$2(d, sortFields, direction, sortFns, me.grid, me.options.candidateDirection);
    me.emit(sortableEvent.afterSort, me, d, {
      dataIndex,
      direction
    });
    me.preventLoad = true;
    me.grid.store.loadData(d);
    me.preventLoad = false;
  },
  getColumnDataById: function(id) {
    let ret;
    this.grid.options.column.forEach(function(column) {
      if (column.id === id) {
        ret = column;
      }
    });
    return ret;
  },
  getSortFnsByFields: function(fields) {
    const fieldMap = {}, ret = [];
    fields.forEach(function(field, index) {
      fieldMap[field] = index;
    });
    this.grid.options.column.forEach(function(column) {
      const index = fieldMap[column.dataIndex];
      if (typeof index !== "undefined") {
        ret[index] = column.sortFn;
      }
    });
    return ret;
  },
  getColumnDataByDataIndex: function(dataIndex) {
    let ret;
    if (dataIndex) {
      this.grid.options.column.forEach(function(column) {
        if (column.dataIndex === dataIndex) {
          ret = column;
        }
      });
    }
    return ret;
  },
  getLastSortCfg: function() {
    const opt = this.options;
    const config = {
      sortField: opt.sortField,
      sortDirection: opt.sortDirection
    };
    return opt.sortField ? config : null;
  },
  clearSortCfg: function() {
    if (this.options.remoteSort) {
      const lastParams = this.grid.store.lastOption && this.grid.store.lastOption.data || {};
      if (lastParams.hasOwnProperty(this.options.sortKey)) {
        delete lastParams[this.options.sortKey];
      }
      if (lastParams.hasOwnProperty(this.options.directionKey)) {
        delete lastParams[this.options.directionKey];
      }
    }
    this.options.sortField = null;
    this.updateHeaderSortState();
  },
  destroy: function() {
    this.clear();
    delete this.grid;
  }
});
Sortable.pluginId = pluginId.sortable;
const localSortFn$1 = function(list, direct, sortFn, group) {
  list.sort(function(data1, data2) {
    if (typeof sortFn === "function") {
      return sortFn(data1, data2, direct, group);
    } else {
      if (direct === sortDirection.ASC) {
        return localeCompare(data1, data2);
      } else {
        return localeCompare(data2, data1);
      }
    }
  });
};
const getDefaultConfigs$2 = () => ({
  pluginId: pluginId.radioSelection,
  hideRadio: false,
  silentSelect: false,
  showRenderer: false,
  beforeSelect: () => true
});
const RadioSelection = oop.extend(CheckSelection, {
  constructor: function(_options) {
    const options = {
      ...getDefaultConfigs$2(),
      ..._options
    };
    options.mode = options.mode || mode.single;
    RadioSelection.superclass.constructor.apply(this, [options]);
  },
  init: function() {
    RadioSelection.superclass.init.apply(this, arguments);
    this.grid.on(
      gridEvent.afterRender,
      function() {
        let cls = getPrefixedClassName("sfis-grid-radio");
        if (this.options.hideRadio) {
          cls += ` ${getPrefixedClassName("sfis-grid-radio-hidden")}`;
        }
        if (this.options.showRenderer) {
          cls += ` ${getPrefixedClassName("sfis-grid-radio-show-renderer")} `;
        }
        this.grid.gridEl.addClass(cls);
      },
      this
    );
    this.grid.on(gridEvent.viewReady, () => {
      if (this.options.hideRadio) {
        this.hideCol();
      }
    });
  },
  doRowClick: function(dom, record) {
    const _this = this;
    const selections = _this.getSelections(true);
    if (selections.indexOf(record) === -1 && record.selectAble !== false) {
      if (_this.emit(radioSelectionEvent.beforeSelect, record, selections) === false) {
        return;
      }
      when(_this.options.beforeSelect(record.data)).then(function(result) {
        if (result === false) {
          return;
        }
        _this.unSelect(selections);
        _this.select(record);
      });
    }
  },
  hideCol() {
    const grid = this.grid;
    const headerColId = `#sfis-grid-column-check${grid.GRID_HEADER_COL_ELEMENT_COMMON_SUFFIX}`;
    const bodyColId = `#sfis-grid-column-check${grid.GRID_BODY_COL_ELEMENT_COMMON_SUFFIX}`;
    grid.headerColumnEl.find(headerColId).hide();
    grid.viewEl.find(bodyColId).hide();
  }
});
RadioSelection.pluginId = pluginId.radioSelection;
const GridGroupLogger = Logger("GridGroup");
const ItemCls = "sfis-grid-body-group-item";
const ItemDisabledCls = "sfis-grid-body-group-item-disabled";
const ItemSelectedCls = "sfis-grid-body-group-item-selected";
const ItemPartSelectedCls = "sfis-grid-body-group-item-part-selected";
const columnCheckCls$2 = "sfis-grid-column-ceil-check";
const columnCheckWrapCls$2 = "sfis-grid-column-ceil-wrap-check";
const groupCls = "sfis-grid-group-column";
const groupArwCls = "sfis-grid-group-arw";
const groupArwExpandCls = "sfis-grid-group-arw-expand";
const storeEventGroupOnly = "__beforeloaddata__";
const groupArwWidth = 40;
const groupArwTdStyle = `width:${groupArwWidth}px;`;
const Group = oop.extend(Observable, {
  constructor: function(options) {
    this.options = {
      ...getDefaultConfigs$5(),
      ...options
    };
    this.options.expandedList = this.options.expandedList || [];
    this.listeners = this.options.listeners;
    this.toggleClass = null;
    const { collapse, expand, expandAll, collapseAll, change } = groupEvent;
    this.addEvents(collapse, expand, expandAll, collapseAll, change);
    this.groupColumnId = uuid("sfis-grid-column-group-");
    if (this.options.isTreeGroup && this.options.groupField) {
      this.__cacheGroupField = this.options.groupField;
      this.options.groupField = "__tree_group_" + this.options.groupField;
    }
    this.groupArwWidth = groupArwWidth;
    this.loadingMap = /* @__PURE__ */ new Map();
    this.stepLoadedNode = /* @__PURE__ */ new Set();
    this.isHideGroupCol = false;
    Group.superclass.constructor.apply(this, arguments);
  },
  init: function(grid) {
    const me = this;
    if (!grid) {
      GridGroupLogger.error("can't find grid, Group do not work");
      return;
    }
    this.grid = grid;
    this.grid.on(gridEvent.onGenerateHeaderRow, (moreTdElements, rowInfo) => {
      const { rowIndex, headerRowNum } = rowInfo;
      if (me.isHideGroupCol) {
        return;
      }
      if (rowIndex === 0) {
        const rowspan = headerRowNum - rowIndex;
        const groupFragment = `<td data-id="${me.groupColumnId}" class="${getPrefixedClassName(
          "sfis-grid-functional-column"
        )}" style="${groupArwTdStyle}" rowspan="${rowspan}"></td>`;
        moreTdElements.push({
          order: functionalColumnOrder[pluginId.group],
          html: groupFragment
        });
      }
    });
    this.grid.on(gridEvent.onGridColFragmentCreated, (colFragment, suffix) => {
      if (me.isHideGroupCol) {
        return;
      }
      const fragment = document.createDocumentFragment();
      const groupColEl = document.createElement("col");
      groupColEl.id = "sfis-grid-column-group" + suffix;
      fragment.append(groupColEl);
      colFragment.push({
        order: functionalColumnOrder[pluginId.group],
        element: fragment
      });
    });
    this.grid.on(gridEvent.beforeCreateViewTr, (elConfig, rowInfo) => {
      const { record } = rowInfo;
      if (record.get("__type") === "group") {
        me.setGroupRowTr(elConfig, rowInfo);
      }
      if (!record.get("__parent")) {
        elConfig.classList.push(getPrefixedClassName("sfis-grid-row-no-parent"));
      }
    });
    this.grid.on(gridEvent.onGenerateViewTd, (moreTdElements, rowInfo) => {
      const { record } = rowInfo;
      if (record.get("__type") === "group") {
        me.addGroupArw(moreTdElements, rowInfo);
        me.addGroupCheck(moreTdElements, rowInfo);
      } else {
        me.addGroupArwPlaceholder(moreTdElements);
      }
    });
    this.grid.getStoreCount = function() {
      let count = this.store.getCount(), record;
      const dataHash = this.store.dataHash;
      for (const key in dataHash) {
        if (dataHash.hasOwnProperty(key)) {
          record = dataHash[key];
          if (record.get("__type") === "group" && record.get("__expanded") === false) {
            const visibleChildren = me.getVisibleData(record.get("__children"), true);
            count -= visibleChildren.length;
          }
        }
      }
      return count;
    };
    this.grid.refresh = function() {
      me.refresh();
    };
    this.grid.store.getRange = function(start, limit) {
      let i, key, record, realStart = 0, visibleChildren = [];
      const ret = [];
      if (!this.dataList || !this.dataList.length) {
        return ret;
      }
      const visibleDataList = me.getVisibleData(this.dataList);
      const visibleDataLength = visibleDataList.length;
      for (i = 0; i < start; i++) {
        key = visibleDataList[realStart];
        if (key === "" || key === void 0 || key === null) {
          break;
        }
        record = this.dataHash[key];
        if (record.get("__type") === "group" && record.get("__expanded") === false) {
          visibleChildren = me.getVisibleData(record.get("__children"), true);
          realStart += visibleChildren.length;
        }
        realStart++;
      }
      for (i = realStart; i < visibleDataLength; i++) {
        key = visibleDataList[i];
        if (key === "" || key === void 0 || key === null) {
          return;
        }
        record = this.dataHash[key];
        ret.push(record);
        if (record.get("__type") === "group" && record.get("__expanded") === false) {
          visibleChildren = me.getVisibleData(record.get("__children"), true);
          i += visibleChildren.length;
        }
        if (ret.length === limit) {
          break;
        }
      }
      return ret;
    };
    this.grid.store.initDataHash = function(data) {
      const me2 = this, records = [];
      if (me2.emit(storeEvent.beforeInitData, me2, data) === false) {
        return;
      }
      me2.emit(storeEventGroupOnly, me2, data);
      if (me2.emit(storeEvent.afterLoadData, me2, data) === false) {
        return;
      }
      me2.dataHash = {};
      me2.snapshot = {};
      me2.dataList = [];
      data.forEach(function(item) {
        const key = item[me2.options.idProperty];
        if (key === null || key === void 0) {
          GridGroupLogger.error("record has not %s field", me2.options.idProperty);
          return false;
        }
        const d = me2.dataHash[key];
        if (d) {
          GridGroupLogger.error("record's id: %s is conflict", key);
          return false;
        }
        const model = new Model({
          data: item
        });
        model.on(modelEvent.selectedStatusChange, me2.modelSelectedController, me2);
        if (me2.selectedIDs.has(key)) {
          model.selected = true;
        }
        me2.dataHash[key] = model;
        me2.snapshot[key] = model;
        me2.dataList.push(key.toString());
      });
      if (!me2.shouldKeepLostSelectedData()) {
        me2.cleanSelectedData();
      }
      me2.emit(storeEvent.initData, me2, data);
      if (this.events) {
        me2.dataList.forEach(function(key) {
          records.push(me2.dataHash[key]);
        });
        if (this.emit(storeEvent.beforeDataChange, me2, records) !== false) {
          this.lastMsg = "";
          this.emit(storeEvent.dataChange, me2, records);
        }
      }
    };
    this.bindGridStoreEvent();
    this.bindGridEvent();
    this.bindSelectionEvent();
  },
  getGroupText: function(record) {
    if (record instanceof Model) {
      return record.get("__fieldTitle");
    } else if ($.isPlainObject(record)) {
      return record.__fieldTitle;
    }
  },
  __getTreeGroupData: function(data) {
    const me = this;
    const groupField = this.options.groupField;
    const childrenField = this.options.childrenField;
    const sort = this.grid.getPlugin(Sortable);
    const keyList = data.map(function(item) {
      return item[me.__cacheGroupField];
    });
    this.groupRecord = keyList.slice(0);
    if (this.options.sortable && (sort && sort.options.sortField || this.options.sortFn)) {
      localSortFn$1(keyList, sort && sort.options.sortDirection || sortDirection.ASC, this.options.sortFn, this);
    }
    return data.reduce(function(total, curr) {
      const children = curr[childrenField];
      const groupVal = curr[me.__cacheGroupField];
      let currGroupData = [];
      const result = [];
      if (groupVal) {
        curr[groupField] = groupVal;
        currGroupData = me.getGroupInitData(groupVal, children, curr);
        currGroupData = Object.assign({}, curr, currGroupData);
        currGroupData.__isTreeGroup = true;
        delete currGroupData[childrenField];
        result.push(currGroupData);
      }
      if (Array.isArray(children)) {
        children.forEach(function(child) {
          child[groupField] = groupVal;
          child.__parent = currGroupData;
        });
        Array.prototype.push.apply(result, children);
      }
      return total.concat(result);
    }, []);
  },
  bindGridStoreEvent: function() {
    const own = this;
    let hasSetExpand = false;
    this.grid.store.on(
      storeEventGroupOnly,
      function(store, data) {
        const me = this, obj = {}, keyList = [], groupField = own.options.groupField, groupOnlyField = own.options.groupOnlyField, sort = own.grid.getPlugin(Sortable);
        if (!groupField) {
          return;
        }
        if (own.options.isTreeGroup) {
          const dataList = own.__getTreeGroupData(data);
          data.length = 0;
          Array.prototype.push.apply(data, dataList);
          store.setInnerLimit(data.length);
          return;
        }
        data.forEach(function(item) {
          const groupKey = item[groupField];
          const isGroupOnly = !!item[groupOnlyField];
          if (obj[groupKey] !== void 0 && obj.hasOwnProperty(groupKey)) {
            obj[groupKey].push(item);
          } else {
            obj[groupKey] = isGroupOnly ? [] : [item];
            keyList.push(groupKey);
          }
        });
        if (own.options.sortable && (sort && sort.options.sortField || own.options.sortFn)) {
          localSortFn$1(keyList, sort && sort.options.sortDirection || sortDirection.ASC, own.options.sortFn, own);
        }
        data.length = 0;
        own.groupRecord = keyList.slice();
        keyList.forEach(function(key) {
          if (key && !own.isUndefined(key)) {
            data.push(me.getGroupInitData(key, obj[key]));
          }
          Array.prototype.push.apply(data, obj[key]);
        });
        own.updateIsHideGroupCol(data);
        store.setInnerLimit(data.length);
      },
      this
    );
    own.grid.store.on(storeEvent.dataChange, function() {
      if (own.options.autoExpandAll && !hasSetExpand) {
        hasSetExpand = true;
        own.expandAll();
      }
    });
    this.grid.store.init();
  },
  bindGridEvent: function() {
    this.grid.on(
      gridEvent.afterRender,
      function() {
        this.grid.gridEl.addClass(getPrefixedClassName("sfis-grid-group")).addClass(getPrefixedClassName("sfis-grid--no-column-border"));
        if (this.options.needToggleIcon) {
          const { toggleClass } = insertToggleToHeader.call(this, {
            colID: this.groupColumnId,
            collapseFn: this.collapseAll.bind(this),
            expandFn: this.expandAll.bind(this),
            autoExpandAll: this.options.autoExpandAll
          });
          this.toggleClass = toggleClass;
        }
        const me = this;
        this.grid.gridEl.delegate("." + groupArwCls, "click", function() {
          const recordId = Format.htmlDecode(
            $(this).parents("." + ItemCls).data("id")
          );
          let record, expanded, index;
          if (recordId) {
            record = me.grid.store.get(recordId);
            if (record) {
              expanded = !record.get("__expanded");
              const fieldTitle = record.get("__fieldTitle");
              if (expanded && me.options.stepLoad) {
                const isNodeLoaded = me.nodeHaveLoaded(fieldTitle);
                if (me.options.shouldLoadNodeChildren(record, isNodeLoaded)) {
                  me.updateLoadingMap(fieldTitle, true);
                } else {
                  record.set("__expanded", expanded);
                  me.syncGroupToggleIcon();
                  if (!me.options.expandedList.includes(fieldTitle)) {
                    me.options.expandedList.push(fieldTitle);
                  }
                }
                me.emit(groupEvent.expand, record);
                me.emit(groupEvent.change, record, expanded);
                me.grid.renderView(null, null, true);
                return;
              }
              record.set("__expanded", expanded);
              me.syncGroupToggleIcon();
              if (expanded) {
                me.options.expandedList.push(record.get("__fieldTitle"));
                me.emit(groupEvent.expand, record);
              } else {
                index = me.options.expandedList.indexOf(record.get("__fieldTitle"));
                if (index !== -1) {
                  me.options.expandedList.splice(index, 1);
                }
                me.emit(groupEvent.collapse, record);
              }
              me.emit(groupEvent.change, record, expanded);
              me.grid.renderView(null, null, true);
            }
          }
        });
        this.grid.gridEl.delegate("." + ItemCls + " ." + columnCheckWrapCls$2, "click", function() {
          if (!me.options.groupField) {
            return;
          }
          if (me.grid.getPlugin(RadioSelection) && !me.options.isTreeGroup) {
            return;
          }
          const key = Format.htmlDecode(
            $(this).parents("." + ItemCls).data("id")
          );
          const record = me.grid.store.get(key);
          const idProperty = me.grid.store.options.idProperty;
          if (!record) {
            GridGroupLogger.error("record is missing");
            return;
          }
          if (me.options.isTreeGroup && record.selectAble === false) {
            return;
          }
          const cs = me.grid.getPlugin(CheckSelection);
          const { select, unselect, change } = checkSelectionEvent;
          if (cs.options.pluginID === pluginId.radioGroupSelection) {
            cs.unSelectAll();
          }
          record.selected = !record.selected;
          const children = me.getVisibleData(record.get("__children"), true);
          if (cs) {
            if ($.isArray(children) && children.length) {
              children.forEach(function(child) {
                const r = me.grid.store.dataHash[child[idProperty]];
                if (!me.checkRecordSelectable(r) || r.selected === record.selected || !r.selected && !record.selected) {
                  return;
                }
                r.selected = record.selected;
                cs.emit(r.selected ? select : unselect, r);
              });
            }
            cs.emit(change, cs, cs.getSelections());
            cs.updateHeaderState();
          }
          me.grid.renderView();
        });
      },
      this
    );
  },
  checkRecordSelectable: function(record) {
    if (record.selectAble === false || record.get("__disabled") === true) {
      return false;
    }
    return true;
  },
  bindSelectionEvent: function() {
    let cs;
    const idProperty = this.grid.store.options.idProperty, me = this;
    cs = this.grid.getPlugin(Selection);
    if (cs) {
      cs.getSelections = function(includeInVisible) {
        const ret = [];
        let r;
        for (const key in this.grid.store.dataHash) {
          if (this.grid.store.dataHash.hasOwnProperty(key)) {
            r = this.grid.store.dataHash[key];
            const flag = me.options.isTreeGroup || r.get("__type") !== "group";
            if (r.selected && r.selectAble !== false && flag && (includeInVisible || me.isRecordVisible(key))) {
              ret.push(r);
            }
          }
        }
        return ret;
      };
    }
    cs = this.grid.getPlugin(CheckSelection);
    const { unselect, select } = checkSelectionEvent;
    if (cs) {
      cs.autoSelectRecordFn = function(lastSelections) {
        const store = this.grid.store, idProperty2 = store.options.idProperty;
        let cur;
        if (lastSelections && lastSelections.length) {
          lastSelections.forEach(function(record) {
            const key = record.get(idProperty2);
            if (key && store.get(key)) {
              store.get(key).selected = true;
            }
          });
          store.dataList.forEach(function(key) {
            const r = store.dataHash[key];
            if (r.get("__type") === "group" && !me.options.isTreeGroup) {
              if (cur) {
                cur.selected = true;
              }
              cur = r;
            } else {
              if (!cur) {
                return;
              }
              if (r.selected !== true) {
                cur = null;
              }
            }
          });
          if (cur) {
            cur.selected = true;
          }
        }
      };
      cs.on(
        unselect,
        function(r) {
          let pr, p, children;
          if (this.options.groupField) {
            p = r.get("__parent");
            if (p) {
              pr = me.grid.store.dataHash[p[idProperty]];
              if (pr) {
                children = me.getVisibleData(pr.get("__children"), true);
                if ($.isArray(children) && children.length) {
                  let selectAbleLen = 0, selectedLen = 0;
                  $.each(children, function(idx, child) {
                    const record = me.grid.store.dataHash[child[idProperty]];
                    if (record.selectAble !== false) {
                      selectAbleLen++;
                      selectedLen += record.selected ? 1 : 0;
                    }
                  });
                  if (selectedLen === 0 || selectedLen === selectAbleLen - 1) {
                    pr.selected = false;
                    me.grid.renderView();
                    cs.updateHeaderState();
                  }
                }
              }
            }
          }
        },
        this
      );
      cs.on(
        select,
        function(r) {
          let pr, p, children;
          if (this.options.groupField) {
            p = r.get("__parent");
            if (p) {
              pr = me.grid.store.dataHash[p[idProperty]];
              if (pr) {
                children = me.getVisibleData(pr.get("__children"), true);
                if ($.isArray(children) && children.length) {
                  let selectAbleLen = 0, selectedLen = 0;
                  $.each(children, function(idx, child) {
                    const record = me.grid.store.dataHash[child[idProperty]];
                    if (record.selectAble !== false) {
                      selectAbleLen++;
                      selectedLen += record.selected ? 1 : 0;
                    }
                  });
                  const allSelected = selectedLen === selectAbleLen;
                  if (allSelected) {
                    pr.selected = true;
                  }
                  if (selectedLen === 1 || allSelected) {
                    me.grid.renderView();
                    cs.updateHeaderState();
                  }
                }
              }
            }
          }
        },
        this
      );
    }
  },
  getGroupInitData: function(key, children, cur) {
    var _a, _b, _c;
    const idProperty = this.grid.store.options.idProperty, ret = {
      __type: "group",
      __expanded: false,
      __field: this.options.groupField,
      __fieldTitle: key,
      __children: children,
      __id: (cur == null ? void 0 : cur.id) || "",
      __groupOnly: !children.length
    };
    const oldGroupId = children.length ? children[0]["__parentId"] : "";
    const isSelected = (_b = (_a = this.grid.store.selectedIDs) == null ? void 0 : _a.has) == null ? void 0 : _b.call(_a, oldGroupId);
    ret[idProperty] = uuid("grid-group-auto-record-");
    const dataHashKeys = Object.keys(this.grid.store.dataHash);
    const lastHashGroupKey = dataHashKeys.find((hashKey) => {
      var _a2;
      const isGroup = ((_a2 = this.grid.store.dataHash[hashKey].data) == null ? void 0 : _a2["__id"]) === ret["__id"];
      return hashKey.startsWith("grid-group-auto-record-") && isGroup;
    });
    if ((_c = this.grid.store.selectedIDs) == null ? void 0 : _c.has(lastHashGroupKey)) {
      this.grid.store.selectedIDs.add(ret[idProperty]);
      this.grid.store.selectedIDs.delete(lastHashGroupKey);
    }
    if (isSelected) {
      this.grid.store.selectedIDs.add(ret[idProperty]);
    }
    if (this.options.autoExpand) {
      if (this.options.expandedList.indexOf(key) !== -1) {
        ret.__expanded = true;
      }
    }
    if ($.isArray(children) && children.length) {
      children.forEach(function(child) {
        child.__parent = ret;
      });
    }
    return ret;
  },
  setGroupRowTr: function(elConfig, rowInfo) {
    const { attrs, classList } = elConfig;
    const { record } = rowInfo;
    const me = this;
    const children = record.get("__children"), idProperty = me.grid.store.options.idProperty;
    let cls = "", hasSelected = false, hasUnselected = false, selectAble = false;
    const groupRowClassList = [getPrefixedClassName(ItemCls)];
    const cs = me.grid.getPlugin(pluginId.checkSelection) || me.grid.getPlugin(pluginId.radioGroupSelection);
    if (cs) {
      if ($.isArray(children) && children.length) {
        $.each(children, function(idx, child) {
          const record2 = me.grid.store.dataHash[child[idProperty]];
          if (record2.selectAble === false) {
            return;
          } else {
            selectAble = true;
          }
          hasUnselected = hasUnselected || record2.selected !== true;
          hasSelected = hasSelected || record2.selected === true;
          if (hasUnselected && hasSelected) {
            return false;
          }
        });
        const groupDisabled = children.every((item) => {
          const record2 = me.grid.store.dataHash[item[idProperty]];
          return record2.get("__disabled");
        });
        if (!selectAble) {
          record.selectAble = false;
        }
        if (groupDisabled) {
          groupRowClassList.push(getPrefixedClassName(ItemDisabledCls));
        }
      }
    }
    if (hasSelected && hasUnselected) {
      cls = getPrefixedClassName(ItemPartSelectedCls);
    } else if (hasSelected) {
      cls = getPrefixedClassName(ItemSelectedCls);
    }
    if (me.options.isTreeGroup) {
      record.selected && (cls = getPrefixedClassName(ItemSelectedCls));
    }
    groupRowClassList.push(cls);
    classList.splice(0, classList.length, ...groupRowClassList);
    attrs.selectAble = `${record.selectAble !== false}`;
  },
  addGroupArw: function(moreTdElements, rowInfo) {
    const { record } = rowInfo;
    const isExpanded = record.get("__expanded");
    const isLoading = this.loadingMap.get(record.get("__fieldTitle"));
    let clsList = [getPrefixedClassName(groupArwCls)];
    if (isExpanded) {
      clsList.push(getPrefixedClassName(groupArwExpandCls));
    }
    if (isLoading) {
      clsList = this.getGroupArwLoadingCls().split(" ");
    }
    const groupArwHtml = `<td style="${groupArwTdStyle}"><div class="${clsList.join(" ")}"></div></td>`;
    moreTdElements.push({
      order: functionalColumnOrder[pluginId.group],
      html: groupArwHtml
    });
  },
  addGroupArwPlaceholder: function(moreTdElements) {
    if (this.isHideGroupCol) {
      return;
    }
    const groupArwPlaceholderHtml = `<td style="${groupArwTdStyle}"></td>`;
    moreTdElements.push({
      order: functionalColumnOrder[pluginId.group],
      html: groupArwPlaceholderHtml
    });
  },
  addGroupCheck: function(moreTdElements, rowInfo) {
    const { record } = rowInfo;
    const me = this, checkSelection = me.grid.getPlugin(CheckSelection), isRadioSelection = !!me.grid.getPlugin(RadioSelection), ret = [];
    let text = checkSelection && record.selectAble !== false ? "" : "-";
    const columnCheckFullClass = [
      getPrefixedClassName(columnCheckCls$2),
      getPrefixedClassName(record.__renderCls__ || "")
    ].join(" ");
    if (!me.options.isTreeGroup && isRadioSelection) {
      ret.push(
        '<td class="' + getPrefixedClassName(columnCheckWrapCls$2) + '" style="width:' + checkSelection.options.width + '; padding: 0;"></td>'
      );
    } else if (checkSelection) {
      let tip = "";
      if (record.selectAble === false) {
        if (typeof me.options.unSelectAbleRenderer === "function") {
          text = me.options.unSelectAbleRenderer.call(this, record) || "-";
        }
        if (typeof me.options.unSelectableTipFn === "function") {
          tip = me.options.unSelectableTipFn.call(this, record) || "";
        }
      }
      const td = Format.format(
        '<td class="{0}" data-tip="{1}" style="width: {2}"><div class="{3}">{4}</div></td>',
        getPrefixedClassName(columnCheckWrapCls$2),
        tip,
        checkSelection.options.width,
        columnCheckFullClass,
        text
      );
      ret.push(td);
    }
    const groupCheckHtml = ret.join("");
    moreTdElements.push({
      order: functionalColumnOrder[pluginId.checkSelection],
      html: groupCheckHtml
    });
  },
  getGroupCeilHtml: function(record, column, row, col, tdOptions) {
    const ret = [], groupArwCol = this.options.groupArwCol;
    tdOptions = tdOptions || {};
    const paddingStyle = tdOptions.isEmpty ? ";padding: 0;" : "";
    if (this.options.colspan) {
      if (!col) {
        ret.push(this.getGroupCeilContent(record, column, row, true, tdOptions));
      }
    } else {
      if (groupArwCol === col) {
        ret.push(this.getGroupCeilContent(record, column, row, false, tdOptions));
      } else {
        column.width = column.width || "auto";
        ret.push(
          '<td class="' + getPrefixedClassName("sfis-grid-column-align-" + (column.align || "left")) + '" style="width:' + column.width + paddingStyle + ';" data-index="' + column.dataIndex + '" data-column-id="' + column.id + '">'
        );
        if (typeof this.options.minorRenderer === "function") {
          ret.push(
            this.options.minorRenderer.call(this.grid, record.get("__fieldTitle"), record, row, col, this.grid.store) || ""
          );
        }
        ret.push("</td>");
      }
    }
    return ret.join("");
  },
  getGroupCeilContent: function(record, column, row, colspan, tdOptions) {
    const me = this, ret = [], columnCnt = me.grid.options.column.filter((item) => !item.hidden).length;
    let content;
    tdOptions = tdOptions || {};
    const paddingStyle = tdOptions.isEmpty ? ";padding: 0;" : "";
    content = record.get("__fieldTitle");
    if (!tdOptions.isEmpty && typeof this.options.renderer === "function") {
      content = this.options.renderer.call(me.grid, content, record, row, 0, me.grid.store);
    }
    ret.push(
      "<td " + (colspan ? ' colspan="' + columnCnt + '"' : "") + ' class="' + getPrefixedClassName(groupCls) + '" style="width:' + (colspan ? "auto" : column.width) + paddingStyle + ';">'
    );
    ret.push(`<div data-index="${column.dataIndex}" data-column-id="${column.id}">`);
    ret.push(content);
    ret.push("</div>");
    ret.push("</td>");
    return ret.join("");
  },
  getVisibleData: function(data, needID) {
    data = data || [];
    const me = this, ret = [], idProperty = this.grid.store.options.idProperty;
    data.forEach(function(item) {
      const id = needID ? item[idProperty] : item;
      if (me.isRecordVisible(id)) {
        ret.push(item);
      }
    });
    return ret;
  },
  isRecordVisible: function(id) {
    if (!id) {
      return false;
    }
    const invisibleHash = this.grid.store.invisibleHash || {};
    return !invisibleHash[id];
  },
  getId: function() {
    return this.options.pluginId;
  },
  expand: function(data) {
    if (!this.options.groupField) {
      return;
    }
    const old = this.options.autoExpand;
    this.options.autoExpand = true;
    if (this.options.expandedList.indexOf(data) === -1) {
      this.options.expandedList.push(data);
      this.refresh();
    }
    this.options.autoExpand = old;
    const expandedGroupData = this.getGroupData(data);
    this.emit(groupEvent.expand, expandedGroupData);
    this.emit(groupEvent.change, expandedGroupData, true);
  },
  collapse: function(data) {
    if (!this.options.groupField) {
      return;
    }
    const old = this.options.autoExpand;
    this.options.autoExpand = true;
    const index = this.options.expandedList.indexOf(data);
    if (index !== -1) {
      this.options.expandedList.splice(index, 1);
      this.refresh();
    }
    this.options.autoExpand = old;
    const collapsedGroupData = this.getGroupData(data);
    this.emit(groupEvent.collapse, collapsedGroupData);
    this.emit(groupEvent.change, collapsedGroupData, false);
  },
  expandAll: function() {
    if (!this.options.groupField) {
      return;
    }
    const old = this.options.autoExpand;
    this.options.autoExpand = true;
    if (this.options.stepLoad) {
      const dataHash = this.grid.store.dataHash;
      for (const key in dataHash) {
        if (dataHash.hasOwnProperty(key)) {
          const record = dataHash[key];
          if (record.get("__type") === "group") {
            const fieldTitle = record.get("__fieldTitle");
            const isNodeLoaded = this.nodeHaveLoaded(fieldTitle);
            if (this.options.shouldLoadNodeChildren(record, isNodeLoaded)) {
              this.updateLoadingMap(fieldTitle, true);
              this.emit(groupEvent.expand, record);
            } else {
              record.set("__expanded", true);
              if (!this.options.expandedList.includes(fieldTitle)) {
                this.options.expandedList.push(fieldTitle);
              }
              this.emit(groupEvent.expand, record);
            }
          }
        }
      }
      this.options.autoExpand = old;
      this.syncGroupToggleIcon();
      this.emit(groupEvent.expandAll);
      this.emit(groupEvent.change, this.getGroupData(), true);
      this.grid.renderView(null, null, true);
      return;
    }
    if (this.groupRecord && $.isArray(this.groupRecord)) {
      this.groupRecord.forEach((item) => {
        if (this.options.expandedList.indexOf(item) === -1) {
          this.options.expandedList.push(item);
        }
      });
      this.refresh();
    }
    this.options.autoExpand = old;
    this.emit(groupEvent.expandAll);
    this.emit(groupEvent.change, this.getGroupData(), true);
  },
  collapseAll: function() {
    if (!this.options.groupField) {
      return;
    }
    if (this.options.autoExpand) {
      const dataHash = this.grid.store.dataHash;
      for (const key in dataHash) {
        if (dataHash.hasOwnProperty(key)) {
          const record = dataHash[key];
          const index = this.options.expandedList.indexOf(record.get("__fieldTitle"));
          if (record.get("__type") === "group" && index !== -1) {
            this.options.expandedList.splice(index, 1);
          }
        }
      }
    }
    this.refresh();
    this.emit(groupEvent.collapseAll);
    this.emit(groupEvent.change, this.getGroupData(), false);
  },
  getGroupToggleIconStatus: function() {
    return getToggleStatus.call(this, {
      colID: this.groupColumnId
    });
  },
  groupBy: function(id) {
    this.options.groupField = id;
    this.refresh();
  },
  clearGroup: function() {
    delete this.options.groupField;
    this.refresh();
  },
  refresh: function() {
    const data = [], me = this;
    this.grid.store.dataList.forEach(function(key) {
      var _a;
      const record = me.grid.store.dataHash[key];
      if (!record) {
        return;
      }
      if (me.options.isTreeGroup) {
        if (record.get("__type") === "group") {
          record.data.__children.forEach(function(item) {
            delete item.__parent;
          });
          record.set(me.options.childrenField, record.data.__children);
          data.push(record.data);
        }
        return;
      }
      if (record.get("__type") !== "group" || record.get("__groupOnly")) {
        const parentId = (_a = record.data.__parent) == null ? void 0 : _a[me.grid.store.options.idProperty];
        record.data.__parentId = parentId;
        delete record.data.__parent;
        data.push(record.data);
      }
    });
    this.grid.store.loadData(data);
  },
  isUndefined: function(key) {
    return typeof key === "undefined";
  },
  updateIsHideGroupCol: function(data) {
    var _a, _b;
    if (!((_a = this.options) == null ? void 0 : _a.isHideGroupColumnWhenNoGroup)) {
      return;
    }
    if (!((_b = this.options) == null ? void 0 : _b.groupField)) {
      this.isHideGroupCol = true;
      return;
    }
    const isNeedGroup = data.some((item) => {
      var _a2;
      return !!item[(_a2 = this.options) == null ? void 0 : _a2.groupField];
    });
    if (!isNeedGroup !== this.isHideGroupCol) {
      this.isHideGroupCol = !isNeedGroup;
      this.grid.updateOption();
    }
  },
  destroy: function() {
    var _a, _b;
    this.clear();
    (_a = this.loadingMap) == null ? void 0 : _a.clear();
    this.loadingMap = null;
    this.toggleClass = null;
    (_b = this.stepLoadedNode) == null ? void 0 : _b.clear();
    this.stepLoadedNode = null;
    delete this.grid;
  },
  getGroupData(groupField) {
    const dataHash = this.grid.store.dataHash;
    const groupRecords = Object.values(dataHash).filter((item) => item.get("__type") === "group");
    if (!groupField) {
      return groupRecords;
    }
    return groupRecords.find((record) => record.get("__fieldTitle") === groupField);
  },
  getGroupArwLoadingCls: function() {
    return this.options.groupArwLoadingCls === defaultGroupArwLoadingCls ? [getPrefixedClassName(defaultGroupArwLoadingMainCls), ...defaultGroupArwLoadingIconCls].join(" ") : this.options.groupArwLoadingCls;
  },
  updateLoadingMap: function(fieldTitle, state) {
    if (state) {
      this.loadingMap.set(fieldTitle, true);
      return;
    }
    this.loadingMap.delete(fieldTitle);
  },
  nodeHaveLoaded(fieldTitle) {
    return this.stepLoadedNode.has(fieldTitle);
  },
  storeLoadedNode(fieldTitle) {
    this.stepLoadedNode.add(fieldTitle);
  },
  syncGroupToggleIcon: function() {
    if (!this.toggleClass || !this.options.groupField) {
      return;
    }
    const dataHash = this.grid.store.dataHash;
    const groupRecords = Object.values(dataHash).filter((item) => item.get("__type") === "group");
    if (!groupRecords.length) {
      return;
    }
    const allExpanded = groupRecords.every((record) => record.get("__expanded") === true);
    const allCollapsed = groupRecords.every((record) => record.get("__expanded") === false);
    if (allExpanded || allCollapsed) {
      this.toggleClass(!allExpanded);
    }
  },
  updateGroupNodeData: function(groupData, data) {
    if (!groupData || !Array.isArray(data)) {
      GridGroupLogger.error("updateGroupNodeData: invalid parameters");
      return false;
    }
    const curFieldTitle = groupData.get("__fieldTitle") || groupData["__fieldTitle"] || groupData["fieldTitle"];
    const isNodeLoaded = this.nodeHaveLoaded(curFieldTitle);
    const groupRecord = this.getGroupData(curFieldTitle);
    if (!groupRecord) {
      GridGroupLogger.error("updateGroupNodeData: group record not found for group: %s", curFieldTitle);
      this.updateLoadingMap(curFieldTitle, false);
      return false;
    }
    if (!this.options.stepLoad || !this.options.shouldLoadNodeChildren(groupRecord, isNodeLoaded)) {
      return false;
    }
    this.storeLoadedNode(curFieldTitle);
    groupRecord.set("__expanded", true);
    this.syncGroupToggleIcon();
    if (!this.options.expandedList.includes(curFieldTitle)) {
      this.options.expandedList.push(curFieldTitle);
    }
    const newData = [];
    const groupField = this.options.groupField;
    let hasReplacedGroup = false;
    this.grid.store.dataList.forEach((key) => {
      const record = this.grid.store.dataHash[key];
      if (!record || record.get("__type") === "group") {
        return;
      }
      const recordGroupTitle = record.get(groupField);
      if (recordGroupTitle === curFieldTitle) {
        if (!hasReplacedGroup) {
          newData.push(...data);
          hasReplacedGroup = true;
        }
        return;
      }
      delete record.data.__parent;
      newData.push(record.data);
    });
    this.grid.store.loadData(newData);
    this.updateLoadingMap(curFieldTitle, false);
    return true;
  }
});
Group.pluginId = pluginId.group;
const getDefaultConfigs$1 = () => ({
  pluginId: pluginId.radioGroupSelection,
  noChildSelection: true
});
const columnCheckCls$1 = "sfis-grid-column-ceil-check";
const columnCheckWrapCls$1 = "sfis-grid-column-ceil-wrap-check";
const RadioGroupSelection = oop.extend(RadioSelection, {
  constructor: function(_options) {
    const options = {
      ...getDefaultConfigs$1(),
      ..._options
    };
    RadioGroupSelection.superclass.constructor.apply(this, [options]);
  },
  doRowClick: function(el, record, event2) {
    if (this.options.noChildSelection) {
      return;
    }
    if (this.options.mode === mode.single) {
      if ($(event2.target).hasClass(columnCheckCls$1) || $(event2.target).hasClass(columnCheckWrapCls$1)) {
        this.doRowMultiClick.apply(this, arguments);
      } else {
        this.doRowSingleClick.apply(this, arguments);
      }
    } else {
      this.doRowMultiClick.apply(this, arguments);
    }
  },
  doRowMultiClick: function(dom, record) {
    const group = this.grid.getPlugin(pluginId.group), idProperty = this.grid.store.options.idProperty, isSelected = record.selected, unSelect = [], me = this;
    let brother;
    if (group && group.options.groupField) {
      brother = record.get("__parent").__children;
      if ($.isArray(brother)) {
        brother.forEach(function(child) {
          const r = me.grid.store.dataHash[child[idProperty]];
          if (r && r.selectAble !== false) {
            unSelect.push(r);
          }
        });
      }
      this.unSelect(unSelect);
      if (isSelected && this.options.mode === mode.multi) {
        return;
      }
      this.select(record);
    } else {
      this.doRowSingleClick.apply(this, arguments);
    }
  },
  selectGroup: function(record) {
    const group = this.grid.getPlugin(pluginId.group);
    const gridCheckSelection = this.grid.getPlugin(CheckSelection);
    const idProperty = this.grid.store.options.idProperty;
    const groupRecord = this.getRecordModelByID(record[group.__cacheGroupField]);
    if (!groupRecord || !group.checkRecordSelectable(groupRecord)) {
      return false;
    }
    gridCheckSelection.unSelectAll();
    const children = group.getVisibleData(groupRecord.get("__children"), true);
    groupRecord.selected = true;
    children.forEach((child) => {
      const childRecord = this.grid.store.dataHash[child[idProperty]];
      if (!group.checkRecordSelectable(childRecord)) {
        return;
      }
      this.select(childRecord);
    });
    return true;
  },
  selectFirst: function() {
    const group = this.grid.getPlugin(pluginId.group);
    if ($.isArray(group.groupRecord) && group.groupRecord.length) {
      group.groupRecord.some((id) => {
        const selected = this.selectGroup({
          [group.__cacheGroupField]: id
        });
        return selected;
      });
    }
  },
  getRecordModelByID: function(recordID) {
    const group = this.grid.getPlugin(pluginId.group);
    const groupField = group.options.groupField;
    const groupRecord = Object.values(this.grid.store.dataHash).find((model) => {
      if (model.data[groupField] === recordID) {
        return true;
      }
      return false;
    });
    return groupRecord;
  }
});
RadioGroupSelection.pluginId = pluginId.radioGroupSelection;
var fieldCtxTpl = `
<td class="{[values.getPrefixedClassName('sfis-grid-tree-item-td')]} {tdCls}" style="{tdStyle}">
  {levelBlockTpl}
  {fieldBeforeBlockTpl}
  {treeCheckboxTpl}
  <div style="{fieldStyle}" class="{fieldCls}">
    <div class="{[values.getPrefixedClassName('ver-center')]} {fieldContentCls}" data-id="{id}" data-uuid="{uuid}" draggable={draggable}>
      <tpl if="icon"><div class="{[values.getPrefixedClassName('sfis-grid-tree-item-icon')]}">{icon}</div></tpl>
      <div class="{[values.getPrefixedClassName('sfis-grid-tree-item-text')]}">{renderText}</div>
    </div>
  </div>
  <tpl if="showMenu">
    <span class="{[values.getPrefixedClassName('tree-item-menu-btn')]}" style="{menuStyle}" ></span>
  </tpl>
</td>
`;
const defaultTreeArwCls = "sfis-grid-tree-arw";
const defaultTreeArwExpandCls = "sfis-grid-tree-arw-expand";
const defaultTreeArwLoadingMainCls = "sfis-grid-tree-arw-loading";
const defaultTreeArwLoadingIconCls = ["iconfont", "vtv-icon-comp-loading", "sf-icon-rotate"];
const defaultTreeArwLoadingCls = [defaultTreeArwLoadingMainCls, ...defaultTreeArwLoadingIconCls].join(" ");
const treeBgTheme = {
  bright: "bright-theme"
};
const selectStatus = {
  select: "select",
  unselect: "unselect",
  partSelect: "partSelect"
};
const getDefaultConfigs = () => ({
  pluginId: pluginId.tree,
  treeField: "name",
  childrenField: "data",
  needRoot: true,
  rootText: $i("scp.vt_component.common.widget.Grid.plugins.Tree.root_text"),
  hideCheckbox: false,
  hideGroupArw: false,
  isGroupSingleCol: true,
  isSelectAlone: false,
  partialSelect: false,
  autoExpandAll: false,
  radioCanSelectGroup: false,
  autoSortdirect: sortDirection.ASC,
  treeBgTheme: "",
  autoSortGroup: false,
  autoSortLeaf: false,
  groupSortFn: null,
  isGroupFn: function(data) {
    return data.type === "group";
  },
  rowCls: "",
  treeArwCls: defaultTreeArwCls,
  treeArwLoadingCls: defaultTreeArwLoadingCls,
  treeArwExpandCls: defaultTreeArwExpandCls,
  selectAbleFn: null,
  namePathSeparator: "/",
  multiRoot: false,
  hiddenIcon: false,
  hiddenTreeArw: false,
  includeRoot: false,
  needToggleIcon: true,
  stepLoad: false,
  hasChildrenField: "group",
  hasChildrenFn: null,
  hasMenu: false,
  isShowMenu: function() {
    return true;
  },
  autoScrollX: false,
  nodeDraggable: false,
  treeDottedStyle: true,
  indentWidth: "25px",
  ignoreItemFn: null,
  shouldLoadNodeChildren: (record, isNodeLoaded) => !isNodeLoaded
});
const localSortFn = function(data, sort, direct, sortFn, scope) {
  data.sort(function(data1, data2) {
    if (typeof sortFn === "function") {
      return sortFn.call(scope, data1, data2, direct);
    } else {
      if (direct === sortDirection.ASC) {
        return localeCompare(data1[sort], data2[sort]);
      } else {
        return localeCompare(data2[sort], data1[sort]);
      }
    }
  });
};
const GridTreeLogger = Logger("GridTree");
const itemSelectedCls = "sfis-grid-body-item-selected";
const itemPartSelectedCls = "sfis-grid-body-tree-item-part-selected";
const headerCheckCls = "sfis-grid-column-header-check";
const columnCheckWrapCls = "sfis-grid-column-ceil-wrap-check";
const columnCheckCls = "sfis-grid-column-ceil-check";
const headerCheckAllCls = "sfis-grid-column-header-check-all";
const headerCheckPartCls = "sfis-grid-column-header-check-part";
const itemRowCls = "sfis-grid-body-item";
const treeGroupRowCls = "sfis-grid-body-tree-group";
const treeGroupNoChildrenRowCls = `${treeGroupRowCls}--no-children`;
const treeLeafRowCls = "sfis-grid-body-tree-leaf";
const getTreeFoldCls = () => `iconfont vtv-icon-file ${getPrefixedClassName("sfis-grid-tree-fold")}`;
const getTreeFoldExpandCls = () => `iconfont vtv-icon-file-expand ${getPrefixedClassName("sfis-grid-tree-fold-expand")}`;
const getTreeLeafCls = () => `iconfont vtv-icon-hci ${getPrefixedClassName("sfis-grid-tree-leaf")}`;
const treeFieldCls = "sfis-grid-tree-field";
const treeFieldBlockCls = "sfis-grid-tree-field-block";
const treeFieldBlockNoLineCls = "sfis-grid-tree-field-block--no-line";
const treeFieldLastCls = "sfis-grid-tree-field-block-last";
const getTreeFieldRootCls = () => getPrefixedClassName("sfis-grid-tree-field-block-root");
const getTreeFieldMultiRootCls = () => `${getPrefixedClassName("sfis-grid-tree-field-block-root")} ${getPrefixedClassName("multi-root")}`;
const levelBlockCls = "level-block-item";
const lineBlockCls = "line-block-item";
const disabledCls = "sfis-grid-body-item-disabled";
const M_TREE_ITEM_MENU_CLS = "tree-item-menu-btn";
const TREE_MENU_WIDTH = 20 + 5;
const SELECT_STATUS_MAP = {
  select: itemSelectedCls,
  unselect: "",
  partSelect: itemPartSelectedCls
};
const privateRootId = "__root";
const LEVEL_BLOCK_WIDTH = 21;
const FIELD_BEFORE_BLOCK_WIDTH = 21;
const Tree = oop.extend(Observable, {
  constructor: function(options) {
    this.options = {
      ...getDefaultConfigs(),
      ...options
    };
    this.initEvent();
    this.listeners = this.options.listeners;
    Tree.superclass.constructor.apply(this, arguments);
  },
  init: function(grid) {
    if (!grid) {
      GridTreeLogger.error("cant't find grid, Tree do not work");
      return;
    }
    if (this.options.treeBgTheme === treeBgTheme.bright && typeof grid.options.border === "undefined") {
      grid.options.border = true;
    }
    this.grid = grid;
    this.cs = grid.getPlugin(CheckSelection);
    this.ra = grid.getPlugin(RadioSelection);
    this.sort = grid.getPlugin(Sortable);
    this.idProperty = grid.store.options.idProperty;
    this.orgData = [];
    this.loaded = false;
    this.expandedMap = {};
    this.expandedMap[privateRootId] = true;
    this.showAll = true;
    this.justShowLeaves = false;
    this.needSortGroup = this.options.autoSortGroup;
    this.needSortLeaf = this.options.autoSortLeaf;
    this.loadingMap = {};
    this.orgTreeData = [];
    this.menuLeftOffset = 0;
    this.initLoadedNodeSet();
    this.initVisibleRecords();
    this.reWriteGridFn();
    this.reWriteStoreFn();
    this.reWriteSectionFn();
    this.reWriteSortableFn();
    this.bindGridEvent();
    this.bindStoreEvent();
    this.bindSelectionEvent();
    this.bindScrollEvent();
  },
  initEvent: function() {
    const { expand, treeMenuClick } = treeEvent;
    this.addEvents(expand, treeMenuClick);
  },
  reWriteGridFn: function() {
    this.grid.refresh = this.refresh.bind(this);
    this.grid.getRowTrHtml = this.getTreeRowTrHtml.bind(this);
    this.grid.getRowTdHtml = this.getTreeRowTdHtml.bind(this);
    this.grid.getStoreCount = this.getTreeStoreCount.bind(this);
    if (this.options.autoScrollX) {
      this.grid.getAllDataWidth = this.getTreeAllDataWidth.bind(this);
      this.grid.on(
        gridEvent.afterRender,
        function() {
          this.grid.gridEl.addClass(getPrefixedClassName("sfis-grid-tree-auto-scroll-x"));
        },
        this
      );
    }
  },
  reWriteStoreFn: function() {
    this.grid.store.loadData = this.loadData.bind(this);
    this.grid.store.getRange = this.getTreeRange.bind(this);
    this.grid.store.search = this.search.bind(this);
    this.grid.store.endSearch = this.endSearch.bind(this);
  },
  reWriteSectionFn: function() {
    const cs = this.cs;
    if (cs) {
      cs.updateHeaderState = this.updateHeaderState.bind(this);
      cs.selectAll = this.selectAll.bind(this);
      cs.unSelectAll = this.unSelectAll.bind(this);
    }
  },
  reWriteSortableFn: function() {
    const me = this;
    if (me.sort) {
      me.sort.doLocalSort = function(dataIndex, direction, sortFn) {
        me.needSortGroup = true;
        me.needSortLeaf = true;
        const sortSelf = this;
        const sortData = me.sortTreeData({
          treeData: me.orgData,
          direction,
          sortFn
        });
        sortSelf.preventLoad = true;
        me.loadData(sortData);
      };
    }
  },
  getInitTreeData: function(data, parent, level) {
    const me = this, childrenField = this.options.childrenField, isGroupFn = this.options.isGroupFn, expandedMap = this.expandedMap, loadingMap = this.loadingMap, idProperty = this.idProperty, nameProperty = this.options.treeField, namePathSeparator = this.options.namePathSeparator, isStepLoad = this.options.stepLoad;
    let newData = [], childrenList;
    data.forEach(function(item, index) {
      if (!item[idProperty]) {
        item[idProperty] = item.id;
      }
      childrenList = (item[childrenField] || []).map(function(childData) {
        return childData[idProperty] || childData.id;
      });
      const isGroupNode = isGroupFn(item) === true || item.id === privateRootId;
      if (isStepLoad && isGroupNode && childrenList.length) {
        me.storeLoadedNode(item[idProperty]);
      }
      $.extend(item, {
        __uuid: item[idProperty],
        __parent: parent && parent.__uuid || "",
        __namePath: parent ? parent.__namePath + namePathSeparator + item[nameProperty] : item[nameProperty],
        __children: childrenList,
        __isGroup: isGroupNode,
        __isExpanded: expandedMap[item[idProperty]] === true,
        __isLoading: loadingMap[item[idProperty]] === true,
        __isLast: index === data.length - 1,
        __leavesCount: me.getLeavesCount(item[childrenField] || []),
        __level: level || 0,
        __deep: level || 0
      });
      newData.push(item);
      if (item[childrenField] && item[childrenField].length) {
        newData = newData.concat(
          me.getInitTreeData(
            item[childrenField],
            {
              __uuid: item.__uuid,
              __namePath: item.__namePath
            },
            item.__level + 1
          )
        );
      }
    });
    return newData;
  },
  getRecordRealLen: function(record) {
    if (!record) {
      return 0;
    }
    if (record.get("__isGroup") && record.get("__isExpanded") === false) {
      return 1 + this.getChildrenLen(record);
    } else {
      return 1;
    }
  },
  getChildrenLen: function(record) {
    const me = this, dataHash = this.grid.store.dataHash;
    let len = 0;
    record.get("__children").forEach(function(child) {
      len += 1 + me.getChildrenLen(dataHash[child]);
    });
    return len;
  },
  getTreeRootCls: function() {
    return this.options.multiRoot ? getTreeFieldMultiRootCls() : getTreeFieldRootCls();
  },
  checkHasSelectedLeaf: function(record) {
    return this.checkLeafSelected(record, true);
  },
  checkHasUnSelectedLeaf: function(record) {
    return this.checkLeafSelected(record, false);
  },
  checkLeafSelected: function(record, leafIsSelected) {
    const me = this, dataHash = me.grid.store.dataHash;
    let isSelected = false, visibleChildren, childRecord;
    if (record.get("__isGroup")) {
      visibleChildren = record.get("__children").filter(function(child) {
        childRecord = dataHash[child];
        return me.checkIsVisible(childRecord) && me.checkIsSelectAble(childRecord);
      });
      $.each(visibleChildren, function(index, child) {
        childRecord = dataHash[child];
        isSelected = me.checkLeafSelected(childRecord, leafIsSelected);
        if (isSelected) {
          return false;
        }
      });
    } else {
      isSelected = leafIsSelected ? record.selected === true : record.selected !== true;
    }
    return isSelected;
  },
  isGroup: function(record) {
    record = this.transformRecord(record)[0];
    return record && record.get("__isGroup");
  },
  checkIsSelectAble: function(record) {
    const me = this, dataHash = me.grid.store.dataHash;
    let isSelectAble = false, visibleChildren, childRecord;
    if (!record) {
      return false;
    }
    if (record.selectAble === false) {
      return false;
    }
    if ($.isFunction(me.options.selectAbleFn)) {
      return me.options.selectAbleFn.call(me, record);
    }
    if (record.get("__isGroup")) {
      visibleChildren = record.get("__children").filter(function(child) {
        childRecord = dataHash[child];
        return me.checkIsVisible(childRecord);
      });
      $.each(visibleChildren, function(index, child) {
        childRecord = dataHash[child];
        isSelectAble = me.checkIsSelectAble(childRecord);
        if (isSelectAble) {
          return false;
        }
      });
    } else {
      isSelectAble = record.selectAble !== false;
    }
    return isSelectAble;
  },
  checkIsDisabled: function(record) {
    const me = this, dataHash = me.grid.store.dataHash;
    let isDisabled = false, visibleChildren, childRecord;
    record = this.transformRecord(record)[0];
    if (!record || record.get("__disabled")) {
      return true;
    }
    if (record.get("__isGroup")) {
      visibleChildren = record.get("__children").filter(function(child) {
        childRecord = dataHash[child];
        return me.checkIsVisible(childRecord);
      });
      if (visibleChildren.length) {
        isDisabled = visibleChildren.every(function(child) {
          return me.checkIsDisabled(dataHash[child]);
        });
      }
    }
    return isDisabled;
  },
  checkIsVisible: function(record) {
    if (!record) {
      return false;
    }
    if (this.showAll) {
      return true;
    }
    return this.visibleRecords[record.get(this.idProperty)];
  },
  getLeavesCount: function(list) {
    const me = this, childrenField = me.options.childrenField;
    let len = 0;
    list.forEach(function(item) {
      if (item[childrenField] && item[childrenField].length) {
        len += me.getLeavesCount(item[childrenField]);
      } else {
        len++;
      }
    });
    return len;
  },
  getNodesCount: function(records) {
    const me = this;
    records = records || me.grid.store.dataList;
    records = me.transformRecord(records);
    return records.filter(function(record) {
      return !record.get("__isGroup");
    }).length;
  },
  getTreeRowTrHtml: function(record) {
    const me = this, key = record.get(me.idProperty), _itemRowCls = record.get("__isGroup") ? "" : getPrefixedClassName(itemRowCls), _TreeRowCls = record.get("__isGroup") ? getPrefixedClassName(treeGroupRowCls) : getPrefixedClassName(treeLeafRowCls), _selectableCls = getPrefixedClassName(SELECT_STATUS_MAP[me.getRecordSelectStatus(key)]), _disabledCls = me.checkIsDisabled(record) ? getPrefixedClassName(disabledCls) : "", _GroupNoChildrenCls = this.isGroupRecordHasChildren(record) ? "" : getPrefixedClassName(treeGroupNoChildrenRowCls);
    let _otherCls = "";
    if (me.options.rowCls) {
      if ($.isFunction(me.options.rowCls)) {
        _otherCls += me.options.rowCls.call(me, record);
      } else {
        _otherCls += me.options.rowCls;
      }
    }
    const trCls = [_itemRowCls, _TreeRowCls, _GroupNoChildrenCls, _selectableCls, _disabledCls, _otherCls].join(" ");
    return Format.format(
      '<tr data-id="{0}" class="{1}" selectable="{2}" style="{3}">',
      Format.htmlEncode(key),
      trCls,
      me.checkIsSelectAble(record) !== false ? "true" : "false",
      "height:" + me.grid.options.rowHeight + "px"
    );
  },
  getTreeRowTdHtml: function(record, row) {
    const g = this.grid, columns = g.options.column, checkPlugin = this.cs || this.ra, otherTreeFieldCols = columns.slice(1), ret = [];
    let getTreeCeilHtml;
    if (checkPlugin && !this.options.hideCheckbox) {
      ret.push(this.getTreeCheckboxHtml(record));
    }
    if (record.get("__isGroup") && this.options.isGroupSingleCol) {
      getTreeCeilHtml = function(record2, column) {
        column.width = column.width || "auto";
        column.align = column.align || "left";
        column.cls = column.cls || " ";
        const tdClass = [getPrefixedClassName(`sfis-grid-column-align-${column.align}`), column.cls].join(" ");
        return '<td class="' + tdClass + '" style="width:' + column.width + ';"></td>';
      };
    } else {
      getTreeCeilHtml = this.grid.getCeilHtml;
    }
    ret.push(this.getTreeFieldCtxHtml(record, row));
    otherTreeFieldCols.forEach(function(column, col) {
      ret.push(getTreeCeilHtml.call(g, record, column, row, col));
    });
    return ret.join("");
  },
  getTreeCheckboxHtml: function(record) {
    const checkPlugin = this.cs || this.ra;
    let isText = true, textCls = "", text = "", selectionTitle = (record.get("__selectionTitle") || "").trim();
    if (!selectionTitle && typeof checkPlugin.options.tipFn === "function") {
      selectionTitle = checkPlugin.options.tipFn(record);
    }
    if (record.selectAble === false) {
      if (typeof record.__renderer__ === "function") {
        text = record.__renderer__.call(this, record) || "-";
      }
      isText = !/<[^>]+>/.test(text);
      if (isText) {
        textCls = getPrefixedClassName("no-selection-text");
      }
      return '<td class="' + getPrefixedClassName(columnCheckWrapCls) + '" style="width:' + checkPlugin.options.width + '"><div class="' + [getPrefixedClassName(columnCheckCls), textCls, getPrefixedClassName(record.__renderCls__)].join(" ") + '" data-hint="' + selectionTitle + '">' + text + "</div></td>";
    }
    return Format.format(
      '<td class="{0}" style="{1}" data-hint="{2}"><div class="{3}">{4}</div></td>',
      getPrefixedClassName(columnCheckWrapCls),
      "width:" + checkPlugin.options.width,
      selectionTitle,
      getPrefixedClassName(columnCheckCls),
      text
    );
  },
  checkIsRoot: function(record) {
    const level = record.get("__level"), id = record.get("id");
    return id === privateRootId || !level && this.options.multiRoot;
  },
  getTreeAllDataWidth: function() {
    const viewEl = this.grid.viewEl, textWraps = viewEl.find(".sfis-grid-tree-item-text-wrap");
    let textMaxWidth = 0;
    if (!textWraps.length) {
      return 0;
    }
    $.each(textWraps, function(index, t) {
      const $t = $(t), id = $t.data("id"), $tr = viewEl.find('tr[data-id="' + id + '"]'), $td = $tr.find(".sfis-grid-tree-item-td"), $levelBlock = $tr.find(".level-block-wrap"), $fieldBlock = $tr.find(".sfis-grid-tree-field-block");
      const maxWidth = $t.innerWidth() + $levelBlock.innerWidth() + $fieldBlock.innerWidth() + (parseInt($td.css("paddingLeft"), 10) || 0) + (parseInt($td.css("paddingRight"), 10) || 0);
      if (maxWidth > textMaxWidth) {
        textMaxWidth = maxWidth;
      }
    });
    textMaxWidth += 2 * this.grid.options.scrollWidth;
    const viewWidth = viewEl.innerWidth();
    const curWidth = textMaxWidth;
    if (curWidth > viewWidth) {
      this.grid.viewEl.find("table").css({
        width: curWidth + "px"
      });
    }
    return curWidth;
  },
  getTreeCheckboxCtxHtml: function(record) {
    const checkPlugin = this.cs;
    if (!checkPlugin || !checkPlugin.options.checkboxInTreeField) {
      return "";
    }
    let isText = true, textCls = "", text = "", selectionTitle = (record.get("__selectionTitle") || "").trim();
    if (!selectionTitle && typeof checkPlugin.options.tipFn === "function") {
      selectionTitle = checkPlugin.options.tipFn(record);
    }
    if (record.selectAble === false) {
      if (typeof record.__renderer__ === "function") {
        text = record.__renderer__.call(this, record) || "-";
      }
      isText = !/<[^>]+>/.test(text);
      if (isText) {
        textCls = getPrefixedClassName("no-selection-text");
      }
      return '<div class="' + getPrefixedClassName(columnCheckWrapCls) + ` ${getPrefixedClassName("multip-check")}"><div class="` + [getPrefixedClassName(columnCheckCls), textCls, getPrefixedClassName("no-selection-checkbox")].join(" ") + '" data-hint="' + selectionTitle + '">' + text + "</div></div>";
    }
    return Format.format(
      '<div class="{0} multip-check" data-hint="{1}"><div class="{2}">{3}</div></div>',
      getPrefixedClassName(columnCheckWrapCls),
      selectionTitle,
      getPrefixedClassName(columnCheckCls),
      text
    );
  },
  getTreeFieldCtxHtml: function(record, row) {
    const level = record.get("__level"), isRoot = this.checkIsRoot(record), firstFieldCol = this.grid.options.column[0], rowHeight = this.grid.options.rowHeight;
    const icon = this.getItemIcon(record, row);
    const treeCheckboxTpl = this.getTreeCheckboxCtxHtml(record);
    const CHECKBOX_OR_RADIO_OCCUPY_WIDTH = treeCheckboxTpl ? 30 : 0;
    return new XTpl(fieldCtxTpl).apply({
      id: record.get(this.idProperty),
      uuid: record.get("__uuid"),
      tdCls: `${getPrefixedClassName(`sfis-grid-column-align-${firstFieldCol.align || "left"}`)} ${firstFieldCol.cls || ""}`,
      tdStyle: "padding:0 8px; width:" + (firstFieldCol.width || "auto"),
      levelBlockTpl: this.getLevelBlockHtml(record),
      fieldBeforeBlockTpl: this.getFieldBeforeBlockHtml(record),
      treeCheckboxTpl,
      showMenu: this.options.hasMenu && this.options.isShowMenu.call(this, record, row),
      menuStyle: this.options.hasMenu ? "left: " + this.getMenuStyleLeft() + "px" : "",
      fieldStyle: "height:" + rowHeight + "px; width:calc(100% - " + (level * LEVEL_BLOCK_WIDTH + FIELD_BEFORE_BLOCK_WIDTH + CHECKBOX_OR_RADIO_OCCUPY_WIDTH) + "px)",
      fieldCls: getPrefixedClassName(treeFieldCls) + " " + (isRoot ? this.getTreeRootCls() : ""),
      fieldContentCls: this.options.autoScrollX ? `${getPrefixedClassName("width-auto")}  ${getPrefixedClassName("sfis-grid-tree-item-text-wrap")}` : "",
      icon,
      renderText: this.getFieldRenderText(record, row, icon),
      draggable: !record.get("__isGroup") && this.options.nodeDraggable,
      getPrefixedClassName
    });
  },
  getMenuStyleLeft: function() {
    return this.menuLeftOffset || this.grid.bodyEl.innerWidth() - this.grid.options.scrollWidth - TREE_MENU_WIDTH;
  },
  getLevelBlockHtml: function(record) {
    if (this.justShowLeaves) {
      return "";
    }
    const itemTplList = [], dataHash = this.grid.store.dataHash;
    let level = record.get("__level") - 1, pRecord = dataHash[record.get("__parent")], isLast = false;
    while (level >= 0) {
      isLast = pRecord && !pRecord.get("__isLast");
      const isMultiRoot = !level && this.options.multiRoot;
      let cls = "";
      let style = "";
      if (this.options.treeDottedStyle) {
        cls = [
          getPrefixedClassName(levelBlockCls),
          isMultiRoot ? "" : isLast ? getPrefixedClassName(lineBlockCls) : ""
        ].join(" ");
      } else {
        cls = getPrefixedClassName(levelBlockCls);
        style = "width:" + this.options.indentWidth;
      }
      itemTplList.push(Format.format('<div class="{0}" style="{1}"></div>', cls, style));
      pRecord = dataHash[pRecord.get("__parent")];
      level--;
    }
    return [
      `<div class="${getPrefixedClassName("level-block-wrap")}" style="height: ${this.grid.options.rowHeight}px">`,
      itemTplList.reverse().join(""),
      "</div>"
    ].join("");
  },
  getTreeArwCls: function(isExpanded, isLoading) {
    if (this.options.hiddenTreeArw) {
      return "";
    }
    if (isLoading) {
      return this.options.treeArwLoadingCls === defaultTreeArwLoadingCls ? [getPrefixedClassName(defaultTreeArwLoadingMainCls), ...defaultTreeArwLoadingIconCls].join(" ") : this.options.treeArwLoadingCls;
    }
    if (isExpanded) {
      return this.options.treeArwExpandCls === defaultTreeArwExpandCls ? getPrefixedClassName(defaultTreeArwExpandCls) : this.options.treeArwExpandCls;
    }
    return this.options.treeArwCls === defaultTreeArwCls ? getPrefixedClassName(defaultTreeArwCls) : this.options.treeArwCls;
  },
  getFieldBeforeBlockHtml: function(record) {
    if (this.justShowLeaves) {
      return "";
    }
    const rowHeight = this.grid.options.rowHeight, isExpanded = record.get("__isExpanded"), isLoading = record.get("__isLoading"), isRoot = this.checkIsRoot(record), isLast = record.get("__isLast"), style = "height:" + rowHeight + "px";
    let arwCls = "";
    if (record.get("__isGroup")) {
      const groupHasChildren = this.isGroupRecordHasChildren(record);
      if (groupHasChildren) {
        arwCls += this.getTreeArwCls(false, isLoading);
        if (isExpanded) {
          arwCls += " " + this.getTreeArwCls(true, isLoading);
        }
      }
      return Format.format(
        '<div style="{0}" class="{1}"><div class="{2}"></div></div>',
        style,
        [
          getPrefixedClassName(treeFieldBlockCls),
          isLast ? getPrefixedClassName(treeFieldLastCls) : "",
          isRoot ? this.getTreeRootCls() : "",
          this.options.treeDottedStyle ? "" : treeFieldBlockNoLineCls
        ].join(" "),
        `${getPrefixedClassName("ver-center")} ${arwCls}`
      );
    }
    return Format.format(
      '<div style="{0}" class="{1}"></div>',
      style,
      [
        getPrefixedClassName(treeFieldBlockCls),
        isLast ? getPrefixedClassName(treeFieldLastCls) : "",
        this.options.treeDottedStyle ? "" : getPrefixedClassName(treeFieldBlockNoLineCls)
      ].join(" ")
    );
  },
  getItemIcon: function(record, row) {
    const firstFieldCol = this.grid.options.column[0];
    let iconCls = record.get("__isGroup") ? firstFieldCol.groupIconCls : firstFieldCol.iconCls;
    if ($.isFunction(iconCls)) {
      iconCls = iconCls.call(this, record, row);
    }
    return typeof iconCls !== "string" && !iconCls ? "" : '<div class="' + iconCls + '"></div>';
  },
  getFieldRenderText: function(record, row, icon) {
    const firstFieldCol = this.grid.options.column[0];
    let renderFn, renderCls, text, renderText, defaultIconCls, title = "";
    if (record.get("__isGroup")) {
      renderFn = this.options.renderer;
      text = record.get(this.options.treeField);
      defaultIconCls = record.get("__isExpanded") ? getTreeFoldExpandCls() : getTreeFoldCls();
      renderCls = icon ? "" : this.options.hiddenIcon ? "" : defaultIconCls;
    } else {
      renderFn = firstFieldCol.renderer;
      text = record.get(firstFieldCol.dataIndex);
      renderCls = icon ? "" : this.options.hiddenIcon ? "" : getTreeLeafCls();
    }
    if (firstFieldCol.ceilTip) {
      if (firstFieldCol.ceilTip === true) {
        title = Format.htmlDoubleEncode(text);
      } else if (typeof firstFieldCol.ceilTip === "function") {
        title = Format.htmlTextEncode(firstFieldCol.ceilTip.call(this, text, record, row));
      }
    }
    if (typeof renderFn === "function") {
      renderText = renderFn.call(this.grid, text, record, row);
    } else {
      renderText = '<div data-hint="' + title + '" class="ellipsis ' + renderCls + '" data-index="' + (firstFieldCol.dataIndex || "") + '" data-column-id="' + firstFieldCol.id + '">' + Format.htmlTextEncode(text) + "</div>";
    }
    return renderText;
  },
  getTreeStoreCount: function() {
    const dataHash = this.grid.store.dataHash, dataList = this.grid.store.dataList;
    let count = 0, key, record;
    for (let i = 0, len = dataList.length; i < len; i++) {
      key = dataList[i];
      record = dataHash[key];
      if (this.checkIsVisible(record)) {
        count++;
      }
      i += this.getRecordRealLen.call(this, record) - 1;
    }
    return count;
  },
  initStoreDataHash: function(data) {
    const store = this.grid.store;
    const ignoreItemFn = this.options.ignoreItemFn;
    let newData = [];
    if ($.isFunction(ignoreItemFn)) {
      const filterMap = {};
      const uuidMap = {};
      data.forEach(function(item) {
        const uuid2 = item.__uuid;
        const pid = item.__parent;
        const isIgnore = filterMap[uuid2] || filterMap[pid] || ignoreItemFn(item);
        uuidMap[uuid2] = item;
        if (!isIgnore) {
          newData.push(item);
          return;
        }
        filterMap[uuid2] = true;
        if (!filterMap[pid] && uuidMap[pid]) {
          const pChildren = uuidMap[pid].__children || [];
          const cIndex = pChildren.indexOf(uuid2);
          pChildren.splice(cIndex, 1);
        }
      });
    } else {
      newData = data;
    }
    store.initDataHash(newData);
  },
  loadData: function(data) {
    const treeField = this.options.treeField, childrenField = this.options.childrenField, store = this.grid.store, d = $.isArray(data) && $.extend(true, [], data) || [];
    let treeData = [];
    this.orgTreeData = $.extend(true, [], d);
    this.orgData = d;
    this.loaded = true;
    store.jsonData = apply(store.setRootData(d), store.jsonData || {});
    if (this.options.needRoot && !this.justShowLeaves && d.length) {
      treeData[0] = {};
      treeData[0].id = privateRootId;
      treeData[0][treeField] = this.options.rootText;
      treeData[0][childrenField] = d;
    } else {
      treeData = d;
    }
    this.initLoadedNodeSet();
    this.initStoreDataHash(this.getInitTreeData(treeData));
    this.orgDataHash = $.extend(true, {}, this.grid.store.dataHash);
    this.orgDataList = $.extend(true, [], this.grid.store.dataList);
    if (this.justShowLeaves) {
      this.loadLeavesData();
    }
  },
  loadTreeData: function(data) {
    const store = this.grid.store;
    const d = data || [];
    store.jsonData = apply(store.setRootData(d), store.jsonData || {});
    this.initStoreDataHash(d);
  },
  loadLeavesData: function() {
    let _data = this.getTreeLeavesData();
    const options = this.options;
    if (options.autoSortLeaf) {
      _data = this.sortTreeData({
        treeData: _data,
        direction: options.autoSortdirect
      });
    }
    this.loadTreeData(_data);
  },
  sortTreeData: function(params) {
    const me = this, grid = me.grid, options = me.options, treeField = options.treeField, childrenField = options.childrenField, treeData = params.treeData, direction = params.direction, sortFn = params.sortFn, treeFieldColumn = me.getTreeFieldColumnData();
    function getSortData(d) {
      const groupList = [], leafList = [];
      d.forEach(function(item) {
        if (item[childrenField] && item[childrenField].length) {
          groupList.push(item);
        } else {
          leafList.push(item);
        }
      });
      if (me.needSortGroup) {
        localSortFn(groupList, treeField, direction, options.groupSortFn, grid);
      }
      if (me.needSortLeaf) {
        localSortFn(leafList, treeField, direction, sortFn || treeFieldColumn && treeFieldColumn.sortFn, grid);
      }
      groupList.forEach(function(item) {
        item[childrenField] = getSortData(item[childrenField]);
      });
      return groupList.concat(leafList);
    }
    return getSortData(treeData);
  },
  getTreeFieldColumnData: function() {
    let ret = {};
    const treeField = this.options.treeField;
    this.grid.options.column.forEach(function(column) {
      if (column.dataIndex === treeField) {
        ret = column;
      }
    });
    return ret;
  },
  getTreeRange: function(start, limit) {
    const store = this.grid.store, dataHash = store.dataHash, dataList = store.dataList, ret = [];
    let realStart = 0, key, record;
    if (!dataList || !dataList.length) {
      return ret;
    }
    while (start > 0) {
      key = dataList[realStart];
      record = dataHash[key];
      realStart += this.getRecordRealLen.call(this, record);
      if (this.checkIsVisible(record)) {
        start--;
      }
    }
    for (let i = realStart, len = dataList.length; i < len; i++) {
      key = dataList[i];
      record = dataHash[key];
      i += this.getRecordRealLen.call(this, record) - 1;
      if (this.checkIsVisible(record)) {
        ret.push(record);
      }
      if (ret.length === limit) {
        break;
      }
    }
    return ret;
  },
  getTreeLeavesData: function() {
    const dataList = this.grid.store.dataList, dataHash = this.grid.store.dataHash, leavesData = [];
    let record;
    for (let i = 0, len = dataList.length; i < len; i++) {
      record = dataHash[dataList[i]];
      if (!record.get("__isGroup")) {
        record.set("__level", 0);
        leavesData.push(record.data);
      }
    }
    return leavesData;
  },
  bindGridEvent: function() {
    const me = this, grid = this.grid, store = grid.store;
    this.grid.on(
      gridEvent.afterRender,
      function() {
        this.grid.gridEl.addClass(getPrefixedClassName("sfis-grid-tree")).addClass(getPrefixedClassName("sfis-grid--no-column-border"));
        if (this.options.needToggleIcon) {
          insertToggleToHeader.call(this, {
            collapseFn: this.collapseAll.bind(this, this.options.includeRoot),
            expandFn: this.expandAll.bind(this),
            autoExpandAll: this.options.autoExpandAll
          });
        }
        if (this.options.treeBgTheme) {
          this.grid.gridEl.addClass(this.options.treeBgTheme);
        }
        if (me.options.hideCheckbox) {
          me.grid.gridEl.find("." + headerCheckCls).closest("td").remove();
        }
        if (!me.options.hiddenTreeArw) {
          grid.gridEl.delegate("." + this.options.treeArwCls, "click", function() {
            const key = Format.htmlDecode($(this).closest("tr").data("id"));
            const isExpanded = store.dataHash[key].get("__isExpanded");
            if (isExpanded) {
              me.collapse(key, { silent: true });
            } else {
              me.expand(key, { silent: true });
            }
            me.emit(treeEvent.handToggleGroup, me._getToggleEventParams(!isExpanded, key));
          });
        }
        if (me.options.hasMenu) {
          grid.gridEl.delegate("." + M_TREE_ITEM_MENU_CLS, "click", function(e) {
            const $treeGroupRow = $(e.target).parents("." + treeGroupRowCls), key = Format.htmlDecode($treeGroupRow.data("id")), record = store.dataHash[key];
            me.emit(treeEvent.treeMenuClick, e, record);
          });
        }
        grid.gridEl.on("mouseenter", "." + treeGroupRowCls + ",." + itemRowCls, function(e) {
          e.stopPropagation();
          const key = Format.htmlDecode($(e.currentTarget).data("id")), record = store.dataHash[key];
          me.emit(treeEvent.treeItemHover, e, record);
        });
        grid.gridEl.delegate("." + treeGroupRowCls, "click", function(e) {
          const $target = $(e.target);
          if ($target.is("." + me.options.treeArwCls)) {
            return;
          }
          const $treeGroupRow = $target.parents("." + treeGroupRowCls), key = Format.htmlDecode($treeGroupRow.data("id"));
          me.treeGroupClickhandler(key);
        });
      },
      this
    );
    me.grid.on(`${gridEvent.search} ${gridEvent.searchInput}`, function(value) {
      me.search(value);
    });
    me.grid.on(gridEvent.searchEnd, function() {
      me.endSearch();
    });
  },
  treeGroupClickhandler: function(key) {
    const me = this, store = this.grid.store, record = store.dataHash[key];
    if (me.checkIsSelectAble(record) === false || me.checkIsDisabled(record)) {
      return;
    }
    if (me.ra && me.options.radioCanSelectGroup) {
      me.ra.getSelections().forEach(function(r) {
        r.selected = false;
      });
      record.selected = true;
      if (me.ra.options.silentSelect) {
        me.clearSelectedCls();
        me.setSelectedClsById(key);
      } else {
        me.grid.renderView();
        me.updateHeaderState();
      }
      me.ra.emit(radioSelectionEvent.select, record);
      me.ra.emit(radioSelectionEvent.change, me.ra, me.ra.getSelections());
      return;
    }
    if (me.cs) {
      record.selected = !record.selected;
      if (!me.options.isSelectAlone) {
        me.setChildrenSelected(record);
        me.setParentSelected(record);
      } else if (me.options.isSelectAlone === "child") {
        me.setChildrenSelected(record);
      }
      me.grid.renderView();
      me.cs.emit(record.selected ? checkSelectionEvent.select : checkSelectionEvent.unselect, record);
      me.cs.emit(checkSelectionEvent.change, me.cs, me.cs.getSelections());
      me.updateHeaderState();
    }
  },
  bindStoreEvent: function() {
    const me = this, options = this.options;
    let hasSetExpand = false, _data;
    me.grid.store.on(storeEvent.load, function() {
      if (me.justShowLeaves) {
        me.loadLeavesData();
      } else if (options.autoSortGroup || options.autoSortLeaf) {
        _data = me.sortTreeData({
          treeData: me.orgData,
          direction: options.autoSortdirect
        });
        me.loadData(_data);
      }
    });
    me.grid.store.on(storeEvent.dataChange, function() {
      if (me.options.autoExpandAll && !hasSetExpand) {
        hasSetExpand = true;
        me.expandBy(me.options.autoExpandAll);
      }
    });
    if (this.ra && (!options.radioCanSelectGroup || $.isFunction(options.selectAbleFn))) {
      me.grid.store.on(storeEvent.beforeDataChange, function(store, rs) {
        rs.forEach(function(r) {
          if (!options.radioCanSelectGroup) {
            if ($.isFunction(options.selectAbleFn)) {
              r.selectAble = options.selectAbleFn.call(me, r);
            }
            if (r.get("__isGroup")) {
              r.selectAble = false;
            }
          } else if ($.isFunction(options.selectAbleFn)) {
            r.selectAble = options.selectAbleFn.call(me, r);
          }
        });
      });
    }
    if (this.cs && this.cs.options.checkboxInTreeField && $.isFunction(options.selectAbleFn)) {
      me.grid.store.on(storeEvent.beforeDataChange, function(store, rs) {
        rs.forEach(function(r) {
          if ($.isFunction(options.selectAbleFn)) {
            r.selectAble = options.selectAbleFn.call(me, r);
          }
        });
      });
    }
  },
  bindSelectionEvent: function() {
    const cs = this.cs, ra = this.ra;
    if (ra) {
      if (this.options.radioCanSelectGroup) {
        ra.on(
          radioSelectionEvent.beforeSelect,
          function(record) {
            this.ra.getSelections().forEach(function(r) {
              r.selected = false;
            });
            record.selected = true;
            this.grid.renderView();
            ra.emit(record.selected ? radioSelectionEvent.select : radioSelectionEvent.unselect, record);
            ra.emit(radioSelectionEvent.change, ra, ra.getSelections());
            return false;
          },
          this
        );
      }
      return;
    }
    if (cs && !this.options.isSelectAlone) {
      cs.on(
        checkSelectionEvent.beforeSelect,
        function(record) {
          if (this.checkIsDisabled(record)) {
            return false;
          }
          record.selected = !record.selected;
          if (!this.justShowLeaves) {
            this.setParentSelected(record);
          }
          this.grid.renderView();
          cs.emit(record.selected ? checkSelectionEvent.select : checkSelectionEvent.unselect, record);
          cs.emit(checkSelectionEvent.change, cs, cs.getSelections());
          return false;
        },
        this
      );
    }
  },
  bindScrollEvent: function() {
    if (!this.options.hasMenu || !this.options.autoScrollX) {
      return;
    }
    this.grid.on(
      gridEvent.scrollXscroll,
      function() {
        this.menuLeftOffset = this.grid.viewEl.scrollLeft() + this.grid.bodyEl.innerWidth() - this.grid.options.scrollWidth - TREE_MENU_WIDTH;
        this.grid.bodyEl.find(".tree-item-menu-btn").css("left", this.menuLeftOffset + "px");
      },
      this
    );
  },
  setStatusClsById: function(id, statusCls) {
    this.grid.gridEl.find('[data-id="' + id + '"]').removeClass(getPrefixedClassName(itemPartSelectedCls)).removeClass(getPrefixedClassName(itemSelectedCls)).addClass(statusCls);
  },
  setSelectedClsById: function(id) {
    this.grid.gridEl.find('[data-id="' + id + '"]').addClass(getPrefixedClassName(itemSelectedCls));
  },
  clearSelectedCls: function() {
    this.grid.gridEl.find("[data-id]").removeClass(getPrefixedClassName(itemPartSelectedCls)).removeClass(getPrefixedClassName(itemSelectedCls));
  },
  setParentSelected: function(record) {
    let parent = record.get("__parent"), parentRecord, parentSelectedCls;
    const dataHash = this.grid.store.dataHash;
    while (parent) {
      parentRecord = dataHash[parent];
      parentRecord.selected = false;
      parentSelectedCls = SELECT_STATUS_MAP[this.getRecordSelectStatus(parent)];
      parentRecord.selected = parentSelectedCls === itemSelectedCls;
      parent = parentRecord.get("__parent");
    }
  },
  setChildrenSelected: function(record, force) {
    const me = this, dataHash = this.grid.store.dataHash, children = record.get("__children"), isSelected = record.selected;
    let childRecord;
    if (children && children.length) {
      children.forEach(function(child) {
        childRecord = dataHash[child];
        if (me.checkIsSelectAble(childRecord) === false || !force && me.checkIsDisabled(childRecord)) {
          return;
        }
        if (!me.checkIsVisible(childRecord)) {
          return;
        }
        childRecord.selected = isSelected;
        if (childRecord.get("__isGroup")) {
          me.setChildrenSelected(childRecord);
        }
      });
    }
  },
  setParentsExpandedById: function(id) {
    const dataHash = this.grid.store.dataHash, expandedMap = this.expandedMap;
    let record = dataHash[id], parentId;
    while (record && record.get("__parent")) {
      parentId = record.get("__parent");
      expandedMap[parentId] = true;
      record = dataHash[parentId];
    }
  },
  setParentsLoadingById: function(id, state) {
    const dataHash = this.grid.store.dataHash;
    let record = dataHash[id], parentId;
    while (record && record.get("__parent")) {
      parentId = record.get("__parent");
      this.updateLoadingMap(parentId, state);
      record = dataHash[parentId];
    }
  },
  updateHeaderState: function() {
    if (!this.grid.gridEl) {
      return;
    }
    const me = this, dataHash = this.grid.store.dataHash, $header = this.grid.gridEl.find("." + headerCheckCls), records = [];
    let hasSelected = false, hasUnselected = false, record, isVisble, isSelectAble;
    for (const key in dataHash) {
      if (dataHash.hasOwnProperty(key)) {
        records.push(dataHash[key]);
      }
    }
    const usefulRecords = records.filter(function(r) {
      isVisble = me.checkIsVisible(r);
      isSelectAble = me.checkIsSelectAble(r);
      return isVisble && isSelectAble;
    });
    for (let i = 0, len = usefulRecords.length; i < len; i++) {
      record = usefulRecords[i];
      hasUnselected = hasUnselected || !me.checkIsSelected(record);
      hasSelected = hasSelected || me.checkIsSelected(record);
      if (hasUnselected && hasSelected) {
        break;
      }
    }
    $header.removeClass(getPrefixedClassName(headerCheckAllCls) + " " + getPrefixedClassName(headerCheckPartCls));
    if (hasSelected && hasUnselected) {
      $header.addClass(getPrefixedClassName(headerCheckPartCls));
    } else if (hasSelected) {
      $header.addClass(getPrefixedClassName(headerCheckAllCls));
    }
  },
  selectAll: function(force) {
    const me = this, checkPlugin = this.cs || this.ra, dataHash = this.grid.store.dataHash;
    let record, isVisible, isSelectAble;
    for (const key in dataHash) {
      if (dataHash.hasOwnProperty(key)) {
        record = dataHash[key];
        isVisible = me.checkIsVisible(record);
        isSelectAble = me.checkIsSelectAble(record);
        if (!isSelectAble || !isVisible || !force && me.checkIsDisabled(record)) {
          continue;
        }
        record.selected = true;
      }
    }
    const checkPluginEvent = this.cs ? checkSelectionEvent : radioSelectionEvent;
    checkPlugin.emit(checkPluginEvent.selectAll);
    checkPlugin.emit(checkPluginEvent.change, checkPlugin, checkPlugin.getSelections());
    if (this.grid.rendered) {
      this.grid.renderView();
    }
  },
  unSelectAll: function(force, clearAll) {
    const me = this, checkPlugin = this.cs || this.ra, dataHash = this.grid.store.dataHash;
    let record, isVisible, isSelectAble;
    for (const key in dataHash) {
      if (dataHash.hasOwnProperty(key)) {
        record = dataHash[key];
        isVisible = me.checkIsVisible(record);
        isSelectAble = me.checkIsSelectAble(record);
        if (clearAll) {
          record.selected = false;
          continue;
        }
        if (!isSelectAble || !isVisible || !force && me.checkIsDisabled(record)) {
          continue;
        }
        record.selected = false;
      }
    }
    const checkPluginEvent = this.cs ? checkSelectionEvent : radioSelectionEvent;
    checkPlugin.emit(checkPluginEvent.unselectAll);
    checkPlugin.emit(checkPluginEvent.change, checkPlugin, checkPlugin.getSelections());
    if (this.grid.rendered) {
      this.grid.renderView();
    }
  },
  getRecordSelectStatus: function(key) {
    const me = this, dataHash = me.grid.store.dataHash, record = dataHash[key];
    let status = selectStatus.unselect, hasSelectedLeaf = false, hasUnSelectedLeaf = false;
    if (me.checkIsSelectAble(record) !== false) {
      if (me.ra || me.options.isSelectAlone || !record.get("__isGroup")) {
        status = record.selected ? selectStatus.select : selectStatus.unselect;
      } else {
        hasSelectedLeaf = me.checkHasSelectedLeaf(record);
        hasUnSelectedLeaf = me.checkHasUnSelectedLeaf(record);
        if (me.options.partialSelect) {
          if (record.selected) {
            return selectStatus.select;
          }
          if (hasSelectedLeaf) {
            status = selectStatus.partSelect;
          }
        } else {
          if (hasSelectedLeaf && hasUnSelectedLeaf) {
            status = selectStatus.partSelect;
          } else if (hasSelectedLeaf) {
            status = selectStatus.select;
          }
        }
      }
    }
    return status;
  },
  checkIsSelected: function(record) {
    const me = this;
    record = me.transformRecord(record)[0];
    if (!record) {
      return false;
    }
    return me.getRecordSelectStatus(record.get(me.idProperty)) === selectStatus.select;
  },
  getSelections: function() {
    const ret = [];
    let r;
    for (const key in this.grid.store.dataHash) {
      if (this.grid.store.dataHash.hasOwnProperty(key)) {
        r = this.grid.store.dataHash[key];
        if (r.selected && r.selectAble !== false && key !== privateRootId) {
          ret.push(r);
        }
      }
    }
    return ret;
  },
  getChildrenSelections: function() {
    return this.getSelections().filter(function(record) {
      return !record.get("__isGroup");
    });
  },
  doParentsSelect: function(record) {
    if (this.justShowLeaves) {
      return;
    }
    const dataHash = this.grid.store.dataHash;
    if (typeof record === "string" || typeof record === "number") {
      record = dataHash[record];
    }
    this.setParentSelected(record);
    this.grid.renderView();
  },
  doChildrenSelect: function(record) {
    if (this.justShowLeaves) {
      return;
    }
    const dataHash = this.grid.store.dataHash;
    if (typeof record === "string" || typeof record === "number") {
      record = dataHash[record];
    }
    if (!record.get("__isGroup")) {
      return;
    }
    this.setChildrenSelected(record);
    this.grid.renderView();
  },
  expand: function(id, option) {
    const isNodeLoaded = this.nodeHaveLoaded(id);
    if (this.options.stepLoad && this.options.shouldLoadNodeChildren(this.orgDataHash[id], isNodeLoaded)) {
      this.updateLoadingMap(id, true);
      this.refresh();
      this.emit(treeEvent.expand, this, id, this.orgDataHash[id], this.idProperty);
      this.expandedMap[id] = true;
      if (!(option == null ? void 0 : option.silent)) {
        this.emit(treeEvent.fnToggleGroup, this._getToggleEventParams(true, id));
      }
      return;
    }
    this.expandedMap[id] = true;
    if (!(option == null ? void 0 : option.silent)) {
      this.emit(treeEvent.fnToggleGroup, this._getToggleEventParams(true, id));
    }
    this.refresh();
  },
  updateLoadingMap: function(id, state) {
    this.loadingMap[id] = state;
  },
  updateTreeNodeData: function(nodeId, data) {
    const orgData = $.extend(true, [], this.orgTreeData);
    const newData = this.insertTreeNodeData(orgData, nodeId, data);
    this.loadData(newData);
  },
  batchUpdateTreeNodeData: function(data) {
    const me = this, orgData = $.extend(true, [], this.orgTreeData);
    data.forEach((item) => {
      const { id, children } = item;
      me.insertTreeNodeData(orgData, id, children);
    });
    this.loadData(orgData);
  },
  insertTreeNodeData: function(treeData, nodeId, data) {
    const me = this, idProperty = this.idProperty, childrenField = me.options.childrenField;
    const cascadeCallback = (record) => {
      var _a;
      const recordId = (_a = record[idProperty]) != null ? _a : record.id;
      if (recordId !== nodeId) {
        return;
      }
      record[childrenField] = data;
      return false;
    };
    cascadeTree(treeData, cascadeCallback, childrenField);
    this.updateLoadingMap(nodeId, false);
    this.storeLoadedNode(nodeId);
    return treeData;
  },
  expandTo: function(ids, isExpandMe) {
    const me = this;
    ids = $.makeArray(ids).map(function(id) {
      return typeof id === "object" ? id.get(me.idProperty) : id;
    });
    ids.forEach(function(id) {
      me.setParentsExpandedById(id);
      if (isExpandMe === true) {
        me.expandedMap[id] = true;
      }
    });
    me.refresh();
  },
  expandBy: function(options) {
    const me = this, store = me.grid.store, dataHash = store.dataHash;
    let allKeys = Object.keys(dataHash);
    options = options || {};
    if (!options.filter && options.hasOwnProperty("level")) {
      options.filter = function(item) {
        return item.get("__level") === options.level;
      };
    }
    if (options.filter) {
      allKeys = allKeys.filter(function(id) {
        return options.filter(dataHash[id]);
      });
    }
    me.expandTo(allKeys, true);
  },
  loadingTo: function(ids, state) {
    const me = this;
    ids = $.makeArray(ids).map(function(id) {
      return typeof id === "object" ? id.get(me.idProperty) : id;
    });
    ids.forEach(function(id) {
      me.setParentsLoadingById(id, state);
      me.updateLoadingMap(id, state);
    });
    me.refresh();
  },
  collapse: function(id, option) {
    this.expandedMap[id] = false;
    if (!(option == null ? void 0 : option.silent)) {
      this.emit(treeEvent.fnToggleGroup, this._getToggleEventParams(false, id));
    }
    this.refresh();
  },
  expandAll: function(option) {
    const expandedMap = this.expandedMap;
    this.grid.store.dataList.forEach(function(item) {
      expandedMap[item] = true;
    });
    if (!(option == null ? void 0 : option.silent)) {
      this.emit(treeEvent.fnToggleAllGroup, this._getToggleEventParams(true));
    }
    this.refresh();
  },
  setItemActive: function(uuid2) {
    this.treeGroupClickhandler(uuid2);
  },
  setItemInactive: function() {
    const firstItemRecord = this.getFirstItemRecord();
    if (!firstItemRecord || !firstItemRecord.get("__uuid")) {
      return;
    }
    const uuid2 = firstItemRecord.get("__uuid");
    this.setItemActive(uuid2);
  },
  getItemRecord: function(uuid2) {
    return uuid2 && this.grid.store.dataHash[uuid2] || false;
  },
  getFirstItemRecord: function() {
    const store = this.grid.store, dataList = this.grid.store.dataList;
    if (!dataList.length) {
      return false;
    }
    return store.dataHash[dataList[0]] || false;
  },
  expandNthDeep: function(deep) {
    deep = Number(deep);
    if (isNaN(deep) || deep < 0) {
      return;
    }
    const dataHash = this.grid.store.dataHash;
    for (const key in dataHash) {
      if (!dataHash.hasOwnProperty(key)) {
        continue;
      }
      const record = dataHash[key];
      if (record.get("__level") <= deep) {
        this.expandedMap[key] = true;
      }
    }
    this.refresh();
  },
  collapseAll: function(includeRoot, option) {
    this.expandedMap = {};
    if (includeRoot !== true) {
      this.expandedMap[privateRootId] = true;
    }
    if (!(option == null ? void 0 : option.silent)) {
      this.emit(treeEvent.fnToggleAllGroup, this._getToggleEventParams(false));
    }
    this.refresh();
  },
  addVisibleRecord: function(record, options) {
    const me = this, dataHash = this.grid.store.dataHash, id = record.get(this.idProperty);
    if (!me.justShowLeaves) {
      setParentVisibleById(id);
    }
    me.visibleRecords[id] = true;
    const showChildren = !options || options.showChildren !== false;
    if (record.get("__isGroup") && showChildren) {
      setChildrenVisibleById(id);
    }
    function setParentVisibleById(id2) {
      let record2 = dataHash[id2], parentId;
      while (record2.get("__parent")) {
        parentId = record2.get("__parent");
        me.visibleRecords[parentId] = true;
        record2 = dataHash[parentId];
      }
    }
    function setChildrenVisibleById(id2) {
      const record2 = dataHash[id2], children = record2.get("__children");
      let childRecord;
      children.forEach(function(child) {
        childRecord = dataHash[child];
        me.visibleRecords[child] = true;
        if (childRecord.get("__isGroup")) {
          setChildrenVisibleById(child);
        }
      });
    }
  },
  initVisibleRecords: function() {
    const me = this, dataList = this.grid.store.dataList;
    me.visibleRecords = {};
    dataList.forEach(function(key) {
      me.visibleRecords[key] = true;
    });
  },
  clearVisibleRecords: function() {
    const me = this, dataList = this.grid.store.dataList;
    dataList.forEach(function(key) {
      me.visibleRecords[key] = false;
    });
  },
  search: function(str, options) {
    str = $.trim(str || "");
    if (!str) {
      this.endSearch();
      return;
    }
    if (this.showAll) {
      this.oldExpandedMap = $.extend(true, {}, this.expandedMap);
    }
    this.collapseAll();
    const me = this, dataHash = this.grid.store.dataHash, treeField = this.options.treeField, searchOpt = $.extend(
      {
        includeGroup: false,
        matchCase: false
      },
      me.options.search,
      options
    );
    let nodeName, record;
    str = Format.escapeRegex(str);
    const strReg = searchOpt.matchCase ? new RegExp(str) : new RegExp(str.toUpperCase());
    this.showAll = false;
    this.clearVisibleRecords();
    for (const key in dataHash) {
      if (!dataHash.hasOwnProperty(key)) {
        continue;
      }
      record = dataHash[key];
      nodeName = record.get(treeField) || "";
      nodeName = searchOpt.matchCase ? nodeName : nodeName.toUpperCase();
      if (!strReg.test(nodeName) || record.get("id") === privateRootId) {
        continue;
      }
      if (!searchOpt.includeGroup && record.get("__isGroup")) {
        continue;
      }
      this.addVisibleRecord(record, searchOpt);
      if (record.get("__isGroup")) {
        me.expandedMap[key] = false;
      }
      if (!me.justShowLeaves) {
        me.setParentsExpandedById(key);
      }
    }
    this.refresh();
    const isEmpty = Object.keys(this.visibleRecords).every(function(id) {
      return !me.visibleRecords[id];
    });
    if (isEmpty) {
      this.grid.showInfo($i("scp.vt_component.common.widget.Grid.plugins.Tree.empty_data"));
    }
  },
  clearSearch: function() {
    this.showAll = true;
  },
  endSearch: function() {
    const me = this;
    Object.keys(me.oldExpandedMap || {}).forEach(function(id) {
      if (me.oldExpandedMap[id]) {
        me.expandedMap[id] = true;
      }
    });
    me.oldExpandedMap = null;
    me.grid.tbarEl.find(".grid-search-input").val("");
    me.clearSearch();
    me.refresh();
  },
  filter: function(records, toBeShow) {
    if (this.orgDataList) {
      this.doFilter({
        records,
        toBeShow
      });
    }
  },
  endFilter: function() {
    if (this.orgDataList) {
      this.doFilter({
        records: this.orgDataList
      });
    }
  },
  filterGroup: function(groups, toBeShow) {
    this.doFilter({
      records: groups,
      toBeShow,
      isFilterGroup: true
    });
  },
  doFilter: function(options) {
    const orgDataList = this.orgDataList, orgDataHash = this.orgDataHash, idProperty = this.idProperty, childrenField = this.options.childrenField, filterKeys = this.getFilterKeys(options), rootBrothers = [];
    let filterData = [], key, brothers;
    for (let i = 0, len = orgDataList.length; i < len; i++) {
      key = orgDataList[i];
      if (filterKeys.indexOf(key) > -1) {
        filterData.push(orgDataHash[key].data);
      }
    }
    if (this.justShowLeaves) {
      filterData = filterData.filter(function(item) {
        return !item.__isGroup;
      });
    } else {
      filterData.forEach(function(item) {
        if (!item.__parent) {
          rootBrothers.push(item[idProperty]);
        }
      });
      filterData.forEach(function(item) {
        if (item.__parent) {
          brothers = orgDataHash[item.__parent].get("__children");
          item.__isLast = brothers.indexOf(item[idProperty]) === brothers.length - 1;
        } else {
          item.__isLast = rootBrothers.indexOf(item[idProperty]) === rootBrothers.length - 1;
        }
        item.__children = [];
        if (item[childrenField] && item[childrenField].length) {
          item[childrenField].forEach(function(childData) {
            if (filterKeys.indexOf(childData[idProperty]) > -1) {
              item.__children.push(childData[idProperty]);
            }
          });
        }
      });
    }
    this.loadTreeData(filterData);
  },
  getFilterKeys: function(options) {
    const idProperty = this.idProperty, orgDataList = this.orgDataList, orgDataHash = this.orgDataHash, recordKeys = this.grid.store.getAllKeys(options.records), filterKeys = [];
    let key, record;
    function shouldPushInFilter(r) {
      if (options.toBeShow !== false) {
        return recordKeys.indexOf(r.get(idProperty)) !== -1;
      } else {
        return recordKeys.indexOf(r.get(idProperty)) === -1;
      }
    }
    function pushParents(r) {
      const parentKey = r.get("__parent");
      if (parentKey) {
        pushParents(orgDataHash[parentKey]);
        if (filterKeys.indexOf(parentKey) === -1) {
          filterKeys.push(parentKey);
        }
      }
    }
    function pushChildren(r) {
      const children = r.get("__children");
      let childRecord;
      children.forEach(function(child) {
        childRecord = orgDataHash[child];
        if (filterKeys.indexOf(child) === -1) {
          filterKeys.push(child);
          if (childRecord.get("__isGroup")) {
            pushChildren(childRecord);
          }
        }
      });
    }
    for (let i = 0, len = orgDataList.length; i < len; i++) {
      key = orgDataList[i];
      record = orgDataHash[key];
      if (!shouldPushInFilter(record)) {
        continue;
      }
      pushParents(record);
      filterKeys.push(key);
      if (options.isFilterGroup === true) {
        pushChildren(record);
      }
    }
    return filterKeys;
  },
  transformRecord: function(records) {
    return this.grid.store.toModels(records);
  },
  setSelect: function(records, isSelected, options) {
    const me = this, checkPlugin = this.cs || this.ra, checkPluginEvent = this.cs ? checkSelectionEvent : radioSelectionEvent;
    if (typeof options === "boolean") {
      options = {
        force: options
      };
    }
    options = options || {};
    records = this.transformRecord(records);
    if (me.options.isSelectAlone) {
      records.forEach(function(item) {
        item.selected = isSelected;
        if (!options.noEvent) {
          checkPlugin.emit(isSelected ? checkPluginEvent.select : checkPluginEvent.unselect, item);
        }
      });
    } else {
      records.forEach(function(r) {
        if (me.checkIsSelectAble(r) === false || !options.force && me.checkIsDisabled(r)) {
          return;
        }
        r.selected = isSelected;
        if (r.get("__isGroup")) {
          me.setChildrenSelected(r, options.force);
        }
        if (!me.justShowLeaves) {
          me.setParentSelected(r);
        }
        if (!options.noEvent) {
          checkPlugin.emit(isSelected ? checkPluginEvent.select : checkPluginEvent.unselect, r);
        }
      });
    }
    if (!options.noEvent) {
      checkPlugin.emit(checkPluginEvent.change, checkPlugin, checkPlugin.getSelections());
    }
    me.grid.renderView();
  },
  setDisabled: function(records, disabled) {
    const me = this;
    disabled = typeof disabled === "undefined" ? true : disabled;
    records = this.transformRecord(this.grid.store.getKeys(records));
    records.forEach(function(record) {
      record.set("__disabled", disabled);
      me.setParentDisabled(record);
    });
  },
  dealWithOrgData: function(func) {
    const currentDataHash = this.grid.store.dataHash, currentDataList = this.grid.store.dataList;
    this.grid.store.dataHash = this.orgDataHash;
    this.grid.store.dataList = this.orgDataList;
    func();
    this.grid.store.dataHash = currentDataHash;
    this.grid.store.dataList = currentDataList;
  },
  setParentDisabled: function(record) {
    let parent = record.get("__parent"), parentRecord;
    const dataHash = this.grid.store.dataHash;
    while (parent) {
      parentRecord = dataHash[parent];
      parentRecord.set("__disabled", this.checkIsDisabled(parentRecord));
      parent = parentRecord.get("__parent");
    }
  },
  select: function(records, force) {
    this.setSelect(records, true, force);
  },
  unSelect: function(records, force) {
    this.setSelect(records, false, force);
  },
  getId: function() {
    return this.options.pluginId;
  },
  clearTree: function() {
    this.justShowLeaves = true;
    if (this.loaded) {
      this.loadLeavesData();
    }
  },
  groupTree: function() {
    this.justShowLeaves = false;
  },
  isGroupTree: function() {
    return !this.justShowLeaves;
  },
  showMenuBtn: function(target) {
    this.hideMenuBtn();
    $(target).addClass(getPrefixedClassName("active"));
  },
  hideMenuBtn: function() {
    $(this.grid.gridEl).find("." + M_TREE_ITEM_MENU_CLS + ".active").removeClass(getPrefixedClassName("active"));
  },
  refresh: function() {
    const dataHash = this.grid.store.dataHash, dataList = this.grid.store.dataList, expandedMap = this.expandedMap, loadingMap = this.loadingMap, newData = [];
    let record;
    dataList.forEach(function(item) {
      record = dataHash[item];
      if (record.get("__isGroup")) {
        record.set("__isExpanded", expandedMap[item] === true);
        record.set("__isLoading", loadingMap[item] === true);
      }
      newData.push(record.data);
    });
    this.loadTreeData(newData);
  },
  initLoadedNodeSet: function() {
    this.stepLoadedNode = /* @__PURE__ */ new Set();
  },
  nodeHaveLoaded(id) {
    return this.stepLoadedNode.has(id);
  },
  storeLoadedNode(id) {
    this.stepLoadedNode.add(id);
  },
  isGroupRecordHasChildren(record) {
    if (!record.get("__isGroup")) {
      return false;
    }
    const children = record.get("__children");
    const { hasChildrenFn, hasChildrenField, stepLoad } = this.options;
    if (children.length) {
      return true;
    }
    if (!stepLoad) {
      return false;
    }
    return typeof hasChildrenFn === "function" ? !!hasChildrenFn(record) : !!record.get(hasChildrenField);
  },
  _getToggleEventParams(expanded, id) {
    var _a;
    const params = { expanded };
    if (!Lang.isEmpty(id)) {
      params.node = (_a = this.orgDataHash[id]) == null ? void 0 : _a.data;
    }
    return params;
  },
  onDestroy: function() {
  },
  destroy: function() {
    this.clear();
    this.onDestroy();
    delete this.grid;
  }
});
Tree.pluginId = pluginId.tree;
Grid.SIZE_CONFIG = SIZE_CONFIG;
Grid.SIZE_LIST = SIZE_LIST;
export { Action, AutoRefresh, CheckSelection, Detail, FixedColumn, Group, Model, RadioGroupSelection, RadioSelection, Resizeable, Selection, Sortable, Store, Tree, Grid as default, event as gridEventName, pluginId as gridPluginId };
