import XTpl from '@sxf/er-lib/xtpl';
import { $i } from '@sxf/er-config';
var checkBoxTpl = `
<div class="sfis-form-item-checkbox">
    <tpl for="items">
        <label {[xindex === xcount ? '' : 'class="sfis-form-item-checkbox__label"']}>
            <input type="checkbox"
                   style-key="checkbox"
                   data-submit-name="{key}"
                   {[values.disabled ? "disabled" : ""]}
                   {[values.checked ? "checked" : ""]} >
            <span class="valign-middle">{label}</span>
        </label>
    </tpl>
</div>`;
var formTpl = `
<div class="sfis-form {cls}">
    <tpl for="items">
        <div class="sfis-form-item {cls}">
            {html}
        </div>
    </tpl>
</div>`;
var inputTpl = `
<input style-key="input"
       type="text"
       class="sfis-form-item-input {elemCls}"
       data-submit-name="{key}"
       placeholder="{placeholder}"
       value="{[values.value ? values.value : ""]}"
       {[values.disabled ? "disabled" : ""]}>
`;
var labelTpl = `
<label class="sfis-form-item-label {[values.labelPosition ? "sfis-form-item-label--" + values.labelPosition : "" ]}
    {[values.postLabel ? "sfis-form-item-post-label" : "" ]}">
    {label}{seperator}
</label>`;
var passwordTpl = `
<input style-key="input"
       type="password"
       class="sfis-form-item-input {elemCls}"
       data-submit-name="{key}"
       {[values.disabled ? "disabled" : ""]}>
`;
var radioTpl = `
<div class="sfis-form-item-radio">
    <tpl for="items">
        <label class="sfis-form-item-radio__label">
            <input type="radio"
                   style-key="radio"
                   name="{parent.key}"
                   value="{value}"
                   {[values.checked ? "checked" : ""]}>
            <span class="valign-middle">{label}</span>
        </label>
    </tpl>
</div>`;
var selectTpl = `
<select style-key="select"
        class="sfis-form-item-select {elemCls}"
        data-submit-name="{key}"
        {[values.disabled ? "disabled" : ""]}>
  <tpl for="options">
    <option class="{cls}" value="{value}">{text}</option>
  </tpl>
</select>
`;
var suffixTpl = `<span class="sfis-form-item-suffix">{suffix}</span>`;
var textareaTpl = `
<textarea style-key="textarea"
          class="sfis-form-item-textarea sfis-resize-none {elemCls}"
          data-submit-name="{key}"
          placeholder="{placeholder}"
          {[values.disabled ? "disabled" : ""]}></textarea>

`;
const M_FORM_XTPL = new XTpl(formTpl);
const M_LABEL_XTPL = new XTpl(labelTpl);
const M_INPUT_XTPL = new XTpl(inputTpl);
const M_TEXTAREA_XTPL = new XTpl(textareaTpl);
const M_PASSWORD_XTPL = new XTpl(passwordTpl);
const M_SELECT_XTPL = new XTpl(selectTpl);
const M_SUFFIX_XTPL = new XTpl(suffixTpl);
const M_RADIO_XTPL = new XTpl(radioTpl);
const M_CHCEKBOX_XTPL = new XTpl(checkBoxTpl);
function getItemHtml(item) {
  const ret = [];
  if (isDefined(item.label) && !isNull(item.label)) {
    const labelConfig = {
      label: item.label,
      seperator: item.label ? isDefined(item.seperator) ? item.seperator || "" : $i("scp.vt_component.common.widget.Form.seperator") : ""
    };
    if (["top", "bottom"].indexOf(item.labelPosition) > -1) {
      labelConfig.labelPosition = item.labelPosition;
    }
    ret.push(M_LABEL_XTPL.apply(labelConfig));
  }
  switch (item.type) {
    case "input":
      ret.push(M_INPUT_XTPL.apply(item));
      break;
    case "password":
      ret.push(M_PASSWORD_XTPL.apply(item));
      break;
    case "select":
      ret.push(M_SELECT_XTPL.apply(item));
      break;
    case "radio":
      ret.push(M_RADIO_XTPL.apply(item));
      break;
    case "checkbox":
      ret.push(M_CHCEKBOX_XTPL.apply(item));
      break;
    case "textarea":
      ret.push(M_TEXTAREA_XTPL.apply(item));
      break;
    case "html":
      ret.push(item.html);
      break;
  }
  if (item.suffix) {
    ret.push(
      M_SUFFIX_XTPL.apply({
        suffix: item.suffix
      })
    );
  }
  return ret.join("");
}
function isDefined(v) {
  return typeof v !== "undefined";
}
function isNull(v) {
  return v === null;
}
function create(opt) {
  if (!opt || !opt.items || !opt.items.length) {
    return;
  }
  const rd = {
    cls: opt.cls || "",
    elemCls: opt.elemCls || ""
  };
  rd.items = opt.items.map(function(item) {
    if (!item || item.hidden) {
      return;
    }
    return {
      cls: item.cls || "",
      html: getItemHtml(item)
    };
  });
  rd.items = rd.items.filter(function(item) {
    return item;
  });
  return M_FORM_XTPL.apply(rd);
}
export { create };
