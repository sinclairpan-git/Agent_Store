import { globalConfig } from '@sxf/er-config';
import format from '@sxf/er-utils/format';
function setInputLimit($el, options) {
  var _a, _b, _c, _d;
  options = Object.assign(
    {
      useUTF8Len: (_b = (_a = globalConfig.search) == null ? void 0 : _a.useUTF8Len) != null ? _b : true,
      limit: (_d = (_c = globalConfig.search) == null ? void 0 : _c.limit) != null ? _d : 100
    },
    options
  );
  $el.off("input.input-limit").on("input.input-limit", function() {
    const value = $el.val();
    const limit = options.limit;
    let len = value.length;
    if (limit) {
      if (options.useUTF8Len) {
        len = format.utf8Length(value);
      }
      if (len > limit) {
        $el.val(format.limitString(value, limit, options.useUTF8Len));
      }
    }
  });
}
export { setInputLimit };
