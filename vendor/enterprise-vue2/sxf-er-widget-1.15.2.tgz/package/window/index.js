import $ from 'jquery';
import { $i } from '@sxf/er-config';
import { getPrefixedClassName } from '@sxf/er-feature';
import XTpl from '@sxf/er-lib/xtpl';
import Debug from '@sxf/er-utils/logger';
import Observable from '@sxf/er-utils/observable';
import oop from '@sxf/er-utils/oop';
import uuid from '@sxf/er-utils/uuid';
import { when } from '@sxf/er-utils/when';
import windowMgr from '@sxf/er-utils/window-mgr';
import getZIndex from '@sxf/er-utils/zindex';
import { hide } from '@sxf/er-widget/tooltip';
const getDefaultConfigs = () => ({
  size: "",
  width: "auto",
  height: "auto",
  autoHeight: false,
  autoMaxHeight: false,
  autoScroll: true,
  title: $i("scp.vt_component.common.widget.Window.win_title"),
  titleTip: true,
  autoMask: true,
  header: true,
  footer: true,
  closeable: true,
  tpl: null,
  body: "",
  verticalAlign: "",
  buttonAlign: "right",
  autoclose: false,
  cls: "",
  maskCls: "",
  overtop: null,
  autoDestroy: false,
  beforeHide: $.noop,
  beforeShow: $.noop,
  beforeClose: $.noop,
  utid: ""
});
const MINI_WIDTH = 1920;
function isMini(width) {
  const bodyWidth = window.screen.width;
  width = width || MINI_WIDTH;
  return bodyWidth < width;
}
var defaultTpl = `<div style="display: none;" id="{id}-mask" class="{[values.getPrefixedClassName('sfis-window-mask')]}"></div>
<div style="display: none;" id="{id}" class="{[values.getPrefixedClassName('sfis-window')]}">
    <div id="{id}-header" class="{[values.getPrefixedClassName('sfis-window-header')]}">
        <tpl if='values.titleTip'>
            <div class="{[values.getPrefixedClassName('title')]}" data-hint-pos="bc" data-tip="{titleTip}">{title}</div>
        <tpl else>
            <div class="{[values.getPrefixedClassName('title')]}">{title}</div>
        </tpl>
        <button type="button" class="iconfont vtv-icon-win-close {[values.getPrefixedClassName('btn-close')]}" action="cancel" utid="{[values.utidPrefix]}close"></button>
        <button style="display: none;" type="button" class="{[values.getPrefixedClassName('btn-help')]}" action="help" utid="{[values.utidPrefix]}help"></button>
    </div>
    <div id="{id}-body" class="{[values.getPrefixedClassName('sfis-window-body')]}">
        {body}
    </div>
    <div id="{id}-footer" class="{[values.getPrefixedClassName('sfis-window-footer')]} {[values.getPrefixedClassName('footer-align-' + values.buttonAlign)]} clearfix">
        <tpl for="buttons">
            <tpl if='values.type === "text"'>
                <span class="{[parent.getPrefixedClassName('txt')]} {[values.cls]}" action="{action}" id="{parent.id}-txt-{[values.__id]}">{[values.text]}</span>
            <tpl else>
                <button type="button" class="{[parent.getPrefixedClassName('btn')]} {[values.action ? parent.getPrefixedClassName('btn-' + values.action) : '']} {[values.cls]}"
                        id="{parent.id}-btn-{[values.__id]}" action="{action}" utid="{[parent.utidPrefix]}{action}">{[values.text]}</button>
            </tpl>
        </tpl>
    </div>
</div>`;
const Logger = Debug("window");
const SIZE_CLS_MAP = {
  large: "sfis-window-lg",
  wider: "sfis-window-wi",
  normal: "sfis-window-md",
  small: "sfis-window-sm"
};
const HTMLPattern = /<("[^"]*"|'[^']*'|[^'">])*>/;
const HEIGHT_INFO = {
  MINI_SCREEN_MAX_HEIGHT: 600,
  NORMAL_SCREEN_MAX_HEIGHT: 952,
  MARGIN_HEIGHT: 128,
  MIN_HEIGHT: 272
};
const Window = oop.extend(Observable, {
  constructor: function(options = {}) {
    const maxHeight = options.maxHeight || (isMini() ? HEIGHT_INFO.MINI_SCREEN_MAX_HEIGHT : HEIGHT_INFO.NORMAL_SCREEN_MAX_HEIGHT);
    const screenMaxHeight = document.body.clientHeight - HEIGHT_INFO.MARGIN_HEIGHT;
    if (screenMaxHeight > 0) {
      options.maxHeight = maxHeight > screenMaxHeight ? screenMaxHeight : maxHeight;
    }
    options.minHeight = options.minHeight ? options.minHeight : HEIGHT_INFO.MIN_HEIGHT;
    options.height = options.verticalAlign && !options.height ? options.minHeight : options.height;
    this.id = windowMgr.getNewId();
    this.options = $.extend(true, {}, getDefaultConfigs(), options);
    this.listeners = this.options.listeners;
    this.init();
    this.initEvent();
    Window.superclass.constructor.apply(this, arguments);
    windowMgr.add(this);
  },
  init: function() {
    if (!this.options.buttons) {
      this.options.buttons = [
        {
          text: $i("scp.vt_component.common.widget.Window.submit_btn"),
          action: "submit"
        },
        {
          text: $i("scp.vt_component.common.widget.Window.cancel_btn"),
          action: "cancel"
        }
      ];
    }
    this.hidden = true;
    this.isDestroyed = false;
    this.rendered = false;
    this.createTpl();
  },
  initEvent: function() {
    this.addEvents(
      "render",
      "afterrender",
      "beforeshow",
      "show",
      "beforehide",
      "hide",
      "beforedestroy",
      "destroy"
    );
  },
  createTpl: function() {
    let tpl = this.options.tpl;
    if (!tpl) {
      tpl = defaultTpl;
    }
    if (!(tpl instanceof XTpl)) {
      tpl = new XTpl(tpl);
    }
    this.options.tpl = tpl;
  },
  render: function() {
    var _a;
    const parent = $((_a = this.options.container) != null ? _a : document.body);
    const windowHtml = this.options.tpl.apply(this.getRenderData());
    parent.append($(windowHtml));
    this.rendered = true;
    this.emit("render", this);
    this.onRender();
    this.initOvertop();
    this.updateHtml();
    this.emit("afterrender", this);
    this.bindEvent();
  },
  initOvertop: function() {
    var _a;
    const $winParent = $((_a = this.options.container) != null ? _a : document.body);
    let $overtop = $(this.options.overtop);
    while ($overtop.length && $.contains($winParent[0], $overtop[0])) {
      this.$overtop = $overtop;
      $overtop = $overtop.offsetParent();
    }
    if (this.$overtop) {
      this.zIndex = Number(this.$overtop.css("z-index")) + 1;
    }
  },
  renderBody: function(html) {
    if (this.rendered) {
      this.bodyEl.html(html);
      this.updatePosition();
    } else {
      this.options.body = html;
    }
  },
  renderFooter: function(el) {
    if (this.rendered) {
      this.footerEl.html("").append(el);
      this.updatePosition();
    }
  },
  renderHeader: function(el) {
    if (this.rendered) {
      $(".title", this.headerEl).html("").append(el);
      this.updatePosition();
    }
  },
  getBodySel: function() {
    return this.bodyEl;
  },
  updateHtml: function() {
    let footer = this.options.footer;
    const body = this.options.body;
    let btnCls = "";
    this.winEl = $("#" + this.id);
    this.maskEl = $("#" + this.id + "-mask");
    this.headerEl = $("#" + this.id + "-header");
    this.bodyEl = $("#" + this.id + "-body");
    this.footerEl = $("#" + this.id + "-footer");
    if (this.options.header === false) {
      this.hideHeader();
    }
    const isBodyCenter = this.options.verticalAlign === "center";
    this.bodyEl.toggleClass(getPrefixedClassName("sfis-window-body--center"), isBodyCenter);
    if ($.isFunction(footer)) {
      footer = footer.call(this);
    }
    if (body === false) {
      this.hideBody();
    } else if (body !== true) {
      this.bodyEl.html("").append(body);
    }
    if (footer === false) {
      this.hideFooter();
    } else if (footer !== true) {
      this.footerEl.html("").append(footer);
    }
    if (this.options.autoMask === false) {
      this.hideMask();
    } else {
      this.maskEl.css({
        "z-index": this._getZIndex()
      });
    }
    if (this.options.closeable === false) {
      $(".btn-close", this.headerEl).hide();
    }
    if (this.options.btnCloseTheme !== "gray") {
      btnCls = getPrefixedClassName("btn-close--" + this.options.btnCloseTheme);
      $(".btn-close", this.headerEl).addClass(btnCls);
    }
    this.winEl.css({
      "z-index": this._getZIndex()
    });
    this.bodyEl.css({
      overflow: this.options.autoScroll ? "auto" : "hidden"
    });
    this.maskEl.addClass(this.options.maskCls);
    if (this.options.size) {
      this.winEl.addClass(getPrefixedClassName(SIZE_CLS_MAP[this.options.size] || ""));
    }
    this.winEl.addClass(this.options.cls);
    this.winEl.attr("utid", this.options.utid);
    if (this.options.showHelp) {
      this.headerEl.find("button[action=help]").show().attr("data-hint", this.options.showHelp);
    }
    this.updateWinSize();
  },
  bindEvent: function() {
    const me = this;
    this.winEl.delegate(".sfis-window-footer [action],.sfis-window-header [action]", "click", function() {
      const dom = $(this);
      if (dom.is(".btn-close")) {
        when(me.options.beforeClose()).then(function(result) {
          if (result === false) {
            return;
          }
          if (typeof me.options.cancelFn === "function") {
            me.options.cancelFn.call(me.options.scope || me);
          }
          me.hide();
        });
        return;
      }
      const action = dom.attr("action");
      if (action) {
        if (typeof me.options[action + "Fn"] === "function") {
          me.options[action + "Fn"].call(me.options.scope || me);
        }
        switch (action) {
          case "cancel":
            me.hide();
            break;
          case "submit":
            if (me.options.autoclose) {
              me.hide();
            }
            break;
        }
      }
    });
    this._autoSetHeight = this.autoSetHeight.bind(this);
    $(window).on("resize", this._autoSetHeight);
  },
  updateWinSize: function() {
    let h;
    if (this.rendered) {
      if (this.options.height === "auto") {
        if (this.options.width === "auto") {
          return;
        }
        this.options.width = parseInt(this.options.width, 10) || 0;
        this.winEl.css({
          width: this.options.width
        });
        return;
      }
      this.options.height = parseInt(this.options.height, 10) || 0;
      h = this.options.height;
      if (this.options.maxHeight) {
        this.options.maxHeight = parseInt(this.options.maxHeight, 10) || 0;
        h = Math.min(h, this.options.maxHeight);
      }
      if (this.options.minHeight) {
        this.options.minHeight = parseInt(this.options.minHeight, 10) || 0;
        h = Math.max(h, this.options.minHeight);
      }
      if (this.options.width === "auto") {
        this.winEl.css({
          height: h
        });
      } else {
        this.winEl.css({
          width: this.options.width,
          height: h
        });
      }
      this.updateBodySize();
      this.updatePosition();
      this.emit("resize");
    }
  },
  updatePosition: function() {
    let size;
    if (this.rendered) {
      size = this.winEl.get(0).getBoundingClientRect();
      this.winEl.css({
        "margin-left": size.width / -2,
        "margin-top": size.height / -2
      });
    }
  },
  updateBodySize: function() {
    var _a, _b;
    const getNumberHeight = (cssHeight) => {
      if (/px$/.test(cssHeight)) {
        return Number(cssHeight.replace(/px$/, ""));
      }
      return 0;
    };
    const headerCssHeight = getNumberHeight(this.headerEl.css("height"));
    const footerCssHeight = getNumberHeight(this.footerEl.css("height"));
    const winClientHeight = this.winEl.get(0).clientHeight;
    const headerClientHeight = this.headerEl.get(0).clientHeight;
    const footerClientHeight = this.footerEl.get(0).clientHeight;
    const headerIsHidden = this.headerEl.get(0).style.display === "none";
    const footerIsHidden = this.footerEl.get(0).style.display === "none";
    const headerSize = headerIsHidden ? headerClientHeight : Math.max(headerClientHeight, headerCssHeight);
    const footerSize = footerIsHidden ? footerClientHeight : Math.max(footerClientHeight, footerCssHeight);
    Logger.warn("client height:%s", winClientHeight);
    Logger.warn("header height:%s,%s", headerSize, headerClientHeight);
    Logger.warn("footer height:%s,%s", footerSize, footerClientHeight);
    if (this.options.height === "auto") {
      if (this.options.maxHeight) {
        const messageBoxContent = this.bodyEl.find(".sf-message-box_inner");
        const messageBoxClientHeight = (_b = (_a = messageBoxContent.get(0)) == null ? void 0 : _a.clientHeight) != null ? _b : 0;
        const defaultHeight = this.options.maxHeight - headerSize - footerSize;
        const maxHeight = messageBoxContent ? Math.max(messageBoxClientHeight, defaultHeight) : defaultHeight;
        this.bodyEl.css({
          "max-height": maxHeight
        });
      }
      if (this.options.minHeight) {
        this.bodyEl.css({
          "min-height": this.options.minHeight - headerSize - footerSize
        });
      }
      return;
    }
    this.bodyEl.css({
      height: winClientHeight - headerSize - footerSize
    });
  },
  onRender: function() {
  },
  afterRender: function() {
  },
  center: function() {
    this.winEl.css({
      left: "50%",
      top: "50%"
    });
  },
  getRenderData: function() {
    const title = this.options.title;
    let titleTip = this.options.titleTip;
    if (typeof titleTip === "boolean") {
      titleTip = titleTip ? title : "";
    }
    return {
      id: this.getId(),
      title,
      titleTip: HTMLPattern.test(titleTip) ? "" : titleTip,
      body: this.options.body,
      buttonAlign: this.options.buttonAlign,
      buttons: this.getRenderButtonData(),
      getPrefixedClassName,
      utidPrefix: this.options.utid ? `${this.options.utid}-` : ""
    };
  },
  getRenderButtonData: function() {
    const mustFloat = this.options.buttons.indexOf("->"), ret = [];
    this.options.buttons.forEach(function(item) {
      if (item === "->") {
        return;
      }
      if (typeof item !== "string") {
        item.type = item.type || "button";
        item.action = item.action || (item.type === "text" ? "" : "submit");
        item.cls = (item.cls || "") + (item.action === "submit" ? " btn-primary" : "");
      } else {
        item = {
          text: item,
          type: "text"
        };
      }
      item.__id = uuid();
      ret.push(item);
    });
    if (mustFloat > 0) {
      const item = ret[mustFloat - 1];
      item.cls = (item.cls || "") + " sfis-window-footer__btn-separate";
    }
    return ret;
  },
  setTitle: function(title) {
    const $title = $(".title", this.headerEl);
    $title.html(title);
    if (this.options.titleTip !== true) {
      return;
    }
    if (HTMLPattern.test(title)) {
      $title.removeAttr("data-tip");
    } else {
      $title.attr("data-tip", title);
    }
  },
  setWidth: function(w) {
    if (w === "auto") {
      return;
    }
    this.options.width = parseInt(w, 10);
    this.updateWinSize();
  },
  setHeight: function(h) {
    if (h === "auto") {
      return;
    }
    this.options.height = parseInt(h, 10);
    this.updateWinSize();
  },
  autoSetHeight: function() {
    const height = document.documentElement.clientHeight;
    if (this.hidden === false && this.options.autoHeight || this.options.autoMaxHeight && height < 630) {
      this.setHeight(Math.max(0, height - 40));
    }
  },
  getSize: function() {
    let rect;
    if (this.rendered) {
      rect = this.winEl.get(0).getBoundingClientRect();
      return rect;
    }
    return {
      width: parseInt(this.options.width, 10) || 0,
      height: parseInt(this.options.height, 10) || 0
    };
  },
  getWidth: function() {
    return this.getSize().width;
  },
  getHeight: function() {
    return this.getSize().height;
  },
  getId: function() {
    return this.id;
  },
  show: function() {
    const self = this;
    if (!self.hidden || self.emit("beforeshow") === false) {
      return;
    }
    when(self.options.beforeShow()).then(function(result) {
      if (result === false) {
        return;
      }
      if (!self.rendered) {
        self.render();
      }
      self.winEl.show();
      self.bindDragEvent();
      if (self.options.autoMask !== false) {
        self.showMask();
      }
      self.updateBodySize();
      self.updatePosition();
      self.toFront();
      self.hidden = false;
      self.emit("show", self);
    });
  },
  hide: function() {
    const self = this;
    if (self.hidden || self.emit("beforehide") === false) {
      return;
    }
    when(self.options.beforeHide()).then(function(result) {
      if (result === false) {
        return;
      }
      self.unbindDragEvent();
      self.winEl.hide();
      if (self.options.autoMask !== false) {
        self.hideMask();
      }
      self.hidden = true;
      self.emit("hide", self);
      if (self.options.autoDestroy && !self.destroying) {
        self.destroy();
      }
    });
  },
  bindDragEvent: function() {
    const me = this, modal = this.winEl.get(0);
    if (!modal) {
      return;
    }
    let modalLeft = 0;
    let modalTop = 0;
    let currentX = 0;
    let currentY = 0;
    let isMove = false;
    this.startMove = function(event) {
      event = event || window.event;
      isMove = true;
      const clientRect = modal.getBoundingClientRect();
      modalLeft = clientRect.left - parseInt(me.winEl.css("margin-left"));
      modalTop = clientRect.top - parseInt(me.winEl.css("margin-top"));
      currentX = event.clientX;
      currentY = event.clientY;
    };
    this.endMove = function() {
      isMove = false;
      const clientRect = modal.getBoundingClientRect();
      modalLeft = clientRect.left;
      modalTop = clientRect.top;
    };
    this.doingMove = function(event) {
      if (!isMove) {
        return;
      }
      hide();
      event = event || window.event;
      const isOverWin = event.clientX < 0 || $(window).width() < event.clientX || event.clientY < 0 || $(window).height() < event.clientY;
      if (!isOverWin) {
        const disX = event.clientX - currentX;
        const disY = event.clientY - currentY;
        modal.style.left = modalLeft + disX + "px";
        modal.style.top = modalTop + disY + "px";
        modal.style.transform = "none";
      }
    };
    this.doResize = function() {
      this.center();
    }.bind(this);
    this.headerEl.on("mousedown", this.startMove);
    $(document).on("mouseup", this.endMove);
    $(document).on("mousemove", this.doingMove);
    $(window).on("resize", this.doResize);
  },
  unbindDragEvent: function() {
    this.headerEl.off("mousedown", this.startMove);
    $(document).off("mouseup", this.endMove);
    $(document).off("mousemove", this.doingMove);
    $(window).off("resize", this.doResize);
  },
  toFront: function() {
    if (!this.rendered) {
      return;
    }
    if (this.options.autoMask !== false) {
      this.maskEl.css({
        "z-index": this._getZIndex()
      });
    }
    this.winEl.css({
      "z-index": this._getZIndex()
    });
  },
  _getZIndex: function() {
    return Math.max(this.zIndex || 0, getZIndex());
  },
  destroy: function() {
    if (!this.isDestroyed) {
      if (this.emit("beforedestroy", this) !== false) {
        this.destroying = true;
        if (this._autoSetHeight) {
          $(window).off("resize", this._autoSetHeight);
        }
        this.beforeDestroy();
        if (this.maskEl) {
          this.maskEl.remove();
        }
        if (this.winEl) {
          this.winEl.remove();
        }
        this.winEl = null;
        this.maskEl = null;
        this.headerEl = null;
        this.bodyEl = null;
        this.footerEl = null;
        this.onDestroy();
        this.emit("destroy", this);
        this.purgeListeners();
        this.destroying = false;
        this.isDestroyed = true;
      }
    }
  },
  beforeDestroy: function() {
    if (this.rendered) {
      this.hide();
    }
  },
  onDestroy: function() {
    windowMgr.remove(this);
    this.options = {};
  },
  hideHeader: function() {
    this.headerEl.hide();
    this.updateBodySize();
  },
  showHeader: function() {
    this.headerEl.show();
    this.updateBodySize();
  },
  hideBody: function() {
    this.bodyEl.hide();
    this.updateBodySize();
  },
  showBody: function() {
    this.bodyEl.show();
    this.updateBodySize();
  },
  hideFooter: function() {
    this.footerEl.hide();
    this.winEl.addClass(getPrefixedClassName("sfis-window--no-footer"));
    this.updateBodySize();
  },
  showFooter: function() {
    this.footerEl.show();
    this.winEl.removeClass(getPrefixedClassName("sfis-window--no-footer"));
    this.updateBodySize();
  },
  hideMask: function() {
    this.maskEl.hide();
  },
  showMask: function() {
    this.maskEl.show();
  },
  showHeaderClose: function() {
    $(".btn-close", this.headerEl).show();
  },
  hideHeaderClose: function() {
    $(".btn-close", this.headerEl).hide();
  }
});
export { Window as default };
