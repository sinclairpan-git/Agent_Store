import $ from 'jquery';
import { $i } from '@sxf/er-config';
import Format from '@sxf/er-utils/format';
function styleInject(css, ref) {
  if (ref === void 0)
    ref = {};
  var insertAt = ref.insertAt;
  if (!css || typeof document === "undefined") {
    return;
  }
  var head = document.head || document.getElementsByTagName("head")[0];
  var style = document.createElement("style");
  style.type = "text/css";
  if (insertAt === "top") {
    if (head.firstChild) {
      head.insertBefore(style, head.firstChild);
    } else {
      head.appendChild(style);
    }
  } else {
    head.appendChild(style);
  }
  if (style.styleSheet) {
    style.styleSheet.cssText = css;
  } else {
    style.appendChild(document.createTextNode(css));
  }
}
var css_248z = ".pika-single {\n  z-index: 50009;\n  display: block;\n  /*position: relative;*/\n  position: absolute;\n  color: #333;\n  background: #fff;\n  border: 1px solid #00b27a;\n  margin: 3px 0;\n  font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;\n  box-shadow: 0 0 6px 0 rgba(0, 0, 0, 0.12);\n}\n.no-border {\n  border: none;\n}\n.pika-single:before,\n.pika-single:after {\n  content: ' ';\n  display: table;\n}\n.pika-single:after {\n  clear: both;\n}\n.pika-single {\n  *zoom: 1;\n}\n.pika-single.is-hidden {\n  display: none;\n}\n.pika-single.is-bound {\n  position: absolute;\n  /* box-shadow: 0 5px 15px -5px rgba(0,0,0,.5);*/\n}\n.pika-lendar {\n  float: left;\n  width: 200px; /*240px;*/\n  margin: 12px;\n  /*  height: 195px;*/\n}\n.pika-title {\n  position: relative;\n  text-align: center;\n  color: #333;\n}\n.pika-label {\n  display: inline-block;\n  *display: inline;\n  position: relative;\n  z-index: 50009;\n  overflow: hidden;\n  margin: 0;\n  padding: 0 4px;\n  font-size: 14px;\n  font-weight: bold;\n  background-color: #fff;\n}\n.pika-title select {\n  cursor: pointer;\n  position: absolute;\n  z-index: 50008;\n  margin: 0;\n  left: 0;\n  top: 0px;\n  filter: alpha(opacity=0);\n  opacity: 0;\n}\n.pika-prev {\n  background: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAQCAYAAAArij59AAAACXBIWXMAAA7DAAAOwwHHb6hkAAAAZklEQVQokWPABzSdfcoY8Un+Z2DoZMQnCWIz4pPEUIAuiaIAmyRcAS5JsAJ8kiDA9I+BQZgBD2B+e//WHmElNS6gXdZYFYAIfIqYYQxcipiROdgUMaMbia6IGZvDkBVhVYBQpMYFAGlxMTGgly4TAAAAAElFTkSuQmCC');\n  left: 10px;\n}\n.pika-next {\n  background: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAQCAYAAAArij59AAAACXBIWXMAAA7DAAAOwwHHb6hkAAAAeklEQVQokWPQdPYpY8ADmEWU1I6IKql9f3P/1lFsCphAxH8Ghk5cJjHBGLgUMSFzsCliQteBrogJm73Iihg1nH3+M+AAjAwM5UwMeMA/BgZhnAqAxnbd3LulnAmfJIjNhE8SQwG6JIoCbJJwBbgkwUDd2aeTASdgYAAAcH8y8bBcKK4AAAAASUVORK5CYII=');\n  right: 10px;\n}\n.pika-prev,\n.pika-next {\n  display: block;\n  cursor: pointer;\n  position: relative;\n  outline: none;\n  border: 0;\n  padding: 0;\n  width: 20px;\n  height: 30px;\n  /* hide text using text-indent trick, using width value (it's enough) */\n  text-indent: 20px;\n  white-space: nowrap;\n  overflow: hidden;\n  background-color: transparent;\n  background-position: center center;\n  background-repeat: no-repeat;\n  *position: absolute;\n  *top: 0;\n}\n.pika-prev:hover,\n.pika-next:hover {\n  opacity: 1;\n}\n.pika-prev,\n.is-rtl .pika-next:after {\n  float: left;\n  content: '\\25b6';\n  *left: 0;\n}\n.pika-next,\n.is-rtl .pika-prev:after {\n  float: right;\n  content: '\\25C0';\n  *right: 0;\n}\n.pika-prev.is-disabled,\n.pika-next.is-disabled {\n  cursor: default;\n  opacity: 0.2;\n}\n.pika-select {\n  display: inline-block;\n  *display: inline;\n}\n.pika-table {\n  width: 100%;\n  border-spacing: 2px;\n  border: 0;\n  margin-top: 4px;\n}\n.pika-table th,\n.pika-table td {\n  width: 14.285714285714286%;\n  padding: 0;\n}\n.pika-table tbody {\n  border-top: 1px solid #eee;\n}\n.pika-table th {\n  color: #999;\n  font-size: 12px;\n  font-weight: 400;\n  line-height: 25px;\n  text-align: center;\n}\n.pika-button {\n  padding-left: 0.5px !important;\n  padding-right: 0.5px !important;\n}\n.pika-button {\n  cursor: pointer;\n  display: block;\n  outline: none;\n  border: 0;\n  margin: 1.24px;\n  color: #333;\n  font-size: 15px;\n  line-height: 25px;\n  text-align: center;\n  background: #fff;\n  width: 25px;\n  height: 25px;\n  border-radius: 50%;\n}\n.pika-week {\n  font-size: 12px;\n  color: #333;\n}\n.is-today .pika-button,\n.is-today .pika-button:hover {\n  color: var(--color-theme);\n  background: #fff;\n}\n.is-selected .pika-button,\n.is-selected .pika-button:hover {\n  color: #fff;\n  background: #3e4559;\n}\n.is-disabled .pika-button {\n  pointer-events: none;\n  cursor: default;\n  color: #ccc;\n  opacity: 0.4;\n}\n.pika-button:hover {\n  background-color: #f7f8fa;\n}\nabbr[title] {\n  border: none !important;\n}\nabbr[title] {\n  -webkit-text-decoration: none;\n  text-decoration: none;\n}\n.pika-header-btn-readonly {\n  display: none;\n}\n.pika-title-readonly {\n  height: 24px;\n  text-align: left;\n}\n.pika-readonly.is-disabled .pika-button {\n  pointer-events: none;\n  cursor: default;\n  opacity: 1;\n  color: #333;\n}\n.pika-readonly.is-selected .pika-button,\n.pika-readonly.is-selected .pika-button:hover {\n  color: #fff;\n  border-radius: 0;\n  background: var(--color-theme);\n}\n";
styleInject(css_248z);
var pikaday = function(root, factory) {
  var moment;
  return factory(moment);
}(window, function(moment) {
  var hasMoment = typeof moment === "function", hasEventListeners = !!window.addEventListener, document2 = window.document, sto = window.setTimeout, addEvent = function(el, e, callback, capture) {
    if (hasEventListeners) {
      el.addEventListener(e, callback, !!capture);
    } else {
      el.attachEvent("on" + e, callback);
    }
  }, removeEvent = function(el, e, callback, capture) {
    if (hasEventListeners) {
      el.removeEventListener(e, callback, !!capture);
    } else {
      el.detachEvent("on" + e, callback);
    }
  }, fireEvent = function(el, eventName, data) {
    var ev;
    if (document2.createEvent) {
      ev = document2.createEvent("HTMLEvents");
      ev.initEvent(eventName, true, false);
      ev = extend(ev, data);
      el.dispatchEvent(ev);
    } else if (document2.createEventObject) {
      ev = document2.createEventObject();
      ev = extend(ev, data);
      el.fireEvent("on" + eventName, ev);
    }
  }, trim = function(str) {
    return str.trim ? str.trim() : str.replace(/^\s+|\s+$/g, "");
  }, hasClass = function(el, cn) {
    return (" " + el.className + " ").indexOf(" " + cn + " ") !== -1;
  }, addClass = function(el, cn) {
    if (!hasClass(el, cn)) {
      el.className = el.className === "" ? cn : el.className + " " + cn;
    }
  }, removeClass = function(el, cn) {
    el.className = trim((" " + el.className + " ").replace(" " + cn + " ", " "));
  }, isArray = function(obj) {
    return /Array/.test(Object.prototype.toString.call(obj));
  }, isDate = function(obj) {
    return /Date/.test(Object.prototype.toString.call(obj)) && !isNaN(obj.getTime());
  }, isLeapYear = function(year) {
    return year % 4 === 0 && year % 100 !== 0 || year % 400 === 0;
  }, getDaysInMonth = function(year, month) {
    return [31, isLeapYear(year) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month];
  }, setToStartOfDay = function(date) {
    if (isDate(date))
      date.setHours(0, 0, 0, 0);
  }, compareDates = function(a, b) {
    return a.getTime() === b.getTime();
  }, extend = function(to, from, overwrite) {
    var prop, hasProp;
    for (prop in from) {
      hasProp = to[prop] !== void 0;
      if (hasProp && typeof from[prop] === "object" && from[prop].nodeName === void 0) {
        if (isDate(from[prop])) {
          if (overwrite) {
            to[prop] = new Date(from[prop].getTime());
          }
        } else if (isArray(from[prop])) {
          if (overwrite) {
            to[prop] = from[prop].slice(0);
          }
        } else {
          to[prop] = extend({}, from[prop], overwrite);
        }
      } else if (overwrite || !hasProp) {
        to[prop] = from[prop];
      }
    }
    return to;
  }, adjustCalendar = function(calendar) {
    if (calendar.month < 0) {
      calendar.year -= Math.ceil(Math.abs(calendar.month) / 12);
      calendar.month += 12;
    }
    if (calendar.month > 11) {
      calendar.year += Math.floor(Math.abs(calendar.month) / 12);
      calendar.month -= 12;
    }
    return calendar;
  }, defaults = {
    field: null,
    trigger: null,
    bound: void 0,
    position: "bottom left",
    format: "Y-m-d",
    defaultDate: null,
    setDefaultDate: false,
    firstDay: 0,
    minDate: null,
    maxDate: null,
    yearRange: 10,
    showWeekNumber: false,
    minYear: 0,
    maxYear: 9999,
    minMonth: void 0,
    maxMonth: void 0,
    isRTL: false,
    noBorder: false,
    yearSuffix: "",
    monthSuffix: "",
    showMonthAfterYear: false,
    numberOfMonths: 1,
    mainCalendar: "left",
    container: void 0,
    utid: "",
    onSelect: null,
    onOpen: null,
    onClose: null,
    onDraw: null,
    readOnly: false
  }, renderDayName = function(opts, day, abbr) {
    day += opts.firstDay;
    while (day >= 7) {
      day -= 7;
    }
    return abbr ? opts.i18n.weekdaysShort[day] : opts.i18n.weekdays[day];
  }, renderDay = function(d, m, y, isSelected, isToday, isDisabled, isEmpty, readOnly) {
    if (isEmpty) {
      return '<td class="is-empty"></td>';
    }
    var arr = [];
    if (readOnly) {
      arr.push("pika-readonly");
    }
    if (isDisabled) {
      arr.push("is-disabled");
    }
    if (isToday) {
      arr.push("is-today");
    }
    if (isSelected) {
      arr.push("is-selected");
    }
    return '<td data-day="' + d + '" class="' + arr.join(" ") + '"><span class="pika-button pika-day" type="button" data-pika-year="' + y + '" data-pika-month="' + m + '" data-pika-day="' + d + '">' + d + "</span></td>";
  }, renderWeek = function(d, m, y) {
    var onejan = new Date(y, 0, 1), weekNum = Math.ceil(((new Date(y, m, d) - onejan) / 864e5 + onejan.getDay() + 1) / 7);
    return '<td class="pika-week">' + weekNum + "</td>";
  }, renderRow = function(days, isRTL) {
    return "<tr>" + (isRTL ? days.reverse() : days).join("") + "</tr>";
  }, renderBody = function(rows) {
    return "<tbody>" + rows.join("") + "</tbody>";
  }, renderHead = function(opts) {
    var i, arr = [];
    if (opts.showWeekNumber) {
      arr.push("<th></th>");
    }
    for (i = 0; i < 7; i++) {
      arr.push(
        '<th scope="col"><abbr title="' + renderDayName(opts, i) + '">' + renderDayName(opts, i, true) + "</abbr></th>"
      );
    }
    return "<thead>" + (opts.isRTL ? arr.reverse() : arr).join("") + "</thead>";
  }, renderTitle = function(instance, c, year, month, refYear) {
    var i, j, arr, opts = instance._o, isMinYear = year === opts.minYear, isMaxYear = year === opts.maxYear, html = '<div class="pika-title' + (opts.readOnly ? " pika-title-readonly" : "") + '">', monthHtml, yearHtml, prev = true, next = true;
    for (arr = [], i = 0; i < 12; i++) {
      arr.push(
        '<option value="' + (year === refYear ? i - c : 12 + i - c) + '"' + (i === month ? " selected" : "") + (isMinYear && i < opts.minMonth || isMaxYear && i > opts.maxMonth ? "disabled" : "") + ">" + opts.i18n.months[i] + "</option>"
      );
    }
    monthHtml = '<div class="pika-label">' + opts.i18n.months[month] + opts.monthSuffix + "</div>";
    if (isArray(opts.yearRange)) {
      i = opts.yearRange[0];
      j = opts.yearRange[1] + 1;
    } else {
      i = year - opts.yearRange;
      j = 1 + year + opts.yearRange;
    }
    for (arr = []; i < j && i <= opts.maxYear; i++) {
      if (i >= opts.minYear) {
        arr.push('<option value="' + i + '"' + (i === year ? " selected" : "") + ">" + i + "</option>");
      }
    }
    yearHtml = '<div class="pika-label">' + year + opts.yearSuffix + "</div>";
    if (opts.showMonthAfterYear) {
      html += yearHtml + monthHtml;
    } else {
      html += monthHtml + yearHtml;
    }
    if (isMinYear && (month === 0 || opts.minMonth >= month)) {
      prev = false;
    }
    if (isMaxYear && (month === 11 || opts.maxMonth <= month)) {
      next = false;
    }
    if (c === 0) {
      var currentPrevCls = "pika-prev" + (prev ? "" : " is-disabled") + (opts.readOnly ? " pika-header-btn-readonly" : "");
      html += '<button type="button"class="' + currentPrevCls + '" type="button">' + opts.i18n.previousMonth + "</button>";
    }
    if (c === instance._o.numberOfMonths - 1) {
      var currentNextCls = "pika-next" + (next ? "" : " is-disabled") + (opts.readOnly ? " pika-header-btn-readonly" : "");
      html += '<button type="button"class="' + currentNextCls + '" type="button">' + opts.i18n.nextMonth + "</button>";
    }
    return html += "</div>";
  }, renderTable = function(opts, data) {
    return '<table cellpadding="0" cellspacing="0" class="pika-table">' + renderHead(opts) + renderBody(data) + "</table>";
  }, Pikaday = function(options) {
    var self = this, opts = self.config(options);
    self._onMouseDown = function(e) {
      if (!self._v) {
        return;
      }
      e = e || window.event;
      var target = e.target || e.srcElement;
      if (!target) {
        return;
      }
      if (!hasClass(target, "is-disabled")) {
        if (hasClass(target, "pika-button") && !hasClass(target, "is-empty")) {
          self.setDate(
            new Date(
              target.getAttribute("data-pika-year"),
              target.getAttribute("data-pika-month"),
              target.getAttribute("data-pika-day")
            )
          );
          if (opts.bound) {
            sto(function() {
              self.hide();
              if (opts.field) {
                opts.field.blur();
              }
            }, 100);
          }
          return;
        } else if (hasClass(target, "pika-prev")) {
          self.prevMonth();
          self.setDate(new Date(self.calendars[0].year, self.calendars[0].month, "1"));
        } else if (hasClass(target, "pika-next")) {
          self.nextMonth();
          self.setDate(new Date(self.calendars[0].year, self.calendars[0].month, "1"));
        }
      }
      if (!hasClass(target, "pika-select")) {
        if (e.preventDefault) {
          e.preventDefault();
        } else {
          e.returnValue = false;
          return false;
        }
      } else {
        self._c = true;
      }
    };
    self._onChange = function(e) {
      e = e || window.event;
      var target = e.target || e.srcElement;
      if (!target) {
        return;
      }
      if (hasClass(target, "pika-select-month")) {
        self.gotoMonth(target.value);
      } else if (hasClass(target, "pika-select-year")) {
        self.gotoYear(target.value);
      }
    };
    self._onInputChange = function(e) {
      var date;
      if (e.firedBy === self) {
        return;
      }
      if (hasMoment) {
        date = moment(opts.field.value, opts.format);
        date = date && date.isValid() ? date.toDate() : null;
      } else {
        date = new Date(Date.parse(opts.field.value));
      }
      self.setDate(isDate(date) ? date : null);
      if (!self._v) {
        self.show();
      }
    };
    self._onInputFocus = function() {
      self.show();
    };
    self._onInputClick = function() {
      if (hasClass(self.el, "is-hidden")) {
        self.show();
      } else {
        self.hide();
      }
    };
    self._onInputBlur = function() {
      if (!self._c) {
        self._b = sto(function() {
          self.hide();
        }, 50);
      }
      self._c = false;
    };
    self._onClick = function(e) {
      e = e || window.event;
      var target = e.target || e.srcElement, pEl = target;
      if (!target) {
        return;
      }
      if (!hasEventListeners && hasClass(target, "pika-select")) {
        if (!target.onchange) {
          target.setAttribute("onchange", "return;");
          addEvent(target, "change", self._onChange);
        }
      }
      do {
        if (hasClass(pEl, "pika-single")) {
          return;
        }
      } while (pEl = pEl.parentNode);
      if (self._v && target !== opts.trigger) {
        self.hide();
      }
    };
    self.el = document2.createElement("div");
    self.el.className = "pika-single" + (opts.isRTL ? " is-rtl" : "") + (opts.noBorder ? " no-border" : "") + " pika-datepicker";
    self.el.setAttribute("utid", opts.utid + "Pika");
    addEvent(self.el, "mousedown", self._onMouseDown, true);
    addEvent(self.el, "change", self._onChange);
    if (opts.field) {
      if (opts.container) {
        opts.container.appendChild(self.el);
      } else if (opts.bound) {
        document2.body.appendChild(self.el);
      } else {
        opts.field.parentNode.insertBefore(self.el, opts.field.nextSibling);
      }
      addEvent(opts.field, "change", self._onInputChange);
      if (!opts.defaultDate) {
        if (hasMoment && opts.field.value) {
          opts.defaultDate = moment(opts.field.value, opts.format).toDate();
        } else {
          opts.defaultDate = new Date(Date.parse(opts.field.value));
        }
        opts.setDefaultDate = true;
      }
    }
    var defDate = opts.defaultDate;
    if (isDate(defDate)) {
      if (opts.setDefaultDate) {
        self.setDate(defDate, true);
      } else {
        self.gotoDate(defDate);
      }
    } else {
      self.gotoDate(new Date());
    }
    if (opts.bound) {
      this.hide();
      self.el.className += " is-bound";
      addEvent(opts.trigger, "click", self._onInputClick);
    } else {
      this.show();
    }
  };
  Pikaday.prototype = {
    config: function(options) {
      if (!this._o) {
        this._o = extend(
          {
            i18n: {
              previousMonth: "Previous Month",
              nextMonth: "Next Month",
              months: [
                $i("scp.vt_component.common.plugins.jquery.date.pikaday.january"),
                $i("scp.vt_component.common.plugins.jquery.date.pikaday.february"),
                $i("scp.vt_component.common.plugins.jquery.date.pikaday.march"),
                $i("scp.vt_component.common.plugins.jquery.date.pikaday.april"),
                $i("scp.vt_component.common.plugins.jquery.date.pikaday.may"),
                $i("scp.vt_component.common.plugins.jquery.date.pikaday.june"),
                $i("scp.vt_component.common.plugins.jquery.date.pikaday.july"),
                $i("scp.vt_component.common.plugins.jquery.date.pikaday.august"),
                $i("scp.vt_component.common.plugins.jquery.date.pikaday.september"),
                $i("scp.vt_component.common.plugins.jquery.date.pikaday.october"),
                $i("scp.vt_component.common.plugins.jquery.date.pikaday.novement"),
                $i("scp.vt_component.common.plugins.jquery.date.pikaday.december")
              ],
              weekdays: [
                $i("scp.vt_component.common.plugins.jquery.date.pikaday.sunday"),
                $i("scp.vt_component.common.plugins.jquery.date.pikaday.monday"),
                $i("scp.vt_component.common.plugins.jquery.date.pikaday.tuesday"),
                $i("scp.vt_component.common.plugins.jquery.date.pikaday.wednesday"),
                $i("scp.vt_component.common.plugins.jquery.date.pikaday.thursday"),
                $i("scp.vt_component.common.plugins.jquery.date.pikaday.friday"),
                $i("scp.vt_component.common.plugins.jquery.date.pikaday.saturday")
              ],
              weekdaysShort: [
                $i("scp.vt_component.common.plugins.jquery.date.pikaday.sunday_short"),
                $i("scp.vt_component.common.plugins.jquery.date.pikaday.monday_short"),
                $i("scp.vt_component.common.plugins.jquery.date.pikaday.tuesday_short"),
                $i("scp.vt_component.common.plugins.jquery.date.pikaday.wednesday_short"),
                $i("scp.vt_component.common.plugins.jquery.date.pikaday.thursday_short"),
                $i("scp.vt_component.common.plugins.jquery.date.pikaday.friday_short"),
                $i("scp.vt_component.common.plugins.jquery.date.pikaday.saturday_short")
              ]
            }
          },
          defaults,
          true
        );
      }
      var opts = extend(this._o, options, true);
      opts.isRTL = !!opts.isRTL;
      opts.field = opts.field && opts.field.nodeName ? opts.field : null;
      opts.bound = !!(opts.bound !== void 0 ? opts.field && opts.bound : opts.field);
      opts.trigger = opts.trigger && opts.trigger.nodeName ? opts.trigger : opts.field;
      var nom = parseInt(opts.numberOfMonths, 10) || 1;
      opts.numberOfMonths = nom > 4 ? 4 : nom;
      if (!isDate(opts.minDate)) {
        opts.minDate = false;
      }
      if (!isDate(opts.maxDate)) {
        opts.maxDate = false;
      }
      if (opts.minDate && opts.maxDate && opts.maxDate < opts.minDate) {
        opts.maxDate = opts.minDate = false;
      }
      if (opts.minDate) {
        setToStartOfDay(opts.minDate);
        opts.minYear = opts.minDate.getFullYear();
        opts.minMonth = opts.minDate.getMonth();
      }
      if (opts.maxDate) {
        setToStartOfDay(opts.maxDate);
        opts.maxYear = opts.maxDate.getFullYear();
        opts.maxMonth = opts.maxDate.getMonth();
      }
      if (isArray(opts.yearRange)) {
        var fallback = new Date().getFullYear() - 10;
        opts.yearRange[0] = parseInt(opts.yearRange[0], 10) || fallback;
        opts.yearRange[1] = parseInt(opts.yearRange[1], 10) || fallback;
      } else {
        opts.yearRange = Math.abs(parseInt(opts.yearRange, 10)) || defaults.yearRange;
        if (opts.yearRange > 100) {
          opts.yearRange = 100;
        }
      }
      return opts;
    },
    toString: function(format) {
      return !isDate(this._d) ? "" : Format ? Format.date(this._d, format || this._o.format) : this._d.toDateString();
    },
    getMoment: function() {
      return hasMoment ? moment(this._d) : null;
    },
    setMoment: function(date, preventOnSelect) {
      if (hasMoment && moment.isMoment(date)) {
        this.setDate(date.toDate(), preventOnSelect);
      }
    },
    getDate: function() {
      return isDate(this._d) ? new Date(this._d.getTime()) : null;
    },
    setDate: function(date, preventOnSelect) {
      if (!date) {
        this._d = null;
        return this.draw();
      }
      if (typeof date === "string") {
        date = new Date(Date.parse(date));
      }
      if (!isDate(date)) {
        return;
      }
      var min = this._o.minDate, max = this._o.maxDate;
      if (isDate(min) && date < min) {
        date = min;
      } else if (isDate(max) && date > max) {
        date = max;
      }
      this._d = new Date(date.getTime());
      setToStartOfDay(this._d);
      this.gotoDate(this._d);
      if (this._o.field) {
        this._o.field.value = this.toString();
        fireEvent(this._o.field, "change", { firedBy: this });
      }
      if (!preventOnSelect && typeof this._o.onSelect === "function") {
        this._o.onSelect.call(this, this.getDate());
      }
    },
    gotoDate: function(date) {
      var newCalendar = true;
      if (!isDate(date)) {
        return;
      }
      if (this.calendars) {
        var firstVisibleDate = new Date(this.calendars[0].year, this.calendars[0].month, 1), lastVisibleDate = new Date(
          this.calendars[this.calendars.length - 1].year,
          this.calendars[this.calendars.length - 1].month,
          1
        ), visibleDate = date.getTime();
        lastVisibleDate.setMonth(lastVisibleDate.getMonth() + 1);
        lastVisibleDate.setDate(lastVisibleDate.getDate() - 1);
        newCalendar = visibleDate < firstVisibleDate.getTime() || lastVisibleDate.getTime() < visibleDate;
      }
      if (newCalendar) {
        this.calendars = [
          {
            month: date.getMonth(),
            year: date.getFullYear()
          }
        ];
        if (this._o.mainCalendar === "right") {
          this.calendars[0].month += 1 - this._o.numberOfMonths;
        }
      }
      this.adjustCalendars();
    },
    adjustCalendars: function() {
      this.calendars[0] = adjustCalendar(this.calendars[0]);
      for (var c = 1; c < this._o.numberOfMonths; c++) {
        this.calendars[c] = adjustCalendar({
          month: this.calendars[0].month + c,
          year: this.calendars[0].year
        });
      }
      this.draw();
    },
    gotoToday: function() {
      this.gotoDate(new Date());
    },
    gotoMonth: function(month) {
      if (!isNaN(month)) {
        this.calendars[0].month = parseInt(month, 10);
        this.adjustCalendars();
      }
    },
    nextMonth: function() {
      this.calendars[0].month++;
      this.adjustCalendars();
    },
    prevMonth: function() {
      this.calendars[0].month--;
      this.adjustCalendars();
    },
    gotoYear: function(year) {
      if (!isNaN(year)) {
        this.calendars[0].year = parseInt(year, 10);
        this.adjustCalendars();
      }
    },
    setMinDate: function(value) {
      this._o.minDate = value;
    },
    setMaxDate: function(value) {
      this._o.maxDate = value;
    },
    draw: function(force) {
      if (!this._v && !force) {
        return;
      }
      var opts = this._o, minYear = opts.minYear, maxYear = opts.maxYear, minMonth = opts.minMonth, maxMonth = opts.maxMonth, html = "";
      if (this._y <= minYear) {
        this._y = minYear;
        if (!isNaN(minMonth) && this._m < minMonth) {
          this._m = minMonth;
        }
      }
      if (this._y >= maxYear) {
        this._y = maxYear;
        if (!isNaN(maxMonth) && this._m > maxMonth) {
          this._m = maxMonth;
        }
      }
      for (var c = 0; c < opts.numberOfMonths; c++) {
        html += '<div class="pika-lendar">' + renderTitle(this, c, this.calendars[c].year, this.calendars[c].month, this.calendars[0].year) + this.render(this.calendars[c].year, this.calendars[c].month) + "</div>";
      }
      this.el.innerHTML = html;
      if (opts.bound) {
        if (opts.field.type !== "hidden") {
          sto(function() {
            opts.trigger.focus();
          }, 1);
        }
      }
      if (typeof this._o.onDraw === "function") {
        var self = this;
        sto(function() {
          self._o.onDraw.call(self);
        }, 0);
      }
    },
    adjustPosition: function() {
      if (this._o.container)
        return;
      var field = this._o.field, pEl = field, width = this.el.offsetWidth, height = this.el.offsetHeight, viewportWidth = window.innerWidth || document2.documentElement.clientWidth, viewportHeight = window.innerHeight || document2.documentElement.clientHeight, scrollTop = window.pageYOffset || document2.body.scrollTop || document2.documentElement.scrollTop, left, top, clientRect;
      var position = "absolute";
      if (typeof field.getBoundingClientRect === "function") {
        clientRect = field.getBoundingClientRect();
        left = clientRect.left;
        top = clientRect.bottom;
        if ($.grep($(field).parents(), function(n) {
          return $(n).css("position") === "fixed";
        }).length > 0) {
          position = "fixed";
        } else {
          left += window.pageXOffset;
          top += window.pageYOffset;
        }
      } else {
        left = pEl.offsetLeft;
        top = pEl.offsetTop + pEl.offsetHeight;
        while (pEl = pEl.offsetParent) {
          left += pEl.offsetLeft;
          top += pEl.offsetTop;
        }
      }
      if (left + width > viewportWidth || this._o.position.indexOf("right") > -1 && left - width + field.offsetWidth > 0) {
        left = left - width + field.offsetWidth;
      }
      if (top + height > viewportHeight + scrollTop || this._o.position.indexOf("top") > -1 && top - height - field.offsetHeight > 0) {
        top = top - height - field.offsetHeight;
      }
      this.el.style.cssText = ["position: " + position, "left: " + left + "px", "top: " + top + "px"].join(";");
    },
    render: function(year, month) {
      var opts = this._o, now = isDate(opts.defaultDate) ? opts.defaultDate : new Date(), days = getDaysInMonth(year, month), before = new Date(year, month, 1).getDay(), data = [], row = [];
      setToStartOfDay(now);
      if (opts.firstDay > 0) {
        before -= opts.firstDay;
        if (before < 0) {
          before += 7;
        }
      }
      var cells = days + before, after = cells;
      while (after > 7) {
        after -= 7;
      }
      cells += 7 - after;
      for (var i = 0, r = 0; i < cells; i++) {
        var day = new Date(year, month, 1 + (i - before)), isDisabled = opts.minDate && day < opts.minDate || opts.maxDate && day > opts.maxDate || opts.readOnly, isSelected = isDate(this._d) ? compareDates(day, this._d) : false, isToday = compareDates(day, now), isEmpty = i < before || i >= days + before;
        row.push(renderDay(1 + (i - before), month, year, isSelected, isToday, isDisabled, isEmpty, opts.readOnly));
        if (++r === 7) {
          if (opts.showWeekNumber) {
            row.unshift(renderWeek(i - before, month, year));
          }
          data.push(renderRow(row, opts.isRTL));
          row = [];
          r = 0;
        }
      }
      return renderTable(opts, data);
    },
    isVisible: function() {
      return this._v;
    },
    show: function() {
      if (!this._v) {
        removeClass(this.el, "is-hidden");
        this._v = true;
        this.draw();
        if (this._o.bound) {
          addEvent(document2, "click", this._onClick);
          this.adjustPosition();
        }
        if (typeof this._o.onOpen === "function") {
          this._o.onOpen.call(this);
        }
      }
    },
    hide: function() {
      var v = this._v;
      if (v !== false) {
        if (this._o.bound) {
          removeEvent(document2, "click", this._onClick);
        }
        this.el.style.cssText = "";
        addClass(this.el, "is-hidden");
        this._v = false;
        if (v !== void 0 && typeof this._o.onClose === "function") {
          this._o.onClose.call(this);
        }
      }
    },
    destroy: function() {
      this.hide();
      removeEvent(this.el, "mousedown", this._onMouseDown, true);
      removeEvent(this.el, "change", this._onChange);
      if (this._o.field) {
        removeEvent(this._o.field, "change", this._onInputChange);
        if (this._o.bound) {
          removeEvent(this._o.trigger, "click", this._onInputClick);
          removeEvent(this._o.trigger, "focus", this._onInputFocus);
          removeEvent(this._o.trigger, "blur", this._onInputBlur);
        }
      }
      if (this.el.parentNode) {
        this.el.parentNode.removeChild(this.el);
      }
    }
  };
  return Pikaday;
});
export { pikaday as default };
