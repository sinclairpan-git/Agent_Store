import $ from 'jquery';
import uuid from '@sxf/er-utils/uuid';
function styleInject(css, ref) {
  if (ref === void 0)
    ref = {};
  var insertAt = ref.insertAt;
  if (!css || typeof document === "undefined") {
    return;
  }
  var head = document.head || document.getElementsByTagName("head")[0];
  var style = document.createElement("style");
  style.type = "text/css";
  if (insertAt === "top") {
    if (head.firstChild) {
      head.insertBefore(style, head.firstChild);
    } else {
      head.appendChild(style);
    }
  } else {
    head.appendChild(style);
  }
  if (style.styleSheet) {
    style.styleSheet.cssText = css;
  } else {
    style.appendChild(document.createTextNode(css));
  }
}
var css_248z = "fieldset.sfis-fieldset {\n  position: relative;\n  z-index: 0;\n}\nfieldset.sfis-fieldset > .sfis-fieldset-legend-wrap > legend > input + .fieldset-mask,\nfieldset.sfis-fieldset > .sfis-fieldset-legend-wrap > legend > input + .checkbox-wrap + .fieldset-mask,\nfieldset.sfis-fieldset > .sfis-fieldset-legend-wrap > legend > input + .radio-wrap + .fieldset-mask,\nfieldset.sfis-fieldset > .sfis-fieldset-legend-wrap > legend > input + .checkbox-round-wrap + .fieldset-mask {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  background: #fff;\n  opacity: 0.6;\n  z-index: 2;\n  display: block;\n}\nfieldset.sfis-fieldset > .sfis-fieldset-legend-wrap > legend > input:checked + .fieldset-mask,\nfieldset.sfis-fieldset > .sfis-fieldset-legend-wrap > legend > input:checked + .checkbox-wrap + .fieldset-mask,\nfieldset.sfis-fieldset > .sfis-fieldset-legend-wrap > legend > input:checked + .radio-wrap + .fieldset-mask,\nfieldset.sfis-fieldset > .sfis-fieldset-legend-wrap > legend > input:checked + .checkbox-round-wrap + .fieldset-mask {\n  display: none;\n}\n";
styleInject(css_248z);
const getWrapCls = function(options) {
  return "fieldset-mask" + (options.cls || "");
};
const getWrapStyle = function(options) {
  return options.style || "";
};
const repaint = function(dom) {
  const repaintCls = "__sfis-repaint_class__";
  $(dom).addClass(repaintCls).removeClass(repaintCls);
};
const getInput = function(node) {
  return $(node).children(".sfis-fieldset-legend-wrap").children("legend").find("input[type=checkbox],input[type=radio]");
};
const willWrap = function(node) {
  return /fieldset/i.test(node.tagName) && !$(node).data("fixfieldset");
};
function wrap(dom, options) {
  $(dom).children("legend").wrapAll(function() {
    return wrapFunc.call(this);
  });
  doWrap(dom, options);
}
function wrapFunc() {
  const target = $(this);
  const styles = [];
  ["margin-left", "margin-right", "margin-top", "margin-bottom"].forEach(function(css) {
    styles.push(css + ":" + target.css(css));
  });
  return '<div class="sfis-fieldset-legend-wrap" style="' + styles.join(";") + '"></span>';
}
function doWrap(node, options) {
  const wrapCls = getWrapCls(options), wrapStyle = getWrapStyle(options);
  let input;
  $(node).data("fixfieldset", true).addClass("sfis-fieldset");
  if (!node.id) {
    node.id = uuid();
  }
  const n = $('<div id="' + node.id + '-mask" class="' + wrapCls + ' unselectable" style="' + wrapStyle + '"></div>');
  input = getInput(node);
  input.change(function() {
    let name;
    if ($(this).is("[type=radio]")) {
      name = $(this).attr("name");
      if (name) {
        repaint($('input[type=radio][name="' + name + '"] ~ .fieldset-mask'));
      }
    } else {
      repaint(n);
    }
  });
  if ($(input).data("fixcheckbox")) {
    input = input.next();
  }
  const legend = $(node).children(".sfis-fieldset-legend-wrap").children("legend");
  n.css("margin-top", legend.outerHeight() || 32);
  n.insertAfter(input);
}
function fixfieldset(options) {
  const self = this;
  self.each(function() {
    if (willWrap(this)) {
      wrap(this, options || {});
    }
  });
  return this;
}
export { fixfieldset };
