# Change Log

## 1.11.4

### Patch Changes

- 解决无法build，publish的问题
- Updated dependencies
  - @sxf/intl@2.5.3

## 1.11.3

### Patch Changes

- fix: 检测修改所有包的 package.json 配置处理打包工具兼容问题
  - @sxf/intl@2.5.2

## 1.11.2

### Patch Changes

- Updated dependencies
  - @sxf/intl@2.5.2

## 1.11.1

### Patch Changes

- Updated dependencies
  - @sxf/intl@2.5.1

## 1.11.0

### Minor Changes

- 8979f61: 添加 addMessages 函数用于动态添加词条

### Patch Changes

- Updated dependencies [8979f61]
  - @sxf/intl@2.5.0

## 1.10.12

### Patch Changes

- d4f5293: chore: release vue intl

## 1.10.11

### Patch Changes

- 7b7a4da: chore: release

  @sxf/intl、@sxf/vue-intl、@sxf/vue3-intl

  - 新增参数格式化钩子

  @sxf/i18n-next-tool

  - 新增 warning 信息过滤功能

- Updated dependencies [7b7a4da]
  - @sxf/intl@2.4.10

## 1.10.10

### Patch Changes

- 60062f2: chore(release): publish
- Updated dependencies [60062f2]
  - @sxf/intl@2.4.9

## 1.10.9

### Patch Changes

- 5d2a9c3: chore(release): update all packages

  1. 将 @formatjs/icu-messageformat-parser 包提取出来，放在 root 下
  2. 新增词条的参数检测

- Updated dependencies [5d2a9c3]
  - @sxf/intl@2.4.8

## 1.10.8

### Patch Changes

- chore(release): publish
- Updated dependencies
  - @sxf/intl@2.4.7

## 1.10.7

### Patch Changes

- chore(release): pnpm publish
- Updated dependencies
  - @sxf/intl@2.4.6

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [1.10.6](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/vue-intl@1.10.5...@sxf/vue-intl@1.10.6) (2021-10-19)

### Bug Fixes

- **#42:** enhance mixin fn ([5f32b6f](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/5f32b6f80b1f09785047f47b6cc48ab2b689427a)), closes [#42](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/issues/42)

## [1.10.5](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/vue-intl@1.10.4...@sxf/vue-intl@1.10.5) (2021-09-16)

**Note:** Version bump only for package @sxf/vue-intl

## [1.10.4](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/vue-intl@1.10.3...@sxf/vue-intl@1.10.4) (2021-09-16)

**Note:** Version bump only for package @sxf/vue-intl

## [1.10.3](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/vue-intl@1.10.2...@sxf/vue-intl@1.10.3) (2021-07-20)

**Note:** Version bump only for package @sxf/vue-intl

## [1.10.2](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/vue-intl@1.10.1...@sxf/vue-intl@1.10.2) (2021-07-20)

**Note:** Version bump only for package @sxf/vue-intl

## [1.10.1](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/vue-intl@1.10.0...@sxf/vue-intl@1.10.1) (2021-07-20)

**Note:** Version bump only for package @sxf/vue-intl

# [1.10.0](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/vue-intl@1.9.1...@sxf/vue-intl@1.10.0) (2021-07-16)

### Bug Fixes

- remover redundant pkg ([08d2f3e](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/08d2f3ece9915ea28a7ec29d5011417b6acb000a))

### Features

- **intl:** add flatten configuration ([016d686](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/016d6863d16f2e2044c7a17e706f81042a25b15e))
- **intl:** the \$i func supports array variables ([82d643b](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/82d643bfa0ab97cde0d697b1789a3429ce2d1bee))
- **intl | vue-intl:** optimiztion of build ([4b363a9](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/4b363a9177f262153e97fadff6e70c9dd6d85320))
- **vue3-intl:** add building config ([021bdac](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/021bdac661e44d66ef0c438ab88605a8356d3d85))
- add ts code transform ([ea5671a](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/ea5671ac5cc0da00bfb6db09911edf8d26b8fe70))

## [1.9.1](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/vue-intl@1.9.0...@sxf/vue-intl@1.9.1) (2021-06-22)

### Bug Fixes

- **vue-intl:** fix index.d.ts error ([50cb0de](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/50cb0de371ea9038a816bc4ef48985fbf5807b2b))

# [1.9.0](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/vue-intl@1.8.3...@sxf/vue-intl@1.9.0) (2021-05-18)

### Features

- **intl | vue-intl:** adding Default Parameters ([969935c](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/969935c56cc48e3fdea56995f3c3c43af9ec4c8d))

## [1.8.3](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/vue-intl@1.8.2...@sxf/vue-intl@1.8.3) (2021-04-27)

### Bug Fixes

- **intl:** fix a bug where core-js polyfill were not packed ([3a9e8fc](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/3a9e8fcddb3cf45f03bb2703c4510bee42e7ac61))

## [1.8.2](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/vue-intl@1.8.1...@sxf/vue-intl@1.8.2) (2021-04-23)

### Bug Fixes

- **intl | vue-intl:** fix unit test error ([f943dd7](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/f943dd74cb93f70fafffc487428c927f84c54ebe))

## [1.8.1](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/vue-intl@1.8.0...@sxf/vue-intl@1.8.1) (2021-04-21)

### Bug Fixes

- **intl | vue-intl:** fix parsing error of the ast parser under old Edge ([b521787](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/b521787ea6c86901dc7c649a38e3ba74118260d5))

# [1.8.0](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/vue-intl@1.7.5...@sxf/vue-intl@1.8.0) (2021-04-20)

### Features

- **all:** use new ast parser ([eee2b03](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/eee2b03a86abd5df0fad0034c1224a873d77107f))

## [1.7.5](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/vue-intl@1.7.4...@sxf/vue-intl@1.7.5) (2021-04-19)

**Note:** Version bump only for package @sxf/vue-intl

## [1.7.4](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/vue-intl@1.7.3...@sxf/vue-intl@1.7.4) (2021-04-16)

### Bug Fixes

- **all:** fix build error ([9602fdc](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/9602fdc48b46b7d0abd21fe8e2ffd2a9bec3ec4c))

## [1.7.3](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/vue-intl@1.7.2...@sxf/vue-intl@1.7.3) (2021-04-15)

### Bug Fixes

- **vue-intl:** fix build error ([3bc14e2](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/3bc14e2a95a09025ad2cfbfaf84c3ffffeb5a6d6))

## [1.7.2](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/vue-intl@1.7.1...@sxf/vue-intl@1.7.2) (2021-04-15)

**Note:** Version bump only for package @sxf/vue-intl

## [1.7.1](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/vue-intl@1.7.0...@sxf/vue-intl@1.7.1) (2021-04-12)

### Bug Fixes

- **@sxf/intl | @sxf/vue-intl:** fix spelling mistakes ([de0d28d](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/de0d28dd4367a0c2efc1fff94164922c4d5d1a4c))

# [1.7.0](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/vue-intl@1.6.3...@sxf/vue-intl@1.7.0) (2021-04-09)

### Features

- **@sxf/vue-intl:** interpolation component use onError hook ([0219de2](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/0219de236c1a3925414b2c69214d77c363b45c98))

## [1.6.3](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/vue-intl@1.6.2...@sxf/vue-intl@1.6.3) (2021-04-09)

**Note:** Version bump only for package @sxf/vue-intl

## [1.6.2](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/vue-intl@1.6.1...@sxf/vue-intl@1.6.2) (2021-04-09)

**Note:** Version bump only for package @sxf/vue-intl

## [1.6.1](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/vue-intl@1.6.0...@sxf/vue-intl@1.6.1) (2021-04-09)

**Note:** Version bump only for package @sxf/vue-intl

# [1.6.0](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/vue-intl@1.5.1...@sxf/vue-intl@1.6.0) (2021-04-09)

### Features

- **all:** add onError hook ([17aaaba](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/17aaaba4131b90dfeb657607097ff94235b65b11))

## [1.5.1](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/vue-intl@1.5.0...@sxf/vue-intl@1.5.1) (2021-04-08)

**Note:** Version bump only for package @sxf/vue-intl

# [1.5.0](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sxf/vue-intl@1.4.0...@sxf/vue-intl@1.5.0) (2021-04-08)

### Features

- **intl | vue-intl:** change the Vue-intl code style to FP ([fced917](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/fced917a8c6a744981efabd40992cd3488f75eb9))

# 1.4.0 (2021-03-31)

### Bug Fixes

- **@sfx/vue-intl:** fix global registration component naming error ([519a4f0](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/519a4f09d10b063245e28b81b18b1550e90db6ae))
- **@sfx/vue-intl:** tslib add es2020.intl ([de21bcd](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/de21bcd4bb0ed67c273e7b5b67becbebddebcb05))

### Features

- **@sfx/vue-intl:** @sfx/vue-intl init ([2ae9564](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/2ae95643a0dd733b1780ab2d71ebf0d278f3578a))
- **@sfx/vue-intl:** intl function and interpoltion component for vue2 ([c9aa5b2](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/c9aa5b2b4df24c57e5d19b144ddc8118e729cdb1))
- **@sfx/vue-intl:** modify interpolation component ([f5e9b5b](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/f5e9b5bd6c467c000a4620c51c632f4558592030))
- **all:** @sfx/vue-intl@1.2.0 ([a18f0b2](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/a18f0b21a47b56a3ca03500dcb65c6bad74d1813))
- **all:** change npm package name ([803771e](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/803771e9a0c17b656f0d1c15e42d7d839f5b472d))
- **all:** reset project configuration and lerna init ([a7e643b](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/a7e643b227f7de8f69deb3f4c9693a140b16cd3d))
- **vue-intl:** vue-intl init ([2089dc8](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/2089dc8bcf6dc6360344e792b7cc05fc6405ba8f))

# [1.3.0](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sfx/vue-intl@1.2.2...@sfx/vue-intl@1.3.0) (2021-03-31)

### Features

- **@sfx/vue-intl:** modify interpolation component ([f5e9b5b](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/f5e9b5bd6c467c000a4620c51c632f4558592030))

## [1.2.2](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sfx/vue-intl@1.2.1...@sfx/vue-intl@1.2.2) (2021-03-30)

### Bug Fixes

- **@sfx/vue-intl:** tslib add es2020.intl ([de21bcd](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/de21bcd4bb0ed67c273e7b5b67becbebddebcb05))

## [1.2.1](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sfx/vue-intl@1.2.0...@sfx/vue-intl@1.2.1) (2021-03-30)

### Bug Fixes

- **@sfx/vue-intl:** fix global registration component naming error ([519a4f0](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/519a4f09d10b063245e28b81b18b1550e90db6ae))

# [1.2.0](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/compare/@sfx/vue-intl@1.1.0...@sfx/vue-intl@1.2.0) (2021-03-30)

### Features

- **all:** @sfx/vue-intl@1.2.0 ([a18f0b2](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/a18f0b21a47b56a3ca03500dcb65c6bad74d1813))

# 1.1.0 (2021-03-29)

### Features

- **@sfx/vue-intl:** @sfx/vue-intl init ([2ae9564](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/2ae95643a0dd733b1780ab2d71ebf0d278f3578a))
- **@sfx/vue-intl:** intl function and interpolation component for vue2 ([c9aa5b2](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/c9aa5b2b4df24c57e5d19b144ddc8118e729cdb1))
- **all:** reset project configuration and lerna init ([a7e643b](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/a7e643b227f7de8f69deb3f4c9693a140b16cd3d))
- **vue-intl:** vue-intl init ([2089dc8](https://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/commits/2089dc8bcf6dc6360344e792b7cc05fc6405ba8f))
