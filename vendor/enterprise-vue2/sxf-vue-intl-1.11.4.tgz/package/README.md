# `@sxf/vue-intl`

一个用来格式化文本（可处理语言复数问题）、日期、时间以及数字的 i18n 库，用于 vue2。

## Contents

- [`@sxf/vue-intl`](#sxfvue-intl)
  - [Contents](#contents)
  - [Get Started](#get-started)
    - [Install](#install)
    - [Basic Example](#basic-example)
    - [Formatting](#formatting)
    - [Pluralization](#pluralization)
    - [DateTime localization](#datetime-localization)
    - [Number localization](#number-localization)
    - [Format RelativeTime](#format-relativetime)
    - [Rich Text](#rich-text)
      - [Escape Rich Text](#escape-rich-text)
    - [Interpolation Component](#interpolation-component)
      - [I18nIntl Component Props](#i18nintl-component-props)
    - [api](#api)
      - [createI18nIntl](#createi18nintl)
        - [options](#options)
      - [getConfig](#getconfig)
      - [getMessageById](#getmessagebyid)
      - [addMessages (deprecated)](#addmessages-deprecated)
  - [Polyfill](#polyfill)
    - [Install](#install-1)
    - [Usage](#usage)
  - [Typescript](#typescript)
    - [Version](#version)
    - [IDE Declaration Prompt](#ide-declaration-prompt)
  - [Compatibility](#compatibility)
  - [License](#license)

## Get Started

### Install

```sh
npm i @sxf/vue-intl -S

# or
yarn add @sxf/vue-intl -S
```

### Basic Example

```typescript
import Vue from 'vue'
import { VueI18nIntlPlugin, createVueI18nIntl } from '@sxf/vue-intl'

Vue.use(VueI18nIntlPlugin)

const i18nIntl = createVueI18nIntl({
  flatten: false,  // 词条对象没有拍平为一层，需要设置为 false
  locale: 'en-US',
  timeZone: 'Asia/Shanghai',
  messages: {
    app: {
      home: {
        header: 'header',
        footer: 'footer',
        page: 'header: {header}, footer: {footer}',
      },
    },
  },
})

new Vue({ i18nIntl }).$mount('#app')
```

### Formatting

语言环境信息如下：

```typescript
createVueI18nIntl({
  flatten: false,  // 词条对象没有拍平为一层，需要设置为 false
  locale: 'en-US',
  timeZone: 'Asia/Shanghai',
  messages: {
    app: {
      home: {
        hello: '{msg} world',
      },
    },
  },
})
```

模板如下：

```html
<p>{{ $i('app.home.hello', { msg: 'hello' }) }}</p>
```

输出如下：

```html
<p>hello world</p>
```

注：不支持 `{0}`、`{1}` 类型的数字占位格式，因为使用 `{variable}` 的 Named formatting 是可以携带语义化的信息传递给译员的。

### Pluralization

复数文本中使用的语法格式是一种国际通用的标准文本格式，可以跨编程语言使用。该语法格式名称为 [ICU Message](https://unicode-org.github.io/icu/userguide/format_parse/messages/)，使用的复数规则为 [CLDR](http://cldr.unicode.org/) 所定义。

**EN**

语言环境信息如下：

```typescript
{
  flatten: false,  // 词条对象没有拍平为一层，需要设置为 false
  locale: 'en-US',
  timeZone: 'Asia/Shanghai',
  messages: {
    app: {
      home: {
        select: 'select {count, plural, one {one message} other {# messages}}.',
      },
    },
  },
}
```

模板如下：

```html
<p>{{ $i('app.home.select', { count: 0 }) }}</p>
<p>{{ $i('app.home.select', { count: 1 }) }}</p>
<p>{{ $i('app.home.select', { count: 2 }) }}</p>
```

输出如下：

```html
<p>select 0 messages.</p>
<p>select one message.</p>
<p>select 2 messages.</p>
```

**ZH**

语言环境信息如下：

```typescript
{
  flatten: false,  // 词条对象没有拍平为一层，需要设置为 false
  locale: 'zh-Hans',
  timeZone: 'Asia/Shanghai',
  messages: {
    app: {
      home: {
        select: '选择{count}条信息。',
      },
    },
  },
}
```

模板如下：

```html
<p>{{ $i('app.home.select', { count: 0 }) }}</p>
<p>{{ $i('app.home.select', { count: 1 }) }}</p>
<p>{{ $i('app.home.select', { count: 2 }) }}</p>
```

输出如下：

```html
<p>选择0条信息。</p>
<p>选择1条信息。</p>
<p>选择2条信息。</p>
```

### DateTime localization

模板如下：

```html
<p>{{ $it(new Date(0)) }}</p>
<p>{{ $it(new Date(0), { hour12: true }) }}</p>
```

**EN**

输出如下：

```html
<p>08:00:00</p>
<p>08:00 AM</p>
```

**ZH**

输出如下：

```html
<p>08:00:00</p>
<p>上午08:00</p>
```

### Number localization

模板如下：

```html
<p>{{ $in(1000) }}</p>
<p>{{ $in(1000, {style: 'currency', currency: 'CNY'}) }}</p>
<p>{{ $in(1000, {style: 'currency', currency: 'USD'}) }}</p>
<p>{{ $in(1000, { style: 'unit', unit: 'kilobyte', unitDisplay: 'narrow'}) }}</p>
```

**EN**

输出如下：

```html
<p>1,000</p>
<p>$1,000.00</p>
<p>CN¥1,000.00</p>
<p>1,000kB</p>
```

**ZH**

输出如下：

```html
<p>1,000</p>
<p>¥1,000.00</p>
<p>US$1,000.00</p>
<p>1,000kB</p>
```

### Format RelativeTime

模板如下：

```html
<p>{{ $irt(-24, 'hour') }}</p>
```

**EN**

输出如下：

```html
<p>24 hours ago</p>
```

**ZH**

输出如下：

```html
<p>24小时前</p>
```

### Rich Text

词条无论任何时候都不应该包含  HTML/XHTML/XML 富文本，需要包含 HTML 标签可以使用 Interpolation Component。

因为解析规则遵循 [ICU Message](https://unicode-org.github.io/icu/userguide/format_parse/messages/), 所以 `<b></b>` 会被当成变量解析，且丢失 HTML tag 上的所有属性，不支持自闭合标签。

语言环境信息如下：

```typescript
{
  locale: 'en-US',
  timeZone: 'Asia/Shanghai',
  messages: {
    richText: 'hello <div>world</div>'
  },
}
```

模板如下：

```html
<p>$i('richText')</p>
```

输出如下：

```txt
Error: The intl string context variable "div" was not provided to the string "hello <div>world</div>"
```

#### Escape Rich Text

因为遵循 [ICU Message](https://unicode-org.github.io/icu/userguide/format_parse/messages/), 所以 `{}` 是保留字符，类似这样的保留字符可以使用 `'` 进行转义，撇号是 [ICU Message](https://unicode-org.github.io/icu/userguide/format_parse/messages/) 规定的 XML/HTML 标签转义语法。

语言环境信息如下：

```typescript
{
  locale: 'en-US',
  timeZone: 'Asia/Shanghai',
  messages: {
    richText: `hello '{}'`
  },
}
```

模板如下：

```html
<p>$i('richText')</p>
```

输出如下：

```html
<p>hello {}</p>
```

### Interpolation Component

有时候我们需要包含 HTML 标签或组件的语言环境信息进行本地化，可以使用 Interpolation Component：`<i18n-intl></i18n-intl>`。

例如：

```html
<label for="page">
  header: <a href="/header" target="_blank">header</a>, footer: <a href="/footer" target="_blank">footer</a>
</label>
```

语言环境信息如下：

```typescript
{
  locale: 'en-US',
  timeZone: 'Asia/Shanghai',
  messages: {
    app: {
      home: {
        header: 'header',
        footer: 'footer',
        page: 'header: {header}, footer: {footer}',
      },
    },
  },
}
```

模板如下：

```html
<i18n-intl path="app.home.page" tag="label" for="page">
  <template v-slot:header>
    <a href="/header" target="_blank">{{ $i('app.home.header') }}</a>
  </template>
  <template v-slot:footer>
    <a href="/footer" target="_blank">{{ $i('app.home.footer') }}</a>
  </template>
</i18n-intl>
```

输出如下：

```html
<label for="page">
  header: 
  <a href="/header" target="_blank">header</a>
  , footer: 
  <a href="/footer" target="_blank">footer</a>
</label>
```

#### I18nIntl Component Props

- `path {string}`: 词条路径
- `tag {string}`：可选，默认值 span
- 使用具名插槽进行变量插值，不要使用 `default` 默认插槽及 `default` 命名

### api

#### createI18nIntl

可以使用 `createVueI18nIntl` 创建 `i18nIntl` 对象获取多语言函数。

```js
const i18nIntl = createVueI18nIntl({
  locale: 'en-US',
  timeZone: 'Asia/Shanghai',
  messages: {},
})

const { $i } = i18nIntl
```

##### options

`createVueI18nIntl` 接收如下参数：

```ts
interface I18nIntlConfig {
  locale: I18nLocale                  // 语言
  messages: I18nIntlMessagesTree      // 词条对象
  timeZone?: string                   // 时区
  numberFormats?: I18nNumberFormats   // 数字格式
  dateTimeFormats?: {                 // 日期时间格式
    date: I18nDateTimeFormats
    time: I18nDateTimeFormats
  }
  defaultLocale?: I18nLocale          // 当前语言无法格式化时，回退的语言，默认为 en
  flatten?: boolean                   // 词条对象是否已拍平为一层，默认为 true
  onError?: OnErrorFn                 // 格式化过程发生错误时会调用此钩子
}
```

#### getConfig

`getConfig` 可以拿到当前的语言代码 `locale`、时区 `timeZone`、回退语言代码 `defaultLocale`、错误监听函数 `onError`

`Vue` 组件内调用如下：

```typescript
this.$i18nIntl.getConfig() // Object { locale, timeZone, defaultLocale, onError }
```

#### getMessageById

可以通过 `getMessageById` 来获取源词条。

语言环境信息如下：

```typescript
{
  locale: 'en-US',
  timeZone: 'Asia/Shanghai',
  messages: {
    title: 'title'
  },
}
```

`Vue` 组件内调用如下：

```typescript
this.$i18nIntl.getMessageById('title') // title
```

#### addMessages (deprecated)

**注意：该 api 已经在 `@sxf/vue-intl v1.10.0` 弃用！**

`addMessages` 可以在 `createI18nIntl` 初始化后添加词条。

语言环境信息如下：

```typescript
{
  locale: 'en-US',
  timeZone: 'Asia/Shanghai',
  messages: {},
}
```

`Vue` 组件内调用如下：

```typescript
this.$i18nIntl.getMessageById('title') // undefined
this.$i18nIntl.addMessages({ title: 'title' }) // true
this.$i18nIntl.getMessageById('title') // title
```

## Polyfill

因为 ECMA402-International 标准较新，且一直在更新，所以需要使用 polyfills， 请按下图顺序引入。

使用由 [formatjs](https://github.com/formatjs/formatjs) 维护的支持最新标准的 polyfill。

### Install

可以使用 `i18n-next` 维护的 polyfill: (@sxf/intl-polyfill)[http://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/tree/master/packages/intl-polyfill]

```sh
npm i @sxf/intl-polyfill -S

# or
yarn add @sxf/intl-polyfill -S
```

### Usage

按顺序引入相应垫片，按需引入。

```js
import '@sxf/intl-polyfill'
import '@sxf/intl-polyfill/dist/locale-data/en-US'
import '@sxf/intl-polyfill/dist/locale-data/zh-CN'
```

## Typescript

### Version

`Typescript` 版本必须为 `4.2` 及以上，用 `sfx2` 打包的话，`sfx2` 的 `typescript` 版本也得是 `4.2` 及以上。

### IDE Declaration Prompt

如有需要，可以使用 `typescript@4.1.0` 版本及以上的字符串模板类型进行 IDE 提示。

推荐使用 vs code 插件：[i18n-assistant](http://code.sangfor.org/UED/FE-COMMON/PACKAGE/i18n-next/tree/master/extension/i18n-assistant)

点击 [Typescript Playground](https://www.typescriptlang.org/play?#code/C4TwDgpgBAkgjADgHYGUD2BXATgYwgFSwmgF4oBvAKCigG0BrCEALigGdgsBLJAcwF1W8ZOmx5CxKAB92nHrwDclAL6VKoSLERIYSYABsUACwCGkADzDUmXASIQAfFDJUaXbQFkIbNid4QACi4AEyFtUVsJCAAFE2AjNktwm3F7BwBKVg5uPhU1DWgrAGE0JAAzLl4kkRS7YicXanZatjCasTqIPMpgiBx9EyIoMowkHGAuUqh3ZF0uYGrrDqiHAKacMt42pBLyysWI1PrKTK1ZvUNTCytDzod88GgAKTQecwBpABooaIaod6gEAAHsAIEhgmxZDleFAAPxNGjRQEgsEQqHyOEIqAAAwAJOR3sp8QByYnI0HgyFI2FQUlQVjEgB0xKJ5GiymxWNYSAgADcIFh6VAefysA9NDdalFYvFEvg-vhyajIZLlvZMTQaOQ6ACeFBGCA0GUoPhBP8lZT0XwNZrbXiCRzpFAXm8vmclpF7DKEuZ8LR3vwHPdbbbuXyBVjlAwmEaTfwhaS1DhShx3boDMYzKRpto5sAAq5mh1WhQsWYwKxC7ajGgALYQStY20TAwN2kt-QQYlNqDKT49kzBWs8RshzVIEz10djzUDABGEH0DPni+7M97PdUtq3G+U6TUVnTlyzjJmSC8Pj8gWJ5cZNfrjI7Xf3QA) 前往查看效果。

```typescript
type I18nSourceTree = {
  [key: string]: I18nSourceTree | string;
}

type I18nIntlShape<I18nSourceTree> = {
  i18nMessage(id: I18nSourceTreePaths<I18nSourceTree>): string
}

type I18nConfig<I18nSourceTree> = {
  sources: I18nSourceTree
}

declare function i18nInit<I18nSourceTree>(
  cfg: I18nConfig<I18nSourceTree>
): I18nIntlShape<I18nSourceTree>

type Join<K, P> = K extends string ?
    P extends string ?
    `${K}${'' extends P ? '' : '.'}${P}`
    : never : never

type I18nSourceTreePaths<T> = T extends I18nSourceTree ?
    { [K in keyof T]: K extends string ?
        `${K}` | Join<K, I18nSourceTreePaths<T[K]>>
        : never
    }[keyof T] : ''

const I18nIntlShape = i18nInit({
  sources: {
    app: {
      home: {
        title: 'title'
      },
      admin: {
        name: {
          label: 'label'
        }
      }
    }
  }
})

/* 
(method) i18nMessage(id: "app" | "app.home" | "app.admin" | "app.home.title" | "app.admin.name" | "app.admin.name.label"): string
*/
I18nIntlShape.i18nMessage('app.home.title')
```

## Compatibility

- Chrome 49
- Firefox 52
- Safari 11
- IE 11
- Edge 12
- node v14

## License

[MIT](http://opensource.org/licenses/MIT)
