const Q = function(window2, document2, undefined$1) {
  function _9q(t, e, i) {
    if (t.hasChildren()) {
      var n = t._fv || t.getChildren();
      if (n) {
        n = n._jf || n;
        for (var o = 0, s = n.length; s > o; o++)
          if (e.call(i, n[o]) === false || _9q(n[o], e, i) === false)
            return false;
        return true;
      }
    }
  }
  function _g9(t) {
    if (!t.hasChildren())
      return t instanceof Node ? t : null;
    for (var e, i = t._fv._jf, n = i.length - 1; n >= 0; ) {
      if (e = i[n], e = _g9(e))
        return e;
      n--;
    }
    return null;
  }
  function _2t(t, e, i, n) {
    return n ? _$b(t, e, i) : _$i(t, e, i);
  }
  function _$b(t, e, i) {
    t = t._jf || t;
    for (var n, o = 0, s = t.length; s > o; o++)
      if (n = t[o], n.hasChildren() && !_$b(n.children, e, i) || e.call(i, n) === false)
        return false;
    return true;
  }
  function _$i(t, e, i) {
    t = t._jf || t;
    for (var n, o = 0, s = t.length; s > o; o++)
      if (n = t[o], e.call(i, n) === false || n.hasChildren() && !_$i(n.children, e, i))
        return false;
    return true;
  }
  function _$r(t, e, i, n) {
    return n ? _1(t, e, i) : _3(t, e, i);
  }
  function _1(t, e, i) {
    t = t._jf || t;
    for (var n, o = t.length, s = o - 1; s >= 0; s--)
      if (n = t[s], n.hasChildren() && !_1(n.children, e, i) || e.call(i, n) === false)
        return false;
    return true;
  }
  function _3(t, e, i) {
    t = t._jf || t;
    for (var n, o = t.length, s = o - 1; s >= 0; s--)
      if (n = t[s], e.call(i, n) === false || n.hasChildren() && !_3(n.children, e, i))
        return false;
    return true;
  }
  function _1j(t, e, i) {
    for (var n, o = (t._jf || t).slice(0); o.length; ) {
      n = o[0], o = o.splice(1);
      var s = e.call(i, n);
      if (s === false)
        return false;
      if (n.hasChildren()) {
        var r = n.children;
        r = r._jf || r, o = o.concat(r);
      }
    }
    return true;
  }
  function _$a(t, e, i) {
    for (var n, o = (t._jf || t).slice(0); o.length; ) {
      n = o[o.length - 1], o = o.splice(0, o.length - 1);
      var s = e.call(i, n);
      if (s === false)
        return false;
      if (n.hasChildren()) {
        var r = n.children;
        r = r._jf || r, o = o.concat(r);
      }
    }
    return true;
  }
  function stableSortMerge(t, e) {
    function i(t2, i2) {
      for (var n2 = t2.length, o = i2.length, s = n2 + o, r = new Array(s), a = 0, h = 0, l = 0; s > l; )
        r[l++] = a === n2 ? i2[h++] : h === o || e(t2[a], i2[h]) <= 0 ? t2[a++] : i2[h++];
      return r;
    }
    function n(t2) {
      var e2 = t2.length, o = Math.ceil(e2 / 2);
      return 1 >= e2 ? t2 : i(n(t2.slice(0, o)), n(t2.slice(o)));
    }
    return n(t);
  }
  function _ic(t, e, i, n) {
    t instanceof HashList && (t = t._jf);
    for (var o = 0, s = (t._jf || t).length; s > o; o++) {
      var r = e.call(i, t[o], o, n);
      if (r === false)
        return false;
    }
    return true;
  }
  function _mo6(t, e, i) {
    for (var n = t instanceof HashList, o = t._jf || t, s = 0, r = o.length; r > s; s++) {
      var a = o[s];
      e.call(i, a) && (n ? t.remove(a) : t.splice(s, 1), s--, r--);
    }
  }
  function _6p(t, e, i, n) {
    t instanceof HashList && (t = t._jf);
    for (var o = (t._jf || t).length - 1; o >= 0; o--) {
      var s = e.call(i, t[o], o, n);
      if (s === false)
        return false;
    }
    return true;
  }
  function _d7(t) {
    if (t.clone instanceof Function)
      return t.clone(true);
    var e, i = [];
    return _ic(
      t,
      function(t2) {
        e = t2 && t2.clone instanceof Function ? t2.clone() : t2, i.push(e);
      },
      this
    ), i;
  }
  function _m9(t, e, i) {
    void 0 === i || 0 > i ? t.push(e) : t.splice(i, 0, e);
  }
  function _jh(t, e) {
    var i = t.indexOf(e);
    return 0 > i || i >= t.length ? false : t.splice(i, 1);
  }
  function containsInArray(t, e) {
    var i = false;
    return _ic(t, function(t2) {
      return e == t2 ? (i = true, false) : void 0;
    }), i;
  }
  function _fa(t, e, i) {
    return e instanceof Object ? t = _7g(e, t) : e && !i && (i = parseInt(e)), e && !i && (i = parseInt(e)), i ? setTimeout(t, i) : setTimeout(t);
  }
  function _dl(t, e) {
    return e && (t = _7g(e, t)), window2.requestAnimationFrame(t);
  }
  function _g7(t, e) {
    return t.className = e, t;
  }
  function _mkg(t, e) {
    if (!t.hasOwnProperty("classList")) {
      var i = t.getAttribute("class");
      if (!i)
        return _g7(t, e);
      for (var n = i.split(" "), o = 0, s = n.length; s > o; o++)
        if (n[o] == e)
          return;
      return i += " " + e, _g7(t, i);
    }
    t.classList.add(e);
  }
  function _mkz(t, e) {
    if (!t.hasOwnProperty("classList")) {
      var i = t.getAttribute("class");
      if (!i || !i.indexOf(e))
        return;
      for (var n = "", o = i.split(" "), s = 0, r = o.length; r > s; s++)
        o[s] != e && (n += o[s] + " ");
      return _g7(t, n);
    }
    t.classList.remove(e);
  }
  function _gd(t) {
    return t instanceof Number || "number" == typeof t;
  }
  function _ho(t) {
    return void 0 !== t && (t instanceof String || "string" == typeof t);
  }
  function _f5(t) {
    return void 0 !== t && (t instanceof Boolean || "boolean" == typeof t);
  }
  function _ig(t) {
    return Array.isArray(t);
  }
  function _2p(t) {
    t || (t = window2.event), t.preventDefault ? t.preventDefault() : t.returnValue = false;
  }
  function _1s(t) {
    t || (t = window2.event), t.stopPropagation ? t.stopPropagation() : t.cancelBubble || (t.cancelBubble = true);
  }
  function _f1(t) {
    _2p(t), _1s(t);
  }
  function _ee(t) {
    return Math.floor(Math.random() * t);
  }
  function _d9() {
    return Math.random() >= 0.5;
  }
  function _gh(t, e) {
    var i = t;
    for (var n in e)
      if (e.__lookupGetter__) {
        var o = e.__lookupGetter__(n), s = e.__lookupSetter__(n);
        o || s ? (o && i.__defineGetter__(n, o), s && i.__defineSetter__(n, s)) : i[n] = e[n];
      } else
        i[n] = e[n];
    return i;
  }
  function _jq(t, e, i) {
    if (!(t instanceof Function))
      throw new Error("subclass must be type of Function");
    var n = null;
    "object" == typeof e && (n = e, e = t, t = function() {
      e.apply(this, arguments);
    });
    var o = t.prototype, s = function() {
    };
    return s.prototype = e.prototype, t.prototype = new s(), t.superclass = e.prototype, t.superclass.constructor = e, _gh(t.prototype, o), n && _gh(t.prototype, n), i && _gh(t.prototype, i), t.prototype.class = t, t;
  }
  function _3g(t, e, i) {
    return _hr(t, e, "constructor", i);
  }
  function _hr(t, e, i, n) {
    var o = e.superclass;
    if (o) {
      var s = o[i];
      return s ? s.apply(t, n) : void 0;
    }
  }
  function _9w(t) {
    return t.toFixed(4);
  }
  function _7d(t) {
    delete t.scope, delete t.handle;
  }
  function _6y(t, e) {
    t[e] && (_7d(t[e]), delete t[e]);
  }
  function _7g(t, e) {
    var i = function() {
      return i.handle.apply(i.scope, arguments);
    };
    return i.handle = e, i.scope = t, i;
  }
  function _kd(t, e) {
    return t == e;
  }
  function _mkx(t, e, i, n, o) {
    if (n)
      return void Object.defineProperty(t, e, { value: i, enumerable: true });
    var s = { configurable: true, enumerable: true }, r = "$" + e;
    void 0 !== i && (t[r] = i), s.get = function() {
      return this[r];
    }, s.set = function(t2) {
      var i2 = this[r];
      if (_kd(i2, t2))
        return false;
      var n2 = new PropertyChangeEvent(this, e, t2, i2);
      return this.beforeEvent(n2) ? (this[r] = t2, o && o.call(this, t2, i2), this.onEvent(n2), true) : false;
    }, Object.defineProperty(t, e, s);
  }
  function _8y(t, e) {
    for (var i = 0, n = e.length; n > i; i++) {
      var o = e[i];
      _mkx(t, o.name || o, o.defaultValue || o.value, o.readOnly, o.onSetting);
    }
  }
  function _mko(t) {
    if (t && t > 0 && 1 > t) {
      var e = Math.floor(16777215 * Math.random());
      return "rgba(" + (e >> 16 & 255) + "," + (e >> 8 & 255) + "," + (255 & e) + "," + t.toFixed(2) + ")";
    }
    return _ia(Math.floor(16777215 * Math.random()));
  }
  function _mm3(t) {
    return t > 0 ? Math.floor(t) : Math.ceil(t);
  }
  function _g1(t) {
    return t > 0 ? Math.ceil(t) : Math.floor(t);
  }
  function _ia(t) {
    return 16777216 > t ? "#" + ("000000" + t.toString(16)).slice(-6) : "rgba(" + (t >> 16 & 255) + "," + (t >> 8 & 255) + "," + (255 & t) + "," + ((t >> 24 & 255) / 255).toFixed(2) + ")";
  }
  function _6u(t, e, i) {
    "object" != typeof i || i.hasOwnProperty("enumerable") || (i.enumerable = true), Object.defineProperty(t, e, i);
  }
  function _4u(t, e) {
    for (var i in e)
      if ("_" != i[0]) {
        var n = e[i];
        "object" != typeof n || n.hasOwnProperty("enumerable") || (n.enumerable = true);
      }
    Object.defineProperties(t, e);
  }
  function stringToObject(t, e) {
    e || (e = window2);
    for (var i = t.split("."), n = 0, o = i.length; o > n; n++) {
      var s = i[n];
      e = e[s];
    }
    return e;
  }
  function isMouseEvent(t) {
    return t instanceof MouseEvent || t instanceof Object && void 0 !== t.touches;
  }
  function _m3(t) {
    window2.console && console.log(t);
  }
  function _l9(t) {
    window2.console && console.trace(t);
  }
  function _l8(t) {
    window2.console && console.error(t);
  }
  function perpendicularLine(t, e, i) {
    var n, o, s;
    0 == t._mk ? (n = -1, s = 0, o = e) : 0 == t._mm ? (n = 0, s = 1, o = i) : (n = -1 / t._mk, o = (t._mk - n) * e + t._mo, s = 1);
    var r = new Line();
    return r._mk = n, r._mo = o, r._mm = s, r._mg = e, r._mb = i, r._ko = Math.atan2(n, s), r._mmos = Math.cos(r._ko), r._sin = Math.sin(r._ko), r;
  }
  function getIntersectionPointOnRect(t, e, i, n, o) {
    var s, r;
    e > n ? s = -1 : n > e && (s = 1), i > o ? r = -1 : o > i && (r = 1);
    var a, h;
    if (!s)
      return h = 0 > r ? t.y : t.bottom, { x: e, y: h };
    if (!r)
      return a = 0 > s ? t.x : t.right, { x: a, y: i };
    var l = (i - o) / (e - n), _ = i - l * e, u = 0 > s ? e - t.x : e - t.right, d = 0 > r ? i - t.y : i - t.bottom;
    return Math.abs(l) >= Math.abs(d / u) ? (h = 0 > r ? t.y : t.bottom, a = (h - _) / l) : (a = 0 > s ? t.x : t.right, h = l * a + _), {
      x: a,
      y: h
    };
  }
  function intersectsRect(t, e, i, n, o, s, r, a) {
    return 0 >= r || 0 >= a || 0 >= i || 0 >= n ? false : (r += o, a += s, i += t, n += e, (o > r || r > t) && (s > a || a > e) && (t > i || i > o) && (e > n || n > s));
  }
  function intersectsPoint(t, e, i, n, o, s) {
    return o >= t && t + i >= o && s >= e && e + n >= s;
  }
  function containsRect(t, e, i, n, o, s, r, a) {
    return o >= t && s >= e && t + i >= o + r && e + n >= s + a;
  }
  function _mkr(t, e, i) {
    if (!t)
      return { x: 0, y: 0 };
    if (void 0 !== t.x)
      return { x: t.x, y: t.y };
    var n, o, s = t.horizontalPosition, r = t.verticalPosition;
    switch (s) {
      case LEFT:
        n = 0;
        break;
      case RIGHT:
        n = e;
        break;
      default:
        n = e / 2;
    }
    switch (r) {
      case TOP:
        o = 0;
        break;
      case BOTTOM:
        o = i;
        break;
      default:
        o = i / 2;
    }
    return { x: n, y: o };
  }
  function doChildAdd(t, e, i) {
    t.children.add(e, i), t.onChildAdd(e, i);
  }
  function doChildRemove(t, e) {
    t._fv && (t._fv.remove(e), t.onChildRemove(e));
  }
  function css_mmamelCase(t) {
    return t.replace(/^-ms-/, "ms-").replace(/-([\da-z])/gi, function(t2, e) {
      return e.toUpperCase();
    });
  }
  function css_pascalCase(t) {
    return t.replace(/[A-Z]/g, function(t2) {
      return "-" + t2.toLowerCase();
    }).replace(/^ms-/, "-ms-");
  }
  function css_mmss(t, e) {
    var i = t.style;
    if (!i)
      return false;
    var n, o;
    for (n in e)
      e.hasOwnProperty(n) && (o = css_pre(n)) && (i[o] = e[n]);
    return t;
  }
  function css_toString(t) {
    var e, i, n = "";
    for (e in t)
      t.hasOwnProperty(e) && (i = css_pre(e)) && (n += css_pascalCase(i) + ":" + t[e] + ";");
    return n ? n.substring(0, n.length - 1) : n;
  }
  function css_m8CSS(t, e, i) {
    (e = css_pre(e)) && (t.style[e] = i);
  }
  function css_m9Rule(t, e) {
    return css_styleSheet ? (e && !_ho(e) && (e = css_toString(e)), css_styleSheet.insertRule ? void css_styleSheet.insertRule(t + "{" + e + "}", 0) : void (css_styleSheet.addRule && css_styleSheet.addRule(t, e, 0))) : false;
  }
  function _88(t, e) {
    t.touches && (t = t.changedTouches && t.changedTouches.length ? t.changedTouches[0] : t.touches[0]);
    var i = e.getBoundingClientRect(), n = t.clientX || 0, o = t.clientY || 0;
    return isTouchSupport && isSafari && (window2.pageXOffset && n == t.pageX && (n -= window2.pageXOffset), window2.pageYOffset && o == t.pageY && (o -= window2.pageYOffset)), {
      x: n - i.left,
      y: o - i.top
    };
  }
  function addEventListenerSupport(t, e) {
    return this["$" + e] = _4s(
      t,
      e,
      function(t2) {
        return onEventSupport.call(this, t2, e);
      },
      false,
      this
    );
  }
  function toQEvent(t) {
    var e = this;
    return t.getData = function() {
      return e._l6.getElementByMouseEvent(t);
    }, t.getUI = function() {
      return e._l6.getUIByMouseEvent(t);
    }, t;
  }
  function _ie(t) {
    this.__mmancelClick || (this.__mmlickEvent = t, this.__mmlickTime ? this.__mmlickTime++ : (this.__mmlickTime = 1, setTimeout(
      _7g(this, function() {
        if (this.__mmlickEvent) {
          var t2 = this.__mmlickTime;
          this.__mmlickTime = 0, 1 == t2 ? this._hy(this.__mmlickEvent, "onclick") : t2 > 1 && this._hy(this.__mmlickEvent, "ondblclick"), this.__mmlickEvent = null;
        }
      }),
      Defaults.DOUBLE_CLICK_INTERVAL_TIME
    )));
  }
  function _g4(t) {
    if (t.touches) {
      for (var e = t.touches, i = [], n = 0, o = e.length; o > n; n++) {
        var s = e[n];
        i.push({ pageX: s.pageX, pageY: s.pageY, clientX: s.clientX, clientY: s.clientY });
      }
      return { timeStamp: t.timeStamp, touches: i, scale: t.scale };
    }
    return { timeStamp: t.timeStamp, x: t.clientX, y: t.clientY };
  }
  function onEventSupport(t, e) {
    switch (t = toQEvent.call(this, t), e) {
      case "touchstart":
        if (t.touches.length >= 2)
          return this._9g = _g4(t), this._mmp.clear(), this._1z(), void (this._mmz || (this._mmz = t, this._9g = _g4(t)));
      case "mousedown":
        if (_f1(t), this._hy(t, "onstart"), this._mmz = t, this._9g = _g4(t), t.button || (this.__onLongPressFunction ? this.__longPressTimer && this._1z() : this.__onLongPressFunction = _7g(this, function() {
          this.__longPressTimer = null, this._mmz && (this.__mmancelClick = true, this._hy(this._mmz, "onlongpress"));
        }), this.__longPressTimer = setTimeout(this.__onLongPressFunction, Defaults.LONG_PRESS_INTERVAL), this.__mmancelClick = false), isTouchSupport)
          return;
        return void (InteractionSupport._mmurrentInteractionSupport = this);
      case "touchend":
        if (!this._mmz)
          return void (this._moving = null);
        if (t.touches.length)
          return void (this._9g = _g4(t));
        t.timeStamp - this._mmz.timeStamp < 200 && _ie.call(this, this._mmz);
      case "touchcancel":
        if (!this._mmz)
          return void (this._moving = null);
        this._moving && (this._moving = null, this._if(t));
      case "mouseup":
        return void this._dt(t);
      case "click":
        return void _ie.call(this, t);
      case "mousewheel":
      case "DOMMouseScroll":
        return t.delta = t.wheelDelta || -t.detail, this._hy(t, "onmousewheel");
      case "touchmove":
        var i = t.touches.length;
        return this._moving || (this._moving = true, 1 == i && this._dr()), void this._k0(t);
    }
    return this._hy(t, "on" + e);
  }
  function removeEventListenerSupport(t, e) {
    var i = "$" + e;
    _2j(t, e, this[i]), _6y(this, i);
  }
  function addEventListenersSupport(t) {
    _ic(
      EVENT_TYPES,
      function(e) {
        addEventListenerSupport.call(this, t, e);
      },
      this
    ), isTouchSupport || InteractionSupport._mkd || (InteractionSupport._mkd = true, _4s(
      window2,
      "mousemove",
      function(t2) {
        if (InteractionSupport._mmurrentInteractionSupport) {
          _f1(t2);
          var e = InteractionSupport._mmurrentInteractionSupport;
          if (!InteractionSupport._dragging) {
            if (e._mmz) {
              var i = e._mmz.screenX - t2.screenX, n = e._mmz.screenY - t2.screenY;
              if (4 > i * i + n * n)
                return;
            }
            InteractionSupport._dragging = true, e._dr();
          }
          e._k0(t2);
        }
      },
      true
    ), _4s(
      window2,
      "mouseup",
      function(t2) {
        var e = InteractionSupport._mmurrentInteractionSupport;
        delete InteractionSupport._mmurrentInteractionSupport, InteractionSupport._dragging && (delete InteractionSupport._dragging, _2p(t2), t2 = toQEvent.call(e, t2), e._if(t2), e._dt(t2));
      },
      true
    ));
  }
  function clearEventListenersSupport(t) {
    _ic(
      EVENT_TYPES,
      function(e) {
        removeEventListenerSupport.call(this, t, e);
      },
      this
    ), isTouchSupport || (InteractionSupport._mmurrentInteractionSupport == this && (delete InteractionSupport._dragging, delete InteractionSupport._mmurrentInteractionSupport), this._1z(), delete this._mmz, delete this._9g);
  }
  function DragSupport(t, e, i) {
    this._m2 = t, this._mmp = new DragPoints(), addEventListenersSupport.call(this, t), e && (this._listener = e), this._l1 = i;
  }
  function isMetaKey(t) {
    return isMac && t.metaKey || !isMac && t.ctrlKey;
  }
  function DragPoints() {
    this.points = [];
  }
  function loadXML(t, e, i, n, o) {
    loadURL(
      t,
      function(n2) {
        if (e) {
          var o2 = n2.responseXML;
          if (!o2)
            return void (i || ON_AJAX_ERROR)("'" + t + "' XML format error.");
          e(o2);
        }
      },
      i,
      n,
      o
    );
  }
  function loadJSON(t, e, i, n, o) {
    loadURL(
      t,
      function(n2) {
        if (e) {
          var o2, s = n2.responseText;
          if (!s)
            return (i || ON_AJAX_ERROR)("'" + t + "' JSON format error."), o2 = new Error("'" + t + "' JSON format error."), e(s, o2);
          try {
            s = JSON.parse(s);
          } catch (r) {
            (i || ON_AJAX_ERROR)(r), o2 = r;
          }
          e(s, o2);
        }
      },
      i,
      n,
      o
    );
  }
  function loadURL(t, e, i, n, o) {
    (i === false || n === false) && (o = false);
    try {
      var s = new XMLHttpRequest(), r = encodeURI(t);
      if (o !== false) {
        var a;
        a = r.indexOf("?") > 0 ? "&" : "?", r += a + "__time=" + Date.now();
      }
      s.open("GET", r), s.onreadystatechange = function() {
        return 4 == s.readyState ? s.status && 200 != s.status ? void (i || ON_AJAX_ERROR)("'" + t + "' load error") : void (e && e(s)) : void 0;
      }, s.send(n);
    } catch (h) {
      (i || ON_AJAX_ERROR)("'" + t + "' load error", h);
    }
  }
  function intersectsRect(t, e, i, n, o, s, r, a) {
    return 0 >= r || 0 >= a || 0 >= i || 0 >= n ? false : (r += o, a += s, i += t, n += e, (o > r || r > t) && (s > a || a > e) && (t > i || i > o) && (e > n || n > s));
  }
  function containsRect(t, e, i, n, o, s, r, a) {
    return o >= t && s >= e && t + i >= o + r && e + n >= s + a;
  }
  function rotatePoint(t, e, i) {
    return t instanceof Object && t.x ? rotateThePointAt(t, e, 0, 0) : rotatePointAt(t, e, i, 0, 0);
  }
  function rotatePointAt(t, e, i, n, o) {
    var s = Math.sin(i), r = Math.cos(i), a = t - n, h = e - o;
    return t = a * r - h * s + n, e = a * s + h * r + o, new Point(t, e, i);
  }
  function rotateThePointAt(t, e, i, n) {
    i = i || 0, n = n || 0;
    var o = Math.sin(e), s = Math.cos(e), r = t.x - i, a = t.y - n;
    return t.x = r * s - a * o + i, t.y = r * o + a * s + n, t;
  }
  function rotateRect(t, e, i) {
    return rotateRectAt(t, e, i, 0, 0);
  }
  function rotateRectAt(t, e, i, n, o) {
    var s = rotatePointAt(t.x, t.y, e, n, o), r = rotatePoint(t.x + t.width, t.y, e), a = rotatePoint(t.x + t.width, t.y + t.height, e), h = rotatePoint(t.x, t.y + t.height, e);
    return i ? i.clear() : i = new Rect(), i.addPoint(s), i.addPoint(r), i.addPoint(a), i.addPoint(h), i;
  }
  function setCanvasSize(t, e) {
    var i = this.ratio || 1;
    this.style.width = t + "px", this.style.height = e + "px", this.width = t * i, this.height = e * i;
  }
  function clearCanvas() {
    this.canvas.width = this.canvas.width;
  }
  function _h6(t) {
    var e = t.webkitBackingStorePixelRatio || t.mozBackingStorePixelRatio || t.msBackingStorePixelRatio || t.oBackingStorePixelRatio || t.backingStorePixelRatio || 1;
    return devicePixelRatio2 / e;
  }
  function _mkc(t, e, i) {
    var n = document2.createElement("canvas");
    if (n.g = n.getContext("2d"), t !== true && !i)
      return t && e && (n.width = t, n.height = e), n;
    var o = n.g;
    return o.ratio = n.ratio = _h6(o), n.setSize = setCanvasSize, o._kt = clearCanvas, t && e && n.setSize(t, e), n;
  }
  function _18(t, e, i) {
    if (void 0 === t || null === t)
      return { width: 0, height: 0 };
    var n = getTempG();
    i = i || Defaults.FONT, n.font != i && (n.font = i);
    for (var o = e * Defaults.LINE_HEIGHT, s = 0, r = 0, a = t.split("\n"), h = 0, l = a.length; l > h; h++) {
      var _ = a[h];
      s = Math.max(n.measureText(_).width, s), r += o;
    }
    return { width: s, height: r };
  }
  function getTempG(t, e) {
    return _mm9 || (_mm9 = _mkc()), t && e && (_mm9.width = t, _mm9.height = e), _mm9.g;
  }
  function asinh(t) {
    return Math.log(t + Math.sqrt(t * t + 1));
  }
  function caculateCurveTByLengthFunction(t, e) {
    e = e || t(1);
    var i = 1 / e, n = 0.5 * i, o = Math.min(1, e / 100);
    return function(s) {
      if (0 >= s)
        return 0;
      if (s >= e)
        return 1;
      for (var r = s * i, a = 0; a++ < 10; ) {
        var h = t(r), l = s - h;
        if (Math.abs(l) <= o)
          return r;
        r += l * n;
      }
      return r;
    };
  }
  function pointOnQuadratic(t, e, i) {
    var n = 1 - t, o = n * n * e[0] + 2 * n * t * e[2] + t * t * e[4], s = n * n * e[1] + 2 * n * t * e[3] + t * t * e[5];
    if (i) {
      var r = (e[0] + e[4] - 2 * e[2]) * t + e[2] - e[0], a = (e[1] + e[5] - 2 * e[3]) * t + e[3] - e[1];
      return { x: o, y: s, rotate: Math.atan2(a, r) };
    }
    return { t, x: o, y: s };
  }
  function derivQuadraticCurve(t, e, i) {
    var n = t - 2 * e + i;
    return 0 != n ? (t - e) / n : -1;
  }
  function calculateQuadraticCurveBounds(t, e) {
    e.add(t[4], t[5]);
    var i = derivQuadraticCurve(t[0], t[2], t[4]);
    if (i > 0 && 1 > i) {
      var n = pointOnQuadratic(i, t);
      e.add(n.x, n.y);
    }
    var o = derivQuadraticCurve(t[1], t[3], t[5]);
    if (o > 0 && 1 > o) {
      var n = pointOnQuadratic(o, t);
      e.add(n.x, n.y);
    }
    return e;
  }
  function caculateQuadraticCurveLengthFunction(t) {
    if (t[0] == t[2] && t[1] == t[3] || t[1] == t[3] && t[1] == t[5]) {
      var e = t[0], i = t[1], n = t[4], o = t[5], s = Math.sqrt(calculateDistanceSquare(e, i, n, o));
      return function(t2) {
        return s * t2;
      };
    }
    var r = t[0], a = t[2], h = t[4], l = r - 2 * a + h, _ = 2 * a - 2 * r;
    r = t[1], a = t[3], h = t[5];
    var u = r - 2 * a + h, d = 2 * a - 2 * r, c = 4 * (l * l + u * u), f = 4 * (l * _ + u * d), E = _ * _ + d * d, s = 4 * c * E - f * f, g = 1 / s, p = 0.125 * Math.pow(c, -1.5), v = 2 * Math.sqrt(c), T = (s * asinh(f / Math.sqrt(s)) + 2 * Math.sqrt(c) * f * Math.sqrt(E)) * p;
    return function(t2) {
      var e2 = f + 2 * t2 * c, i2 = e2 / Math.sqrt(s), n2 = e2 * e2 * g;
      return (s * Math.log(i2 + Math.sqrt(n2 + 1)) + v * e2 * Math.sqrt(E + t2 * f + t2 * t2 * c)) * p - T;
    };
  }
  function pointOnBezier(t, e, i) {
    var n = 1 - t, o = e[0], s = e[2], r = e[4], a = e[6], h = o * n * n * n + 3 * s * t * n * n + 3 * r * t * t * n + a * t * t * t;
    if (i)
      var l = 3 * t * t * a + (6 * t - 9 * t * t) * r + (9 * t * t - 12 * t + 3) * s + (-3 * t * t + 6 * t - 3) * o;
    o = e[1], s = e[3], r = e[5], a = e[7];
    var _ = o * n * n * n + 3 * s * t * n * n + 3 * r * t * t * n + a * t * t * t;
    if (i) {
      var u = 3 * t * t * a + (6 * t - 9 * t * t) * r + (9 * t * t - 12 * t + 3) * s + (-3 * t * t + 6 * t - 3) * o;
      return { x: h, y: _, rotate: Math.atan2(u, l) };
    }
    return { x: h, y: _ };
  }
  function derivBezierCurve(t, e, i, n) {
    var o = -t + 3 * e - 3 * i + n;
    if (0 == o)
      return [(t - e) / (2 * i - 4 * e + 2 * t)];
    var s = 2 * t - 4 * e + 2 * i, r = e - t, a = s * s - 4 * o * r;
    return 0 > a ? void 0 : 0 == a ? [-s / (2 * o)] : (a = Math.sqrt(a), [(a - s) / (2 * o), (-a - s) / (2 * o)]);
  }
  function calculateBezierCurveBounds(t, e) {
    e.add(t[6], t[7]);
    var i = derivBezierCurve(t[0], t[2], t[4], t[6]);
    if (i)
      for (var n = 0; n < i.length; n++) {
        var o = i[n];
        if (!(0 >= o || o >= 1)) {
          var s = pointOnBezier(o, t);
          e.add(s.x, s.y);
        }
      }
    if (i = derivBezierCurve(t[1], t[3], t[5], t[7]))
      for (var n = 0; n < i.length; n++) {
        var o = i[n];
        if (!(0 >= o || o >= 1)) {
          var s = pointOnBezier(o, t);
          e.add(s.x, s.y);
        }
      }
  }
  function caculateBezierCurveLength2(t) {
    var e = { x: t[0], y: t[1] }, i = { x: t[2], y: t[3] }, n = { x: t[4], y: t[5] }, o = {
      x: t[6],
      y: t[7]
    }, s = e.x - 0, r = e.y - 0, a = i.x - 0, h = i.y - 0, l = n.x - 0, _ = n.y - 0, u = o.x - 0, d = o.y - 0, c = 3 * (-s + 3 * a - 3 * l + u), f = 6 * (s - 2 * a + l), E = 3 * (-s + a), g = 3 * (-r + 3 * h - 3 * _ + d), p = 6 * (r - 2 * h + _), v = 3 * (-r + h), T = function(t2) {
      var e2 = c * t2 * t2 + f * t2 + E, i2 = g * t2 * t2 + p * t2 + v;
      return Math.sqrt(e2 * e2 + i2 * i2);
    }, m = (T(0) + 4 * T(0.5) + T(1)) / 6;
    return m;
  }
  function caculateBezierCurveLengthFunction(t, e) {
    function i(t2, e2, i2, n2) {
      var o2 = -t2 + 3 * e2 - 3 * i2 + n2, s2 = 2 * t2 - 4 * e2 + 2 * i2, r2 = e2 - t2;
      return function(t3) {
        return 3 * (o2 * t3 * t3 + s2 * t3 + r2);
      };
    }
    function n(t2, e2) {
      var i2 = o(t2), n2 = s(t2);
      return Math.sqrt(i2 * i2 + n2 * n2) * e2;
    }
    var o = i(t[0], t[2], t[4], t[6]), s = i(t[1], t[3], t[5], t[7]);
    e = e || 100;
    var r = 1 / e;
    return function(t2) {
      if (!t2)
        return 0;
      for (var e2, i2 = 0, o2 = 0; ; ) {
        if (e2 = i2 + r, e2 >= t2)
          return o2 += n(i2, e2 - i2);
        o2 += n(i2, r), i2 = e2;
      }
    };
  }
  function inCircle(t, e, i) {
    return calculateDistanceSquare(e, i, t.cx, t.cy) <= t._squareR + DISTANCE_TOLERANCE;
  }
  function circleByTwoPoints(t, e, i, n) {
    return i = i || calculateDistance2(t, e), new Circle((t.x + e.x) / 2, (t.y + e.y) / 2, i / 2, t, e, null, n);
  }
  function calculateDistance2(t, e) {
    return calculateDistance(t.x, t.y, e.x, e.y);
  }
  function Circle(t, e, i, n, o, s, r) {
    this.cx = t, this.cy = e, this.r = i, this._squareR = i * i, this.p1 = n, this.p2 = o, this.p3 = s, this._otherPoint = r;
  }
  function Ellipse(t, e, i, n) {
    this.cx = t, this.cy = e, this.width = i, this.height = n;
  }
  function smallEmbodyCircle(t) {
    var e = t[0], i = t[1], n = t[2], o = Circle._mmreateCircle(e, i, n);
    return tryCircle(t, e, i, n, o);
  }
  function smallEmbodyEllipse(t, e) {
    e = e || caculateBounds(t);
    for (var i, n = e.width / e.height, o = [], s = t.length, r = 0; s > r; r++)
      i = t[r], o.push({
        x: i.x,
        y: i.y * n
      });
    var a = smallEmbodyCircle(o);
    return a ? new Ellipse(a.cx, a.cy / n, 2 * a.r, 2 * a.r / n) : void 0;
  }
  function tryCircle(t, e, i, n, o) {
    for (var s, r, a = t.length, h = o._squareR, l = 0; a > l; l++)
      if (s = t[l], s != e && s != i && s != n) {
        var _ = calculateDistanceSquare(o.cx, o.cy, s.x, s.y);
        _ - DISTANCE_TOLERANCE > h && (h = _, r = s);
      }
    if (!r)
      return o;
    var u, d = Circle._mmreateCircle(r, e, i), c = Circle._mmreateCircle(r, e, n), f = Circle._mmreateCircle(r, n, i);
    return inCircle(d, n.x, n.y) && (u = d), inCircle(c, i.x, i.y) && (!u || u.r > c.r) && (u = c), inCircle(f, e.x, e.y) && (!u || u.r > f.r) && (u = f), e = u.p1, i = u.p2, n = u.p3 || u._otherPoint, tryCircle(t, e, i, n, u);
  }
  function caculateBounds(t) {
    for (var e, i = t.length, n = new Rect(), o = 0; i > o; o++)
      e = t[o], n.add(e.x, e.y);
    return n;
  }
  function PathGenerator(t, e, i, n, o) {
    this._6k && this.validate();
    var s = o ? this.getBounds(o) : this.bounds, r = i / s.width, a = t - r * s.x, h = n / s.height, l = e - h * s.y, _ = this._fe, u = [];
    return _ic(
      _,
      function(t2) {
        var e2 = t2.clone(), i2 = e2.points;
        if (i2 && i2.length) {
          for (var n2 = i2.length, o2 = [], s2 = 0; n2 > s2; s2++) {
            var _2 = i2[s2];
            s2++;
            var d = i2[s2];
            _2 = r * _2 + a, d = h * d + l, o2.push(_2), o2.push(d);
          }
          e2.points = o2;
        }
        u.push(e2);
      },
      this
    ), new Path(u);
  }
  function pathHitTest(t, e, i, n, o, s) {
    if (o = o || 0, i = i || 0, !o && !s)
      return false;
    if (!n) {
      var r = this.getBounds(o);
      if (!r.intersectsPoint(t, e, i))
        return false;
    }
    var a = Math.round(2 * i) || 1, h = getTempG(a, a), l = (h.canvas, -t + i), _ = -e + i;
    if (h.setTransform(1, 0, 0, 1, l, _), !h.isPointInStroke) {
      this._le(h), o && h.stroke(), s && h.fill();
      for (var u = h.getImageData(0, 0, a, a).data, d = u.length / 4; d > 0; ) {
        if (u[4 * d - 1] > ALPHA_TOLERANCE)
          return true;
        --d;
      }
      return false;
    }
    return h.lineWidth = (o || 0) + 2 * i, this._le(h), o && h.isPointInStroke(i, i) ? true : s ? h.isPointInPath(i, i) : false;
  }
  function calculatePointByLength(t, e, i) {
    if (!this._k4)
      return null;
    var n = this._fe;
    if (n.length < 2)
      return null;
    i === false && (t += this._k4);
    var o = n[0];
    if (0 >= t)
      return calculatePointInfoOnStraightLine(o.points[0], o.points[1], n[1].points[0], n[1].points[1], t, e);
    if (t >= this._k4) {
      o = n[n.length - 1];
      var s, r, a = o.points, h = a.length, l = a[h - 2], _ = a[h - 1];
      if (h >= 4)
        s = a[h - 4], r = a[h - 3];
      else {
        o = n[n.length - 2];
        var u = o.lastPoint;
        s = u.x, r = u.y;
      }
      return calculatePointInfoOnStraightLine(l, _, l + l - s, _ + _ - r, t - this._k4, e);
    }
    for (var d, c = 0, f = 1, h = n.length; h > f; f++)
      if (d = n[f], d._k4) {
        if (!(c + d._k4 < t)) {
          var E, u = o.lastPoint;
          if (d.type == ARC_TO) {
            var g = d.points;
            E = getLocationOnArcByLength(t - c, d, u.x, u.y, g[0], g[1], g[2], g[3], d._r);
          } else {
            if (!d._lf)
              return calculatePointInfoOnStraightLine(u.x, u.y, d.points[0], d.points[1], t - c, e);
            var p = caculateCurveTByLengthFunction(d._lf, d._k4)(t - c), g = d.points;
            E = d.type == CURVE_TO && 6 == g.length ? pointOnBezier(p, [u.x, u.y].concat(g), true) : pointOnQuadratic(p, [u.x, u.y].concat(g), true);
          }
          return e && (E.x -= e * Math.sin(E.rotate || 0), E.y += e * Math.cos(E.rotate || 0)), E;
        }
        c += d._k4, o = d;
      } else
        o = d;
  }
  function getLocationOnArcByLength(t, e, i, n, o, s, r, a) {
    if (t <= e._l1)
      return calculatePointInfoOnStraightLine(i, n, o, s, t);
    if (t >= e._k4)
      return t -= e._k4, calculatePointInfoOnStraightLine(e._p2x, e._p2y, r, a, t);
    if (t -= e._l1, e._o) {
      var h = t / e._r;
      e._CCW && (h = -h);
      var l = rotatePointAt(e._p1x, e._p1y, h, e._o.x, e._o.y);
      return l.rotate += e._mk1 || 0, l.rotate += Math.PI, l;
    }
    return calculatePointInfoOnStraightLine(e._p1x, e._p1y, e._p2x, e._p2y, t);
  }
  function perpendicularLine(t, e, i) {
    var n, o, s;
    0 == t._mk ? (n = -1, s = 0, o = e) : 0 == t._mm ? (n = 0, s = 1, o = i) : (n = -1 / t._mk, o = (t._mk - n) * e + t._mo, s = 1);
    var r = new Line();
    return r._mk = n, r._mo = o, r._mm = s, r._mg = e, r._mb = i, r;
  }
  function angleFormat(t) {
    return t %= 2 * Math.PI, 0 > t && (t += 2 * Math.PI), t;
  }
  function caculateArcLength(t, e, i, n, o, s, r, a) {
    var h = calculateDistance(e, i, n, o), l = calculateDistance(n, o, s, r);
    if (!h || !l)
      return t._d = 0, t._r = 0, t._l1 = h, t._l2 = l, t._k4 = 0;
    var _ = constructLine(n, o, e, i), u = constructLine(n, o, s, r);
    t._mk1 = _, t._mk2 = u;
    var d = _ - u;
    d = angleFormat(d), d > Math.PI && (d = 2 * Math.PI - d, t._CCW = true);
    var c = Math.PI - d, f = Math.tan(d / 2), E = a / f, g = Math.min(h, l);
    E > g && (E = g, a = f * E);
    var p, v = n + Math.cos(_) * E, T = o + Math.sin(_) * E, m = n + Math.cos(u) * E, y = o + Math.sin(u) * E, S = new Line(e, i, n, o), I = new Line(n, o, s, r), P = perpendicularLine(S, v, T), O = perpendicularLine(I, m, y), R = P._3y(O), A = Math.atan2(T - R.y, v - R.x), L = Math.atan2(y - R.y, m - R.x);
    p = t._CCW ? L : A;
    for (var C, x = 0; 4 > x; ) {
      var D = x * HALF_PI;
      if (angleFormat(D - p) <= c) {
        var w, b;
        if (C ? C++ : C = 1, 0 == x ? (w = R.x + a, b = R.y) : 1 == x ? (w = R.x, b = R.y + a) : 2 == x ? (w = R.x - a, b = R.y) : (w = R.x, b = R.y - a), t["_mooundaryPoint" + C] = {
          x: w,
          y: b
        }, 2 == C)
          break;
      }
      x++;
    }
    return t._p1x = v, t._p1y = T, t._p2x = m, t._p2y = y, t._o = R, t._d = E, t._r = a, t._l1 = h - E, t._l2 = l - E, t._k4 = t._l1 + c * a;
  }
  function constructThreePoint(t, e, i, n, o, s, r) {
    var a = constructLine(i, n, t, e), h = constructLine(i, n, o, s), l = a - h;
    return r ? l : (0 > l && (l = -l), l > Math.PI && (l -= Math.PI), l);
  }
  function constructLine(t, e, i, n) {
    return Math.atan2(n - e, i - t);
  }
  function getImagePostfix(t) {
    var e = REG_BASE64_IMAGE.exec(t);
    if (e)
      return e[1];
    var i = t.lastIndexOf(".");
    return i >= 0 && i < t.length - 1 ? t.substring(i + 1) : void 0;
  }
  function getImageType(t) {
    if (!t)
      return null;
    if (t instanceof Path)
      return IMAGE_TYPE_SHAPE;
    if (t.draw instanceof Function)
      return IMAGE_TYPE_DRAWABLE;
    if (_ho(t)) {
      var e = getImagePostfix(t);
      if (e) {
        if (!isIE && REG_GIF.test(e))
          return IMAGE_TYPE_GIF;
        if (REG_SVG.test(e))
          return IMAGE_TYPE_SVG;
      }
      return IMAGE_TYPE_DEFAULT;
    }
  }
  function QImage(t, e, i) {
    if (this._lg = getImageType(t), !this._lg)
      throw new Error("the image format is not supported", t);
    this._lc = t, this._mkp = e, this._98 = i, this.width = e || Defaults.IMAGE_WIDTH, this.height = i || Defaults.IMAGE_HEIGHT, this._ka = {};
  }
  function _8g(t, e, i, n) {
    return e ? (IMAGE_CACHE[t] = new QImage(e, i, n), t) : void delete IMAGE_CACHE[t];
  }
  function _he(t) {
    if (t._kf)
      return t._kf;
    var e = _ho(t);
    if (!e && !t.name)
      return t._kf = new QImage(t);
    var i = t.name || t;
    return i in IMAGE_CACHE ? IMAGE_CACHE[i] : IMAGE_CACHE[i] = new QImage(t);
  }
  function _ha(t) {
    return t in IMAGE_CACHE;
  }
  function _mow(t, e, i) {
    i = i || {};
    var n = t.getBounds(i.lineWidth);
    if (!n.width || !n.height)
      return false;
    var o = e.getContext("2d"), s = e.ratio || 1, r = i.scaleMode || "full.uniform", a = /full/i.test(r), h = /uniform/i.test(r), l = 1, _ = 1;
    if (a) {
      var u = e.width, d = e.height, c = i.padding, f = 0, E = 0;
      if (c) {
        var g, p, v, T;
        _gd(c) ? g = p = v = T = c : (g = c.top || 0, p = c.bottom || 0, v = c.left || 0, T = c.right || 0), u -= v + T, d -= g + p, f += v, E += g;
      }
      l = u / n.width, _ = d / n.height, h && (l > _ ? (f += (u - _ * n.width) / 2, l = _) : _ > l && (E += (d - l * n.height) / 2, _ = l)), (f || E) && o.translate(f, E);
    }
    o.translate(-n.x * l, -n.y * _), t.draw(o, s, i, l, _, true);
  }
  function _eu(t, e, i) {
    var n = _he(t);
    return n ? (n.validate(), (n._lg == IMAGE_TYPE_GIF || n._7s()) && n._mo2(function(t2) {
      t2.source && (this.width = this.width, _mow(t2.source, this, i));
    }, e), void _mow(n, e, i)) : (Q2.error("draw image error - " + t), false);
  }
  function _7y(t, e, i, n) {
    var o = t.length;
    if (o && !(0 > o)) {
      n = n || 1;
      for (var s, r, a, h = [], l = 0; l++ < o; )
        if (s = t.getLocation(l, 0), s && calculateDistance(e, i, s.x, s.y) <= n) {
          r = l, a = s.rotate;
          break;
        }
      if (void 0 !== r) {
        for (var s, _, u, d = 0, l = 0, c = t._fe.length; c > l; l++) {
          if (s = t._fe[l], !_ && (d += s._k4 || 0, d > r)) {
            _ = true;
            var f = Math.max(10, s._k4 / 6), E = f * Math.sin(a), g = f * Math.cos(a);
            if (s.type == CURVE_TO) {
              var p = s.points[0], v = s.points[1];
              if (u) {
                var T = new Line(e, i, e + g, i + E), m = T._3y(new Line(u.lastPoint.x, u.lastPoint.y, s.points[0], s.points[1]));
                void 0 !== m.x && (p = m.x, v = m.y);
              }
              h.push(new PathSegment(CURVE_TO, [p, v, e - g, i - E, e, i]));
            } else
              h.push(new PathSegment(QUAD_TO, [e - g, i - E, e, i]));
            if (s.points)
              if (s.type == CURVE_TO) {
                s.points[0] = e + g, s.points[1] = i + E;
                var T = new Line(e, i, e + g, i + E), m = T._3y(new Line(s.points[2], s.points[3], s.points[4], s.points[5]));
                void 0 !== m.x && (s.points[2] = m.x, s.points[3] = m.y);
              } else if (s.type == QUAD_TO) {
                s.type = CURVE_TO, s.points = [e + g, i + E].concat(s.points);
                var T = new Line(e, i, e + g, i + E), m = T._3y(new Line(s.points[2], s.points[3], s.points[4], s.points[5]));
                void 0 !== m.x && (s.points[2] = m.x, s.points[3] = m.y);
              } else
                s.type == LINE_TO && (s.type = QUAD_TO, s.points = [e + g, i + E].concat(s.points), l == c - 1 && (s.invalidTerminal = true));
          }
          h.push(s), u = s;
        }
        return h;
      }
    }
  }
  function toPixelsFromCanvas(t) {
    var e = t.width, i = t.height;
    try {
      var n = t.g.getImageData(0, 0, e, i), o = n.data;
      return toPixelsFromCanvasData(o, e, i);
    } catch (s) {
      Q2.error(s);
    }
  }
  function toPixelsFromCanvasData(t, e) {
    var i, n, o, s, r, a = t.length, h = 0, l = 0;
    for (r = 0; a > r; r += 4)
      if (t[r + 3] > 0) {
        i = (r + 4) / e / 4 | 0;
        break;
      }
    for (r = a - 4; r >= 0; r -= 4)
      if (t[r + 3] > 0) {
        n = (r + 4) / e / 4 | 0;
        break;
      }
    for (h = 0; e > h; h++) {
      for (l = i; n > l; l++)
        if (t[l * e * 4 + 4 * h + 3] > 0) {
          o = h;
          break;
        }
      if (o >= 0)
        break;
    }
    for (h = e - 1; h >= 0; h--) {
      for (l = i; n > l; l++)
        if (t[l * e * 4 + 4 * h + 3] > 0) {
          s = h;
          break;
        }
      if (s >= 0)
        break;
    }
    var _, u, d, c = [], f = [];
    for (h = o; s >= h; h++)
      for (d = [], c.push(d), l = i; n >= l; l++)
        r = 4 * (l * e + h), _ = t[r + 3], _ ? (u = {
          a: _,
          r: t[r],
          g: t[r + 1],
          b: t[r + 2]
        }, d.push(u), f.push(u.r), f.push(u.g), f.push(u.b), f.push(u.a)) : (d.push(null), f.push(0), f.push(0), f.push(0), f.push(0));
    return c._x = o, c._y = i, c._width = s - o + 1, c._height = n - i + 1, c._j1 = new Rect(o, i, c._width, c._height), c._pixelSize = c._width * c._height, c;
  }
  function hitPixels(t, e, i, n, o) {
    if (o = 1 | o, !o || 1 > o) {
      var s = t[i];
      return s ? s[n] : false;
    }
    var r = n - o, a = i - o;
    0 > r && (r = 0), 0 > a && (a = 0);
    var h = i + o, l = n + o;
    for (h > e.width && (h = e.width), l > e.height && (l = e.height); h > a; ) {
      for (; l > r; ) {
        if (t[a][r])
          return true;
        r++;
      }
      a++;
    }
    return false;
  }
  function colorToRGB(t) {
    if ("#" == t[0]) {
      if (t = t.substring(1), 3 == t.length)
        t = t[0] + t[0] + t[1] + t[1] + t[2] + t[2];
      else if (6 != t.length)
        return;
      return t = parseInt(t, 16), [t >> 16 & 255, t >> 8 & 255, 255 & t];
    }
    if (/^rgb/i.test(t)) {
      var e = t.indexOf("("), i = t.indexOf(")");
      if (0 > e || e > i)
        return;
      if (t = t.substring(e + 1, i), t = t.split(","), t.length < 3)
        return;
      var n = parseInt(t[0]), o = parseInt(t[1]), s = parseInt(t[2]), r = 3 == t.length ? 255 : parseInt(t[3]);
      return [n, o, s, r];
    }
  }
  function colorBurn(t, e, i) {
    return i || (i = Defaults.BLEND_MODE), i == Consts.BLEND_MODE_MULTIPLY ? t * e : i == Consts.BLEND_MODE_DARKEN ? Math.min(t, e) : i == Consts.BLEND_MODE_COLOR_BURN ? 1 - (1 - e) / t : i == Consts.BLEND_MODE_LINEAR_BURN ? t + e - 1 : i == Consts.BLEND_MODE_LIGHTEN ? Math.max(t, e) : i == Consts.BLEND_MODE_SCREEN ? t + e - t * e : e;
  }
  function getRenderCanvas(t, e, i) {
    var n = colorToRGB(e);
    if (!n)
      return void Q2.error("color error, [" + e + "]");
    var o = t.g.getImageData(0, 0, t.width, t.height), s = o.data;
    if (i instanceof Function)
      s = i(t, s, n) || s;
    else {
      var r = n[0] / 255, a = n[1] / 255, h = n[2] / 255;
      if (i == Consts.BLEND_MODE_GRAY)
        for (var l = 0, _ = s.length; _ > l; l += 4) {
          var u = 77 * s[l] + 151 * s[l + 1] + 28 * s[l + 2] >> 8;
          s[l] = u * r | 0, s[l + 1] = u * a | 0, s[l + 2] = u * h | 0;
        }
      else
        for (var l = 0, _ = s.length; _ > l; l += 4)
          s[l] = 255 * colorBurn(r, s[l] / 255, i) | 0, s[l + 1] = 255 * colorBurn(a, s[l + 1] / 255, i) | 0, s[l + 2] = 255 * colorBurn(h, s[l + 2] / 255, i) | 0;
    }
    var t = _mkc(t.width, t.height);
    return t.g.putImageData(o, 0, 0), t;
  }
  function UIHitTest(t, e, i, n) {
    return 1 > i && (i = 1), UIHitTestByRect(t - i, e - i, 2 * i, 2 * i, n);
  }
  function UIHitTestByRect(t, e, i, n, o) {
    i = Math.round(i) || 1, n = Math.round(n) || 1;
    var s = getTempG(i, n);
    s.setTransform(1, 0, 0, 1, -t, -e), o.draw(s);
    for (var r = s.getImageData(0, 0, i, n).data, a = r.length / 4; a-- > 0; )
      if (r[4 * a - 1] > ALPHA_TOLERANCE)
        return true;
    return false;
  }
  function UIHitTestByBoundsAbsolute(t, e, i, n, o, s) {
    t -= o.$x, e -= o.$y;
    var r = o._fu.intersection(t, e, i, n);
    if (!r)
      return false;
    t = r.x * s, e = r.y * s, i = r.width * s, n = r.height * s, i = Math.round(i) || 1, n = Math.round(n) || 1;
    var a = getTempG(), h = a.canvas;
    h.width < i || h.height < n ? (h.width = i, h.height = n) : (a.setTransform(1, 0, 0, 1, 0, 0), a.clearRect(0, 0, i, n)), a.setTransform(1, 0, 0, 1, -t - o.$x * s, -e - o.$y * s), a.scale(s, s), o._j5(a, 1);
    for (var l = a.getImageData(0, 0, i, n).data, _ = l.length / 4; _-- > 0; )
      if (l[4 * _ - 1] > ALPHA_TOLERANCE)
        return true;
    return false;
  }
  function createBubblePointer(t, e, i, n, o, s, r, a, h) {
    if (intersectsPoint(t, e, i, n, a, h))
      return null;
    var l, u, d = new PathSegment(LINE_TO, [t + i - o, e]), c = new PathSegment(QUAD_TO, [t + i, e, t + i, e + s]), f = new PathSegment(LINE_TO, [t + i, e + n - s]), E = new PathSegment(QUAD_TO, [t + i, e + n, t + i - o, e + n]), g = new PathSegment(LINE_TO, [t + o, e + n]), p = new PathSegment(QUAD_TO, [t, e + n, t, e + n - s]), v = new PathSegment(LINE_TO, [t, e + s]), T = new PathSegment(QUAD_TO, [t, e, t + o, e]), m = (new PathSegment(CLOSE), [d, c, f, E, g, p, v, T]), y = new Rect(t + o, e + s, i - o - o, n - s - s);
    t > a ? (l = LEFT, u = 5) : a > t + i ? (l = RIGHT, u = 1) : (l = CENTER, u = 0), e > h ? l == LEFT && (u = 7) : h > e + n ? l == RIGHT ? u = 3 : l == CENTER && (u = 4) : l == LEFT ? u = 6 : l == RIGHT && (u = 2);
    var S = bubbleIntersectionPoints(u, t, e, i, n, o, s, r, a, h, y), I = S[0], P = S[1], O = new Path(), R = O._fe;
    R.push(new PathSegment(MOVE_TO, [I.x, I.y])), R.push(new PathSegment(LINE_TO, [a, h])), R.push(new PathSegment(LINE_TO, [P.x, P.y])), P._li && (R.push(P._li), P._liNO++);
    for (var A = P._liNO % 8, L = I._liNO; ; )
      if (R.push(m[A]), ++A, A %= 8, A == L)
        break;
    return I._li && R.push(I._li), O.closePath(), O;
  }
  function bubbleConerIntersectionPoints(t, e, i, n, o, s, r, a, h, l, _, u, d, c) {
    var f = new Line(u, d, i, n), E = new Line(e[0], e[1], e[4], e[5]), g = E._3y(f, _), p = g[0], v = g[1];
    if (void 0 !== p._rest) {
      p._liNO = (t - 1) % 8, v._liNO = (t + 1) % 8;
      var T = p._rest;
      7 == t ? (p.y = s + l + Math.min(c.height, T), v.x = o + h + Math.min(c.width, T)) : 5 == t ? (p.x = o + h + Math.min(c.width, T), v.y = s + a - l - Math.min(c.height, T)) : 3 == t ? (p.y = s + a - l - Math.min(c.height, T), v.x = o + r - h - Math.min(c.width, T)) : 1 == t && (p.x = o + r - h - Math.min(c.width, T), v.y = s + l + Math.min(c.height, T));
    } else {
      f._m8(f._mg, f._mb, p.x, p.y), p = f._$l(e), f._m8(f._mg, f._mb, v.x, v.y), v = f._$l(e);
      var m = breakQuadraticCurve2(e, [p, v]), y = m[0], S = m[2];
      p._liNO = t, v._liNO = t, p._li = new PathSegment(QUAD_TO, y.slice(2)), v._li = new PathSegment(QUAD_TO, S.slice(2));
    }
    return [p, v];
  }
  function bubbleIntersectionPoints0(t, e, i, n, o, s, r, a, h, l) {
    var _, u;
    if (h - a >= e + s)
      _ = { y: i, x: h - a }, _._liNO = 0;
    else {
      _ = { y: i + r, x: Math.max(e, h - a) };
      var d = [e, i + r, e, i, e + s, i], c = new Line(h, l, _.x, _.y);
      if (_ = c._$l(d)) {
        _ig(_) && (_ = _[0].t > _[1].t ? _[0] : _[1]);
        var f = breakQuadraticCurve2(d, [_]);
        f = f[0], f && (_._li = new PathSegment(QUAD_TO, f.slice(2))), _._liNO = 7;
      } else
        _ = { y: i, x: e + s }, _._liNO = 0;
    }
    if (e + n - s >= h + a)
      u = { y: i, x: h + a }, u._liNO = 0;
    else {
      u = { y: i + r, x: Math.min(e + n, h + a) };
      var E = [e + n - s, i, e + n, i, e + n, i + r], c = new Line(h, l, u.x, u.y);
      if (u = c._$l(E)) {
        _ig(u) && (u = u[0].t < u[1].t ? u[0] : u[1]);
        var f = breakQuadraticCurve2(E, [u]);
        f && f[f.length - 1] && (u._li = new PathSegment(QUAD_TO, f[f.length - 1].slice(2))), u._liNO = 1;
      } else
        u = { y: i, x: e + n - s }, u._liNO = 0;
    }
    return [_, u];
  }
  function bubbleIntersectionPoints2(t, e, i, n, o, s, r, a, h, l) {
    var _, u;
    if (l - a >= i + r)
      _ = { x: e + n, y: l - a }, _._liNO = 2;
    else {
      _ = { x: e + n - s, y: Math.max(i, l - a) };
      var d = [e + n - s, i, e + n, i, e + n, i + r], c = new Line(h, l, _.x, _.y);
      if (_ = c._$l(d)) {
        _ig(_) && (_ = _[0].t > _[1].t ? _[0] : _[1]);
        var f = breakQuadraticCurve2(d, [_]);
        f = f[0], f && (_._li = new PathSegment(QUAD_TO, f.slice(2))), _._liNO = 1;
      } else
        _ = { x: e + n, y: i + r }, _._liNO = 2;
    }
    if (i + o - r >= l + a)
      u = { x: e + n, y: l + a }, u._liNO = 2;
    else {
      u = { x: e + n - s, y: Math.min(i + o, l + a) };
      var E = [e + n, i + o - r, e + n, i + o, e + n - s, i + o], c = new Line(h, l, u.x, u.y);
      if (u = c._$l(E)) {
        _ig(u) && (u = u[0].t < u[1].t ? u[0] : u[1]);
        var f = breakQuadraticCurve2(E, [u]);
        f[1] && (u._li = new PathSegment(QUAD_TO, f[1].slice(2))), u._liNO = 3;
      } else
        u = { x: e + n, y: i + o - r }, u._liNO = 2;
    }
    return [_, u];
  }
  function bubbleIntersectionPoints4(t, e, i, n, o, s, r, a, h, l) {
    var _, u;
    if (h - a >= e + s)
      u = { y: i + o, x: h - a }, u._liNO = 4;
    else {
      u = { y: i + o - r, x: Math.max(e, h - a) };
      var d = [e + s, i + o, e, i + o, e, i + o - r], c = new Line(h, l, u.x, u.y);
      if (u = c._$l(d)) {
        _ig(u) && (u = u[0].t < u[1].t ? u[0] : u[1]);
        var f = breakQuadraticCurve2(d, [u]);
        f = f[f.length - 1], f && (u._li = new PathSegment(QUAD_TO, f.slice(2))), u._liNO = 5;
      } else
        u = { y: i + o, x: e + s }, u._liNO = 4;
    }
    if (e + n - s >= h + a)
      _ = { y: i + o, x: h + a }, _._liNO = 4;
    else {
      _ = { y: i + o - r, x: Math.min(e + n, h + a) };
      var E = [e + n, i + o - r, e + n, i + o, e + n - s, i + o], c = new Line(h, l, _.x, _.y);
      if (_ = c._$l(E)) {
        _ig(_) && (_ = _[0].t > _[1].t ? _[0] : _[1]);
        var f = breakQuadraticCurve2(E, [_]);
        f[0] && (_._li = new PathSegment(QUAD_TO, f[0].slice(2))), _._liNO = 3;
      } else
        _ = { y: i + o, x: e + n - s }, _._liNO = 4;
    }
    return [_, u];
  }
  function bubbleIntersectionPoints6(t, e, i, n, o, s, r, a, h, l) {
    var _, u;
    if (l - a >= i + r)
      u = { x: e, y: l - a }, u._liNO = 6;
    else {
      u = { x: e + s, y: Math.max(i, l - a) };
      var d = [e, i + r, e, i, e + s, i], c = new Line(h, l, u.x, u.y);
      if (u = c._$l(d)) {
        _ig(u) && (u = u[0].t < u[1].t ? u[0] : u[1]);
        var f = breakQuadraticCurve2(d, [u]);
        f = f[f.length - 1], f && (u._li = new PathSegment(QUAD_TO, f.slice(2)));
      } else
        u = { x: e, y: i + r };
      u._liNO = 7;
    }
    if (i + o - r >= l + a)
      _ = { x: e, y: l + a }, _._liNO = 6;
    else {
      _ = { x: e + s, y: Math.min(i + o, l + a) };
      var E = [e + s, i + o, e, i + o, e, i + o - r], c = new Line(h, l, _.x, _.y);
      if (_ = c._$l(E)) {
        _ig(_) && (_ = _[0].t > _[1].t ? _[0] : _[1]);
        var f = breakQuadraticCurve2(E, [_]);
        f[0] && (_._li = new PathSegment(QUAD_TO, f[0].slice(2))), _._liNO = 5;
      } else
        _ = { x: e, y: i + o - r }, _._liNO = 6;
    }
    return [_, u];
  }
  function bubbleIntersectionPoints(t, e, i, n, o, s, r, a, h, l, _) {
    var u = a / 2;
    switch (t) {
      case 7:
        var d = [e, i + r, e, i, e + s, i], c = e + s, f = i + r;
        return bubbleConerIntersectionPoints(t, d, c, f, e, i, n, o, s, r, a, h, l, _);
      case 5:
        return d = [e + s, i + o, e, i + o, e, i + o - r], c = e + s, f = i + o - r, bubbleConerIntersectionPoints(t, d, c, f, e, i, n, o, s, r, a, h, l, _);
      case 3:
        return d = [e + n, i + o - r, e + n, i + o, e + n - s, i + o], c = e + n - s, f = i + o - r, bubbleConerIntersectionPoints(t, d, c, f, e, i, n, o, s, r, a, h, l, _);
      case 1:
        return d = [e + n - s, i, e + n, i, e + n, i + r], c = e + n - s, f = i + r, bubbleConerIntersectionPoints(t, d, c, f, e, i, n, o, s, r, a, h, l, _);
      case 0:
        return bubbleIntersectionPoints0(t, e, i, n, o, s, r, u, h, l);
      case 2:
        return bubbleIntersectionPoints2(t, e, i, n, o, s, r, u, h, l);
      case 4:
        return bubbleIntersectionPoints4(t, e, i, n, o, s, r, u, h, l);
      case 6:
        return bubbleIntersectionPoints6(t, e, i, n, o, s, r, u, h, l);
    }
  }
  function breakQuadraticCurve2(t, e) {
    for (var i, n, o, s, r, a, h = t[0], l = t[1], _ = t[2], u = t[3], d = t[4], c = t[5], f = [], E = 0; E < e.length; E++)
      r = e[E], a = r.t, 0 != a && 1 != a ? (i = h + (_ - h) * a, n = l + (u - l) * a, o = _ + (d - _) * a, s = u + (c - u) * a, f.push([h, l, i, n, r.x, r.y]), h = r.x, l = r.y, _ = o, u = s) : f.push(null);
    return void 0 !== o && f.push([r.x, r.y, o, s, d, c]), f;
  }
  function localToParent(t) {
    return this.$layoutByAnchorPoint && this._mo0 && (t.x -= this._mo0.x, t.y -= this._mo0.y), this.$rotate && rotateThePointAt(t, this.$rotate), t.x += this.$offsetX || 0, t.y += this.$offsetY || 0, this.$rotatable && this.$_hostRotate ? rotateThePointAt(t, this.$_hostRotate) : t;
  }
  function parentToLocal(t) {
    return this.$rotatable && this.$_hostRotate && rotateThePointAt(t, -this.$_hostRotate), t.x -= this.$offsetX || 0, t.y -= this.$offsetY || 0, this.$rotate && rotateThePointAt(t, -this.$rotate), this.$layoutByAnchorPoint && this._mo0 && (t.x += this._mo0.x, t.y += this._mo0.y), t;
  }
  function UIValidateBoundsBackgroundBorderAndPointer() {
    var t = this.$invalidateSize;
    this.$invalidateSize && (this.$invalidateSize = false, this.$invalidateAnchorPoint = true, this._8b.setByRect(this._j1), this.$padding && this._8b.grow(this.$padding), this.$border && this._8b.grow(this.$border));
    var e = this._$v();
    if (e)
      var i = this.showPointer && this.$pointerWidth;
    return this.$invalidateAnchorPoint && this.$layoutByAnchorPoint && (this.$invalidateAnchorPoint = false, i && (t = true), this._mo0 = _mkr(this.$anchorPosition, this._8b.width, this._8b.height), this._mo0.x += this._8b.x, this._mo0.y += this._8b.y), e ? (t && (this._moackgroundGradientInvalidateFlag = true, UIValidateBackgroundShape.call(this, i)), this._moackgroundGradientInvalidateFlag && (this._moackgroundGradientInvalidateFlag = false, this._moackgroundGradient = this.backgroundGradient && this._loShape && this._loShape.bounds ? Gradient.prototype.generatorGradient.call(this.backgroundGradient, this._loShape.bounds) : null), t) : (this.__lkPointer = false, t);
  }
  function UIValidateBackgroundShape(t) {
    var e = this._8b.x + this.$border / 2, i = this._8b.y + this.$border / 2, n = this._8b.width - this.$border, o = this._8b.height - this.$border, s = 0, r = 0;
    if (this.$borderRadius && (_gd(this.$borderRadius) ? s = r = this.$borderRadius : (s = this.$borderRadius.x || 0, r = this.$borderRadius.y || 0), s = Math.min(s, n / 2), r = Math.min(r, o / 2)), t && (this._pointerX = this._mo0.x - this.$offsetX + this.$pointerX, this._pointerY = this._mo0.y - this.$offsetY + this.$pointerY, !this._8b.intersectsPoint(this._pointerX, this._pointerY))) {
      var a = new Bubble(e, i, n, o, s, r, this.$pointerWidth, this._pointerX, this._pointerY);
      return this._loShape = a._li, this._loShape.bounds.set(e, i, n, o), void (this.__lkPointer = true);
    }
    this._loShape && this._loShape.clear(), this._loShape = Shapes.getRect(e, i, n, o, s, r, this._loShape), this._loShape.bounds.set(e, i, n, o);
  }
  function addPointToRect(t, e, i, n) {
    return n && (t.width < 0 || t.height < 0) ? (t.x = e, t.y = i, void (t.width = t.height = 0)) : (e < t.x ? (t.width += t.x - e, t.x = e) : e > t.x + t.width && (t.width = e - t.x), void (i < t.y ? (t.height += t.y - i, t.y = i) : i > t.y + t.height && (t.height = i - t.y)));
  }
  function UIGetLocation(t, e, i) {
    var n, o = t.position, s = void 0 === t.layoutByPath ? this.layoutByPath : t.layoutByPath;
    return this.$data instanceof Path && s ? (n = pathUtils._mkr(o, this.$data, this.lineWidth, e, i), n.x *= this._j7, n.y *= this._j0) : (n = _mkr(o, this._8b.width, this._8b.height), n.x += this._8b.x, n.y += this._8b.y), localToParent.call(this, n);
  }
  function UILayoutChild(t, e) {
    if (e)
      if (e._8b.isEmpty())
        t.$x = e.$x, t.$y = e.$y;
      else {
        var i = UIGetLocation.call(e, t);
        t.$x = i.x, t.$y = i.y, t._hostRotate = i.rotate;
      }
    else
      t.$x = 0, t.$y = 0;
    t.$invalidateRotate && UIValidateRotate.call(t);
  }
  function addLineDashSupport(t) {
    if (void 0 === t.lineDash) {
      var e, i;
      if (t.setLineDash)
        e = t.getLineDash, i = t.setLineDash;
      else {
        var n;
        if (void 0 !== t.mozDash)
          n = "mozDash";
        else {
          if (void 0 === t.webkitLineDash)
            return false;
          n = "webkitLineDash";
        }
        i = function(t2) {
          this[n] = t2;
        }, e = function() {
          return this[n];
        };
      }
      _6u(t, "lineDash", {
        get: function() {
          return e.call(this);
        },
        set: function(t2) {
          i.call(this, t2);
        }
      });
    }
    if (void 0 === t.lineDashOffset) {
      var o;
      if (void 0 !== t.mozDashOffset)
        o = "mozDashOffset";
      else {
        if (void 0 === t.webkitLineDashOffset)
          return;
        o = "webkitLineDashOffset";
      }
      _6u(t, "lineDashOffset", {
        get: function() {
          return this[o];
        },
        set: function(t2) {
          this[o] = t2;
        }
      });
    }
  }
  function GifLoader(t, e, i, n, o) {
    var s, r, a, h, l, _, u, d, c = function(t2) {
      return function(e2) {
        t2(e2);
      };
    }, f = function() {
      r = null, a = null, h = l, l = null, _ = null;
    }, E = function(t2) {
      s = t2, u || (u = _mkc()), u.width = s.width, u.height = s.height, e.width = s.width, e.height = s.height;
    }, g = function(t2) {
      p(), f(), r = t2.transparencyGiven ? t2.transparencyIndex : null, a = 10 * t2.delayTime, l = t2.disposalMethod;
    }, p = function() {
      if (_) {
        var t2 = _.getImageData(0, 0, s.width, s.height), i2 = {
          data: t2,
          _pixels: toPixelsFromCanvasData(t2.data, s.width, s.height),
          delay: a
        };
        o.call(e, i2);
      }
    }, v = function(t2) {
      _ || (_ = u.getContext("2d"));
      var e2 = t2.lctFlag ? t2.lct : s.gct, i2 = _.getImageData(t2.leftPos, t2.topPos, t2.width, t2.height);
      t2.pixels.forEach(function(t3, n2) {
        r !== t3 ? (i2.data[4 * n2 + 0] = e2[t3][0], i2.data[4 * n2 + 1] = e2[t3][1], i2.data[4 * n2 + 2] = e2[t3][2], i2.data[4 * n2 + 3] = 255) : (2 === h || 3 === h) && (i2.data[4 * n2 + 3] = 0);
      }), _.clearRect(0, 0, s.width, s.height), _.putImageData(i2, t2.leftPos, t2.topPos);
    }, T = function() {
    }, m = {
      hdr: c(E),
      gce: c(g),
      com: c(T),
      app: { NETSCAPE: c(T) },
      img: c(v),
      eof: function() {
        p(), i.call(e);
      }
    }, y = new XMLHttpRequest();
    isIE || y.overrideMimeType("text/plain; charset=x-user-defined"), y.onload = function() {
      d = new Stream(y.responseText);
      try {
        parseGIF(d, m);
      } catch (t2) {
        n.call(e, "parse");
      }
    }, y.onerror = function() {
      n.call(e, "xhr");
    }, y.open("GET", t, true), y.send();
  }
  function findAgentNode(t) {
    return t.parent ? (t = t.parent, t._e1 ? t._e1 : t._hk === false ? t : null) : null;
  }
  function _6h(t, e, i) {
    if (i = i || e.toAgent, i == t)
      return false;
    var n = t.getEdgeBundle(i);
    return n || (n = new EdgeBundle(t, i), t._linkedNodes[i.id] = n), n._io(e, t);
  }
  function _2z(t, e, i) {
    if (i = i || e.toAgent, i == t)
      return false;
    var n = t.getEdgeBundle(i);
    return n ? n._d1(e, t) : void 0;
  }
  function _5i(t, e, i) {
    return void 0 === i && (i = e.toAgent), i != t ? (t._8h || (t._8h = new HashList()), t._8h.add(e) === false ? false : void t._9r++) : void 0;
  }
  function _2w(t, e, i) {
    return t._8h && t._8h.remove(e) !== false ? (t._9r--, void _2z(t, e, i)) : false;
  }
  function _7i(t, e) {
    return e.fromAgent != t ? (t._9n || (t._9n = new HashList()), t._9n.add(e) === false ? false : void t._moo++) : void 0;
  }
  function _3z(t, e) {
    return t._9n && t._9n.remove(e) !== false ? (t._moo--, void _2z(e.fromAgent, e, t)) : false;
  }
  function findGroup(t, e) {
    if (void 0 === e && (e = t instanceof Edge), e) {
      if (t.isInvalid())
        return null;
      var i = findGroup(t.from, false);
      if (t.isLooped())
        return i;
      for (var n = findGroup(t.to, false); null != i && null != n; ) {
        if (i == n)
          return i;
        if (i.isDescendantOf(n))
          return n;
        if (n.isDescendantOf(i))
          return i;
        i = findGroup(i, false), n = findGroup(n, false);
      }
      return null;
    }
    for (var o = t.parent; null != o; ) {
      if (o._i7())
        return o;
      o = o.parent;
    }
    return null;
  }
  function findFollowers(t, e, i) {
    t._i7() && t.hasChildren() && t.children.forEach(function(t2) {
      t2 instanceof Node && e.add(t2) && findFollowers(t2, e, i);
    }, this), t.hasFollowers() && t._dx.forEach(function(t2) {
      (null == i || i.accept(t2)) && e.add(t2) && findFollowers(t2, e, i);
    });
  }
  function sendToTopSibling(t, e) {
    e.parent ? e.parent.setChildIndex(e, e.parent.childrenCount - 1) : t.roots.setIndex(e, t.roots.length - 1);
  }
  function elementSendToTop(t, e) {
    if (e instanceof Edge)
      return void (e.isInvalid() || sendToTopEdge(t, e));
    for (sendToTopSibling(t, e); e = e.parent; )
      sendToTopSibling(t, e);
  }
  function elementSendToBottom(t, e) {
    if (e instanceof Edge)
      return void (e.isInvalid() || sendToTopEdge(t, e));
    for (sendToTopSibling(t, e); e = e.parent; )
      sendToTopSibling(t, e);
  }
  function sendToTopEdge(t, e) {
    var i = e.fromAgent;
    if (e.isLooped())
      sendToTopSibling(t, i);
    else {
      var n = e.toAgent;
      sendToTopSibling(t, i), sendToTopSibling(t, n);
    }
  }
  function _dc(t, e) {
    return t._9r++, t._fn ? (e._it = t._i0, t._i0._is = e, void (t._i0 = e)) : (t._fn = e, void (t._i0 = e));
  }
  function _8f(t, e) {
    t._9r--, t._i0 == e && (t._i0 = e._it), e._it ? e._it._is = e._is : t._fn = e._is, e._is && (e._is._it = e._it), e._it = null, e._is = null, _2z(t, e, e.$to);
  }
  function _eq(t, e) {
    return t._moo++, t._i3 ? (e._k5 = t._jd, t._jd._k7 = e, void (t._jd = e)) : (t._i3 = e, void (t._jd = e));
  }
  function _9e(t, e) {
    t._moo--, t._jd == e && (t._jd = e._k5), e._k5 ? e._k5._k7 = e._k7 : t._i3 = e._k7, e._k7 && (e._k7._k5 = e._k5), e._k5 = null, e._k7 = null;
  }
  function getAllChildrenEdgeInfos(t, e) {
    return e = e || new HashList(), t.forEachEdge(function(t2) {
      e.add({ id: t2.id, edge: t2, fromAgent: t2.$from._e1, toAgent: t2.$to._e1 });
    }), t.forEachChild(function(t2) {
      t2 instanceof Node && getAllChildrenEdgeInfos(t2, e);
    }), e;
  }
  function _69(t, e, i) {
    return _45(t, e, i) === false ? false : _38(t, e, i);
  }
  function _38(t, e, i) {
    if (t._fn)
      for (var n = t._fn; n; ) {
        if (e.call(i, n) === false)
          return false;
        n = n._is;
      }
  }
  function _45(t, e, i) {
    if (t._i3)
      for (var n = t._i3; n; ) {
        if (e.call(i, n) === false)
          return false;
        n = n._k7;
      }
  }
  function addRect(t, e, i, n, o, s, r) {
    return s || r ? (s = s || 0, r = void 0 === r ? s : r || 0, s = Math.min(s, n / 2), r = Math.min(r, o / 2), t.moveTo(e + s, i), t.lineTo(e + n - s, i), t.quadTo(e + n, i, e + n, i + r), t.lineTo(e + n, i + o - r), t.quadTo(e + n, i + o, e + n - s, i + o), t.lineTo(e + s, i + o), t.quadTo(e, i + o, e, i + o - r), t.lineTo(e, i + r), t.quadTo(e, i, e + s, i), t.closePath(), t) : (t.moveTo(e, i), t.lineTo(e + n, i), t.lineTo(e + n, i + o), t.lineTo(e, i + o), t.closePath(), t);
  }
  function addCircle(t, e) {
    var i = e.r || 1, n = e.cx || 0, o = e.cy || 0, s = i * Math.tan(Math.PI / 8), r = i * Math.sin(Math.PI / 4);
    t.moveTo(n + i, o), t.quadTo(n + i, o + s, n + r, o + r), t.quadTo(n + s, o + i, n, o + i), t.quadTo(n - s, o + i, n - r, o + r), t.quadTo(n - i, o + s, n - i, o), t.quadTo(n - i, o - s, n - r, o - r), t.quadTo(n - s, o - i, n, o - i), t.quadTo(n + s, o - i, n + r, o - r), t.quadTo(n + i, o - s, n + i, o);
  }
  function addEllipse(t, e, i, n, o) {
    e instanceof Ellipse && (n = e.width, o = e.height, i = e.cy - o / 2, e = e.cx - n / 2);
    var s = 0.5522848, r = n / 2 * s, a = o / 2 * s, h = e + n, l = i + o, _ = e + n / 2, u = i + o / 2;
    return t.moveTo(e, u), t.curveTo(e, u - a, _ - r, i, _, i), t.curveTo(_ + r, i, h, u - a, h, u), t.curveTo(h, u + a, _ + r, l, _, l), t.curveTo(_ - r, l, e, u + a, e, u), t;
  }
  function addStar(t, e, i, n, o) {
    var s = 2 * n, r = 2 * o, a = e + n / 2, h = i + o / 2;
    return t.moveTo(a - s / 4, h - r / 12), t.lineTo(e + 0.306 * n, i + 0.579 * o), t.lineTo(a - s / 6, h + r / 4), t.lineTo(e + n / 2, i + 0.733 * o), t.lineTo(a + s / 6, h + r / 4), t.lineTo(e + 0.693 * n, i + 0.579 * o), t.lineTo(a + s / 4, h - r / 12), t.lineTo(e + 0.611 * n, i + 0.332 * o), t.lineTo(a + 0, h - r / 4), t.lineTo(e + 0.388 * n, i + 0.332 * o), t.closePath(), t;
  }
  function addDelta(t, e, i, n, o) {
    return t.moveTo(e, i), t.lineTo(e + n, i + o / 2), t.lineTo(e, i + o), t.closePath(), t;
  }
  function addDiamond(t, e, i, n, o) {
    return t.moveTo(e, i + o / 2), t.lineTo(e + n / 2, i), t.lineTo(e + n, i + o / 2), t.lineTo(e + n / 2, i + o), t.closePath(), t;
  }
  function addStandardArrow(t, e, i, n, o, s) {
    return t.moveTo(e, i), t.lineTo(e + n, i + o / 2), t.lineTo(e, i + o), s || (t.lineTo(e + 0.25 * n, i + o / 2), t.closePath()), t;
  }
  function createRegularPolygon(t, e, i, n, o) {
    if (!t || 3 > t)
      throw new Error("edge number must greater than 2");
    t = 0 | t, n = n || 50, o = o || 0, e = e || 0, i = i || 0;
    for (var s, r, a = 0, h = 2 * Math.PI / t, l = new Path(); t > a; )
      s = e + n * Math.cos(o), r = i + n * Math.sin(o), a ? l.lineTo(s, r) : l.moveTo(s, r), ++a, o += h;
    return l.closePath(), l;
  }
  function createHeart() {
    var t = new Path();
    return t.moveTo(75, 40), t.curveTo(75, 37, 70, 25, 50, 25), t.curveTo(20, 25, 20, 62.5, 20, 62.5), t.curveTo(20, 80, 40, 102, 75, 120), t.curveTo(110, 102, 130, 80, 130, 62.5), t.curveTo(130, 62.5, 130, 25, 100, 25), t.curveTo(85, 25, 75, 37, 75, 40), t;
  }
  function createTrapezium() {
    var t = new Path();
    return t.moveTo(20, 0), t.lineTo(80, 0), t.lineTo(100, 100), t.lineTo(0, 100), t.closePath(), t;
  }
  function createRhombus() {
    var t = new Path();
    return t.moveTo(100, 0), t.lineTo(100, 80), t.lineTo(0, 100), t.lineTo(0, 20), t.closePath(), t;
  }
  function createParallelogram() {
    var t = new Path();
    return t.moveTo(20, 0), t.lineTo(100, 0), t.lineTo(80, 100), t.lineTo(0, 100), t.closePath(), t;
  }
  function createArrow1() {
    var t = new Path();
    return t.moveTo(43, 23), t.lineTo(28, 10), t.lineTo(37, 2), t.lineTo(63, 31), t.lineTo(37, 59), t.lineTo(28, 52), t.lineTo(44, 38), t.lineTo(3, 38), t.lineTo(3, 23), t.closePath(), t;
  }
  function createArrow2() {
    var t = new Path();
    return t.moveTo(1, 8), t.lineTo(7, 2), t.lineTo(32, 26), t.lineTo(7, 50), t.lineTo(1, 44), t.lineTo(18, 26), t.closePath(), t.moveTo(27, 8), t.lineTo(33, 2), t.lineTo(57, 26), t.lineTo(33, 50), t.lineTo(27, 44), t.lineTo(44, 26), t.closePath(), t;
  }
  function createArrow3() {
    var t = new Path();
    return t.moveTo(0, 15), t.lineTo(23, 15), t.lineTo(23, 1), t.lineTo(47, 23), t.lineTo(23, 43), t.lineTo(23, 29), t.lineTo(0, 29), t.closePath(), t;
  }
  function createArrow4() {
    var t = new Path();
    return t.moveTo(0, 21), t.lineTo(30, 21), t.lineTo(19, 0), t.lineTo(25, 0), t.lineTo(47, 25), t.lineTo(25, 48), t.lineTo(19, 48), t.lineTo(30, 28), t.lineTo(0, 28), t.closePath(), t;
  }
  function createArrow5() {
    var t = new Path();
    return t.moveTo(0, 0), t.lineTo(34, 24), t.lineTo(0, 48), t.lineTo(14, 24), t.closePath(), t;
  }
  function createArrow6() {
    var t = new Path();
    return t.moveTo(20, 0), t.lineTo(34, 14), t.lineTo(20, 28), t.lineTo(22, 18), t.lineTo(1, 25), t.lineTo(10, 14), t.lineTo(1, 3), t.lineTo(22, 10), t.closePath(), t;
  }
  function createArrow7() {
    var t = new Path();
    return t.moveTo(4, 18), t.lineTo(45, 18), t.lineTo(37, 4), t.lineTo(83, 25), t.lineTo(37, 46), t.lineTo(45, 32), t.lineTo(4, 32), t.closePath(), t;
  }
  function createArrow8() {
    var t = new Path();
    return t.moveTo(17, 11), t.lineTo(27, 11), t.lineTo(42, 27), t.lineTo(27, 42), t.lineTo(17, 42), t.lineTo(28, 30), t.lineTo(4, 30), t.lineTo(4, 23), t.lineTo(28, 23), t.closePath(), t;
  }
  function initShapes() {
    Shapes.register(Consts.SHAPE_CIRCLE, addEllipse(new Path(), 0, 0, 100, 100)), Shapes.register(Consts.SHAPE_RECT, addRect(new Path(), 0, 0, 100, 100)), Shapes.register(Consts.SHAPE_ROUNDRECT, addRect(new Path(), 0, 0, 100, 100, 20, 20)), Shapes.register(Consts.SHAPE_STAR, addStar(new Path(), 0, 0, 100, 100)), Shapes.register(Consts.SHAPE_TRIANGLE, addDelta(new Path(), 0, 0, 100, 100)), Shapes.register(Consts.SHAPE_PENTAGON, createRegularPolygon(5)), Shapes.register(Consts.SHAPE_HEXAGON, createRegularPolygon(6)), Shapes.register(Consts.SHAPE_DIAMOND, addDiamond(new Path(), 0, 0, 100, 100)), Shapes.register(Consts.SHAPE_HEART, createHeart()), Shapes.register(Consts.SHAPE_TRAPEZIUM, createTrapezium()), Shapes.register(Consts.SHAPE_RHOMBUS, createRhombus()), Shapes.register(Consts.SHAPE_PARALLELOGRAM, createParallelogram());
    var t = new Path();
    t.moveTo(20, 0), t.lineTo(40, 0), t.lineTo(40, 20), t.lineTo(60, 20), t.lineTo(60, 40), t.lineTo(40, 40), t.lineTo(40, 60), t.lineTo(20, 60), t.lineTo(20, 40), t.lineTo(0, 40), t.lineTo(0, 20), t.lineTo(20, 20), t.closePath(), Shapes.register(Consts.SHAPE_CROSS, t), Shapes.register(Consts.SHAPE_ARROW_STANDARD, addStandardArrow(new Path(), 0, 0, 100, 100)), Shapes.register(Consts.SHAPE_ARROW_1, createArrow1()), Shapes.register(Consts.SHAPE_ARROW_2, createArrow2()), Shapes.register(Consts.SHAPE_ARROW_3, createArrow3()), Shapes.register(Consts.SHAPE_ARROW_4, createArrow4()), Shapes.register(Consts.SHAPE_ARROW_5, createArrow5()), Shapes.register(Consts.SHAPE_ARROW_6, createArrow6()), Shapes.register(Consts.SHAPE_ARROW_7, createArrow7()), Shapes.register(Consts.SHAPE_ARROW_8, createArrow8()), Shapes.register(Consts.SHAPE_ARROW_OPEN, addStandardArrow(new Path(), 0, 0, 100, 100, true));
  }
  function Bus() {
    _3g(this, Bus, arguments), this.busLayout = true;
  }
  function GraphModel() {
    _3g(this, GraphModel), this._$x = new Dispatcher();
  }
  function checkGroupAgentEdges() {
    if (this._hk === true) {
      var t = this._8h, e = this._9n;
      if (t)
        for (t = t._jf; t.length; ) {
          var i = t[0];
          _2w(this, i, i.toAgent);
        }
      if (e)
        for (e = e._jf; e.length; ) {
          var i = e[0];
          _3z(this, i, i.fromAgent);
        }
      return void this.forEachChild(function(t2) {
        t2._i7() && checkGroupAgentEdges.call(t2);
      });
    }
    var n = getAllChildrenEdgeInfos(this);
    n.forEach(function(t2) {
      t2 = t2.edge;
      var e2 = t2.$from, i2 = t2.$to, n2 = e2.isDescendantOf(this), o = i2.isDescendantOf(this);
      n2 && !o ? (_5i(this, t2), _6h(this, t2)) : o && !n2 && (_7i(this, t2), _6h(t2.fromAgent, t2, this));
    }, this);
  }
  function Text() {
    _3g(this, Text, arguments), this.$image = null;
  }
  function createUIPropertyFunction(t, e, i, n) {
    return t[e] = i, n ? {
      get: function() {
        return this[e];
      },
      set: function(t2) {
        if (t2 !== this[e]) {
          this[e] = t2, !this._mkd, this._1q = true;
          for (var i2 = n.length; --i2 >= 0; )
            this[n[i2]] = true;
        }
      }
    } : {
      get: function() {
        return this[e];
      },
      set: function(t2) {
        t2 !== this[e] && (this[e] = t2);
      }
    };
  }
  function defineUIProperties(t, e) {
    var i = {}, n = {};
    for (var o in e) {
      var s = e[o];
      s.validateFlags && s.validateFlags.forEach(function(t2, e2, i2) {
        i2[e2] = "$invalidate" + t2, n[t2] = true;
      }), i[o] = createUIPropertyFunction(t, "$" + o, s.value, s.validateFlags);
    }
    for (var r in n)
      t["$invalidate" + r] = true;
    Object.defineProperties(t, i);
  }
  function doBinding(t, e, i, n) {
    if (Array.isArray(e))
      for (var o = e.length; --o >= 0; )
        doBinding(t, e[o], i, n);
    else {
      var s = e.target;
      if (s) {
        if (s instanceof BaseUI || (s = t[s]), !s)
          return;
      } else
        s = t;
      if (n || (n = t.getProperty(e.property, i)), e.bindingProperty && (s[e.bindingProperty] = n), e.callback) {
        var r = e.callback;
        r instanceof Function || (r = t[r]), r instanceof Function && r.call(t, n, s);
      }
    }
  }
  function UIBindingMap() {
    PROPERTY_TYPES.forEach(function(t) {
      this[t] = {};
    }, this);
  }
  function setElementProperty(t, e, i, n) {
    return n == Consts.PROPERTY_TYPE_ACCESSOR ? void (t[i] = e) : n == Consts.PROPERTY_TYPE_CLIENT ? void t.set(i, e) : n == Consts.PROPERTY_TYPE_STYLE ? void t.setStyle(i, e) : false;
  }
  function EdgeUI() {
    _3g(this, EdgeUI, arguments);
  }
  function NodeUI() {
    _3g(this, NodeUI, arguments);
  }
  function createCanvas(t) {
    var e = _mkc(true);
    return addLineDashSupport(e.g), e.onselectstart = function() {
      return false;
    }, t.appendChild(e), css_mmss(e, CANVAS_STYLES), e;
  }
  function BaseCanvas(t) {
    this._m7 = t, _mkg(this._m7, "Q-Graph"), t.tabIndex = 0, this._jn = createCanvas(t), this.ratio = this._jn.ratio || 1, this._topCanvas = new TopCanvas(this, t), this._gl = [], this._mo4 = new ClipSupport(), this._jp = new CanvasMatrix(this), this._m6 = new HashList();
    var e = this;
    this._m6._g3 = function(t2, i, n) {
      i.destroy();
      var o = i.uiBounds;
      return i._hw && o && e._mo4._lo(i.$x + i.uiBounds.x, i.$y + i.uiBounds.y, i.uiBounds.width, i.uiBounds.height), HashList.prototype._g3.call(this, t2, i, n);
    }, this._m6.clear = function() {
      return this.forEach(function(t2) {
        t2.destroy();
      }), HashList.prototype.clear.call(this);
    }, this._d3 = [], this._8c = {}, this._8p = new Rect(), this._8m = [], this._mmc();
  }
  function CanvasMatrix(t) {
    this._d5 = t, this._jp = new Matrix2D(), this._jp.ratio = t.ratio, this._78 = new Rect();
  }
  function calculateOrthogonalAndFlexionalEdgePoints(t, e, i, n) {
    var o = isHorizontal(t, e, i), s = [];
    if (isFlexionalTypeEdge(t))
      flexional(o, e, i, s, n.getStyle(Styles.EDGE_EXTEND));
    else {
      orthogonal(t, e, i, s, o, n);
      var r = isSplitByPercent(t, n), a = r ? calculateSplitValueByPercent(t, o, e, i, n.getStyle(Styles.EDGE_SPLIT_PERCENT)) : n.getStyle(Styles.EDGE_SPLIT_VALUE);
      0 == a && (o = !o);
    }
    return s;
  }
  function isHorizontal(t, e, i) {
    if (null != t) {
      if (t == Consts.EDGE_TYPE_ELBOW_HORIZONTAL || t == Consts.EDGE_TYPE_ORTHOGONAL_HORIZONTAL || t == Consts.EDGE_TYPE_HORIZONTAL_VERTICAL || t == Consts.EDGE_TYPE_EXTEND_LEFT || t == Consts.EDGE_TYPE_EXTEND_RIGHT)
        return true;
      if (t == Consts.EDGE_TYPE_ELBOW_VERTICAL || t == Consts.EDGE_TYPE_ORTHOGONAL_VERTICAL || t == Consts.EDGE_TYPE_VERTICAL_HORIZONTAL || t == Consts.EDGE_TYPE_EXTEND_TOP || t == Consts.EDGE_TYPE_EXTEND_BOTTOM)
        return false;
    }
    var n = calculateXGap(e, i), o = calculateYGap(e, i);
    return n >= o;
  }
  function flexional(t, e, i, n, o) {
    t ? flexionalHorizontal(e, i, n, o) : flexionalVertical(e, i, n, o);
  }
  function isSplitByPercent(t, e) {
    return e.getStyle(Styles.EDGE_SPLIT_BY_PERCENT);
  }
  function isExtendTypeEdge(t) {
    return null != t && (t == Consts.EDGE_TYPE_EXTEND_TOP || t == Consts.EDGE_TYPE_EXTEND_LEFT || t == Consts.EDGE_TYPE_EXTEND_BOTTOM || t == Consts.EDGE_TYPE_EXTEND_RIGHT);
  }
  function isFlexionalTypeEdge(t) {
    return t && (t == Consts.EDGE_TYPE_ELBOW || t == Consts.EDGE_TYPE_ELBOW_HORIZONTAL || t == Consts.EDGE_TYPE_ELBOW_VERTICAL);
  }
  function calculateControlPoint(t, e, i, n, o) {
    if (t == Consts.EDGE_TYPE_HORIZONTAL_VERTICAL || t == Consts.EDGE_TYPE_VERTICAL_HORIZONTAL)
      return new Point(n.x + n.width / 2, n.y + n.height / 2);
    var s;
    if (isExtendTypeEdge(t)) {
      var r = Math.min(i.y, n.y), a = Math.min(i.x, n.x), h = Math.max(i.bottom, n.bottom), l = Math.max(i.right, n.right);
      if (s = o.getStyle(Styles.EDGE_EXTEND), t == Consts.EDGE_TYPE_EXTEND_TOP)
        return new Point((a + l) / 2, r - s);
      if (t == Consts.EDGE_TYPE_EXTEND_LEFT)
        return new Point(a - s, (r + h) / 2);
      if (t == Consts.EDGE_TYPE_EXTEND_BOTTOM)
        return new Point((a + l) / 2, h + s);
      if (t == Consts.EDGE_TYPE_EXTEND_RIGHT)
        return new Point(l + s, (r + h) / 2);
    }
    var _ = isSplitByPercent(t, o);
    if (s = _ ? calculateSplitValueByPercent(t, e, i, n, o.getStyle(Styles.EDGE_SPLIT_PERCENT)) : o.getStyle(Styles.EDGE_SPLIT_VALUE), s == Number.NEGATIVE_INFINITY || s == Number.POSITIVE_INFINITY)
      return new Point(n.x + n.width / 2, n.y + n.height / 2);
    if (0 == s)
      return new Point(i.x + i.width / 2, i.y + i.height / 2);
    if (e) {
      var u = i.x + i.right < n.x + n.right;
      return new Point(calculateSplitLocation(u, s, i.x, i.width), i.y + i.height / 2);
    }
    var d = i.y + i.bottom < n.y + n.bottom;
    return new Point(i.x + i.width / 2, calculateSplitLocation(d, s, i.y, i.height));
  }
  function calculateGap(t, e, i, n) {
    var o = Math.max(e, n) - Math.min(t, i);
    return o - (e - t + n - i);
  }
  function calculateXGap(t, e) {
    var i = Math.max(t.x + t.width, e.x + e.width) - Math.min(t.x, e.x);
    return i - t.width - e.width;
  }
  function calculateYGap(t, e) {
    var i = Math.max(t.y + t.height, e.y + e.height) - Math.min(t.y, e.y);
    return i - t.height - e.height;
  }
  function calculateSplitValueByPercent(t, e, i, n, o) {
    var s = calculateSplitGapByPercent(o, e, i, n);
    return s * o;
  }
  function calculateSplitGapByPercent(t, e, i, n) {
    return e ? _$p(t, i.x, i.right, n.x, n.right) : _$p(t, i.y, i.bottom, n.y, n.bottom);
  }
  function _$p(t, e, i, n, o) {
    var s = calculateGap(e, i, n, o), r = n + o > e + i;
    if (s > 0) {
      if (1 == t)
        return s + (o - n) / 2;
      if (t >= 0 && 1 > t)
        return s;
      if (0 > t)
        return r ? n - e : i - o;
    }
    return Math.abs(r && t > 0 || !r && 0 > t ? i - o : e - n);
  }
  function calculateSplitLocation(t, e, i, n) {
    return t == e > 0 ? i + n + Math.abs(e) : i - Math.abs(e);
  }
  function drawCorner(t, e) {
    var i = t.length;
    if (!(3 > i)) {
      var n = e.getStyle(Styles.EDGE_CORNER);
      if (n != Consts.EDGE_CORNER_NONE) {
        var o = e.getStyle(Styles.EDGE_CORNER_RADIUS), s = 0, r = 0;
        o && (_gd(o) ? s = r = o : (s = o.x || 0, r = o.y || 0));
        for (var a, h, l, _, u = t[0], d = t[1], c = null, f = 2; i > f; f++) {
          var E = t[f], g = d.x - u.x, p = d.y - u.y, v = E.x - d.x, T = E.y - d.y, m = !g || g > -DISTANCE_TOLERANCE && DISTANCE_TOLERANCE > g, y = !p || p > -DISTANCE_TOLERANCE && DISTANCE_TOLERANCE > p, S = !v || v > -DISTANCE_TOLERANCE && DISTANCE_TOLERANCE > v, I = !T || T > -DISTANCE_TOLERANCE && DISTANCE_TOLERANCE > T, P = y;
          (m && I || y && S) && (P ? (a = Math.min(2 == f ? Math.abs(g) : Math.abs(g) / 2, s), h = Math.min(f == i - 1 ? Math.abs(T) : Math.abs(T) / 2, r), l = new Point(d.x - (g > 0 ? a : -a), d.y), _ = new Point(d.x, d.y + (T > 0 ? h : -h))) : (a = Math.min(f == i - 1 ? Math.abs(v) : Math.abs(v) / 2, s), h = Math.min(2 == f ? Math.abs(p) : Math.abs(p) / 2, r), l = new Point(d.x, d.y - (p > 0 ? h : -h)), _ = new Point(d.x + (v > 0 ? a : -a), d.y)), _jh(t, d), f--, i--, (l.x != u.x || l.y != u.y) && (_m9(t, l, f), f++, i++), n == Consts.EDGE_CORNER_BEVEL ? (_m9(t, _, f), f++, i++) : n == Consts.EDGE_CORNER_ROUND && (_m9(t, [d, _], f), f++, i++)), u = d, d = E;
        }
        null != c && _.x == d.x && _.y == d.y && _jh(t, d);
      }
    }
  }
  function orthogonal(t, e, i, n, o, s) {
    var r = s.getStyle(Styles.EDGE_CONTROL_POINT), a = null == r;
    if (null != r) {
      var h = new Rect().union(e).union(i);
      h.intersects(r) || (o = calculateIsHorizontalByControlPoint(r.x, r.y, h.y, h.x, h.bottom, h.right));
    } else
      r = calculateControlPoint(t, o, e, i, s);
    o ? sideToSide(e, i, r, n, a) : topToBottom(e, i, r, n, a);
  }
  function calculateIsHorizontalByControlPoint(t, e, i, n, o, s) {
    return i > e && i - e > n - t && i - e > t - s || e > o && e - o > n - t && e - o > t - s ? false : true;
  }
  function contains(t, e, i) {
    return e >= t.x && e <= t.right && i >= t.y && i <= t.bottom;
  }
  function topToBottom(t, e, i, n, o) {
    var s = Math.max(t.y, e.y), r = Math.min(t.y + t.height, e.y + e.height), a = null != i ? i.y : r + (s - r) / 2, h = t.x + t.width / 2, l = e.x + e.width / 2;
    if (0 == o && null != i && (i.x >= t.x && i.x <= t.x + t.width && (h = i.x), i.x >= e.x && i.x <= e.x + e.width && (l = i.x)), contains(e, h, a) || contains(t, h, a) || n.push(new Point(h, a)), contains(e, l, a) || contains(t, l, a) || n.push(new Point(l, a)), 0 == n.length)
      if (null != i)
        contains(e, i.x, a) || contains(t, i.x, a) || n.push(new Point(i.x, a));
      else {
        var _ = Math.max(t.x, e.x), u = Math.min(t.x + t.width, e.x + e.width);
        n.push(new Point(_ + (u - _) / 2, a));
      }
  }
  function sideToSide(t, e, i, n, o) {
    var s = Math.max(t.x, e.x), r = Math.min(t.x + t.width, e.x + e.width), a = null != i ? i.x : r + (s - r) / 2, h = t.y + t.height / 2, l = e.y + e.height / 2;
    if (0 == o && null != i && (i.y >= t.y && i.y <= t.y + t.height && (h = i.y), i.y >= e.y && i.y <= e.y + e.height && (l = i.y)), contains(e, a, h) || contains(t, a, h) || n.push(new Point(a, h)), contains(e, a, l) || contains(t, a, l) || n.push(new Point(a, l)), 0 == n.length)
      if (null != i)
        contains(e, a, i.y) || contains(t, a, i.y) || n.push(new Point(a, i.y));
      else {
        var _ = Math.max(t.y, e.y), u = Math.min(t.y + t.height, e.y + e.height);
        n.push(new Point(a, _ + (u - _) / 2));
      }
  }
  function flexionalHorizontal(t, e, i, n) {
    var o = e.x + e.width < t.x, s = t.x + t.width < e.x, r = o ? t.x : t.x + t.width, a = t.y + t.height / 2, h = s ? e.x : e.x + e.width, l = e.y + e.height / 2, _ = n, u = o ? -_ : _, d = new Point(r + u, a);
    u = s ? -_ : _;
    var c = new Point(h + u, l);
    if (o == s) {
      var f = o ? Math.min(r, h) - n : Math.max(r, h) + n;
      i.push(new Point(f, a)), i.push(new Point(f, l));
    } else if (d.x < c.x == o) {
      var E = a + (l - a) / 2;
      i.push(d), i.push(new Point(d.x, E)), i.push(new Point(c.x, E)), i.push(c);
    } else
      i.push(d), i.push(c);
  }
  function flexionalVertical(t, e, i, n) {
    var o = e.y + e.height < t.y, s = t.y + t.height < e.y, r = t.x + t.width / 2, a = o ? t.y : t.y + t.height, h = e.x + e.width / 2, l = s ? e.y : e.y + e.height, _ = n, u = o ? -_ : _, d = new Point(r, a + u);
    u = s ? -_ : _;
    var c = new Point(h, l + u);
    if (o == s) {
      var f = o ? Math.min(a, l) - n : Math.max(a, l) + n;
      i.push(new Point(r, f)), i.push(new Point(h, f));
    } else if (d.y < c.y == o) {
      var E = r + (h - r) / 2;
      i.push(d), i.push(new Point(E, d.y)), i.push(new Point(E, c.y)), i.push(c);
    } else
      i.push(d), i.push(c);
  }
  function isOrthogonalOrFlexionalType(t) {
    return t == Consts.EDGE_TYPE_ORTHOGONAL || t == Consts.EDGE_TYPE_ORTHOGONAL_HORIZONTAL || t == Consts.EDGE_TYPE_HORIZONTAL_VERTICAL || t == Consts.EDGE_TYPE_ORTHOGONAL_VERTICAL || t == Consts.EDGE_TYPE_VERTICAL_HORIZONTAL || t == Consts.EDGE_TYPE_EXTEND_TOP || t == Consts.EDGE_TYPE_EXTEND_LEFT || t == Consts.EDGE_TYPE_EXTEND_BOTTOM || t == Consts.EDGE_TYPE_EXTEND_RIGHT || t == Consts.EDGE_TYPE_ELBOW || t == Consts.EDGE_TYPE_ELBOW_HORIZONTAL || t == Consts.EDGE_TYPE_ELBOW_VERTICAL;
  }
  function createArrow(t, e) {
    var i, n;
    e && e.width && e.height ? (i = e.width, n = e.height) : i = n = isNaN(e) ? Defaults.ARROW_SIZE : e;
    var o = Shapes.getShape(t, -i, -n / 2, i, n);
    return o || (o = new Path(), o.moveTo(-i, -n / 2), o.lineTo(0, 0), o.lineTo(-i, n / 2)), o;
  }
  function transformPoint(t, e) {
    var i = Math.sin(e), n = Math.cos(e), o = t.x, s = t.y;
    return t.x = o * n - s * i, t.y = o * i + s * n, t;
  }
  function calculatePointInfoOnStraightLine(t, e, i, n, o, s) {
    var r = Math.atan2(n - e, i - t), a = new Point(o, s);
    return a.rotate = r, transformPoint(a, r), a.x += t, a.y += e, a;
  }
  function calculateEdgeBundle(t, e, i, n, o) {
    e = getIntersectionPointOnRect(n, e.x, e.y, i.x, i.y), i = getIntersectionPointOnRect(o, i.x, i.y, e.x, e.y);
    var s = Math.PI / 2 + Math.atan2(i.y - e.y, i.x - e.x), r = t * Math.cos(s), a = t * Math.sin(s), h = i.x - e.x, l = i.y - e.y, _ = e.x + 0.25 * h, u = e.y + 0.25 * l, d = e.x + 0.75 * h, c = e.y + 0.75 * l;
    return [new PathSegment(CURVE_TO, [_ + r, u + a, d + r, c + a])];
  }
  function appendTerminalPoints(t, e, i) {
    if (_m9(t, new PathSegment(MOVE_TO, [e.x, e.y]), 0), i) {
      if (t.length > 1) {
        var n = t[t.length - 1];
        if (QUAD_TO == n.type && (n.invalidTerminal || void 0 === n.points[2] || null === n.points[2]))
          return n.points[2] = i.x, n.points[3] = i.y, void (n.invalidTerminal = true);
        if (CURVE_TO == n.type && (n.invalidTerminal || void 0 === n.points[4] || null === n.points[4]))
          return n.points[4] = i.x, n.points[5] = i.y, void (n.invalidTerminal = true);
      }
      t.push(new PathSegment(LINE_TO, [i.x, i.y]));
    }
  }
  function calculateEdgePath(t, e, i, n, o, s, r, a) {
    return e.hasPathSegments() ? void (i._fe = e._9x.toDatas()) : n == o ? void t.drawLoopedEdge(i, n, s, r) : void t.drawEdge(i, n, o, s, r, a);
  }
  function drawEdge(t, e, i, n, o) {
    var s = n == o, r = t.graph.getUI(n), a = s ? r : t.graph.getUI(o);
    if (r && a) {
      var h = e.edgeType, l = r.bodyBounds.clone(), _ = s ? l : a.bodyBounds.clone(), u = e.hasPathSegments();
      if (!s && !h && !u) {
        var d = n.busLayout, c = o.busLayout;
        if (d != c) {
          var f, E, g, p, v = e.angle;
          d ? (f = r, E = l, g = a, p = _) : (f = a, E = _, g = r, p = l);
          var T = caculateIntersectionOnBus(E, f, d, g, p, v);
          if (T && 2 == T.length) {
            var m = T[0], y = T[1];
            return i.moveTo(m.x, m.y), y.x == m.x && y.y == m.y && (y.y += 0.01), i.lineTo(y.x, y.y), void (i._6k = true);
          }
        }
      }
      calculateEdgePath(t, e, i, r, a, h, l, _), (!s || u) && offsetTerminalPointToEdge(t, e, i, r, a, h, l, _), i._6k = true;
    }
  }
  function offsetTerminalPointToEdge(t, e, i, n, o, s, r, a) {
    var h = r.center, l = a.center, _ = t.fromAtEdge, u = t.toAtEdge;
    if (!_ && !u)
      return void appendTerminalPoints(i._fe, h, l);
    var d = i._fe;
    if (d.length) {
      if (_) {
        var c = d[0], f = c.firstPoint;
        r.contains(f.x, f.y) && (c.type == CURVE_TO ? (h = f, f = {
          x: c.points[2],
          y: c.points[3]
        }, c.points = c.points.slice(2), c.type = QUAD_TO) : c.type == QUAD_TO && (h = f, f = {
          x: c.points[0],
          y: c.points[1]
        }, c.points = c.points.slice(2), c.type = LINE_TO)), getIntersectPointOnNodeUI3(n, r, f, h, void 0, void 0);
      }
      if (u) {
        var E, g = d[d.length - 1], p = g.lastPoint, v = g.points.length, T = void 0 === p.x || void 0 === p.y;
        v >= 4 && (T || a.contains(p.x, p.y)) && (T || (l = p), E = true, p = {
          x: g.points[v - 4],
          y: g.points[v - 3]
        }, a.contains(p.x, p.y) && (l = p, v >= 6 ? (p = {
          x: g.points[v - 6],
          y: g.points[v - 5]
        }, g.points = g.points.slice(0, 4), g.type = QUAD_TO) : 1 == d.length ? (p = {
          x: h.x,
          y: h.y
        }, g.points = g.points.slice(0, 2), g.type = LINE_TO) : (g = d[d.length - 2], p = g.lastPoint))), getIntersectPointOnNodeUI3(o, a, p, l, void 0, void 0), E && (v = g.points.length, g.points[v - 2] = l.x, g.points[v - 1] = l.y, l = null);
      }
    } else {
      var m = Math.atan2(l.y - h.y, l.x - h.x), y = Math.cos(m), S = Math.sin(m);
      _ && getIntersectPointOnNodeUI3(n, r, l, h, y, S), u && getIntersectPointOnNodeUI3(o, a, h, l, -y, -S);
    }
    appendTerminalPoints(i._fe, h, l);
  }
  function getIntersectPointOnNodeUI3(t, e, i, n, o, s) {
    if (void 0 === o) {
      var r = Math.atan2(i.y - n.y, i.x - n.x);
      o = Math.cos(r), s = Math.sin(r);
    }
    for (o += o, s += s, i = {
      x: i.x,
      y: i.y
    }, e.contains(i.x, i.y) || (i = getIntersectionPointOnRect(e, n.x, n.y, i.x, i.y)); ; ) {
      if (!e.contains(i.x, i.y))
        return n;
      if (t._hq(i.x - o, i.y - s, Defaults.LOOKING_EDGE_ENDPOINT_TOLERANCE)) {
        n.x = i.x - o / 2, n.y = i.y - s / 2;
        break;
      }
      i.x -= o, i.y -= s;
    }
    return n;
  }
  function calculateEdgeSegments(t, e, i, n, o, s, r, a) {
    if (e.hasPathSegments())
      return e._9x;
    var h = e.edgeType;
    if (isOrthogonalOrFlexionalType(h)) {
      var l = calculateOrthogonalAndFlexionalEdgePoints(h, i, n, t);
      if (!l || !l.length)
        return null;
      _m9(l, r, 0), l.push(a), h != Consts.EDGE_TYPE_ELBOW && drawCorner(l, t);
      for (var _ = [], u = l.length, d = 1; u - 1 > d; d++) {
        var c = l[d];
        _.push(
          _ig(c) ? new PathSegment(QUAD_TO, [c[0].x, c[0].y, c[1].x, c[1].y]) : new PathSegment(LINE_TO, [c.x, c.y])
        );
      }
      return _;
    }
    if (e.$bundleEnabled) {
      var f = t._2b();
      if (!f)
        return;
      return calculateEdgeBundle(f, r, a, i, n);
    }
  }
  function drawLoopedEdge(t, e, i) {
    var n = t.getStyle(Styles.EDGE_LOOPED_EXTAND), o = t._2b(), s = n + 0.2 * o, r = e.x + e.width - s, a = e.y, h = e.x + e.width, l = e.y + s;
    n += o;
    var _ = 0.707, u = -0.707, d = e.x + e.width, c = e.y, f = d + _ * n, E = c + u * n, g = { x: r, y: a }, p = {
      x: f,
      y: E
    }, v = {
      x: h,
      y: l
    }, T = g.x, m = p.x, y = v.x, S = g.y, I = p.y, P = v.y, O = ((P - S) * (I * I - S * S + m * m - T * T) + (I - S) * (S * S - P * P + T * T - y * y)) / (2 * (m - T) * (P - S) - 2 * (y - T) * (I - S)), R = ((y - T) * (m * m - T * T + I * I - S * S) + (m - T) * (T * T - y * y + S * S - P * P)) / (2 * (I - S) * (y - T) - 2 * (P - S) * (m - T)), s = Math.sqrt((T - O) * (T - O) + (S - R) * (S - R)), A = Math.atan2(g.y - R, g.x - O), L = Math.atan2(v.y - R, v.x - O), C = L - A;
    return 0 > C && (C += 2 * Math.PI), PathDrawArc(O, R, A, C, s, s, true, i);
  }
  function PathDrawArc(t, e, i, n, o, s, r, a) {
    var h, l, _, u, d, c, f, E, g, p, v;
    if (Math.abs(n) > 2 * Math.PI && (n = 2 * Math.PI), d = Math.ceil(Math.abs(n) / (Math.PI / 4)), h = n / d, l = h, _ = i, d > 0) {
      c = t + Math.cos(_) * o, f = e + Math.sin(_) * s, moveTo ? a.moveTo(c, f) : a.lineTo(c, f);
      for (var T = 0; d > T; T++)
        _ += l, u = _ - l / 2, E = t + Math.cos(_) * o, g = e + Math.sin(_) * s, p = t + Math.cos(u) * (o / Math.cos(l / 2)), v = e + Math.sin(u) * (s / Math.cos(l / 2)), a.quadTo(p, v, E, g);
    }
  }
  function caculateIntersectionOnBus(t, e, i, n, o, s) {
    var r = o.cx, a = o.cy, h = r < t.x, l = r > t.right, _ = a < t.y, u = a > t.bottom, d = t.cx, c = t.cy, f = h || l, E = _ || u, g = void 0 === s || null === s;
    g && (s = Math.atan2(a - c, r - d), f || E || (s += Math.PI));
    var p = Math.cos(s), v = Math.sin(s), T = caculateIntersectPointOn(e, t, { x: r, y: a }, -p, -v);
    T || (s = Math.atan2(a - c, r - d), f || E || (s += Math.PI), p = Math.cos(s), v = Math.sin(s), T = caculateIntersectPointOn(
      e,
      t,
      {
        x: r,
        y: a
      },
      -p,
      -v
    ) || { x: d, y: c });
    var m = caculateIntersectPointOn(n, o, { x: T.x, y: T.y }, -T.perX || p, -T.perY || v, false) || { x: r, y: a };
    return i ? [T, m] : [m, T];
  }
  function getIntersectionPointOnRectByLine(t, e, i, n, o, s) {
    var r = e < t.x, a = e > t.right, h = i < t.y, l = i > t.bottom;
    if (r && n > 0) {
      var _ = t.x - e, u = i + _ * o / n;
      if (u >= t.y && u <= t.bottom)
        return { x: t.x, y: u, perX: n, perY: o };
    }
    if (a && 0 > n) {
      var _ = t.right - e, u = i + _ * o / n;
      if (u >= t.y && u <= t.bottom)
        return { x: t.right, y: u, perX: n, perY: o };
    }
    if (h && o > 0) {
      var d = t.y - i, c = e + d * n / o;
      if (c >= t.x && c <= t.right)
        return { x: c, y: t.y, perX: n, perY: o };
    }
    if (l && 0 > o) {
      var d = t.bottom - i, c = e + d * n / o;
      if (c >= t.x && c <= t.right)
        return { x: c, y: t.bottom, perX: n, perY: o };
    }
    return s !== false ? getIntersectionPointOnRectByLine(t, e, i, -n, -o, false) : void 0;
  }
  function caculateIntersectPointOn(t, e, i, n, o, s) {
    if (!e.contains(i.x, i.y)) {
      if (i = getIntersectionPointOnRectByLine(e, i.x, i.y, n, o, s), !i)
        return;
      return caculateIntersectPointIn(t, e, i, i.perX, i.perY);
    }
    return s === false ? caculateIntersectPointIn(t, e, i, n, o) : caculateIntersectPointIn(
      t,
      e,
      {
        x: i.x,
        y: i.y,
        perX: n,
        perY: o
      },
      n,
      o
    ) || caculateIntersectPointIn(t, e, i, -n, -o);
  }
  function caculateIntersectPointIn(t, e, i, n, o) {
    for (; ; ) {
      if (!e.contains(i.x, i.y))
        return;
      if (t._hq(i.x + n, i.y + o))
        break;
      i.x += n, i.y += o;
    }
    return i;
  }
  function toImage(t) {
    return _ha(t) ? t : t.match(/.(gif|jpg|jpeg|png|svg)$/gi) ? t : (t = stringToObject(t), t instanceof Object && t.draw ? t : void 0);
  }
  function _6w(t) {
    for (var e = t.parent; e; ) {
      if (e.enableSubNetwork)
        return e;
      e = e.parent;
    }
    return null;
  }
  function GroupUI() {
    _3g(this, GroupUI, arguments);
  }
  function createNavButton(t, e, i, n, o, s, r) {
    var a = document2.createElement("div");
    a.className = "Q-Graph-Nav-Button", css_mmss(a, NAV_BUTTON_CSS), e && css_mmss(a, e);
    var h = document2.createElement("img");
    return s && (isTouchSupport ? h.ontouchstart = s : h.onmousedown = s), h.name = r, h.src = i, css_mmss(h, NAV_BUTTON_IMAGE_CSS), o && css_mmss(h, o), n && css_m8CSS(h, "transform", "rotate(180deg)"), a._img = h, a.appendChild(h), t.appendChild(a), a;
  }
  function createNavigationPane(t, e) {
    this._navPane = document2.createElement("div"), this._navPane.className = "Q-Graph-Nav", css_mmss(this._navPane, {
      "background-color": "rgba(0, 0, 0, 0)",
      overflow: "hidden",
      float: "left",
      "user-select": "none",
      position: "absolute"
    }), this._top = createNavButton(
      this._navPane,
      { width: "100%" },
      Defaults.NAVIGATION_IMAGE_TOP,
      false,
      null,
      e,
      "top"
    ), this._left = createNavButton(
      this._navPane,
      { height: "100%" },
      Defaults.NAVIGATION_IMAGE_LEFT,
      false,
      NAV_VERTICAL_MIDDLE_CSS,
      e,
      "left"
    ), this._right = createNavButton(
      this._navPane,
      {
        height: "100%",
        right: "0px"
      },
      Defaults.NAVIGATION_IMAGE_LEFT,
      true,
      NAV_VERTICAL_MIDDLE_CSS,
      e,
      "right"
    ), this._moottom = createNavButton(
      this._navPane,
      {
        width: "100%",
        bottom: "0px"
      },
      Defaults.NAVIGATION_IMAGE_TOP,
      true,
      null,
      e,
      "bottom"
    ), t.appendChild(this._navPane);
  }
  function NavigationPane(t, e) {
    this._d5 = t;
    var i = function(e2) {
      var i2, n, o = e2.target, s = o.name;
      if ("left" == s)
        i2 = 1;
      else if ("right" == s)
        i2 = -1;
      else if ("top" == s)
        n = 1;
      else {
        if ("bottom" != s)
          return;
        n = -1;
      }
      isTouchSupport && (o.className = "hover", setTimeout(function() {
        o.className = "";
      }, 100)), _f1(e2), t._l6._mk4(i2, n);
    };
    createNavigationPane.call(this, e, i), this._3n(e.clientWidth, e.clientHeight);
  }
  function ScrollBar(t, e) {
    this._d5 = t, this.init(e, t);
  }
  function ShapeNodeUI() {
    _3g(this, ShapeNodeUI, arguments);
  }
  function TopCanvas(t, e) {
    this._d5 = t, this._jn = createCanvas(e), this.g = this._jn.g, this._9k = new HashList();
  }
  function selectAllElement(t) {
    var e = t.selectionModel, i = [];
    return t.graphModel.forEach(function(e2) {
      t.isVisible(e2) && t.isSelectable(e2) && i.push(e2);
    }), e.set(i);
  }
  function zoomByMouseEvent(t, e, i, n) {
    void 0 === n && (n = Defaults.ZOOM_ANIMATE);
    var o = t.globalToLocal(e);
    return i ? t.zoomIn(o.x, o.y, n) : t.zoomOut(o.x, o.y, n);
  }
  function exportGraph(t, e, i) {
    var n = t.bounds;
    i = i || n, e = e || 1;
    var s = _mkc();
    addLineDashSupport(s.g), s.width = i.width * e, s.height = i.height * e, t._94._h7(s.g, e, i);
    var r = null;
    try {
      r = s.toDataURL("image/png");
    } catch (a) {
      Q2.error(a);
    }
    return { canvas: s, data: r, width: s.width, height: s.height };
  }
  function DrawableInteraction(t) {
    this.graph = t, this.topCanvas = t.topCanvas;
  }
  function InteractionMode(t, e) {
    this.interactions = t, this.defaultCursor = e || "default";
  }
  function CreatePathInteraction() {
    _3g(this, CreatePathInteraction, arguments);
  }
  function mixDrawProperties(t, e) {
    if (!t)
      return e;
    var i = {};
    for (var n in t)
      i[n] = t[n];
    for (var n in e)
      void 0 === i[n] && (i[n] = e[n]);
    return i;
  }
  function CreateEdgeInteraction() {
    _3g(this, CreateEdgeInteraction, arguments);
  }
  function CreateShapeInteraction() {
    _3g(this, CreateShapeInteraction, arguments);
  }
  function CreateLineInteraction() {
    _3g(this, CreateLineInteraction, arguments);
  }
  function CreateSimpleEdgeInteraction() {
    _3g(this, CreateSimpleEdgeInteraction, arguments);
  }
  function localToGlobal(t, e, i) {
    t += window2.pageXOffset, e += window2.pageYOffset;
    var n = i.getBoundingClientRect();
    return { x: t + n.left, y: e + n.top };
  }
  function showDivCenterAt(t, e, i) {
    var n = t.offsetWidth, o = t.offsetHeight;
    t.style.left = e - n / 2 + "px", t.style.top = i - o / 2 + "px";
  }
  function getLabelSize(t) {
    var e = document2.createElement("canvas"), i = e.getContext("2d"), n = getComputedStyle(t, null), o = n.font;
    o || (o = n.fontStyle + " " + n.fontSize + " " + n.fontFamily), i.font = o;
    var s = t.value, r = s.split("\n"), a = parseInt(n.fontSize), h = 0, l = 0;
    return Q2.forEach(r, function(t2) {
      var e2 = i.measureText(t2).width;
      e2 > h && (h = e2), l += 1.2 * a;
    }), { width: h, height: l };
  }
  function pasteIntoInput(t, e) {
    if ("number" == typeof t.selectionStart && "number" == typeof t.selectionEnd) {
      var i = t.value, n = t.selectionStart;
      t.value = i.slice(0, n) + e + i.slice(t.selectionEnd), t.selectionEnd = t.selectionStart = n + e.length;
    } else if ("undefined" != typeof document2.selection) {
      var o = document2.selection.createRange();
      o.text = e, o.collapse(false), o.select();
    }
  }
  function selectInput(t) {
    if (isIE) {
      var e = window2.scrollX || window2.pageXOffset, i = window2.scrollY || window2.pageYOffset;
      return t.select(), void window2.scrollTo(e, i);
    }
    t.select();
  }
  function LabelEditor() {
  }
  function PointsInteraction(t) {
    this.graph = t, this.topCanvas = t.topCanvas, this.handlerSize = isTouchSupport ? 8 : 5;
  }
  function ResizeInteraction(t) {
    this.graph = t, this.topCanvas = t.topCanvas, this.handlerSize = isTouchSupport ? 8 : 4, this._rotateHandleLength = isTouchSupport ? 30 : 20;
  }
  function toUIBounds(t, e) {
    var i = new Rect();
    return i.addPoint(localToParent.call(t, { x: e.x, y: e.y })), i.addPoint(
      localToParent.call(t, {
        x: e.x + e.width,
        y: e.y
      })
    ), i.addPoint(
      localToParent.call(t, {
        x: e.x + e.width,
        y: e.y + e.height
      })
    ), i.addPoint(localToParent.call(t, { x: e.x, y: e.y + e.height })), i;
  }
  function getCursorByAngle(t) {
    t %= 2 * Math.PI;
    var e = Math.round(t / QUARTER_PI);
    return 0 == e || 4 == e ? "ew-resize" : 1 == e || 5 == e ? "nwse-resize" : 2 == e || 6 == e ? "ns-resize" : "nesw-resize";
  }
  function showDivAt(t, e, i) {
    var n = document2.documentElement, o = new Q2.Rect(window2.pageXOffset, window2.pageYOffset, n.clientWidth - 2, n.clientHeight - 2), s = t.offsetWidth, r = t.offsetHeight;
    e + s > o.x + o.width && (e = o.x + o.width - s), i + r > o.y + o.height && (i = o.y + o.height - r), e < o.x && (e = o.x), i < o.y && (i = o.y), t.style.left = e + "px", t.style.top = i + "px";
  }
  function InteractionEvent(t, e, i, n, o) {
    this.source = t, this.type = "interaction", this.kind = e, this.event = i, this.data = n, this.datas = o;
  }
  function InteractionManager(t) {
    this._4g = {}, this._l6 = t, this._l6._1x.addListener(this._9t, this), this.currentMode = Consts.INTERACTION_MODE_DEFAULT;
  }
  function isHorizontalDirection(t) {
    return t >= 10 && 20 > t;
  }
  function isOppositeDirection(t) {
    return t == DIRECTION_LEFT || t == DIRECTION_TOP;
  }
  function prepareLayoutDatas() {
    var t, e, i = {}, n = [], o = 0, s = {}, r = 0;
    this.graph.forEach(function(a2) {
      if (this.isLayoutable(a2)) {
        if (a2 instanceof Node) {
          var h2 = { node: a2, id: a2.id, x: a2.x, y: a2.y };
          for (this.appendNodeInfo && this.appendNodeInfo(a2, h2), i[a2.id] = h2, n.push(h2), o++, e = a2.parent; e instanceof Group; ) {
            t || (t = {});
            var l2 = t[e.id];
            l2 || (l2 = t[e.id] = { id: e.id, children: [] }), l2.children.push(h2), e = e.parent;
          }
        } else if (a2 instanceof Edge && !a2.isLooped() && a2.fromAgent && a2.toAgent) {
          var h2 = { edge: a2 };
          s[a2.id] = h2, r++;
        }
      }
    }, this);
    var a = {};
    for (var h in s) {
      var l = s[h], _ = l.edge, u = _.fromAgent, d = _.toAgent, c = u.id + "-" + d.id, f = d.id + "-" + u.id;
      if (i[u.id] && i[d.id] && !a[c] && !a[f]) {
        var E = i[u.id], g = i[d.id];
        l.from = E, l.to = g, a[c] = l, this.appendEdgeInfo && this.appendEdgeInfo(_, l);
      } else
        delete s[h], r--;
    }
    return {
      groups: t,
      nodesArray: n,
      nodes: i,
      nodeCount: o,
      edges: s,
      edgeCount: r,
      minEnergy: this.minEnergyFunction(o, r)
    };
  }
  function DynamicLayouter(t) {
    this.graph = t, this.currentMovingNodes = {};
  }
  function SpringLayouter() {
    _3g(this, SpringLayouter, arguments);
  }
  function forEachLinkedNode(t, e, i, n, o) {
    n ? t.forEachEdge(
      function(n2) {
        var s = n2.otherNode(t);
        s != i && s._marker != o && e(s, t);
      },
      this,
      true
    ) : t.forEachOutEdge(function(n2) {
      var s = n2.toAgent;
      s != i && s._marker != o && e(s, t);
    });
  }
  var idIndex = 0;
  if (window2.navigator) {
    var userAgent = navigator.userAgent, isOpera = /opera/i.test(userAgent), isIE = !isOpera && /msie/i.test(userAgent), isIE11 = /rv:11.0/i.test(userAgent), isIE10 = /MSIE 10./i.test(userAgent);
    if (isIE11 && (isIE = true), /msie\s[6,7,8]/i.test(userAgent))
      throw new Error("your browser is not supported");
    var isWebkit = /webkit|khtml/i.test(userAgent), isGecko = !isWebkit && /gecko/i.test(userAgent), isFirefox = /firefox\//i.test(userAgent), isChrome = /Chrome\//i.test(userAgent), isSafari = !isChrome && /Safari\//i.test(userAgent), isMac = /Macintosh;/i.test(userAgent), isIOS = /(iPad|iPhone|iPod)/g.test(userAgent), isAndroid = /Android/g.test(userAgent), isWindowsPhone = /Windows Phone/g.test(userAgent), isTouchSupport = (isIOS || isAndroid || isWindowsPhone) && "ontouchstart" in window2, appleWebkitMatch = userAgent.match(/AppleWebKit\/([0-9\.]*)/);
    if (appleWebkitMatch && appleWebkitMatch.length > 1)
      var webkitVersion = parseFloat(appleWebkitMatch[1]);
    if (isAndroid) {
      parseFloat(userAgent.match(/Android\s([0-9\.]*)/)[1]);
      if (webkitVersion && 534.3 >= webkitVersion)
        var withoutClip = true;
    }
  }
  window2.requestAnimationFrame || (window2.requestAnimationFrame = window2.webkitRequestAnimationFrame || window2.mozRequestAnimationFrame || window2.oRequestAnimationFrame || window2.msRequestAnimationFrame || function(t) {
    return window2.setTimeout(function() {
      t();
    }, 1e3 / 60);
  }), window2.cancelAnimationFrame || (window2.cancelAnimationFrame = window2.webkitCancelAnimationFrame || window2.mozCancelAnimationFrame || window2.oCancelAnimationFrame || window2.msCancelAnimationFrame || function(t) {
    return window2.clearTimeout(t);
  });
  var Defaults = { SELECTION_TOLERANCE: 2, DOUBLE_BUFFER: void 0, LABEL_COLOR: "#333" };
  _4u(Defaults, {
    FONT_STYLE: {
      get: function() {
        return this._f2 || (this._f2 = "normal");
      },
      set: function(t) {
        this._f2 != t && (this._f2 = t, this._fontChanged = true);
      }
    },
    FONT_SIZE: {
      get: function() {
        return this._gf || (this._gf = 12);
      },
      set: function(t) {
        this._gf != t && (this._gf = t, this._fontChanged = true);
      }
    },
    FONT_FAMILY: {
      get: function() {
        return this._mm8 || (this._mm8 = "Verdana,helvetica,arial,sans-serif");
      },
      set: function(t) {
        this._mm8 != t && (this._mm8 = t, this._fontChanged = true);
      }
    },
    FONT: {
      get: function() {
        return (this._fontChanged || void 0 === this._fontChanged) && (this._fontChanged = false, this._font = this.FONT_STYLE + " " + this.FONT_SIZE + "px " + this.FONT_FAMILY), this._font;
      }
    }
  });
  var Matrix2D = function() {
  };
  Matrix2D.prototype = {
    _me: 0,
    _mc: 0,
    _la: true,
    _l5: 1,
    _gm: function(t, e, i) {
      var n = this._mm0(e), o = this._mmn(i), s = t * n, r = t * o;
      return this._9j(t, e - s, i - r);
    },
    _mm0: function(t) {
      return (t - this._me) / this._l5;
    },
    _mmn: function(t) {
      return (t - this._mc) / this._l5;
    },
    _el: function(t, e) {
      return this._9j(this._l5, this._me + t, this._mc + e);
    },
    _9j: function(t, e, i) {
      return this._l5 == t && this._me == e && this._mc == i ? false : (this._la && (1 != this.ratio || 2 != this.ratio ? (e = Math.round(e * this.ratio) / this.ratio, i = Math.round(i * this.ratio) / this.ratio) : (e = Math.round(e), i = Math.round(i))), this._me = e, this._mc = i, this._l5 = t, void (this._35 && this._35()));
    },
    _h1: function() {
      return { a: this._l5, b: 0, c: 0, d: this._l5, e: this._me, f: this._mc };
    },
    toString: function() {
      return "matrix(" + _9w(this._l5) + ",0,0," + _9w(this._l5) + "," + _9w(this._me) + "," + _9w(this._mc) + ")";
    },
    _h3: function(t) {
      css_m8CSS(t, "transform", this.toString());
    }
  };
  var HashList = function(t) {
    this._jf = [], this._lp = {}, t && this.add(t);
  };
  HashList.prototype = {
    _jf: null,
    _lp: null,
    get: function(t) {
      return this.getByIndex(t);
    },
    getById: function(t) {
      return this._lp[t];
    },
    getByIndex: function(t) {
      return this._jf[t];
    },
    setByIndex: function(t, e) {
      if (!(0 > t || t >= this.length)) {
        if (!e)
          return void this.remove(this._jf[t]);
        delete this._lp[this._jf[t].id], this._jf[t] = e, this._lp[e.id] = e;
      }
    },
    forEach: function(t, e, i) {
      return _ic(this._jf, t, e, i);
    },
    forEachReverse: function(t, e, i) {
      return _6p(this._jf, t, e, i);
    },
    size: function() {
      return this._jf.length;
    },
    contains: function(t) {
      return this.containsById(t.id);
    },
    containsById: function(t) {
      return this._lp.hasOwnProperty(t);
    },
    setIndex: function(t, e) {
      var i = this._jf.indexOf(t);
      if (0 > i)
        throw new Error("'" + t.id + "' not exist");
      return i == e ? false : (this._jf.splice(i, 1), this._jf.splice(e, 0, t), true);
    },
    setIndexAfter: function(t, e) {
      var i = this._jf.indexOf(t);
      if (0 > i)
        throw new Error("'" + t.id + "' not exist");
      return i == e ? e : i == e + 1 ? e + 1 : (i > e && (e += 1), this._jf.splice(i, 1), this._jf.splice(e, 0, t), e);
    },
    setIndexBefore: function(t, e) {
      var i = this._jf.indexOf(t);
      if (0 > i)
        throw new Error("'" + t.id + "' not exist");
      return i == e ? e : i == e - 1 ? e - 1 : (e > i && (e -= 1), this._jf.splice(i, 1), this._jf.splice(e, 0, t), e);
    },
    indexOf: function(t) {
      return this._jf.indexOf(t);
    },
    getIndexById: function(t) {
      var e = this.getById(t);
      return e ? this._jf.indexOf(e) : -1;
    },
    add: function(t, e) {
      return _ig(t) ? this._fx(t, e) : this._kh(t, e);
    },
    addFirst: function(t) {
      return this.add(t, 0);
    },
    _fx: function(t, e) {
      if (0 == t.length)
        return false;
      var i = false, n = e >= 0;
      t = t._jf || t;
      for (var o = 0, s = t.length; s > o; o++) {
        var r = t[o];
        null !== r && void 0 !== r && this._kh(r, e, true) && (i = true, n && e++);
      }
      return i;
    },
    _kh: function(t, e) {
      var i = t.id;
      return void 0 === i || this.containsById(i) ? false : (_m9(this._jf, t, e), this._lp[i] = t, t);
    },
    remove: function(t) {
      return _ig(t) ? this._mke(t) : t.id ? this._g3(t.id, t) : this.removeById(t);
    },
    _mke: function(t) {
      if (0 == t.length)
        return false;
      var e = false;
      t = t._jf || t;
      for (var i = 0, n = t.length; n > i; i++) {
        var o = t[i];
        if (null !== o && void 0 !== o) {
          void 0 === o.id && (o = this._lp[o]);
          var s = o.id;
          this._g3(s, o, true) && (e = true);
        }
      }
      return e;
    },
    _g3: function(t, e) {
      return void 0 !== t && this.containsById(t) ? ((null === e || void 0 === e) && (e = this.getById(t)), delete this._lp[t], _jh(this._jf, e), true) : false;
    },
    removeById: function(t) {
      var e = this._lp[t];
      return e ? this._g3(t, e) : false;
    },
    set: function(t) {
      if (!t || 0 == t)
        return void this.clear();
      if (this.isEmpty() || !_ig(t))
        return this.clear(), this.add(t);
      var e = [], i = {}, n = 0;
      if (_ic(
        t,
        function(t2) {
          this._lp[t2.id] ? (i[t2.id] = t2, n++) : e.push(t2);
        },
        this
      ), n != this.length) {
        var o = [];
        this.forEach(function(t2) {
          i[t2.id] || o.push(t2);
        }, this), o.length && this._mke(o);
      }
      return e.length && this._fx(e), true;
    },
    clear: function() {
      return this.isEmpty() ? false : (this._jf.length = 0, this._lp = {}, true);
    },
    toDatas: function() {
      return this._jf.slice(0);
    },
    isEmpty: function() {
      return 0 == this._jf.length;
    },
    valueOf: function() {
      return this._jf.length;
    },
    clone: function(t) {
      var e = new HashList();
      return e.add(t ? _d7(this._jf) : this.toDatas()), e;
    }
  }, _4u(HashList.prototype, {
    datas: {
      get: function() {
        return this._jf;
      }
    },
    random: {
      get: function() {
        return this._jf && this._jf.length ? this._jf[_ee(this._jf.length)] : null;
      }
    },
    length: {
      get: function() {
        return this._jf ? this._jf.length : 0;
      }
    }
  });
  var HALF_PI = 0.5 * Math.PI, getFirstElementChildByTagName = function(t, e) {
    e = e.toUpperCase();
    for (var i = isIE ? t.firstChild : t.firstElementChild; i && (1 != i.nodeType || i.tagName && i.tagName.toUpperCase() != e); )
      i = isIE ? i.nextSibling : i.nextElementSibling;
    return i && 1 == i.nodeType && i.tagName && i.tagName.toUpperCase() == e ? i : null;
  }, Point = function(t, e, i) {
    t instanceof Point && (e = t.y, t = t.x, i = t.rotate), this.set(t, e, i);
  }, calculateDistance = function(t, e, i, n) {
    var o = t - i, s = e - n;
    return Math.sqrt(o * o + s * s);
  };
  Point.prototype = {
    x: 0,
    y: 0,
    rotate: void 0,
    set: function(t, e, i) {
      this.x = t || 0, this.y = e || 0, this.rotate = i || 0;
    },
    negate: function() {
      this.x = -this.x, this.y = -this.y;
    },
    offset: function(t, e) {
      this.x += t, this.y += e;
    },
    equals: function(t) {
      return this.x == t.x && this.y == t.y;
    },
    distanceTo: function(t) {
      return calculateDistance(this.x, this.y, t.x, t.y);
    },
    toString: function() {
      return "Point(" + this.x + ", " + this.y + ")";
    },
    clone: function() {
      return new Point(this.x, this.y);
    }
  }, Object.defineProperty(Point.prototype, "distance", {
    get: function() {
      return Math.sqrt(this.x * this.x + this.y * this.y);
    }
  });
  var Line = function(t, e, i, n) {
    void 0 !== t && this._m8(t, e, i, n);
  };
  Line.prototype = {
    _mg: null,
    _mb: null,
    _mi: null,
    _mj: null,
    _mk: null,
    _mo: null,
    _mm: 1,
    _m8: function(t, e, i, n) {
      this._mg = t, this._mb = e, this._mi = i, this._mj = n, t == i ? (this._mk = -1, this._mm = 0, this._mo = t) : (this._mk = (e - n) / (t - i), this._mo = e - this._mk * t, this._mm = 1), this._ko = Math.atan2(this._mj - this._mb, this._mi - this._mg), this._mmos = Math.cos(this._ko), this._sin = Math.sin(this._ko);
    },
    _mmj: function(t) {
      return 0 == this._mm ? Number.NaN : this._mk * t + this._mo;
    },
    _mmd: function(t) {
      return 0 == this._mk ? Number.NaN : (t - this._mo) / this._mk;
    },
    _$l: function(t) {
      var e, i, n, o, s, r = t[0], a = t[2], h = t[4], l = t[1], _ = t[3], u = t[5], d = this._mk, c = this._mo, f = this._mm;
      if (0 == f ? (n = Math.sqrt((-d * d * r - d * c) * h + d * d * a * a + 2 * d * c * a - d * c * r), o = -d * a + d * r, s = d * h - 2 * d * a + d * r) : (n = Math.sqrt(
        (-l + d * r + c) * u + _ * _ + (-2 * d * a - 2 * c) * _ + (d * h + c) * l + (-d * d * r - d * c) * h + d * d * a * a + 2 * d * c * a - d * c * r
      ), o = -_ + l + d * a - d * r, s = u - 2 * _ + l - d * h + 2 * d * a - d * r), 0 != s) {
        e = (n + o) / s, i = (-n + o) / s;
        var E, g;
        return e >= 0 && 1 >= e && (E = pointOnQuadratic(e, t)), i >= 0 && 1 >= i && (g = pointOnQuadratic(i, t)), E && g ? [E, g] : E ? E : g ? g : void 0;
      }
    },
    _3y: function(t, e, i) {
      if (this._mk == t._mk || 0 == this._mm && 0 == t._mm)
        return null;
      var n, o;
      if (n = 0 == this._mm ? this._mo : 0 == t._mm ? t._mo : (t._mo - this._mo) / (this._mk - t._mk), o = 0 == this._mk ? this._mo : 0 == t._mk ? t._mo : this._mm ? this._mk * n + this._mo : t._mk * n + t._mo, !e)
        return {
          x: n,
          y: o
        };
      var s, r, a;
      if (i)
        s = -e / 2, r = -s;
      else {
        s = -calculateDistance(this._mg, this._mb, n, o), r = calculateDistance(this._mi, this._mj, n, o);
        var h = -s + r;
        if (h > e) {
          var l = e / h;
          s *= l, r *= l;
        } else
          a = (e - h) / 2;
      }
      var _ = this._71(n, o, s), u = this._71(n, o, r);
      return a && (_._rest = a, u._rest = a), [_, u];
    },
    _71: function(t, e, i) {
      return 0 == this._mm ? { x: t, y: e + i } : { x: t + i * this._mmos, y: e + i * this._sin };
    }
  };
  var Size = function(t, e) {
    this.width = t, this.height = e;
  };
  Size.prototype = {
    width: 0,
    height: 0,
    isEmpty: function() {
      return this.width <= 0 || this.height <= 0;
    },
    clone: function() {
      return new Size(this.width, this.height);
    },
    toString: function() {
      return "Size(" + this.width + ", " + this.height + ")";
    }
  };
  var Rect = function(t, e, i, n) {
    void 0 === i && (i = -1), void 0 === n && (n = -1), this.x = t || 0, this.y = e || 0, this.width = i, this.height = n;
  };
  Rect.prototype = {
    x: 0,
    y: 0,
    width: -1,
    height: -1,
    setByRect: function(t) {
      this.x = t.x || 0, this.y = t.y || 0, this.width = t.width || 0, this.height = t.height || 0;
    },
    set: function(t, e, i, n) {
      this.x = t || 0, this.y = e || 0, this.width = i || 0, this.height = n || 0;
    },
    offset: function(t, e) {
      this.x += t, this.y += e;
    },
    contains: function(t, e) {
      return t instanceof Rect ? containsRect(this.x, this.y, this.width, this.height, t.x, t.y, t.width, t.height) : t >= this.x && t <= this.x + this.width && e >= this.y && e <= this.y + this.height;
    },
    intersectsPoint: function(t, e, i) {
      return this.width <= 0 && this.height <= 0 ? false : i ? this.intersectsRect(t - i, e - i, 2 * i, 2 * i) : t >= this.x && t <= this.x + this.width && e >= this.y && e <= this.y + this.height;
    },
    intersectsRect: function(t, e, i, n) {
      return intersectsRect(this.x, this.y, this.width, this.height, t, e, i, n);
    },
    intersects: function(t, e) {
      return t instanceof Rect ? this.intersectsRect(t.x, t.y, t.width, t.height) : this.intersectsPoint(t, e);
    },
    intersection: function(t, e, i, n) {
      var o = this.x, s = this.y, r = o;
      r += this.width;
      var a = s;
      a += this.height;
      var h = t;
      h += i;
      var l = e;
      return l += n, t > o && (o = t), e > s && (s = e), r > h && (r = h), a > l && (a = l), r -= o, a -= s, 0 > r || 0 > a ? null : new Rect(o, s, r, a);
    },
    addPoint: function(t) {
      this.add(t.x, t.y);
    },
    add: function(t, e) {
      if (t instanceof Rect)
        return this.addRect(t.x, t.y, t.width, t.height);
      if (t instanceof Point && (e = t.y, t = t.x), this.width < 0 || this.height < 0)
        return this.x = t, this.y = e, void (this.width = this.height = 0);
      var i = this.x, n = this.y, o = this.width, s = this.height;
      o += i, s += n, i > t && (i = t), n > e && (n = e), t > o && (o = t), e > s && (s = e), o -= i, s -= n, o > Number.MAX_VALUE && (o = Number.MAX_VALUE), s > Number.MAX_VALUE && (s = Number.MAX_VALUE), this.set(i, n, o, s);
    },
    addRect: function(t, e, i, n) {
      var o = this.width, s = this.height;
      (0 > o || 0 > s) && this.set(t, e, i, n);
      var r = i, a = n;
      if (!(0 > r || 0 > a)) {
        var h = this.x, l = this.y;
        o += h, s += l;
        var _ = t, u = e;
        r += _, a += u, h > _ && (h = _), l > u && (l = u), r > o && (o = r), a > s && (s = a), o -= h, s -= l, o > Number.MAX_VALUE && (o = Number.MAX_VALUE), s > Number.MAX_VALUE && (s = Number.MAX_VALUE), this.set(h, l, o, s);
      }
    },
    grow: function(t, e, i, n) {
      return _gd(t) ? 1 == arguments.length ? n = e = i = t || 0 : 2 == arguments.length ? (i = t || 0, n = e || 0) : (t = t || 0, e = e || 0, i = i || 0, n = n || 0) : (e = t.left || 0, i = t.bottom || 0, n = t.right || 0, t = t.top || 0), this.x -= e, this.y -= t, this.width += e + n, this.height += t + i, this;
    },
    isEmpty: function() {
      return this.width <= 0 && this.height <= 0;
    },
    toString: function() {
      return this.x + " , " + this.y + " , " + this.width + " , " + this.height;
    },
    union: function(t) {
      var e = this.width, i = this.height;
      if (0 > e || 0 > i)
        return new Rect(t.x, t.y, t.width, t.height);
      var n = t.width, o = t.height;
      if (0 > n || 0 > o)
        return new Rect(this.x, this.y, this.width, this.height);
      var s = this.x, r = this.y;
      e += s, i += r;
      var a = t.x, h = t.y;
      return n += a, o += h, s > a && (s = a), r > h && (r = h), n > e && (e = n), o > i && (i = o), e -= s, i -= r, e > Number.MAX_VALUE && (e = Number.MAX_VALUE), i > Number.MAX_VALUE && (i = Number.MAX_VALUE), new Rect(s, r, e, i);
    },
    clear: function() {
      this.set(0, 0, -1, -1);
    },
    equals: function(t) {
      return this.x == t.x && this.y == t.y && this.width == t.width && this.height == t.height;
    },
    clone: function(t, e) {
      return new Rect(this.x + (t || 0), this.y + (e || 0), this.width, this.height);
    },
    getIntersectionPoint: function(t, e, i, n) {
      return getIntersectionPointOnRect(this, t, e, i, n);
    }
  }, _jq(Rect, Size), _4u(Rect.prototype, {
    left: {
      get: function() {
        return this.x;
      }
    },
    top: {
      get: function() {
        return this.y;
      }
    },
    bottom: {
      get: function() {
        return this.y + this.height;
      }
    },
    right: {
      get: function() {
        return this.x + this.width;
      }
    },
    cx: {
      get: function() {
        return this.x + this.width / 2;
      }
    },
    cy: {
      get: function() {
        return this.y + this.height / 2;
      }
    },
    center: {
      get: function() {
        return new Point(this.cx, this.cy);
      }
    }
  });
  var Insets = function(t, e, i, n) {
    1 == arguments.length ? e = i = n = t : 2 == arguments.length && (i = t, n = e), this.set(t, e, i, n);
  };
  Insets.prototype = {
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    set: function(t, e, i, n) {
      this.top = t || 0, this.left = e || 0, this.bottom = i || 0, this.right = n || 0;
    },
    clone: function() {
      return new Insets(this.top, this.left, this.bottom, this.right);
    },
    equals: function(t) {
      return t && this.top == t.top && this.bottom == t.bottom && this.left == t.left && this.right == t.right;
    }
  };
  var Position = function(t, e) {
    this.horizontalPosition = t, this.verticalPosition = e;
  };
  Position.prototype = {
    verticalPosition: false,
    horizontalPosition: false,
    toString: function() {
      return (this.horizontalPosition || "") + (this.verticalPosition || "");
    }
  }, _6u(Position.prototype, "sortName", {
    get: function() {
      return (this.horizontalPosition || "") + (this.verticalPosition || "");
    }
  });
  var LEFT = "l", CENTER = "c", RIGHT = "r", TOP = "t", MIDDLE = "m", BOTTOM = "b";
  Position.LEFT_TOP = new Position(LEFT, TOP), Position.LEFT_MIDDLE = new Position(LEFT, MIDDLE), Position.LEFT_BOTTOM = new Position(LEFT, BOTTOM), Position.CENTER_TOP = new Position(CENTER, TOP), Position.CENTER_MIDDLE = new Position(CENTER, MIDDLE), Position.CENTER_BOTTOM = new Position(CENTER, BOTTOM), Position.RIGHT_TOP = new Position(RIGHT, TOP), Position.RIGHT_MIDDLE = new Position(RIGHT, MIDDLE), Position.RIGHT_BOTTOM = new Position(RIGHT, BOTTOM);
  var positions = [
    Position.LEFT_TOP,
    Position.LEFT_MIDDLE,
    Position.LEFT_BOTTOM,
    Position.CENTER_TOP,
    Position.CENTER_MIDDLE,
    Position.CENTER_BOTTOM,
    Position.RIGHT_TOP,
    Position.RIGHT_MIDDLE,
    Position.RIGHT_BOTTOM
  ];
  _6u(Position, "random", {
    get: function() {
      return positions[_ee(positions.length)];
    }
  });
  var RoundRect = function(t, e, i, n, o) {
    this.set(t, e, i, n), this.radius = o;
  };
  RoundRect.prototype = {
    radius: 0,
    classify: function(t, e, i, n) {
      return e > t ? 0 : e + n > t ? 1 : i - n > t ? 2 : i > t ? 3 : 4;
    },
    intersectsRect: function(t, e, i, n) {
      if (_hr(this, RoundRect, "intersectsRect", arguments) === false)
        return false;
      var o = this.x, s = this.y, r = o + this.width, a = s + this.height, h = 2 * radius, l = 2 * radius, _ = Math.min(this.width, Math.abs(h)) / 2, u = Math.min(this.height, Math.abs(l)) / 2, d = this.classify(t, o, r, _), c = this.classify(t + i, o, r, _), f = this.classify(e, s, a, u), E = this.classify(e + n, s, a, u);
      return 2 == d || 2 == c || 2 == f || 2 == E ? true : 2 > d && c > 2 || 2 > f && E > 2 ? true : (t = 1 == c ? t = t + i - (o + _) : t -= r - _, e = 1 == E ? e = e + n - (s + u) : e -= a - u, t /= _, e /= u, 1 >= t * t + e * e);
    },
    intersectsPoint: function(t, e) {
      if (_hr(this, RoundRect, "intersectsPoint", arguments) === false)
        return false;
      var i = this.x, n = this.y, o = i + this.width, s = n + this.height;
      if (i > t || n > e || t >= o || e >= s)
        return false;
      var r = 2 * radius, a = 2 * radius, h = Math.min(this.width, Math.abs(r)) / 2, l = Math.min(this.height, Math.abs(a)) / 2;
      return t >= (i += h) && t < (i = o - h) ? true : e >= (n += l) && e < (n = s - l) ? true : (t = (t - i) / h, e = (e - n) / l, 1 >= t * t + e * e);
    },
    clone: function() {
      return new RoundRect(this.x, this.y, this.width, this.height, this.radius);
    }
  }, _jq(RoundRect, Rect);
  var Event = function(t, e, i, n) {
    this.source = t, this.type = e, this.kind = i, this.value = n;
  };
  Event.prototype = {
    source: null,
    type: null,
    kind: null,
    value: null,
    toString: function() {
      return "source: " + this.source + ", type: " + this.type + ", kind: " + this.kind;
    }
  };
  var PropertyChangeEvent = function(t, e, i, n, o) {
    this.source = t, this.kind = e, this.oldValue = n, this.value = i, this.propertyType = o;
  };
  PropertyChangeEvent.prototype = {
    type: "property.change",
    propertyType: null,
    toString: function() {
      return "source: " + this.source + ", type: " + this.type + ", propertyName: " + this.kind + ", oldValue: " + this.oldValue + ", value: " + this.value;
    }
  }, _jq(PropertyChangeEvent, Event), _6u(PropertyChangeEvent.prototype, "propertyName", {
    get: function() {
      return this.kind;
    },
    set: function(t) {
      this.kind = t;
    }
  });
  var ParentChangeEvent = function(t, e, i) {
    this.source = t, this.oldValue = t.parent, this.value = e, this.newIndex = i, this.oldValue && (this.oldIndex = this.oldValue.getChildIndex(t));
  };
  ParentChangeEvent.prototype = { kind: "parent" }, _jq(ParentChangeEvent, PropertyChangeEvent);
  var ChildAddEvent = function(t, e) {
    this.source = t, this.value = e;
  };
  ChildAddEvent.prototype.kind = "child.add", _jq(ChildAddEvent, PropertyChangeEvent);
  var ChildRemoveEvent = function(t, e) {
    this.source = t, this.value = e;
  };
  ChildRemoveEvent.prototype.kind = "child.remove", _jq(ChildRemoveEvent, PropertyChangeEvent);
  var ChildIndexChangeEvent = function(t, e, i, n) {
    this.source = e, this.oldValue = i, this.value = n, this.parent = t, this.child = e, this.oldIndex = i, this.newIndex = n;
  };
  ChildIndexChangeEvent.prototype.kind = "child.index", _jq(ChildIndexChangeEvent, PropertyChangeEvent);
  var Handler = function() {
  };
  Handler.prototype = {
    listener: null,
    beforeEvent: function(t) {
      return null != this.listener && this.listener.beforeEvent ? this.listener.beforeEvent(t) : true;
    },
    onEvent: function(t) {
      null != this.listener && this.listener.onEvent && this.listener.onEvent(t);
    }
  };
  var Dispatcher = function() {
    _3g(this, Dispatcher, arguments), this.events = {}, this.listeners = [];
  }, QListener = function(t, e) {
    this.listener = t, this.scope = e, t instanceof Function ? this.onEvent = t : (this.onEvent = t.onEvent, this.beforeEvent = t.beforeEvent), this.equals = function(t2) {
      return t2 && this.listener == t2.listener && this.scope == t2.scope;
    };
  };
  QListener.prototype = {
    equals: function(t) {
      return t && this.listener == t.listener && this.scope == t.scope;
    },
    destroy: function() {
      delete this.scope, delete this.listener;
    }
  }, Dispatcher.prototype = {
    listeners: null,
    _mot: function() {
      return this.listeners && this.listeners.length > 0;
    },
    _6q: function(t, e) {
      return t instanceof Dispatcher ? t : new QListener(t, e);
    },
    _9b: function(t, e) {
      if (t instanceof Dispatcher)
        return this.listeners.indexOf(t);
      for (var i = this.listeners, n = 0, o = i.length; o > n; n++) {
        var s = i[n];
        if (s.listener == t && s.scope == e)
          return n;
      }
      return -1;
    },
    contains: function(t, e) {
      return this._9b(t, e) >= 0;
    },
    addListener: function(t, e) {
      return this.contains(t, e) ? false : void this.listeners.push(this._6q(t, e));
    },
    removeListener: function(t, e, i) {
      var n = this._9b(t, e);
      if (n >= 0) {
        var o = this.listeners.splice(n, 1)[0];
        i || _7d(o);
      }
    },
    on: function(t, e) {
      this.addListener(t, e);
    },
    un: function(t, e, i) {
      this.removeListener(t, e, i);
    },
    onEvent: function(t) {
      return this.listeners ? void _ic(
        this.listeners,
        function(e) {
          e.onEvent && (e.scope ? e.onEvent.call(e.scope, t) : e.onEvent(t));
        },
        this
      ) : false;
    },
    beforeEvent: function(t) {
      return this.listeners ? _ic(
        this.listeners,
        function(e) {
          return e.beforeEvent ? e.scope ? e.beforeEvent.call(e.scope, t) : e.beforeEvent(t) : true;
        },
        this
      ) : true;
    },
    _dp: function(t) {
      return this.beforeEvent(t) === false ? false : (this.onEvent(t), true);
    },
    clear: function() {
      this.listeners = [];
    },
    destroy: function() {
      this.clear();
    }
  }, _jq(Dispatcher, Handler);
  var IListener = {
    onEvent: function() {
    },
    beforeEvent: function() {
    }
  }, ListEvent = function(t, e, i, n, o) {
    this.source = t, this.type = "list", this.kind = e, this.data = i, this.index = n, this.oldIndex = o;
  };
  ListEvent.prototype = {
    index: -1,
    oldIndex: -1,
    toString: function() {
      return "source: " + this.source + ", type: " + this.type + ", kind: " + this.kind + ", data: " + this.data + ", index: " + this.index + ", oldIndex: " + this.oldIndex;
    }
  }, _jq(ListEvent, Event), ListEvent.KIND_ADD = "add", ListEvent.KIND_REMOVE = "remove", ListEvent.KIND_CLEAR = "clear", ListEvent.KIND_INDEX_CHANGE = "index.change";
  var Data = function() {
    this.id = ++idIndex, this._mm5 = {};
  };
  Data.prototype = {
    _mm5: null,
    id: null,
    get: function(t) {
      return this._mm5[t];
    },
    set: function(t, e) {
      var i = this.get(t);
      if (i === e)
        return false;
      var n = new PropertyChangeEvent(this, t, e, i);
      return n.propertyType = Consts.PROPERTY_TYPE_CLIENT, this._mkm(t, e, n, this._mm5);
    },
    _mkm: function(t, e, i, n) {
      return this.beforeEvent(i) === false ? false : (n || (n = this._mm5), void 0 === e ? delete n[t] : n[t] = e, this.onEvent(i), true);
    },
    remove: function(t) {
      this.set(t, null);
    },
    valueOf: function() {
      return this.id;
    },
    toString: function() {
      return this.id;
    },
    _dq: function(t, e) {
      if (void 0 === e && (e = -1), this == t || t == this._j2)
        return false;
      if (t && this == t._j2 && !t._dq(null))
        return false;
      var i = new ParentChangeEvent(this, t, e);
      if (!this.beforeEvent(i))
        return false;
      var n, o, s = this._j2;
      return t && (n = new ChildAddEvent(t, this), !t.beforeEvent(n)) ? false : null == s || (o = new ChildRemoveEvent(s, this), s.beforeEvent(o)) ? (this._j2 = t, null != t && doChildAdd(t, this, e), null != s && doChildRemove(s, this), this.onEvent(i), null != t && t.onEvent(n), null != s && s.onEvent(o), this.onParentChanged(s, t), true) : false;
    },
    addChild: function(t, e) {
      var i = t._dq(this, e);
      return i && this.onChildAdd(t, e), i;
    },
    onChildAdd: function() {
    },
    removeChild: function(t) {
      if (!this._fv || !this._fv.contains(t))
        return false;
      var e = t._dq(null);
      return this.onChildRemove(t), e;
    },
    onChildRemove: function() {
    },
    toChildren: function() {
      return this._fv ? this._fv.toDatas() : null;
    },
    clearChildren: function() {
      if (this._fv && this._fv.length) {
        var t = this.toChildren();
        _ic(
          t,
          function(t2) {
            t2._dq(null);
          },
          this
        ), this.onChildrenClear(t);
      }
    },
    forEachChild: function(t, e) {
      return this.hasChildren() ? this._fv.forEach(t, e) : false;
    },
    onChildrenClear: function() {
    },
    getChildIndex: function(t) {
      return this._fv && this._fv.length ? this._fv.indexOf(t) : -1;
    },
    setChildIndex: function(t, e) {
      if (!this._fv || !this._fv.length)
        return false;
      var i = this._fv.indexOf(t);
      if (0 > i || i == e)
        return false;
      var n = new ChildIndexChangeEvent(this, t, i, e);
      return this.beforeEvent(n) === false ? false : (this._fv.remove(t) && this._fv.add(t, e), this.onEvent(n), true);
    },
    hasChildren: function() {
      return this._fv && this._fv.length > 0;
    },
    getChildAt: function(t) {
      return null == this._fv ? null : this._fv._jf[t];
    },
    isDescendantOf: function(t) {
      if (!t.hasChildren())
        return false;
      for (var e = this.parent; null != e; ) {
        if (t == e)
          return true;
        e = e.parent;
      }
      return false;
    },
    onParentChanged: function() {
    },
    firePropertyChangeEvent: function(t, e, i, n) {
      this.onEvent(new PropertyChangeEvent(this, t, e, i, n));
    }
  }, _jq(Data, Handler), _4u(Data.prototype, {
    childrenCount: {
      get: function() {
        return this._fv ? this._fv.length : 0;
      }
    },
    children: {
      get: function() {
        return this._fv || (this._fv = new HashList()), this._fv;
      }
    },
    parent: {
      get: function() {
        return this._j2;
      },
      set: function(t) {
        this._dq(t, -1);
      }
    },
    properties: {
      get: function() {
        return this._mm5;
      },
      set: function(t) {
        this._mm5 != t && (this._mm5 = t);
      }
    }
  });
  var HashCollection = function() {
    this._jf = [], this._lp = {}, this._1x = new Dispatcher();
  };
  HashCollection.prototype = {
    beforeEvent: function(t) {
      return null != this._1x && this._1x.beforeEvent ? this._1x.beforeEvent(t) : true;
    },
    onEvent: function(t) {
      return this._1x instanceof Function ? void this._1x(t) : void (null != this._1x && this._1x.onEvent && this._1x.onEvent(t));
    },
    _1x: null,
    setIndex: function(t, e) {
      if (!this.contains(t))
        throw new Error("'" + t.getId() + "' not exist");
      var i = this.indexOf(t);
      if (i == e)
        return false;
      var n = new ListEvent(this, ListEvent.KIND_INDEX_CHANGE, t, e, i);
      return this.beforeEvent(n) === false ? false : (this._jf.remove(t) >= 0 && this._jf.add(e, t), this.onEvent(n), true);
    },
    _fx: function(t, e) {
      if (0 == t.length)
        return false;
      var i = false, n = e >= 0, o = new ListEvent(this, ListEvent.KIND_ADD, t, e);
      if (this.beforeEvent(o) === false)
        return false;
      var s = [];
      t = t._jf || t;
      for (var r = 0, a = t.length; a > r; r++) {
        var h = t[r];
        null !== h && void 0 !== h && this._kh(h, e, true) && (s.push(h), i = true, n && e++);
      }
      return o.data = s, this.onEvent(o), i;
    },
    _kh: function(t, e, i) {
      if (this.accept(t) === false)
        return false;
      if (i)
        return _hr(this, HashCollection, "_kh", arguments);
      var n = new ListEvent(this, ListEvent.KIND_ADD, t, e);
      return this.beforeEvent(n) === false ? false : _hr(this, HashCollection, "_kh", arguments) ? (this._kj(t, n), t) : false;
    },
    _kj: function(t, e) {
      this.onEvent(e);
    },
    _mke: function(t) {
      if (0 == t.length)
        return false;
      var e = new ListEvent(this, ListEvent.KIND_REMOVE, t);
      if (this.beforeEvent(e) === false)
        return false;
      var i = [], n = false;
      t = t._jf || t;
      for (var o = 0, s = t.length; s > o; o++) {
        var r = t[o];
        if (null !== r && void 0 !== r) {
          var a = r.id || r;
          void 0 === r.id && (r = null), this._g3(a, r, true) && (i.push(r), n = true);
        }
      }
      return e.data = i, this.onEvent(e), n;
    },
    _g3: function(t, e, i) {
      if (i)
        return _hr(this, HashCollection, "_g3", arguments);
      var n = new ListEvent(this, ListEvent.KIND_REMOVE, e);
      return this.beforeEvent(n) === false ? false : _hr(this, HashCollection, "_g3", arguments) ? (this.onEvent(n), true) : false;
    },
    clear: function() {
      if (this.isEmpty())
        return false;
      var t = new ListEvent(this, ListEvent.KIND_CLEAR, this.toDatas());
      return this.beforeEvent(t) === false ? false : _hr(this, HashCollection, "clear") ? (this.onEvent(t), true) : false;
    },
    accept: function(t) {
      return this.filter && this.filter(t) === false ? false : true;
    }
  }, _jq(HashCollection, HashList), _6u(HashCollection.prototype, "listChangeDispatcher", {
    get: function() {
      return this._1x;
    }
  });
  var DataModel = function() {
    _3g(this, DataModel, arguments), this.selectionChangeDispatcher = new Dispatcher(), this._selectionModel = new SelectionModel(this), this._selectionModel._1x = this.selectionChangeDispatcher, this.dataChangeDispatcher = new Dispatcher(), this.dataChangeDispatcher.addListener(
      {
        beforeEvent: this.beforeDataPropertyChange,
        onEvent: this.onDataPropertyChanged
      },
      this
    ), this.parentChangeDispatcher = new Dispatcher(), this.childIndexChangeDispatcher = new Dispatcher(), this.$roots = new HashList();
    var t = this;
    this.$roots.setIndex = function(e, i) {
      if (!t.$roots.contains(e))
        throw new Error("'" + e.id + "' not exist");
      var n = t.$roots._jf.indexOf(e);
      if (n == i)
        return false;
      t.$roots._jf.splice(n, 1), t.$roots._jf.splice(i, 0, e), t._mmcIndexFlag = true;
      var o = new ChildIndexChangeEvent(t, e, n, i);
      return t._2l(o), true;
    };
  };
  DataModel.prototype = {
    selectionModel: null,
    selectionChangeDispatcher: null,
    dataChangeDispatcher: null,
    parentChangeDispatcher: null,
    roots: null,
    _kj: function(t, e) {
      t.listener = this.dataChangeDispatcher, t.parent || this.$roots.add(t), this.onEvent(e);
    },
    _g3: function(t, e) {
      if (_hr(this, DataModel, "_g3", arguments)) {
        if (e instanceof Edge)
          e.disconnect();
        else if (e instanceof Node) {
          var i = e.getEdges();
          this.remove(i);
        }
        var n = e.parent;
        return null == n ? this.$roots.remove(e) : (n.removeChild(e), n.__6k = true), e.hasChildren() && this.remove(e.toChildren()), e.listener = null, true;
      }
      return false;
    },
    _61: function(t) {
      var e = t.source;
      this.contains(e) && (null == e.parent ? this.$roots.add(e) : null == t.oldValue && this.$roots.remove(e), this.parentChangeDispatcher.onEvent(t));
    },
    _2l: function(t) {
      this.childIndexChangeDispatcher.onEvent(t);
    },
    beforeDataPropertyChange: function(t) {
      return t instanceof ParentChangeEvent ? this.parentChangeDispatcher.beforeEvent(t) : true;
    },
    onDataPropertyChanged: function(t) {
      return t instanceof ParentChangeEvent ? (this._mmcIndexFlag = true, t.source._mmcIndexFlag = true, void this._61(t)) : void (t instanceof ChildIndexChangeEvent && (this._mmcIndexFlag = true, t.source._mmcIndexFlag = true, this._2l(t)));
    },
    toRoots: function() {
      return this.$roots.toDatas();
    },
    _gi: function(t) {
      var e, i = t._j2;
      e = i ? i._fv : this.$roots;
      var n = e.indexOf(t);
      if (0 > n)
        throw new Error("data '" + t + "' not exist in the box");
      return 0 == n ? i : e.getByIndex(n - 1);
    },
    _gk: function(t) {
      var e, i = t._j2;
      e = i ? i._fv : this.$roots;
      var n = e.indexOf(t);
      if (0 > n)
        throw new Error("data '" + t + "' not exist in the box");
      return n == e.length - 1 ? i ? this._gk(i) : null : e.getByIndex(n + 1);
    },
    forEachByDepthFirst: function(t, e, i) {
      return this.$roots.length ? _2t(this.$roots, t, e, i) : false;
    },
    forEachByDepthFirstReverse: function(t, e, i) {
      return this.$roots.length ? _$r(this.$roots, t, e, i) : false;
    },
    forEachByBreadthFirst: function(t, e) {
      return this.$roots.length ? _1j(this.$roots, t, e) : false;
    },
    forEachByBreadthFirstReverse: function(t, e) {
      return this.$roots.length ? _$a(this.$roots, t, e) : false;
    },
    clear: function() {
      return _hr(this, DataModel, "clear") ? (this.$roots.clear(), this.selectionModel.clear(), true) : false;
    }
  }, _jq(DataModel, HashCollection), _4u(DataModel.prototype, {
    selectionModel: {
      get: function() {
        return this._selectionModel;
      }
    },
    roots: {
      get: function() {
        return this.$roots;
      }
    }
  });
  var SelectionModel = function(t) {
    _3g(this, SelectionModel), this.box = t, this._mooxChangeListener = {
      onEvent: function(t2) {
        ListEvent.KIND_REMOVE == t2.kind ? null != t2.data ? this.remove(t2.data) : null != t2.datas && this.remove(t2.datas) : ListEvent.KIND_CLEAR == t2.kind && this.clear();
      }
    }, this.box.listChangeDispatcher.addListener(this._mooxChangeListener, this);
  };
  SelectionModel.prototype = {
    box: null,
    isSelected: function(t) {
      return this.containsById(t.id || t);
    },
    select: function(t) {
      return this.add(t);
    },
    unselect: function(t) {
      return this.remove(t);
    },
    reverseSelect: function(t) {
      return this.contains(t) ? this.remove(t) : this.add(t);
    },
    accept: function(t) {
      return this.box.contains(t);
    }
  }, _jq(SelectionModel, HashCollection);
  var css_styleSheet = null, css_prefix = null, css_pre = function() {
    if (!document2.createElement)
      return function(t2) {
        return t2;
      };
    var t = document2.createElement("div"), e = t.style, i = {};
    return function(t2) {
      if (i[t2])
        return i[t2];
      var n = css_mmamelCase(t2);
      return void 0 !== e[n] || css_prefix && void 0 !== e[n = css_mmamelCase(css_prefix + n)] ? (i[t2] = n, n) : t2;
    };
  }(), css_DefaultCSS = {};
  !function() {
    if (!document2.head)
      return false;
    for (var t = document2.head, e = "Webkit Moz O ms Khtml".split(" "), i = 0; i < e.length; i++)
      if (void 0 !== t.style[e[i] + "Transform"]) {
        css_prefix = "-" + e[i].toLowerCase() + "-";
        break;
      }
    var n = document2.createElement("style");
    window2.createPopup || n.appendChild(document2.createTextNode("")), n.classList && true, n.type = "text/css", n.id = "qunee-styles", t.appendChild(n), css_styleSheet = n.sheet;
    var o, s;
    for (var r in css_DefaultCSS) {
      var a = css_DefaultCSS[r];
      o = r, s = "";
      for (var h in a)
        s += css_pre(h) + ":" + a[h] + ";\n";
      css_m9Rule(o, s);
    }
  }();
  var _4s = function(t, e, i, n, o) {
    if (o) {
      var s = function(t2) {
        s.handle.call(s.scope, t2);
      };
      return s.scope = o, s.handle = i, t.addEventListener(e, s, n), s;
    }
    return t.addEventListener(e, i, n), i;
  }, _2j = function(t, e, i) {
    t.removeEventListener(e, i);
  }, _2p = function(t) {
    t.preventDefault ? t.preventDefault() : t.returnValue = false;
  }, _1s = function(t) {
    t.stopPropagation ? t.stopPropagation() : t.cancelBubble || (t.cancelBubble = true);
  }, _f1 = function(t) {
    _2p(t), _1s(t);
  };
  Defaults.DOUBLE_CLICK_INTERVAL_TIME = isTouchSupport ? 500 : 300, Defaults.LONG_PRESS_INTERVAL = isTouchSupport ? 1500 : 1e3;
  var EVENT_TYPES, MouseWheelName = "onmousewheel" in window2 ? "mousewheel" : "DOMMouseScroll";
  EVENT_TYPES = MouseWheelName + ",mousedown,mouseup,click,mousemove,keydown", isTouchSupport && (EVENT_TYPES += ",touchstart,touchmove,touchend,touchcancel"), EVENT_TYPES = EVENT_TYPES.split(","), DragSupport.prototype = {
    _l1: null,
    _i5: function() {
      var t = this._m2;
      t && clearEventListenersSupport.call(this, t);
    },
    destroy: function() {
      this._i5();
    },
    _mmz: null,
    _1z: function() {
      this.__longPressTimer && (clearTimeout(this.__longPressTimer), this.__longPressTimer = null);
    },
    _dr: function() {
      this.__mmancelClick = true, this._1z(), this._hy(this._mmz, "startdrag"), this._mmp.clear();
    },
    _mmp: null,
    _73: function(t) {
      var e = this._9g;
      this._9g = _g4(t), this._mmp.add(e, this._9g, t);
    },
    _k0: function(t) {
      this._73(t), this._hy(t, "ondrag"), t.touches && t.touches.length > 1 && this._hy(t, "onpinch");
    },
    _if: function(t) {
      isTouchSupport || this._73(t);
      var e = this._mmp.getCurrentSpeed();
      e && (t.vx = e.x, t.vy = e.y), this._hy(t, "enddrag"), this._mmp.clear();
    },
    _dt: function(t) {
      this._mmz && (this._1z(), this._hy(t, "onrelease"), this._mmz = null, this._9g = null);
    },
    _hy: function(t, e) {
      this._listener && this._listener[e] instanceof Function && this._listener[e].call(this._listener, t, this._l1 || this._m2);
    }
  };
  var InteractionSupport = function(t) {
    this._l6 = t, _3g(this, InteractionSupport, [t.html]);
  };
  InteractionSupport._mmurrentInteractionSupport = null, InteractionSupport.prototype = {
    _4y: function(t) {
      this._54(function(e) {
        e.onElementRemoved instanceof Function && e.onElementRemoved(t, this._l6);
      });
    },
    _7f: function() {
      this._54(function(t) {
        t.onClear instanceof Function && t.onClear(this._l6);
      });
    },
    _i5: function() {
      this._27 && this._2g(this._27), this._$n && this._2g(this._$n);
      var t = this._l6.html;
      t && clearEventListenersSupport.call(this, t);
    },
    _l6: null,
    _27: null,
    _$n: null,
    _7b: function(t) {
      return this._27 == t ? false : (this._27 && this._27.length && this._2g(this._27), void (this._27 = t));
    },
    _9: function(t) {
      this._$n || (this._$n = []), this._$n.push(t);
    },
    _6: function(t) {
      this._$n && 0 != this._$n.length && _jh(this._$n, t);
    },
    _hy: function(t, e, i) {
      this._l6[e] instanceof Function && this._l6[e].call(this._l6, t, i), this._27 && this._gg(t, e, this._27, i), this._$n && this._gg(t, e, this._$n, i);
    },
    _54: function(t) {
      this._27 && _ic(this._27, t, this), this._$n && _ic(this._$n, t, this);
    },
    _gg: function(t, e, i, n) {
      if (!_ig(i))
        return void this._mk0(t, e, i, n);
      for (var o = 0; o < i.length; o++) {
        var s = i[o];
        this._mk0(t, e, s, n);
      }
    },
    _mk0: function(t, e, i, n) {
      var o = i[e];
      o && o.call(i, t, this._l6, n);
    },
    _37: function(t) {
      t.destroy instanceof Function && t.destroy.call(t, this._l6);
    },
    _2g: function(t) {
      if (!_ig(t))
        return void this._37(t);
      for (var e = 0; e < t.length; e++) {
        var i = t[e];
        i && this._37(i);
      }
    }
  }, _jq(InteractionSupport, DragSupport), DragPoints.prototype = {
    limitCount: 10,
    points: null,
    add: function(t, e, i) {
      var n = e.timeStamp - t.timeStamp || 1;
      i.interval = n;
      var o, s;
      if (!i.touches)
        return o = e.x - t.x, s = e.y - t.y, i.dx = o, i.dy = s, void this._kh(o, s, n);
      var r = i.touches.length;
      if (1 == r)
        o = i.touches[0].clientX - t.touches[0].clientX, s = i.touches[0].clientY - t.touches[0].clientY;
      else {
        for (var a, h, l, _ = [], u = [], d = 0, c = 0, f = 0, E = 0, g = 0, p = 0, v = 0, r = t.touches.length; r > v; v++) {
          a = t.touches[v];
          var T = a.clientX, m = a.clientY;
          d += T, c += m, v && (g = Math.max(g, Math.sqrt((T - h) * (T - h) + (m - l) * (m - l)))), h = T, l = m, _.push({
            x: T,
            y: m
          });
        }
        d /= r, c /= r;
        for (var v = 0, r = i.touches.length; r > v; v++) {
          a = i.touches[v];
          var T = a.clientX, m = a.clientY;
          f += T, E += m, v && (p = Math.max(p, Math.sqrt((T - h) * (T - h) + (m - l) * (m - l)))), h = T, l = m, u.push({
            x: T,
            y: m
          });
        }
        if (f /= r, E /= r, o = f - d, s = E - c, g && p) {
          var y = p / g;
          i.scale && t.scale && (y = i.scale / t.scale), i.center = {
            x: f,
            y: E,
            clientX: f,
            clientY: E
          }, i.dScale = y, i.prev = t;
        }
      }
      i.dx = o, i.dy = s, this._kh(o, s, n);
    },
    _kh: function(t, e, i) {
      var n = { interval: i, dx: t, dy: e };
      this.points.splice(0, 0, n), this.points.length > this.limitCount && this.points.pop();
    },
    getCurrentSpeed: function() {
      if (!this.points.length)
        return null;
      for (var t = 0, e = 0, i = 0, n = 0, o = this.points.length; o > n; n++) {
        var s = this.points[n], r = s.interval;
        if (r > 300)
          break;
        if (t += s.interval, e += s.dx, i += s.dy, t > 500)
          break;
      }
      return 0 == t || 0 == e && 0 == i ? null : { x: e / t, y: i / t };
    },
    clear: function() {
      this.points = [];
    }
  };
  var CURSOR_ZOOMIN, CURSOR_ZOOMOUT, CURSOR_GRABBING;
  isWebkit ? (CURSOR_ZOOMIN = "-webkit-zoom-in", CURSOR_ZOOMOUT = "-webkit-zoom-out", CURSOR_GRABBING = "-webkit-grabbing") : isGecko ? (CURSOR_ZOOMIN = "-moz-zoom-in", CURSOR_ZOOMOUT = "-moz-zoom-out", CURSOR_GRABBING = "-moz-grabbing") : (CURSOR_ZOOMIN = "crosshair", CURSOR_ZOOMOUT = "crosshair", CURSOR_GRABBING = "move");
  var CURSOR_ROTATE = "url(data:image/gif;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAFVJREFUeNpi/P//PwMlgBGfAYyMIOn/jGQZANIMoskyAKYZGeAyiGgX4PIOSWGAzRBGUmMBw1CqGUBMlA1yA4gxhKhYwBnfpKQDqqREquRGYgBAgAEAD8h/4adTIzwAAAAASUVORK5CYII=) 8 8,crosshair", PI = Math.PI, pow = Math.pow, sin = Math.sin, BACK_CONST = 1.70158, Easing = {
    swing: function(t) {
      return -Math.cos(t * PI) / 2 + 0.5;
    },
    easeNone: function(t) {
      return t;
    },
    easeIn: function(t) {
      return t * t;
    },
    easeOut: function(t) {
      return (2 - t) * t;
    },
    easeBoth: function(t) {
      return (t *= 2) < 1 ? 0.5 * t * t : 0.5 * (1 - --t * (t - 2));
    },
    easeInStrong: function(t) {
      return t * t * t * t;
    },
    easeOutStrong: function(t) {
      return 1 - --t * t * t * t;
    },
    easeBothStrong: function(t) {
      return (t *= 2) < 1 ? 0.5 * t * t * t * t : 0.5 * (2 - (t -= 2) * t * t * t);
    },
    elasticIn: function(t) {
      var e = 0.3, i = e / 4;
      return 0 === t || 1 === t ? t : -(pow(2, 10 * (t -= 1)) * sin(2 * (t - i) * PI / e));
    },
    elasticOut: function(t) {
      var e = 0.3, i = e / 4;
      return 0 === t || 1 === t ? t : pow(2, -10 * t) * sin(2 * (t - i) * PI / e) + 1;
    },
    elasticBoth: function(t) {
      var e = 0.45, i = e / 4;
      return 0 === t || 2 === (t *= 2) ? t : 1 > t ? -0.5 * pow(2, 10 * (t -= 1)) * sin(2 * (t - i) * PI / e) : pow(2, -10 * (t -= 1)) * sin(2 * (t - i) * PI / e) * 0.5 + 1;
    },
    backIn: function(t) {
      return 1 === t && (t -= 1e-3), t * t * ((BACK_CONST + 1) * t - BACK_CONST);
    },
    backOut: function(t) {
      return (t -= 1) * t * ((BACK_CONST + 1) * t + BACK_CONST) + 1;
    },
    backBoth: function(t) {
      return (t *= 2) < 1 ? 0.5 * t * t * (((BACK_CONST *= 1.525) + 1) * t - BACK_CONST) : 0.5 * ((t -= 2) * t * (((BACK_CONST *= 1.525) + 1) * t + BACK_CONST) + 2);
    },
    bounceIn: function(t) {
      return 1 - Easing.bounceOut(1 - t);
    },
    bounceOut: function(t) {
      var i = 7.5625;
      return 1 / 2.75 > t ? i * t * t : 2 / 2.75 > t ? i * (t -= 1.5 / 2.75) * t + 0.75 : 2.5 / 2.75 > t ? i * (t -= 2.25 / 2.75) * t + 0.9375 : i * (t -= 2.625 / 2.75) * t + 0.984375;
    },
    bounceBoth: function(t) {
      return 0.5 > t ? 0.5 * Easing.bounceIn(2 * t) : 0.5 * Easing.bounceOut(2 * t - 1) + 0.5;
    }
  }, FrameTimer = function(t) {
    this._jk = t;
  };
  FrameTimer.prototype = {
    _jk: null,
    _km: function(t) {
      var e = Date.now();
      this._ll();
      var i = this;
      this._requestID = requestAnimationFrame(function n() {
        var o = Date.now(), s = o - e;
        return !s || i._jk && i._jk(s) !== false ? (e = o, void (i._requestID = requestAnimationFrame(n))) : (i._ll(), void (t instanceof Function && t.call()));
      });
    },
    _ll: function() {
      return this._requestID ? (window2.cancelAnimationFrame(this._requestID), void delete this._requestID) : false;
    },
    _ez: function() {
      return null != this._requestID;
    }
  };
  var FrameAnimation = function(t, e, i, n) {
    this._onStep = t, this._l1 = e || this, this._3t = n, i && i > 0 && (this._iu = i);
  };
  FrameAnimation.prototype = {
    _iu: 1e3,
    _3t: null,
    _ex: 0,
    _ll: function() {
      return this._ex = 0, this._d8 = 0, _hr(this, FrameAnimation, "_ll");
    },
    _d8: 0,
    _jk: function(t) {
      if (this._ex += t, this._ex >= this._iu)
        return this._onStep.call(this._l1, 1, (1 - this._d8) * this._iu, t, this._iu), false;
      var e = this._ex / this._iu;
      return this._3t && (e = this._3t(e)), this._onStep.call(this._l1, e, (e - this._d8) * this._iu, t, this._iu) === false ? false : void (this._d8 = e);
    }
  }, _jq(FrameAnimation, FrameTimer);
  var ON_AJAX_ERROR = function(t) {
    _l8(t);
  }, Q2 = {
    version: "0.0",
    extend: _jq,
    doSuperConstructor: _3g,
    doSuper: _hr,
    createFunction: _7g,
    setClass: _g7,
    appendClass: _mkg,
    removeClass: _mkz,
    forEach: _ic,
    forEachReverse: _6p,
    isNumber: _gd,
    isString: _ho,
    isBoolean: _f5,
    isArray: _ig,
    eventPreventDefault: _2p,
    eventStopPropagation: _1s,
    stopEvent: _f1,
    callLater: _fa,
    nextFrame: _dl,
    forEachChild: _9q,
    forEachByDepthFirst: _2t,
    forEachByDepthFirstReverse: _$r,
    forEachByBreadthFirst: _1j,
    randomInt: _ee,
    randomBool: _d9,
    randomColor: _mko,
    addEventListener: _4s,
    getFirstElementChildByTagName
  };
  Q2.isTouchSupport = isTouchSupport, Q2.isIOS = isIOS, Q2.intersectsPoint = intersectsPoint, Q2.containsRect = containsRect, Q2.Rect = Rect, Q2.Size = Size, Q2.Point = Point, Q2.Insets = Insets, Q2.Event = Event, Q2.PropertyChangeEvent = PropertyChangeEvent, Q2.ListEvent = ListEvent, Q2.Handler = Handler, Q2.Dispatcher = Dispatcher, Q2.Position = Position, Q2.Data = Data, Q2.SelectionModel = SelectionModel, Q2.DataModel = DataModel, Q2.IListener = IListener, Q2.loadURL = loadURL, Q2.loadXML = loadXML, Q2.loadJSON = loadJSON, Q2.isMetaKey = isMetaKey, Q2.calculateDistance = calculateDistance, Q2.HashList = HashList, Q2.DragSupport = DragSupport, Q2.alert = function(t) {
    alert(t);
  }, Q2.prompt = function(t, e, i, n) {
    var o = prompt(t, e);
    return o != e && i ? i.call(n, o) : o;
  }, Q2.confirm = function(t, e, i) {
    var n = confirm(t);
    return n && e ? e.call(i) : n;
  }, Q2.addCSSRule = css_m9Rule;
  var Consts = {
    SELECTION_TYPE_BORDER_RECT: "border.rect",
    SELECTION_TYPE_BORDER: "border",
    SELECTION_TYPE_SHADOW: "shadow",
    NS_SVG: "http://www.w3.org/2000/svg",
    PROPERTY_TYPE_ACCESSOR: 0,
    PROPERTY_TYPE_STYLE: 1,
    PROPERTY_TYPE_CLIENT: 2,
    EDGE_TYPE_DEFAULT: null,
    EDGE_TYPE_ELBOW: "elbow",
    EDGE_TYPE_ELBOW_HORIZONTAL: "elbow.H",
    EDGE_TYPE_ELBOW_VERTICAL: "elbow.V",
    EDGE_TYPE_ORTHOGONAL: "orthogonal",
    EDGE_TYPE_ORTHOGONAL_HORIZONTAL: "orthogonal.H",
    EDGE_TYPE_ORTHOGONAL_VERTICAL: "orthogonal.V",
    EDGE_TYPE_HORIZONTAL_VERTICAL: "orthogonal.H.V",
    EDGE_TYPE_VERTICAL_HORIZONTAL: "orthogonal.V.H",
    EDGE_TYPE_EXTEND_TOP: "extend.top",
    EDGE_TYPE_EXTEND_LEFT: "extend.left",
    EDGE_TYPE_EXTEND_BOTTOM: "extend.bottom",
    EDGE_TYPE_EXTEND_RIGHT: "extend.right",
    EDGE_TYPE_ZIGZAG: "zigzag",
    EDGE_CORNER_NONE: "none",
    EDGE_CORNER_ROUND: "round",
    EDGE_CORNER_BEVEL: "bevel",
    GROUP_TYPE_RECT: "rect",
    GROUP_TYPE_CIRCLE: "circle",
    GROUP_TYPE_ELLIPSE: "ELLIPSE",
    SHAPE_CIRCLE: "oval",
    SHAPE_RECT: "rect",
    SHAPE_ROUNDRECT: "roundrect",
    SHAPE_STAR: "star",
    SHAPE_TRIANGLE: "triangle",
    SHAPE_HEXAGON: "hexagon",
    SHAPE_PENTAGON: "pentagon",
    SHAPE_TRAPEZIUM: "trapezium",
    SHAPE_RHOMBUS: "rhombus",
    SHAPE_PARALLELOGRAM: "parallelogram",
    SHAPE_HEART: "heart",
    SHAPE_DIAMOND: "diamond",
    SHAPE_CROSS: "cross",
    SHAPE_ARROW_STANDARD: "arrow.standard",
    SHAPE_ARROW_1: "arrow.1",
    SHAPE_ARROW_2: "arrow.2",
    SHAPE_ARROW_3: "arrow.3",
    SHAPE_ARROW_4: "arrow.4",
    SHAPE_ARROW_5: "arrow.5",
    SHAPE_ARROW_6: "arrow.6",
    SHAPE_ARROW_7: "arrow.7",
    SHAPE_ARROW_8: "arrow.8",
    SHAPE_ARROW_OPEN: "arrow.open"
  };
  Consts.LINE_CAP_TYPE_BUTT = "butt", Consts.LINE_CAP_TYPE_ROUND = "round", Consts.LINE_CAP_TYPE_SQUARE = "square", Consts.LINE_JOIN_TYPE_BEVEL = "bevel", Consts.LINE_JOIN_TYPE_ROUND = "round", Consts.LINE_JOIN_TYPE_MITER = "miter", Defaults.SELECTION_TYPE = Consts.SELECTION_TYPE_SHADOW, Defaults.SELECTION_TOLERANCE = 3, Defaults.SELECTION_BORDER = 2, Defaults.SELECTION_SHADOW_BLUR = 7, Defaults.SELECTION_COLOR = _ia(3422561023), Defaults.SELECTION_TYPE = Consts.SELECTION_TYPE_SHADOW, Defaults.BORDER_RADIUS = 10, Defaults.POINTER_WIDTH = 10, Defaults.DOUBLE_BUFFER = void 0, Defaults.ARROW_SIZE = 10, Defaults.IMAGE_MAX_SIZE = 200, Defaults.LINE_HEIGHT = 1.2;
  var devicePixelRatio2 = window2.devicePixelRatio || 1;
  1 > devicePixelRatio2 && (devicePixelRatio2 = 1);
  var _mm9;
  Q2.createCanvas = _mkc;
  var calculateDistanceSquare = function(t, e, i, n) {
    var o = t - i, s = e - n;
    return o * o + s * s;
  };
  Circle.prototype = {
    equals: function(t) {
      return this.cx == t.cx && this.cy == t.cy && this.r == t.r;
    }
  }, Circle._mmreateCircle = function(t, e, i) {
    if (!i)
      return circleByTwoPoints(t, e);
    var n = calculateDistanceSquare(t.x, t.y, e.x, e.y), o = calculateDistanceSquare(t.x, t.y, i.x, i.y), s = calculateDistanceSquare(i.x, i.y, e.x, e.y);
    if (n + DISTANCE_TOLERANCE >= o + s)
      return circleByTwoPoints(t, e, 0, i);
    if (o + DISTANCE_TOLERANCE >= n + s)
      return circleByTwoPoints(t, i, 0, e);
    if (s + DISTANCE_TOLERANCE >= n + o)
      return circleByTwoPoints(e, i, 0, t);
    var r;
    Math.abs(i.y - e.y) < 1e-4 && (r = t, t = e, e = r), r = i.x * (t.y - e.y) + t.x * (e.y - i.y) + e.x * (-t.y + i.y);
    var a = (i.x * i.x * (t.y - e.y) + (t.x * t.x + (t.y - e.y) * (t.y - i.y)) * (e.y - i.y) + e.x * e.x * (-t.y + i.y)) / (2 * r), h = (e.y + i.y) / 2 - (i.x - e.x) / (i.y - e.y) * (a - (e.x + i.x) / 2);
    return new Circle(a, h, calculateDistance(a, h, t.x, t.y), t, e, i);
  };
  var DISTANCE_TOLERANCE = 0.01, pathUtils = {
    _mkr: function(t, e, i, n, o) {
      var s = 0, r = 0, a = e._k4;
      if (i = i || 0, void 0 === t.x) {
        var h = t.horizontalPosition, l = t.verticalPosition, _ = true;
        switch (h) {
          case RIGHT:
            _ = false;
            break;
          case CENTER:
            s += a / 2;
        }
        switch (l) {
          case TOP:
            r -= i / 2;
            break;
          case BOTTOM:
            r += i / 2;
        }
      } else
        s = t.x, r = t.y, Math.abs(s) > 0 && Math.abs(s) < 1 && (s *= a);
      o && null != n && (r += n.y, s += Math.abs(n.x) < 1 ? n.x * a : n.x);
      var u = calculatePointByLength.call(e, s, r, _);
      return u ? (o || null == n || u.offset(n), u) : { x: 0, y: 0 };
    },
    _le: function(t, e) {
      var i = e.type, n = e.points;
      switch (i) {
        case ARC_TO:
          t.arcTo(n[0], n[1], n[2], n[3], e._r);
          break;
        case MOVE_TO:
          t.moveTo(n[0], n[1]);
          break;
        case LINE_TO:
          t.lineTo(n[0], n[1]);
          break;
        case QUAD_TO:
          t.quadraticCurveTo(n[0], n[1], n[2], n[3]);
          break;
        case CURVE_TO:
          t.bezierCurveTo(n[0], n[1], n[2], n[3], n[4], n[5]);
          break;
        case CLOSE:
          t.closePath();
      }
    },
    _5p: function(t, e, i, n) {
      var o = e.type;
      if (o != MOVE_TO && o != CLOSE) {
        var s = i.lastPoint, r = e.points;
        switch (i.type == MOVE_TO && t.add(s.x, s.y), o) {
          case ARC_TO:
            caculateArcLength(e, s.x, s.y, r[0], r[1], r[2], r[3], r[4]), t.add(r[0], r[1]), t.add(e._p1x, e._p1y), t.add(e._p2x, e._p2y), e._mooundaryPoint1 && t.add(e._mooundaryPoint1.x, e._mooundaryPoint1.y), e._mooundaryPoint2 && t.add(e._mooundaryPoint2.x, e._mooundaryPoint2.y);
            break;
          case LINE_TO:
            t.add(r[0], r[1]);
            break;
          case QUAD_TO:
            calculateQuadraticCurveBounds([s.x, s.y].concat(r), t);
            break;
          case CURVE_TO:
            calculateBezierCurveBounds([s.x, s.y].concat(r), t);
            break;
          case CLOSE:
            n && t.add(n.points[0], n.points[1]);
        }
      }
    },
    _5l: function(t, e, i) {
      var n = t.type;
      if (n == MOVE_TO)
        return 0;
      var o = e.lastPoint, s = t.points;
      switch (n == CURVE_TO && 4 == s.length && (n = QUAD_TO), n) {
        case LINE_TO:
          return calculateDistance(s[0], s[1], o.x, o.y);
        case ARC_TO:
          return t._k4;
        case QUAD_TO:
          var r = caculateQuadraticCurveLengthFunction([o.x, o.y].concat(s));
          return t._lf = r, r(1);
        case CURVE_TO:
          var r = caculateBezierCurveLengthFunction([o.x, o.y].concat(s));
          return t._lf = r, r(1) || caculateBezierCurveLength2([o.x, o.y].concat(s));
        case CLOSE:
          if (o && i)
            return t.points = i.points, calculateDistance(i.points[0], i.points[1], o.x, o.y);
      }
      return 0;
    }
  }, REG_BASE64_IMAGE = /^data:image\/(\w+);base64,/i, REG_GIF = /^gif/i, REG_SVG = /^svg/i, IMAGE_TYPE_DEFAULT = 10, IMAGE_TYPE_SVG = 11, IMAGE_TYPE_GIF = 12, IMAGE_TYPE_DRAWABLE = 20, IMAGE_TYPE_SHAPE = 30;
  Defaults.IMAGE_WIDTH = 50, Defaults.IMAGE_HEIGHT = 30, Defaults.MAX_CACHE_PIXELS = 1e6;
  var IMAGE_STATUS_LOADING = 1, IMAGE_STATUS_LOADED = 2, IMAGE_STATUS_ERROR = 3;
  QImage.prototype = {
    _k9: 0,
    _6k: true,
    _kf: null,
    _jn: null,
    _lc: null,
    _lg: null,
    _mkp: void 0,
    _98: void 0,
    _7s: function() {
      return this._k9 == IMAGE_STATUS_LOADING;
    },
    getBounds: function(t) {
      return this._lg == IMAGE_TYPE_SHAPE ? this._lc.getBounds(t) : (this._6k && this._fz(), this);
    },
    validate: function() {
      this._6k && this._fz();
    },
    _fz: function() {
      if (this._6k = false, this._lg == IMAGE_TYPE_SHAPE)
        return this._lc.validate(), void this.setByRect(this._lc.bounds);
      if (this._lg == IMAGE_TYPE_DRAWABLE)
        return void this._9d();
      if (this._k9 != IMAGE_STATUS_LOADING)
        try {
          this._dk();
        } catch (t) {
          this._k9 = IMAGE_STATUS_ERROR, Q2.error(t);
        }
    },
    _5d: function() {
      this._dp(), this._dispatcher.clear(), delete this._dispatcher;
    },
    _hp: function(t) {
      this._kf && this._kf.parentNode && this._kf.parentNode.removeChild(this._kf), this._k9 = IMAGE_STATUS_ERROR, Q2.error("Image load error - " + this._lc), this._pixels = null, this._jn = null, this._kf = null, t !== false && this._5d();
    },
    _dk: function() {
      var t = this._lc;
      if (this._k9 = IMAGE_STATUS_LOADING, this._dispatcher = new Dispatcher(), this._lg == IMAGE_TYPE_GIF) {
        for (var e in GIFImageSupport)
          this[e] = GIFImageSupport[e];
        return void GifLoader(this._lc, this, this._dg, this._hp, this._dn);
      }
      this._kf || (this._kf = document2.createElement("img"));
      if (isIE) {
        this._kf.style.visibility = "hidden";
        document2.body.appendChild(this._kf);
        this._kf.onload = function() {
          setTimeout(this._86.bind(this), 100);
        }.bind(this);
        this._kf.onerror = this._hp.bind(this);
      } else {
        this._kf.onload = this._86.bind(this);
        this._kf.onerror = this._86.bind(this);
      }
      this._kf.src = t;
    },
    _86: function() {
      this._k9 = IMAGE_STATUS_LOADED;
      var t = this._kf.width, e = this._kf.height;
      if (this._kf.parentNode && this._kf.parentNode.removeChild(this._kf), !t || !e)
        return void this._hp();
      this.width = t, this.height = e;
      var i = this._dz();
      i.width = t, i.height = e, i.g.drawImage(this._kf, 0, 0, t, e), this._pixels = isIE && this._lg == IMAGE_TYPE_SVG ? null : toPixelsFromCanvas(i), this._5d();
    },
    _9d: function() {
      var t = this._lc;
      if (!(t.draw instanceof Function))
        return void this._hp(false);
      if (t.cacheable === false && t.width && t.height)
        return this.width = t.width, void (this.height = t.height);
      var e = t.width || Defaults.IMAGE_MAX_SIZE, i = t.height || Defaults.IMAGE_MAX_SIZE, n = this._dz();
      n.width = e, n.height = i;
      var o = n.g;
      t.draw(o);
      var s = o.getImageData(0, 0, e, i), r = toPixelsFromCanvasData(s.data, e);
      this.x = r._x, this.y = r._y, this.width = r._width, this.height = r._height, n.width = this.width, n.height = this.height, o.putImageData(s, -this.x, -this.y), this._pixels = r;
    },
    _dz: function() {
      return this._jn || (this._jn = _mkc());
    },
    _7p: function(t, e, i, n, o, s) {
      e.save(), e.rect(0, 0, n, o), e.fillStyle = s || "#CCC", e.fill(), e.clip(), e.textAlign = "center", e.textBaseline = "middle", e.fillStyle = "#888";
      var r = 6 * (e.canvas.ratio || 1);
      e.font = "normal " + r + "px Verdana,helvetica,arial,sans-serif", e.strokeStyle = "#FFF", e.lineWidth = 1, e.strokeText(t, n / 2 + 0.5, o / 2 + 0.5), e.strokeStyle = "#000", e.strokeText(t, n / 2 - 0.5, o / 2 - 0.5), e.fillText(t, n / 2, o / 2), e.restore();
    },
    draw: function(t, e, i, n, o, s) {
      if (this.width && this.height) {
        e = e || 1, n = n || 1, o = o || 1;
        var r = this.width * n, a = this.height * o;
        if (s && i.shadowColor && (t.shadowColor = i.shadowColor, t.shadowBlur = (i.shadowBlur || 0) * e, t.shadowOffsetX = (i.shadowOffsetX || 0) * e, t.shadowOffsetY = (i.shadowOffsetY || 0) * e), this._k9 == IMAGE_STATUS_LOADING)
          return this._7p("Loading...", t, e, r, a, i.renderColor);
        if (this._k9 == IMAGE_STATUS_ERROR)
          return this._7p("Error...", t, e, r, a, i.renderColor);
        if (this._lg == IMAGE_TYPE_SHAPE)
          return t.scale(n, o), void this._lc.draw(t, e, i);
        var h = this._fp(e, n, o);
        return h ? ((this.x || this.y) && t.translate(this.x * n, this.y * o), t.scale(n / h.scale, o / h.scale), void h._le(t, i.renderColor, i.renderColorBlendMode)) : void this._js(t, e, n, o, this.width * n, this.height * o, i);
      }
    },
    _js: function(t, e, i, n, o, s, r) {
      if (this._lg == IMAGE_TYPE_DRAWABLE)
        return 1 != i && 1 != n && t.scale(i, n), void this._lc.draw(t, r);
      if (this._kf) {
        if (!isFirefox)
          return void t.drawImage(this._kf, 0, 0, o, s);
        var i = e * o / this.width, n = e * s / this.height;
        t.scale(1 / i, 1 / n), t.drawImage(this._kf, 0, 0, o * i, s * n);
      }
    },
    _ka: null,
    _fp: function(t, e, i) {
      if (this._lg == IMAGE_TYPE_DRAWABLE && this._lc.cacheable === false)
        return null;
      if (this._lg == IMAGE_TYPE_DEFAULT || (t *= Math.max(e, i)) <= 1)
        return this._defaultCache || (this._defaultCache = this._fm(this._jn || this._kf, 1)), this._defaultCache;
      var n = this._ka.maxScale || 0;
      if (t = Math.ceil(t), n >= t) {
        for (var o = t, s = this._ka[o]; !s && ++o <= n; )
          s = this._ka[o];
        if (s)
          return s;
      }
      t % 2 && t++;
      var r = this.width * t, a = this.height * t;
      if (r * a > Defaults.MAX_CACHE_PIXELS)
        return null;
      var h = _mkc(r, a);
      return (this.x || this.y) && h.g.translate(-this.x * t, -this.y * t), this._js(h.g, 1, t, t, r, a), this._fm(h, t);
    },
    _fm: function(t, e) {
      var i = new BufferedImage(t, e);
      return this._ka[e] = i, this._ka.maxScale = e, i;
    },
    _hq: function(t, e, i) {
      if (this._lg == IMAGE_TYPE_SHAPE)
        return this._lc._hq.apply(this._lc, arguments);
      if (!(this._pixels && this._pixels.length || this._kf && this._kf._pixels))
        return true;
      var n = this._pixels || this._kf._pixels;
      return t -= n._j1.x, e -= n._j1.y, t = Math.round(t), e = Math.round(e), hitPixels(n, n._j1, t, e, i);
    },
    _dp: function() {
      this._dispatcher && this._dispatcher.onEvent(new Event(this, "image", "load", this._kf));
    },
    _mo2: function(t, e) {
      this._dispatcher && this._dispatcher.addListener(t, e);
    },
    _7k: function(t, e) {
      this._dispatcher && this._dispatcher.removeListener(t, e);
    },
    _mm2: function(t) {
      this._ka = {}, (t || this.width * this.height > 1e5) && (this._kf = null, this._jn = null);
    }
  }, _jq(QImage, Rect);
  var IMAGE_CACHE = {};
  Q2.drawImage = _eu, Q2.registerImage = _8g, Q2.hasImage = _ha, Q2.getAllImages = function() {
    var t = [];
    for (var e in IMAGE_CACHE)
      t.push(e);
    return t;
  };
  var Gradient = function(t, e, i, n, o, s) {
    this.type = t, this.colors = e, this.positions = i, this.angle = n || 0, this.tx = o || 0, this.ty = s || 0;
  };
  Consts.GRADIENT_TYPE_RADIAL = "r", Consts.GRADIENT_TYPE_LINEAR = "l", Gradient.prototype = {
    type: null,
    colors: null,
    positions: null,
    angle: null,
    tx: 0,
    ty: 0,
    position: Position.CENTER_MIDDLE,
    isEmpty: function() {
      return null == this.colors || 0 == this.colors.length;
    },
    _6m: function() {
      var t = this.colors.length;
      if (1 == t)
        return [0];
      for (var e = [], i = 1 / (t - 1), n = 0; t > n; n++)
        e.push(i * n);
      return this.positions || (this.positions = e), e;
    },
    generatorGradient: function(t) {
      if (null == this.colors || 0 == this.colors.length)
        return null;
      var e, i = getTempG();
      if (this.type == Consts.GRADIENT_TYPE_LINEAR) {
        var n = this.angle;
        n > Math.PI && (n -= Math.PI);
        var o;
        if (n <= Math.PI / 2) {
          var s = Math.atan2(t.height, t.width), r = Math.sqrt(t.width * t.width + t.height * t.height), a = s - n;
          o = Math.cos(a) * r;
        } else {
          var s = Math.atan2(t.width, t.height), r = Math.sqrt(t.width * t.width + t.height * t.height), a = s - (n - Math.PI / 2);
          o = Math.cos(a) * r;
        }
        var h = o / 2, l = h * Math.cos(n), _ = h * Math.sin(n), u = t.x + t.width / 2 - l, d = t.y + t.height / 2 - _, c = t.x + t.width / 2 + l, f = t.y + t.height / 2 + _;
        e = i.createLinearGradient(u, d, c, f);
      } else {
        if (!(this.type = Consts.GRADIENT_TYPE_RADIAL))
          return null;
        var E = _mkr(this.position, t.width, t.height);
        E.x += t.x, E.y += t.y, this.tx && (E.x += Math.abs(this.tx) < 1 ? t.width * this.tx : this.tx), this.ty && (E.y += Math.abs(this.ty) < 1 ? t.height * this.ty : this.ty);
        var g = calculateDistance(E.x, E.y, t.x, t.y);
        g = Math.max(g, calculateDistance(E.x, E.y, t.x, t.y + t.height)), g = Math.max(g, calculateDistance(E.x, E.y, t.x + t.width, t.y + t.height)), g = Math.max(g, calculateDistance(E.x, E.y, t.x + t.width, t.y)), e = i.createRadialGradient(E.x, E.y, 0, E.x, E.y, g);
      }
      var p = this.colors, v = this.positions;
      v && v.length == p.length || (v = this._6m());
      for (var T = 0, m = p.length; m > T; T++)
        e.addColorStop(v[T], p[T]);
      return e;
    }
  };
  var LINEAR_GRADIENT_VERTICAL = new Gradient(
    Consts.GRADIENT_TYPE_LINEAR,
    [_ia(2332033023), _ia(1154272460), _ia(1154272460), _ia(1442840575)],
    [0.1, 0.3, 0.7, 0.9],
    Math.PI / 2
  ), LINEAR_GRADIENT_HORIZONTAL = new Gradient(
    Consts.GRADIENT_TYPE_LINEAR,
    [_ia(2332033023), _ia(1154272460), _ia(1154272460), _ia(1442840575)],
    [0.1, 0.3, 0.7, 0.9],
    0
  );
  new Gradient(
    Consts.GRADIENT_TYPE_LINEAR,
    [_ia(1154272460), _ia(1442840575)],
    [0.1, 0.9],
    0
  );
  var RADIAL_GRADIENT = new Gradient(
    Consts.GRADIENT_TYPE_RADIAL,
    [_ia(2298478591), _ia(1156509422), _ia(1720223880), _ia(1147561574)],
    [0.1, 0.3, 0.7, 0.9],
    0,
    -0.3,
    -0.3
  ), rainbowColors = [
    _ia(0),
    _ia(4294901760),
    _ia(4294967040),
    _ia(4278255360),
    _ia(4278250239),
    _ia(4278190992),
    _ia(4294901958),
    _ia(0)
  ], rainbowPositions = [0, 0.12, 0.28, 0.45, 0.6, 0.75, 0.8, 1], RAINBOW_LINEAR_GRADIENT = new Gradient(Consts.GRADIENT_TYPE_LINEAR, rainbowColors, rainbowPositions), RAINBOW_LINEAR_GRADIENT_VERTICAL = new Gradient(
    Consts.GRADIENT_TYPE_LINEAR,
    rainbowColors,
    rainbowPositions,
    Math.PI / 2
  ), RAINBOW_RADIAL_GRADIENT = new Gradient(Consts.GRADIENT_TYPE_RADIAL, rainbowColors, rainbowPositions);
  Gradient.LINEAR_GRADIENT_VERTICAL = LINEAR_GRADIENT_VERTICAL, Gradient.LINEAR_GRADIENT_HORIZONTAL = LINEAR_GRADIENT_HORIZONTAL, Gradient.RADIAL_GRADIENT = RADIAL_GRADIENT, Gradient.RAINBOW_LINEAR_GRADIENT = RAINBOW_LINEAR_GRADIENT, Gradient.RAINBOW_LINEAR_GRADIENT_VERTICAL = RAINBOW_LINEAR_GRADIENT_VERTICAL, Gradient.RAINBOW_RADIAL_GRADIENT = RAINBOW_RADIAL_GRADIENT;
  var MOVE_TO = "m", LINE_TO = "l", QUAD_TO = "q", CURVE_TO = "c", ARC_TO = "a", CLOSE = "z";
  Consts.SEGMENT_MOVE_TO = MOVE_TO, Consts.SEGMENT_LINE_TO = LINE_TO, Consts.SEGMENT_QUAD_TO = QUAD_TO, Consts.SEGMENT_CURVE_TO = CURVE_TO, Consts.SEGMENT_ARC_TO = ARC_TO, Consts.SEGMENT_CLOSE = CLOSE;
  var PathSegment = function(t, e) {
    this.id = ++idIndex, _ig(t) ? this.points = t : (this.type = t, this.points = e);
  };
  PathSegment.prototype = {
    toJSON: function() {
      var t = { type: this.type, points: this.points };
      return this.invalidTerminal && (t.invalidTerminal = true), t;
    },
    parseJSON: function(t) {
      this.type = t.type, this.points = t.points, this.invalidTerminal = t.invalidTerminal;
    },
    points: null,
    type: LINE_TO,
    clone: function() {
      return new PathSegment(this.type, _d7(this.points));
    },
    move: function(t, e) {
      if (this.points)
        for (var i = 0, n = this.points.length; n > i; i++) {
          var o = this.points[i];
          Q2.isNumber(o) && (this.points[i] += i % 2 == 0 ? t : e);
        }
    }
  }, _4u(PathSegment.prototype, {
    lastPoint: {
      get: function() {
        return this.type == ARC_TO ? { x: this._p2x, y: this._p2y } : {
          x: this.points[this.points.length - 2],
          y: this.points[this.points.length - 1]
        };
      }
    },
    firstPoint: {
      get: function() {
        return { x: this.points[0], y: this.points[1] };
      }
    }
  }), Q2.PathSegment = PathSegment;
  var ALPHA_TOLERANCE = 0, Path = function(t) {
    this.bounds = new Rect(), this._fe = t || [];
  };
  Path.prototype = {
    toJSON: function() {
      var t = [];
      return this._fe.forEach(function(e) {
        t.push(e.toJSON());
      }), t;
    },
    parseJSON: function(t) {
      var e = this._fe;
      t.forEach(function(t2) {
        e.push(new PathSegment(t2.type, t2.points));
      });
    },
    clear: function() {
      this._fe.length = 0, this.bounds.clear(), this._k4 = 0, this._6k = true;
    },
    _di: true,
    _6r: function(t, e) {
      this._di && 0 === this._fe.length && t != MOVE_TO && this._fe.push(new PathSegment(MOVE_TO, [0, 0])), this._fe.push(new PathSegment(t, e)), this._6k = true;
    },
    add: function(t) {
      this._fe.push(t), this._6k = true;
    },
    removePathSegment: function(t) {
      return t >= this._fe.length ? false : (this._fe.splice(t, 1), void (this._6k = true));
    },
    moveTo: function(t, e) {
      this._6r(MOVE_TO, [t, e]);
    },
    lineTo: function(t, e) {
      this._6r(LINE_TO, [t, e]);
    },
    quadTo: function(t, e, i, n) {
      this._6r(QUAD_TO, [t, e, i, n]);
    },
    curveTo: function(t, e, i, n, o, s) {
      this._6r(CURVE_TO, [t, e, i, n, o, s]);
    },
    arcTo: function(t, e, i, n, o) {
      this._6r(ARC_TO, [t, e, i, n, o]);
    },
    closePath: function() {
      this._6r(CLOSE);
    },
    _89: function(t, e, i, n, o) {
      if (n.selectionColor) {
        if (i == Consts.SELECTION_TYPE_SHADOW) {
          if (!n.selectionShadowBlur)
            return;
          return t.shadowColor = n.selectionColor, t.shadowBlur = n.selectionShadowBlur * e, t.shadowOffsetX = (n.selectionShadowOffsetX || 0) * e, void (t.shadowOffsetY = (n.selectionShadowOffsetY || 0) * e);
        }
        if (i == Consts.SELECTION_TYPE_BORDER) {
          if (!n.selectionBorder)
            return;
          t.strokeStyle = n.selectionColor, t.lineWidth = n.selectionBorder + (o.lineWidth || 0), this._le(t), t.stroke();
        }
      }
    },
    _6k: true,
    _fe: null,
    _k4: 0,
    lineCap: "butt",
    lineJoin: "round",
    draw: function(t, e, i, n, o) {
      t.lineCap = i.lineCap || this.lineCap, t.lineJoin = i.lineJoin || this.lineJoin, n && (o || (o = i), this._89(t, e, o.selectionType, o, i)), i.outlineStyle && (this._le(t), t.lineWidth = i.lineWidth + 2 * (i.outline || 0), t.strokeStyle = i.outlineStyle, t.stroke()), t.lineWidth = 0, this._le(t), i.fillColor && (t.fillStyle = i.renderColor || i.fillColor, t.fill()), i.fillGradient && (t.fillStyle = i._fillGradient || i.fillGradient, t.fill()), i.lineWidth && (t.lineWidth = i.lineWidth, i.lineDash && (t.lineDash = i.lineDash, t.lineDashOffset = i.lineDashOffset), t.strokeStyle = i.renderColor || i.strokeStyle, t.stroke(), t.lineDash = []);
    },
    _le: function(t) {
      t.beginPath();
      for (var e, i, n = 0, o = this._fe.length; o > n; n++)
        e = this._fe[n], pathUtils._le(t, e, i), i = e;
    },
    validate: function() {
      if (this._6k = false, this.bounds.clear(), this._k4 = 0, 0 != this._fe.length)
        for (var t, e, i = this._fe, n = 1, o = i[0], s = o, r = i.length; r > n; n++)
          t = i[n], t.type == MOVE_TO ? s = t : (pathUtils._5p(this.bounds, t, o, s), e = pathUtils._5l(t, o, s), t._k4 = e, this._k4 += e), o = t;
    },
    getBounds: function(t, e) {
      if (this._6k && this.validate(), e = e || new Rect(), t) {
        var i = t / 2;
        e.set(this.bounds.x - i, this.bounds.y - i, this.bounds.width + t, this.bounds.height + t);
      } else
        e.set(this.bounds.x, this.bounds.y, this.bounds.width, this.bounds.height);
      return e;
    },
    _hq: function(t, e, i, n, o, s) {
      return pathHitTest.call(this, t, e, i, n, o, s);
    },
    toSegments: function() {
      return [].concat(this._fe);
    },
    generator: function(t, e, i, n, o) {
      return PathGenerator.call(this, t, e, i, n, o);
    },
    getLocation: function(t, e) {
      return calculatePointByLength.call(this, t, e || 0);
    }
  }, _4u(Path.prototype, {
    segments: {
      get: function() {
        return this._fe;
      },
      set: function(t) {
        this.clear(), this._fe = t;
      }
    },
    length: {
      get: function() {
        return this._6k && this.validate(), this._k4;
      }
    },
    _empty: {
      get: function() {
        return 0 == this._fe.length;
      }
    }
  }), Consts.BLEND_MODE_DARKEN = "darken", Consts.BLEND_MODE_MULTIPLY = "multiply", Consts.BLEND_MODE_COLOR_BURN = "color.burn", Consts.BLEND_MODE_LINEAR_BURN = "linear.burn", Consts.BLEND_MODE_LIGHTEN = "lighten", Consts.BLEND_MODE_SCREEN = "screen", Consts.BLEND_MODE_GRAY = "gray", Defaults.BLEND_MODE = Consts.BLEND_MODE_LINEAR_BURN;
  var BufferedImage = function(t, e, i) {
    this._jn = t, this.scale = e || 1, t instanceof Image && (i = false), this._ii = i;
  };
  BufferedImage.prototype = {
    scale: 1,
    _jn: null,
    _ka: null,
    _ii: true,
    _le: function(t, e, i) {
      if (!e || this._ii === false)
        return void t.drawImage(this._jn, 0, 0);
      this._ka || (this._ka = {});
      var n = e + i, o = this._ka[n];
      o || (o = getRenderCanvas(this._jn, e, i), o || (this._ii = false), this._ka[n] = o || this._jn), t.drawImage(o, 0, 0);
    }
  };
  var Bubble = function(t, e, i, n, o, s, r, a, h) {
    this._li = createBubblePointer(t, e, i, n, o, s, r, a, h);
  }, Graphs = {
    server: {
      draw: function(t) {
        t.save(), t.translate(0, 0), t.beginPath(), t.moveTo(0, 0), t.lineTo(40, 0), t.lineTo(40, 40), t.lineTo(0, 40), t.closePath(), t.clip(), t.translate(0, 0), t.translate(0, 0), t.scale(1, 1), t.translate(0, 0), t.strokeStyle = "rgba(0,0,0,0)", t.lineCap = "butt", t.lineJoin = "miter", t.miterLimit = 4, t.save(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.restore(), t.save();
        var e = t.createLinearGradient(6.75, 3.9033, 30.5914, 27.7447);
        e.addColorStop(0.0493, "#1C6B9D"), e.addColorStop(0.0689, "#186493"), e.addColorStop(0.0939, "#145E8B"), e.addColorStop(0.129, "#115B87"), e.addColorStop(0.2266, "#115A85"), e.addColorStop(0.2556, "#125C89"), e.addColorStop(0.2869, "#176291"), e.addColorStop(0.3194, "#1D6C9F"), e.addColorStop(0.3525, "#2479B0"), e.addColorStop(0.3695, "#2881BB"), e.addColorStop(0.5025, "#1F6FA2"), e.addColorStop(0.9212, "#115A86"), e.addColorStop(1, "#004063"), t.fillStyle = e, t.beginPath(), t.moveTo(25.677, 4.113), t.bezierCurveTo(25.361, 2.4410000000000007, 23.364, 2.7940000000000005, 22.14, 2.7990000000000004), t.bezierCurveTo(19.261, 2.813, 16.381, 2.8260000000000005, 13.502, 2.8400000000000003), t.bezierCurveTo(12.185, 2.846, 10.699000000000002, 2.652, 9.393, 2.8790000000000004), t.bezierCurveTo(9.19, 2.897, 8.977, 2.989, 8.805, 3.094), t.bezierCurveTo(8.084999999999999, 3.5109999999999997, 7.436999999999999, 4.1259999999999994, 6.776, 4.63), t.bezierCurveTo(5.718999999999999, 5.436, 4.641, 6.22, 3.6029999999999998, 7.05), t.bezierCurveTo(4.207, 6.5889999999999995, 21.601999999999997, 36.579, 21.028, 37.307), t.bezierCurveTo(22.019, 36.063, 23.009999999999998, 34.819, 24.000999999999998, 33.575), t.bezierCurveTo(
          24.587999999999997,
          32.84,
          25.589999999999996,
          31.995000000000005,
          25.593999999999998,
          30.983000000000004
        ), t.bezierCurveTo(
          25.595999999999997,
          30.489000000000004,
          25.598,
          29.994000000000003,
          25.601,
          29.500000000000004
        ), t.bezierCurveTo(25.612, 26.950000000000003, 25.622, 24.400000000000006, 25.633, 21.85), t.bezierCurveTo(25.657, 16.318, 25.680999999999997, 10.786000000000001, 25.704, 5.253), t.bezierCurveTo(25.706, 4.885, 25.749, 4.478, 25.677, 4.113), t.bezierCurveTo(25.67, 4.077, 25.697, 4.217, 25.677, 4.113), t.closePath(), t.fill(), t.stroke(), t.restore(), t.save(), t.save(), t.fillStyle = "#2e8ece", t.beginPath(), t.moveTo(19.763, 6.645), t.bezierCurveTo(20.002000000000002, 6.643999999999999, 20.23, 6.691999999999999, 20.437, 6.778), t.bezierCurveTo(
          20.644000000000002,
          6.864999999999999,
          20.830000000000002,
          6.991,
          20.985,
          7.146999999999999
        ), t.bezierCurveTo(21.14, 7.302999999999999, 21.266, 7.488999999999999, 21.352999999999998, 7.696999999999999), t.bezierCurveTo(21.438999999999997, 7.903999999999999, 21.487, 8.133, 21.487, 8.372), t.lineTo(21.398, 36.253), t.bezierCurveTo(21.397, 36.489, 21.349, 36.713, 21.262, 36.917), t.bezierCurveTo(21.174, 37.121, 21.048000000000002, 37.305, 20.893, 37.458), t.bezierCurveTo(20.738, 37.611, 20.553, 37.734, 20.348, 37.818999999999996), t.bezierCurveTo(20.141, 37.903999999999996, 19.916, 37.95099999999999, 19.679, 37.949), t.lineTo(4.675, 37.877), t.bezierCurveTo(4.4399999999999995, 37.876000000000005, 4.216, 37.827000000000005, 4.012, 37.741), t.bezierCurveTo(
          3.8089999999999997,
          37.653999999999996,
          3.6249999999999996,
          37.528999999999996,
          3.4719999999999995,
          37.376
        ), t.bezierCurveTo(
          3.3179999999999996,
          37.221,
          3.1939999999999995,
          37.037,
          3.1079999999999997,
          36.833999999999996
        ), t.bezierCurveTo(3.022, 36.629999999999995, 2.9739999999999998, 36.406, 2.9739999999999998, 36.172), t.lineTo(2.924, 8.431), t.bezierCurveTo(2.923, 8.192, 2.971, 7.964, 3.057, 7.758), t.bezierCurveTo(3.143, 7.552, 3.267, 7.365, 3.4219999999999997, 7.209), t.bezierCurveTo(3.5769999999999995, 7.052999999999999, 3.76, 6.925, 3.965, 6.837), t.bezierCurveTo(4.17, 6.749, 4.396, 6.701, 4.633, 6.7), t.lineTo(19.763, 6.645), t.closePath(), t.fill(), t.stroke(), t.restore(), t.restore(), t.save(), t.fillStyle = "#efefef", t.beginPath(), t.arc(12.208, 26.543, 2.208, 0, 6.283185307179586, true), t.closePath(), t.fill(), t.stroke(), t.restore(), t.save(), t.fillStyle = "#2e8ece", t.beginPath(), t.arc(12.208, 26.543, 1.876, 0, 6.283185307179586, true), t.closePath(), t.fill(), t.stroke(), t.restore(), t.save(), t.fillStyle = "#efefef", t.beginPath(), t.moveTo(19.377, 17.247), t.bezierCurveTo(19.377, 17.724, 18.991999999999997, 18.108999999999998, 18.516, 18.108999999999998), t.lineTo(5.882, 18.108999999999998), t.bezierCurveTo(5.404999999999999, 18.108999999999998, 5.02, 17.723, 5.02, 17.247), t.lineTo(5.02, 11.144), t.bezierCurveTo(5.02, 10.666, 5.406, 10.281, 5.882, 10.281), t.lineTo(18.516, 10.281), t.bezierCurveTo(18.993, 10.281, 19.377, 10.666, 19.377, 11.144), t.lineTo(19.377, 17.247), t.closePath(), t.fill(), t.stroke(), t.restore(), t.save(), t.save(), t.fillStyle = "#2e8ece", t.beginPath(), t.moveTo(18.536, 13.176), t.bezierCurveTo(18.536, 13.518, 18.261000000000003, 13.794, 17.919, 13.794), t.lineTo(6.479, 13.794), t.bezierCurveTo(6.1370000000000005, 13.794, 5.861, 13.518, 5.861, 13.176), t.lineTo(5.861, 11.84), t.bezierCurveTo(5.861, 11.498, 6.137, 11.221, 6.479, 11.221), t.lineTo(17.918, 11.221), t.bezierCurveTo(18.259999999999998, 11.221, 18.535, 11.497, 18.535, 11.84), t.lineTo(18.535, 13.176), t.closePath(), t.fill(), t.stroke(), t.restore(), t.save(), t.fillStyle = "#2e8ece", t.beginPath(), t.moveTo(18.536, 16.551), t.bezierCurveTo(
          18.536,
          16.892999999999997,
          18.261000000000003,
          17.168999999999997,
          17.919,
          17.168999999999997
        ), t.lineTo(6.479, 17.168999999999997), t.bezierCurveTo(6.1370000000000005, 17.168999999999997, 5.861, 16.892999999999997, 5.861, 16.551), t.lineTo(5.861, 15.215999999999998), t.bezierCurveTo(5.861, 14.872999999999998, 6.137, 14.596999999999998, 6.479, 14.596999999999998), t.lineTo(17.918, 14.596999999999998), t.bezierCurveTo(
          18.259999999999998,
          14.596999999999998,
          18.535,
          14.872999999999998,
          18.535,
          15.215999999999998
        ), t.lineTo(18.535, 16.551), t.closePath(), t.fill(), t.stroke(), t.restore(), t.restore(), t.restore();
      }
    },
    exchanger2: {
      draw: function(t) {
        t.save(), t.translate(0, 0), t.beginPath(), t.moveTo(0, 0), t.lineTo(40, 0), t.lineTo(40, 40), t.lineTo(0, 40), t.closePath(), t.clip(), t.translate(0, 0), t.translate(0, 0), t.scale(1, 1), t.translate(0, 0), t.strokeStyle = "rgba(0,0,0,0)", t.lineCap = "butt", t.lineJoin = "miter", t.miterLimit = 4, t.save(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.restore(), t.save();
        var e = t.createLinearGradient(0.4102, 24.3613, 39.5898, 24.3613);
        e.addColorStop(0, "#1C6B9D"), e.addColorStop(0.0788, "#115A85"), e.addColorStop(0.2046, "#135D89"), e.addColorStop(0.3649, "#186494"), e.addColorStop(0.5432, "#1F70A4"), e.addColorStop(0.6798, "#257AB2"), e.addColorStop(0.7462, "#2377AD"), e.addColorStop(0.8508, "#1E6DA0"), e.addColorStop(0.98, "#125C89"), e.addColorStop(1, "#105984"), t.fillStyle = e, t.beginPath(), t.moveTo(0.41, 16.649), t.bezierCurveTo(0.633, 19.767, 0.871, 20.689, 1.094, 23.807000000000002), t.bezierCurveTo(1.29, 26.548000000000002, 3.324, 28.415000000000003, 5.807, 29.711000000000002), t.bezierCurveTo(10.582, 32.202000000000005, 16.477, 32.806000000000004, 21.875999999999998, 32.523), t.bezierCurveTo(26.929, 32.258, 32.806, 31.197000000000003, 36.709999999999994, 27.992000000000004), t.bezierCurveTo(
          38.30499999999999,
          26.728000000000005,
          38.83599999999999,
          25.103000000000005,
          38.998999999999995,
          23.161000000000005
        ), t.bezierCurveTo(39.589, 16.135000000000005, 39.589, 16.135000000000005, 39.589, 16.135000000000005), t.bezierCurveTo(39.589, 16.135000000000005, 3.26, 16.647, 0.41, 16.649), t.closePath(), t.fill(), t.stroke(), t.restore(), t.save(), t.save(), t.fillStyle = "#2e8ece", t.beginPath(), t.moveTo(16.4, 25.185), t.bezierCurveTo(12.807999999999998, 24.924999999999997, 9.139, 24.238, 5.857999999999999, 22.705), t.bezierCurveTo(
          3.175999999999999,
          21.450999999999997,
          -0.32200000000000095,
          18.971999999999998,
          0.544999999999999,
          15.533999999999999
        ), t.bezierCurveTo(
          1.3499999999999992,
          12.335999999999999,
          4.987999999999999,
          10.495999999999999,
          7.807999999999999,
          9.428999999999998
        ), t.bezierCurveTo(
          11.230999999999998,
          8.133999999999999,
          14.911999999999999,
          7.519999999999999,
          18.558,
          7.345999999999998
        ), t.bezierCurveTo(
          22.233,
          7.169999999999998,
          25.966,
          7.437999999999998,
          29.548000000000002,
          8.300999999999998
        ), t.bezierCurveTo(32.673, 9.052999999999999, 36.192, 10.296, 38.343, 12.814999999999998), t.bezierCurveTo(
          40.86600000000001,
          15.768999999999998,
          39.208000000000006,
          19.066999999999997,
          36.406000000000006,
          21.043999999999997
        ), t.bezierCurveTo(
          33.566,
          23.046999999999997,
          30.055000000000007,
          24.071999999999996,
          26.670000000000005,
          24.676999999999996
        ), t.bezierCurveTo(23.289, 25.28, 19.824, 25.436, 16.4, 25.185), t.bezierCurveTo(13.529, 24.977, 19.286, 25.396, 16.4, 25.185), t.closePath(), t.fill(), t.stroke(), t.restore(), t.restore(), t.save(), t.save(), t.save(), t.save(), t.save(), t.fillStyle = "#f7f8f8", t.beginPath(), t.moveTo(5.21, 21.754), t.lineTo(8.188, 17.922), t.lineTo(9.53, 18.75), t.lineTo(15.956, 16.004), t.lineTo(18.547, 17.523), t.lineTo(12.074, 20.334), t.lineTo(13.464, 21.204), t.lineTo(5.21, 21.754), t.closePath(), t.fill(), t.stroke(), t.restore(), t.restore(), t.restore(), t.save(), t.save(), t.save(), t.fillStyle = "#f7f8f8", t.beginPath(), t.moveTo(17.88, 14.61), t.lineTo(9.85, 13.522), t.lineTo(11.703, 12.757), t.lineTo(7.436, 10.285), t.lineTo(10.783, 8.942), t.lineTo(15.091, 11.357), t.lineTo(16.88, 10.614), t.lineTo(17.88, 14.61), t.closePath(), t.fill(), t.stroke(), t.restore(), t.restore(), t.save(), t.save(), t.fillStyle = "#f7f8f8", t.beginPath(), t.moveTo(17.88, 14.61), t.lineTo(9.85, 13.522), t.lineTo(11.703, 12.757), t.lineTo(7.436, 10.285), t.lineTo(10.783, 8.942), t.lineTo(15.091, 11.357), t.lineTo(16.88, 10.614), t.lineTo(17.88, 14.61), t.closePath(), t.fill(), t.stroke(), t.restore(), t.restore(), t.restore(), t.save(), t.save(), t.save(), t.fillStyle = "#f7f8f8", t.beginPath(), t.moveTo(23.556, 15.339), t.lineTo(20.93, 13.879), t.lineTo(26.953, 11.304), t.lineTo(25.559, 10.567), t.lineTo(33.251, 9.909), t.lineTo(31.087, 13.467), t.lineTo(29.619, 12.703), t.lineTo(23.556, 15.339), t.closePath(), t.fill(), t.stroke(), t.restore(), t.restore(), t.restore(), t.save(), t.save(), t.save(), t.fillStyle = "#f7f8f8", t.beginPath(), t.moveTo(30.028, 23.383), t.lineTo(24.821, 20.366), t.lineTo(22.915, 21.227), t.lineTo(21.669, 16.762), t.lineTo(30.189, 17.942), t.lineTo(28.33, 18.782), t.lineTo(33.579, 21.725), t.lineTo(30.028, 23.383), t.closePath(), t.fill(), t.stroke(), t.restore(), t.restore(), t.save(), t.save(), t.fillStyle = "#f7f8f8", t.beginPath(), t.moveTo(30.028, 23.383), t.lineTo(24.821, 20.366), t.lineTo(22.915, 21.227), t.lineTo(21.669, 16.762), t.lineTo(30.189, 17.942), t.lineTo(28.33, 18.782), t.lineTo(33.579, 21.725), t.lineTo(30.028, 23.383), t.closePath(), t.fill(), t.stroke(), t.restore(), t.restore(), t.restore(), t.restore(), t.restore(), t.restore();
      }
    },
    exchanger: {
      draw: function(t) {
        t.save(), t.translate(0, 0), t.beginPath(), t.moveTo(0, 0), t.lineTo(40, 0), t.lineTo(40, 40), t.lineTo(0, 40), t.closePath(), t.clip(), t.translate(0, 0), t.translate(0, 0), t.scale(1, 1), t.translate(0, 0), t.strokeStyle = "rgba(0,0,0,0)", t.lineCap = "butt", t.lineJoin = "miter", t.miterLimit = 4, t.save(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.restore(), t.save();
        var e = t.createLinearGradient(0.2095, 20.7588, 39.4941, 20.7588);
        e.addColorStop(0, "#6A6969"), e.addColorStop(0.0788, "#4F4C4B"), e.addColorStop(0.352, "#545252"), e.addColorStop(0.6967, "#646262"), e.addColorStop(0.8916, "#6F6E6F"), e.addColorStop(0.9557, "#4C4948"), e.addColorStop(1, "#494645"), t.fillStyle = e, t.beginPath(), t.moveTo(39.449, 12.417), t.lineTo(39.384, 9.424), t.bezierCurveTo(39.384, 9.424, 0.7980000000000018, 22.264, 0.3710000000000022, 23.024), t.bezierCurveTo(
          -0.026999999999997804,
          23.733,
          0.4240000000000022,
          24.903000000000002,
          0.5190000000000022,
          25.647000000000002
        ), t.bezierCurveTo(
          0.7240000000000022,
          27.244000000000003,
          0.9240000000000023,
          28.841,
          1.1350000000000022,
          30.437
        ), t.bezierCurveTo(1.3220000000000023, 31.843, 2.7530000000000023, 32.094, 3.9620000000000024, 32.094), t.bezierCurveTo(8.799000000000003, 32.092, 13.636000000000003, 32.091, 18.473000000000003, 32.089), t.bezierCurveTo(23.515, 32.086999999999996, 28.556000000000004, 32.086, 33.598, 32.083999999999996), t.bezierCurveTo(34.859, 32.083999999999996, 36.286, 31.979999999999997, 37.266, 31.081999999999997), t.bezierCurveTo(
          37.537,
          30.820999999999998,
          37.655,
          30.535999999999998,
          37.699999999999996,
          30.229999999999997
        ), t.lineTo(37.711, 30.316999999999997), t.lineTo(39.281, 16.498999999999995), t.bezierCurveTo(
          39.281,
          16.498999999999995,
          39.467999999999996,
          15.126999999999995,
          39.489,
          14.666999999999994
        ), t.bezierCurveTo(39.515, 14.105, 39.449, 12.417, 39.449, 12.417), t.closePath(), t.fill(), t.stroke(), t.restore(), t.save(), t.save(), t.save(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.save(), t.restore(), t.restore(), t.save();
        var e = t.createLinearGradient(19.8052, 7.7949, 19.8052, 24.7632);
        e.addColorStop(0, "#7D7D7D"), e.addColorStop(0.1455, "#808080"), e.addColorStop(0.2975, "#888888"), e.addColorStop(0.4527, "#939293"), e.addColorStop(0.6099, "#9E9D9D"), e.addColorStop(0.7687, "#A7A5A4"), e.addColorStop(0.9268, "#A9A6A5"), e.addColorStop(0.9754, "#A7A4A3"), e.addColorStop(1, "#FFFFFF"), t.fillStyle = e, t.beginPath(), t.moveTo(33.591, 24.763), t.bezierCurveTo(
          23.868000000000002,
          24.754,
          14.145,
          24.746000000000002,
          4.423000000000002,
          24.738000000000003
        ), t.bezierCurveTo(
          3.140000000000002,
          24.737000000000002,
          -0.48799999999999777,
          24.838000000000005,
          0.3520000000000021,
          22.837000000000003
        ), t.bezierCurveTo(
          1.292000000000002,
          20.594000000000005,
          2.2330000000000023,
          18.351000000000003,
          3.1730000000000023,
          16.108000000000004
        ), t.bezierCurveTo(
          4.113000000000002,
          13.865000000000006,
          5.054000000000002,
          11.623000000000005,
          5.994000000000002,
          9.380000000000004
        ), t.bezierCurveTo(
          6.728000000000002,
          7.629000000000005,
          9.521000000000003,
          7.885000000000004,
          11.156000000000002,
          7.880000000000004
        ), t.bezierCurveTo(
          16.974000000000004,
          7.861000000000004,
          22.793000000000003,
          7.843000000000004,
          28.612000000000002,
          7.825000000000005
        ), t.bezierCurveTo(
          30.976000000000003,
          7.818000000000005,
          33.341,
          7.810000000000005,
          35.707,
          7.803000000000004
        ), t.bezierCurveTo(36.157000000000004, 7.802000000000004, 36.609, 7.787000000000004, 37.06, 7.804000000000005), t.bezierCurveTo(
          37.793,
          7.833000000000005,
          39.389,
          7.875000000000004,
          39.385000000000005,
          9.424000000000005
        ), t.bezierCurveTo(
          39.38400000000001,
          9.647000000000006,
          39.31,
          10.138000000000005,
          39.27700000000001,
          10.359000000000005
        ), t.bezierCurveTo(
          38.81900000000001,
          13.361000000000004,
          38.452000000000005,
          15.764000000000006,
          37.99400000000001,
          18.766000000000005
        ), t.bezierCurveTo(
          37.806000000000004,
          19.998000000000005,
          37.61800000000001,
          21.230000000000004,
          37.43000000000001,
          22.462000000000007
        ), t.bezierCurveTo(37.151, 24.271, 35.264, 24.77, 33.591, 24.763), t.closePath(), t.fill(), t.stroke(), t.restore(), t.restore(), t.restore(), t.save(), t.save(), t.save(), t.fillStyle = "#f7f8f8", t.beginPath(), t.moveTo(10.427, 19.292), t.lineTo(5.735, 16.452), t.lineTo(12.58, 13.8), t.lineTo(12.045, 15.07), t.lineTo(20.482, 15.072), t.lineTo(19.667, 17.887), t.lineTo(11.029, 17.851), t.lineTo(10.427, 19.292), t.closePath(), t.fill(), t.stroke(), t.restore(), t.restore(), t.save(), t.save(), t.fillStyle = "#f7f8f8", t.beginPath(), t.moveTo(13.041, 13.042), t.lineTo(8.641, 10.73), t.lineTo(14.82, 8.474), t.lineTo(14.373, 9.537), t.lineTo(22.102, 9.479), t.lineTo(21.425, 11.816), t.lineTo(13.54, 11.85), t.lineTo(13.041, 13.042), t.closePath(), t.fill(), t.stroke(), t.restore(), t.restore(), t.save(), t.save(), t.fillStyle = "#f7f8f8", t.beginPath(), t.moveTo(29.787, 16.049), t.lineTo(29.979, 14.704), t.lineTo(21.51, 14.706), t.lineTo(22.214, 12.147), t.lineTo(30.486, 12.116), t.lineTo(30.653, 10.926), t.lineTo(36.141, 13.4), t.lineTo(29.787, 16.049), t.closePath(), t.fill(), t.stroke(), t.restore(), t.restore(), t.save(), t.save(), t.fillStyle = "#f7f8f8", t.beginPath(), t.moveTo(28.775, 23.14), t.lineTo(29.011, 21.49), t.lineTo(19.668, 21.405), t.lineTo(20.523, 18.295), t.lineTo(29.613, 18.338), t.lineTo(29.815, 16.898), t.lineTo(35.832, 19.964), t.lineTo(28.775, 23.14), t.closePath(), t.fill(), t.stroke(), t.restore(), t.restore(), t.restore(), t.restore();
      }
    },
    cloud: {
      draw: function(t) {
        t.save(), t.beginPath(), t.moveTo(0, 0), t.lineTo(90.75, 0), t.lineTo(90.75, 62.125), t.lineTo(0, 62.125), t.closePath(), t.clip(), t.strokeStyle = "rgba(0,0,0,0)", t.lineCap = "butt", t.lineJoin = "miter", t.miterLimit = 4, t.save();
        var e = t.createLinearGradient(44.0054, 6.4116, 44.0054, 51.3674);
        e.addColorStop(0, "rgba(159, 160, 160, 0.7)"), e.addColorStop(0.9726, "#E9EAEA"), t.fillStyle = e, t.beginPath(), t.moveTo(57.07, 20.354), t.bezierCurveTo(57.037, 20.354, 57.006, 20.358, 56.974000000000004, 20.358), t.bezierCurveTo(
          54.461000000000006,
          14.308,
          48.499,
          10.049000000000001,
          41.538000000000004,
          10.049000000000001
        ), t.bezierCurveTo(
          33.801,
          10.049000000000001,
          27.309000000000005,
          15.316000000000003,
          25.408000000000005,
          22.456000000000003
        ), t.bezierCurveTo(
          18.988000000000007,
          23.289,
          14.025000000000006,
          28.765000000000004,
          14.025000000000006,
          35.413000000000004
        ), t.bezierCurveTo(
          14.025000000000006,
          42.635000000000005,
          19.880000000000006,
          48.49,
          27.102000000000004,
          48.49
        ), t.bezierCurveTo(29.321000000000005, 48.49, 31.407000000000004, 47.933, 33.237, 46.961), t.bezierCurveTo(34.980000000000004, 49.327, 37.78, 50.867999999999995, 40.945, 50.867999999999995), t.bezierCurveTo(43.197, 50.867999999999995, 45.261, 50.086, 46.896, 48.785999999999994), t.bezierCurveTo(49.729, 50.78699999999999, 53.244, 51.98799999999999, 57.07, 51.98799999999999), t.bezierCurveTo(66.412, 51.98799999999999, 73.986, 44.90699999999999, 73.986, 36.17099999999999), t.bezierCurveTo(73.986, 27.436, 66.413, 20.354, 57.07, 20.354), t.closePath(), t.fill(), t.stroke(), t.restore(), t.restore();
      }
    },
    node: {
      width: 60,
      height: 100,
      draw: function(t) {
        t.save(), t.translate(0, 0), t.beginPath(), t.moveTo(0, 0), t.lineTo(40, 0), t.lineTo(40, 40), t.lineTo(0, 40), t.closePath(), t.clip(), t.translate(0, 0), t.translate(0, 0), t.scale(1, 1), t.translate(0, 0), t.strokeStyle = "rgba(0,0,0,0)", t.lineCap = "butt", t.lineJoin = "miter", t.miterLimit = 4, t.save(), t.fillStyle = "#9fa0a0", t.beginPath(), t.moveTo(13.948, 31.075), t.lineTo(25.914, 31.075), t.quadraticCurveTo(25.914, 31.075, 25.914, 31.075), t.lineTo(25.914, 34.862), t.quadraticCurveTo(25.914, 34.862, 25.914, 34.862), t.lineTo(13.948, 34.862), t.quadraticCurveTo(13.948, 34.862, 13.948, 34.862), t.lineTo(13.948, 31.075), t.quadraticCurveTo(13.948, 31.075, 13.948, 31.075), t.closePath(), t.fill(), t.stroke(), t.restore(), t.save(), t.fillStyle = "#c9caca", t.beginPath(), t.moveTo(29.679, 35.972), t.bezierCurveTo(29.679, 36.675000000000004, 29.110999999999997, 37.244, 28.407999999999998, 37.244), t.lineTo(11.456, 37.244), t.bezierCurveTo(10.751999999999999, 37.244, 10.183, 36.675, 10.183, 35.972), t.lineTo(10.183, 36.136), t.bezierCurveTo(10.183, 35.431000000000004, 10.751999999999999, 34.863, 11.456, 34.863), t.lineTo(28.407, 34.863), t.bezierCurveTo(29.11, 34.863, 29.678, 35.431, 29.678, 36.136), t.lineTo(29.678, 35.972), t.closePath(), t.fill(), t.stroke(), t.restore(), t.save(), t.fillStyle = "#c9caca", t.beginPath(), t.moveTo(0.196, 29.346), t.bezierCurveTo(0.196, 30.301, 0.9690000000000001, 31.075, 1.925, 31.075), t.lineTo(37.936, 31.075), t.bezierCurveTo(38.891, 31.075, 39.665, 30.301, 39.665, 29.346), t.lineTo(39.665, 27.174), t.lineTo(0.196, 27.174), t.lineTo(0.196, 29.346), t.closePath(), t.fill(), t.stroke(), t.restore(), t.save(), t.fillStyle = "#3e3a39", t.beginPath(), t.moveTo(37.937, 3.884), t.lineTo(1.926, 3.884), t.bezierCurveTo(0.97, 3.884, 0.19699999999999984, 4.657, 0.19699999999999984, 5.614), t.lineTo(0.19699999999999984, 27.12), t.lineTo(39.666000000000004, 27.12), t.lineTo(39.666000000000004, 5.615), t.bezierCurveTo(39.665, 4.657, 38.892, 3.884, 37.937, 3.884), t.closePath(), t.fill(), t.stroke(), t.restore(), t.save(), t.save(), t.restore(), t.save(), t.restore(), t.restore(), t.save();
        var e = t.createLinearGradient(6.9609, 2.9341, 32.9008, 28.874);
        e.addColorStop(0, "#B2CBEA"), e.addColorStop(1, "#2E8ECE"), t.fillStyle = e, t.beginPath(), t.moveTo(35.788, 6.39), t.lineTo(4.074, 6.39), t.bezierCurveTo(3.315, 6.39, 2.702, 7.003, 2.702, 7.763), t.lineTo(2.702, 24.616), t.lineTo(37.159, 24.616), t.lineTo(37.159, 7.763), t.bezierCurveTo(37.159, 7.003, 36.546, 6.39, 35.788, 6.39), t.closePath(), t.fill(), t.stroke(), t.restore(), t.restore();
      }
    },
    group: {
      draw: function(t) {
        t.save(), t.translate(0, 0), t.beginPath(), t.moveTo(0, 0), t.lineTo(47.75, 0), t.lineTo(47.75, 40), t.lineTo(0, 40), t.closePath(), t.clip(), t.translate(0, 0), t.translate(0, 0), t.scale(1, 1), t.translate(0, 0), t.strokeStyle = "rgba(0,0,0,0)", t.lineCap = "butt", t.lineJoin = "miter", t.miterLimit = 4, t.save(), t.save(), t.fillStyle = "#9fa0a0", t.beginPath(), t.moveTo(10.447, 26.005), t.lineTo(18.847, 26.005), t.quadraticCurveTo(18.847, 26.005, 18.847, 26.005), t.lineTo(18.847, 28.663), t.quadraticCurveTo(18.847, 28.663, 18.847, 28.663), t.lineTo(10.447, 28.663), t.quadraticCurveTo(10.447, 28.663, 10.447, 28.663), t.lineTo(10.447, 26.005), t.quadraticCurveTo(10.447, 26.005, 10.447, 26.005), t.closePath(), t.fill(), t.stroke(), t.restore(), t.save(), t.fillStyle = "#c9caca", t.beginPath(), t.moveTo(21.491, 29.443), t.bezierCurveTo(21.491, 29.935000000000002, 21.094, 30.338, 20.597, 30.338), t.lineTo(8.698, 30.338), t.bezierCurveTo(8.201, 30.338, 7.8020000000000005, 29.936, 7.8020000000000005, 29.443), t.lineTo(7.8020000000000005, 29.557000000000002), t.bezierCurveTo(
          7.8020000000000005,
          29.063000000000002,
          8.201,
          28.662000000000003,
          8.698,
          28.662000000000003
        ), t.lineTo(20.597, 28.662000000000003), t.bezierCurveTo(21.093, 28.662000000000003, 21.491, 29.062, 21.491, 29.557000000000002), t.lineTo(21.491, 29.443), t.closePath(), t.fill(), t.stroke(), t.restore(), t.save(), t.fillStyle = "#c9caca", t.beginPath(), t.moveTo(0.789, 24.79), t.bezierCurveTo(0.789, 25.461, 1.334, 26.005, 2.0060000000000002, 26.005), t.lineTo(27.289, 26.005), t.bezierCurveTo(27.961000000000002, 26.005, 28.504, 25.461, 28.504, 24.79), t.lineTo(28.504, 23.267), t.lineTo(0.789, 23.267), t.lineTo(0.789, 24.79), t.closePath(), t.fill(), t.stroke(), t.restore(), t.save(), t.fillStyle = "#3e3a39", t.beginPath(), t.moveTo(27.289, 6.912), t.lineTo(2.006, 6.912), t.bezierCurveTo(1.3339999999999996, 6.912, 0.7889999999999997, 7.455, 0.7889999999999997, 8.126), t.lineTo(0.7889999999999997, 23.227), t.lineTo(28.503999999999998, 23.227), t.lineTo(28.503999999999998, 8.126), t.bezierCurveTo(28.504, 7.455, 27.961, 6.912, 27.289, 6.912), t.closePath(), t.fill(), t.stroke(), t.restore(), t.save(), t.save(), t.restore(), t.save(), t.restore(), t.restore(), t.save();
        var e = t.createLinearGradient(5.54, 6.2451, 23.7529, 24.458);
        e.addColorStop(0, "#B2CBEA"), e.addColorStop(1, "#2E8ECE"), t.fillStyle = e, t.beginPath(), t.moveTo(25.78, 8.671), t.lineTo(3.514, 8.671), t.bezierCurveTo(2.9819999999999998, 8.671, 2.549, 9.101999999999999, 2.549, 9.635), t.lineTo(2.549, 21.466), t.lineTo(26.743, 21.466), t.lineTo(26.743, 9.636), t.bezierCurveTo(26.743, 9.102, 26.312, 8.671, 25.78, 8.671), t.closePath(), t.fill(), t.stroke(), t.restore(), t.restore(), t.save(), t.save(), t.fillStyle = "#9fa0a0", t.beginPath(), t.moveTo(27.053, 33.602), t.lineTo(36.22, 33.602), t.quadraticCurveTo(36.22, 33.602, 36.22, 33.602), t.lineTo(36.22, 36.501), t.quadraticCurveTo(36.22, 36.501, 36.22, 36.501), t.lineTo(27.053, 36.501), t.quadraticCurveTo(27.053, 36.501, 27.053, 36.501), t.lineTo(27.053, 33.602), t.quadraticCurveTo(27.053, 33.602, 27.053, 33.602), t.closePath(), t.fill(), t.stroke(), t.restore(), t.save(), t.fillStyle = "#c9caca", t.beginPath(), t.moveTo(39.104, 37.352), t.bezierCurveTo(39.104, 37.891, 38.67, 38.327, 38.13, 38.327), t.lineTo(25.143, 38.327), t.bezierCurveTo(24.602, 38.327, 24.166, 37.891, 24.166, 37.352), t.lineTo(24.166, 37.477999999999994), t.bezierCurveTo(24.166, 36.937, 24.602, 36.501, 25.143, 36.501), t.lineTo(38.131, 36.501), t.bezierCurveTo(38.671, 36.501, 39.105, 36.937, 39.105, 37.477999999999994), t.lineTo(39.105, 37.352), t.closePath(), t.fill(), t.stroke(), t.restore(), t.save(), t.fillStyle = "#c9caca", t.beginPath(), t.moveTo(16.514, 32.275), t.bezierCurveTo(16.514, 33.004999999999995, 17.107, 33.601, 17.839, 33.601), t.lineTo(45.433, 33.601), t.bezierCurveTo(46.166, 33.601, 46.758, 33.005, 46.758, 32.275), t.lineTo(46.758, 30.607999999999997), t.lineTo(16.514, 30.607999999999997), t.lineTo(16.514, 32.275), t.closePath(), t.fill(), t.stroke(), t.restore(), t.save(), t.fillStyle = "#3e3a39", t.beginPath(), t.moveTo(45.433, 12.763), t.lineTo(17.839, 12.763), t.bezierCurveTo(17.107, 12.763, 16.514, 13.356, 16.514, 14.089), t.lineTo(16.514, 30.57), t.lineTo(46.757999999999996, 30.57), t.lineTo(46.757999999999996, 14.088), t.bezierCurveTo(46.758, 13.356, 46.166, 12.763, 45.433, 12.763), t.closePath(), t.fill(), t.stroke(), t.restore(), t.save(), t.save(), t.restore(), t.save(), t.restore(), t.restore(), t.save(), e = t.createLinearGradient(21.6973, 12.0352, 41.5743, 31.9122), e.addColorStop(0, "#B2CBEA"), e.addColorStop(1, "#2E8ECE"), t.fillStyle = e, t.beginPath(), t.moveTo(43.785, 14.683), t.lineTo(19.486, 14.683), t.bezierCurveTo(18.903000000000002, 14.683, 18.433, 15.153, 18.433, 15.735), t.lineTo(18.433, 28.649), t.lineTo(44.837, 28.649), t.lineTo(44.837, 15.734), t.bezierCurveTo(44.838, 15.153, 44.367, 14.683, 43.785, 14.683), t.closePath(), t.fill(), t.stroke(), t.restore(), t.restore(), t.save(), t.globalAlpha = 0.5, t.beginPath(), t.moveTo(23.709, 36.33), t.lineTo(4.232, 36.33), t.lineTo(4.232, 27.199), t.lineTo(5.304, 27.199), t.lineTo(5.304, 35.259), t.lineTo(23.709, 35.259), t.lineTo(23.709, 36.33), t.closePath(), t.fill(), t.stroke(), t.restore(), t.restore();
      }
    },
    subnetwork: {
      draw: function(t) {
        t.save(), t.translate(0, 0), t.beginPath(), t.moveTo(0, 0), t.lineTo(60.75, 0), t.lineTo(60.75, 42.125), t.lineTo(0, 42.125), t.closePath(), t.clip(), t.translate(0, 0.26859504132231393), t.scale(0.6694214876033058, 0.6694214876033058), t.translate(0, 0), t.strokeStyle = "rgba(0,0,0,0)", t.lineCap = "butt", t.lineJoin = "miter", t.miterLimit = 4, t.save(), t.save(), t.restore(), t.save(), t.restore(), t.restore(), t.save();
        var e = t.createLinearGradient(43.6724, -2.7627, 43.6724, 59.3806);
        e.addColorStop(0, "rgba(159, 160, 160, 0.7)"), e.addColorStop(0.9726, "#E9EAEA"), t.fillStyle = e, t.beginPath(), t.moveTo(61.732, 16.509), t.bezierCurveTo(61.686, 16.509, 61.644, 16.515, 61.599, 16.515), t.bezierCurveTo(58.126, 8.152000000000001, 49.884, 2.2650000000000006, 40.262, 2.2650000000000006), t.bezierCurveTo(29.567, 2.2650000000000006, 20.594, 9.545000000000002, 17.966, 19.415), t.bezierCurveTo(9.09, 20.566, 2.229, 28.136, 2.229, 37.326), t.bezierCurveTo(2.229, 47.309, 10.322, 55.403000000000006, 20.306, 55.403000000000006), t.bezierCurveTo(23.374000000000002, 55.403000000000006, 26.257, 54.633, 28.787, 53.28900000000001), t.bezierCurveTo(31.197, 56.56000000000001, 35.067, 58.69000000000001, 39.442, 58.69000000000001), t.bezierCurveTo(42.555, 58.69000000000001, 45.408, 57.60900000000001, 47.669, 55.81200000000001), t.bezierCurveTo(
          51.586,
          58.57800000000001,
          56.443999999999996,
          60.238000000000014,
          61.732,
          60.238000000000014
        ), t.bezierCurveTo(
          74.64699999999999,
          60.238000000000014,
          85.116,
          50.45000000000002,
          85.116,
          38.37400000000001
        ), t.bezierCurveTo(85.116, 26.298, 74.646, 16.509, 61.732, 16.509), t.closePath(), t.fill(), t.stroke(), t.restore(), t.save(), t.save(), t.fillStyle = "#9fa0a0", t.beginPath(), t.moveTo(34.966, 44.287), t.lineTo(45.112, 44.287), t.quadraticCurveTo(45.112, 44.287, 45.112, 44.287), t.lineTo(45.112, 47.497), t.quadraticCurveTo(45.112, 47.497, 45.112, 47.497), t.lineTo(34.966, 47.497), t.quadraticCurveTo(34.966, 47.497, 34.966, 47.497), t.lineTo(34.966, 44.287), t.quadraticCurveTo(34.966, 44.287, 34.966, 44.287), t.closePath(), t.fill(), t.stroke(), t.restore(), t.save(), t.fillStyle = "#727171", t.beginPath(), t.moveTo(48.306, 48.439), t.bezierCurveTo(48.306, 49.034, 47.824999999999996, 49.52, 47.226, 49.52), t.lineTo(32.854, 49.52), t.bezierCurveTo(32.253, 49.52, 31.771, 49.034000000000006, 31.771, 48.439), t.lineTo(31.771, 48.578), t.bezierCurveTo(31.771, 47.981, 32.253, 47.497, 32.854, 47.497), t.lineTo(47.226, 47.497), t.bezierCurveTo(47.824999999999996, 47.497, 48.306, 47.98, 48.306, 48.578), t.lineTo(48.306, 48.439), t.closePath(), t.fill(), t.stroke(), t.restore(), t.save(), t.fillStyle = "#b5b5b6", t.beginPath(), t.moveTo(23.302, 42.82), t.bezierCurveTo(23.302, 43.63, 23.96, 44.287, 24.772, 44.287), t.lineTo(55.308, 44.287), t.bezierCurveTo(56.12, 44.287, 56.775, 43.629999999999995, 56.775, 42.82), t.lineTo(56.775, 40.98), t.lineTo(23.302, 40.98), t.lineTo(23.302, 42.82), t.closePath(), t.fill(), t.stroke(), t.restore(), t.save(), t.fillStyle = "#3e3a39", t.beginPath(), t.moveTo(55.307, 21.229), t.lineTo(24.771, 21.229), t.bezierCurveTo(23.959, 21.229, 23.301000000000002, 21.884, 23.301000000000002, 22.695), t.lineTo(23.301000000000002, 40.933), t.lineTo(56.774, 40.933), t.lineTo(56.774, 22.695), t.bezierCurveTo(56.774, 21.884, 56.119, 21.229, 55.307, 21.229), t.closePath(), t.fill(), t.stroke(), t.restore(), t.save(), t.save(), t.restore(), t.save(), t.restore(), t.restore(), t.save(), e = t.createLinearGradient(29.04, 20.4219, 51.0363, 42.4181), e.addColorStop(0, "#B2CBEA"), e.addColorStop(1, "#2E8ECE"), t.fillStyle = e, t.beginPath(), t.moveTo(53.485, 23.353), t.lineTo(26.592, 23.353), t.bezierCurveTo(25.948999999999998, 23.353, 25.427, 23.873, 25.427, 24.517000000000003), t.lineTo(25.427, 38.807), t.lineTo(54.647, 38.807), t.lineTo(54.647, 24.517000000000003), t.bezierCurveTo(54.648, 23.873, 54.127, 23.353, 53.485, 23.353), t.closePath(), t.fill(), t.stroke(), t.restore(), t.restore(), t.restore();
      }
    }
  };
  for (var name in Graphs)
    _8g("Q-" + name, Graphs[name]);
  var UIValidateRotate = function() {
    this.$invalidateRotate = false;
    var t = this._fu;
    t.clear();
    var e = this._8b.x + this.$border / 2, i = this._8b.y + this.$border / 2, n = this._8b.width - this.$border, o = this._8b.height - this.$border, s = localToParent.call(this, {
      x: e,
      y: i
    });
    addPointToRect(t, s.x, s.y, true), s = localToParent.call(this, {
      x: e + n,
      y: i
    }), addPointToRect(t, s.x, s.y), s = localToParent.call(this, {
      x: e + n,
      y: i + o
    }), addPointToRect(t, s.x, s.y), s = localToParent.call(this, {
      x: e,
      y: i + o
    }), addPointToRect(t, s.x, s.y), this.__lkPointer && (s = localToParent.call(this, {
      x: this._pointerX,
      y: this._pointerY
    }), addPointToRect(t, s.x, s.y)), this.$border && t.grow(this.$border / 2);
  }, GIF_INTERVAL_MIN = 20, GIFImageSupport = {
    _gq: false,
    _k2: null,
    _de: 0,
    _l2: -1,
    _l3: null,
    _dn: function(t) {
      this._k2 || (this._k2 = [], this._k9 = IMAGE_STATUS_LOADED), this._k2.push(t), this._dl(), this._km();
    },
    _km: function() {
      if (!this._l3) {
        var t = this;
        this._l3 = setTimeout(function e() {
          return t._dl() !== false ? void (t._l3 = setTimeout(e, t._h5())) : void delete t._l3;
        }, this._h5());
      }
    },
    _h5: function() {
      return Math.max(GIF_INTERVAL_MIN, this._k2[this._l2].delay);
    },
    _dl: function() {
      return this._fs(this._l2 + 1);
    },
    _fs: function(t) {
      if (this._gq)
        t %= this._de;
      else if (t >= this._k2.length)
        return false;
      if (this._l2 == t)
        return false;
      this._l2 = t;
      var e = this._k2[this._l2], i = e._mmache;
      return i || (e._mmache = i = _mkc(this.width, this.height), i.g.putImageData(e.data, 0, 0), i._pixels = e._pixels), this._kf = i, this.$invalidateSize = true, this._dp();
    },
    _dg: function() {
      return this._k2 ? (this._gq = true, this._de = this._k2.length, 1 == this._de ? this._dp() : void this._km()) : void this._hp();
    },
    _ll: function() {
      this._l3 && (clearTimeout(this._l3), delete this._l3);
    },
    _dp: function() {
      var t = this._dispatcher.listeners;
      if (!t || !t.length)
        return false;
      for (var e = new Event(this, "image", "load", this._kf), i = 0, n = t.length; n > i; i++) {
        var o = t[i];
        o.scope._j2 && o.scope._j2._i5ed ? (t.splice(i, 1), i--, n--) : o.onEvent.call(o.scope, e);
      }
      return t.length > 0;
    },
    _mo2: function(t, e) {
      this._dispatcher.addListener(t, e), this._gq && !this._l3 && this._km();
    },
    _7k: function(t, e) {
      this._dispatcher.removeListener(t, e), this._dispatcher._mot() || this._ll();
    },
    _i5: function() {
      this._ll(), this._dispatcher.clear();
    },
    _fp: function() {
      var t = this._kf._moufferedImage;
      return t || (this._kf._moufferedImage = t = new BufferedImage(this._kf, 1)), t;
    }
  }, bitsToNum = function(t) {
    return t.reduce(function(t2, e) {
      return 2 * t2 + e;
    }, 0);
  }, byteToBitArr = function(t) {
    for (var e = [], i = 7; i >= 0; i--)
      e.push(!!(t & 1 << i));
    return e;
  }, Stream = function(t) {
    this.data = t, this.len = this.data.length, this.pos = 0, this.readByte = function() {
      if (this.pos >= this.data.length)
        throw new Error("Attempted to read past end of stream.");
      return 255 & t.charCodeAt(this.pos++);
    }, this.readBytes = function(t2) {
      for (var e = [], i = 0; t2 > i; i++)
        e.push(this.readByte());
      return e;
    }, this.read = function(t2) {
      for (var e = "", i = 0; t2 > i; i++)
        e += String.fromCharCode(this.readByte());
      return e;
    }, this.readUnsigned = function() {
      var t2 = this.readBytes(2);
      return (t2[1] << 8) + t2[0];
    };
  }, lzwDecode = function(t, e) {
    for (var i, n, o = 0, s = function(t2) {
      for (var i2 = 0, n2 = 0; t2 > n2; n2++)
        e.charCodeAt(o >> 3) & 1 << (7 & o) && (i2 |= 1 << n2), o++;
      return i2;
    }, r = [], a = 1 << t, h = a + 1, l = t + 1, _ = [], u = function() {
      _ = [], l = t + 1;
      for (var e2 = 0; a > e2; e2++)
        _[e2] = [e2];
      _[a] = [], _[h] = null;
    }; ; )
      if (n = i, i = s(l), i !== a) {
        if (i === h)
          break;
        if (i < _.length)
          n !== a && _.push(_[n].concat(_[i][0]));
        else {
          if (i !== _.length)
            throw new Error("Invalid LZW code.");
          _.push(_[n].concat(_[n][0]));
        }
        r.push.apply(r, _[i]), _.length === 1 << l && 12 > l && l++;
      } else
        u();
    return r;
  }, parseGIF = function(t, e) {
    e || (e = {});
    var i = function(e2) {
      for (var i2 = [], n2 = 0; e2 > n2; n2++)
        i2.push(t.readBytes(3));
      return i2;
    }, n = function() {
      var e2, i2;
      i2 = "";
      do
        e2 = t.readByte(), i2 += t.read(e2);
      while (0 !== e2);
      return i2;
    }, o = function() {
      var n2 = {};
      if (n2.sig = t.read(3), n2.ver = t.read(3), "GIF" !== n2.sig)
        throw new Error("Not a GIF file.");
      n2.width = t.readUnsigned(), n2.height = t.readUnsigned();
      var o2 = byteToBitArr(t.readByte());
      n2.gctFlag = o2.shift(), n2.colorRes = bitsToNum(o2.splice(0, 3)), n2.sorted = o2.shift(), n2.gctSize = bitsToNum(o2.splice(0, 3)), n2.bgColor = t.readByte(), n2.pixelAspectRatio = t.readByte(), n2.gctFlag && (n2.gct = i(1 << n2.gctSize + 1)), e.hdr && e.hdr(n2);
    }, s = function(i2) {
      var o2 = function(i3) {
        var n2 = (t.readByte(), byteToBitArr(t.readByte()));
        i3.reserved = n2.splice(0, 3), i3.disposalMethod = bitsToNum(n2.splice(0, 3)), i3.userInput = n2.shift(), i3.transparencyGiven = n2.shift(), i3.delayTime = t.readUnsigned(), i3.transparencyIndex = t.readByte(), i3.terminator = t.readByte(), e.gce && e.gce(i3);
      }, s2 = function(t2) {
        t2.comment = n(), e.com && e.com(t2);
      }, r2 = function(i3) {
        t.readByte();
        i3.ptHeader = t.readBytes(12), i3.ptData = n(), e.pte && e.pte(i3);
      }, a2 = function(i3) {
        {
          var o3 = function(i4) {
            t.readByte();
            i4.unknown = t.readByte(), i4.iterations = t.readUnsigned(), i4.terminator = t.readByte(), e.app && e.app.NETSCAPE && e.app.NETSCAPE(i4);
          }, s3 = function(t2) {
            t2.appData = n(), e.app && e.app[t2.identifier] && e.app[t2.identifier](t2);
          };
          t.readByte();
        }
        switch (i3.identifier = t.read(8), i3.authCode = t.read(3), i3.identifier) {
          case "NETSCAPE":
            o3(i3);
            break;
          default:
            s3(i3);
        }
      }, h2 = function(t2) {
        t2.data = n(), e.unknown && e.unknown(t2);
      };
      switch (i2.label = t.readByte(), i2.label) {
        case 249:
          i2.extType = "gce", o2(i2);
          break;
        case 254:
          i2.extType = "com", s2(i2);
          break;
        case 1:
          i2.extType = "pte", r2(i2);
          break;
        case 255:
          i2.extType = "app", a2(i2);
          break;
        default:
          i2.extType = "unknown", h2(i2);
      }
    }, r = function(o2) {
      var s2 = function(t2, e2) {
        for (var i2 = new Array(t2.length), n2 = t2.length / e2, o3 = function(n3, o4) {
          var s4 = t2.slice(o4 * e2, (o4 + 1) * e2);
          i2.splice.apply(i2, [n3 * e2, e2].concat(s4));
        }, s3 = [0, 4, 2, 1], r3 = [8, 8, 4, 2], a3 = 0, h2 = 0; 4 > h2; h2++)
          for (var l = s3[h2]; n2 > l; l += r3[h2])
            o3(l, a3), a3++;
        return i2;
      };
      o2.leftPos = t.readUnsigned(), o2.topPos = t.readUnsigned(), o2.width = t.readUnsigned(), o2.height = t.readUnsigned();
      var r2 = byteToBitArr(t.readByte());
      o2.lctFlag = r2.shift(), o2.interlaced = r2.shift(), o2.sorted = r2.shift(), o2.reserved = r2.splice(0, 2), o2.lctSize = bitsToNum(r2.splice(0, 3)), o2.lctFlag && (o2.lct = i(1 << o2.lctSize + 1)), o2.lzwMinCodeSize = t.readByte();
      var a2 = n();
      o2.pixels = lzwDecode(o2.lzwMinCodeSize, a2), o2.interlaced && (o2.pixels = s2(o2.pixels, o2.width)), e.img && e.img(o2);
    }, a = function() {
      var i2 = {};
      switch (i2.sentinel = t.readByte(), String.fromCharCode(i2.sentinel)) {
        case "!":
          i2.type = "ext", s(i2);
          break;
        case ",":
          i2.type = "img", r(i2);
          break;
        case ";":
          i2.type = "eof", e.eof && e.eof(i2);
          break;
        default:
          throw new Error("Unknown block: 0x" + i2.sentinel.toString(16));
      }
      "eof" !== i2.type && setTimeout(a, 0);
    }, h = function() {
      o(), setTimeout(a, 0);
    };
    h();
  }, authorizationInfo = "";
  document2.addEventListener && document2.addEventListener(
    "keydown",
    function(t) {
      if (t.ctrlKey && t.shiftKey && t.altKey && 73 == t.keyCode) {
        var e = Q2.name + "\nVersion - " + Q2.version + "\nPublish Date - " + Q2.publishDate + "\n" + Q2.about + "\n" + Q2.copyright + authorizationInfo;
        Q2.alert(e);
      }
    },
    false
  ), authorizationInfo = "\nLicensed to: " + decodeURIComponent(
    "%E6%8E%88%E6%9D%83%E7%BB%99%E6%B7%B1%E5%9C%B3%E5%B8%82%E6%B7%B1%E4%BF%A1%E6%9C%8D%E7%94%B5%E5%AD%90%E7%A7%91%E6%8A%80%E6%9C%89%E9%99%90%E5%85%AC%E5%8F%B8%E8%99%9A%E6%8B%9F%E5%8C%96%E4%BA%A7%E5%93%81%E9%83%A8%E9%97%A8"
  );
  var StyleChangeEvent = function(t, e, i, n) {
    this.source = t, this.kind = e, this.oldValue = n, this.value = i, this.propertyType = Consts.PROPERTY_TYPE_STYLE;
  };
  _jq(StyleChangeEvent, PropertyChangeEvent);
  var Element = function(t) {
    this.id = ++idIndex, this._mm5 = {}, this._jb = {}, t && (this.$name = t);
  };
  Element.prototype = {
    _jb: null,
    getStyle: function(t) {
      return this._jb[t];
    },
    setStyle: function(t, e) {
      var i = this._jb[t];
      return i === e || i && e && i.equals && i.equals(e) ? false : this._mkm(t, e, new StyleChangeEvent(this, t, e, i), this._jb);
    },
    putStyles: function(t, e) {
      for (var i in t) {
        var n = t[i];
        e ? this._jb[i] = n : this.setStyle(i, n);
      }
    },
    _$t: true,
    invalidateVisibility: function(t) {
      this._$t = true, t || (this instanceof Node && this.hasEdge() && this.forEachEdge(function(t2) {
        t2._$t = true;
      }), this._i7() && this.hasChildren() && this.forEachChild(function(t2) {
        t2.invalidateVisibility();
      }));
    },
    onParentChanged: function() {
      this.invalidateVisibility();
    },
    _i7: function() {
      return !this._4q && this instanceof Group;
    },
    invalidate: function() {
      this.onEvent(new Event(this, "ui", "invalidate"));
    },
    _mm7: null,
    addUI: function(t, e) {
      if (this._mm7 || (this._mm7 = new HashList()), this._mm7.containsById(t.id))
        return false;
      var i = { id: t.id, ui: t, bindingProperties: e };
      this._mm7.add(i);
      var n = new Event(this, "ui", "add", i);
      return this.onEvent(n);
    },
    removeUI: function(t) {
      if (!this._mm7)
        return false;
      var e = this._mm7.getById(t.id);
      return e ? (this._mm7.remove(e), void this.onEvent(new Event(this, "ui", "remove", e))) : false;
    },
    toString: function() {
      return this.$name || this.id;
    },
    type: "Q.Element",
    _4q: false,
    _hw: true
  }, _jq(Element, Data), _8y(Element.prototype, ["uiClass", "name", "zIndex"]), _4u(Element.prototype, {
    enableSubNetwork: {
      get: function() {
        return this._4q;
      },
      set: function(t) {
        if (this._4q != t) {
          var e = this._4q;
          this._4q = t, this instanceof Node && this._13(), this.onEvent(new PropertyChangeEvent(this, "enableSubNetwork", t, e));
        }
      }
    },
    bindingUIs: {
      get: function() {
        return this._mm7;
      }
    },
    styles: {
      get: function() {
        return this._jb;
      },
      set: function(t) {
        if (this._jb != t) {
          for (var e in this._jb)
            e in t || (t[e] = void 0);
          this.putStyles(t), this._jb = t;
        }
      }
    }
  });
  var Edge = function(t, e, i) {
    this.id = ++idIndex, this._mm5 = {}, this._jb = {}, i && (this.$name = i), this.$from = t, this.$to = e, this.connect();
  };
  Edge.prototype = {
    $uiClass: EdgeUI,
    _k5: null,
    _it: null,
    _k7: null,
    _is: null,
    _ew: false,
    type: "Q.Edge",
    otherNode: function(t) {
      return t == this.from ? this.to : t == this.to ? this.from : void 0;
    },
    connect: function() {
      if (this._ew)
        return false;
      if (!this.$from || !this.$to)
        return false;
      if (this._ew = true, this.$from == this.$to)
        return void this.$from._hx(this);
      _eq(this.$to, this), _dc(this.$from, this), _6h(this.$from, this, this.$to);
      var t = this.fromAgent, e = this.toAgent;
      if (t != e) {
        var i;
        this.$from._e1 && (_5i(t, this, e), i = true), this.$to._e1 && (_7i(e, this), i = true), i && _6h(t, this, e);
      }
    },
    disconnect: function() {
      if (!this._ew)
        return false;
      if (this._ew = false, this.$from == this.$to)
        return void this.$from._mmh(this);
      _8f(this.$from, this), _9e(this.$to, this), _2z(this.$from, this, this.$to);
      var t = this.fromAgent, e = this.toAgent;
      if (t != e) {
        var i;
        this.$from._e1 && (_2w(t, this, e), i = true), this.$to._e1 && (_3z(e, this), i = true), i && _2z(t, this, e);
      }
    },
    isConnected: function() {
      return this._ew;
    },
    isInvalid: function() {
      return !this.$from || !this.$to;
    },
    isLooped: function() {
      return this.$from == this.$to;
    },
    getEdgeBundle: function(t) {
      return t ? this._33() : this.isLooped() ? this.$from._4p : this.$from.getEdgeBundle(this.$to);
    },
    hasEdgeBundle: function() {
      var t = this.getEdgeBundle(true);
      return t && t.edges.length > 1;
    },
    _33: function() {
      var t = this.fromAgent, e = this.toAgent;
      return t == e ? this.$from._e1 || this.$to._e1 ? null : this.$from._4p : this.fromAgent.getEdgeBundle(this.toAgent);
    },
    _9x: null,
    hasPathSegments: function() {
      return this._9x && !this._9x.isEmpty();
    },
    isBundleEnabled: function() {
      return this.bundleEnabled && !this.hasPathSegments();
    },
    firePathChange: function(t) {
      this.onEvent(new PropertyChangeEvent(this, "path.segment", t));
    },
    addPathSegment: function(t, e, i) {
      var n = new PathSegment(e || LINE_TO, t);
      this._9x || (this._9x = new HashList()), this._9x.add(n, i), this.firePathChange(n);
    },
    addPathSegement: function() {
      return this.addPathSegment.apply(this, arguments);
    },
    removePathSegmentByIndex: function(t) {
      if (!this._9x)
        return false;
      var e = this._9x.getByIndex(t);
      e && (this._9x.remove(e), this.firePathChange(e));
    },
    removePathSegment: function(t) {
      return this._9x ? (this._9x.remove(t), void this.firePathChange(t)) : false;
    },
    movePathSegment: function(t, e, i) {
      if (!this._9x)
        return false;
      if (t = t || 0, e = e || 0, Q2.isNumber(i)) {
        var n = this._9x.getByIndex(i);
        return n ? (n.move(t, e), void this.firePathChange()) : false;
      }
      _ic(function(i2) {
        i2.move(t, e);
      }), this.firePathChange();
    },
    move: function(t, e) {
      return this._9x ? (this._9x.forEach(function(i) {
        i.move(t, e);
      }, this), void this.firePathChange()) : false;
    },
    validateEdgeBundle: function() {
    }
  }, _jq(Edge, Element), _4u(Edge.prototype, {
    pathSegments: {
      get: function() {
        return this._9x;
      },
      set: function(t) {
        Q2.isArray(t) && (t = new HashList(t)), this._9x = t, this.firePathChange();
      }
    },
    from: {
      get: function() {
        return this.$from;
      },
      set: function(t) {
        if (this.$from != t) {
          var e = new PropertyChangeEvent(this, "from", t, this.$from);
          this.beforeEvent(e) !== false && (this.disconnect(), this.$from = t, this.connect(), this.onEvent(e));
        }
      }
    },
    to: {
      get: function() {
        return this.$to;
      },
      set: function(t) {
        if (this.$to != t) {
          var e = new PropertyChangeEvent(this, "to", t, this.$to);
          this.beforeEvent(e) !== false && (this.disconnect(), this.$to = t, this.connect(), this.onEvent(e));
        }
      }
    },
    fromAgent: {
      get: function() {
        return this.$from ? this.$from._e1 || this.$from : null;
      }
    },
    toAgent: {
      get: function() {
        return this.$to ? this.$to._e1 || this.$to : null;
      }
    }
  }), _8y(Edge.prototype, ["edgeType", { name: "bundleEnabled", value: true }, "angle"]);
  var Node = function(t, e, i) {
    this.id = ++idIndex, this._mm5 = {}, this._jb = {}, t && (this.$name = t), this.$image = "Q-node", this.$anchorPosition = Position.CENTER_MIDDLE, this.$location = {
      x: e || 0,
      y: i || 0
    }, this._linkedNodes = {};
  };
  Node.prototype = {
    $uiClass: NodeUI,
    _e1: null,
    forEachEdge: function(t, e, i) {
      return !i && this._kg && this._kg.forEach(t, e) === false ? false : _69(this, t, e);
    },
    forEachOutEdge: function(t, e) {
      return _38(this, t, e);
    },
    forEachInEdge: function(t, e) {
      return _45(this, t, e);
    },
    getEdges: function() {
      var t = [];
      return this.forEachEdge(function(e) {
        t.push(e);
      }), t;
    },
    _i3: null,
    _fn: null,
    _jd: null,
    _i0: null,
    _moo: 0,
    _9r: 0,
    hasInEdge: function() {
      return null != this._i3;
    },
    hasOutEdge: function() {
      return null != this._fn;
    },
    hasEdge: function() {
      return null != this._i3 || null != this._fn || this.hasLoops();
    },
    linkedWith: function(t) {
      return t.from == this || t.to == this || t.fromAgent == this || t.toAgent == this;
    },
    hasEdgeWith: function(t) {
      var e = this.getEdgeBundle(t);
      return e && e.edges.length > 0;
    },
    _kg: null,
    _4p: null,
    hasLoops: function() {
      return this._kg && this._kg.length > 0;
    },
    _hx: function(t) {
      return this._kg || (this._kg = new HashList(), this._4p = new EdgeBundle(this, this, this._kg)), this._4p._io(t);
    },
    _mmh: function(t) {
      return this._4p ? this._4p._d1(t) : void 0;
    },
    getEdgeBundle: function(t) {
      return t == this ? this._4p : this._linkedNodes[t.id] || t._linkedNodes[this.id];
    },
    _6v: function() {
      return this._9n && this._9n.length;
    },
    _5a: function() {
      return this._8h && this._8h.length;
    },
    _9o: function() {
      return this._6v() || this._5a();
    },
    _8h: null,
    _9n: null,
    _mmb: function() {
      var t = this._e1, e = findAgentNode(this);
      if (t != e) {
        var i = getAllChildrenEdgeInfos(this);
        this._9l(e), i.forEach(function(t2) {
          var e2 = t2.fromAgent, i2 = t2.toAgent, t2 = t2.edge, n = t2.$from._e1, o = t2.$to._e1;
          e2 != i2 && (e2 && _2w(e2, t2, i2 || t2.$to), i2 && _3z(i2, t2, e2 || t2.$from)), n != o && (n && _5i(n, t2, o || t2.$to), o && _7i(o, t2, n || t2.$from), _6h(n || t2.$from, t2, o || t2.$to));
        }, this);
      }
    },
    onParentChanged: function() {
      this.invalidateVisibility(), this._mmb();
    },
    _8o: null,
    _13: function() {
      var t;
      if (this._4q ? t = null : (t = this._e1, t || this._hk !== false || (t = this)), this._8o == t)
        return false;
      if (this._8o = t, this._fv && this._fv._jf.length)
        for (var e, i = this._fv._jf, n = 0, o = i.length; o > n; n++)
          e = i[n], e instanceof Node && e._9l(t);
    },
    setLocation: function(t, e) {
      if (this.$location && this.$location.x == t && this.$location.y == e)
        return false;
      var i = new PropertyChangeEvent(this, "location", this.$location, { x: t, y: e });
      return this.beforeEvent(i) === false ? false : (this.$location ? (this.$location.x = t, this.$location.y = e) : this.$location = new Point(t, e), this.onEvent(i), true);
    },
    _dx: null,
    addFollower: function(t) {
      return null == t ? false : t.host = this;
    },
    removeFollower: function(t) {
      return this._dx && this._dx.contains(t) ? t.host = null : false;
    },
    hasFollowers: function() {
      return this._dx && !this._dx.isEmpty();
    },
    toFollowers: function() {
      return this.hasFollowers() ? this._dx.toDatas() : null;
    },
    clearFollowers: function() {
      if (this.hasFollowers()) {
        {
          this.toFollowers();
        }
        _ic(this.toFollowers(), function(t) {
          t.host = null;
        });
      }
    },
    getFollowerIndex: function(t) {
      return this._dx && this._dx.contains(t) ? this._dx.indexOf(t) : -1;
    },
    setFollowerIndex: function(t, e) {
      return this._dx && this._dx.contains(t) ? void this._dx.setIndex(t, e) : -1;
    },
    getFollowerCount: function() {
      return this._dx ? this._dx.length : 0;
    },
    _9m: function() {
      return this._dx ? this._dx : (this._dx = new HashList(), this._dx);
    },
    isFollow: function(t) {
      if (!t || !this._host)
        return false;
      for (var e = this._host; e; ) {
        if (e == t)
          return true;
        e = e._host;
      }
      return false;
    },
    _9l: function(t) {
      return t == this._e1 ? false : (this._e1 = t, this.invalidateVisibility(), void this._13());
    },
    type: "Q.Node"
  }, _jq(Node, Element), _4u(Node.prototype, {
    loops: {
      get: function() {
        return this._kg;
      }
    },
    edgeCount: {
      get: function() {
        return this._moo + this._9r;
      }
    },
    agentNode: {
      get: function() {
        return this._e1 || this;
      }
    },
    host: {
      set: function(t) {
        if (this == t || t == this._host)
          return false;
        var e = new PropertyChangeEvent(this, "host", this._host, t);
        if (false === this.beforeEvent(e))
          return false;
        var i = null, n = null, o = this._host;
        if (null != t && (i = new PropertyChangeEvent(t, "follower.add", null, this), false === t.beforeEvent(i)))
          return false;
        if (null != o && (n = new PropertyChangeEvent(o, "follower.remove", null, this), false === o.beforeEvent(n)))
          return false;
        if (this._host = t, null != t) {
          var s = t._9m();
          s.add(this);
        }
        if (null != o) {
          var s = o._9m();
          s.remove(this);
        }
        return this.onEvent(e), null != t && t.onEvent(i), null != o && o.onEvent(n), true;
      },
      get: function() {
        return this._host;
      }
    }
  }), _8y(Node.prototype, ["location", "size", "image", "rotate", "anchorPosition"]), _4u(Node.prototype, {
    x: {
      get: function() {
        return this.location.x;
      },
      set: function(t) {
        t != this.location.x && (this.location = new Point(t, this.location.y));
      }
    },
    y: {
      get: function() {
        return this.location.y;
      },
      set: function(t) {
        t != this.location.y && (this.location = new Point(this.location.x, t));
      }
    }
  });
  var ShapeNode = function(t, e) {
    t instanceof Path && (e = t, t = void 0), _3g(this, ShapeNode, [t]), this.$path = e || new Path(), this.image = this.$path, this.anchorPosition = null, this.uiClass = ShapeNodeUI, Defaults.SHAPENODE_STYLES || (Defaults.SHAPENODE_STYLES = {}, Defaults.SHAPENODE_STYLES[Styles.ARROW_TO] = false), this.putStyles(Defaults.SHAPENODE_STYLES);
  };
  ShapeNode.prototype = {
    $uiClass: ShapeNodeUI,
    type: "Q.ShapeNode",
    moveTo: function(t, e) {
      this.path.moveTo(t, e), this.firePathChange();
    },
    lineTo: function(t, e) {
      this.path.lineTo(t, e), this.firePathChange();
    },
    quadTo: function(t, e, i, n) {
      this.path.quadTo(t, e, i, n), this.firePathChange();
    },
    curveTo: function(t, e, i, n, o, s) {
      this.path.curveTo(t, e, i, n, o, s), this.firePathChange();
    },
    arcTo: function(t, e, i, n, o) {
      this.path.arcTo(t, e, i, n, o), this.firePathChange();
    },
    closePath: function() {
      this.path.closePath(), this.firePathChange();
    },
    clear: function() {
      this.path.clear(), this.firePathChange();
    },
    removePathSegmentByIndex: function(t) {
      this.path.removePathSegment(t) !== false && this.firePathChange();
    },
    firePathChange: function() {
      this.path._6k = true, this.onEvent(new PropertyChangeEvent(this, "path.segment"));
    }
  }, _jq(ShapeNode, Node), _8y(ShapeNode.prototype, ["path"]), _4u(ShapeNode.prototype, {
    pathSegments: {
      get: function() {
        return this.path.segments;
      },
      set: function(t) {
        this.path.segments = t || [], this.firePathChange();
      }
    },
    length: {
      get: function() {
        return this.path.length;
      }
    }
  }), Q2.ShapeNode = ShapeNode;
  var Shapes = {
    _kc: {},
    register: function(t, e) {
      Shapes._kc[t] = e;
    },
    getShape: function(t, e, i, n, o, s) {
      void 0 === n && (n = e, o = i, e = 0, i = 0), n || (n = 50), o || (o = 50);
      var r = Shapes._kc[t];
      return r ? r.generator instanceof Function ? r.generator(e, i, n, o, s) : r : void 0;
    },
    getRect: function(t, e, i, n, o, s, r) {
      return addRect(r || new Path(), t, e, i, n, o, s);
    },
    getAllShapes: function(t, e, i, n, o) {
      var s = {};
      for (var r in Shapes._kc) {
        var a = Shapes.getShape(r, t, e, i, n, o);
        a && (s[r] = a);
      }
      return s;
    },
    createRegularShape: function(t, e, i, n, o) {
      return createRegularPolygon(t, e, i, n, o);
    }
  };
  initShapes(), Bus.prototype = { type: "Q.Bus" }, _jq(Bus, ShapeNode), Q2.Bus = Bus, GraphModel.prototype = {
    _gp: function(t) {
      var e, i = t._j2;
      e = i ? i._fv : this.$roots;
      var n = e.indexOf(t);
      if (0 > n)
        throw new Error("data '" + t + "' not exist in the box");
      for (; n >= 0; ) {
        if (0 == n)
          return i instanceof Node ? i : null;
        n -= 1;
        var o = e.getByIndex(n);
        if (o = _g9(o))
          return o;
      }
      return null;
    },
    forEachNode: function(t, e) {
      this.forEach(function(i) {
        return i instanceof Node && t.call(e, i) === false ? false : void 0;
      });
    },
    _49: null
  }, _jq(GraphModel, DataModel), _4u(GraphModel.prototype, {
    propertyChangeDispatcher: {
      get: function() {
        return this._$x;
      }
    },
    currentSubNetwork: {
      get: function() {
        return this._49;
      },
      set: function(t) {
        if (t && !t.enableSubNetwork && (t = null), this._49 != t) {
          var e = this._49;
          this._49 = t, this._$x.onEvent(new PropertyChangeEvent(this, "currentSubNetwork", t, e));
        }
      }
    }
  }), Defaults.GROUP_TYPE = Consts.GROUP_TYPE_RECT, Defaults.GROUP_PADDING = 5, Defaults.GROUP_EXPANDED = true, Defaults.GROUP_MIN_SIZE = {
    width: 60,
    height: 60
  };
  var Group = function(t, e, i) {
    _3g(this, Group, arguments), (void 0 === e || void 0 === i) && (this.$location.invalidateFlag = true), this.$groupType = Defaults.GROUP_TYPE, this.$padding = Defaults.GROUP_PADDING, this.$image = Graphs.group, this.$minSize = Defaults.GROUP_MIN_SIZE, this.expanded = Defaults.GROUP_EXPANDED;
  };
  Group.prototype = {
    type: "Q.Group",
    $uiClass: GroupUI,
    _9u: function() {
      return !this._hk && !this._e1;
    },
    forEachOutEdge: function(t, e, i) {
      if (_38(this, t, e) === false)
        return false;
      if (!i && this._9u())
        return this._8h ? this._8h.forEach(t, e) : void 0;
    },
    forEachInEdge: function(t, e, i) {
      if (_45(this, t, e) === false)
        return false;
      if (!i && this._9u())
        return this._9n ? this._9n.forEach(t, e) : void 0;
    },
    forEachEdge: function(t, e, i) {
      if (_hr(this, Group, "forEachEdge", arguments) === false)
        return false;
      if (!i && !i && this._9u())
        return this._9n && this._9n.forEach(t, e) === false ? false : this._8h ? this._8h.forEach(t, e) : void 0;
    },
    hasInEdge: function(t) {
      return t ? null != this._i3 : null != this._i3 || this._6v();
    },
    hasOutEdge: function(t) {
      return t ? null != this._fn : null != this._fn || this._5a();
    },
    hasEdge: function(t) {
      return t ? null != this._i3 || null != this._fn : null != this._i3 || null != this._fn || this._9o();
    }
  }, _jq(Group, Node), _4u(Group.prototype, {
    expanded: {
      get: function() {
        return this._hk;
      },
      set: function(t) {
        if (this._hk != t) {
          var e = new PropertyChangeEvent(this, "expanded", t, this._hk);
          this.beforeEvent(e) !== false && (this._hk = t, this._13(), this.onEvent(e), this._e1 || checkGroupAgentEdges.call(this));
        }
      }
    }
  }), _8y(Group.prototype, ["minSize", "groupType", "padding", "groupImage"]), Q2.Group = Group, Text.prototype.type = "Q.Text", _jq(Text, Node), Q2.Text = Text;
  var BaseUI = function(t) {
    this._j1 = new Rect(), this._8b = new Rect(), this._fu = new Rect(), this.id = ++idIndex, t && (this.data = t);
  };
  BaseUI.prototype = {
    invalidate: function() {
      this.invalidateData();
    },
    _1q: true,
    _j1: null,
    _8b: null,
    _fu: null,
    _mkd: false,
    _j7: 1,
    _j0: 1,
    _hw: true,
    _8k: 0,
    _6t: 0,
    _j2: null,
    _mo0: null,
    borderColor: "#444",
    borderLineDash: null,
    borderLineDashOffset: null,
    syncSelection: true,
    syncSelectionStyles: true,
    _1n: function() {
      this.$anchorPoint = _mkr(this.anchorPosition, this._8k, this._6t);
    },
    setMeasuredBounds: function(t, e, i, n) {
      return t instanceof Object && (i = t.x, n = t.y, e = t.height, t = t.width), this._j1.width == t && this._j1.height == e && this._j1.x == i && this._j1.y == n ? false : void this._j1.set(i || 0, n || 0, t || 0, e || 0);
    },
    initialize: function() {
    },
    measure: function() {
    },
    draw: function() {
    },
    _89: function(t, e, i) {
      i.selectionType == Consts.SELECTION_TYPE_SHADOW ? (t.shadowColor = i.selectionColor, t.shadowBlur = i.selectionShadowBlur * e, t.shadowOffsetX = (i.selectionShadowOffsetX || 0) * e, t.shadowOffsetY = (i.selectionShadowOffsetY || 0) * e) : this._2a(t, e, i);
    },
    _2a: function(t, e, i) {
      var n = i.selectionBorder || 0;
      i.selectionBackgroundColor && (t.fillStyle = i.selectionBackgroundColor, t.fillRect(this._8b.x - n / 2, this._8b.y - n / 2, this._8b.width + n, this._8b.height + n)), t.strokeStyle = i.selectionColor, t.lineWidth = n, t.strokeRect(this._8b.x - n / 2, this._8b.y - n / 2, this._8b.width + n, this._8b.height + n);
    },
    _j5: function(t, e, i, n) {
      if (!this._hw)
        return false;
      if (this.syncSelection || (i = this.selected), (i && !this.syncSelectionStyles || !n) && (n = this), t.save(), 1 != this.$alpha && (t.globalAlpha = this.$alpha), t.translate(this.$x, this.$y), this.$rotatable && this.$_hostRotate && t.rotate(this.$_hostRotate), (this.offsetX || this.offsetY) && t.translate(this.offsetX, this.offsetY), this.$rotate && t.rotate(this.$rotate), this.$layoutByAnchorPoint && this._mo0 && t.translate(-this._mo0.x, -this._mo0.y), this.shadowColor && (t.shadowColor = this.shadowColor, t.shadowBlur = this.shadowBlur * e, t.shadowOffsetX = this.shadowOffsetX * e, t.shadowOffsetY = this.shadowOffsetY * e), i && n.selectionType == Consts.SELECTION_TYPE_BORDER_RECT && (this._2a(t, e, n), i = false), this._$v() && this._loShape && !this._loShape._empty) {
        this._loShape.validate();
        var o = {
          lineWidth: this.$border,
          strokeStyle: this.borderColor,
          lineDash: this.borderLineDash,
          lineDashOffset: this.borderLineDashOffset,
          fillColor: this.$backgroundColor,
          fillGradient: this._moackgroundGradient,
          lineCap: "butt",
          lineJoin: "round"
        };
        this._loShape.draw(t, e, o, i, n), i = false, t.shadowColor = "rgba(0,0,0,0)";
      }
      t.beginPath(), this.draw(t, e, i, n), t.restore();
    },
    invalidateData: function() {
      this.$invalidateData = true, this._1q = true;
    },
    invalidateSize: function() {
      this.$invalidateSize = true, this._1q = true;
    },
    invalidateRender: function() {
      this._1q = true;
    },
    _5e: function() {
    },
    _$v: function() {
      return this.$backgroundColor || this.$backgroundGradient || this.$border;
    },
    _4e: function() {
      return this.$backgroundColor || this.$backgroundGradient;
    },
    doValidate: function() {
      return this.$invalidateData && (this.$invalidateData = false, this.measure() !== false && (this.$invalidateSize = true)), this.$invalidateSize && this.validateSize && this.validateSize(), UIValidateBoundsBackgroundBorderAndPointer.call(this) ? (this.$invalidateRotate = true, this.onBoundsChanged && this.onBoundsChanged(), true) : this.$invalidateLocation ? (this.$invalidateLocation = false, true) : void 0;
    },
    validate: function() {
      var t = this._hw;
      return this.$invalidateVisibility && (this.$invalidateVisibility = false, this._hw = this.$visible, !this._hw || (this.$data || this.$showEmpty) && this._5e() !== false || (this._hw = false)), this._hw ? (this._1q = false, this._mkd || (this.initialize(), this._mkd = true), this.doValidate()) : t != this._hw;
    },
    _hu: function(t, e) {
      return t -= this.$x, e -= this.$y, parentToLocal.call(this, { x: t, y: e });
    },
    _hq: function(t, e, i, n) {
      if (t -= this.$x, e -= this.$y, !this._fu.intersectsPoint(t, e, i))
        return false;
      var o = parentToLocal.call(this, { x: t, y: e });
      return t = o.x, e = o.y, !n && this._$v() && this._loShape && this._loShape._hq(t, e, i, false, this.$border, this.$backgroundColor || this.$backgroundGradient) ? true : this._dv ? this._dv(t, e, i) : this._j1.intersectsPoint(t, e, i);
    },
    onDataChanged: function() {
      this.$invalidateData = true, this._1q = true, this.$invalidateVisibility = true;
    },
    getBounds: function() {
      var t = this._fu.clone();
      return t.offset(this.x, this.y), this.parent && (this.parent.rotate && rotateRect(t, this.parent.rotate, t), t.offset(this.parent.x || 0, this.parent.y || 0)), t;
    },
    destroy: function() {
      this._i5ed = true;
    },
    _e0: false
  }, _4u(BaseUI.prototype, {
    data: {
      get: function() {
        return this.$data;
      },
      set: function(t) {
        if (this.$data != t) {
          var e = this.$data;
          this.$data = t, this.onDataChanged(t, e);
        }
      }
    },
    parent: {
      get: function() {
        return this._j2;
      }
    },
    showOnTop: {
      get: function() {
        return this._e0;
      },
      set: function(t) {
        t != this._e0 && (this._e0 = t, this._1q = true, this._j2 && this._j2._mki && this._j2._mki(this));
      }
    }
  }), defineUIProperties(BaseUI.prototype, {
    visible: { value: true, validateFlags: ["Visibility", "Location"] },
    showEmpty: { validateFlags: ["Visibility"] },
    anchorPosition: { value: Position.CENTER_MIDDLE, validateFlags: ["AnchorPoint"] },
    position: { value: Position.CENTER_MIDDLE, validateFlags: ["Location"] },
    offsetX: { value: 0, validateFlags: ["Location"] },
    offsetY: { value: 0, validateFlags: ["Location"] },
    layoutByAnchorPoint: { value: true, validateFlags: ["Size", "AnchorPoint"] },
    padding: { value: 0, validateFlags: ["Size"] },
    border: { value: 0, validateFlags: ["Size"] },
    borderRadius: { value: Defaults.BORDER_RADIUS },
    showPointer: { value: false, validateFlags: ["Size"] },
    pointerX: { value: 0, validateFlags: ["Size"] },
    pointerY: { value: 0, validateFlags: ["Size"] },
    pointerWidth: { value: Defaults.POINTER_WIDTH },
    backgroundColor: { validateFlags: ["Size"] },
    backgroundGradient: { validateFlags: ["Size", "BackgroundGradient"] },
    selected: { value: false, validateFlags: ["Size"] },
    selectionBorder: { value: Defaults.SELECTION_BORDER, validateFlags: ["Size"] },
    selectionShadowBlur: { value: Defaults.SELECTION_SHADOW_BLUR, validateFlags: ["Size"] },
    selectionColor: { value: Defaults.SELECTION_COLOR, validateFlags: ["Size"] },
    selectionType: { value: Defaults.SELECTION_TYPE, validateFlags: ["Size"] },
    selectionShadowOffsetX: { value: 0, validateFlags: ["Size"] },
    selectionShadowOffsetY: { value: 0, validateFlags: ["Size"] },
    shadowBlur: { value: 0, validateFlags: ["Size"] },
    shadowColor: { validateFlags: ["Size"] },
    shadowOffsetX: { value: 0, validateFlags: ["Size"] },
    shadowOffsetY: { value: 0, validateFlags: ["Size"] },
    renderColorBlendMode: {},
    renderColor: {},
    x: { value: 0, validateFlags: ["Location"] },
    y: { value: 0, validateFlags: ["Location"] },
    rotatable: { value: true, validateFlags: ["Rotate", "Size"] },
    rotate: { value: 0, validateFlags: ["Rotate", "Size"] },
    _hostRotate: { validateFlags: ["Rotate"] },
    lineWidth: { value: 0, validateFlags: ["Data"] },
    alpha: { value: 1 }
  });
  var PROPERTY_TYPES = [Consts.PROPERTY_TYPE_ACCESSOR, Consts.PROPERTY_TYPE_STYLE, Consts.PROPERTY_TYPE_CLIENT];
  UIBindingMap.prototype = {
    removeBinding: function(t) {
      for (var e = PROPERTY_TYPES.length; --e >= 0; ) {
        var i = PROPERTY_TYPES[e], n = this[i];
        for (var o in n) {
          var s = n[o];
          Array.isArray(s) ? (_mo6(
            s,
            function(e2) {
              return e2.target == t;
            },
            this
          ), s.length || delete n[o]) : s.target == t && delete n[o];
        }
      }
    },
    _2h: function(t, e, i) {
      if (!i && (i = this[e.propertyType || Consts.PROPERTY_TYPE_ACCESSOR], !i))
        return false;
      var n = i[t];
      n ? (Array.isArray(n) || (i[t] = n = [n]), n.push(e)) : i[t] = e;
    },
    _2x: function(t, e, i, n, o, s) {
      t = t || Consts.PROPERTY_TYPE_ACCESSOR;
      var r = this[t];
      if (!r)
        return false;
      var a = { property: e, propertyType: t, bindingProperty: n, target: i, callback: o, invalidateSize: s };
      this._2h(e, a, r);
    },
    onBindingPropertyChange: function(t, e, i, n) {
      var o = this[i || Consts.PROPERTY_TYPE_ACCESSOR];
      if (!o)
        return false;
      var s = o[e];
      return s ? (t._1q = true, doBinding(t, s, i, n), true) : false;
    },
    initBindingProperties: function(t, e) {
      for (var i = PROPERTY_TYPES.length; --i >= 0; ) {
        var n = PROPERTY_TYPES[i], o = this[n];
        for (var s in o) {
          var r = o[s];
          if (r.bindingProperty) {
            var a = r.target;
            if (a) {
              if (!(a instanceof BaseUI || (a = t[a])))
                continue;
            } else
              a = t;
            var h;
            h = e === false ? t.getProperty(r.property, n) : n == Consts.PROPERTY_TYPE_STYLE ? t.graph.getStyle(t.$data, r.property) : t.$data[r.property], void 0 !== h && (a[r.bindingProperty] = h);
          }
        }
      }
    }
  };
  var Styles = {};
  Styles.SELECTION_COLOR = "selection.color", Styles.SELECTION_BORDER = "selection.border", Styles.SELECTION_SHADOW_BLUR = "selection.shadow.blur", Styles.SELECTION_SHADOW_OFFSET_X = "selection.shadow.offset.x", Styles.SELECTION_SHADOW_OFFSET_Y = "selection.shadow.offset.y", Styles.SELECTION_TYPE = "selection.type", Styles.RENDER_COLOR = "render.color", Styles.RENDER_COLOR_BLEND_MODE = "render.color.blend.mode", Styles.ALPHA = "alpha", Styles.SHADOW_BLUR = "shadow.blur", Styles.SHADOW_COLOR = "shadow.color", Styles.SHADOW_OFFSET_X = "shadow.offset.x", Styles.SHADOW_OFFSET_Y = "shadow.offset.y", Styles.SHAPE_STROKE = "shape.stroke", Styles.SHAPE_STROKE_STYLE = "shape.stroke.style", Styles.SHAPE_LINE_DASH = "shape.line.dash", Styles.SHAPE_LINE_DASH_OFFSET = "shape.line.dash.offset", Styles.SHAPE_FILL_COLOR = "shape.fill.color", Styles.SHAPE_FILL_GRADIENT = "shape.fill.gradient", Styles.SHAPE_OUTLINE = "shape.outline", Styles.SHAPE_OUTLINE_STYLE = "shape.outline.style", Styles.LINE_CAP = "line.cap", Styles.LINE_JOIN = "line.join", Styles.LAYOUT_BY_PATH = "layout.by.path", Styles.BACKGROUND_COLOR = "background.color", Styles.BACKGROUND_GRADIENT = "background.gradient", Styles.BORDER = "border.width", Styles.BORDER_COLOR = "border.color", Styles.BORDER_LINE_DASH = "border.line.dash", Styles.BORDER_LINE_DASH_OFFSET = "border.line.dash.offset", Styles.BORDER_RADIUS = "border.radius", Styles.PADDING = "padding", Styles.IMAGE_BACKGROUND_COLOR = "image.background.color", Styles.IMAGE_BACKGROUND_GRADIENT = "image.background.gradient", Styles.IMAGE_BORDER = "image.border.width", Styles.IMAGE_BORDER_STYLE = Styles.IMAGE_BORDER_COLOR = "image.border.style", Styles.IMAGE_BORDER_LINE_DASH = "image.border.line.dash", Styles.IMAGE_BORDER_LINE_DASH_OFFSET = "image.border.line.dash.offset", Styles.IMAGE_RADIUS = Styles.IMAGE_BORDER_RADIUS = "image.radius", Styles.IMAGE_PADDING = "image.padding", Styles.IMAGE_Z_INDEX = "image.z.index", Styles.IMAGE_ALPHA = "image.alpha", Styles.LABEL_ROTATE = "label.rotate", Styles.LABEL_POSITION = "label.position", Styles.LABEL_ANCHOR_POSITION = "label.anchor.position", Styles.LABEL_COLOR = "label.color", Styles.LABEL_FONT_SIZE = "label.font.size", Styles.LABEL_FONT_FAMILY = "label.font.family", Styles.LABEL_FONT_STYLE = "label.font.style", Styles.LABEL_PADDING = "label.padding", Styles.LABEL_POINTER_WIDTH = "label.pointer.width", Styles.LABEL_POINTER = "label.pointer", Styles.LABEL_RADIUS = "label.radius", Styles.LABEL_OFFSET_X = "label.offset.x", Styles.LABEL_OFFSET_Y = "label.offset.y", Styles.LABEL_SIZE = "label.size", Styles.LABEL_ALIGN_POSITION = "label.align.position", Styles.LABEL_BORDER = "label.border", Styles.LABEL_BORDER_STYLE = "label.border.style", Styles.LABEL_BACKGROUND_COLOR = "label.background.color", Styles.LABEL_BACKGROUND_GRADIENT = "label.background.gradient", Styles.LABEL_ROTATABLE = "label.rotatable", Styles.LABEL_SHADOW_BLUR = "label.shadow.blur", Styles.LABEL_SHADOW_COLOR = "label.shadow.color", Styles.LABEL_SHADOW_OFFSET_X = "label.shadow.offset.x", Styles.LABEL_SHADOW_OFFSET_Y = "label.shadow.offset.y", Styles.LABEL_Z_INDEX = "label.z.index", Styles.LABEL_ON_TOP = "label.on.top", Styles.GROUP_BACKGROUND_COLOR = "group.background.color", Styles.GROUP_BACKGROUND_GRADIENT = "group.background.gradient", Styles.GROUP_STROKE = "group.stroke", Styles.GROUP_STROKE_STYLE = "group.stroke.color", Styles.GROUP_STROKE_LINE_DASH = "group.stroke.line.dash", Styles.GROUP_STROKE_LINE_DASH_OFFSET = "group.stroke.line.dash.offset", Styles.EDGE_BUNDLE_LABEL_ROTATE = "edge.bundle.label.rotate", Styles.EDGE_BUNDLE_LABEL_POSITION = "edge.bundle.label.position", Styles.EDGE_BUNDLE_LABEL_ANCHOR_POSITION = "edge.bundle.label.anchor.position", Styles.EDGE_BUNDLE_LABEL_COLOR = "edge.bundle.label.color", Styles.EDGE_BUNDLE_LABEL_FONT_SIZE = "edge.bundle.label.font.size", Styles.EDGE_BUNDLE_LABEL_FONT_FAMILY = "edge.bundle.label.font.family", Styles.EDGE_BUNDLE_LABEL_FONT_STYLE = "edge.bundle.label.font.style", Styles.EDGE_BUNDLE_LABEL_PADDING = "edge.bundle.label.padding", Styles.EDGE_BUNDLE_LABEL_POINTER_WIDTH = "edge.bundle.label.pointer.width", Styles.EDGE_BUNDLE_LABEL_POINTER = "edge.bundle.label.pointer", Styles.EDGE_BUNDLE_LABEL_RADIUS = "edge.bundle.label.radius", Styles.EDGE_BUNDLE_LABEL_OFFSET_X = "edge.bundle.label.offset.x", Styles.EDGE_BUNDLE_LABEL_OFFSET_Y = "edge.bundle.label.offset.y", Styles.EDGE_BUNDLE_LABEL_BORDER = "edge.bundle.label.border", Styles.EDGE_BUNDLE_LABEL_BORDER_STYLE = "edge.bundle.label.border.color", Styles.EDGE_BUNDLE_LABEL_BACKGROUND_COLOR = "edge.bundle.label.background.color", Styles.EDGE_BUNDLE_LABEL_BACKGROUND_GRADIENT = "edge.bundle.label.background.gradient", Styles.EDGE_BUNDLE_LABEL_ROTATABLE = "edge.bundle.label.rotatable", Styles.EDGE_WIDTH = "edge.width", Styles.EDGE_COLOR = "edge.color", Styles.EDGE_OUTLINE = "edge.outline", Styles.EDGE_OUTLINE_STYLE = "edge.outline.style", Styles.EDGE_LINE_DASH = "edge.line.dash", Styles.EDGE_LINE_DASH_OFFSET = "edge.line.dash.offset", Styles.EDGE_FROM_OFFSET = "edge.from.offset", Styles.EDGE_TO_OFFSET = "edge.to.offset", Styles.EDGE_BUNDLE_GAP = "edge.bundle.gap", Styles.EDGE_LOOPED_EXTAND = "edge.looped.extand", Styles.EDGE_EXTEND = "edge.extend", Styles.EDGE_CONTROL_POINT = "edge.control.point", Styles.EDGE_SPLIT_BY_PERCENT = "edge.split.by.percent", Styles.EDGE_SPLIT_PERCENT = "edge.split.percent", Styles.EDGE_SPLIT_VALUE = "edge.split.value", Styles.EDGE_CORNER = "edge.corner", Styles.EDGE_CORNER_RADIUS = "edge.corner.radius", Styles.EDGE_FROM_AT_EDGE = "edge.from.at.edge", Styles.EDGE_TO_AT_EDGE = "edge.to.at.edge", Styles.ARROW_FROM = "arrow.from", Styles.ARROW_FROM_SIZE = "arrow.from.size", Styles.ARROW_FROM_OFFSET = "arrow.from.offset", Styles.ARROW_FROM_STROKE = "arrow.from.stroke", Styles.ARROW_FROM_STROKE_STYLE = "arrow.from.stroke.style", Styles.ARROW_FROM_OUTLINE = "arrow.from.outline", Styles.ARROW_FROM_OUTLINE_STYLE = "arrow.from.outline.style", Styles.ARROW_FROM_LINE_DASH = "arrow.from.line.dash", Styles.ARROW_FROM_LINE_DASH_OFFSET = "arrow.from.line.dash.offset", Styles.ARROW_FROM_FILL_COLOR = "arrow.from.fill.color", Styles.ARROW_FROM_FILL_GRADIENT = "arrow.from.fill.gradient", Styles.ARROW_FROM_LINE_CAP = "arrow.from.line.cap", Styles.ARROW_FROM_LINE_JOIN = "arrow.from.line.join", Styles.ARROW_TO = "arrow.to", Styles.ARROW_TO_SIZE = "arrow.to.size", Styles.ARROW_TO_OFFSET = "arrow.to.offset", Styles.ARROW_TO_STROKE = "arrow.to.stroke", Styles.ARROW_TO_STROKE_STYLE = "arrow.to.stroke.style", Styles.ARROW_TO_OUTLINE = "arrow.to.outline", Styles.ARROW_TO_OUTLINE_STYLE = "arrow.to.outline.style", Styles.ARROW_TO_LINE_DASH = "arrow.to.line.dash", Styles.ARROW_TO_LINE_DASH_OFFSET = "arrow.to.line.dash.offset", Styles.ARROW_TO_FILL_COLOR = "arrow.to.fill.color", Styles.ARROW_TO_FILL_GRADIENT = "arrow.to.fill.gradient", Styles.ARROW_TO_LINE_CAP = "arrow.to.line.cap", Styles.ARROW_TO_LINE_JOIN = "arrow.to.line.join";
  var ElementUIBindingMap = new UIBindingMap(), PROPERTY_TYPE_ACCESSOR = Consts.PROPERTY_TYPE_ACCESSOR, PROPERTY_TYPE_STYLE = Consts.PROPERTY_TYPE_STYLE;
  ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.SELECTION_TYPE, null, "selectionType"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.SELECTION_BORDER, null, "selectionBorder"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.SELECTION_SHADOW_BLUR, null, "selectionShadowBlur"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.SELECTION_COLOR, null, "selectionColor"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.SELECTION_SHADOW_OFFSET_X, null, "selectionShadowOffsetX"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.SELECTION_SHADOW_OFFSET_Y, null, "selectionShadowOffsetY"), ElementUIBindingMap._2x(PROPERTY_TYPE_ACCESSOR, "name", "label", "data"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LABEL_POSITION, "label", "position"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LABEL_ANCHOR_POSITION, "label", "anchorPosition"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LABEL_COLOR, "label", "color"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LABEL_FONT_SIZE, "label", "fontSize"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LABEL_BORDER, "label", "border"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LABEL_BORDER_STYLE, "label", "borderColor"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LABEL_BACKGROUND_COLOR, "label", "backgroundColor"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LABEL_ON_TOP, "label", "showOnTop"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.SHADOW_BLUR, null, "shadowBlur"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.SHADOW_COLOR, null, "shadowColor"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.SHADOW_OFFSET_X, null, "shadowOffsetX"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.SHADOW_OFFSET_Y, null, "shadowOffsetY"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LABEL_FONT_FAMILY, "label", "fontFamily"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LABEL_FONT_STYLE, "label", "fontStyle"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LABEL_ALIGN_POSITION, "label", "alignPosition"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LABEL_ROTATE, "label", "rotate"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LABEL_PADDING, "label", "padding"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LABEL_POINTER_WIDTH, "label", "pointerWidth"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LABEL_POINTER, "label", "showPointer"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LABEL_RADIUS, "label", "borderRadius"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LABEL_OFFSET_X, "label", "offsetX"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LABEL_OFFSET_Y, "label", "offsetY"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LABEL_ROTATABLE, "label", "rotatable"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LABEL_BACKGROUND_GRADIENT, "label", "backgroundGradient"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LABEL_SIZE, "label", "size"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LABEL_SHADOW_BLUR, "label", "shadowBlur"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LABEL_SHADOW_COLOR, "label", "shadowColor"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LABEL_SHADOW_OFFSET_X, "label", "shadowOffsetX"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LABEL_SHADOW_OFFSET_Y, "label", "shadowOffsetY"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LABEL_Z_INDEX, "label", "zIndex"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.RENDER_COLOR, null, "renderColor"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.RENDER_COLOR_BLEND_MODE, null, "renderColorBlendMode"), ElementUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ALPHA, null, "alpha");
  var NodeUIBindingMap = new UIBindingMap();
  NodeUIBindingMap._2x(PROPERTY_TYPE_ACCESSOR, "location"), NodeUIBindingMap._2x(PROPERTY_TYPE_ACCESSOR, "anchorPosition", null, "_3c"), NodeUIBindingMap._2x(PROPERTY_TYPE_ACCESSOR, "rotate", null, "rotate"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.BACKGROUND_COLOR, null, "backgroundColor"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.BACKGROUND_GRADIENT, null, "backgroundGradient"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.PADDING, null, "padding"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.BORDER, null, "border"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.BORDER_RADIUS, null, "borderRadius"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.BORDER_COLOR, null, "borderColor"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.BORDER_LINE_DASH, null, "borderLineDash"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.BORDER_LINE_DASH_OFFSET, null, "borderLineDashOffset"), NodeUIBindingMap._2x(PROPERTY_TYPE_ACCESSOR, "image", "image", "data", "_moz"), NodeUIBindingMap._2x(PROPERTY_TYPE_ACCESSOR, "size", "image", "size"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.SHAPE_STROKE, "image", "lineWidth"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.SHAPE_STROKE_STYLE, "image", "strokeStyle"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.SHAPE_FILL_COLOR, "image", "fillColor"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.SHAPE_OUTLINE, "image", "outline"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.SHAPE_OUTLINE_STYLE, "image", "outlineStyle"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.SHAPE_FILL_GRADIENT, "image", "fillGradient"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.SHAPE_LINE_DASH, "image", "lineDash"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.SHAPE_LINE_DASH_OFFSET, "image", "lineDashOffset"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LINE_CAP, "image", "lineCap"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LINE_JOIN, "image", "lineJoin"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LAYOUT_BY_PATH, "image", "layoutByPath"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.IMAGE_BACKGROUND_COLOR, "image", "backgroundColor"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.IMAGE_BACKGROUND_GRADIENT, "image", "backgroundGradient"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.IMAGE_PADDING, "image", "padding"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.IMAGE_BORDER, "image", "border"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.IMAGE_BORDER_RADIUS, "image", "borderRadius"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.IMAGE_BORDER_COLOR, "image", "borderColor"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.IMAGE_BORDER_LINE_DASH, "image", "borderLineDash"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.IMAGE_BORDER_LINE_DASH_OFFSET, "image", "borderLineDashOffset"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.IMAGE_Z_INDEX, "image", "zIndex"), NodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.IMAGE_ALPHA, "image", "alpha"), NodeUIBindingMap._2x(PROPERTY_TYPE_ACCESSOR, "expanded", null, null, "checkBody"), NodeUIBindingMap._2x(PROPERTY_TYPE_ACCESSOR, "enableSubNetwork", null, null, "checkBody");
  var GroupUIBindingMap = new UIBindingMap();
  GroupUIBindingMap._2x(PROPERTY_TYPE_ACCESSOR, "groupType", null, null, "_6f"), GroupUIBindingMap._2x(PROPERTY_TYPE_ACCESSOR, "groupImage", null, null, "_6f"), GroupUIBindingMap._2x(PROPERTY_TYPE_ACCESSOR, "minSize", null, null, "_6f"), GroupUIBindingMap._2x(PROPERTY_TYPE_ACCESSOR, "padding", null, null, "_6f"), GroupUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.GROUP_BACKGROUND_COLOR, "shape", "fillColor"), GroupUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.GROUP_BACKGROUND_GRADIENT, "shape", "fillGradient"), GroupUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.GROUP_STROKE, "shape", "lineWidth"), GroupUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.GROUP_STROKE_STYLE, "shape", "strokeStyle"), GroupUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.GROUP_STROKE_LINE_DASH, "shape", "lineDash"), GroupUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.GROUP_STROKE_LINE_DASH_OFFSET, "shape", "lineDashOffset");
  var EdgeUIBindingMap = new UIBindingMap();
  EdgeUIBindingMap._2x(PROPERTY_TYPE_ACCESSOR, "from", "shape", null, "_56"), EdgeUIBindingMap._2x(PROPERTY_TYPE_ACCESSOR, "to", "shape", null, "_56"), EdgeUIBindingMap._2x(PROPERTY_TYPE_ACCESSOR, "edgeType", "shape", null, "_56"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.EDGE_WIDTH, "shape", "lineWidth"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.EDGE_COLOR, "shape", "strokeStyle"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_FROM, "shape", "fromArrow"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_TO, "shape", "toArrow"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.EDGE_FROM_AT_EDGE, null, "fromAtEdge", "_56"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.EDGE_TO_AT_EDGE, null, "toAtEdge", "_56"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.EDGE_OUTLINE, "shape", "outline"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.EDGE_OUTLINE_STYLE, "shape", "outlineStyle"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.EDGE_LINE_DASH, "shape", "lineDash"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.EDGE_LINE_DASH_OFFSET, "shape", "lineDashOffset"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.EDGE_CONTROL_POINT, "shape", null, "_56"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.EDGE_FROM_OFFSET, "shape", null, "_56"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.EDGE_TO_OFFSET, "shape", null, "_56"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LINE_CAP, "shape", "lineCap"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LINE_JOIN, "shape", "lineJoin"), EdgeUIBindingMap._2x(PROPERTY_TYPE_ACCESSOR, "path.segment", null, null, "_56", true), EdgeUIBindingMap._2x(PROPERTY_TYPE_ACCESSOR, "angle", null, null, "_56", true), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_FROM_SIZE, "shape", "fromArrowSize"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_FROM_OFFSET, "shape", "fromArrowOffset"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_FROM_STROKE, "shape", "fromArrowStroke"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_FROM_STROKE_STYLE, "shape", "fromArrowStrokeStyle"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_FROM_OUTLINE, "shape", "fromArrowOutline"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_FROM_OUTLINE_STYLE, "shape", "fromArrowOutlineStyle"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_FROM_FILL_COLOR, "shape", "fromArrowFillColor"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_FROM_FILL_GRADIENT, "shape", "fromArrowFillGradient"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_FROM_LINE_DASH, "shape", "fromArrowLineDash"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_FROM_LINE_DASH_OFFSET, "shape", "fromArrowLineDashOffset"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_FROM_LINE_JOIN, "shape", "fromArrowLineJoin"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_FROM_LINE_CAP, "shape", "fromArrowLineCap"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_TO_SIZE, "shape", "toArrowSize"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_TO_OFFSET, "shape", "toArrowOffset"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_TO_STROKE, "shape", "toArrowStroke"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_TO_STROKE_STYLE, "shape", "toArrowStrokeStyle"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_TO_OUTLINE, "shape", "toArrowOutline"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_TO_OUTLINE_STYLE, "shape", "toArrowOutlineStyle"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_TO_FILL_COLOR, "shape", "toArrowFillColor"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_TO_FILL_GRADIENT, "shape", "toArrowFillGradient"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_TO_LINE_DASH, "shape", "toArrowLineDash"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_TO_LINE_DASH_OFFSET, "shape", "toArrowLineDashOffset"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_TO_LINE_JOIN, "shape", "toArrowLineJoin"), EdgeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_TO_LINE_CAP, "shape", "toArrowLineCap");
  var EdgeBundleLabelBindingMap = new UIBindingMap();
  EdgeBundleLabelBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.EDGE_BUNDLE_LABEL_COLOR, "bundleLabel", "color"), EdgeBundleLabelBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.EDGE_BUNDLE_LABEL_POSITION, "bundleLabel", "position"), EdgeBundleLabelBindingMap._2x(
    PROPERTY_TYPE_STYLE,
    Styles.EDGE_BUNDLE_LABEL_ANCHOR_POSITION,
    "bundleLabel",
    "anchorPosition"
  ), EdgeBundleLabelBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.EDGE_BUNDLE_LABEL_FONT_SIZE, "bundleLabel", "fontSize"), EdgeBundleLabelBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.EDGE_BUNDLE_LABEL_ROTATABLE, "bundleLabel", "rotatable"), EdgeBundleLabelBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.EDGE_BUNDLE_LABEL_ROTATE, "bundleLabel", "rotate"), EdgeBundleLabelBindingMap._2x(
    PROPERTY_TYPE_STYLE,
    Styles.EDGE_BUNDLE_LABEL_FONT_FAMILY,
    "bundleLabel",
    "fontFamily"
  ), EdgeBundleLabelBindingMap._2x(
    PROPERTY_TYPE_STYLE,
    Styles.EDGE_BUNDLE_LABEL_FONT_STYLE,
    "bundleLabel",
    "fontStyle"
  ), EdgeBundleLabelBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.EDGE_BUNDLE_LABEL_PADDING, "bundleLabel", "padding"), EdgeBundleLabelBindingMap._2x(
    PROPERTY_TYPE_STYLE,
    Styles.EDGE_BUNDLE_LABEL_POINTER_WIDTH,
    "bundleLabel",
    "pointerWidth"
  ), EdgeBundleLabelBindingMap._2x(
    PROPERTY_TYPE_STYLE,
    Styles.EDGE_BUNDLE_LABEL_POINTER,
    "bundleLabel",
    "showPointer"
  ), EdgeBundleLabelBindingMap._2x(
    PROPERTY_TYPE_STYLE,
    Styles.EDGE_BUNDLE_LABEL_RADIUS,
    "bundleLabel",
    "borderRadius"
  ), EdgeBundleLabelBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.EDGE_BUNDLE_LABEL_OFFSET_X, "bundleLabel", "offsetX"), EdgeBundleLabelBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.EDGE_BUNDLE_LABEL_OFFSET_Y, "bundleLabel", "offsetY"), EdgeBundleLabelBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.EDGE_BUNDLE_LABEL_BORDER, "bundleLabel", "border"), EdgeBundleLabelBindingMap._2x(
    PROPERTY_TYPE_STYLE,
    Styles.EDGE_BUNDLE_LABEL_BORDER_STYLE,
    "bundleLabel",
    "borderColor"
  ), EdgeBundleLabelBindingMap._2x(
    PROPERTY_TYPE_STYLE,
    Styles.EDGE_BUNDLE_LABEL_BACKGROUND_COLOR,
    "bundleLabel",
    "backgroundColor"
  ), EdgeBundleLabelBindingMap._2x(
    PROPERTY_TYPE_STYLE,
    Styles.EDGE_BUNDLE_LABEL_BACKGROUND_GRADIENT,
    "bundleLabel",
    "backgroundGradient"
  );
  var ShapeNodeUIBindingMap = new UIBindingMap();
  ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_ACCESSOR, "location"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.BACKGROUND_COLOR, null, "backgroundColor"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.BACKGROUND_GRADIENT, null, "backgroundGradient"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.PADDING, null, "padding"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.BORDER, null, "border"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.BORDER_RADIUS, null, "borderRadius"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.BORDER_COLOR, null, "borderColor"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.BORDER_LINE_DASH, null, "borderLineDash"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.BORDER_LINE_DASH_OFFSET, null, "borderLineDashOffset"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_ACCESSOR, "rotate", null, "rotate"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_ACCESSOR, "path.segment", null, null, "invalidateShape"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_ACCESSOR, "path", "image", "data"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_ACCESSOR, "size", "image", "size"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.SHAPE_STROKE, "image", "lineWidth"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.SHAPE_STROKE_STYLE, "image", "strokeStyle"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.SHAPE_FILL_COLOR, "image", "fillColor"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.SHAPE_FILL_GRADIENT, "image", "fillGradient"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.SHAPE_OUTLINE, "image", "outline"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.SHAPE_OUTLINE_STYLE, "image", "outlineStyle"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.SHAPE_LINE_DASH, "image", "lineDash"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.SHAPE_LINE_DASH_OFFSET, "image", "lineDashOffset"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LINE_CAP, "image", "lineCap"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LINE_JOIN, "image", "lineJoin"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.LAYOUT_BY_PATH, "image", "layoutByPath"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.IMAGE_BACKGROUND_COLOR, "image", "backgroundColor"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.IMAGE_BACKGROUND_GRADIENT, "image", "backgroundGradient"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.IMAGE_PADDING, "image", "padding"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.IMAGE_BORDER, "image", "border"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.IMAGE_BORDER_RADIUS, "image", "borderRadius"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.IMAGE_BORDER_COLOR, "image", "borderColor"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.IMAGE_BORDER_LINE_DASH, "image", "borderLineDash"), ShapeNodeUIBindingMap._2x(
    PROPERTY_TYPE_STYLE,
    Styles.IMAGE_BORDER_LINE_DASH_OFFSET,
    "image",
    "borderLineDashOffset"
  ), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_FROM, "image", "fromArrow"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_FROM_SIZE, "image", "fromArrowSize"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_FROM_OFFSET, "image", "fromArrowOffset"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_FROM_STROKE, "image", "fromArrowStroke"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_FROM_STROKE_STYLE, "image", "fromArrowStrokeStyle"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_FROM_FILL_COLOR, "image", "fromArrowFillColor"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_FROM_FILL_GRADIENT, "image", "fromArrowFillGradient"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_FROM_LINE_DASH, "image", "fromArrowLineDash"), ShapeNodeUIBindingMap._2x(
    PROPERTY_TYPE_STYLE,
    Styles.ARROW_FROM_LINE_DASH_OFFSET,
    "image",
    "fromArrowLineDashOffset"
  ), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_FROM_LINE_JOIN, "image", "fromArrowLineJoin"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_FROM_LINE_CAP, "image", "fromArrowLineCap"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_TO_SIZE, "image", "toArrowSize"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_TO_OFFSET, "image", "toArrowOffset"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_TO, "image", "toArrow"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_TO_STROKE, "image", "toArrowStroke"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_TO_STROKE_STYLE, "image", "toArrowStrokeStyle"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_TO_FILL_COLOR, "image", "toArrowFillColor"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_TO_FILL_GRADIENT, "image", "toArrowFillGradient"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_TO_LINE_DASH, "image", "toArrowLineDash"), ShapeNodeUIBindingMap._2x(
    PROPERTY_TYPE_STYLE,
    Styles.ARROW_TO_LINE_DASH_OFFSET,
    "image",
    "toArrowLineDashOffset"
  ), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_TO_LINE_JOIN, "image", "toArrowLineJoin"), ShapeNodeUIBindingMap._2x(PROPERTY_TYPE_STYLE, Styles.ARROW_TO_LINE_CAP, "image", "toArrowLineCap");
  var CHILDREN_SORT_FUNCTION = function(t, e) {
    return t = t.zIndex, e = e.zIndex, t == e ? 0 : (t = t || 0, e = e || 0, t > e ? 1 : e > t ? -1 : void 0);
  }, ElementUI = function(t, e) {
    this.uiBounds = new Rect(), _3g(this, ElementUI, arguments), this.id = this.$data.id, this.graph = e, this._fv = [], this._mm4 = new UIBindingMap();
  };
  ElementUI.prototype = {
    syncSelection: false,
    graph: null,
    layoutByAnchorPoint: false,
    _mm4: null,
    _fv: null,
    addChild: function(t, e) {
      t._j2 = this, void 0 !== e ? _m9(this._fv, t, e) : this._fv.push(t), t._e0 && this._mki(t), this.invalidateChildrenIndex(), this.invalidateSize();
    },
    removeChild: function(t) {
      this._mm4.removeBinding(t), t._j2 = null, _jh(this._fv, t), this._j4 && this._j4.remove(t), this.invalidateSize();
    },
    getProperty: function(t, e) {
      return e == Consts.PROPERTY_TYPE_STYLE ? this.graph.getStyle(this.$data, t) : e == Consts.PROPERTY_TYPE_CLIENT ? this.$data.get(t) : this.$data[t];
    },
    getStyle: function(t) {
      return this.graph.getStyle(this.$data, t);
    },
    _$z: function(t, e, i) {
      var n = this._mm4.onBindingPropertyChange(this, t, e, i);
      return ElementUIBindingMap.onBindingPropertyChange(this, t, e, i) || n;
    },
    onPropertyChange: function(t) {
      if ("zIndex" == t.kind)
        return this.invalidateRender(), true;
      if ("ui" == t.type) {
        if ("invalidate" == t.kind)
          return this.invalidate(), true;
        var e = t.value;
        return e && e.ui ? ("add" == t.kind ? this._96(e) : "remove" == t.kind && this.removeChild(e.ui), true) : false;
      }
      return this._$z(t.kind, t.propertyType || PROPERTY_TYPE_ACCESSOR, t.value);
    },
    label: null,
    initLabel: function() {
      var t = new LabelUI();
      t.name = "label", this.addChild(t), this.label = t;
    },
    initialize: function() {
      this.initLabel(), this.$data._mm7 && this.$data._mm7.forEach(this._96, this), ElementUIBindingMap.initBindingProperties(this), this._mm4.initBindingProperties(this, false);
    },
    addBinding: function(t, e) {
      return e.property ? (e.target = t, void this._mm4._2h(e.property, e)) : false;
    },
    _fo: function(t, e) {
      var i = this.$data;
      if (!i._mm7)
        return false;
      var n = i._mm7.getById(t.id);
      if (!n || !n.bindingProperties)
        return false;
      var o = n.bindingProperties;
      if (_ig(o)) {
        var s = false;
        return _ic(
          o,
          function(t2) {
            return "data" == t2.bindingProperty ? (s = setElementProperty(i, e, t2.property, t2.propertyType), false) : void 0;
          },
          this
        ), s;
      }
      return "data" == o.bindingProperty ? setElementProperty(i, e, o.property, o.propertyType) : false;
    },
    _96: function(t) {
      var e = t.ui;
      if (e) {
        var i = t.bindingProperties;
        i && (Array.isArray(i) ? i.forEach(function(t2) {
          this.addBinding(e, t2);
        }, this) : this.addBinding(e, i)), this.addChild(e);
      }
    },
    validate: function() {
      return this._mkd || (this.initialize(), this._mkd = true), this.doValidate();
    },
    _$e: true,
    invalidateChildrenIndex: function() {
      this._$e = true;
    },
    doValidate: function() {
      if (this._1q && (this._1q = false, this.validateChildren() && (this.measure(), this.$invalidateSize = true), this._$e && (this._$e = false, isChrome ? this._fv = stableSortMerge(this._fv, CHILDREN_SORT_FUNCTION) : this._fv.sort(CHILDREN_SORT_FUNCTION))), UIValidateBoundsBackgroundBorderAndPointer.call(this) && (this.$invalidateRotate = true), this.$invalidateRotate) {
        UIValidateRotate.call(this), this.uiBounds.setByRect(this._fu);
        var t = this.$selectionBorder || 0, e = Math.max(this.$selectionBorder || 0, this.$shadowOffsetX || 0, this.$selectionShadowOffsetX || 0), i = Math.max(this.$shadowOffsetY || 0, this.$selectionShadowOffsetY || 0), n = Math.max(2 * t, this.$shadowBlur, this.$selectionShadowBlur);
        n += Defaults.UI_BOUNDS_GROW || 0;
        var o = n - e, s = n + e, r = n - i, a = n + i;
        return 0 > o && (o = 0), 0 > s && (s = 0), 0 > r && (r = 0), 0 > a && (a = 0), this.uiBounds.grow(r, o, a, s), this.onBoundsChanged && this.onBoundsChanged(), this.$invalidateBounds = true, true;
      }
    },
    validateChildren: function() {
      var t, e = this._moody, i = this.bodyChanged;
      e && (e.$renderColor = this.$renderColor, e.$renderColorBlendMode = this.$renderColorBlendMode, e.$shadowColor = this.$shadowColor, e.$shadowBlur = this.$shadowBlur, e.$shadowOffsetX = this.$shadowOffsetX, e.$shadowOffsetY = this.$shadowOffsetY), this.bodyChanged = false, e && e._1q && (i = e.validate() || i, e.$x = 0, e.$y = 0, e.$invalidateRotate && UIValidateRotate.call(e), t = true);
      for (var n = 0, o = this._fv.length; o > n; n++) {
        var s = this._fv[n];
        if (s != e) {
          var r = s._1q && s.validate();
          (r || i) && s._hw && UILayoutChild(s, e), !t && r && (t = true);
        }
      }
      return t;
    },
    measure: function() {
      this._j1.clear();
      for (var t, e, i = 0, n = this._fv.length; n > i; i++)
        t = this._fv[i], t._hw && (e = t._fu, e.width <= 0 || e.height <= 0 || this._j1.addRect(t.$x + e.x, t.$y + e.y, e.width, e.height));
    },
    _j4: null,
    _mki: function(t) {
      if (!this._j4) {
        if (!t.showOnTop)
          return;
        return this._j4 = new HashList(), this._j4.add(t);
      }
      return t.showOnTop ? this._j4.add(t) : this._j4.remove(t);
    },
    draw: function(t, e, i) {
      for (var n, o = 0, s = this._fv.length; s > o; o++)
        n = this._fv[o], n._hw && !n.showOnTop && n._j5(t, e, i, this);
    },
    _95: function(t, e) {
      if (!this._hw || !this._j4 || !this._j4.length)
        return false;
      t.save(), t.translate(this.$x, this.$y), this.$rotatable && this.$_hostRotate && t.rotate(this.$_hostRotate), (this.offsetX || this.offsetY) && t.translate(this.offsetX, this.offsetY), this.$rotate && t.rotate(this.$rotate), this.$layoutByAnchorPoint && this._mo0 && t.translate(-this._mo0.x, -this._mo0.y), this.shadowColor && (t.shadowColor = this.shadowColor, t.shadowBlur = this.shadowBlur * e, t.shadowOffsetX = this.shadowOffsetX * e, t.shadowOffsetY = this.shadowOffsetY * e), t.beginPath();
      for (var i, n = 0, o = this._fv.length; o > n; n++)
        i = this._fv[n], i._hw && i.showOnTop && i._j5(t, e, this.selected, this);
      t.restore();
    },
    _dv: function(t, e, i) {
      if (i) {
        if (!this._j1.intersectsRect(t - i, e - i, 2 * i, 2 * i))
          return false;
      } else if (!this._j1.intersectsPoint(t, e))
        return false;
      return this._5f(t, e, i);
    },
    _5f: function(t, e, i) {
      for (var n, o = this._fv.length - 1; o >= 0; o--)
        if (n = this._fv[o], n._hw && n._hq(t, e, i))
          return n;
      return false;
    },
    destroy: function() {
      this._i5ed = true;
      for (var t, e = this._fv.length - 1; e >= 0; e--)
        t = this._fv[e], t.destroy();
    }
  }, _jq(ElementUI, BaseUI), _4u(ElementUI.prototype, {
    renderColorBlendMode: {
      get: function() {
        return this.$renderColorBlendMode;
      },
      set: function(t) {
        this.$renderColorBlendMode = t, this._1q = true, this.body && (this.body.renderColorBlendMode = this.$renderColorBlendMode);
      }
    },
    renderColor: {
      get: function() {
        return this.$renderColor;
      },
      set: function(t) {
        this.$renderColor = t, this._1q = true, this.body && (this.body.renderColor = this.$renderColor);
      }
    },
    bodyBounds: {
      get: function() {
        if (this.$invalidateBounds) {
          this.$invalidateBounds = false;
          var t, e = this.body;
          t = e && e._hw && !this._$v() ? e._fu.clone() : this._fu.clone(), this.rotate && rotateRect(t, this.rotate, t), t.x += this.$x, t.y += this.$y, this._mml = t;
        }
        return this._mml;
      }
    },
    bounds: {
      get: function() {
        return new Rect(
          (this.$x || 0) + this.uiBounds.x,
          (this.$y || 0) + this.uiBounds.y,
          this.uiBounds.width,
          this.uiBounds.height
        );
      }
    },
    body: {
      get: function() {
        return this._moody;
      },
      set: function(t) {
        t && this._moody != t && (this._moody = t, this.bodyChanged = true, this.invalidateSize());
      }
    }
  }), Defaults.UI_BOUNDS_GROW = 1;
  var ImageUI = function() {
    _3g(this, ImageUI, arguments);
  };
  ImageUI.prototype = {
    strokeStyle: "#000",
    lineWidth: 0,
    fillColor: null,
    fillGradient: null,
    _j7: 1,
    _j0: 1,
    outline: 0,
    onDataChanged: function(t) {
      _hr(this, ImageUI, "onDataChanged", arguments), this._kf && this._86 && this._kf._7k(this._86, this), t && this._moz(t);
    },
    _moz: function(t) {
      this._kf = _he(t), this._kf.validate(), (this._kf._lg == IMAGE_TYPE_GIF || this._kf._7s()) && (this._86 || (this._86 = function() {
        this.invalidateData(), this._j2 && this._j2.graph && (this._j2.invalidateSize(), this._j2.graph.invalidate());
      }), this._kf._mo2(this._86, this));
    },
    _kf: null,
    initialize: function() {
      this._moz(this.$data);
    },
    _5e: function() {
      return this._kf && this._kf.draw;
    },
    _mka: function(t) {
      if (!t || t.width <= 0 || t.height <= 0 || !this.$size || !(this.size instanceof Object))
        return this._j7 = 1, void (this._j0 = 1);
      var e = this.size.width, i = this.size.height;
      if ((void 0 === e || null === e) && (e = -1), (void 0 === i || null === i) && (i = -1), 0 > e && 0 > i)
        return this._j7 = 1, void (this._j0 = 1);
      var n, o, s = t.width, r = t.height;
      e >= 0 && (n = e / s), i >= 0 && (o = i / r), 0 > e ? n = o : 0 > i && (o = n), this._j7 = n, this._j0 = o;
    },
    validateSize: function() {
      if (this.$invalidateScale) {
        this.$invalidateScale = false;
        {
          var t = this._originalBounds;
          this._j7, this._j0;
        }
        this._mka(t), this.setMeasuredBounds(t.width * this._j7, t.height * this._j0, t.x * this._j7, t.y * this._j0);
      }
    },
    measure: function() {
      var t = this._kf.getBounds(this.lineWidth + this.outline);
      return t ? (this.$invalidateScale = true, void (this._originalBounds = t.clone())) : void this._j1.set(0, 0, 0, 0);
    },
    onBoundsChanged: function() {
      this.$invalidateFillGradient = true;
    },
    _1u: function() {
      this.$invalidateFillGradient = false, this._fillGradient = this.fillGradient ? Gradient.prototype.generatorGradient.call(this.$fillGradient, this._8b) : null;
    },
    draw: function(t, e, i, n) {
      if (this._j7 && this._j0) {
        if (this.$invalidateFillGradient && this._1u(), t.save(), this._kf._lg == IMAGE_TYPE_SHAPE)
          return t.scale(this._j7, this._j0), this._kf._lc.draw(t, e, this, i, n || this), void t.restore();
        i && this._89(t, e, n), this._kf.draw(t, e, this, this._j7, this._j0), t.restore();
      }
    },
    _dv: function(t, e, i) {
      if (this._kf._hq) {
        t /= this._j7, e /= this._j0;
        var n = (this._j7 + this._j0) / 2;
        return n > 1 && (i /= n, i = 0 | i), this._kf._lc instanceof Path ? this._kf._lc._hq(t, e, i, true, this.$lineWidth, this.$fillColor || this.$fillGradient) : this._kf._hq(t, e, i);
      }
      return true;
    },
    $invalidateScale: true,
    $invalidateFillGradient: true
  }, _jq(ImageUI, BaseUI), defineUIProperties(ImageUI.prototype, {
    fillColor: {},
    size: { validateFlags: ["Size", "Scale"] },
    fillGradient: { validateFlags: ["FillGradient"] }
  }), _4u(ImageUI.prototype, {
    originalBounds: {
      get: function() {
        return this._originalBounds;
      }
    }
  }), Defaults.ALIGN_POSITION = Position.CENTER_MIDDLE;
  var LabelUI = function() {
    _3g(this, LabelUI, arguments), this.color = Defaults.LABEL_COLOR;
  };
  LabelUI.prototype = {
    color: Defaults.LABEL_COLOR,
    showPointer: true,
    fontSize: null,
    fontFamily: null,
    fontStyle: null,
    _gb: null,
    alignPosition: null,
    measure: function() {
      this.font;
      var t = _18(this.$data, this.$fontSize || Defaults.FONT_SIZE, this.$font);
      if (this._gb = t, this.$size) {
        var e = this.$size.width || 0, i = this.$size.height || 0;
        return this.setMeasuredBounds(e > t.width ? e : t.width, i > t.height ? i : t.height);
      }
      return this.setMeasuredBounds(t.width, t.height);
    },
    _dv: function(t, e, i) {
      return this.$data ? UIHitTest(t, e, i, this) : false;
    },
    draw: function(t, e, i, n) {
      i && this._89(t, e, n);
      var o = this.$fontSize || Defaults.FONT_SIZE;
      if (this.$rotatable && this.$_hostRotate) {
        var s = angleFormat(this.$_hostRotate);
        s > HALF_PI && 3 * HALF_PI > s && (t.translate(this._j1.width / 2, this._j1.height / 2), t.rotate(Math.PI), t.translate(-this._j1.width / 2, -this._j1.height / 2));
      }
      var r = this.alignPosition || Defaults.ALIGN_POSITION, a = r.horizontalPosition, h = r.verticalPosition, l = o * Defaults.LINE_HEIGHT, _ = l / 2;
      if (h != TOP && this._gb.height < this._j1.height) {
        var u = this._j1.height - this._gb.height;
        _ += h == MIDDLE ? u / 2 : u;
      }
      t.translate(0, _), t.font != this.$font && (t.font = this.$font), a == CENTER ? (t.textAlign = "center", t.translate(this._j1.width / 2, 0)) : a == RIGHT ? (t.textAlign = "right", t.translate(this._j1.width, 0)) : t.textAlign = "left", t.textBaseline = "middle", t.fillStyle = this.color;
      for (var d = 0, c = this.$data.split("\n"), f = 0, E = c.length; E > f; f++) {
        var g = c[f];
        t.fillText(g, 0, d), d += l;
      }
    },
    _5e: function() {
      return null != this.$data || this.$size;
    },
    $invalidateFont: true
  }, _jq(LabelUI, BaseUI), defineUIProperties(LabelUI.prototype, {
    size: { validateFlags: ["Data"] },
    fontStyle: { validateFlags: ["Data", "Font"] },
    fontSize: { validateFlags: ["Data", "Font"] },
    fontFamily: { validateFlags: ["Data", "Font"] }
  }), _4u(LabelUI.prototype, {
    font: {
      get: function() {
        return this.$invalidateFont && (this.$invalidateFont = false, this.$font = (this.$fontStyle || Defaults.FONT_STYLE) + " " + (this.$fontSize || Defaults.FONT_SIZE) + "px " + (this.$fontFamily || Defaults.FONT_FAMILY)), this.$font;
      }
    }
  });
  var ShapeUI = function(t) {
    t = t || new Path(), this.pathBounds = new Rect(), _3g(this, ShapeUI, [t]);
  };
  ShapeUI.prototype = {
    layoutByPath: true,
    layoutByAnchorPoint: false,
    measure: function() {
      this.$invalidateFromArrow = true, this.$invalidateToArrow = true, this.$data.getBounds(this.$lineWidth + this.$outline, this.pathBounds), this.setMeasuredBounds(this.pathBounds);
    },
    validateSize: function() {
      if (this.$invalidateFromArrow || this.$invalidateToArrow) {
        var t = this.pathBounds.clone();
        if (this.$invalidateFromArrow) {
          this.$invalidateFromArrow = false;
          var e = this.validateFromArrow();
          e && t.add(e);
        }
        if (this.$invalidateToArrow) {
          this.$invalidateToArrow = false;
          var e = this.validateToArrow();
          e && t.add(e);
        }
        this.setMeasuredBounds(t);
      }
    },
    validateFromArrow: function() {
      if (!this.$data._k4 || !this.$fromArrow)
        return void (this.$fromArrowShape = null);
      var t = this.$data, e = 0, i = 0, n = this.$fromArrowOffset;
      n && (isNaN(n) && (n.x || n.y) ? (e += n.x || 0, i += n.y || 0) : e += n || 0, e > 0 && 1 > e && (e *= t._k4)), this.fromArrowLocation = t.getLocation(e, i), this.fromArrowLocation.rotate = Math.PI + this.fromArrowLocation.rotate || 0, this.$fromArrowShape = createArrow(this.$fromArrow, this.$fromArrowSize);
      var o = this.$fromArrowShape.getBounds(this.fromArrowStyles.lineWidth + this.fromArrowStyles.outline);
      return this.fromArrowFillGradient instanceof Q2.Gradient ? this.fromArrowStyles._fillGradient = Gradient.prototype.generatorGradient.call(
        this.fromArrowFillGradient,
        o
      ) : this.fromArrowStyles && (this.fromArrowStyles._fillGradient = null), rotateRectAt(o, this.fromArrowLocation.rotate, o, o.right, o.cy), o.offset(this.fromArrowLocation.x, this.fromArrowLocation.y), o;
    },
    validateToArrow: function() {
      if (!this.$data._k4 || !this.$toArrow)
        return void (this.$toArrowShape = null);
      var t = this.$data, e = 0, i = 0, n = this.$toArrowOffset;
      n && (isNaN(n) && (n.x || n.y) ? (e += n.x || 0, i += n.y || 0) : e += n || 0), 0 > e && e > -1 && (e *= t._k4), e += t._k4, this.toArrowLocation = t.getLocation(e, i), this.$toArrowShape = createArrow(this.$toArrow, this.$toArrowSize);
      var o = this.$toArrowShape.getBounds(this.toArrowStyles.lineWidth + this.toArrowStyles.outline);
      return this.toArrowFillGradient instanceof Q2.Gradient ? this.toArrowStyles._fillGradient = Gradient.prototype.generatorGradient.call(this.toArrowFillGradient, o) : this.toArrowStyles && (this.toArrowStyles._fillGradient = null), rotateRectAt(o, this.toArrowLocation.rotate, o, o.right, o.cy), o.offset(this.toArrowLocation.x, this.toArrowLocation.y), o;
    },
    _2d: function(t) {
      var e = t ? "from" : "to", i = this[e + "ArrowStroke"];
      void 0 === i && (i = this.$lineWidth);
      var n = this[e + "ArrowStrokeStyle"];
      void 0 === n && (n = this.strokeStyle);
      var o = this[e + "ArrowStyles"];
      o || (this[e + "ArrowStyles"] = o = {}), o.lineWidth = i, o.strokeStyle = n, o.lineDash = this[e + "ArrowLineDash"], o.lineDashOffset = this[e + "ArrowLineDashOffset"], o.fillColor = this[e + "ArrowFillColor"], o.fillGradient = this[e + "ArrowFillGradient"], o.lineCap = this[e + "ArrowLineCap"], o.lineJoin = this[e + "ArrowLineJoin"], o.outline = this[e + "ArrowOutline"] || 0, o.outlineStyle = this[e + "ArrowOutlineStyle"];
    },
    doValidate: function() {
      return this.$fromArrow && this._2d(true), this.$toArrow && this._2d(false), _hr(this, ShapeUI, "doValidate");
    },
    drawArrow: function(t, e, i, n) {
      if (this.$fromArrow && this.$fromArrowShape) {
        t.save();
        var o = this.fromArrowLocation, s = o.x, r = o.y, a = o.rotate;
        t.translate(s, r), a && t.rotate(a), this.$fromArrowShape.draw(t, e, this.fromArrowStyles, i, n), t.restore();
      }
      if (this.$toArrow && this.$toArrowShape) {
        t.save();
        var o = this.toArrowLocation, s = o.x, r = o.y, a = o.rotate;
        t.translate(s, r), a && t.rotate(a), this.$toArrowShape.draw(t, e, this.toArrowStyles, i, n), t.restore();
      }
    },
    outlineStyle: null,
    outline: 0,
    onBoundsChanged: function() {
      this.$invalidateFillGradient = true;
    },
    _1u: function() {
      this.$invalidateFillGradient = false, this._fillGradient = this.$fillGradient ? Gradient.prototype.generatorGradient.call(this.$fillGradient, this._8b) : null;
    },
    draw: function(t, e, i, n) {
      this.$invalidateFillGradient && this._1u(), this.$data.draw(t, e, this, i, n), this.drawArrow(t, e, i, n);
    },
    _dv: function(t, e, i) {
      if (this.$data._hq(t, e, i, true, this.$lineWidth + this.$outline, this.$fillColor || this.$fillGradient))
        return true;
      if (this.$toArrow && this.$toArrowShape) {
        var n = t - this.toArrowLocation.x, o = e - this.toArrowLocation.y;
        if (this.toArrowLocation.rotate) {
          var s = rotatePoint(n, o, -this.toArrowLocation.rotate);
          n = s.x, o = s.y;
        }
        var r = this.toArrowStyles.fillColor || this.toArrowStyles.fillGradient;
        if (this.$toArrowShape._hq(n, o, i, true, this.toArrowStyles.lineWidth, r))
          return true;
      }
      if (this.$fromArrow && this.$fromArrowShape) {
        var n = t - this.fromArrowLocation.x, o = e - this.fromArrowLocation.y;
        if (this.fromArrowLocation.rotate) {
          var s = rotatePoint(n, o, -this.fromArrowLocation.rotate);
          n = s.x, o = s.y;
        }
        var r = this.fromArrowStyles.fillColor || this.fromArrowStyles.fillGradient;
        if (this.$fromArrowShape._hq(n, o, i, true, this.fromArrowStyles.lineWidth, r))
          return true;
      }
      return false;
    },
    $fromArrowOutline: 0,
    $toArrowOutline: 0,
    $invalidateFillGradient: true,
    $invalidateFromArrow: true,
    $invalidateToArrow: true
  }, _jq(ShapeUI, BaseUI), defineUIProperties(ShapeUI.prototype, {
    fillColor: {},
    fillGradient: { validateFlags: ["FillGradient"] },
    fromArrowOffset: { validateFlags: ["FromArrow", "Size"] },
    fromArrowSize: { validateFlags: ["FromArrow", "Size"] },
    fromArrow: { validateFlags: ["FromArrow", "Size"] },
    fromArrowOutline: { validateFlags: ["FromArrow", "Size"] },
    fromArrowStroke: { validateFlags: ["FromArrow", "Size"] },
    toArrowOffset: { validateFlags: ["ToArrow", "Size"] },
    toArrowSize: { validateFlags: ["ToArrow", "Size"] },
    toArrow: { validateFlags: ["ToArrow", "Size"] },
    toArrowOutline: { validateFlags: ["ToArrow", "Size"] },
    toArrowStroke: { validateFlags: ["ToArrow", "Size"] },
    outline: { value: 0, validateFlags: ["Data"] }
  }), _4u(ShapeUI.prototype, {
    length: {
      get: function() {
        return this.data.length;
      }
    }
  }), EdgeUI.prototype = {
    shape: null,
    path: null,
    initialize: function() {
      _hr(this, EdgeUI, "initialize"), this.path = new Path(), this.path._di = false, this.shape = new ShapeUI(this.path), this.addChild(this.shape, 0), this._moody = this.shape, EdgeUIBindingMap.initBindingProperties(this);
    },
    _24: true,
    _5z: null,
    _$v: function() {
      return false;
    },
    _4e: function() {
      return false;
    },
    validatePoints: function() {
      this.shape.invalidateData();
      var t = this.$data, e = this.path;
      e.clear();
      var i = t.fromAgent, n = t.toAgent;
      i && n && drawEdge(this, t, e, i, n);
    },
    drawLoopedEdge: function(t, e, i, n) {
      drawLoopedEdge(this, n, t);
    },
    drawEdge: function(t, e, i, n, o, s) {
      var r = this.getStyle(Styles.EDGE_FROM_OFFSET), a = this.getStyle(Styles.EDGE_TO_OFFSET);
      if (r && (o.x += r.x || 0, o.y += r.y || 0), a && (s.x += a.x || 0, s.y += a.y || 0), n == Consts.EDGE_TYPE_ZIGZAG) {
        var h = o.center, l = s.center, _ = (h.x + l.x) / 2, u = (h.y + l.y) / 2, d = h.x - l.x, c = h.y - l.y, f = Math.sqrt(d * d + c * c), E = Math.atan2(c, d);
        E += Math.PI / 6, f *= 0.04, f > 30 && (f = 30);
        var g = Math.cos(E) * f, p = Math.sin(E) * f;
        return t.lineTo(_ - p, u + g), void t.lineTo(_ + p, u - g);
      }
      var v = calculateEdgeSegments(this, this.data, o, s, e, i, o.center, s.center);
      v && (t._fe = v);
    },
    _2b: function() {
      if (!this.$data.isBundleEnabled())
        return null;
      var t = this.graph._94._91(this.$data);
      if (!t || !t.canBind(this.graph) || !t._hk)
        return null;
      var e = t.getYOffset(this);
      return t.isPositiveOrder(this.$data) || (e = -e), e;
    },
    checkBundleLabel: function() {
      var t = this.getBundleLabel();
      return t ? (this.bundleLabel || this.createBundleLabel(), this.bundleLabel._hw = true, void (this.bundleLabel.data = t)) : void (this.bundleLabel && (this.bundleLabel._hw = false, this.bundleLabel.data = null));
    },
    createBundleLabel: function() {
      var t = new LabelUI();
      t.editable = false, this.bundleLabel = t, this.addChild(this.bundleLabel), EdgeBundleLabelBindingMap.initBindingProperties(this);
    },
    getBundleLabel: function() {
      return this.graph.getBundleLabel(this.data);
    },
    doValidate: function() {
      return this._24 && (this._24 = false, this.validatePoints()), this.checkBundleLabel(), _hr(this, EdgeUI, "doValidate");
    },
    _56: function() {
      this._24 = true, this.invalidateSize();
    },
    _$z: function(t, e, i) {
      var n = this._mm4.onBindingPropertyChange(this, t, e, i);
      return n = ElementUIBindingMap.onBindingPropertyChange(this, t, e, i) || n, this.bundleLabel && this.bundleLabel.$data && (n = EdgeBundleLabelBindingMap.onBindingPropertyChange(this, t, e, i) || n), EdgeUIBindingMap.onBindingPropertyChange(this, t, e, i) || n;
    }
  }, _jq(EdgeUI, ElementUI), EdgeUI.drawReferenceLine = function(t, e, i, n) {
    if (t.moveTo(e.x, e.y), !n || n == Consts.EDGE_TYPE_DEFAULT)
      return void t.lineTo(i.x, i.y);
    if (n == Consts.EDGE_TYPE_VERTICAL_HORIZONTAL)
      t.lineTo(e.x, i.y);
    else if (n == Consts.EDGE_TYPE_HORIZONTAL_VERTICAL)
      t.lineTo(i.x, e.y);
    else if (0 == n.indexOf(Consts.EDGE_TYPE_ORTHOGONAL)) {
      var o;
      o = n == Consts.EDGE_TYPE_ORTHOGONAL_HORIZONTAL ? true : n == Consts.EDGE_TYPE_ORTHOGONAL_VERTICAL ? false : Math.abs(e.x - i.x) > Math.abs(e.y - i.y);
      var s = (e.x + i.x) / 2, r = (e.y + i.y) / 2;
      o ? (t.lineTo(s, e.y), t.lineTo(s, i.y)) : (t.lineTo(e.x, r), t.lineTo(i.x, r));
    }
    t.lineTo(i.x, i.y);
  }, _4u(EdgeUI.prototype, {
    length: {
      get: function() {
        return this.path ? this.path.length : 0;
      }
    }
  }), EdgeUI.prototype.addPoint = function(t, e, i) {
    var n = _7y(this.path, t, e, i);
    if (n && n.length > 2) {
      var o = this.data, s = n[n.length - 1];
      o.pathSegments = s.type == LINE_TO ? n.splice(1, n.length - 2) : n.splice(1, n.length - 1);
    }
  }, NodeUI.prototype = {
    _3c: null,
    image: null,
    initialize: function() {
      _hr(this, NodeUI, "initialize"), this._mo8(), NodeUIBindingMap.initBindingProperties(this);
    },
    _moz: function() {
      this.data.image ? this.image && (this.body = this.image) : this.label && (this.body = this.label);
    },
    _mo8: function() {
      this.image = new ImageUI(), this.addChild(this.image, 0), this._moz();
    },
    doValidate: function() {
      this.body && (this instanceof GroupUI && !this.$data.groupImage && this._65() ? this.body.$layoutByAnchorPoint = false : (this.body.$layoutByAnchorPoint = null != this._3c, this.body.anchorPosition = this._3c));
      var t = this.$data.$location, e = 0, i = 0;
      t && (e = t.x, i = t.y);
      var n = this.$x != e || this.$y != i;
      return n && (this.$invalidateBounds = true), this.$x = e, this.$y = i, ElementUI.prototype.doValidate.call(this) || n;
    },
    _$z: function(t, e, i) {
      var n = this._mm4.onBindingPropertyChange(this, t, e, i);
      return n = ElementUIBindingMap.onBindingPropertyChange(this, t, e, i) || n, NodeUIBindingMap.onBindingPropertyChange(this, t, e, i) || n;
    }
  }, _jq(NodeUI, ElementUI);
  var UI_SORT_FUNCTION = function(t, e) {
    return t = t.$data.zIndex || 0, e = e.$data.zIndex || 0, t - e;
  }, CANVAS_STYLES = {
    position: "absolute",
    "user-select": "none",
    "transform-origin": "0 0",
    "-webkit-tap-highlight-color": "rgba(0,0,0,0)"
  };
  css_m9Rule(".Q-Graph", "text-align: left; outline: none;-webkit-tap-highlight-color:rgba(0,0,0,0);user-select: none"), BaseCanvas.prototype = {
    _kn: 1,
    _d3: null,
    _8c: null,
    _8p: null,
    _$j: true,
    _m6: null,
    _m7: null,
    _jn: null,
    _mo4: null,
    _6k: false,
    _mkd: false,
    _jp: null,
    _4o: function(t, e) {
      for (var i = this._d3, n = 0, o = i.length; o > n; n++)
        if (t.call(e, i[n]) === false)
          return false;
    },
    _ei: function(t, e) {
      this._m6.forEach(t, e);
    },
    _11: function(t, e) {
      for (var i = this._d3, n = i.length - 1; n >= 0; n--)
        if (t.call(e, i[n]) === false)
          return false;
    },
    _4k: function(t, e) {
      this._m6.forEachReverse(t, e);
    },
    _3n: function(t, e) {
      this._7w && this._7w._3n && this._7w._3n(t, e);
    },
    _mmu: function() {
      css_mmss(this._m7, {
        overflow: "hidden",
        padding: "0"
      }), this._jp._4c(), this._l6 && this._l6.originAtCenter ? this._jp._em(0, 0) : this._jp._2n = true;
    },
    _4h: function() {
      return this._$j && (this._$j = false, this._1w()), this._8p;
    },
    _4a: function() {
      return this._jp._1c ? false : (this._jp._1c = true, void this._mmc());
    },
    _mmc: function() {
      this._6k || (this._6k = true, _dl(this._fz.bind(this)));
    },
    _mog: function() {
      var t = !this._mkd || 0 == this._m6.length;
      this._mkd || (this._mkd = true, this._mmu()), this._moi(t);
      var e = this._jn.g;
      if (this._m6.isEmpty())
        return e._kt(), this._topCanvas._j5(), this._6k = false, this._jp._jl(this, true), void this._4h();
      if (this._jp._jl(this, this._l6.fullRefresh || this._mo4._lm), this._js) {
        var i = this._l5;
        e.canvas.ratio && (i *= e.canvas.ratio), this._js(e, i, t);
      }
      this._mo4._kt(), this._jp._76(), this._topCanvas._j5(), this._6k = false;
    },
    _fz: function() {
      this._6k && (this._i5ed || (this._mkd && this._l6 && this._l6._$t && (this._l6._$t = false, this._l6.forEach(function(t) {
        t.invalidateVisibility(true);
      })), this._mog(), this._2r()));
    },
    _gl: null,
    _1o: function(t, e, i, n, o) {
      if (!i || !n)
        return void this._6d();
      var s = this._d3, r = this._8c;
      this._6d(), this._gl.length = 0;
      var a, h = {}, l = this._mo4;
      o = o || l._lm;
      for (var _, u, d, c, f, E, g = this._m6._jf, p = t + i, v = e + n, T = 0, m = g.length; m > T; T++)
        if (E = g[T], f = E.__oldBounds, E.__oldBounds = null, E._hw)
          if (c = E.__j1Changed, E.__j1Changed = false, _ = E.uiBounds, u = _.x + E.$x, d = _.y + E.$y, p > u && v > d && u + _.width > t && d + _.height > e) {
            if (a = E.$data.zIndex, a in h || (h[a] = true, this._gl.push(a || 0)), s.push(E), this._8c[E.id] = E, o)
              continue;
            f && (l._lo(f.x, f.y, f.width, f.height), o = l._lm), c && (l._lo(u, d, _.width, _.height), o = l._lm);
          } else
            !o && r[E.id] && f && (l._lo(f.x, f.y, f.width, f.height), o = l._lm);
        else
          !o && f && (l._lo(f.x, f.y, f.width, f.height), o = l._lm);
    },
    _mmy: function(t) {
      var e = t.$data.__hwChanged;
      return t.$data.__hwChanged = false, t._1q || t.$data._6k ? (t.$data._6k = false, t._mkd && (t.__oldBounds = {
        x: t.$x + t.uiBounds.x,
        y: t.$y + t.uiBounds.y,
        width: t.uiBounds.width,
        height: t.uiBounds.height
      }), t.__j1Changed = t.validate(), e || t.__j1Changed) : (e && t._mkd && (t.__oldBounds = {
        x: t.$x + t.uiBounds.x,
        y: t.$y + t.uiBounds.y,
        width: t.uiBounds.width,
        height: t.uiBounds.height
      }), e);
    },
    _js: function(t, e, i, n) {
      n = n || this._jp._78;
      var o = n.x, s = n.y, r = n.width, a = n.height;
      this._1o(o, s, r, a, i), this._4h(), this._gl.length && (isChrome ? (this._gl.sort(), this._d3 = stableSortMerge(this._d3, UI_SORT_FUNCTION)) : this._d3.sort(UI_SORT_FUNCTION));
      try {
        this._ij(t, e);
      } catch (h) {
        Q2.error(h), this._l8Flag || (this._l8Flag = true, this._l6.invalidate());
      }
    },
    _ij: function(t, e) {
      t.save(), this._mo4._kb(t, this._jn, this._jp), this._jp._mkv(t);
      for (var i, n, o = this._d3, s = [], r = 0, a = o.length; a > r; r++)
        i = o[r], n = i.uiBounds, (this._mo4._lm || this._mo4._fc(n.x + i.$x, n.y + i.$y, n.width, n.height)) && (i._j5(t, e), i._j4 && i._j4.length && s.push(i));
      if (s.length)
        for (r = 0, a = s.length; a > r; r++)
          s[r]._95(t, e);
      t.restore();
    },
    _h7: function(t, e, i) {
      t.save(), t.translate(-i.x * e, -i.y * e), t.scale(e, e);
      var n, o, s = this._m6._jf.slice();
      this._gl.length && (isChrome ? (this._gl.sort(), s = stableSortMerge(s, UI_SORT_FUNCTION)) : s.sort(UI_SORT_FUNCTION));
      for (var r = [], a = 0, h = s.length; h > a; a++)
        n = s[a], n._hw && (o = n.uiBounds, i.intersectsRect(o.x + n.$x, o.y + n.$y, o.width, o.height) && (n._j5(t, e), n._j4 && n._j4.length && r.push(n)));
      if (r.length)
        for (a = 0, h = r.length; h > a; a++)
          r[a]._95(t, e);
      t.restore();
    },
    _1a: function() {
    },
    _1w: function() {
      for (var t, e, i = this._m6._jf, n = new Rect(), o = i.length - 1; o >= 0; o--)
        t = i[o], t._hw && (e = t.uiBounds, n.addRect(t.$x + e.x, t.$y + e.y, e.width, e.height));
      var s = this._8p;
      this._8p = n, n.equals(s) || this._1a(s, n);
    },
    _moi: function() {
      for (var t, e = this._m6._jf, i = e.length - 1; i >= 0; i--)
        t = e[i], this._mmy(t) && !this._$j && (this._$j = true);
    },
    _21: function(t, e, i, n) {
      this._mo4._lm || (t && (t > 0 && this._mo4._lo(this._jp._78.x, this._jp._78.y, t / this._jp._l5, this._jp._9z / this._jp._l5), i + t < this._jp._moj && this._mo4._lo(
        this._jp._78.x + (i + t) / this._jp._l5,
        this._jp._78.y,
        (this._jp._moj - i - t) / this._jp._l5,
        this._jp._9z / this._jp._l5
      )), e && (e > 0 && this._mo4._lo(this._jp._78.x, this._jp._78.y, this._jp._moj / this._jp._l5, e / this._jp._l5), n + e < this._jp._9z && this._mo4._lo(
        this._jp._78.x,
        this._jp._78.y + (n + e) / this._jp._l5,
        this._jp._moj / this._jp._l5,
        (this._jp._9z - n - e) / this._jp._l5
      )));
    },
    _el: function(t, e) {
      this._mmc(), this._jp._el(t, e);
    },
    _mo9: function(t, e, i) {
      this._mmc(), this._jp._mo9(t, e, i);
    },
    _8v: function() {
    },
    _gm: function(t, e, i) {
      return this._mkd ? void (this._jp._gm(t, e, i) !== false && this._mmc()) : void (this._jp._l5 = t);
    },
    _26: function() {
      var t = this._4h();
      if (!t.isEmpty()) {
        var e = this._jp._moj / t.width, i = this._jp._9z / t.height, n = Math.min(e, i);
        return n = Math.max(this._gz, Math.min(this._gy, n)), { scale: n, cx: t.cx, cy: t.cy };
      }
    },
    _jt: function(t, e, i) {
      return this._jp._jt(t, e, i) === false ? false : void this._mmc();
    },
    _i6: function(t, e) {
      return this._jp._i6(t, e) === false ? false : void this._mmc();
    },
    _jv: function(t, e) {
      return this._jp._jv(t, e) === false ? false : void this._mmc();
    },
    _75: function() {
      return this._jp._75Flag ? false : (this._jp._75Flag = true, void this._mmc());
    },
    _6d: function() {
      this._d3.length = 0, this._8c = {};
    },
    _kr: function() {
      this._kt();
    },
    _i5: function() {
      this._kt(), this._i5ed = true, this._6k = false, this._topCanvas.clear(), this._8m.length = 0, this._7w && (this._7w._i5(), delete this._7w);
    },
    _kt: function() {
      this._mkd = false, this._$j = true, this._m6.clear(), this._6d(), this._mo4._kt(), this._mmc();
    },
    _8i: function(t, e, i, n) {
      var o = this._l5;
      return new Rect(this._mm0(t), this._mmn(e), i / o, n / o);
    },
    _mm0: function(t) {
      return this._jp._mm0(t);
    },
    _mmn: function(t) {
      return this._jp._mmn(t);
    },
    _ed: function(t) {
      return this._jp._ed(t);
    },
    _eb: function(t) {
      return this._jp._eb(t);
    },
    _ky: function(t) {
      return this._m6.getById(t.id || t);
    },
    _$h: function(t) {
      var e = this._88(t);
      return e.x = this._mm0(e.x), e.y = this._mmn(e.y), e;
    },
    _g0: function(t, e) {
      return { x: this._ed(t), y: this._eb(e) };
    },
    _e8: function(t, e) {
      return { x: this._mm0(t), y: this._mmn(e) };
    },
    _88: function(t) {
      return _88(t, this._m7);
    },
    _3w: function(t) {
      if (void 0 !== t.uiId)
        return t.uiId ? this._m6.getById(t.uiId) : null;
      var e = Math.round(Defaults.SELECTION_TOLERANCE / this._jp._l5) || 0.1;
      this._jn.ratio && (e *= this._jn.ratio);
      for (var i, n = this._$h(t), o = n.x, s = n.y, r = this._d3, a = r.length - 1; a >= 0; a--)
        if (i = r[a], i._hw && i._hq(o, s, e))
          return t.uiId = i.id, i;
      t.uiId = null;
    },
    _hq: function(t) {
      var e = this._3w(t);
      if (!e)
        return null;
      var i = Math.round(Defaults.SELECTION_TOLERANCE / this._jp._l5) || 1;
      this._jn.ratio && (i *= this._jn.ratio);
      var n = this._$h(t), o = n.x, s = n.y, r = e._hq(o, s, i, true);
      return r instanceof BaseUI ? r : e;
    },
    _mkk: function(t) {
      void 0 !== t.id && (t = t.id);
      var e = this._m6.getById(t);
      return e ? new Rect((e.$x || 0) + e.uiBounds.x, (e.$y || 0) + e.uiBounds.y, e.uiBounds.width, e.uiBounds.height) : void 0;
    },
    _8m: null,
    _2r: function() {
      if (!this._8m.length)
        return false;
      var t = this._8m;
      this._8m = [], _ic(
        t,
        function(t2) {
          try {
            t2.delay ? _fa(t2.call, t2.scope, t2.delay) : t2.call.call(t2.scope);
          } catch (e) {
          }
        },
        this
      ), this._fz();
    },
    callLater: function(t, e, i) {
      e && _gd(e) && (i = e, e = null);
      var n = this._8m;
      n.push({ call: t, scope: e, delay: i }), this._6k || this._2r();
    }
  }, _4u(BaseCanvas.prototype, {
    _78: {
      get: function() {
        return this._jp._78;
      }
    },
    _ek: {
      get: function() {
        return this._jp._ek;
      },
      set: function(t) {
        return !t || 1 > t ? false : void (this._jp._ek = t);
      }
    },
    _gy: {
      get: function() {
        return this._jp._gy;
      },
      set: function(t) {
        return !t || 1 > t ? false : void (this._jp._gy = t);
      }
    },
    _gz: {
      get: function() {
        return this._jp._gz;
      },
      set: function(t) {
        return !t || 0 >= t ? false : void (this._jp._gz = t);
      }
    },
    _l5: {
      get: function() {
        return this._jp._hm();
      },
      set: function(t) {
        this._gm(t);
      }
    },
    _me: {
      get: function() {
        return this._jp._kx();
      }
    },
    _mc: {
      get: function() {
        return this._jp._kv();
      }
    }
  }), CanvasMatrix.prototype = {
    _d5: null,
    _moj: 0,
    _9z: 0,
    _2n: true,
    _1c: true,
    _jp: null,
    _78: null,
    _ek: 1.3,
    _gy: 10,
    _gz: 0.1,
    _l5: 1,
    _me: 0,
    _mc: 0,
    _76: function() {
      this._jp._h3(this._d5._jn);
    },
    _4c: function() {
      return this._1c = false, this._5k(this._d5._m7.clientWidth, this._d5._m7.clientHeight);
    },
    _5k: function(t, e) {
      return this._moj == t && this._9z == e ? false : (this._moj = t, this._9z = e, void this._d5._3n(t, e));
    },
    _em: function(t, e, i) {
      i && (i = Math.max(this._gz, Math.min(this._gy, i)), this._l5 = i), this._me = this._moj / 2 - t * this._l5, this._mc = this._9z / 2 - e * this._l5, this._2n = true;
    },
    _3i: function(t, e) {
      t = t || this._moj, e = e || this._9z, this._78.set(-this._me / this._l5, -this._mc / this._l5, t / this._l5, e / this._l5);
    },
    _jt: function(t, e, i) {
      return this._gm(this._5c() * t, e, i);
    },
    _jv: function(t, e) {
      return this._gm(this._5c() * this._ek, t, e);
    },
    _i6: function(t, e) {
      return this._gm(this._5c() / this._ek, t, e);
    },
    _gm: function(t, e, i) {
      this._75Flag = false, t = Math.max(this._gz, Math.min(this._gy, t));
      var n = this._5c();
      return void 0 === e && (e = this._moj / 2, i = this._9z / 2), t != n && (this._2n = true, this._d5._8v(n, t)), this._jp._gm(t / this._l5, e, i);
    },
    _5c: function() {
      return this._l5 * this._jp._l5;
    },
    _el: function(t, e) {
      this._jp._el(t, e);
    },
    _mo9: function(t, e, i) {
      var n = this._kx(), o = this._kv(), s = this._hm();
      return i && (i = Math.max(this._gz, Math.min(this._gy, i))), t != n || e != o || i && i != s ? (i && i != s ? (i /= this._l5, this._2n = true) : i = this._jp._l5, t -= n * i, e -= o * i, this._jp._9j(i, t, e), this._d5._35(n, o, s, arguments[0], arguments[1], arguments[2]), s != arguments[2] && this._d5._8v(s, arguments[2]), true) : false;
    },
    _75: function() {
      this._75Flag = true;
    },
    _hm: function() {
      return this._l5 * this._jp._l5;
    },
    _kx: function() {
      return this._me * this._jp._l5 + this._jp._me;
    },
    _kv: function() {
      return this._mc * this._jp._l5 + this._jp._mc;
    },
    _jl: function(t, e) {
      this._1c && this._4c(), isTouchSupport && isAndroid && (e = true);
      var i = t._jn, n = i.ratio || 1, o = i.clientWidth, s = i.clientHeight, r = this._moj != o, a = this._9z != s, h = r || a;
      h && t._topCanvas._jn.setSize(this._moj, this._9z);
      var l = this._me, _ = this._mc, u = this._l5;
      if (this._75Flag) {
        this._75Flag = false;
        var d = t._26();
        d && this._em(d.cx, d.cy, d.scale);
      }
      if (this._2n || e || h)
        return this._2n = false, this._l5 *= this._jp._l5, this._me = this._me * this._jp._l5 + this._jp._me, this._mc = this._mc * this._jp._l5 + this._jp._mc, this._jp._l5 = 1, this._jp._me = 0, this._jp._mc = 0, h && i.setSize(this._moj, this._9z), t._mo4._lm = true, this._3i(this._moj, this._9z), void ((l != this._me || _ != this._mc || u != this._l5) && (t._35(l, _, u, this._me, this._mc, this._l5), u != this._l5 && t._8v(u, this._l5)));
      var c = this._jp._me, f = this._jp._mc;
      if (c || f) {
        this._jp._me = 0, this._jp._mc = 0, this._me += c, this._mc += f, this._3i(o, s);
        var E = i.g;
        this._eu(E, i, c * n, f * n), t._21(c, f, o, s), t._35(l, _, u, this._me, this._mc, this._l5);
      }
    },
    _eu: function(t, e, i, n) {
      var o = this._moackCanvas;
      o || (o = this._moackCanvas = document2.createElement("canvas"), o.g = o.getContext("2d")), o.width = e.width, o.height = e.height, o.g.drawImage(e, i, n), t._kt(), t.drawImage(o, 0, 0);
    },
    _mkv: function(t) {
      1 != t.canvas.ratio && t.scale(t.canvas.ratio, t.canvas.ratio), t.translate(this._me, this._mc), t.scale(this._l5, this._l5);
    },
    _mm0: function(t) {
      return (t - this._me) / this._l5;
    },
    _mmn: function(t) {
      return (t - this._mc) / this._l5;
    },
    _ed: function(t) {
      return t * this._l5 + this._me;
    },
    _eb: function(t) {
      return t * this._l5 + this._mc;
    }
  };
  var ClipSupport = function() {
    this._hc = [], this._j1 = new Rect();
  };
  ClipSupport.prototype = {
    _h8: 20,
    _hc: null,
    _lm: false,
    _j1: null,
    _kt: function() {
      this._lm = false, this._hc.length = 0, this._j1.clear();
    },
    _iq: function() {
      return this._lm || this._hc.length > 0;
    },
    _lo: function(t, e, i, n) {
      this._lm || 0 >= i || 0 >= n || (this._hc.push({
        x: t,
        y: e,
        width: i,
        height: n
      }), this._j1.addRect(t, e, i, n));
    },
    _hd: function(t) {
      this._lo(t.x, t.y, t.width, t.height);
    },
    _fc: function(t, e, i, n) {
      if (!this._j1.intersectsRect(t, e, i, n))
        return false;
      if (withoutClip || this._hc.length >= this._h8)
        return true;
      for (var o, s = 0, r = this._hc.length; r > s; s++)
        if (o = this._hc[s], intersectsRect(t, e, i, n, o.x, o.y, o.width, o.height))
          return true;
      return false;
    },
    _kb: function(t, e, i) {
      if (this._lm)
        return t.setTransform(1, 0, 0, 1, 0, 0), void t.clearRect(0, 0, e.width, e.height);
      t.beginPath();
      var n, o, s, r, a = i._l5, h = this._hc, l = e.ratio || 1;
      if (withoutClip || h.length >= this._h8)
        return n = i._ed(this._j1.x) * l, o = i._eb(this._j1.y) * l, s = _g1(n + this._j1.width * a * l) - (n = _mm3(n)), r = _g1(o + this._j1.height * a * l) - (o = _mm3(o)), t.clearRect(n, o, s, r), t.rect(n, o, s, r), void t.clip();
      for (var _, u = 0, d = h.length; d > u; u++)
        _ = h[u], n = i._ed(_.x) * l, o = i._eb(_.y) * l, s = _g1(n + _.width * a * l) - (n = _mm3(n)), r = _g1(o + _.height * a * l) - (o = _mm3(o)), t.clearRect(n, o, s, r), t.rect(n, o, s, r);
      t.clip();
    }
  };
  var DefaultStyles = {};
  DefaultStyles[Styles.SELECTION_COLOR] = Defaults.SELECTION_COLOR, DefaultStyles[Styles.SELECTION_BORDER] = Defaults.SELECTION_BORDER, DefaultStyles[Styles.SELECTION_SHADOW_BLUR] = Defaults.SELECTION_SHADOW_BLUR, DefaultStyles[Styles.SELECTION_TYPE] = Consts.SELECTION_TYPE_SHADOW, DefaultStyles[Styles.SELECTION_SHADOW_OFFSET_X] = 2, DefaultStyles[Styles.SELECTION_SHADOW_OFFSET_Y] = 2, DefaultStyles[Styles.LABEL_COLOR] = Defaults.LABEL_COLOR, DefaultStyles[Styles.LABEL_POSITION] = Position.CENTER_BOTTOM, DefaultStyles[Styles.LABEL_ANCHOR_POSITION] = Position.CENTER_TOP, DefaultStyles[Styles.LABEL_PADDING] = new Insets(0, 2), DefaultStyles[Styles.LABEL_POINTER_WIDTH] = 8, DefaultStyles[Styles.LABEL_RADIUS] = 8, DefaultStyles[Styles.LABEL_POINTER] = true, DefaultStyles[Styles.LABEL_BORDER] = 0, DefaultStyles[Styles.LABEL_BORDER_STYLE] = "#000", DefaultStyles[Styles.LABEL_ROTATABLE] = true, DefaultStyles[Styles.LABEL_BACKGROUND_COLOR] = null, DefaultStyles[Styles.LABEL_BACKGROUND_GRADIENT] = null, DefaultStyles[Styles.EDGE_COLOR] = "#555555", DefaultStyles[Styles.EDGE_WIDTH] = 1.5, DefaultStyles[Styles.EDGE_FROM_AT_EDGE] = true, DefaultStyles[Styles.EDGE_TO_AT_EDGE] = true, DefaultStyles[Styles.GROUP_BACKGROUND_COLOR] = _ia(3438210798), DefaultStyles[Styles.GROUP_STROKE] = 1, DefaultStyles[Styles.GROUP_STROKE_STYLE] = "#000", DefaultStyles[Styles.ARROW_TO] = true, DefaultStyles[Styles.ARROW_FROM_SIZE] = Defaults.ARROW_SIZE, DefaultStyles[Styles.ARROW_TO_SIZE] = Defaults.ARROW_SIZE, DefaultStyles[Styles.EDGE_LOOPED_EXTAND] = 10, DefaultStyles[Styles.EDGE_CORNER_RADIUS] = 8, DefaultStyles[Styles.EDGE_CORNER] = Consts.EDGE_CORNER_ROUND, DefaultStyles[Styles.EDGE_SPLIT_BY_PERCENT] = true, DefaultStyles[Styles.EDGE_EXTEND] = 20, DefaultStyles[Styles.EDGE_SPLIT_PERCENT] = 0.5, DefaultStyles[Styles.EDGE_SPLIT_VALUE] = 20, DefaultStyles[Styles.EDGE_BUNDLE_GAP] = 20, DefaultStyles[Styles.EDGE_BUNDLE_LABEL_ANCHOR_POSITION] = Position.CENTER_BOTTOM, DefaultStyles[Styles.EDGE_BUNDLE_LABEL_POSITION] = Position.CENTER_TOP, DefaultStyles[Styles.EDGE_BUNDLE_LABEL_COLOR] = "#075bc5", DefaultStyles[Styles.SHAPE_STROKE] = 1, DefaultStyles[Styles.SHAPE_STROKE_STYLE] = "#2898E0", DefaultStyles[Styles.RENDER_COLOR_BLEND_MODE] = Defaults.BLEND_MODE, DefaultStyles[Styles.ALPHA] = 1, Defaults.LOOKING_EDGE_ENDPOINT_TOLERANCE = 2, Consts.NAVIGATION_SCROLLBAR = "navigation.scrollbar", Consts.NAVIGATION_NONE = "navigation.none", Consts.NAVIGATION_BUTTON = "navigation.button", Defaults.NAVIGATION_TYPE = Consts.NAVIGATION_SCROLLBAR;
  var ElementCanvas = function(t, e) {
    this._l6 = t, _ho(e) && (e = document2.getElementById(e)), e && e.tagName || (e = document2.createElement("div")), _3g(this, ElementCanvas, [e]), this._l6._$x.addListener(this._1e, this), this._l6._$d.addListener(this._1p, this), this._l6._1x.addListener(this._9t, this), this._l6._14.addListener(this._7a, this), this._l6._$o.addListener(this._3a, this), this._l6._$s.addListener(this._3p, this), this._moa = {}, this._47(Defaults.NAVIGATION_TYPE, true);
  };
  ElementCanvas.prototype = {
    _$g: null,
    _3p: function(t) {
      var e = t.source, i = t.data;
      if (i)
        if (this._mkd) {
          var n, o;
          if (_ig(i))
            for (var s = 0, r = i.length; r > s; s++)
              o = i[s].id, n = this._m6.getById(o), n && (n.selected = e.containsById(o), n.invalidateRender());
          else {
            if (o = i.id, n = this._m6.getById(o), !n)
              return;
            n.selected = e.containsById(o), n.invalidateRender();
          }
          this._mmc();
        } else {
          this._$g || (this._$g = {});
          var n, o;
          if (_ig(i))
            for (var s = 0, r = i.length; r > s; s++)
              o = i[s].id, this._$g[o] = true;
          else
            o = i.id, this._$g[o] = true;
        }
    },
    _l6: null,
    _d2: function(t) {
      var e = t.uiClass;
      return e ? new e(t, this._l6) : void 0;
    },
    _1e: function() {
    },
    _1p: function(t) {
      if (!this._mkd)
        return false;
      var e = t.source, i = t.kind;
      "enableSubNetwork" == i && this._l6.invalidateVisibility(), "uiClass" == i ? (this._m6.removeById(e.id), this._kj(e)) : "expanded" == i && e._i7() && t.value && this._63(e);
      var n = this._m6.getById(e.id);
      n && n._mkd && n.onPropertyChange(t) && this._mmc();
    },
    _3u: function(t) {
      var e = this._ky(t);
      e && (e.invalidateData(), this._mmc());
    },
    _9t: function(t) {
      if (!this._mkd)
        return false;
      switch (this._$j = true, t.kind) {
        case ListEvent.KIND_ADD:
          this._kj(t.data);
          break;
        case ListEvent.KIND_REMOVE:
          this._gw(t.data);
          break;
        case ListEvent.KIND_CLEAR:
          this._i2(t.data);
      }
    },
    _kt: function() {
      this._moa = {}, _hr(this, ElementCanvas, "_kt");
    },
    _moa: null,
    _kj: function(t) {
      var e = this._d2(t);
      e && (this._m6.add(e), this._mkd && (this._moa[t.id] = t), this._mmc());
    },
    _gw: function(t) {
      if (Q2.isArray(t)) {
        for (var e, i = [], n = 0, o = t.length; o > n; n++)
          e = t[n].id, i.push(e), delete this._moa[e];
        t = i;
      } else
        t = t.id, delete this._moa[t];
      this._m6.remove(t) && this._mmc();
    },
    _i2: function() {
      this._kt();
    },
    _7a: function(t) {
      return this._mkd ? void (t.source instanceof Node && !this._moa[t.source.id] && (t.oldValue && (this._3u(t.oldValue), t.oldValue.__6k = true), t.value && (this._3u(t.value), t.value.__6k = true), this._63(t.source))) : false;
    },
    _3a: function(t) {
      return this._mkd ? void (t.source instanceof Node && !this._moa[t.source.id] && this._63(t.source)) : false;
    },
    _moi: function(t) {
      return t ? this._$y() : void this._mk2();
    },
    _3e: function(t) {
      if (t._edgeBundleInvalidateFlag) {
        var e = t.getEdgeBundle(true);
        if (!e)
          return t._edgeBundleInvalidateFlag = false, void t.validateEdgeBundle();
        e._fz(this._l6), e._mox(function(t2) {
          t2.validateEdgeBundle();
        });
      }
    },
    _$y: function() {
      var t, e = (this._l6, this._l6.graphModel), i = this._m6, n = [], o = 1;
      if (e.forEachByDepthFirst(function(e2) {
        return e2 instanceof Edge ? (this._3e(e2), void n.push(e2)) : (t = this._d2(e2), void (t && (i.add(t), t._hw = this._e3(e2, false, true), e2.__l2 = o++)));
      }, this), i.length)
        for (var s = i._jf, o = s.length - 1; o >= 0; o--)
          t = s[o], t._hw && this._40(t, t.$data);
      for (var r, o = 0, a = n.length; a > o; o++)
        if (r = n[o], t = this._d2(r))
          if (t._hw = this._e3(r, true, true), t._hw) {
            this._40(t, r, true), i.add(t);
            var h = r.fromAgent, l = r.toAgent, _ = h.__l2 || 0;
            h != l && (_ = Math.max(_, l.__l2 || 0)), r.__l2 = _;
          } else
            i.add(t);
      if (n.length && i._jf.sort(function(t2, e2) {
        return t2.$data.__l2 - e2.$data.__l2;
      }), this._$g) {
        var u = e.selectionModel;
        for (var d in this._$g)
          if (u.containsById(d)) {
            var t = i.getById(d);
            t && (t.selected = true);
          }
        this._$g = null;
      }
    },
    _mk2: function() {
      for (var t in this._moa) {
        var e = this._moa[t];
        e instanceof Node ? this._63(e) : this._62(e);
      }
      this._moa = {};
      for (var i, n, o, s = this._m6._jf, r = [], a = s.length - 1; a >= 0; a--)
        i = s[a], n = i.$data, o = n instanceof Edge, o && this._3e(n), i._hw = this._e3(n, o), i._hw ? o ? r.push(i) : this._40(i, n) && !this._$j && (this._$j = true) : n.__hwChanged && i._mkd && (i.__oldBounds = {
          x: i.$x + i.uiBounds.x,
          y: i.$y + i.uiBounds.y,
          width: i.uiBounds.width,
          height: i.uiBounds.height
        });
      if (r.length)
        for (var a = 0, h = r.length; h > a; a++)
          i = r[a], this._40(i, i.$data) && !this._$j && (this._$j = true);
    },
    _40: function(t, e, i) {
      if (i || void 0 === i && e instanceof Edge)
        return e.__56 && (e.__56 = false, t._56()), this._mmy(t);
      if (e.__6k && e._i7() && (t._6f(), e.__6k = false), this._mmy(t)) {
        var n = this._59(e);
        return n && (n.__6k = true), e.hasEdge() && e.forEachEdge(function(t2) {
          t2.__56 = true;
        }, this), true;
      }
    },
    _3l: function(t, e) {
      var i = t.fromAgent, n = t.toAgent, o = e.getIndexById(i.id);
      if (i == n)
        return o;
      var s = e.getIndexById(n.id);
      return Math.max(o, s);
    },
    _3m: function(t, e) {
      var i = this.graphModel._gp(t);
      return i ? e.getIndexById(i.id) : 0;
    },
    _63: function(t) {
      var e = this._m6, i = e.getById(t.id);
      if (!i)
        throw new Error("UI '" + t.name + "' not found");
      var n = this._3m(t, e), o = [i];
      t.hasChildren() && _9q(
        t,
        function(t2) {
          t2 instanceof Node && (i = e.getById(t2.id), i && o.push(i));
        },
        this
      ), this._4z(e, n, o);
    },
    _62: function(t) {
      var e = this._m6.getById(t.id);
      if (e) {
        var i = this._3l(t, this._m6);
        this._m6.setIndexBefore(e, i);
      }
    },
    _4z: function(t, e, i) {
      function n(t2) {
        o.add(t2);
      }
      var o = new HashList();
      if (_ic(
        i,
        function(i2) {
          e = t.setIndexAfter(i2, e), i2.$data.forEachEdge(n);
        },
        this
      ), 0 != o.length) {
        o.forEach(this._62, this);
      }
    },
    _91: function(t) {
      return t.getEdgeBundle(true);
    },
    _5x: function(t) {
      if (!t.isBundleEnabled())
        return false;
      var e = t.getEdgeBundle(true);
      e && e.reverseExpanded() !== false && this._mmc();
    },
    _59: function(t) {
      var e = findGroup(t);
      return e && e.expanded ? e : null;
    },
    _g5: function(t) {
      return findGroup(t);
    },
    _31: function(t, e, i) {
      t._$t = false;
      var n = t._hw;
      t._hw = this._5e(t, e), i || t._hw == n || (t.__hwChanged = true);
    },
    _5e: function(t, e) {
      return this._44(t, e) ? !this._l6._hwFilter || this._l6._hwFilter(t) !== false : false;
    },
    _e3: function(t, e, i) {
      return t._$t && this._31(t, e, i), t._hw;
    },
    _mk8: function(t) {
      return !this._l6._49 || this._l6._49 == _6w(t);
    },
    _44: function(t, e) {
      if (t.visible === false)
        return false;
      if (void 0 === e && (e = t instanceof Edge), !e)
        return this._l6._49 != _6w(t) ? false : !t._e1;
      var i = t.fromAgent, n = t.toAgent;
      if (!i || !n)
        return false;
      if (i == n && !t.isLooped())
        return false;
      if (t.isBundleEnabled()) {
        var o = t.getEdgeBundle(true);
        if (o && !o._e3(t))
          return false;
      }
      var s = this._e3(i, false), r = this._e3(n, false);
      return s && r ? true : false;
    },
    _7v: null,
    _7w: null,
    _47: function(t, e) {
      return e || t != this._7v ? (this._7v = t, this._7w && (this._7w._i5(), delete this._7w), t == Consts.NAVIGATION_SCROLLBAR ? void (this._7w = new ScrollBar(this, this._m7)) : t == Consts.NAVIGATION_BUTTON ? void (this._7w = new NavigationPane(this, this._m7)) : void 0) : false;
    },
    _35: function(t, e, i, n, o, s) {
      this._l6._57(
        new PropertyChangeEvent(
          this._l6,
          "transform",
          { tx: n, ty: o, scale: s },
          {
            tx: t,
            ty: e,
            scale: i
          }
        )
      ), this._5n();
    },
    _8v: function(t, e) {
      this._l6._57(new PropertyChangeEvent(this._l6, "scale", e, t));
    },
    _5n: function() {
      this._7w && this._7w._jl(), this._l6._57(new PropertyChangeEvent(this._l6, "bounds"));
    },
    _1a: function(t, e) {
      this._l6._57(new PropertyChangeEvent(this._l6, "element.bounds", e, t)), this._5n();
    }
  }, _jq(ElementCanvas, BaseCanvas), _4u(ElementCanvas.prototype, {
    graphModel: {
      get: function() {
        return this._l6._l6Model;
      }
    }
  });
  var Graph = function(t, e) {
    this._$x = new Dispatcher(), this._$x.on(function(t2) {
      "currentSubNetwork" == t2.kind && this.invalidateVisibility();
    }, this), this._1x = new Dispatcher(), this._1x.addListener(function(t2) {
      !this.currentSubNetwork || t2.kind != ListEvent.KIND_CLEAR && t2.kind != ListEvent.KIND_REMOVE || this.graphModel.contains(this.currentSubNetwork) || (this.currentSubNetwork = null);
    }, this), this._$d = new Dispatcher(), this._14 = new Dispatcher(), this._$o = new Dispatcher(), this._$s = new Dispatcher(), this.graphModel = e || new GraphModel(), this._94 = new ElementCanvas(this, t), this._2u = new InteractionManager(this), this._1i = new Dispatcher(), this._onresize = _4s(
      window2,
      "resize",
      function() {
        this.updateViewport();
      },
      false,
      this
    ), this._94._m7.ondrop = function(t2) {
      this.ondrop(t2);
    }.bind(this), this._94._m7.ondragover = function(t2) {
      this.ondragover(t2);
    }.bind(this);
  };
  Graph.prototype = {
    fullRefresh: false,
    originAtCenter: true,
    editable: false,
    ondragover: function(t) {
      Q2.stopEvent(t);
    },
    getDropInfo: function(t, e) {
      var i = null;
      if (e)
        try {
          i = JSON.parse(e);
        } catch (n) {
        }
      return i;
    },
    ondrop: function(t) {
      var e = t.dataTransfer;
      if (e) {
        var i = e.getData("text"), n = this.getDropInfo(t, i);
        n || (n = {}, n.image = e.getData("image"), n.type = e.getData("type"), n.label = e.getData("label"), n.groupImage = e.getData("groupImage"));
        var o = this.globalToLocal(t);
        if (o = this.toLogical(o.x, o.y), !(this.dropAction instanceof Function && this.dropAction.call(this, t, o, n) === false) && (n.image || n.label)) {
          var s = n.image, r = n.type, a = n.label, h = n.groupImage;
          Q2.stopEvent(t);
          var l;
          if (r && "Node" != r ? "Text" == r ? l = this.createText(a, o.x, o.y) : "ShapeNode" == r ? l = this.createShapeNode(a, o.x, o.y) : "Group" == r ? (l = this.createGroup(a, o.x, o.y), h && (h = toImage(h), h && (l.groupImage = h))) : (r = stringToObject(r), r instanceof Function && r.prototype instanceof Node && (l = new r(), l.name = a, l.location = new Point(o.x, o.y), this._l6Model.add(l))) : l = this.createNode(a, o.x, o.y), l) {
            if (s && (s = toImage(s), s && (l.image = s)), t.shiftKey) {
              var _ = this.getElementByMouseEvent(t);
              (_.enableSubNetwork || _ instanceof Group) && (l.parent = _);
            }
            if (n.properties)
              for (var u in n.properties)
                l[u] = n.properties[u];
            if (n.clientProperties)
              for (var u in n.clientProperties)
                l.set(u, n.clientProperties[u]);
            if (n.styles && l.putStyles(n.styles), this.onElementCreated(l, t, n) === false)
              return false;
            var d = new InteractionEvent(this, InteractionEvent.ELEMENT_CREATED, t, l);
            return this.onInteractionEvent(d), l;
          }
        }
      }
    },
    enableDoubleClickToOverview: true,
    _94: null,
    _$x: null,
    _1x: null,
    _$d: null,
    _$s: null,
    _14: null,
    _$o: null,
    _22: function(t) {
      return this._$x.beforeEvent(t);
    },
    _57: function(t) {
      this._$x.onEvent(t);
    },
    isVisible: function(t) {
      return this._94._e3(t);
    },
    isMovable: function(t) {
      return (t instanceof Node || t instanceof Edge && t.hasPathSegments()) && t.movable !== false;
    },
    isSelectable: function(t) {
      return t.selectable !== false;
    },
    isEditable: function(t) {
      return t.editable !== false;
    },
    isRotatable: function(t) {
      return t.rotatable !== false;
    },
    isResizable: function(t) {
      return t.resizable !== false;
    },
    canLinkFrom: function(t) {
      return t.linkable !== false && t.canLinkFrom !== false;
    },
    canLinkTo: function(t) {
      return t.linkable !== false && t.canLinkTo !== false;
    },
    createNode: function(t, e, i) {
      var n = new Node(t, e, i);
      return this._l6Model.add(n), n;
    },
    createText: function(t, e, i) {
      var n = new Text(t, e, i);
      return this._l6Model.add(n), n;
    },
    createShapeNode: function(t, e, i, n) {
      _gd(e) && (n = i, i = e, e = null);
      var o = new ShapeNode(t, e);
      return o.$location = new Point(i, n), this._l6Model.add(o), o;
    },
    createGroup: function(t, e, i) {
      var n = new Group(t, e, i);
      return this._l6Model.add(n), n;
    },
    createEdge: function(t, e, i) {
      if (t instanceof Node) {
        var n = i;
        i = e, e = t, t = n;
      }
      var o = new Edge(e, i);
      return t && (o.$name = t), this._l6Model.add(o), o;
    },
    addElement: function(t, e) {
      this._l6Model.add(t), e && t.hasChildren() && t.forEachChild(function(t2) {
        this.addElement(t2, e);
      }, this);
    },
    removeElement: function(t) {
      this._l6Model.remove(t);
    },
    clear: function() {
      this._l6Model.clear();
    },
    getStyle: function(t, e) {
      var i = t._jb[e];
      return void 0 !== i ? i : this.getDefaultStyle(e);
    },
    getDefaultStyle: function(t) {
      if (this._jb) {
        var e = this._jb[t];
        if (void 0 !== e)
          return e;
      }
      return DefaultStyles[t];
    },
    translate: function(t, e, i) {
      return i ? this.translateTo(this.tx + t, this.ty + e, this.scale, i) : this._94._el(t, e);
    },
    translateTo: function(t, e, i, n) {
      if (n) {
        var o = this._5v();
        return o._l7(t, e, i, n);
      }
      return this._94._mo9(t, e, i);
    },
    centerTo: function(t, e, i, n) {
      return (!i || 0 >= i) && (i = this.scale), this.translateTo(this.width / 2 - t * i, this.height / 2 - e * i, i, n);
    },
    moveToCenter: function(t, e) {
      this.callLater(function() {
        var i = this.bounds;
        this.centerTo(i.cx, i.cy, t, e);
      }, this);
    },
    zoomToOverview: function(t) {
      return t ? this.callLater(function() {
        var e = this._94._26();
        e && this.centerTo(e.cx, e.cy, e.scale, t);
      }, this) : void this._94._75();
    },
    zoomAt: function(t, e, i, n) {
      if (void 0 === n && (n = Defaults.ZOOM_ANIMATE), void 0 === e && (e = this.width / 2), e = e || 0, void 0 === i && (i = this.height / 2), i = i || 0, n) {
        var o = this.scale;
        return t = o * t, t >= this.maxScale || t <= this.minScale ? false : (e = t * (this.tx - e) / o + e, i = t * (this.ty - i) / o + i, this.translateTo(e, i, t, n));
      }
      return this._94._jt(t, e, i);
    },
    zoomOut: function(t, e, i) {
      return this.zoomAt(1 / this.scaleStep, t, e, i);
    },
    zoomIn: function(t, e, i) {
      return this.zoomAt(this.scaleStep, t, e, i);
    },
    _5v: function() {
      return this._panAnimation || (this._panAnimation = new PanAnimation(this)), this._panAnimation;
    },
    enableInertia: true,
    _mk4: function(t, e) {
      var i = this._5v();
      return i._fl(t || 0, e || 0);
    },
    stopAnimation: function() {
      this._panAnimation && this._panAnimation._ll();
    },
    getUI: function(t) {
      return isMouseEvent(t) ? this._94._3w(t) : this._94._ky(t);
    },
    getUIByMouseEvent: function(t) {
      return this._94._3w(t);
    },
    hitTest: function(t) {
      return this._94._hq(t);
    },
    globalToLocal: function(t) {
      return this._94._88(t);
    },
    toCanvas: function(t, e) {
      return this._94._g0(t, e);
    },
    toLogical: function(t, e) {
      return isMouseEvent(t) ? this._94._$h(t) : this._94._e8(t, e);
    },
    getElementByMouseEvent: function(t) {
      var e = this._94._3w(t);
      return e ? e.$data : void 0;
    },
    getElement: function(t) {
      if (isMouseEvent(t)) {
        var e = this._94._3w(t);
        return e ? e.$data : null;
      }
      return this._l6Model.getById(t);
    },
    invalidate: function() {
      this._94._mmc();
    },
    invalidateUI: function(t) {
      t.invalidate(), this.invalidate();
    },
    invalidateElement: function(t) {
      this._94._3u(t);
    },
    getUIBounds: function(t) {
      return this._94._mkk(t);
    },
    forEachVisibleUI: function(t, e) {
      return this._94._4o(t, e);
    },
    forEachReverseVisibleUI: function(t, e) {
      return this._94._11(t, e);
    },
    forEachUI: function(t, e) {
      return this._94._ei(t, e);
    },
    forEachReverseUI: function(t, e) {
      return this._94._4k(t, e);
    },
    forEach: function(t, e) {
      return this._l6Model.forEach(t, e);
    },
    getElementByName: function(t) {
      var e;
      return this._l6Model.forEach(function(i) {
        return i.name == t ? (e = i, false) : void 0;
      }), e;
    },
    focus: function(t) {
      if (t) {
        var e = window2.scrollX || window2.pageXOffset, i = window2.scrollY || window2.pageYOffset;
        return this.html.focus(), void window2.scrollTo(e, i);
      }
      this.html.focus();
    },
    callLater: function(t, e, i) {
      this._94.callLater(t, e, i);
    },
    exportImage: function(t, e) {
      return exportGraph(this, t, e);
    },
    setSelection: function(t) {
      return this._l6Model._selectionModel.set(t);
    },
    select: function(t) {
      return this._l6Model._selectionModel.select(t);
    },
    unselect: function(t) {
      return this._l6Model._selectionModel.unselect(t);
    },
    reverseSelect: function(t) {
      return this._l6Model._selectionModel.reverseSelect(t);
    },
    selectAll: function() {
      selectAllElement(this);
    },
    unSelectAll: function() {
      this.selectionModel.clear();
    },
    unselectAll: function() {
      this.unSelectAll();
    },
    isSelected: function(t) {
      return this._l6Model._selectionModel.contains(t);
    },
    sendToTop: function(t) {
      elementSendToTop(this._l6Model, t);
    },
    sendToBottom: function(t) {
      elementSendToBottom(this._l6Model, t);
    },
    moveElements: function(t, e, i) {
      var n = [], o = new HashList();
      return _ic(t, function(t2) {
        t2 instanceof Node ? n.push(t2) : t2 instanceof Edge && o.add(t2);
      }), this._eg(n, e, i, o);
    },
    _eg: function(t, e, i, n) {
      if (0 == e && 0 == i || 0 == t.length && 0 == n.length)
        return false;
      if (0 != t.length) {
        var o = this._4v(t);
        n = this._51(o, n), _ic(o, function(t2) {
          var n2 = t2.$location;
          n2 ? t2.setLocation(n2.x + e, n2.y + i) : t2.setLocation(e, i);
        });
      }
      return n && n.length && this._eh(n, e, i), true;
    },
    _eh: function(t, e, i) {
      t.forEach(function(t2) {
        t2.move(e, i);
      });
    },
    _51: function(t, e) {
      return this.graphModel.forEach(function(i) {
        i instanceof Edge && this.isMovable(i) && t.contains(i.fromAgent) && t.contains(i.toAgent) && e.add(i);
      }, this), e;
    },
    _4v: function(t) {
      var e = new HashList();
      return _ic(
        t,
        function(t2) {
          !this.isMovable(t2), e.add(t2), findFollowers(t2, e, this._movableFilter);
        },
        this
      ), e;
    },
    reverseExpanded: function(t) {
      return this._94._5x(t);
    },
    _2u: null,
    _1i: null,
    beforeInteractionEvent: function(t) {
      return this._1i.beforeEvent(t);
    },
    onInteractionEvent: function(t) {
      this._1i.onEvent(t);
    },
    addCustomInteraction: function(t) {
      this._2u.addCustomInteraction(t);
    },
    enableWheelZoom: true,
    enableTooltip: true,
    getTooltip: function(t) {
      return t.tooltip || t.name;
    },
    updateViewport: function() {
      this._94._4a();
    },
    destroy: function() {
      this._57(new PropertyChangeEvent(this, "destroy", true, this._i5ed)), this._i5ed = true, _2j(window2, "resize", this._onresize), _6y(this, "_onresize"), this._2u.destroy(), this.graphModel = new GraphModel();
      var t = this.html;
      this._94._i5(), t && (t.innerHTML = "");
    },
    onPropertyChange: function(t, e, i) {
      this._$x.addListener(function(n) {
        n.kind == t && e.call(i, n);
      });
    },
    removeSelection: function() {
      var t = this.selectionModel._jf;
      return t && 0 != t.length ? (t = t.slice(), this._l6Model.remove(t), t) : false;
    },
    removeSelectionByInteraction: function(t) {
      var e = this.selectionModel.datas;
      return e && 0 != e.length ? void Q2.confirm(
        "Delete Elements - " + e.length,
        function() {
          var e2 = this.removeSelection();
          if (e2) {
            var i = new InteractionEvent(this, InteractionEvent.ELEMENT_REMOVED, t, e2);
            this.onInteractionEvent(i);
          }
        },
        this
      ) : false;
    },
    createShapeByInteraction: function(t, e, i, n) {
      var o = new Path(e);
      e.length > 2 && o.closePath();
      var s = this.createShapeNode("Shape", o, i, n);
      this.onElementCreated(s, t);
      var r = new InteractionEvent(this, InteractionEvent.ELEMENT_CREATED, t, s);
      return this.onInteractionEvent(r), s;
    },
    createLineByInteraction: function(t, e, i, n) {
      var o = new Path(e), s = this.createShapeNode("Line", o, i, n);
      s.setStyle(Q2.Styles.SHAPE_FILL_COLOR, null), s.setStyle(Q2.Styles.SHAPE_FILL_GRADIENT, null), s.setStyle(Q2.Styles.LAYOUT_BY_PATH, true), this.onElementCreated(s, t);
      var r = new InteractionEvent(this, InteractionEvent.ELEMENT_CREATED, t, s);
      return this.onInteractionEvent(r), s;
    },
    createEdgeByInteraction: function(t, e, i, n) {
      var o = this.createEdge("Edge", t, e);
      if (n)
        o._9x = n;
      else {
        var s = this.edgeUIClass, r = this.edgeType;
        this.interactionProperties && (s = this.interactionProperties.uiClass || s, r = this.interactionProperties.edgeType || r), s && (o.uiClass = s), r && (o.edgeType = r);
      }
      this.onElementCreated(o, i);
      var a = new InteractionEvent(this, InteractionEvent.ELEMENT_CREATED, i, o);
      return this.onInteractionEvent(a), o;
    },
    onElementCreated: function(t) {
      !t.parent && this.currentSubNetwork && (t.parent = this.currentSubNetwork);
    },
    allowEmptyLabel: false,
    startLabelEdit: function(t, e, i, n) {
      var o = this;
      i.startEdit(n.x, n.y, e.data, this.getStyle(t, Styles.LABEL_FONT_SIZE), function(i2) {
        return o.onLabelEdit(t, e, i2, e.parent);
      });
    },
    onLabelEdit: function(t, e, i, n) {
      return i || this.allowEmptyLabel ? void ("label" == e.name ? t.name = i : n._fo(e, i) === false && (e.data = i, this.invalidateElement(t))) : (Q2.alert("Label Can't Empty"), false);
    },
    setInteractionMode: function(t, e) {
      this.interactionMode = t, this.interactionProperties = e;
    },
    upSubNetwork: function() {
      return this._49 ? this.currentSubNetwork = _6w(this._49) : false;
    },
    _$t: false,
    invalidateVisibility: function() {
      this._$t = true, this.invalidate();
    },
    getBundleLabel: function(t) {
      var e = t.getEdgeBundle(true);
      return e && e.agentEdge == t ? "+" + e.bindableEdges.length : null;
    }
  }, _4u(Graph.prototype, {
    center: {
      get: function() {
        return this.toLogical(this.html.clientWidth / 2, this.html.clientHeight / 2);
      }
    },
    visibleFilter: {
      get: function() {
        return this._hwFilter;
      },
      set: function(t) {
        this._hwFilter = t, this.invalidate();
      }
    },
    topCanvas: {
      get: function() {
        return this._94._topCanvas;
      }
    },
    propertyChangeDispatcher: {
      get: function() {
        return this._$x;
      }
    },
    listChangeDispatcher: {
      get: function() {
        return this._1x;
      }
    },
    dataPropertyChangeDispatcher: {
      get: function() {
        return this._$d;
      }
    },
    selectionChangeDispatcher: {
      get: function() {
        return this._$s;
      }
    },
    parentChangeDispatcher: {
      get: function() {
        return this._14;
      }
    },
    childIndexChangeDispatcher: {
      get: function() {
        return this._$o;
      }
    },
    interactionDispatcher: {
      get: function() {
        return this._1i;
      }
    },
    cursor: {
      set: function(t) {
        this.html.style.cursor = t || this._2u.defaultCursor;
      },
      get: function() {
        return this.html.style.cursor;
      }
    },
    interactionMode: {
      get: function() {
        return this._2u._mmurrentMode;
      },
      set: function(t) {
        var e = this.interactionMode;
        e != t && (this._2u.currentMode = t, this._57(new PropertyChangeEvent(this, "interactionMode", t, e)));
      }
    },
    scaleStep: {
      get: function() {
        return this._94._ek;
      },
      set: function(t) {
        this._94._ek = t;
      }
    },
    maxScale: {
      get: function() {
        return this._94._gy;
      },
      set: function(t) {
        this._94._gy = t;
      }
    },
    minScale: {
      get: function() {
        return this._94._gz;
      },
      set: function(t) {
        this._94._gz = t;
      }
    },
    scale: {
      get: function() {
        return this._94._l5;
      },
      set: function(t) {
        return this._94._l5 = t;
      }
    },
    tx: {
      get: function() {
        return this._94._me;
      }
    },
    ty: {
      get: function() {
        return this._94._mc;
      }
    },
    styles: {
      get: function() {
        return this._jb;
      },
      set: function(t) {
        this._jb = t;
      }
    },
    selectionModel: {
      get: function() {
        return this._l6Model._selectionModel;
      }
    },
    graphModel: {
      get: function() {
        return this._l6Model;
      },
      set: function(t) {
        if (this._l6Model == t)
          return false;
        var e = this._l6Model, i = new PropertyChangeEvent(this, "graphModel", e, t);
        return this._22(i) === false ? false : (null != e && (e.propertyChangeDispatcher.removeListener(this._$x, this), e.listChangeDispatcher.removeListener(this._1x, this), e.dataChangeDispatcher.removeListener(this._$d, this), e.parentChangeDispatcher.removeListener(this._14, this), e.childIndexChangeDispatcher.removeListener(this._$o, this), e.selectionChangeDispatcher.removeListener(this._$s, this)), this._l6Model = t, this._l6Model && (this._l6Model.propertyChangeDispatcher.addListener(this._$x, this), this._l6Model.listChangeDispatcher.addListener(this._1x, this), this._l6Model.dataChangeDispatcher.addListener(this._$d, this), this._l6Model.parentChangeDispatcher.addListener(this._14, this), this._l6Model.childIndexChangeDispatcher.addListener(this._$o, this), this._l6Model.selectionChangeDispatcher.addListener(this._$s, this)), this._94 && this._94._kr(), void this._57(i));
      }
    },
    count: {
      get: function() {
        return this._l6Model.length;
      }
    },
    width: {
      get: function() {
        return this.html.clientWidth;
      }
    },
    height: {
      get: function() {
        return this.html.clientHeight;
      }
    },
    viewportBounds: {
      get: function() {
        return this._94._78;
      }
    },
    bounds: {
      get: function() {
        return this._94._4h();
      }
    },
    html: {
      get: function() {
        return this._94._m7;
      }
    },
    navigationType: {
      get: function() {
        return this._94._7v;
      },
      set: function(t) {
        this._94._47(t);
      }
    },
    _49: {
      get: function() {
        return this._l6Model._49;
      }
    },
    currentSubNetwork: {
      get: function() {
        return this._l6Model.currentSubNetwork;
      },
      set: function(t) {
        this._l6Model.currentSubNetwork = t;
      }
    }
  }), GroupUI.prototype = {
    initialize: function() {
      _hr(this, GroupUI, "initialize"), this.checkBody();
    },
    _moy: function() {
      this._li = new Path(), this.shape = new ImageUI(this._li), this.shape.layoutByPath = false, this.addChild(this.shape, 0), this.body = this.shape;
    },
    checkBody: function() {
      return this._65() ? (this._28 = true, this.shape ? (this.shape.visible = true, this.body = this.shape) : (this._moy(), GroupUIBindingMap.initBindingProperties(this)), void (this.image && (this.image.visible = false))) : (this.image ? (this.image.visible = true, this.body = this.image) : this._mo8(), void (this.shape && (this.shape.visible = false)));
    },
    _65: function() {
      return this.$data._i7() && this.$data.expanded;
    },
    _li: null,
    _28: true,
    _6f: function() {
      this._1q = true, this._28 = true;
    },
    doValidate: function() {
      if (this._28 && this._65()) {
        if (this._28 = false, this.shape.invalidateData(), this.$data.groupImage) {
          this.shape.data = this.$data.groupImage;
          var t = this._2o();
          return this.shape.offsetX = t.x + t.width / 2, this.shape.offsetY = t.y + t.height / 2, this.shape.size = {
            width: t.width,
            height: t.height
          }, NodeUI.prototype.doValidate.call(this);
        }
        this.shape.offsetX = 0, this.shape.offsetY = 0;
        var e = this._8t(this.$data.groupType);
        this._li.clear(), e instanceof Rect ? addRect(this._li, e.x, e.y, e.width, e.height, e.rx, e.ry) : e instanceof Circle ? addCircle(this._li, e) : e instanceof Ellipse && addEllipse(this._li, e), this._li._6k = true, this.shape.invalidateData();
      }
      return NodeUI.prototype.doValidate.call(this);
    },
    _6o: function(t, e, i) {
      switch (t) {
        case Consts.GROUP_TYPE_CIRCLE:
          return new Circle(0, 0, Math.max(e, i) / 2);
        case Consts.GROUP_TYPE_ELLIPSE:
          return new Ellipse(0, 0, e, i);
        default:
          return new Rect(-e / 2, -i / 2, e, i);
      }
    },
    _2o: function() {
      return this._8t(null);
    },
    _8t: function(t) {
      var e = this.data, i = e.padding, n = e.minSize, o = 60, s = 60;
      if (n && (o = n.width, s = n.height), !e.hasChildren())
        return this._6o(t, o, s);
      var r, a = this.$data._fv._jf;
      (t == Consts.GROUP_TYPE_CIRCLE || t == Consts.GROUP_TYPE_ELLIPSE) && (r = []);
      for (var h, l, _, u, d = new Rect(), c = 0, f = a.length; f > c; c++) {
        var E = a[c];
        if (this.graph.isVisible(E)) {
          var g = this.graph.getUI(E);
          g && (h = g.$x + g._fu.x, l = g.$y + g._fu.y, _ = g._fu.width, u = g._fu.height, d.addRect(h, l, _, u), r && (r.push({
            x: h,
            y: l
          }), r.push({ x: h + _, y: l }), r.push({ x: h + _, y: l + u }), r.push({ x: h, y: l + u })));
        }
      }
      i && d.grow(i);
      var p = this.$data.$location;
      p ? p.invalidateFlag && (p.invalidateFlag = false, p.x = d.cx, p.y = d.cy) : p = this.$data.$location = {
        x: d.cx,
        y: d.cy
      };
      var v, T = p.x, m = p.y;
      if (t == Consts.GROUP_TYPE_CIRCLE) {
        v = smallEmbodyCircle(r), v.cx -= T, v.cy -= m;
        var y = Math.max(o, s) / 2;
        return v.r < y && (v.cx += y - v.r, v.cy += y - v.r, v.r = y), v;
      }
      return t == Consts.GROUP_TYPE_ELLIPSE ? (v = smallEmbodyEllipse(r, d), v.cx -= T, v.cy -= m, v.width < o && (v.cx += (o - v.width) / 2, v.width = o), v.height < s && (v.cy += (s - v.height) / 2, v.height = s), v) : (v = d, d.width < o && (d.width = o), d.height < s && (d.height = s), d.offset(-T, -m), v);
    },
    _$z: function(t, e, i) {
      if (!this._65())
        return _hr(this, GroupUI, "_$z", arguments);
      var n = this._mm4.onBindingPropertyChange(this, t, e, i);
      return n = ElementUIBindingMap.onBindingPropertyChange(this, t, e, i) || n, n = NodeUIBindingMap.onBindingPropertyChange(this, t, e, i) || n, GroupUIBindingMap.onBindingPropertyChange(this, t, e, i) || n;
    }
  }, _jq(GroupUI, NodeUI);
  var IDrawable = {
    draw: function() {
    }
  };
  Defaults.NAVIGATION_IMAGE_LEFT = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAoCAYAAAD+MdrbAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA09JREFUeNqcVl1Ik1EYfqebIuaQTWQK/udkdKMXIggG3XQRRBDdRBDdhDdBhRAVFUS/1FVXEt1EEBVEIIFIN0JGEEF6E+HU6VR0iDPdnKLT2fN87h2fY+aODzzfDud8ezjP9/6c49jZ2ZGhoSExxFGwHWwDh7u6ut7pguMQghR7nzX3GaL3OSgQc1zno6qqSgKBgBQUWBKnsanzhxG8DXaUlJRIQ0ODVFRUSEtLi661mQoeA886HA7x+/1SWFgo/Fxzc3O6PmwqeIWP6upqcbvd1gTFVlZWOAyBH0wEabVdrRLr6+syNTWl670ISipfwXa1yu/FX1odHR2VVCqlER7Ul/MR7OajpqZGysrKrInZ2VmJx+Mc/gEf2V8+SPAu2FpaWiq1tbXWRCKRkHA4bLe6la9gB3gml1X+An0Q+579p/0EnRpV7ow7JKanp60dAiMQe5Drj/sJ3gID/Gb8dgS/2czMjK6/3M9WLsETuawGg0G1+gm7+5mvYJFGlfnGvCMmJydlbW2Nw1/g4/9FMVvwDrsJK4EVQcRiMXt5vTgox+yCJ8FTrFHWKq1ub2/vsQr+zlfQpVbr6+szVllaLDHgx0FWswV7wLry8vKM1eXlZSOr2YKtfDQ2NmYWQqGQDl+BQVPBEW1HCt0puzHoNhXkIZOMRCKytLRkTfh8PvF4PNYQvGkqGNbsHxsbk62t3Xpvbm4Wp9OpGXDORJB4DX7d3NyUiYmJ3SwvKpKmpiZdvwx6TASJZ+DqwsKCRKNRa6KyslK8Xi+H3nSNGwlG0lG1rCeTyYx1l8uldX7BRJB4Cw5SbHx8fDfrIUZRtY4z2GciSDwF/y4uLgrtW35hm/aBI+ANU8GoRp0BYqAIBoiBAo5jl5dMBImP4BemEL+n1caRQjbr3RCtMxFU6xEmO5OeYLIz6dMNpcdUMKbW2WQ3NjZEa764uJjDTuyy20TQOsjBAVpnbyS0Z9qi7jcRJJ6wPNnS5ufnrQl7qwOumgomNOFpPd107c24A7u8aHr7GgD7eSww6jwWaF0vT9pTTS+cD9l7eYVj7+Shr41Ee6rTUJAZ3gs+p3Veh7lj4BvO6jeHvWPz6tZHy2mxfohdMw3KHqTvNZ0sQYzv2df+CTAAM91P5i8bXigAAAAASUVORK5CYII=", Defaults.NAVIGATION_IMAGE_TOP = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAUCAYAAAD/Rn+7AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAohJREFUeNrMVs+LUlEUPk8jNBGJXKWgBCrRZhAiCFy0HYigVdvazdQf0A+CftAPaFlNu4HZtQqGgdkOKAQRSAgRPkEUtG2ImBKj9n2Pc0XNmcb3Xj8OfN57ve/d893vnHfutYrFoixrhUJh4f+lUumEzn8Xn+yYH4uAWBjNHWBVx7tonoFo3+vaAR/IXUKzRXLBYFAIJbqlc/9GQTjnu/eAyxzHYjHJZrPOnG3b0ul0zqD7As/toH0CNffd+LHc5CDsIrAGnA0EApJOpyWRSMw80G63pdFoyGg04vAL8AYk3/8NgveBK+xEo1HJ5XISDoedieFw6LQaZun3+1KtVqXb7Zp3t0Hy8Z8imAfWgRXLsiSVSkkymRT2aQipE1oaQ82Q08bjsbRaLWk2m04f9gnYANGynwTvAlfZiUQijmpsaQwhQ8mQThtDztAzBWi9Xs9Rk63aO5B86pXgOeAWcJ5KUTEqZ1Rj6OiUoVTb1PYGfxh6boapYNSkklRU1fwIvALRz24Irrt1hC936Y3h3Y2jEpws7jVUILpMaixUc57gjGqZTMZzsoPkbz+uWq12oJqG4Gngtta3X1Tzo1yA6IHlaYGarJfP4eMrCZ7C4C1wMhQKzZQIPwuukjy0wJtSNRgMOPwGXKNEKyQXj8cln89PyFG1SqUi9XrdkOORdV1358p0Y1xjh2tybfow4aVvciAXciI3nqe2SX7NrXnV6lQN2PPj5qNn8kOoydxa45ldLpcnapLD1Adomxx8DVww6lFqNeegB/aPch90EfLjek2bXDim/H+An5vmNvMIeKk3EN9VO0TNH/NqTvl/MF9mTD6aEjJa9kbtUc0Z//Dh+LdM3v2v9lOAAQDlEZVA4N7FygAAAABJRU5ErkJggg==";
  var NAV_BUTTON_CSS = { position: "absolute", "text-align": "center" }, NAV_BUTTON_IMAGE_CSS = {
    padding: "10px",
    transition: "opacity 0.2s ease-in"
  }, NAV_VERTICAL_MIDDLE_CSS = { position: "relative", display: "block" };
  css_m9Rule(".Q-Graph-Nav img", "opacity:0.7;vertical-align:middle;"), css_m9Rule(".Q-Graph-Nav img:hover,img.hover", "opacity:1;background-color: rgba(0, 0, 0, 0.5)"), isTouchSupport || (css_m9Rule(".Q-Graph-Nav", "opacity:0;" + css_pre("transition") + ":opacity 3s cubic-bezier(0.8, 0, 0.8, 1)"), css_m9Rule(".Q-Graph-Nav:hover", "opacity:1;" + css_pre("transition") + ":opacity 0.3s linear")), NavigationPane.prototype = {
    _db: function(t, e) {
      return t._hw == e ? false : (t._hw = e, void (t.style.display = e ? "block" : "none"));
    },
    _3n: function(t, e) {
      var i = e / 2 - this._left._img.clientHeight / 2 + "px";
      this._left._img.style.top = i, this._right._img.style.top = i, this._navPane.style.width = t + "px", this._navPane.style.height = e + "px";
    },
    _9a: function(t, e, i, n) {
      this._db(this._top, t), this._db(this._left, e), this._db(this._moottom, i), this._db(this._right, n);
    },
    _i5: function() {
      var t = this._navPane.parentNode;
      t && t.removeChild(this._navPane);
    },
    _jl: function() {
      var t = this._d5._l6;
      if (t) {
        var e = t.bounds;
        if (e.isEmpty())
          return void this._9a(false, false, false, false);
        var i = t.viewportBounds, n = i.y > e.y + 1, o = i.x > e.x + 1, s = i.bottom < e.bottom - 1, r = i.right < e.right - 1;
        this._9a(n, o, s, r);
      }
    }
  };
  var SCROLLBAR_SIZE = 8;
  css_m9Rule(
    ".Q-Graph-ScrollBar",
    "position: absolute;box-sizing: border-box;box-shadow: #FFF 0px 0px 1px; background-color: rgba(120,120,120,0.3);border-radius: 4px;margin: 1px;"
  ), css_m9Rule(
    ".Q-Graph-ScrollBar:hover",
    "background-color: #7E7E7E;" + css_pre("transition") + ": background-color 0.2s linear;"
  ), css_m9Rule(".Q-Graph-ScrollBar--V", "width: 8px;right: 0px;"), css_m9Rule(".Q-Graph-ScrollBar--H", "height: 8px;bottom: 0px;"), css_m9Rule(".Q-Graph-ScrollBar--V.Both", "margin-bottom: 8px;"), css_m9Rule(".Q-Graph-ScrollBar--H.Both", "margin-right: 8px;"), isTouchSupport || (css_m9Rule(
    ".Q-Graph-ScrollPane",
    "opacity:0;" + css_pre("transition") + ":opacity 3s cubic-bezier(0.8, 0, 0.8, 1);"
  ), css_m9Rule(".Q-Graph:hover .Q-Graph-ScrollPane", "opacity:1;" + css_pre("transition") + ":opacity 0.3s linear;")), ScrollBar.prototype = {
    _i5: function() {
      this._verticalDragSupport._i5(), this._horizontalDragSupport._i5(), delete this._verticalDragSupport, delete this._horizontalDragSupport, this._m2.parentNode && this._m2.parentNode.removeChild(this._m2);
    },
    _m2: null,
    _mkt: null,
    _8r: null,
    init: function(t) {
      var e = document2.createElement("div");
      e.className = "Q-Graph-ScrollPane", css_mmss(e, { width: "100%", height: "100%", position: "relative" });
      var i = document2.createElement("div");
      i.className = "Q-Graph-ScrollBar Q-Graph-ScrollBar--V";
      var n = document2.createElement("div");
      n.className = "Q-Graph-ScrollBar Q-Graph-ScrollBar--H", e.appendChild(i), e.appendChild(n), t.appendChild(e), this._m2 = e, this._8r = n, this._mkt = i, n.isH = true;
      var o = this, s = {
        ondrag: function(t2, e2) {
          var i2 = o._d5._l6;
          if (i2) {
            var n2 = e2.isH, s2 = n2 ? t2.dx : t2.dy;
            if (s2 && e2.scale) {
              var r = i2.scale / e2.scale;
              n2 ? i2.translate(-r * s2, 0) : i2.translate(0, -r * s2), Q2.stopEvent(t2);
            }
          }
        },
        enddrag: function(t2, e2) {
          var i2 = o._d5._l6;
          if (i2 && i2.enableInertia) {
            var n2 = e2.isH, s2 = n2 ? t2.vx : t2.vy;
            if (Math.abs(s2) > 0.1) {
              var r = i2.scale / e2.scale;
              s2 *= r, n2 ? i2._mk4(-s2, 0) : i2._mk4(0, -s2);
            }
          }
        }
      };
      this._verticalDragSupport = new DragSupport(i, s), this._horizontalDragSupport = new DragSupport(n, s);
    },
    _jl: function() {
      var t = this._d5._l6;
      if (t) {
        var e = t.bounds;
        if (e.isEmpty())
          return this._4j(false), void this._4m(false);
        var i = t.viewportBounds, n = t.width, o = t.height, s = t.scale, r = 1 / s, a = i.x > e.x + r || i.right < e.right - r, h = i.y > e.y + r || i.bottom < e.bottom - r, l = a && h;
        l ? (_mkg(this._mkt, "Both"), _mkg(this._8r, "Both")) : (_mkz(this._mkt, "Both"), _mkz(this._8r, "Both")), this._4j(a, i, e, l ? n - SCROLLBAR_SIZE : n), this._4m(h, i, e, l ? o - SCROLLBAR_SIZE : o);
      }
    },
    _4j: function(t, e, i, n) {
      if (!t)
        return this._8r.style.display = "none", void (this._8r.scale = 0);
      var o = Math.min(e.x, i.x), s = Math.max(e.right, i.right), r = s - o, a = n / r;
      this._8r.scale = a, this._8r.style.left = parseInt((e.x - o) * a) + "px", this._8r.style.right = parseInt((s - e.right) * a) + "px", this._8r.style.display = "";
    },
    _4m: function(t, e, i, n) {
      if (!t)
        return this._mkt.style.display = "none", void (this._mkt.scale = 0);
      var o = Math.min(e.y, i.y), s = Math.max(e.bottom, i.bottom), r = s - o, a = n / r;
      this._mkt.scale = a, this._mkt.style.top = parseInt((e.y - o) * a) + "px", this._mkt.style.bottom = parseInt((s - e.bottom) * a) + "px", this._mkt.style.display = "";
    }
  }, ShapeNodeUI.prototype = {
    shape: null,
    initialize: function() {
      _hr(this, ShapeNodeUI, "initialize"), this._mo8(), ShapeNodeUIBindingMap.initBindingProperties(this);
    },
    _mo8: function() {
      this.image = new ShapeUI(this.$data.path), this.addChild(this.image, 0), this.body = this.image;
    },
    invalidateShape: function() {
      this.image.invalidateData(), this.invalidateRender();
    },
    _$z: function(t, e, i) {
      var n = this._mm4.onBindingPropertyChange(this, t, e, i);
      return n = ElementUIBindingMap.onBindingPropertyChange(this, t, e, i) || n, ShapeNodeUIBindingMap.onBindingPropertyChange(this, t, e, i) || n;
    },
    doValidate: function() {
      this.body && (this.body.$layoutByAnchorPoint = null != this._3c, this.body.anchorPosition = this._3c);
      var t = this.$data.$location, e = 0, i = 0;
      t && (e = t.x, i = t.y);
      var n = this.$x != e || this.$y != i;
      return n && (this.$invalidateBounds = true), this.$x = e, this.$y = i, ElementUI.prototype.doValidate.call(this) || n;
    }
  }, _jq(ShapeNodeUI, ElementUI), _4u(ShapeNodeUI.prototype, {
    path: {
      get: function() {
        return this.data.path;
      }
    },
    length: {
      get: function() {
        return this.data.length;
      }
    }
  }), ShapeNodeUI.prototype.addPoint = function(t, e, i) {
    var n = this._hu(t, e), o = this.data, s = _7y(o.path, n.x, n.y, i);
    s && (o.pathSegments = s);
  }, TopCanvas.prototype = {
    _lk: function() {
      this._jn.style.visibility = "visible";
    },
    _j9: function() {
      this._jn.style.visibility = "hidden";
    },
    clear: function() {
      this._9k.clear(), this._mmc();
    },
    contains: function(t) {
      return t instanceof Object && t.id && (t = t.id), this._9k.containsById(t);
    },
    addDrawable: function(t, e) {
      if (e) {
        var i = { id: ++idIndex, drawable: t, scope: e };
        return this._9k.add(i), i;
      }
      return t.id || (t.id = ++idIndex), this._9k.add(t), t;
    },
    removeDrawable: function(t) {
      return t.id ? void this._9k.remove(t) : this._9k.removeById(t);
    },
    _9k: null,
    invalidate: function() {
      this._mmc();
    },
    _mmc: function() {
      this._d5._6k || this._j5();
    },
    _j5: function() {
      css_m8CSS(this._jn, "transform", "");
      var t = this._d5._l5, e = this.g;
      e.setTransform(1, 0, 0, 1, 0, 0), e.clearRect(0, 0, this._jn.width, this._jn.height), e.save(), this._d5._jp._mkv(e);
      for (var i = this._9k._jf, n = 0, o = i.length; o > n; n++)
        e.save(), e.beginPath(), this._gu(e, i[n], t), e.restore();
      e.restore();
    },
    _gu: function(t, e, i) {
      return e instanceof Function ? void e(t, i) : void (e.drawable instanceof Function && e.scope && e.drawable.call(e.scope, t, i));
    }
  }, Defaults.ZOOM_ANIMATE = true;
  var PanAnimation = function(t) {
    this._l6 = t;
  };
  Defaults.ANIMATION_MAXTIME = 600, Defaults.ANIMATION_TYPE = Easing.easeOut, PanAnimation.prototype = {
    _l6: null,
    _mk: 1e-3,
    _fd: null,
    _mmx: function(t) {
      return t > 1 ? 1 : -1 > t ? -1 : t;
    },
    _fl: function(t, e) {
      t *= 0.6, e *= 0.6, t = this._mmx(t), e = this._mmx(e), this._ll();
      var i = Math.sqrt(t * t + e * e);
      if (0.01 > i)
        return false;
      var n = Math.min(Defaults.ANIMATION_MAXTIME, i / this._mk);
      this._speedX = t, this._speedY = e, this._mkX = t / n, this._mkY = e / n, this._fd = new FrameAnimation(this._6j, this, n, Easing.easeOutStrong), this._fd._km();
    },
    _6j: function(t, e) {
      if (0 != t) {
        var i = this._speedX * e - 0.5 * this._mkX * e * e, n = this._speedY * e - 0.5 * this._mkY * e * e;
        this._speedX -= this._mkX * e, this._speedY -= this._mkY * e, this._l6.translate(i, n);
      }
    },
    _ll: function() {
      this._fd && this._fd._ll();
    },
    _in: function(t) {
      var e = this._fromTX + (this._toTX - this._fromTX) * t, i = this._fromTY + (this._toTY - this._fromTY) * t, n = this._fromScale + (this._toScale - this._fromScale) * t;
      this._l6.translateTo(e, i, n);
    },
    _l7: function(t, e, i, n) {
      var o = this._l6, s = o.scale;
      if (0 >= i && (i = s), this._ll(), t != o.tx || e != o.ty || i != s) {
        var r, a, h;
        n instanceof Object && (r = n.duration, a = n.maxTime, h = n.animationType);
        var l = o.tx, _ = o.ty;
        if (!r) {
          var u = calculateDistance(t, e, l, _);
          if (r = u / 2, i != s) {
            var d = i > s ? i / s : s / i;
            r = Math.max(r, 50 * d);
          }
        }
        a = a || Defaults.ANIMATION_MAXTIME, h = h || Defaults.ANIMATION_TYPE, r = Math.min(a, r), this._fromTX = l, this._fromTY = _, this._fromScale = s, this._toTX = t, this._toTY = e, this._toScale = i, this._fd = new FrameAnimation(this._in, this, r, h), this._fd._km();
      }
    }
  }, Defaults.INTERACTION_HANDLER_SIZE_TOUCH = 8, Defaults.INTERACTION_HANDLER_SIZE_DESKTOP = 4, Defaults.INTERACTION_ROTATE_HANDLER_SIZE_TOUCH = 30, Defaults.INTERACTION_ROTATE_HANDLER_SIZE_DESKTOP = 20;
  var QUARTER_PI = Math.PI / 4;
  DrawableInteraction.prototype = {
    onElementRemoved: function(t, e) {
      this.element && (t == this.element || _ig(t) && containsInArray(t, this.element)) && this.destroy(e);
    },
    onClear: function(t) {
      this.element && this.destroy(t);
    },
    destroy: function() {
      delete this.element, this.removeDrawable();
    },
    invalidate: function() {
      this.topCanvas.invalidate();
    },
    removeDrawable: function() {
      this._fgId && (this.topCanvas.removeDrawable(this._fgId), delete this._fgId, this.invalidate());
    },
    addDrawable: function() {
      this._fgId || (this._fgId = this.topCanvas.addDrawable(this.doDraw, this).id, this.invalidate());
    },
    doDraw: function() {
    },
    escapable: true,
    onkeydown: function(t, e) {
      this.escapable && 27 == t.keyCode && (_f1(t), this.destroy(e));
    }
  }, Q2.ResizeInteraction = ResizeInteraction, InteractionMode.prototype = {
    defaultCursor: "default",
    getInteractionInstances: function(t) {
      if (!this.interactions)
        return null;
      for (var e = [], i = 0, n = this.interactions.length; n > i; i++) {
        var o = this.interactions[i];
        o instanceof Function ? e.push(new o(t)) : o instanceof Object && e.push(o);
      }
      return e;
    }
  }, CreatePathInteraction.prototype = {
    _e7: null,
    _ji: null,
    destroy: function() {
      _hr(this, CreatePathInteraction, "destroy", arguments), delete this._ji, delete this._9g, delete this._e7;
    },
    doDraw: function(t) {
      var e = this.points;
      e && (e.forEach(function(e2) {
        this.drawPoint(t, e2);
      }, this), this.isClosePath && t.closePath(), this.styleDraw(t));
    },
    styleDraw: function(t) {
      var e = mixDrawProperties(this.graph.interactionProperties, this.getDefaultDrawStyles(this.graph));
      e.lineWidth && (t.lineWidth = e.lineWidth, e.lineCap && (t.lineCap = e.lineCap), e.lineJoin && (t.lineJoin = e.lineJoin), e.lineDash && (t.lineDash = e.lineDash, t.lineDashOffset = e.lineDashOffset || 0), t.strokeStyle = e.strokeStyle, t.stroke()), e.fillStyle && (t.fillStyle = e.fillStyle, t.fill());
    },
    drawPoint: function(t, e, i) {
      if (i)
        return void t.moveTo(e.x, e.y);
      if (Q2.isArray(e)) {
        var n = e[0], o = e[1];
        t.quadraticCurveTo(n.x, n.y, o.x, o.y);
      } else
        t.lineTo(e.x, e.y);
    },
    _fw: function(t) {
      this._ji || (this._ji = [], this.addDrawable()), this._ji.push(t), this.invalidate();
    }
  }, _4u(CreatePathInteraction.prototype, {
    currentPoint: {
      get: function() {
        return this._9g;
      },
      set: function(t) {
        this._9g = t, this.invalidate();
      }
    },
    points: {
      get: function() {
        return this._9g && this._ji && this._ji.length ? this._ji.concat(this._9g) : void 0;
      }
    }
  }), _jq(CreatePathInteraction, DrawableInteraction), CreateEdgeInteraction.prototype = {
    destroy: function() {
      _hr(this, CreateEdgeInteraction, "destroy", arguments), delete this._kmTime, delete this.start;
    },
    doDraw: function(t, e) {
      return this._ji ? this._ji.length <= 1 ? CreateSimpleEdgeInteraction.prototype.doDraw.call(this, t, e) : void _hr(this, CreateEdgeInteraction, "doDraw", arguments) : void 0;
    },
    ondblclick: function(t, e) {
      this.destroy(e);
    },
    finish: function(t, e, i) {
      if (this._kmTime && Date.now() - this._kmTime < 200)
        return void this.destroy(e);
      var n;
      this._ji && this._ji.length >= 2 && (this._ji.shift(), n = new HashList(), _ic(
        this._ji,
        function(t2) {
          if (Q2.isArray(t2)) {
            var e2 = t2[0], i2 = t2[1];
            n.add(new PathSegment(Consts.SEGMENT_QUAD_TO, [e2.x, e2.y, i2.x, i2.y]));
          } else
            n.add(new PathSegment(Consts.SEGMENT_LINE_TO, [t2.x, t2.y]));
        },
        this
      )), e.createEdgeByInteraction(this.start, i, t, n), this.destroy(e);
    },
    onstart: function(t, e) {
      if (2 != t.button) {
        var i = t.getData();
        if (this.start) {
          var n = i instanceof Node && e.canLinkTo(i, this.start);
          return n ? void this.finish(t, e, i) : void this._fw(e.toLogical(t));
        }
        var o = i instanceof Node && e.canLinkFrom(i);
        o && (this.start = i, this._kmTime = Date.now(), this._fw(e.toLogical(t)));
      }
    },
    onmousemove: function(t, e) {
      this.start && (this.currentPoint = e.toLogical(t));
    },
    startdrag: function(t) {
      this.start && (t.responded = true);
    },
    ondrag: function(t, e) {
      this.start && (this.currentPoint = e.toLogical(t));
    },
    enddrag: function(t, e) {
      if (this.start) {
        var i = t.getData(), n = i instanceof Node && e.canLinkTo(i, this.start);
        n && this.finish(t, e, i);
      }
    },
    getDefaultDrawStyles: function() {
      return {
        lineWidth: this.graph.getDefaultStyle(Styles.EDGE_WIDTH),
        strokeStyle: this.graph.getDefaultStyle(Styles.EDGE_COLOR),
        lineDash: this.graph.getDefaultStyle(Styles.EDGE_LINE_DASH),
        lineDashOffset: this.graph.getDefaultStyle(Styles.EDGE_LINE_DASH_OFFSET),
        lineCap: this.graph.getDefaultStyle(Styles.LINE_CAP),
        lineJoin: this.graph.getDefaultStyle(Styles.LINE_JOIN)
      };
    }
  }, _jq(CreateEdgeInteraction, CreatePathInteraction), CreateShapeInteraction.prototype = {
    getDefaultDrawStyles: function() {
      return {
        lineWidth: this.graph.getDefaultStyle(Styles.SHAPE_STROKE),
        strokeStyle: this.graph.getDefaultStyle(Styles.SHAPE_STROKE_STYLE),
        fillStyle: this.graph.getDefaultStyle(Styles.SHAPE_FILL_COLOR)
      };
    },
    finish: function(t, e) {
      if (this._ji && this._ji.length) {
        var i = this._ji, n = 0, o = 0, s = 0;
        i.forEach(function(t2) {
          return Q2.isArray(t2) ? void t2.forEach(function() {
            n += t2.x, o += t2.y, s++;
          }) : (n += t2.x, o += t2.y, void s++);
        }), n /= s, o /= s;
        var r = [];
        i.forEach(function(t2, e2) {
          if (0 == e2)
            return void r.push(new PathSegment(Consts.SEGMENT_MOVE_TO, [t2.x - n, t2.y - o]));
          if (Q2.isArray(t2)) {
            var i2 = t2[0], s2 = t2[1];
            r.push(new PathSegment(Consts.SEGMENT_QUAD_TO, [i2.x - n, i2.y - o, s2.x - n, s2.y - o]));
          } else
            r.push(new PathSegment(Consts.SEGMENT_LINE_TO, [t2.x - n, t2.y - o]));
        }), this.createElement(t, r, n, o), this.destroy(e);
      }
    },
    startdrag: function(t) {
      t.responded = true;
    },
    createElement: function(t, e, i, n) {
      return this.graph.createShapeByInteraction(t, e, i, n);
    },
    onstart: function(t, e) {
      var i = e.toLogical(t);
      this._e7 = i, this._fw(i);
    },
    onmousemove: function(t, e) {
      this._e7 && (this.currentPoint = e.toLogical(t));
    },
    ondblclick: function(t, e) {
      if (this._e7) {
        if (this._ji.length < 3)
          return void this.destroy(e);
        delete this._ji[this._ji.length - 1], this.finish(t, e);
      }
    },
    isClosePath: true
  }, _jq(CreateShapeInteraction, CreatePathInteraction), Q2.CreateShapeInteraction = CreateShapeInteraction, CreateLineInteraction.prototype = {
    isClosePath: false,
    createElement: function(t, e, i, n) {
      return this.graph.createLineByInteraction(t, e, i, n);
    },
    getDefaultDrawStyles: function() {
      return {
        lineWidth: DefaultStyles[Styles.SHAPE_STROKE],
        strokeStyle: DefaultStyles[Styles.SHAPE_STROKE_STYLE],
        lineDash: this.graph.getDefaultStyle(Styles.SHAPE_LINE_DASH),
        lineDashOffset: this.graph.getDefaultStyle(Styles.SHAPE_LINE_DASH_OFFSET),
        lineCap: this.graph.getDefaultStyle(Styles.LINE_CAP),
        lineJoin: this.graph.getDefaultStyle(Styles.LINE_JOIN)
      };
    }
  }, _jq(CreateLineInteraction, CreateShapeInteraction), Q2.CreateLineInteraction = CreateLineInteraction, CreateSimpleEdgeInteraction.prototype = {
    destroy: function(t) {
      _hr(this, CreateSimpleEdgeInteraction, "destroy", arguments), t.cursor = "", this.start = null;
    },
    doDraw: function(t) {
      if (this.start && this.currentPoint) {
        var e, i;
        this.graph.interactionProperties && (e = this.graph.interactionProperties.uiClass, i = this.graph.interactionProperties.edgeType), e = e || this.graph.edgeUIClass || Q2.EdgeUI, i = i || this.graph.edgeType;
        var n = e.drawReferenceLine || Q2.EdgeUI.drawReferenceLine, o = this.graph.getUI(this.start);
        o && o.bodyBounds && (o = o.bodyBounds.center, n(t, o, this.currentPoint, i), this.styleDraw(t));
      }
    },
    canLinkFrom: function(t, e) {
      return t instanceof Node && e.canLinkFrom(t);
    },
    canLinkTo: function(t, e) {
      return t instanceof Node && e.canLinkTo(t, this.start);
    },
    startdrag: function(t, e) {
      var i = t.getData();
      this.canLinkFrom(i, e) && (t.responded = true, this.start = i, e.cursor = "crosshair", this.addDrawable());
    },
    ondrag: function(t, e) {
      this.start && (Q2.stopEvent(t), this.currentPoint = e.toLogical(t), this.invalidate());
    },
    enddrag: function(t, e) {
      if (this.start) {
        this.invalidate();
        var i = t.getData();
        this.canLinkTo(i, e) && e.createEdgeByInteraction(this.start, i, t), this.destroy(e);
      }
    },
    getDefaultDrawStyles: function() {
      return {
        lineWidth: this.graph.getDefaultStyle(Styles.EDGE_WIDTH),
        strokeStyle: this.graph.getDefaultStyle(Styles.EDGE_COLOR),
        lineDash: this.graph.getDefaultStyle(Styles.EDGE_LINE_DASH),
        lineDashOffset: this.graph.getDefaultStyle(Styles.EDGE_LINE_DASH_OFFSET),
        lineCap: this.graph.getDefaultStyle(Styles.LINE_CAP),
        lineJoin: this.graph.getDefaultStyle(Styles.LINE_JOIN)
      };
    }
  }, _jq(CreateSimpleEdgeInteraction, CreatePathInteraction), Q2.CreateSimpleEdgeInteraction = CreateSimpleEdgeInteraction, Defaults.LABEL_EDITOR_SUBMIT_WHEN_LOST_FOCUS = false, LabelEditor.prototype = {
    html: null,
    createHTML: function() {
      var t = document2.createElement("textarea");
      t.className = "Q-LabelEditor", t.style.position = "absolute", t.style.textAlign = "center", t.style.border = "solid #08E 1px", t.style.padding = "5px", t.style.boxShadow = "0px 0px 10px rgba(40, 85, 184, 0.75)", t.style.display = "none", t.style.overflow = "hidden";
      var e = this;
      return t.oninput = function(t2) {
        e.onValueChange(t2);
      }, t.onkeydown = function(t2) {
        return 27 == t2.keyCode ? void e.cancelEdit() : void 0;
      }, t.onkeypress = function(i) {
        if (13 == i.keyCode || 10 == i.keyCode) {
          if (i.preventDefault(), i.altKey || i.ctrlKey || i.shiftKey)
            return pasteIntoInput(t, "\n"), void e.onValueChange(i);
          e.stopEdit();
        }
      }, document2.body.appendChild(t), t;
    },
    setText: function(t, e) {
      this.html.value = t || "", e && (this.html.style.fontSize = e), selectInput(this.html), this.onSizeChange(this.html);
    },
    onSizeChange: function(t) {
      var e = (t.offsetWidth, t.offsetHeight, getLabelSize(t));
      return t.style.width = e.width + 30 + "px", t.style.height = e.height + 10 + "px", e;
    },
    onValueChange: function(t) {
      {
        var e = t.target;
        this.onSizeChange(e);
      }
      e.style.left = e.x - e.offsetWidth / 2 + "px";
    },
    onClickOnWindow: function(t) {
      t.target != this.html && (Defaults.LABEL_EDITOR_SUBMIT_WHEN_LOST_FOCUS ? this.stopEdit() : this.cancelEdit());
    },
    startEdit: function(t, e, i, n, o) {
      this.html || (this.html = this.createHTML()), this.stopEditWhenClickOnWindow || (this.stopEditWhenClickOnWindow = function(t2) {
        this.onClickOnWindow(t2);
      }.bind(this)), window2.addEventListener("mousedown", this.stopEditWhenClickOnWindow, true), this.callback = o, this.html.x = t, this.html.y = e, this.html.style.display = "block", showDivCenterAt(this.html, t, e), this.setText(i, n || 10), showDivCenterAt(this.html, t, e);
    },
    isEditing: function() {
      return "none" != this.html.style.display;
    },
    cancelEdit: function() {
      this.stopEdit(true);
    },
    stopEdit: function(t) {
      if (this.isEditing()) {
        window2.removeEventListener("mousedown", this.stopEditWhenClickOnWindow);
        var e = this.html.value;
        if (!t && this.callback && this.callback(e) === false)
          return false;
        this.html.style.display = "none", this.html.value = null, this.callback = null;
      }
    },
    destroy: function() {
      this.html && document2.body.removeChild(this.html);
    }
  }, Q2.LabelEditor = LabelEditor;
  var DoubleClickInteraction = function(t) {
    this.graph = t;
  };
  DoubleClickInteraction.prototype = {
    destroy: function(t) {
      t.labelEditor && (t.labelEditor.destroy(), delete t.labelEditor);
    },
    ondblclick: function(t, e) {
      var i = t.getData();
      if (!i)
        return e.currentSubNetwork ? void e.upSubNetwork() : void (e.enableDoubleClickToOverview && e.zoomToOverview(Defaults.ZOOM_ANIMATE));
      if (e.editable && e.isEditable(i)) {
        var n = e.hitTest(t);
        if (n instanceof LabelUI && n.editable !== false) {
          var o = e.labelEditor;
          o || (e.labelEditor = o = new LabelEditor());
          var s = n.getBounds();
          return s = e.toCanvas(s.x + s.width / 2, s.y + s.height / 2), s = localToGlobal(s.x, s.y, e.html), void e.startLabelEdit(i, n, o, s);
        }
      }
      var r = i instanceof Group, a = i instanceof Edge && i.hasEdgeBundle();
      return i._4q && (isMetaKey(t) || !r && !a) ? void (e.currentSubNetwork = i) : r ? void (i.expanded = !i.expanded) : a ? void this.graph.reverseExpanded(i) : void 0;
    }
  };
  var EditInteraction = function(t) {
    this.graph = t;
  };
  EditInteraction.prototype = {
    onkeydown: function(t, e) {
      if (e.editable) {
        var i = t.keyCode;
        if (8 == i || 46 == i || 127 == i)
          return e.removeSelectionByInteraction(t), void _2p(t);
        if (isMetaKey(t)) {
          if (67 == i)
            ;
          else if (86 == i)
            ;
          else if (90 == i)
            ;
          else if (89 != i)
            return;
          _2p(t);
        }
      }
    }
  }, Q2.EditInteraction = EditInteraction;
  var ExportInteraction = function(t) {
    this.graph = t;
  };
  ExportInteraction.prototype = {
    onkeydown: function(t, e) {
      if (t.metaKey && 83 == t.keyCode) {
        var i = e.exportImage(e.scale, e.viewportBounds), n = window2.open(), o = n.document;
        o.title = "export image - " + i.width + " x " + i.height;
        var s = o.createElement("img");
        s.src = i.data, o.body.appendChild(s), _2p(t);
      }
    }
  };
  var MoveInteraction = function(t) {
    this.graph = t;
  };
  MoveInteraction.prototype = {
    destroy: function() {
      delete this.draggingElements, delete this.currentDraggingElement;
    },
    _2s: function(t) {
      var e = new HashList();
      return t.selectionModel.forEach(function(i) {
        t.isMovable(i) && t.isVisible(i) && e.add(i);
      }, this), e;
    },
    onstart: function(t, e) {
      this.currentDraggingElement && this.destroy(e);
    },
    startdrag: function(t, e) {
      if (!t.responded) {
        var i = t.getData();
        if (!i || !e.isSelected(i) || !e.isMovable(i))
          return void this.destroy(e);
        t.responded = true, this.currentDraggingElement = i, this.draggingElements = this._2s(e);
        var n = new InteractionEvent(
          e,
          InteractionEvent.ELEMENT_MOVE_START,
          t,
          this.currentDraggingElement,
          this.draggingElements.datas
        );
        return e.beforeInteractionEvent(n) === false ? void this.destroy(e) : void e.onInteractionEvent(n);
      }
    },
    ondrag: function(t, e) {
      if (this.currentDraggingElement) {
        _f1(t);
        var i = t.dx, n = t.dy, o = e.scale;
        i /= o, n /= o;
        var s = new InteractionEvent(
          e,
          InteractionEvent.ELEMENT_MOVING,
          t,
          this.currentDraggingElement,
          this.draggingElements.datas
        );
        e.moveElements(this.draggingElements.datas, i, n), e.onInteractionEvent(s);
      }
    },
    enddrag: function(t, e) {
      if (this.currentDraggingElement) {
        if (this.draggingElements && this.draggingElements.length) {
          if (t.shiftKey) {
            var i, n = e.toLogical(t), o = n.x, s = n.y;
            e.forEachReverseVisibleUI(function(t2) {
              var e2 = t2.data;
              if (!this.draggingElements.contains(e2) && t2.uiBounds.intersectsPoint(o - t2.x, s - t2.y) && t2._hq(o, s, 1)) {
                if (e2 instanceof Q2.Edge) {
                  if (!e2.enableSubNetwork)
                    return;
                  for (var n2 = this.draggingElements.length; n2-- > 0; ) {
                    var r2 = this.draggingElements.get(n2);
                    if (r2 instanceof Q2.Node && r2.linkedWith(e2))
                      return;
                  }
                  return i = e2, false;
                }
                return (e2.enableSubNetwork || e2._i7() && e2.expanded) && (i = e2), false;
              }
            }, this), i && this.draggingElements.forEach(function(t2) {
              for (var e2 = t2.parent; e2; ) {
                if (this.draggingElements.contains(e2))
                  return;
                e2 = e2.parent;
              }
              t2.parent = i;
            }, this);
          }
          var r = new InteractionEvent(
            e,
            InteractionEvent.ELEMENT_MOVE_END,
            t,
            this.currentDraggingElement,
            this.draggingElements.datas
          );
          e.onInteractionEvent(r);
        }
        this.destroy(e);
      }
    },
    onpinch: function(t, e) {
      this.currentDraggingElement && this.enddrag(t, e);
    },
    step: 1,
    onkeydown: function(t, e) {
      if (isMetaKey(t)) {
        var i, n;
        if (37 == t.keyCode ? i = -1 : 39 == t.keyCode ? i = 1 : 38 == t.keyCode ? n = -1 : 40 == t.keyCode && (n = 1), i || n) {
          var o = this._2s(e).datas;
          if (0 != o.length) {
            _2p(t), i = i || 0, n = n || 0;
            var s = this.step / e.scale, r = new InteractionEvent(e, InteractionEvent.ELEMENT_MOVE_END, t, null, o);
            e.moveElements(o, i * s, n * s), e.onInteractionEvent(r);
          }
        }
      }
    }
  };
  var PanInteraction = function(t) {
    this.graph = t;
  };
  PanInteraction.prototype = {
    onkeydown: function(t, e) {
      isMetaKey(t) || (37 == t.keyCode ? (this._5t(e, 1, 0), _2p(t)) : 39 == t.keyCode ? (this._5t(e, -1, 0), _2p(t)) : 38 == t.keyCode ? (this._5t(e, 0, 1), _2p(t)) : 40 == t.keyCode && (this._5t(e, 0, -1), _2p(t)));
    },
    _5t: function(t, e, i) {
      t._mk4(e, i);
    },
    onstart: function(t, e) {
      this._km && this.destroy(e);
    },
    _km: false,
    startdrag: function(t, e) {
      t.responded || (t.responded = true, this._km = true, e.cursor = CURSOR_GRABBING);
    },
    ondrag: function(t, e) {
      this._km && (_f1(t), e.translate(t.dx || 0, t.dy || 0));
    },
    enddrag: function(t, e) {
      if (this._km) {
        if (e.enableInertia !== false) {
          var i = t.vx, n = t.vy;
          (Math.abs(i) > 0.1 || Math.abs(n) > 0.1) && e._mk4(i, n);
        }
        this.destroy(e);
      }
    },
    onpinch: function(t, e) {
      this._km = true;
      var i = t.dScale;
      if (i && 1 != i) {
        var n = e.globalToLocal(t.center);
        e.zoomAt(i, n.x, n.y, false);
      }
    },
    destroy: function(t) {
      this._km = false, t.cursor = null;
    }
  }, PointsInteraction.prototype = {
    _1p: function(t) {
      this.element && t.source == this.element && this.graph.callLater(function() {
        this._jl();
      }, this);
    },
    _8: function() {
      this._lcPropertyChangeListing || (this._lcPropertyChangeListing = true, this.graph.dataPropertyChangeDispatcher.addListener(this._1p, this));
    },
    _5: function() {
      this._lcPropertyChangeListing = false, this.graph.dataPropertyChangeDispatcher.removeListener(this._1p, this);
    },
    onElementRemoved: function(t, e) {
      this.element && (t == this.element || _ig(t) && containsInArray(t, this.element)) && this.destroy(e);
    },
    onClear: function(t) {
      this.element && this.destroy(t);
    },
    destroy: function() {
      this.graph.cursor = null, this.element && delete this.element._editting, delete this.element, delete this._9x, delete this._9g, delete this._mmanEdit, this._80(), this._5();
    },
    _80: function() {
      this.drawLineId && (this.topCanvas.removeDrawable(this.drawLineId), delete this.drawLineId, this.topCanvas.invalidate());
    },
    _mo5: function() {
      this.drawLineId && this.topCanvas.contains(this.drawLineId) || (this.drawLineId = this.topCanvas.addDrawable(this.drawLine, this).id, this.topCanvas.invalidate());
    },
    _9x: null,
    _67: function(t) {
      this._9x = t, this.invalidate();
    },
    _es: function(t, e, i) {
      t.beginPath(), e.isControlPoint ? t.rect(
        e.x - this.handlerSize / i,
        e.y - this.handlerSize / i,
        this.handlerSize / i * 2,
        this.handlerSize / i * 2
      ) : t.arc(e.x, e.y, this.handlerSize / i, 0, 2 * Math.PI, false), t.lineWidth = 1 / i, t.lineDash = [], t.strokeStyle = "#888", t.fillStyle = "rgba(255, 255, 0, 0.8)", t.stroke(), t.fill();
    },
    _fg: function(t, e, i, n) {
      n ? t.moveTo(e, i) : t.lineTo(e, i);
    },
    drawLine: function(t, e) {
      if (this._9x && this._9x.length) {
        t.save();
        var i = this.element instanceof ShapeNode;
        i && (t.translate(this.element.x, this.element.y), this.element.rotate && t.rotate(this.element.rotate));
        var n, o = [];
        t.beginPath();
        {
          this._9x.length;
        }
        _ic(
          this._9x,
          function(e2) {
            if (e2.type != Consts.SEGMENT_CLOSE)
              for (var i2 = 0, s = e2.points; i2 + 1 < s.length; ) {
                var r = s[i2], a = s[i2 + 1], h = { x: r, y: a, isControlPoint: this._6l(e2, i2) };
                o.push(h), this._fg(t, h.x, h.y, null == n), n = h, i2 += 2;
              }
          },
          this
        ), t.lineWidth = 1 / e, t.lineDash = [2 / e, 3 / e], t.strokeStyle = "#555", t.stroke(), _ic(
          o,
          function(i2) {
            this._es(t, i2, e);
          },
          this
        ), t.restore();
      }
    },
    invalidate: function() {
      this.topCanvas.invalidate();
    },
    _42: function(t) {
      if (this.element != t && (this.element && this.destroy(), t && this.isEditable(t))) {
        var e = this._6b(t, this.graph);
        e && (this.element = t, t._editting = true, this._mmanEdit = true, this._67(e), this._8(), this._mo5());
      }
    },
    _jl: function() {
      if (this.drawLineId && this.element) {
        var t = this._6b(this.element, this.graph);
        return t ? void this._67(t) : void this.destroy(this.graph);
      }
    },
    _6b: function(t, e) {
      return e.isEditable(t) ? t.pathSegments || [] : void 0;
    },
    _hu: function(t, e) {
      t -= this.element.x, e -= this.element.y;
      var i = { x: t, y: e };
      return this.element.rotate && transformPoint(i, -this.element.rotate), i;
    },
    onclick: function(t, e) {
      if (e.editable && t.altKey && this.element) {
        var i = this._fj(t, e);
        if (i && i.isControlPoint)
          return void this.element.removePathSegmentByIndex(i.index);
        if (this.element == t.getData()) {
          var n = e.toLogical(t), o = e.getUI(this.element);
          o.addPoint(n.x, n.y, this.handlerSize || 2);
        }
      }
    },
    isEditable: function(t) {
      return this.graph.isEditable(t) && (t instanceof Edge || t instanceof ShapeNode);
    },
    ondblclick: function(t, e) {
      if (!e.editable)
        return void (this.element && this.destroy(e));
      var i = t.getData();
      return !i || i == this.element || i._editting ? void this.destroy(e) : void this._42(i);
    },
    onstart: function(t, e) {
      if (!e.editable)
        return void (this.element && this.destroy(e));
      if (!t.responded) {
        if (this.element && this._fj(t, e))
          return void (t.responded = true);
        var i = t.getData();
        return i && e.isResizable(i) && i instanceof ShapeNode ? void (this.element && i != this.element && this.destroy()) : void this._42(i);
      }
    },
    onrelease: function() {
      this.element && (this._mmanEdit = true);
    },
    _9g: null,
    _fj: function(t, e) {
      var i = e.toLogical(t);
      this.element instanceof ShapeNode && (i = this._hu(i.x, i.y));
      var n, o = e.scale, s = this.handlerSize / o, r = this._9x;
      return _ic(
        r,
        function(t2, e2) {
          for (var o2 = 0, a = t2.points; o2 + 1 < a.length; ) {
            var h = a[o2], l = a[o2 + 1], _ = calculateDistance(i.x, i.y, h, l);
            if (s > _) {
              if (n = { segment: t2, index: e2, pointIndex: o2 }, this._6l(t2, o2)) {
                n.isControlPoint = true;
                var u = r instanceof HashList ? r.getByIndex(e2 + 1) : r[e2 + 1];
                u && (n.nextSegment = u);
              }
              return false;
            }
            o2 += 2;
          }
        },
        this
      ), n;
    },
    _6l: function(t, e) {
      return e == t.points.length - 2;
    },
    startdrag: function(t, e) {
      if (this.element && this._mmanEdit && (this._9g = this._fj(t, e), this._9g)) {
        this._80(), t.responded = true;
        var i = new InteractionEvent(e, InteractionEvent.POINT_MOVE_START, t, this.element);
        i.point = this._9g, e.onInteractionEvent(i);
      }
    },
    ondrag: function(t, e) {
      if (this.element && this._9g) {
        var i = t.dx, n = t.dy, o = e.scale;
        if (i /= o, n /= o, this.element.rotate) {
          var s = { x: i, y: n };
          transformPoint(s, -this.element.rotate), i = s.x, n = s.y;
        }
        var r = this._9g.segment;
        if (!this._9g.isControlPoint || r.type != QUAD_TO && r.type != CURVE_TO)
          r.points[this._9g.pointIndex] += i, r.points[this._9g.pointIndex + 1] += n;
        else {
          for (var a = r.points.length - 4; a < r.points.length; )
            r.points[a] += i, r.points[a + 1] += n, a += 2;
          !this._9g.nextSegment || this._9g.nextSegment.type != CURVE_TO && this._9g.nextSegment.type != QUAD_TO || (this._9g.nextSegment.points[0] += i, this._9g.nextSegment.points[1] += n);
        }
        this.element.firePathChange();
        var h = new InteractionEvent(e, InteractionEvent.POINT_MOVING, t, this.element);
        h.point = this._9g, e.onInteractionEvent(h);
      }
    },
    enddrag: function(t, e) {
      if (this.element && this._9g) {
        this._mo5(), this._jl();
        var i = new InteractionEvent(e, InteractionEvent.POINT_MOVE_END, t, this.element);
        i.point = this._9g, e.onInteractionEvent(i);
      }
    },
    onmousemove: function(t, e) {
      this.element && (e.cursor = t.altKey && (this._fj(t, e) || this.element == t.getData()) ? "crosshair" : null);
    }
  }, Defaults.SELECTION_RECTANGLE_STROKE = 1, Defaults.SELECTION_RECTANGLE_STROKE_COLOR = _ia(3724541951), Defaults.SELECTION_RECTANGLE_FILL_COLOR = _ia(1430753245);
  var RectangleSelectionInteraction = function(t) {
    this.graph = t, this.topCanvas = t._94._topCanvas;
  };
  RectangleSelectionInteraction.prototype = {
    onstart: function(t, e) {
      this._km && this.destroy(e);
    },
    startdrag: function(t, e) {
      t.responded || (t.responded = true, this._km = e.toLogical(t), e.cursor = "crosshair", this._1gId = this.topCanvas.addDrawable(this._1g, this).id);
    },
    ondrag: function(t, e) {
      if (this._km) {
        _f1(t), this._end = e.toLogical(t), this.invalidate();
        var i = new InteractionEvent(e, InteractionEvent.SELECT_START, t, e.selectionModel);
        e.onInteractionEvent(i);
      }
    },
    enddrag: function(t, e) {
      if (this._km) {
        this._fzTimer && (clearTimeout(this._fzTimer), this._fzTimer = null), this._fz(true), this.destroy(e);
        var i = new InteractionEvent(e, InteractionEvent.SELECT_END, t, e.selectionModel);
        e.onInteractionEvent(i);
      }
    },
    onpinch: function(t, e) {
      this._km && this.enddrag(t, e);
    },
    _1g: function(t, e) {
      t.strokeStyle = Defaults.SELECTION_RECTANGLE_STROKE_COLOR, t.fillStyle = Defaults.SELECTION_RECTANGLE_FILL_COLOR, t.lineWidth = Defaults.SELECTION_RECTANGLE_STROKE / e;
      var i = this._km.x, n = this._km.y;
      t.rect(i, n, this._end.x - i, this._end.y - n), t.fill(), t.stroke();
    },
    invalidate: function() {
      return this.invalidateFlag ? void this.topCanvas.invalidate() : (this.invalidateFlag = true, void (this._fzTimer = setTimeout(this._fz.bind(this), 100)));
    },
    _fz: function(t) {
      if (this.invalidateFlag = false, this._fzTimer = null, !this._km || isIE10 && !t)
        return void this.topCanvas.invalidate();
      var e = Math.min(this._km.x, this._end.x), i = Math.min(this._km.y, this._end.y), n = Math.abs(this._km.x - this._end.x), o = Math.abs(this._km.y - this._end.y);
      if (!n || !o)
        return void this.graph.selectionModel.clear();
      var s, r = [], a = this.graph.scale;
      if (this.graph.forEachVisibleUI(function(t2) {
        t2._hw && this.graph.isSelectable(t2.$data) && (s = t2._fu, (containsRect(e, i, n, o, s.x + t2._x, s.y + t2._y, s.width, s.height) || UIHitTestByBoundsAbsolute(e, i, n, o, t2, a)) && r.push(t2.$data));
      }, this), this.graph.selectionModel.set(r), this.topCanvas.invalidate(), !t) {
        var h = new InteractionEvent(this.graph, InteractionEvent.SELECT_BETWEEN, null, this.graph.selectionModel);
        this.graph.onInteractionEvent(h);
      }
    },
    destroy: function(t) {
      this._km = null, t.cursor = null, this._1gId && (this.topCanvas.removeDrawable(this._1gId), delete this._1gId, this.topCanvas.invalidate());
    }
  };
  var QUARTER_PI = Math.PI / 4;
  ResizeInteraction.prototype = {
    _f7: false,
    _f8: false,
    _1p: function(t) {
      this.element && t.source == this.element && this.graph.callLater(function() {
        this._9i();
      }, this);
    },
    _8: function() {
      this._lcPropertyChangeListing || (this._lcPropertyChangeListing = true, this.graph.dataPropertyChangeDispatcher.addListener(this._1p, this));
    },
    _5: function() {
      this._lcPropertyChangeListing = false, this.graph.dataPropertyChangeDispatcher.removeListener(this._1p, this);
    },
    onElementRemoved: function(t, e) {
      this.element && (t == this.element || _ig(t) && containsInArray(t, this.element)) && this.destroy(e);
    },
    onClear: function(t) {
      this.element && this.destroy(t);
    },
    ondblclick: function(t, e) {
      this.element && this.destroy(e);
    },
    destroy: function(t) {
      t.cursor = null, delete this.element, delete this._mml, delete this._moody, delete this._9g, delete this._mmanEdit, delete this._ji, delete this._rotatePoint, delete this._f8, delete this._f7, delete this._insets, this._80(), this._5();
    },
    _80: function() {
      this._fgId && (this.topCanvas.removeDrawable(this._fgId), delete this._fgId, this.topCanvas.invalidate());
    },
    _mo5: function() {
      this._fgId && this.topCanvas.contains(this._fgId) || (this._fgId = this.topCanvas.addDrawable(this._fg, this).id, this.topCanvas.invalidate());
    },
    _mml: null,
    _ji: null,
    _8z: function(t) {
      this._mml = t;
      var e = this._mml.x, i = this._mml.y, n = this._mml.width, o = this._mml.height;
      if (this._f8) {
        var s = [];
        s.push({
          x: e,
          y: i,
          p: Position.LEFT_TOP,
          cursor: "nwse-resize",
          rotate: 5 * QUARTER_PI
        }), s.push({
          x: e + n / 2,
          y: i,
          p: Position.CENTER_TOP,
          cursor: "ns-resize",
          rotate: 6 * QUARTER_PI
        }), s.push({
          x: e + n,
          y: i,
          p: Position.RIGHT_TOP,
          cursor: "nesw-resize",
          rotate: 7 * QUARTER_PI
        }), s.push({
          x: e,
          y: i + o / 2,
          p: Position.LEFT_MIDDLE,
          cursor: "ew-resize",
          rotate: 4 * QUARTER_PI
        }), s.push({
          x: e + n,
          y: i + o / 2,
          p: Position.RIGHT_MIDDLE,
          cursor: "ew-resize",
          rotate: 0
        }), s.push({
          x: e,
          y: i + o,
          p: Position.LEFT_BOTTOM,
          cursor: "nesw-resize",
          rotate: 3 * QUARTER_PI
        }), s.push({
          x: e + n / 2,
          y: i + o,
          p: Position.CENTER_BOTTOM,
          cursor: "ns-resize",
          rotate: 2 * QUARTER_PI
        }), s.push({
          x: e + n,
          y: i + o,
          p: Position.RIGHT_BOTTOM,
          cursor: "nwse-resize",
          rotate: QUARTER_PI
        }), this._ji = s;
      }
      this._rotatePoint = this._f7 ? { x: e + n / 2, y: i, cursor: CURSOR_ROTATE } : null, this._mmc();
    },
    _es: function(t, e, i, n) {
      t.beginPath();
      var o = (this.handlerSize - 1) / n;
      t.rect(e - o, i - o, 2 * o, 2 * o), t.lineWidth = 1 / n, t.lineDash = [], t.strokeStyle = "#888", t.fillStyle = "rgba(255, 255, 255, 0.8)", t.stroke(), t.fill();
    },
    _5g: function(t, e, i, n, o, s) {
      o = o || this.handlerSize, s = s || "rgba(0, 255, 0, 1)", t.beginPath(), o /= n, t.arc(e, i, o, 0, 2 * Math.PI, false), t.lineWidth = 1 / n, t.lineDash = [], t.strokeStyle = "#888", t.fillStyle = s, t.stroke(), t.fill();
    },
    _hu: function(t, e) {
      t -= this.element.x, e -= this.element.y;
      var i = { x: t, y: e };
      return this.element.rotate && transformPoint(i, -this.element.rotate), i;
    },
    _fg: function(t, e) {
      if (this._mml) {
        if (t.save(), t.translate(this.element.x, this.element.y), this.element.rotate && t.rotate(this.element.rotate), this._rotatePoint) {
          this._5g(t, 0, 0, e, 3, "#FF0");
          var i = this._rotatePoint.x, n = this._rotatePoint.y - this._rotateHandleLength / e;
          t.beginPath(), t.moveTo(i, this._rotatePoint.y), t.lineTo(i, n), t.lineWidth = 1 / e, t.strokeStyle = "#555", t.stroke(), this._5g(t, i, n, e);
        }
        if (this._ji) {
          var o = this._mml.x, s = this._mml.y, r = this._mml.width, a = this._mml.height;
          t.beginPath(), t.rect(o, s, r, a), t.lineWidth = 1 / e, t.lineDash = [2 / e, 3 / e], t.strokeStyle = "#555", t.stroke(), _ic(
            this._ji,
            function(i2) {
              this._es(t, i2.x, i2.y, e);
            },
            this
          );
        }
        t.restore();
      }
    },
    _mmc: function() {
      this.topCanvas.invalidate();
    },
    _42: function(t, e, i, n) {
      this.element = t, this._mo5();
      var o = e.getUI(t);
      this._moody = o.body, this._f8 = i, this._f7 = n, this._9i(), this._8();
    },
    _9i: function() {
      if (this._fgId) {
        var t = toUIBounds(this._moody, this._moody._j1), e = toUIBounds(this._moody, this._moody._8b);
        this._insets = new Insets(t.y - e.y, t.x - e.x, e.bottom - t.bottom, e.right - t.right), this._8z(e);
      }
    },
    _mom: function(t, e) {
      return (!t._i7() || !t.expanded) && e.isResizable(t);
    },
    _mol: function(t, e) {
      return (!t._i7() || !t.expanded) && e.isRotatable(t);
    },
    _mmo: function(t, e) {
      return t instanceof Node && e.isEditable(t);
    },
    onstart: function(t, e) {
      if (!e.editable)
        return void (this.element && this.destroy(e));
      if (!t.responded) {
        var i = e.getUI(t), n = t.getData();
        if (n != this.element) {
          if (this.element) {
            if (this._fj(t, e))
              return void (t.responded = true);
            this.destroy(e);
          }
          if (n && !n._editting && this._mmo(n, e)) {
            var o = this._mom(n, e, i), s = this._mol(n, e, i);
            (o || s) && this._42(n, e, o, s);
          }
        }
      }
    },
    onrelease: function(t, e) {
      this.element && (this._mmanEdit = true, this._mo5(), e.callLater(function() {
        this._9i();
      }, this));
    },
    _9g: null,
    _fj: function(t, e) {
      var i = e.toLogical(t);
      i = this._hu(i.x, i.y);
      var n = e.scale, o = this.handlerSize / n;
      if (this._rotatePoint) {
        var s = this._rotatePoint.x, r = this._rotatePoint.y - this._rotateHandleLength / n;
        if (calculateDistance(i.x, i.y, s, r) < o)
          return this._rotatePoint;
      }
      if (this._ji && this._ji.length) {
        var a;
        return _ic(
          this._ji,
          function(t2) {
            return calculateDistance(i.x, i.y, t2.x, t2.y) < o ? (a = t2, false) : void 0;
          },
          this
        ), a;
      }
    },
    onmousemove: function(t, e) {
      if (this.element) {
        var i = this._fj(t, e);
        if (!i)
          return void (e.cursor = null);
        if (i != this._rotatePoint && this.element.rotate) {
          var n = i.rotate + this.element.rotate;
          return void (e.cursor = getCursorByAngle(n));
        }
        e.cursor = i.cursor;
      }
    },
    startdrag: function(t, e) {
      if (this.element && (this._80(), this._mmanEdit && (this._9g = this._fj(t, e), this._9g))) {
        if (t.responded = true, this._9g == this._rotatePoint)
          return this._9g.start = e.toLogical(t), void (this._9g.rotate = this.element.rotate || 0);
        var i = new InteractionEvent(e, InteractionEvent.RESIZE_START, t, this.element);
        i.point = this._9g, e.onInteractionEvent(i);
      }
    },
    _83: function(t, e, i, n, o, s) {
      var r = this._mml, a = r.x, h = r.y, l = r.width, _ = r.height;
      if (s) {
        var u = n != l;
        u ? o = n * _ / l : n = o * l / _;
      }
      var d = t.path._fe, c = n / l, f = o / _, E = -a * c + e, g = -h * f + i;
      d.forEach(function(t2) {
        if (t2.type != Consts.SEGMENT_CLOSE) {
          var n2 = t2.points;
          if (n2 && n2.length)
            for (var o2 = 0, s2 = n2.length; s2 > o2; o2 += 2) {
              var r2 = n2[o2], l2 = n2[o2 + 1];
              n2[o2] = (r2 - a) * c + e - E, n2[o2 + 1] = (l2 - h) * f + i - g;
            }
        }
      }), this._mml.set(e - E, i - g, n, o), t.setLocation(t.x + E, t.y + g), t.firePathChange();
    },
    _4x: function(t, e, i, n, o) {
      if (this.element instanceof ShapeNode)
        return this._83(this.element, t, e, i, n, o);
      var s = this._moody instanceof LabelUI;
      if (!s && o) {
        var r = this._mml, a = this._moody.originalBounds, h = i != r.width;
        h ? n = i * a.height / a.width : i = n * a.width / a.height;
      }
      var l = this.element.anchorPosition, _ = new Size(i - this._insets.left - this._insets.right, n - this._insets.top - this._insets.bottom);
      if (_.width < 1 && (i = this._insets.left + this._insets.right + 1, _.width = 1), _.height < 1 && (n = this._insets.top + this._insets.bottom + 1, _.height = 1), s ? this.element.setStyle(Styles.LABEL_SIZE, _) : this.element.size = _, l) {
        var u = _mkr(l, i, n), d = u.x + t - (this._moody.offsetX || 0), c = u.y + e - (this._moody.offsetY || 0);
        if (this._mml.set(t - d, e - c, i, n), this.element.rotate) {
          var u = transformPoint({ x: d, y: c }, this.element.rotate);
          d = u.x, c = u.y;
        }
        this.element.x += d, this.element.y += c;
      } else {
        var d = this._mml.x * i / this._mml.width - t, c = this._mml.y * n / this._mml.height - e;
        if (this._mml.set(t + d, e + c, i, n), this.element.rotate) {
          var u = transformPoint({ x: d, y: c }, this.element.rotate);
          d = u.x, c = u.y;
        }
        this.element.x -= d, this.element.y -= c;
      }
    },
    ondrag: function(t, e) {
      if (this.element && this._9g)
        if (this._9g != this._rotatePoint) {
          var i = t.dx, n = t.dy, o = e.scale;
          if (i /= o, n /= o, this.element.rotate) {
            var s = { x: i, y: n };
            transformPoint(s, -this.element.rotate), i = s.x, n = s.y;
          }
          var r = this._9g.p, a = this._mml, h = a.x, l = a.y, _ = a.width, u = a.height;
          r.horizontalPosition == LEFT ? i >= _ ? (h += _, _ = i - _ || 1) : (h += i, _ -= i) : r.horizontalPosition == RIGHT && (-i >= _ ? (_ = -i - _ || 1, h -= _) : _ += i), r.verticalPosition == TOP ? n >= u ? (l += u, u = n - u || 1) : (l += n, u -= n) : r.verticalPosition == BOTTOM && (-n >= u ? (u = -n - u || 1, l -= u) : u += n), this._4x(h, l, _, u, t.shiftKey);
          var d = new InteractionEvent(e, InteractionEvent.RESIZING, t, this.element);
          d.point = this._9g, e.onInteractionEvent(d);
        } else {
          var s = e.toLogical(t), c = constructThreePoint(s.x, s.y, this.element.x, this.element.y, this._9g.start.x, this._9g.start.y, true);
          c += this._9g.rotate || 0, t.shiftKey && (c = Math.round(c / Math.PI * 4) * Math.PI / 4), this.element.rotate = c % (2 * Math.PI);
          var d = new InteractionEvent(e, InteractionEvent.ROTATING, t, this.element);
        }
    },
    enddrag: function(t, e) {
      if (this.element && this._9g && this._9g != this._rotatePoint) {
        var i = new InteractionEvent(e, InteractionEvent.RESIZE_END, t, this.element);
        i.point = this._9g, e.onInteractionEvent(i);
      }
    }
  }, Q2.ResizeInteraction = ResizeInteraction;
  var SelectionInteraction = function(t) {
    this.graph = t;
  };
  SelectionInteraction.prototype = {
    onstart: function(t, e) {
      if (!t.responded) {
        isTouchSupport || isIE || e.focus(true);
        var i = t.getData();
        if (i && !e.isSelectable(i) && (i = null), i && isMetaKey(t)) {
          e.reverseSelect(i);
          var n = new InteractionEvent(e, InteractionEvent.SELECT, t, e.selectionModel);
          return void e.onInteractionEvent(n);
        }
        if (!i || !e.selectionModel.isSelected(i)) {
          i ? (e.setSelection(i), e.sendToTop(i)) : e.setSelection(null);
          var n = new InteractionEvent(e, InteractionEvent.SELECT, t, e.selectionModel);
          e.onInteractionEvent(n);
        }
      }
    },
    onkeydown: function(t, e) {
      return 27 == t.keyCode ? void e.unSelectAll() : void (isMetaKey(t) && 65 == t.keyCode && (e.selectAll(), _2p(t)));
    }
  };
  var CURSOR_OFFSET_X = 0, CURSOR_OFFSET_Y = 15;
  Defaults.TOOLTIP_DURATION = 3e3, Defaults.TOOLTIP_DELAY = 1e3;
  var tooltipClass = "Q-Tooltip";
  css_m9Rule("." + tooltipClass, {
    "background-color": "#FFFFCA",
    overflow: "hidden",
    "box-shadow": "0 5px 10px rgba(136, 136, 136, 0.5)",
    color: "#000",
    "pointer-events": "none",
    border: "1px solid #D9D9D9",
    padding: "2px 4px",
    display: "block",
    position: "absolute"
  });
  var TooltipInteraction = function(t) {
    this.graph = t;
  };
  TooltipInteraction.prototype = {
    _moe: {},
    _mod: null,
    _mob: function() {
      delete this._initTimer, this._moe.data && (this._mod || (this._mod = document2.createElement("div"), this._mod.className = tooltipClass), this._mod.parentNode || document2.body.appendChild(this._mod), this._mmw(this.graph, this._moe.data));
    },
    _mmw: function(t, e) {
      var i = t.getTooltip(e), n = "text" == e.tooltipType;
      i && !n && (i = i.replace(/\n/g, "<br>")), n ? this._mod.textContent = i || "" : this._mod.innerHTML = i || "";
      var o = this._moe.evt.pageX + CURSOR_OFFSET_X, s = this._moe.evt.pageY + CURSOR_OFFSET_Y;
      showDivAt(this._mod, o, s), this._deleteTimer && (clearTimeout(this._deleteTimer), delete this._deleteTimer), this._deleteTimer = setTimeout(
        Q2.createFunction(this, this._85),
        t.tooltipDuration || Defaults.TOOLTIP_DURATION
      );
    },
    _85: function() {
      delete this._deleteTimer, this._mod && this._mod.parentNode && this._mod.parentNode.removeChild(this._mod), delete this._mod, this._moe = {};
    },
    _eo: function(t, e, i, n) {
      if (!this._mod) {
        var o = n.tooltipDelay;
        return isNaN(o) && (o = Defaults.TOOLTIP_DELAY), void (this._initTimer = setTimeout(Q2.createFunction(this, this._mob), o));
      }
      this._mmw(n, t);
    },
    onstart: function(t, e) {
      this.destroy(e);
    },
    onmousemove: function(t, e) {
      if (e.enableTooltip) {
        var i = t.getData();
        if (this._moe.evt = t, this._moe.data != i && (this._moe.data = i, this._initTimer && (clearTimeout(this._initTimer), delete this._initTimer), i)) {
          var n = e.getTooltip(i);
          n && this._eo(i, n, t, e);
        }
      }
    },
    destroy: function() {
      this._initTimer && (clearTimeout(this._initTimer), delete this._initTimer), this._deleteTimer && (clearTimeout(this._deleteTimer), delete this._deleteTimer), this._mod && this._85();
    }
  };
  var WheelZoomInteraction = function(t) {
    this.graph = t;
  };
  WheelZoomInteraction.prototype = {
    onmousewheel: function(t, e) {
      if (e.enableWheelZoom !== false) {
        if (e._scaling)
          return void _2p(t);
        e._scaling = true, _fa(
          function() {
            delete e._scaling;
          },
          this,
          100
        ), zoomByMouseEvent(e, t, t.delta > 0) !== false && _2p(t);
      }
    }
  };
  var ZoomInInteraction = function(t) {
    this.graph = t;
  };
  ZoomInInteraction.prototype = {
    onclick: function(t, e) {
      zoomByMouseEvent(e, t, !isMetaKey(t));
    }
  };
  var ZoomOutInteraction = function(t) {
    this.graph = t;
  };
  ZoomOutInteraction.prototype = {
    onclick: function(t, e) {
      zoomByMouseEvent(e, t, isMetaKey(t));
    }
  }, _jq(InteractionEvent, Event), InteractionEvent.ELEMENT_MOVE_START = "element.move.start", InteractionEvent.ELEMENT_MOVING = "element.moving", InteractionEvent.ELEMENT_MOVE_END = "element.move.end", InteractionEvent.ELEMENT_CREATED = "element.created", InteractionEvent.ELEMENT_REMOVED = "element.removed", InteractionEvent.POINT_MOVE_START = "point.move.start", InteractionEvent.POINT_MOVING = "point.moving", InteractionEvent.POINT_MOVE_END = "point.move.end", InteractionEvent.RESIZE_START = "resize.start", InteractionEvent.RESIZING = "resizing", InteractionEvent.RESIZE_END = "resize.end", InteractionEvent.ROTATING = "rotating", InteractionEvent.ROTATE_END = "rotate.end", InteractionEvent.EDGE_BUNDLE = "edge.bundle", InteractionEvent.SELECT = "select", InteractionEvent.SELECT_START = "select.start", InteractionEvent.SELECT_BETWEEN = "select.between", InteractionEvent.SELECT_END = "select.end", InteractionEvent.LONG_CLICK = "long.click", InteractionManager.prototype = {
    _9t: function(t) {
      if (this._interactionSupport)
        switch (t.kind) {
          case ListEvent.KIND_REMOVE:
            this._interactionSupport._4y(t.data);
            break;
          case ListEvent.KIND_CLEAR:
            this._interactionSupport._7f(t.data);
        }
    },
    destroy: function() {
      delete this._l6, delete this._4g, this._interactionSupport && (this._interactionSupport._i5(), delete this._interactionSupport);
    },
    _l6: null,
    _4g: null,
    defaultMode: null,
    _hi: function(t, e, i) {
      this._4g[t] = new InteractionMode(e, i), t == this.currentMode && this._interactionSupport._7b(e);
    },
    addCustomInteraction: function(t) {
      this._interactionSupport._9(t);
    },
    _m4: function(t) {
      var e = this._4g[t];
      return e ? e : defaultInteractionModes[t];
    }
  }, _4u(InteractionManager.prototype, {
    defaultCursor: {
      get: function() {
        return this.currentInteractionMode ? this.currentInteractionMode.defaultCursor : void 0;
      }
    },
    currentMode: {
      get: function() {
        return this._mmurrentMode;
      },
      set: function(t) {
        if (this._mmurrentMode != t) {
          {
            this._mmurrentMode;
          }
          this._interactionSupport || (this._interactionSupport = new InteractionSupport(this._l6)), this._mmurrentMode = t, this.currentInteractionMode = this._m4(this._mmurrentMode), this._l6.cursor = this.defaultCursor, this._interactionSupport._7b(
            this.currentInteractionMode ? this.currentInteractionMode.getInteractionInstances(this._l6) : []
          );
        }
      }
    }
  });
  var defaultInteractionModes = {};
  Defaults.registerInteractions = function(t, e, i) {
    var n = new InteractionMode(e, i);
    defaultInteractionModes[t] = n;
  }, Consts.INTERACTION_MODE_VIEW = "view", Consts.INTERACTION_MODE_DEFAULT = "default", Consts.INTERACTION_MODE_SELECTION = "selection", Consts.INTERACTION_MODE_ZOOMIN = "zoomin", Consts.INTERACTION_MODE_ZOOMOUT = "zoomout", Consts.INTERACTION_MODE_CREATE_SIMPLE_EDGE = "create.simple.edge", Consts.INTERACTION_MODE_CREATE_EDGE = "create.edge", Consts.INTERACTION_MODE_CREATE_SHAPE = "create.shape", Consts.INTERACTION_MODE_CREATE_LINE = "create.line", Defaults.registerInteractions(Consts.INTERACTION_MODE_VIEW, [
    SelectionInteraction,
    PanInteraction,
    WheelZoomInteraction,
    ExportInteraction,
    DoubleClickInteraction,
    TooltipInteraction
  ]), Defaults.registerInteractions(Consts.INTERACTION_MODE_CREATE_SIMPLE_EDGE, [
    EditInteraction,
    CreateSimpleEdgeInteraction,
    SelectionInteraction,
    PanInteraction,
    WheelZoomInteraction,
    ExportInteraction,
    TooltipInteraction
  ]), Defaults.registerInteractions(Consts.INTERACTION_MODE_CREATE_EDGE, [
    EditInteraction,
    CreateEdgeInteraction,
    SelectionInteraction,
    PanInteraction,
    WheelZoomInteraction,
    ExportInteraction,
    TooltipInteraction
  ]), Defaults.registerInteractions(Consts.INTERACTION_MODE_CREATE_SHAPE, [
    EditInteraction,
    CreateShapeInteraction,
    SelectionInteraction,
    PanInteraction,
    WheelZoomInteraction,
    ExportInteraction,
    TooltipInteraction
  ]), Defaults.registerInteractions(Consts.INTERACTION_MODE_CREATE_LINE, [
    CreateLineInteraction,
    SelectionInteraction,
    PanInteraction,
    WheelZoomInteraction,
    ExportInteraction,
    TooltipInteraction
  ]), Defaults.registerInteractions(Consts.INTERACTION_MODE_DEFAULT, [
    EditInteraction,
    ResizeInteraction,
    PointsInteraction,
    SelectionInteraction,
    MoveInteraction,
    PanInteraction,
    WheelZoomInteraction,
    ExportInteraction,
    DoubleClickInteraction,
    TooltipInteraction
  ]), Defaults.registerInteractions(Consts.INTERACTION_MODE_SELECTION, [
    EditInteraction,
    ResizeInteraction,
    PointsInteraction,
    SelectionInteraction,
    MoveInteraction,
    RectangleSelectionInteraction,
    PanInteraction,
    WheelZoomInteraction,
    ExportInteraction,
    DoubleClickInteraction,
    TooltipInteraction
  ]), Defaults.registerInteractions(
    Consts.INTERACTION_MODE_ZOOMIN,
    [WheelZoomInteraction, ExportInteraction, ZoomInInteraction],
    CURSOR_ZOOMIN
  ), Defaults.registerInteractions(
    Consts.INTERACTION_MODE_ZOOMOUT,
    [WheelZoomInteraction, ExportInteraction, ZoomOutInteraction],
    CURSOR_ZOOMOUT
  ), Q2.PanInteraction = PanInteraction, Q2.SelectionInteraction = SelectionInteraction, Q2.MoveInteraction = MoveInteraction, Q2.WheelZoomInteraction = WheelZoomInteraction, Q2.DoubleClickInteraction = DoubleClickInteraction, Q2.ExportInteraction = ExportInteraction, Q2.TooltipInteraction = TooltipInteraction, Q2.RectangleSelectionInteraction = RectangleSelectionInteraction, Q2.PointsInteraction = PointsInteraction;
  var Layouter = function(t) {
    this.graph = t;
  };
  Q2.Layouter = Layouter, Layouter.prototype = {
    getNodeBounds: function(t) {
      return this.graph.getUIBounds(t);
    },
    isLayoutable: function(t) {
      return t.layoutable !== false;
    },
    getLayoutResult: function() {
    },
    updateLocations: function(t, e, i, n, o) {
      if (e === true) {
        if (this.animate || (this.animate = new NodeTranslation()), i && (this.animate.duration = i), n && (this.animate.animationType = n), this.animate.locations = t, o) {
          var s = o, r = this;
          o = function() {
            s.call(r, t);
          };
        }
        return void this.animate.start(o);
      }
      for (var a in t) {
        var h = t[a], l = h.node;
        l.setLocation(h.x, h.y);
      }
      o && o.call(this, t);
    },
    _fi: function(t) {
      var e, i, n, o = null;
      t && (e = t.byAnimate, o = t.callback, i = t.duration, n = t.animationType);
      var s = this.getLayoutResult(t);
      return s ? (this.updateLocations(s, e, i, n, o), s) : false;
    },
    doLayout: function(t, e) {
      return this.graph && e !== true ? void this.graph.callLater(function() {
        this._fi(t);
      }, this) : this._fi(t);
    }
  };
  var DIRECTION_RIGHT = 11, DIRECTION_LEFT = 12, DIRECTION_CENTER = 13, DIRECTION_BOTTOM = 21, DIRECTION_TOP = 22, DIRECTION_MIDDLE = 23;
  Consts.DIRECTION_RIGHT = DIRECTION_RIGHT, Consts.DIRECTION_LEFT = DIRECTION_LEFT, Consts.DIRECTION_CENTER = DIRECTION_CENTER, Consts.DIRECTION_BOTTOM = DIRECTION_BOTTOM, Consts.DIRECTION_TOP = DIRECTION_TOP, Consts.DIRECTION_MIDDLE = DIRECTION_MIDDLE;
  var LAYOUT_TYPE_EVEN = "even", LAYOUT_TYPE_TWO_SIDE = "two.side", LAYOUT_TYPE_EVEN_HORIZONTAL = "even.h", LAYOUT_TYPE_EVEN_VERTICAL = "even.v";
  Consts.LAYOUT_TYPE_EVEN = LAYOUT_TYPE_EVEN, Consts.LAYOUT_TYPE_EVEN_HORIZONTAL = LAYOUT_TYPE_EVEN_HORIZONTAL, Consts.LAYOUT_TYPE_EVEN_VERTICAL = LAYOUT_TYPE_EVEN_VERTICAL, Consts.LAYOUT_TYPE_TWO_SIDE = LAYOUT_TYPE_TWO_SIDE, Q2.isHorizontalDirection = isHorizontalDirection;
  var TreeLayouter = function(t) {
    this.graph = t;
  };
  TreeLayouter.prototype = {
    hGap: 50,
    vGap: 50,
    parentChildrenDirection: DIRECTION_BOTTOM,
    layoutType: LAYOUT_TYPE_EVEN,
    defaultSize: { width: 50, height: 60 },
    getNodeSize: function(t) {
      if (this.graph._94._mkd) {
        var e = this.graph.getUI(t);
        if (e)
          return e._fu;
      }
      return t.image && t.image.bounds ? {
        width: t.image.bounds.width,
        height: t.image.bounds.height
      } : this.defaultSize;
    },
    _mmg: function(t, e) {
      if (this.isLayoutable(t)) {
        var i = this.getNodeSize(t), n = t.id, o = (t.parentChildrenDirection, e ? this._mk6[e.id] : this._mor);
        this._mk6[n] = new TreeLayoutBounds(
          t.hGap || this.hGap,
          t.vGap || this.vGap,
          t.layoutType || this.layoutType,
          t.parentChildrenDirection,
          o,
          t,
          i.width,
          i.height
        );
      }
    },
    _mk6: null,
    _mor: null,
    _kt: function() {
      this._mk6 = null, this._mor = null;
    },
    getLayoutResult: function(t) {
      var e, i, n, o, s = this.graph;
      t instanceof Object && (e = t.x, i = t.y, s = t.root || this.graph, n = t.bounds, o = t.undirected), this._mk6 = {}, this._mor = new TreeLayoutBounds(), this._mor._m8(this.hGap, this.vGap, this.parentChildrenDirection, this.layoutType);
      var r = {}, a = forEachByTopoDepthFirstSearch(s, this._mmg, this, false, o);
      return a && (this._mor._fi(e || 0, i || 0, r), n && n.set(this._mor.x, this._mor.y, this._mor.width, this._mor.height)), this._kt(), r;
    },
    doLayout: function(t, e) {
      if (_gd(t)) {
        var i = t, n = 0;
        _gd(e) && (n = e), t = { x: i, y: n }, e = true;
      }
      return _hr(this, TreeLayouter, "doLayout", [t, e]);
    }
  }, _jq(TreeLayouter, Layouter);
  var TreeLayoutBounds = function(t, e, i, n, o, s, r, a) {
    this._lq = t || 0, this._m1 = e || 0, this.layoutType = i, this.parentChildrenDirection = n, this.parentBounds = o, o && o._fr(this), this.node = s, this._ea = r, this._mmq = a;
  };
  TreeLayoutBounds.prototype = {
    _m8: function(t, e, i, n) {
      this._lq = t, this._m1 = e, this.parentChildrenDirection = i, this.layoutType = n;
    },
    _8d: function() {
      this._fv = [];
    },
    _lq: 0,
    _m1: 0,
    _fv: null,
    _ea: 0,
    _mmq: 0,
    layoutType: null,
    parentChildrenDirection: null,
    _fr: function(t) {
      this._fv || (this._fv = []), this._fv.push(t);
    },
    _mme: function(t, e, i, n) {
      var o = new Rect();
      return i(
        this._fv,
        function(i2) {
          i2._3s(t, e), o.add(i2), n ? t += i2.width + this._lq : e += i2.height + this._m1;
        },
        this
      ), o;
    },
    _93: function(t, e, i, n, o) {
      var s, r = n ? this._lq : this._m1, a = n ? this._m1 : this._lq, h = n ? "width" : "height", l = n ? "height" : "width", _ = n ? "_ea" : "_mmq", u = n ? "_mmq" : "_ea", d = n ? "hostDX" : "hostDY", c = n ? "hostDY" : "hostDX", f = new Rect(), E = 0, g = 0, p = [], v = 0, T = 0;
      i(
        this._fv,
        function(i2) {
          var o2 = T >= g;
          i2._inheritedParentChildrenDirection = o2 ? n ? DIRECTION_LEFT : DIRECTION_TOP : n ? DIRECTION_RIGHT : DIRECTION_BOTTOM, i2._3s(t, e), o2 ? (p.push(i2), E = Math.max(E, i2[h]), g += i2[l] + a) : (s || (s = []), s.push(i2), v = Math.max(v, i2[h]), T += i2[l] + a);
        },
        this
      ), g -= a, T -= a;
      var m = Math.max(g, T), y = r, S = 0;
      this.node && (o && (y += this[_] + r, m > this[u] ? this[c] = (m - this[u]) / 2 : S = (this[u] - m) / 2), this[d] = E + y / 2 - this[_] / 2);
      var I = 0, P = S;
      return _ic(
        p,
        function(t2) {
          n ? t2.offset(E - t2[h], P) : t2.offset(P, E - t2[h]), P += a + t2[l], f.add(t2);
        },
        this
      ), s ? (P = S, I = E + y, _ic(
        s,
        function(t2) {
          n ? t2.offset(I, P) : t2.offset(P, I), P += a + t2[l], f.add(t2);
        },
        this
      ), f) : f;
    },
    offset: function(t, e) {
      this.x += t, this.y += e, this.nodeX += t, this.nodeY += e, this._7n(t, e);
    },
    _moq: function(t, e) {
      return 2 * this.cx - t - e - t;
    },
    _mop: function(t, e) {
      return 2 * this.cy - t - e - t;
    },
    _lz: function(t) {
      if (this._fv && 0 != this._fv.length) {
        if (t)
          return this.node && (this.nodeX += this._moq(this.nodeX, this._ea)), void _ic(
            this._fv,
            function(t2) {
              t2.offset(this._moq(t2.x, t2.width), 0);
            },
            this
          );
        this.node && (this.nodeY += this._mop(this.nodeY, this._mmq)), _ic(
          this._fv,
          function(t2) {
            t2.offset(0, this._mop(t2.y, t2.height));
          },
          this
        );
      }
    },
    _7n: function(t, e) {
      this._fv && _ic(
        this._fv,
        function(i) {
          i.offset(t, e);
        },
        this
      );
    },
    _3s: function(t, e) {
      return this.x = t || 0, this.y = e || 0, this._fv && 0 != this._fv.length ? void this._1y(this.x, this.y, this.layoutType) : void (this.node && (this.width = this._ea, this.height = this._mmq, this.nodeX = this.x, this.nodeY = this.y));
    },
    _7m: function(t) {
      this.node && (t[this.node.id] = {
        node: this.node,
        x: this.nodeX + this._ea / 2,
        y: this.nodeY + this._mmq / 2,
        left: this.nodeX,
        top: this.nodeY,
        width: this._ea,
        height: this._mmq
      }), this._fv && _ic(
        this._fv,
        function(e) {
          e._7m(t);
        },
        this
      );
    },
    _fi: function(t, e, i) {
      this._3s(t, e), this._7m(i);
    },
    _1y: function(t, e, i) {
      var n, o = t, s = e;
      !this.parentChildrenDirection && this.parentBounds && (this.parentChildrenDirection = this._inheritedParentChildrenDirection || this.parentBounds.parentChildrenDirection);
      var r = this.parentChildrenDirection, a = isHorizontalDirection(r);
      if (this.node) {
        n = r == DIRECTION_CENTER || r == DIRECTION_MIDDLE;
        var h = isOppositeDirection(r);
        n || (a ? t += this._ea + this._lq : e += this._mmq + this._m1);
      }
      var l, _ = this.node && this.node.layoutReverse ? _6p : _ic;
      if (i == LAYOUT_TYPE_TWO_SIDE)
        l = this._93(t, e, _, !a, n);
      else {
        var u;
        u = i == LAYOUT_TYPE_EVEN ? !a : i == LAYOUT_TYPE_EVEN_HORIZONTAL, l = this._mme(t, e, _, u, n);
      }
      var d = 0, c = 0;
      l && !l.isEmpty() && (d = l.width, c = l.height, this.add(l)), this.node && (this.nodeX = o, this.nodeY = s, void 0 !== this.hostDX || void 0 !== this.hostDY ? (this.nodeX += this.hostDX || 0, this.nodeY += this.hostDY || 0) : a ? this.nodeY += c / 2 - this._mmq / 2 : this.nodeX += d / 2 - this._ea / 2, this.addRect(this.nodeX, this.nodeY, this._ea, this._mmq), h && this._lz(a));
    },
    node: null,
    uiBounds: null
  }, _jq(TreeLayoutBounds, Rect), DynamicLayouter.prototype = {
    layoutDatas: null,
    isMovable: function(t) {
      return !this.currentMovingNodes[t.id];
    },
    _6z: false,
    _3q: function() {
      this._6z = true, this.graph._1x.addListener(this._9v, this), this.graph._1i.addListener(this._2f, this);
    },
    _1v: function() {
      this._6z = false, this.graph._1x.removeListener(this._9v, this), this.graph._1i.removeListener(this._2f, this);
    },
    invalidateFlag: true,
    invalidateLayoutDatas: function() {
      this.invalidateFlag = true;
    },
    resetLayoutDatas: function() {
      return this.invalidateFlag = false, this.layoutDatas = prepareLayoutDatas.call(this);
    },
    _2f: function(t) {
      InteractionEvent.ELEMENT_MOVE_START == t.kind ? (this.currentMovingNodes = {}, t.datas.forEach(function(t2) {
        this.currentMovingNodes[t2.id] = t2;
      }, this)) : InteractionEvent.ELEMENT_MOVE_END == t.kind && (this.currentMovingNodes = {});
    },
    _9v: function() {
      this.invalidateLayoutDatas();
    },
    isRunning: function() {
      return this.timer && this.timer._ez();
    },
    getLayoutResult: function() {
      this.stop(), this.resetLayoutDatas();
      for (var t = this.getMaxIterations(this.layoutDatas.nodeCount || 0, this.layoutDatas.edgeCount || 0), e = 0; t > e && this.step(false) !== false; e++)
        ;
      var i = this.layoutDatas.nodes;
      return this.onstop(), i;
    },
    _ls: function() {
      return false;
    },
    step: function(t) {
      if (t === false)
        return this._ls(this.timeStep);
      (this.invalidateFlag || !this.layoutDatas) && this.resetLayoutDatas();
      var e = this._ls(t), i = this.layoutDatas.nodes;
      for (var n in i) {
        var o = i[n], s = o.node;
        this.isMovable(s) ? s.setLocation(o.x, o.y) : (o.x = s.x, o.y = s.y, o.vx = 0, o.vy = 0);
      }
      return e;
    },
    onstop: function() {
      delete this.layoutDatas;
    },
    start: function(t) {
      if (this.isRunning())
        return false;
      this._6z || this._3q(), this._jkr || (this._jkr = _7g(this, function(t2) {
        return this.step(t2);
      })), this.invalidateLayoutDatas(), this.timer = new FrameTimer(this._jkr);
      var e = this;
      return this.timer._km(function() {
        e.onstop(), t && t();
      }), true;
    },
    stop: function() {
      this.timer && (this.timer._ll(), this.onstop());
    },
    getMaxIterations: function(t) {
      return Math.min(1e3, 3 * t + 10);
    },
    minEnergyFunction: function(t, e) {
      return 10 + Math.pow(t + e, 1.4);
    },
    resetGraph: function() {
      this._6z || this._3q(), this.resetLayoutDatas();
    },
    destroy: function() {
      this.stop(), this._1v();
    }
  }, _jq(DynamicLayouter, Layouter);
  var BalloonLayouter = function(t, e, i, n) {
    this.graph = t, _gd(e) && (this.radius = e), _gd(i) && (this.gap = i), _gd(n) && (this.startAngle = n);
  };
  Q2.BalloonLayouter = BalloonLayouter;
  var ANGLE_SPACING_PROPORTIONAL = "proportional", ANGLE_SPACING_REGULAR = "regular", RADIUS_MODE_UNIFORM = "uniform", RADIUS_MODE_VARIABLE = "variable";
  Consts.ANGLE_SPACING_PROPORTIONAL = ANGLE_SPACING_PROPORTIONAL, Consts.ANGLE_SPACING_REGULAR = ANGLE_SPACING_REGULAR, Consts.RADIUS_MODE_UNIFORM = RADIUS_MODE_UNIFORM, Consts.RADIUS_MODE_VARIABLE = RADIUS_MODE_VARIABLE, BalloonLayouter.prototype = {
    angleSpacing: ANGLE_SPACING_PROPORTIONAL,
    radiusMode: RADIUS_MODE_VARIABLE,
    gap: 4,
    radius: 50,
    startAngle: 0,
    _mk6: null,
    _mor: null,
    _kt: function() {
      this._mk6 = null, this._mor = null;
    },
    getLayoutResult: function(t) {
      var e, i = 0, n = 0, o = this.graph;
      t instanceof Object && (i = t.cx || 0, n = t.cy || 0, o = t.root || this.graph, e = t.bounds), this._mk6 = {}, this._mor = new BalloonBounds(this);
      var s = {}, r = forEachByTopoBreadthFirstSearch(o, this._mmg, this);
      return r && (this._mor._fv && 1 == this._mor._fv.length && (this._mor = this._mor._fv[0]), this._mor._f6(true), this._mor._6e(i, n, this.startAngle, s, e)), this._kt(), s;
    },
    _mmg: function(t, e) {
      if (this.isLayoutable(t)) {
        var i = e ? this._mk6[e.id] : this._mor;
        this._mk6[t.id] = new BalloonBounds(this, t, i);
      }
    },
    defaultSize: 40,
    getRadius: function() {
      return this.radius;
    },
    getNodeSize: function(t) {
      if (this.graph._94._mkd) {
        var e = this.graph.getUI(t);
        if (e)
          return (e._fu.width + e._fu.height) / 2;
      }
      return this.defaultSize;
    },
    getGap: function() {
      return this.gap;
    },
    _3j: function(t, e, i) {
      return this.getNodeSize(t, e, i) + this.getGap(t, e, i);
    }
  };
  var calulateRadiusProportionalAngleSpacing = function(t) {
    var e, i = this._fv.length, n = 0, o = 0;
    if (_ic(
      this._fv,
      function(t2) {
        var i2 = t2._f6();
        1 > i2 && (i2 = 1), o += i2, i2 > n && (n = i2, e = t2);
      },
      this
    ), i > 1) {
      var s = 0, r = {}, a = o / i / 3;
      o = 0, _ic(
        this._fv,
        function(t2) {
          var e2 = t2._lx;
          a > e2 && (e2 = a), r[t2.id] = e2, o += e2;
        },
        this
      );
      var h = PI2 / o;
      _ic(
        this._fv,
        function(e2, i2) {
          var n2 = r[e2.id], o2 = n2 * h;
          0 === i2 && (s = t ? -o2 / 2 : -o2), e2._ko = s + o2 / 2, e2._kl = o2, s += o2;
        },
        this
      );
    }
    return [n, e._kl];
  }, calulateRadiusRegularAngleSpacing = function(t) {
    var e = this._8x, i = 2 * Math.PI / e, n = 0, o = t ? 0 : e > 1 ? -i / 2 : 0;
    return _ic(
      this._fv,
      function(t2) {
        t2._ko = o % PI2, o += i, t2._kl = i;
        var e2 = t2._f6();
        e2 > n && (n = e2);
      },
      this
    ), [n, i];
  }, BalloonBounds = function(t, e, i) {
    this.layouter = t, e && (this._lv = e, this.id = e.id), i && (i._fr(this), i._m0 = false, this._kq = i._kq + 1);
  }, PI2 = 2 * Math.PI;
  BalloonBounds.prototype = {
    _kl: 0,
    _ko: 0,
    _ke: 0,
    _f3: 0,
    _d4: 0,
    _kq: 0,
    _m0: true,
    _lx: 0,
    _go: 0,
    _fv: null,
    _lv: null,
    _fr: function(t) {
      this._fv || (this._fv = []), this._fv.push(t), t.parent = this;
    },
    _gs: function(t) {
      if (this._ko = (this._ko + t) % PI2, this._fv) {
        var e = this._fv.length;
        if (1 == e)
          return void this._fv[0]._gs(this._ko);
        t = this._ko + Math.PI, _ic(
          this._fv,
          function(e2) {
            e2._gs(t);
          },
          this
        );
      }
    },
    _8x: 0,
    _82: function(t) {
      if (this._lv && (this._go = this.layouter._3j(this._lv, this._kq, this._m0) / 2), !this._fv)
        return null;
      this._go;
      return this._8x = this._fv.length, this._8x <= 2 || this.layouter.angleSpacing == ANGLE_SPACING_REGULAR ? calulateRadiusRegularAngleSpacing.call(this, t) : calulateRadiusProportionalAngleSpacing.call(this, t);
    },
    _f6: function(t) {
      var e = this._82(t);
      if (!e)
        return this._lx = this._go;
      var i = e[0], n = e[1], o = this.layouter.getRadius(this._lv, this._kq);
      if (o < this._go && (o = this._go), this._f3 = o, this._go + i > o && (o = this._go + i), i && this._8x > 1 && n < Math.PI) {
        var s = i / Math.sin(n / 2);
        s > o && (o = s);
      }
      return this._ke = o, this._lx = o + i, this._lv && this._fv && this.layouter.radiusMode == RADIUS_MODE_VARIABLE && _ic(
        this._fv,
        function(t2) {
          var e2 = t2._lx;
          1 == t2._8x && (e2 /= 2);
          var i2 = this._go + e2, n2 = t2._kl;
          if (n2 && n2 < Math.PI) {
            var o2 = Math.sin(n2 / 2), s2 = e2 / o2;
            s2 > e2 && (e2 = s2);
          }
          i2 > e2 && (e2 = i2), t2._d4 = e2;
        },
        this
      ), (!this._lv || t) && this._gs(0), this._lx;
    },
    _6e: function(t, e, i, n, o) {
      if (this._lv && (n[this._lv.id] = {
        x: t,
        y: e,
        node: this._lv
      }, o && o.addRect(t - this._go / 2, e - this._go / 2, this._go, this._go)), this._fv) {
        if (!this._lv && 1 == this._fv.length)
          return void this._fv[0]._6e(t, e, i, n, o);
        i = i || 0;
        var s = this._ke, r = this._f3;
        _ic(
          this._fv,
          function(a) {
            var h = s;
            a._d4 && (h = Math.max(r, a._d4));
            var l = a._ko + i, _ = t + h * Math.cos(l), u = e + h * Math.sin(l);
            a._6e(_, u, i, n, o);
          },
          this
        );
      }
    }
  }, _jq(BalloonLayouter, Layouter);
  var BarycentricLayouter = function() {
    _3g(this, BarycentricLayouter, arguments);
  };
  _jq(BarycentricLayouter, SpringLayouter);
  var EdgeBundle = function(t, e) {
    this.node1 = t, this.node2 = e, t == e ? (this.isLooped = true, this._kz = t._kg) : this._kz = new HashList(), this._8j = [], this._hk = Defaults.EDGE_BUNDLE_EXPANDED;
  };
  Defaults.EDGE_BUNDLE_EXPANDED = true, EdgeBundle.prototype = {
    node1: null,
    node2: null,
    _kz: null,
    _hk: Defaults.EDGE_BUNDLE_EXPANDED,
    _8j: null,
    _ff: null,
    agentEdge: null,
    _mox: function(t, e, i) {
      this._kz.forEach(function(n) {
        return i && n.$from != i && n.fromAgent != i ? void 0 : t.call(e, n);
      });
    },
    _5s: 0,
    _5q: 0,
    _io: function(t, e) {
      return this._kz.add(t) === false ? false : (e == this.node1 ? this._5s++ : this._5q++, this._mkd ? void this._16(t) : void (this._mkd = true));
    },
    _d1: function(t, e) {
      return this._kz.remove(t) === false ? false : (e == this.node1 ? this._5s-- : this._5q--, this._16(t), void this._kz.forEach(function(t2) {
        t2._edgeBundleInvalidateFlag = true, t2.__56 = true;
      }, this));
    },
    _16: function(t) {
      this._mmcBindableFlag = true, this._6k = true, t._edgeBundleInvalidateFlag = true, t.__56 = true;
    },
    _mmc: function() {
      this._6k || (this._6k = true, this._kz.forEach(function(t) {
        t._edgeBundleInvalidateFlag = true;
      }));
    },
    isEmpty: function() {
      return this._kz.isEmpty();
    },
    isPositiveOrder: function(t) {
      return this.node1 == t.$from || this.node1 == t.fromAgent;
    },
    canBind: function(t) {
      return t && this._6k && this._fz(t), this._kz.length > 1 && this._8j.length > 1;
    },
    _i9: function(t) {
      return this._8j.indexOf(t);
    },
    getYOffset: function(t) {
      return this._ff[t.id];
    },
    _52: function(t) {
      if (!this.canBind())
        return void (this._ff = {});
      var e = {}, i = this._8j.length;
      if (!(2 > i)) {
        var n = 0, o = this._8j[0];
        e[o.id] = 0;
        for (var s = 1; i > s; s++) {
          o = this._8j[s];
          var r = t.getStyle(o, Styles.EDGE_BUNDLE_GAP) || DefaultStyles[Styles.EDGE_BUNDLE_GAP];
          n += r, e[o.id] = n;
        }
        if (!this.isLooped)
          for (var a = n / 2, s = 0; i > s; s++)
            o = this._8j[s], e[o.id] -= a;
        this._ff = e;
      }
    },
    _mov: function(t) {
      return this._hk == t ? false : (this._hk = t, this._mmc(), true);
    },
    reverseExpanded: function() {
      return this._mov(!this._hk);
    },
    _1l: function() {
      this._mmcBindableFlag = false, this._8j.length = 0;
      var t;
      this._kz.forEach(function(e) {
        if (e.isBundleEnabled()) {
          if (!this.isPositiveOrder(e))
            return t || (t = []), void t.push(e);
          this._8j.push(e);
        }
      }, this), t && (this._8j = t.concat(this._8j));
    },
    _e3: function(t) {
      return t == this.agentEdge || !this.canBind() || this._hk;
    },
    _fz: function(t) {
      this._6k = false, this._kz.forEach(function(t2) {
        t2._edgeBundleInvalidateFlag = false;
      }), this._mmcBindableFlag && this._1l();
      var e = this._hk, i = this.canBind(), n = !i || e;
      _ic(
        this._8j,
        function(t2) {
          t2._$t = true, t2._hwInBundle = n, n && (t2.__56 = true);
        },
        this
      ), n ? this._mk7(null, t) : (this._mk7(this._8j[0], t), this.agentEdge._hwInBundle = true, this.agentEdge.__56 = true), n && this._52(t);
    },
    _mk7: function(t, e) {
      if (t != this.agentEdge) {
        var i = this.agentEdge;
        return this.agentEdge = t, e && e._57(new PropertyChangeEvent(this, "agentEdge", t, i)), true;
      }
    }
  }, _4u(EdgeBundle.prototype, {
    bindableEdges: {
      get: function() {
        return this._8j;
      }
    },
    edges: {
      get: function() {
        return this._kz._jf;
      }
    },
    length: {
      get: function() {
        return this._kz ? this._kz.length : 1;
      }
    },
    expanded: {
      get: function() {
        return this._hk;
      },
      set: function(t) {
        return this._hk == t ? false : (this._hk = t, void this._mmc());
      }
    }
  });
  var nbodyForce = function() {
    function t(t2, e2) {
      this.node = t2, this.body = e2;
    }
    function e() {
      this.stack = [], this.popIdx = 0;
    }
    var i = -1e6, n = 0.8;
    e.prototype = {
      isEmpty: function() {
        return 0 === this.popIdx;
      },
      push: function(e2, i2) {
        var n2 = this.stack[this.popIdx];
        n2 ? (n2.node = e2, n2.body = i2) : this.stack[this.popIdx] = new t(e2, i2), ++this.popIdx;
      },
      pop: function() {
        return this.popIdx > 0 ? this.stack[--this.popIdx] : void 0;
      },
      reset: function() {
        this.popIdx = 0;
      }
    };
    var o = [], s = new e(), r = function() {
      this.body = null, this.quads = [], this.mass = 0, this.massX = 0, this.massY = 0, this.left = 0, this.top = 0, this.bottom = 0, this.right = 0, this.isInternal = false;
    }, a = [], h = 0, l = function() {
      var t2;
      return a[h] ? (t2 = a[h], t2.quads[0] = null, t2.quads[1] = null, t2.quads[2] = null, t2.quads[3] = null, t2.body = null, t2.mass = t2.massX = t2.massY = 0, t2.left = t2.right = t2.top = t2.bottom = 0, t2.isInternal = false) : (t2 = new r(), a[h] = t2), ++h, t2;
    }, _ = l(), u = function(t2, e2) {
      var i2 = Math.abs(t2.x - e2.x), n2 = Math.abs(t2.y - e2.y);
      return 1e-8 > i2 && 1e-8 > n2;
    }, d = function(t2) {
      for (s.reset(), s.push(_, t2); !s.isEmpty(); ) {
        var e2 = s.pop(), i2 = e2.node, n2 = e2.body;
        if (i2.isInternal) {
          var o2 = n2.x, r2 = n2.y;
          i2.mass = i2.mass + n2.mass, i2.massX = i2.massX + n2.mass * o2, i2.massY = i2.massY + n2.mass * r2;
          var a2 = 0, h2 = i2.left, d2 = (i2.right + h2) / 2, c2 = i2.top, f2 = (i2.bottom + c2) / 2;
          if (o2 > d2) {
            a2 += 1;
            var E = h2;
            h2 = d2, d2 += d2 - E;
          }
          if (r2 > f2) {
            a2 += 2;
            var g = c2;
            c2 = f2, f2 += f2 - g;
          }
          var p = i2.quads[a2];
          p || (p = l(), p.left = h2, p.top = c2, p.right = d2, p.bottom = f2, i2.quads[a2] = p), s.push(p, n2);
        } else if (i2.body) {
          var v = i2.body;
          if (i2.body = null, i2.isInternal = true, u(v, n2)) {
            if (i2.right - i2.left < 1e-8)
              return;
            do {
              var T = Math.random(), m = (i2.right - i2.left) * T, y = (i2.bottom - i2.top) * T;
              v.x = i2.left + m, v.y = i2.top + y;
            } while (u(v, n2));
          }
          s.push(i2, v), s.push(i2, n2);
        } else
          i2.body = n2;
      }
    }, c = function(t2) {
      var e2, s2, r2, a2, h2 = o, l2 = 1, u2 = 0, d2 = 1;
      for (h2[0] = _; l2; ) {
        var c2 = h2[u2], f2 = c2.body;
        l2 -= 1, u2 += 1, f2 && f2 !== t2 ? (s2 = f2.x - t2.x, r2 = f2.y - t2.y, a2 = Math.sqrt(s2 * s2 + r2 * r2), 0 === a2 && (s2 = (Math.random() - 0.5) / 50, r2 = (Math.random() - 0.5) / 50, a2 = Math.sqrt(s2 * s2 + r2 * r2)), e2 = i * f2.mass * t2.mass / (a2 * a2), -1e3 > e2 && (e2 = -1e3), e2 /= a2, t2.fx = t2.fx + e2 * s2, t2.fy = t2.fy + e2 * r2) : (s2 = c2.massX / c2.mass - t2.x, r2 = c2.massY / c2.mass - t2.y, a2 = Math.sqrt(s2 * s2 + r2 * r2), 0 === a2 && (s2 = (Math.random() - 0.5) / 50, r2 = (Math.random() - 0.5) / 50, a2 = Math.sqrt(s2 * s2 + r2 * r2)), (c2.right - c2.left) / a2 < n ? (e2 = i * c2.mass * t2.mass / (a2 * a2), -1e3 > e2 && (e2 = -1e3), e2 /= a2, t2.fx = t2.fx + e2 * s2, t2.fy = t2.fy + e2 * r2) : (c2.quads[0] && (h2[d2] = c2.quads[0], l2 += 1, d2 += 1), c2.quads[1] && (h2[d2] = c2.quads[1], l2 += 1, d2 += 1), c2.quads[2] && (h2[d2] = c2.quads[2], l2 += 1, d2 += 1), c2.quads[3] && (h2[d2] = c2.quads[3], l2 += 1, d2 += 1)));
      }
    }, f = function(t2, e2) {
      i = e2;
      var n2, o2 = Number.MAX_VALUE, s2 = Number.MAX_VALUE, r2 = Number.MIN_VALUE, a2 = Number.MIN_VALUE, u2 = t2, c2 = u2.length;
      for (n2 = c2; n2--; ) {
        var f2 = u2[n2].x, E = u2[n2].y;
        o2 > f2 && (o2 = f2), f2 > r2 && (r2 = f2), s2 > E && (s2 = E), E > a2 && (a2 = E);
      }
      var g = r2 - o2, p = a2 - s2;
      for (g > p ? a2 = s2 + g : r2 = o2 + p, h = 0, _ = l(), _.left = o2, _.right = r2, _.top = s2, _.bottom = a2, n2 = c2; n2--; )
        d(u2[n2]);
    };
    return { init: f, update: c };
  }, applyCenterAttractiveForce = function(t) {
    t.fx -= t.x * this.attractive, t.fy -= t.y * this.attractive;
  }, applySpringForce = function(t) {
    if (0 != t.k) {
      var e = this._mmt, i = t.from, n = t.to, o = n.x - i.x, s = n.y - i.y, r = o * o + s * s, a = Math.sqrt(r) || 0.1, h = (a - e) * t.k * this.elastic;
      h /= a;
      var l = h * o, _ = h * s;
      n.fx -= l, n.fy -= _, i.fx += l, i.fy += _;
    }
  };
  SpringLayouter.prototype = {
    appendNodeInfo: function(t, e) {
      e.mass = t.layoutMass || 1, e.fx = 0, e.fy = 0, e.vx = 0, e.vy = 0;
    },
    appendEdgeInfo: function(t, e) {
      e.k = t.layoutElasticity || 1;
    },
    setMass: function(t, e) {
      t.layoutMass = e, this.layoutDatas && this.layoutDatas.nodes && (t = this.layoutDatas.nodes[t.id], t && (t.mass = e));
    },
    setElasticity: function(t, e) {
      t.layoutElasticity = e, this.layoutDatas && this.layoutDatas.edges && (t = this.layoutDatas.edges[t.id], t && (t.k = e));
    },
    _mmt: 50,
    _iw: 0.5,
    timeStep: 0.15,
    repulsion: 50,
    attractive: 0.1,
    elastic: 3,
    _lr: 1e3,
    _jw: function(t) {
      return this._lr + 0.3 * (t - this._lr);
    },
    _ls: function(t, e) {
      var i = this.layoutDatas.nodes;
      for (var n in i) {
        var o = i[n];
        e && (o.x += Math.random() - 0.5, o.y += Math.random() - 0.5), applyCenterAttractiveForce.call(this, o);
      }
      var s = this.layoutDatas.groups;
      if (s)
        for (var n in s) {
          var r = s[n], a = r.children, h = 0, l = 0;
          a.forEach(function(t2) {
            h += t2.x, l += t2.y;
          }), h /= a.length, l /= a.length;
          var _ = 10 * this.attractive;
          a.forEach(function(t2) {
            t2.fx -= (t2.x - h) * _, t2.fy -= (t2.y - l) * _;
          });
        }
      var u = this._nbodyForce;
      u || (u = this._nbodyForce = nbodyForce()), u.init(this.layoutDatas.nodesArray, -this.repulsion * this.repulsion * this.repulsion);
      for (var n in i)
        u.update(i[n]);
      if (this.elastic) {
        var d = this.layoutDatas.edges;
        for (var n in d)
          applySpringForce.call(this, d[n]);
      }
      return this._lu(t);
    },
    _lu: function(t) {
      var e = this.layoutDatas.minEnergy, i = (this.layoutDatas.currentEnergy, this.layoutDatas.nodes), t = this.timeStep, n = 0, o = this._iw;
      for (var s in i) {
        var r = i[s], a = r.fx / r.mass, h = r.fy / r.mass, l = r.vx += a * t, _ = r.vy += h * t;
        r.x += l * t, r.y += _ * t, e > n && (n += 2 * (l * l + _ * _)), r.fx = 0, r.fy = 0, r.vx *= o, r.vy *= o;
      }
      return this.layoutDatas.currentEnergy = n, n >= e;
    }
  }, _jq(SpringLayouter, DynamicLayouter), Q2.SpringLayouter = SpringLayouter;
  var NodeTranslation = function(t) {
    this.locations = t;
  };
  NodeTranslation.prototype = {
    oldLocations: null,
    _e5: null,
    duration: 700,
    animationType: Easing.easeOutStrong,
    _7r: function(t) {
      if (this._e5 = t, this.oldLocations = {}, t)
        for (var e in t) {
          var i = t[e], n = i.node;
          this.oldLocations[e] = { x: n.x, y: n.y };
        }
    },
    setLocation: function(t, e, i) {
      t.setLocation(e, i);
    },
    forEach: function(t, e) {
      for (var i in this.locations) {
        var n = this.oldLocations[i], o = this.locations[i];
        t.call(e, n, o);
      }
    },
    _jy: function(t) {
      this.forEach(function(e, i) {
        var n = i.node, o = e.x + (i.x - e.x) * t, s = e.y + (i.y - e.y) * t;
        this.setLocation(n, o, s);
      }, this);
    },
    stop: function() {
      this._mknimate && this._mknimate._ll();
    },
    start: function(t) {
      this._mknimate ? (this._mknimate._ll(), this._mknimate._iu = this.duration, this._mknimate._fdType = this.animationType, this._mknimate._onfinish = this._onfinish) : this._mknimate = new FrameAnimation(this._jy, this, this.duration, this.animationType), this._mknimate._km(t);
    }
  }, _4u(NodeTranslation.prototype, {
    locations: {
      get: function() {
        return this._e5;
      },
      set: function(t) {
        this._e5 != t && this._7r(t);
      }
    }
  });
  var findRootNodes = function(t) {
    var e = new HashList();
    return t.forEach(function(t2) {
      t2 instanceof Node && (t2.hasInEdge() || e.add(t2._e1 || t2));
    }), e;
  }, forEachByTopoSearch = function(t, e, i, n, o, s) {
    if (e instanceof Data)
      return t(e, i, n, o, s), e;
    if (e instanceof Graph) {
      var r = new HashList();
      e._l6Model.forEach(function(t2) {
        return e.isVisible(t2) ? t2._i7() && t2._hk && t2.hasChildren() ? void (t2.$location && (t2.$location.invalidateFlag = false)) : void r.add(t2) : void 0;
      }), e = r;
    }
    var e = findRootNodes(e);
    return _ic(e, function(e2) {
      t(e2, i, n, o, s);
    }), e;
  }, forEachByTopoDepthFirstSearch = function(t, e, i, n, o) {
    return forEachByTopoSearch(depthFirstSearch, t, e, i, n, o);
  }, forEachByTopoBreadthFirstSearch = function(t, e, i, n, o) {
    return forEachByTopoSearch(breadthFirstSearch, t, e, i, n, o);
  };
  GraphModel.prototype.forEachByTopoDepthFirstSearch = function(t, e, i, n) {
    forEachByTopoDepthFirstSearch(this, t, e, i, n);
  }, GraphModel.prototype.forEachByTopoBreadthFirstSearch = function(t, e, i, n) {
    forEachByTopoBreadthFirstSearch(this, t, e, i, n);
  };
  var depthFirstSearch = function(t, e, i, n, o) {
    function s(t2, e2, i2, n2, o2, r, a, h) {
      t2._marker = r, n2 || e2.call(i2, t2, h, a), forEachLinkedNode(
        t2,
        function(h2) {
          s(h2, e2, i2, n2, o2, r, a + 1, t2);
        },
        h,
        o2,
        r
      ), n2 && e2.call(i2, t2, h, a);
    }
    s(t, e, i, n, o, {}, 0);
  }, breadthFirstSearch = function(t, e, i, n, o) {
    function s(t2, e2, i2, n2, o2, r, a) {
      var h, l = t2.length;
      t2.forEach(function(t3, s2) {
        var _ = t3.v;
        _._marker = r, n2 || e2.call(i2, _, t3._from, a, s2, l), forEachLinkedNode(
          _,
          function(t4) {
            h || (h = []), t4._marker = r, h.push({ v: t4, _from: _ });
          },
          _,
          o2,
          r
        );
      }), h && s(h, e2, i2, n2, o2, r, a + 1), n2 && t2.forEach(function(t3, n3) {
        e2.call(i2, t3.v, t3._from, a, n3, l);
      });
    }
    s([{ v: t }], e, i, n, o, {}, 0);
  };
  Q2.toColor = _ia, Q2.log = _m3, Q2.error = _l8, Q2.trace = _l9, Q2.isIE = isIE, Q2.isOpera = isOpera, Q2.isWebkit = isWebkit, Q2.isGecko = isGecko, Q2.isFirefox = isFirefox, Q2.isSafari = isSafari, Q2.isChrome = isChrome, Q2.isMac = isMac, Q2.DefaultStyles = DefaultStyles, Q2.Defaults = Defaults, Q2.Styles = Styles, Q2.Consts = Consts, Q2.Graphs = Graphs, Q2.Graph = Graph, Q2.BaseUI = BaseUI, Q2.ElementUI = ElementUI, Q2.NodeUI = NodeUI, Q2.EdgeUI = EdgeUI, Q2.LabelUI = LabelUI, Q2.ImageUI = ImageUI, Q2.Shapes = Shapes, Q2.Path = Path, Q2.Gradient = Gradient, Q2.InteractionEvent = InteractionEvent, Q2.Element = Element, Q2.Node = Node, Q2.Edge = Edge, Q2.GraphModel = GraphModel, Q2.EdgeBundle = EdgeBundle, Q2.TreeLayouter = TreeLayouter, Q2.name = "Qunee for HTML5";
  Q2.version = "2.0.6", Q2.about = "Qunee - Diagramming Components for HTML5/Canvas", Q2.copyright = "Copyright \xA9 2015 Qunee.com", Q2.css = css_mmss;
  Q2.IDrawable = IDrawable, _m3 = function() {
  }, Q2.publishDate = "8/8/2015";
  Q2.sfExports = {
    _18,
    angleFormat,
    HALF_PI,
    LEFT,
    CENTER,
    RIGHT,
    TOP,
    MIDDLE,
    BOTTOM
  };
  return Q2;
}(window, document);
(function(proto) {
  const oriGetFollowerCount = proto.getFollowerCount;
  const prop = oriGetFollowerCount.toString().match(/\.(\w+)\.length/)[1];
  proto.getFollowerCount = function() {
    return this.hasFollowers() ? this[prop].length : 0;
  };
})(Q.Node.prototype);
(function(proto) {
  const _initLabel = proto.initLabel;
  proto.initLabel = function() {
    const ret = _initLabel.apply(this, arguments);
    this.label.sfNode = this.$data;
    return ret;
  };
})(Q.ElementUI.prototype);
(function(proto) {
  const _draw = proto.draw;
  const _measure = proto.measure;
  proto.draw = function() {
    if (this.sfNode && this.sfNode.sfNameFormatter) {
      return draw.apply(this, arguments);
    }
    return _draw.apply(this, arguments);
  };
  proto.measure = function() {
    if (this.sfNode && this.sfNode.sfNameFormatter) {
      return measure.apply(this, arguments);
    }
    return _measure.apply(this, arguments);
  };
  const Defaults = Q.Defaults;
  const HALF_PI = Q.sfExports.HALF_PI;
  const CENTER = Q.sfExports.CENTER;
  const RIGHT = Q.sfExports.RIGHT;
  const TOP = Q.sfExports.TOP;
  const MIDDLE = Q.sfExports.MIDDLE;
  const _18 = Q.sfExports._18;
  const angleFormat = Q.sfExports.angleFormat;
  function draw(t, e, i, n) {
    i && this._89(t, e, n);
    const o = this.$fontSize || Defaults.FONT_SIZE;
    if (this.$rotatable && this.$_hostRotate) {
      const s = angleFormat(this.$_hostRotate);
      s > HALF_PI && 3 * HALF_PI > s && (t.translate(this._j1.width / 2, this._j1.height / 2), t.rotate(Math.PI), t.translate(-this._j1.width / 2, -this._j1.height / 2));
    }
    const r = this.alignPosition || Defaults.ALIGN_POSITION, a = r.horizontalPosition, h = r.verticalPosition, l = o * Defaults.LINE_HEIGHT;
    let _ = l / 2;
    if (h != TOP && this._gb.height < this._j1.height) {
      const u = this._j1.height - this._gb.height;
      _ += h == MIDDLE ? u / 2 : u;
    }
    t.translate(0, _), t.font != this.$font && (t.font = this.$font), a == CENTER ? (t.textAlign = "center", t.translate(this._j1.width / 2, 0)) : a == RIGHT ? (t.textAlign = "right", t.translate(this._j1.width, 0)) : t.textAlign = "left", t.textBaseline = "middle", t.fillStyle = this.color;
    let text = this.$data;
    if (this.sfNode && typeof this.sfNode.sfNameFormatter === "function") {
      text = this.sfNode.sfNameFormatter(text, this.sfNode);
    }
    for (let d = 0, c = text.split("\n"), f = 0, E = c.length; E > f; f++) {
      const g = c[f];
      t.fillText(g, 0, d), d += l;
    }
  }
  function measure() {
    let text = this.$data;
    if (this.$data && this.sfNode && this.sfNode.sfNameFormatter) {
      text = this.sfNode.sfNameFormatter(this.$data, this.sfNode);
    }
    this.font;
    const t = _18(text, this.$fontSize || Defaults.FONT_SIZE, this.$font);
    if (this._gb = t, this.$size) {
      const e = this.$size.width || 0, i = this.$size.height || 0;
      return this.setMeasuredBounds(e > t.width ? e : t.width, i > t.height ? i : t.height);
    }
    return this.setMeasuredBounds(t.width, t.height);
  }
})(Q.LabelUI.prototype);
Q.Graph.prototype.isSelectable = function(item) {
  return this.graphModel.contains(item) && item.selectable !== false;
};
window.Q = Q;
export { Q as default };
