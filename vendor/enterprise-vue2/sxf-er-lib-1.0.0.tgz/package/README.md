# Eresh

- [线上文档](http://ui.sangfor.com.cn/common/docs/cloud/eresh)

- [playground](http://ui.sangfor.com.cn/common/docs/cloud/playground)

## 模块

### 组件库内模块

| 模块名称 | 版本号 | 描述 |
| --- | --- | --- |
| [**@sxf/er-components**](http://mq.code.sangfor.org/UED/CloudFE/Eresh/tree/master/packages/components) | ![npm (custom registry)](http://chat.uedc.sangfor.com.cn:10002/npm/v/@sxf/er-components/latest?label=latest&registry_uri=http%3A%2F%2Fnpm.uedc.sangfor.com.cn&style=flat-square) | 基础组件 |
| [**@sxf/er-config**](http://mq.code.sangfor.org/UED/CloudFE/Eresh/tree/master/packages/config) | ![npm (custom registry)](http://chat.uedc.sangfor.com.cn:10002/npm/v/@sxf/er-config/latest?label=latest&registry_uri=http%3A%2F%2Fnpm.uedc.sangfor.com.cn&style=flat-square) | 全局配置，包括国际化相关和业务配置相关，如：VMP 字段、ajax配置等，详细可配置项可查阅类型定义 |
| [**@sxf/er-lib**](http://mq.code.sangfor.org/UED/CloudFE/Eresh/tree/master/packages/lib) | ![npm (custom registry)](http://chat.uedc.sangfor.com.cn:10002/npm/v/@sxf/er-lib/latest?label=latest&registry_uri=http%3A%2F%2Fnpm.uedc.sangfor.com.cn&style=flat-square) | 一些第三方包，可能因为一些具体场景需求被魔改过 |
| [**@sxf/er-style**](http://mq.code.sangfor.org/UED/CloudFE/Eresh/tree/master/packages/style) | ![npm (custom registry)](http://chat.uedc.sangfor.com.cn:10002/npm/v/@sxf/er-style/latest?label=latest&registry_uri=http%3A%2F%2Fnpm.uedc.sangfor.com.cn&style=flat-square) | 核心样式，不管组件按需加载还是全局注册都需要引入这里的样式文件 |
| [**@sxf/er-utils**](http://mq.code.sangfor.org/UED/CloudFE/Eresh/tree/master/packages/utils) | ![npm (custom registry)](http://chat.uedc.sangfor.com.cn:10002/npm/v/@sxf/er-utils/latest?label=latest&registry_uri=http%3A%2F%2Fnpm.uedc.sangfor.com.cn&style=flat-square) | 工具包，目前业务中有使用的都从 vt-component 迁移过来了，但后续可能会将部分 utils 移到业务中去 |
| [**@sxf/er-validator**](http://mq.code.sangfor.org/UED/CloudFE/Eresh/tree/master/packages/validator) | ![npm (custom registry)](http://chat.uedc.sangfor.com.cn:10002/npm/v/@sxf/er-validator/latest?label=latest&registry_uri=http%3A%2F%2Fnpm.uedc.sangfor.com.cn&style=flat-square) | 校验相关，即 vtype |
| [**@sxf/er-widget**](http://mq.code.sangfor.org/UED/CloudFE/Eresh/tree/master/packages/widget) | ![npm (custom registry)](http://chat.uedc.sangfor.com.cn:10002/npm/v/@sxf/er-widget/latest?label=latest&registry_uri=http%3A%2F%2Fnpm.uedc.sangfor.com.cn&style=flat-square) | 基于 jQuery 实现的组件、插件，如 grid、tree、fixselect 等 |

### 扩展模块

| 模块名称 | 版本号 | 描述 |
| --- | --- | --- |
| [**@sxf/er-hooks**](http://mq.code.sangfor.org/UED/CloudFE/Eresh/tree/master/packages/hooks) | ![npm (custom registry)](http://chat.uedc.sangfor.com.cn:10002/npm/v/@sxf/er-hooks/latest?label=latest&registry_uri=http%3A%2F%2Fnpm.uedc.sangfor.com.cn&style=flat-square) | 基于基础组件库封装的一套 hooks 库，支持按需加载 |
| [**@sxf/er-pro**](http://mq.code.sangfor.org/UED/CloudFE/Eresh/tree/master/packages/pro) | ![npm (custom registry)](http://chat.uedc.sangfor.com.cn:10002/npm/v/@sxf/er-pro/latest?label=latest&registry_uri=http%3A%2F%2Fnpm.uedc.sangfor.com.cn&style=flat-square) | 基于基础组件库封装的扩展组件库，支持按需加载 |
| [**@sxf/er-unocss**](http://mq.code.sangfor.org/UED/CloudFE/Eresh/tree/master/packages/unocss) | ![npm (custom registry)](http://chat.uedc.sangfor.com.cn:10002/npm/v/@sxf/er-unocss/latest?label=latest&registry_uri=http%3A%2F%2Fnpm.uedc.sangfor.com.cn&style=flat-square) | 基于云BG规范，提供的一套符合规范的 unocss 原子 css 预设 |
| [**@sxf/er-skeleton**](http://mq.code.sangfor.org/UED/CloudFE/Eresh/tree/master/packages/skeleton) | ![npm (custom registry)](http://chat.uedc.sangfor.com.cn:10002/npm/v/@sxf/er-skeleton/latest?label=latest&registry_uri=http%3A%2F%2Fnpm.uedc.sangfor.com.cn&style=flat-square) | web components 封装的骨架屏组件 |

### 如何贡献

查看 [CONTRIBUTING.md](./CONTRIBUTING.md)
