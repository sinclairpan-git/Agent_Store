var moxie = function(global, factory) {
  var extract = function() {
    var ctx = {};
    factory.apply(ctx, arguments);
    return ctx.moxie;
  };
  return extract();
}(window, function() {
  (function(exports, undefined$1) {
    var modules = {};
    function require(ids, callback) {
      var module, defs = [];
      for (var i = 0; i < ids.length; ++i) {
        module = modules[ids[i]] || resolve(ids[i]);
        if (!module) {
          throw "module definition dependecy not found: " + ids[i];
        }
        defs.push(module);
      }
      callback.apply(null, defs);
    }
    function define(id, dependencies, definition) {
      if (typeof id !== "string") {
        throw "invalid module definition, module id must be defined and be a string";
      }
      if (dependencies === undefined$1) {
        throw "invalid module definition, dependencies must be specified";
      }
      if (definition === undefined$1) {
        throw "invalid module definition, definition function must be specified";
      }
      require(dependencies, function() {
        modules[id] = definition.apply(null, arguments);
      });
    }
    function defined(id) {
      return !!modules[id];
    }
    function resolve(id) {
      var target = exports;
      var fragments = id.split(/[.\/]/);
      for (var fi = 0; fi < fragments.length; ++fi) {
        if (!target[fragments[fi]]) {
          return;
        }
        target = target[fragments[fi]];
      }
      return target;
    }
    function expose(ids) {
      for (var i = 0; i < ids.length; i++) {
        var target = exports;
        var id = ids[i];
        var fragments = id.split(/[.\/]/);
        for (var fi = 0; fi < fragments.length - 1; ++fi) {
          if (target[fragments[fi]] === undefined$1) {
            target[fragments[fi]] = {};
          }
          target = target[fragments[fi]];
        }
        target[fragments[fragments.length - 1]] = modules[id];
      }
    }
    define("moxie/core/utils/Basic", [], function() {
      function typeOf(o) {
        var undef;
        if (o === undef) {
          return "undefined";
        } else if (o === null) {
          return "null";
        } else if (o.nodeType) {
          return "node";
        }
        return {}.toString.call(o).match(/\s([a-z|A-Z]+)/)[1].toLowerCase();
      }
      function extend() {
        return merge(false, false, arguments);
      }
      function extendIf() {
        return merge(true, false, arguments);
      }
      function extendImmutable() {
        return merge(false, true, arguments);
      }
      function extendImmutableIf() {
        return merge(true, true, arguments);
      }
      function clone(value) {
        switch (typeOf(value)) {
          case "array":
            return merge(false, true, [[], value]);
          case "object":
            return merge(false, true, [{}, value]);
          default:
            return value;
        }
      }
      function shallowCopy(obj) {
        switch (typeOf(obj)) {
          case "array":
            return Array.prototype.slice.call(obj);
          case "object":
            return extend({}, obj);
        }
        return obj;
      }
      function merge(strict, immutable, args) {
        var undef;
        var target = args[0];
        each(args, function(arg, i) {
          if (i > 0) {
            each(arg, function(value, key) {
              var isComplex = inArray(typeOf(value), ["array", "object"]) !== -1;
              if (value === undef || strict && target[key] === undef) {
                return true;
              }
              if (isComplex && immutable) {
                value = shallowCopy(value);
              }
              if (typeOf(target[key]) === typeOf(value) && isComplex) {
                merge(strict, immutable, [target[key], value]);
              } else {
                target[key] = value;
              }
            });
          }
        });
        return target;
      }
      function inherit(child, parent) {
        for (var key in parent) {
          if ({}.hasOwnProperty.call(parent, key)) {
            child[key] = parent[key];
          }
        }
        function ctor() {
          this.constructor = child;
        }
        ctor.prototype = parent.prototype;
        child.prototype = new ctor();
        child.parent = parent.prototype;
        return child;
      }
      function each(obj, callback) {
        var length, key, i, undef;
        if (obj) {
          try {
            length = obj.length;
          } catch (ex) {
            length = undef;
          }
          if (length === undef || typeof length !== "number") {
            for (key in obj) {
              if (obj.hasOwnProperty(key)) {
                if (callback(obj[key], key) === false) {
                  return;
                }
              }
            }
          } else {
            for (i = 0; i < length; i++) {
              if (callback(obj[i], i) === false) {
                return;
              }
            }
          }
        }
      }
      function isEmptyObj(obj) {
        var prop;
        if (!obj || typeOf(obj) !== "object") {
          return true;
        }
        for (prop in obj) {
          return false;
        }
        return true;
      }
      function inSeries(queue, cb) {
        var i = 0, length = queue.length;
        if (typeOf(cb) !== "function") {
          cb = function() {
          };
        }
        if (!queue || !queue.length) {
          cb();
        }
        function callNext(i2) {
          if (typeOf(queue[i2]) === "function") {
            queue[i2](function(error) {
              ++i2 < length && !error ? callNext(i2) : cb(error);
            });
          }
        }
        callNext(i);
      }
      function inParallel(queue, cb) {
        var count = 0, num = queue.length, cbArgs = new Array(num);
        each(queue, function(fn, i) {
          fn(function(error) {
            if (error) {
              return cb(error);
            }
            var args = [].slice.call(arguments);
            args.shift();
            cbArgs[i] = args;
            count++;
            if (count === num) {
              cbArgs.unshift(null);
              cb.apply(this, cbArgs);
            }
          });
        });
      }
      function inArray(needle, array) {
        if (array) {
          if (Array.prototype.indexOf) {
            return Array.prototype.indexOf.call(array, needle);
          }
          for (var i = 0, length = array.length; i < length; i++) {
            if (array[i] === needle) {
              return i;
            }
          }
        }
        return -1;
      }
      function arrayDiff(needles, array) {
        var diff = [];
        if (typeOf(needles) !== "array") {
          needles = [needles];
        }
        if (typeOf(array) !== "array") {
          array = [array];
        }
        for (var i in needles) {
          if (inArray(needles[i], array) === -1) {
            diff.push(needles[i]);
          }
        }
        return diff.length ? diff : false;
      }
      function arrayIntersect(array1, array2) {
        var result = [];
        each(array1, function(item) {
          if (inArray(item, array2) !== -1) {
            result.push(item);
          }
        });
        return result.length ? result : null;
      }
      function toArray(obj) {
        var i, arr = [];
        for (i = 0; i < obj.length; i++) {
          arr[i] = obj[i];
        }
        return arr;
      }
      var guid = function() {
        var counter = 0;
        return function(prefix) {
          var guid2 = new Date().getTime().toString(32), i;
          for (i = 0; i < 5; i++) {
            guid2 += Math.floor(Math.random() * 65535).toString(32);
          }
          return (prefix || "o_") + guid2 + (counter++).toString(32);
        };
      }();
      function trim(str) {
        if (!str) {
          return str;
        }
        return String.prototype.trim ? String.prototype.trim.call(str) : str.toString().replace(/^\s*/, "").replace(/\s*$/, "");
      }
      function parseSizeStr(size) {
        if (typeof size !== "string") {
          return size;
        }
        var muls = {
          t: 1099511627776,
          g: 1073741824,
          m: 1048576,
          k: 1024
        }, mul;
        size = /^([0-9\.]+)([tmgk]?)$/.exec(size.toLowerCase().replace(/[^0-9\.tmkg]/g, ""));
        mul = size[2];
        size = +size[1];
        if (muls.hasOwnProperty(mul)) {
          size *= muls[mul];
        }
        return Math.floor(size);
      }
      function sprintf(str) {
        var args = [].slice.call(arguments, 1);
        return str.replace(/%([a-z])/g, function($0, $1) {
          var value = args.shift();
          switch ($1) {
            case "s":
              return value + "";
            case "d":
              return parseInt(value, 10);
            case "f":
              return parseFloat(value);
            case "c":
              return "";
            default:
              return value;
          }
        });
      }
      function delay(cb, timeout) {
        var self = this;
        setTimeout(function() {
          cb.call(self);
        }, timeout || 1);
      }
      return {
        guid,
        typeOf,
        extend,
        extendIf,
        extendImmutable,
        extendImmutableIf,
        clone,
        inherit,
        each,
        isEmptyObj,
        inSeries,
        inParallel,
        inArray,
        arrayDiff,
        arrayIntersect,
        toArray,
        trim,
        sprintf,
        parseSizeStr,
        delay
      };
    });
    define("moxie/core/utils/Encode", [], function() {
      var utf8_encode = function(str) {
        return unescape(encodeURIComponent(str));
      };
      var utf8_decode = function(str_data) {
        return decodeURIComponent(escape(str_data));
      };
      var atob = function(data, utf8) {
        if (typeof window.atob === "function") {
          return utf8 ? utf8_decode(window.atob(data)) : window.atob(data);
        }
        var b64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
        var o1, o2, o3, h1, h2, h3, h4, bits, i = 0, ac = 0, dec = "", tmp_arr = [];
        if (!data) {
          return data;
        }
        data += "";
        do {
          h1 = b64.indexOf(data.charAt(i++));
          h2 = b64.indexOf(data.charAt(i++));
          h3 = b64.indexOf(data.charAt(i++));
          h4 = b64.indexOf(data.charAt(i++));
          bits = h1 << 18 | h2 << 12 | h3 << 6 | h4;
          o1 = bits >> 16 & 255;
          o2 = bits >> 8 & 255;
          o3 = bits & 255;
          if (h3 == 64) {
            tmp_arr[ac++] = String.fromCharCode(o1);
          } else if (h4 == 64) {
            tmp_arr[ac++] = String.fromCharCode(o1, o2);
          } else {
            tmp_arr[ac++] = String.fromCharCode(o1, o2, o3);
          }
        } while (i < data.length);
        dec = tmp_arr.join("");
        return utf8 ? utf8_decode(dec) : dec;
      };
      var btoa = function(data, utf8) {
        if (utf8) {
          data = utf8_encode(data);
        }
        if (typeof window.btoa === "function") {
          return window.btoa(data);
        }
        var b64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
        var o1, o2, o3, h1, h2, h3, h4, bits, i = 0, ac = 0, enc = "", tmp_arr = [];
        if (!data) {
          return data;
        }
        do {
          o1 = data.charCodeAt(i++);
          o2 = data.charCodeAt(i++);
          o3 = data.charCodeAt(i++);
          bits = o1 << 16 | o2 << 8 | o3;
          h1 = bits >> 18 & 63;
          h2 = bits >> 12 & 63;
          h3 = bits >> 6 & 63;
          h4 = bits & 63;
          tmp_arr[ac++] = b64.charAt(h1) + b64.charAt(h2) + b64.charAt(h3) + b64.charAt(h4);
        } while (i < data.length);
        enc = tmp_arr.join("");
        var r = data.length % 3;
        return (r ? enc.slice(0, r - 3) : enc) + "===".slice(r || 3);
      };
      return {
        utf8_encode,
        utf8_decode,
        atob,
        btoa
      };
    });
    define("moxie/core/utils/Env", ["moxie/core/utils/Basic"], function(Basic) {
      var UAParser = function(undefined2) {
        var EMPTY = "", UNKNOWN = "?", FUNC_TYPE = "function", UNDEF_TYPE = "undefined", OBJ_TYPE = "object", NAME = "name", VERSION = "version";
        var util = {
          has: function(str1, str2) {
            return str2.toLowerCase().indexOf(str1.toLowerCase()) !== -1;
          },
          lowerize: function(str) {
            return str.toLowerCase();
          }
        };
        var mapper = {
          rgx: function() {
            for (var result, i = 0, j, k, p, q, matches, match, args = arguments; i < args.length; i += 2) {
              var regex = args[i], props = args[i + 1];
              if (typeof result === UNDEF_TYPE) {
                result = {};
                for (p in props) {
                  q = props[p];
                  if (typeof q === OBJ_TYPE) {
                    result[q[0]] = undefined2;
                  } else {
                    result[q] = undefined2;
                  }
                }
              }
              for (j = k = 0; j < regex.length; j++) {
                matches = regex[j].exec(this.getUA());
                if (!!matches) {
                  for (p = 0; p < props.length; p++) {
                    match = matches[++k];
                    q = props[p];
                    if (typeof q === OBJ_TYPE && q.length > 0) {
                      if (q.length == 2) {
                        if (typeof q[1] == FUNC_TYPE) {
                          result[q[0]] = q[1].call(this, match);
                        } else {
                          result[q[0]] = q[1];
                        }
                      } else if (q.length == 3) {
                        if (typeof q[1] === FUNC_TYPE && !(q[1].exec && q[1].test)) {
                          result[q[0]] = match ? q[1].call(this, match, q[2]) : undefined2;
                        } else {
                          result[q[0]] = match ? match.replace(q[1], q[2]) : undefined2;
                        }
                      } else if (q.length == 4) {
                        result[q[0]] = match ? q[3].call(this, match.replace(q[1], q[2])) : undefined2;
                      }
                    } else {
                      result[q] = match ? match : undefined2;
                    }
                  }
                  break;
                }
              }
              if (!!matches)
                break;
            }
            return result;
          },
          str: function(str, map) {
            for (var i in map) {
              if (typeof map[i] === OBJ_TYPE && map[i].length > 0) {
                for (var j = 0; j < map[i].length; j++) {
                  if (util.has(map[i][j], str)) {
                    return i === UNKNOWN ? undefined2 : i;
                  }
                }
              } else if (util.has(map[i], str)) {
                return i === UNKNOWN ? undefined2 : i;
              }
            }
            return str;
          }
        };
        var maps = {
          browser: {
            oldsafari: {
              major: {
                1: ["/8", "/1", "/3"],
                2: "/4",
                "?": "/"
              },
              version: {
                "1.0": "/8",
                1.2: "/1",
                1.3: "/3",
                "2.0": "/412",
                "2.0.2": "/416",
                "2.0.3": "/417",
                "2.0.4": "/419",
                "?": "/"
              }
            }
          },
          device: {
            sprint: {
              model: {
                "Evo Shift 4G": "7373KT"
              },
              vendor: {
                HTC: "APA",
                Sprint: "Sprint"
              }
            }
          },
          os: {
            windows: {
              version: {
                ME: "4.90",
                "NT 3.11": "NT3.51",
                "NT 4.0": "NT4.0",
                2e3: "NT 5.0",
                XP: ["NT 5.1", "NT 5.2"],
                Vista: "NT 6.0",
                7: "NT 6.1",
                8: "NT 6.2",
                8.1: "NT 6.3",
                RT: "ARM"
              }
            }
          }
        };
        var regexes = {
          browser: [
            [
              /(opera\smini)\/([\w\.-]+)/i,
              /(opera\s[mobiletab]+).+version\/([\w\.-]+)/i,
              /(opera).+version\/([\w\.]+)/i,
              /(opera)[\/\s]+([\w\.]+)/i
            ],
            [NAME, VERSION],
            [
              /\s(opr)\/([\w\.]+)/i
            ],
            [[NAME, "Opera"], VERSION],
            [
              /(kindle)\/([\w\.]+)/i,
              /(lunascape|maxthon|netfront|jasmine|blazer)[\/\s]?([\w\.]+)*/i,
              /(avant\s|iemobile|slim|baidu)(?:browser)?[\/\s]?([\w\.]*)/i,
              /(?:ms|\()(ie)\s([\w\.]+)/i,
              /(rekonq)\/([\w\.]+)*/i,
              /(chromium|flock|rockmelt|midori|epiphany|silk|skyfire|ovibrowser|bolt|iron|vivaldi)\/([\w\.-]+)/i
            ],
            [NAME, VERSION],
            [
              /(trident).+rv[:\s]([\w\.]+).+like\sgecko/i
            ],
            [[NAME, "IE"], VERSION],
            [
              /(edge)\/((\d+)?[\w\.]+)/i
            ],
            [NAME, VERSION],
            [
              /(yabrowser)\/([\w\.]+)/i
            ],
            [[NAME, "Yandex"], VERSION],
            [
              /(comodo_dragon)\/([\w\.]+)/i
            ],
            [[NAME, /_/g, " "], VERSION],
            [
              /(chrome|omniweb|arora|[tizenoka]{5}\s?browser)\/v?([\w\.]+)/i,
              /(uc\s?browser|qqbrowser)[\/\s]?([\w\.]+)/i
            ],
            [NAME, VERSION],
            [
              /(dolfin)\/([\w\.]+)/i
            ],
            [[NAME, "Dolphin"], VERSION],
            [
              /((?:android.+)crmo|crios)\/([\w\.]+)/i
            ],
            [[NAME, "Chrome"], VERSION],
            [
              /XiaoMi\/MiuiBrowser\/([\w\.]+)/i
            ],
            [VERSION, [NAME, "MIUI Browser"]],
            [
              /android.+version\/([\w\.]+)\s+(?:mobile\s?safari|safari)/i
            ],
            [VERSION, [NAME, "Android Browser"]],
            [
              /FBAV\/([\w\.]+);/i
            ],
            [VERSION, [NAME, "Facebook"]],
            [
              /version\/([\w\.]+).+?mobile\/\w+\s(safari)/i
            ],
            [VERSION, [NAME, "Mobile Safari"]],
            [
              /version\/([\w\.]+).+?(mobile\s?safari|safari)/i
            ],
            [VERSION, NAME],
            [
              /webkit.+?(mobile\s?safari|safari)(\/[\w\.]+)/i
            ],
            [NAME, [VERSION, mapper.str, maps.browser.oldsafari.version]],
            [
              /(konqueror)\/([\w\.]+)/i,
              /(webkit|khtml)\/([\w\.]+)/i
            ],
            [NAME, VERSION],
            [
              /(navigator|netscape)\/([\w\.-]+)/i
            ],
            [[NAME, "Netscape"], VERSION],
            [
              /(swiftfox)/i,
              /(icedragon|iceweasel|camino|chimera|fennec|maemo\sbrowser|minimo|conkeror)[\/\s]?([\w\.\+]+)/i,
              /(firefox|seamonkey|k-meleon|icecat|iceape|firebird|phoenix)\/([\w\.-]+)/i,
              /(mozilla)\/([\w\.]+).+rv\:.+gecko\/\d+/i,
              /(polaris|lynx|dillo|icab|doris|amaya|w3m|netsurf)[\/\s]?([\w\.]+)/i,
              /(links)\s\(([\w\.]+)/i,
              /(gobrowser)\/?([\w\.]+)*/i,
              /(ice\s?browser)\/v?([\w\._]+)/i,
              /(mosaic)[\/\s]([\w\.]+)/i
            ],
            [NAME, VERSION]
          ],
          engine: [
            [
              /windows.+\sedge\/([\w\.]+)/i
            ],
            [VERSION, [NAME, "EdgeHTML"]],
            [
              /(presto)\/([\w\.]+)/i,
              /(webkit|trident|netfront|netsurf|amaya|lynx|w3m)\/([\w\.]+)/i,
              /(khtml|tasman|links)[\/\s]\(?([\w\.]+)/i,
              /(icab)[\/\s]([23]\.[\d\.]+)/i
            ],
            [NAME, VERSION],
            [
              /rv\:([\w\.]+).*(gecko)/i
            ],
            [VERSION, NAME]
          ],
          os: [
            [
              /microsoft\s(windows)\s(vista|xp)/i
            ],
            [NAME, VERSION],
            [
              /(windows)\snt\s6\.2;\s(arm)/i,
              /(windows\sphone(?:\sos)*|windows\smobile|windows)[\s\/]?([ntce\d\.\s]+\w)/i
            ],
            [NAME, [VERSION, mapper.str, maps.os.windows.version]],
            [/(win(?=3|9|n)|win\s9x\s)([nt\d\.]+)/i],
            [
              [NAME, "Windows"],
              [VERSION, mapper.str, maps.os.windows.version]
            ],
            [
              /\((bb)(10);/i
            ],
            [[NAME, "BlackBerry"], VERSION],
            [
              /(blackberry)\w*\/?([\w\.]+)*/i,
              /(tizen)[\/\s]([\w\.]+)/i,
              /(android|webos|palm\os|qnx|bada|rim\stablet\sos|meego|contiki)[\/\s-]?([\w\.]+)*/i,
              /linux;.+(sailfish);/i
            ],
            [NAME, VERSION],
            [
              /(symbian\s?os|symbos|s60(?=;))[\/\s-]?([\w\.]+)*/i
            ],
            [[NAME, "Symbian"], VERSION],
            [
              /\((series40);/i
            ],
            [NAME],
            [
              /mozilla.+\(mobile;.+gecko.+firefox/i
            ],
            [[NAME, "Firefox OS"], VERSION],
            [
              /(nintendo|playstation)\s([wids3portablevu]+)/i,
              /(mint)[\/\s\(]?(\w+)*/i,
              /(mageia|vectorlinux)[;\s]/i,
              /(joli|[kxln]?ubuntu|debian|[open]*suse|gentoo|arch|slackware|fedora|mandriva|centos|pclinuxos|redhat|zenwalk|linpus)[\/\s-]?([\w\.-]+)*/i,
              /(hurd|linux)\s?([\w\.]+)*/i,
              /(gnu)\s?([\w\.]+)*/i
            ],
            [NAME, VERSION],
            [
              /(cros)\s[\w]+\s([\w\.]+\w)/i
            ],
            [[NAME, "Chromium OS"], VERSION],
            [
              /(sunos)\s?([\w\.]+\d)*/i
            ],
            [[NAME, "Solaris"], VERSION],
            [
              /\s([frentopc-]{0,4}bsd|dragonfly)\s?([\w\.]+)*/i
            ],
            [NAME, VERSION],
            [
              /(ip[honead]+)(?:.*os\s*([\w]+)*\slike\smac|;\sopera)/i
            ],
            [
              [NAME, "iOS"],
              [VERSION, /_/g, "."]
            ],
            [
              /(mac\sos\sx)\s?([\w\s\.]+\w)*/i,
              /(macintosh|mac(?=_powerpc)\s)/i
            ],
            [
              [NAME, "Mac OS"],
              [VERSION, /_/g, "."]
            ],
            [
              /((?:open)?solaris)[\/\s-]?([\w\.]+)*/i,
              /(haiku)\s(\w+)/i,
              /(aix)\s((\d)(?=\.|\)|\s)[\w\.]*)*/i,
              /(plan\s9|minix|beos|os\/2|amigaos|morphos|risc\sos|openvms)/i,
              /(unix)\s?([\w\.]+)*/i
            ],
            [NAME, VERSION]
          ]
        };
        var UAParser2 = function(uastring) {
          var ua = uastring || (window && window.navigator && window.navigator.userAgent ? window.navigator.userAgent : EMPTY);
          this.getBrowser = function() {
            return mapper.rgx.apply(this, regexes.browser);
          };
          this.getEngine = function() {
            return mapper.rgx.apply(this, regexes.engine);
          };
          this.getOS = function() {
            return mapper.rgx.apply(this, regexes.os);
          };
          this.getResult = function() {
            return {
              ua: this.getUA(),
              browser: this.getBrowser(),
              engine: this.getEngine(),
              os: this.getOS()
            };
          };
          this.getUA = function() {
            return ua;
          };
          this.setUA = function(uastring2) {
            ua = uastring2;
            return this;
          };
          this.setUA(ua);
        };
        return UAParser2;
      }();
      function version_compare(v1, v2, operator) {
        var i = 0, x = 0, compare = 0, vm = {
          dev: -6,
          alpha: -5,
          a: -5,
          beta: -4,
          b: -4,
          RC: -3,
          rc: -3,
          "#": -2,
          p: 1,
          pl: 1
        }, prepVersion = function(v) {
          v = ("" + v).replace(/[_\-+]/g, ".");
          v = v.replace(/([^.\d]+)/g, ".$1.").replace(/\.{2,}/g, ".");
          return !v.length ? [-8] : v.split(".");
        }, numVersion = function(v) {
          return !v ? 0 : isNaN(v) ? vm[v] || -7 : parseInt(v, 10);
        };
        v1 = prepVersion(v1);
        v2 = prepVersion(v2);
        x = Math.max(v1.length, v2.length);
        for (i = 0; i < x; i++) {
          if (v1[i] == v2[i]) {
            continue;
          }
          v1[i] = numVersion(v1[i]);
          v2[i] = numVersion(v2[i]);
          if (v1[i] < v2[i]) {
            compare = -1;
            break;
          } else if (v1[i] > v2[i]) {
            compare = 1;
            break;
          }
        }
        if (!operator) {
          return compare;
        }
        switch (operator) {
          case ">":
          case "gt":
            return compare > 0;
          case ">=":
          case "ge":
            return compare >= 0;
          case "<=":
          case "le":
            return compare <= 0;
          case "==":
          case "=":
          case "eq":
            return compare === 0;
          case "<>":
          case "!=":
          case "ne":
            return compare !== 0;
          case "":
          case "<":
          case "lt":
            return compare < 0;
          default:
            return null;
        }
      }
      var can = function() {
        var caps = {
          access_global_ns: function() {
            return !!window.moxie;
          },
          define_property: function() {
            return false;
          }(),
          create_canvas: function() {
            var el = document.createElement("canvas");
            var isSupported = !!(el.getContext && el.getContext("2d"));
            caps.create_canvas = isSupported;
            return isSupported;
          },
          return_response_type: function(responseType) {
            try {
              if (Basic.inArray(responseType, ["", "text", "document"]) !== -1) {
                return true;
              } else if (window.XMLHttpRequest) {
                var xhr = new XMLHttpRequest();
                xhr.open("get", "/");
                if ("responseType" in xhr) {
                  xhr.responseType = responseType;
                  if (xhr.responseType !== responseType) {
                    return false;
                  }
                  return true;
                }
              }
            } catch (ex) {
            }
            return false;
          },
          use_blob_uri: function() {
            var URL = window.URL;
            caps.use_blob_uri = URL && "createObjectURL" in URL && "revokeObjectURL" in URL && (Env.browser !== "IE" || Env.verComp(Env.version, "11.0.46", ">="));
            return caps.use_blob_uri;
          },
          use_data_uri: function() {
            var du = new Image();
            du.onload = function() {
              caps.use_data_uri = du.width === 1 && du.height === 1;
            };
            setTimeout(function() {
              du.src = "data:image/gif;base64,R0lGODlhAQABAIAAAP8AAAAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==";
            }, 1);
            return false;
          }(),
          use_data_uri_over32kb: function() {
            return caps.use_data_uri && (Env.browser !== "IE" || Env.version >= 9);
          },
          use_data_uri_of: function(bytes) {
            return caps.use_data_uri && bytes < 33e3 || caps.use_data_uri_over32kb();
          },
          use_fileinput: function() {
            if (navigator.userAgent.match(
              /(Android (1.0|1.1|1.5|1.6|2.0|2.1))|(Windows Phone (OS 7|8.0))|(XBLWP)|(ZuneWP)|(w(eb)?OSBrowser)|(webOS)|(Kindle\/(1.0|2.0|2.5|3.0))/
            )) {
              return false;
            }
            var el = document.createElement("input");
            el.setAttribute("type", "file");
            return caps.use_fileinput = !el.disabled;
          },
          use_webgl: function() {
            var canvas = document.createElement("canvas");
            var gl = null, isSupported;
            try {
              gl = canvas.getContext("webgl") || canvas.getContext("experimental-webgl");
            } catch (e) {
            }
            if (!gl) {
              gl = null;
            }
            isSupported = !!gl;
            caps.use_webgl = isSupported;
            canvas = undefined$1;
            return isSupported;
          }
        };
        return function(cap) {
          var args = [].slice.call(arguments);
          args.shift();
          return Basic.typeOf(caps[cap]) === "function" ? caps[cap].apply(this, args) : !!caps[cap];
        };
      }();
      var uaResult = new UAParser().getResult();
      var Env = {
        can,
        uaParser: UAParser,
        browser: uaResult.browser.name,
        version: uaResult.browser.version,
        os: uaResult.os.name,
        osVersion: uaResult.os.version,
        verComp: version_compare,
        swf_url: "../flash/Moxie.swf",
        xap_url: "../silverlight/Moxie.xap",
        global_event_dispatcher: "moxie.core.EventTarget.instance.dispatchEvent"
      };
      Env.OS = Env.os;
      return Env;
    });
    define("moxie/core/Exceptions", ["moxie/core/utils/Basic"], function(Basic) {
      function _findKey(obj, value) {
        var key;
        for (key in obj) {
          if (obj[key] === value) {
            return key;
          }
        }
        return null;
      }
      return {
        RuntimeError: function() {
          var namecodes = {
            NOT_INIT_ERR: 1,
            EXCEPTION_ERR: 3,
            NOT_SUPPORTED_ERR: 9,
            JS_ERR: 4
          };
          function RuntimeError(code, message) {
            this.code = code;
            this.name = _findKey(namecodes, code);
            this.message = this.name + (message || ": RuntimeError " + this.code);
          }
          Basic.extend(RuntimeError, namecodes);
          RuntimeError.prototype = Error.prototype;
          return RuntimeError;
        }(),
        OperationNotAllowedException: function() {
          function OperationNotAllowedException(code) {
            this.code = code;
            this.name = "OperationNotAllowedException";
          }
          Basic.extend(OperationNotAllowedException, {
            NOT_ALLOWED_ERR: 1
          });
          OperationNotAllowedException.prototype = Error.prototype;
          return OperationNotAllowedException;
        }(),
        ImageError: function() {
          var namecodes = {
            WRONG_FORMAT: 1,
            MAX_RESOLUTION_ERR: 2,
            INVALID_META_ERR: 3
          };
          function ImageError(code) {
            this.code = code;
            this.name = _findKey(namecodes, code);
            this.message = this.name + ": ImageError " + this.code;
          }
          Basic.extend(ImageError, namecodes);
          ImageError.prototype = Error.prototype;
          return ImageError;
        }(),
        FileException: function() {
          var namecodes = {
            NOT_FOUND_ERR: 1,
            SECURITY_ERR: 2,
            ABORT_ERR: 3,
            NOT_READABLE_ERR: 4,
            ENCODING_ERR: 5,
            NO_MODIFICATION_ALLOWED_ERR: 6,
            INVALID_STATE_ERR: 7,
            SYNTAX_ERR: 8
          };
          function FileException(code) {
            this.code = code;
            this.name = _findKey(namecodes, code);
            this.message = this.name + ": FileException " + this.code;
          }
          Basic.extend(FileException, namecodes);
          FileException.prototype = Error.prototype;
          return FileException;
        }(),
        DOMException: function() {
          var namecodes = {
            INDEX_SIZE_ERR: 1,
            DOMSTRING_SIZE_ERR: 2,
            HIERARCHY_REQUEST_ERR: 3,
            WRONG_DOCUMENT_ERR: 4,
            INVALID_CHARACTER_ERR: 5,
            NO_DATA_ALLOWED_ERR: 6,
            NO_MODIFICATION_ALLOWED_ERR: 7,
            NOT_FOUND_ERR: 8,
            NOT_SUPPORTED_ERR: 9,
            INUSE_ATTRIBUTE_ERR: 10,
            INVALID_STATE_ERR: 11,
            SYNTAX_ERR: 12,
            INVALID_MODIFICATION_ERR: 13,
            NAMESPACE_ERR: 14,
            INVALID_ACCESS_ERR: 15,
            VALIDATION_ERR: 16,
            TYPE_MISMATCH_ERR: 17,
            SECURITY_ERR: 18,
            NETWORK_ERR: 19,
            ABORT_ERR: 20,
            URL_MISMATCH_ERR: 21,
            QUOTA_EXCEEDED_ERR: 22,
            TIMEOUT_ERR: 23,
            INVALID_NODE_TYPE_ERR: 24,
            DATA_CLONE_ERR: 25
          };
          function DOMException(code) {
            this.code = code;
            this.name = _findKey(namecodes, code);
            this.message = this.name + ": DOMException " + this.code;
          }
          Basic.extend(DOMException, namecodes);
          DOMException.prototype = Error.prototype;
          return DOMException;
        }(),
        EventException: function() {
          function EventException(code) {
            this.code = code;
            this.name = "EventException";
          }
          Basic.extend(EventException, {
            UNSPECIFIED_EVENT_TYPE_ERR: 0
          });
          EventException.prototype = Error.prototype;
          return EventException;
        }()
      };
    });
    define("moxie/core/utils/Dom", ["moxie/core/utils/Env"], function(Env) {
      var get = function(id) {
        if (typeof id !== "string") {
          return id;
        }
        return document.getElementById(id);
      };
      var hasClass = function(obj, name) {
        if (!obj.className) {
          return false;
        }
        var regExp = new RegExp("(^|\\s+)" + name + "(\\s+|$)");
        return regExp.test(obj.className);
      };
      var addClass = function(obj, name) {
        if (!hasClass(obj, name)) {
          obj.className = !obj.className ? name : obj.className.replace(/\s+$/, "") + " " + name;
        }
      };
      var removeClass = function(obj, name) {
        if (obj.className) {
          var regExp = new RegExp("(^|\\s+)" + name + "(\\s+|$)");
          obj.className = obj.className.replace(regExp, function($0, $1, $2) {
            return $1 === " " && $2 === " " ? " " : "";
          });
        }
      };
      var getStyle = function(obj, name) {
        if (obj.currentStyle) {
          return obj.currentStyle[name];
        } else if (window.getComputedStyle) {
          return window.getComputedStyle(obj, null)[name];
        }
      };
      var getPos = function(node, root) {
        var x = 0, y = 0, parent, doc = document, nodeRect, rootRect;
        node = node;
        root = root || doc.body;
        function getIEPos(node2) {
          var bodyElm, rect, x2 = 0, y2 = 0;
          if (node2) {
            rect = node2.getBoundingClientRect();
            bodyElm = doc.compatMode === "CSS1Compat" ? doc.documentElement : doc.body;
            x2 = rect.left + bodyElm.scrollLeft;
            y2 = rect.top + bodyElm.scrollTop;
          }
          return {
            x: x2,
            y: y2
          };
        }
        if (node && node.getBoundingClientRect && Env.browser === "IE" && (!doc.documentMode || doc.documentMode < 8)) {
          nodeRect = getIEPos(node);
          rootRect = getIEPos(root);
          return {
            x: nodeRect.x - rootRect.x,
            y: nodeRect.y - rootRect.y
          };
        }
        parent = node;
        while (parent && parent != root && parent.nodeType) {
          x += parent.offsetLeft || 0;
          y += parent.offsetTop || 0;
          parent = parent.offsetParent;
        }
        parent = node.parentNode;
        while (parent && parent != root && parent.nodeType) {
          x -= parent.scrollLeft || 0;
          y -= parent.scrollTop || 0;
          parent = parent.parentNode;
        }
        return {
          x,
          y
        };
      };
      var getSize = function(node) {
        return {
          w: node.offsetWidth || node.clientWidth,
          h: node.offsetHeight || node.clientHeight
        };
      };
      return {
        get,
        hasClass,
        addClass,
        removeClass,
        getStyle,
        getPos,
        getSize
      };
    });
    define("moxie/core/EventTarget", [
      "moxie/core/utils/Env",
      "moxie/core/Exceptions",
      "moxie/core/utils/Basic"
    ], function(Env, x, Basic) {
      var eventpool = {};
      function EventTarget() {
        this.uid = Basic.guid();
      }
      Basic.extend(EventTarget.prototype, {
        init: function() {
          if (!this.uid) {
            this.uid = Basic.guid("uid_");
          }
        },
        addEventListener: function(type, fn, priority, scope) {
          var self = this, list;
          if (!this.hasOwnProperty("uid")) {
            this.uid = Basic.guid("uid_");
          }
          type = Basic.trim(type);
          if (/\s/.test(type)) {
            Basic.each(type.split(/\s+/), function(type2) {
              self.addEventListener(type2, fn, priority, scope);
            });
            return;
          }
          type = type.toLowerCase();
          priority = parseInt(priority, 10) || 0;
          list = eventpool[this.uid] && eventpool[this.uid][type] || [];
          list.push({ fn, priority, scope: scope || this });
          if (!eventpool[this.uid]) {
            eventpool[this.uid] = {};
          }
          eventpool[this.uid][type] = list;
        },
        hasEventListener: function(type) {
          var list;
          if (type) {
            type = type.toLowerCase();
            list = eventpool[this.uid] && eventpool[this.uid][type];
          } else {
            list = eventpool[this.uid];
          }
          return list ? list : false;
        },
        removeEventListener: function(type, fn) {
          var self = this, list, i;
          type = type.toLowerCase();
          if (/\s/.test(type)) {
            Basic.each(type.split(/\s+/), function(type2) {
              self.removeEventListener(type2, fn);
            });
            return;
          }
          list = eventpool[this.uid] && eventpool[this.uid][type];
          if (list) {
            if (fn) {
              for (i = list.length - 1; i >= 0; i--) {
                if (list[i].fn === fn) {
                  list.splice(i, 1);
                  break;
                }
              }
            } else {
              list = [];
            }
            if (!list.length) {
              delete eventpool[this.uid][type];
              if (Basic.isEmptyObj(eventpool[this.uid])) {
                delete eventpool[this.uid];
              }
            }
          }
        },
        removeAllEventListeners: function() {
          if (eventpool[this.uid]) {
            delete eventpool[this.uid];
          }
        },
        dispatchEvent: function(type) {
          var uid, list, args, tmpEvt, evt = {}, result = true, undef;
          if (Basic.typeOf(type) !== "string") {
            tmpEvt = type;
            if (Basic.typeOf(tmpEvt.type) === "string") {
              type = tmpEvt.type;
              if (tmpEvt.total !== undef && tmpEvt.loaded !== undef) {
                evt.total = tmpEvt.total;
                evt.loaded = tmpEvt.loaded;
              }
              evt.async = tmpEvt.async || false;
            } else {
              throw new x.EventException(x.EventException.UNSPECIFIED_EVENT_TYPE_ERR);
            }
          }
          if (type.indexOf("::") !== -1) {
            (function(arr) {
              uid = arr[0];
              type = arr[1];
            })(type.split("::"));
          } else {
            uid = this.uid;
          }
          type = type.toLowerCase();
          list = eventpool[uid] && eventpool[uid][type];
          if (list) {
            list.sort(function(a, b) {
              return b.priority - a.priority;
            });
            args = [].slice.call(arguments);
            args.shift();
            evt.type = type;
            args.unshift(evt);
            var queue = [];
            Basic.each(list, function(handler) {
              args[0].target = handler.scope;
              if (evt.async) {
                queue.push(function(cb) {
                  setTimeout(function() {
                    cb(handler.fn.apply(handler.scope, args) === false);
                  }, 1);
                });
              } else {
                queue.push(function(cb) {
                  cb(handler.fn.apply(handler.scope, args) === false);
                });
              }
            });
            if (queue.length) {
              Basic.inSeries(queue, function(err) {
                result = !err;
              });
            }
          }
          return result;
        },
        bindOnce: function(type, fn, priority, scope) {
          var self = this;
          self.bind.call(
            this,
            type,
            function cb() {
              self.unbind(type, cb);
              return fn.apply(this, arguments);
            },
            priority,
            scope
          );
        },
        bind: function() {
          this.addEventListener.apply(this, arguments);
        },
        unbind: function() {
          this.removeEventListener.apply(this, arguments);
        },
        unbindAll: function() {
          this.removeAllEventListeners.apply(this, arguments);
        },
        trigger: function() {
          return this.dispatchEvent.apply(this, arguments);
        },
        handleEventProps: function(dispatches) {
          var self = this;
          this.bind(dispatches.join(" "), function(e) {
            var prop = "on" + e.type.toLowerCase();
            if (Basic.typeOf(this[prop]) === "function") {
              this[prop].apply(this, arguments);
            }
          });
          Basic.each(dispatches, function(prop) {
            prop = "on" + prop.toLowerCase(prop);
            if (Basic.typeOf(self[prop]) === "undefined") {
              self[prop] = null;
            }
          });
        }
      });
      EventTarget.instance = new EventTarget();
      return EventTarget;
    });
    define("moxie/runtime/Runtime", [
      "moxie/core/utils/Env",
      "moxie/core/utils/Basic",
      "moxie/core/utils/Dom",
      "moxie/core/EventTarget"
    ], function(Env, Basic, Dom, EventTarget) {
      var runtimeConstructors = {}, runtimes = {};
      function Runtime(options, type, caps, modeCaps, preferredMode) {
        var self = this, _shim, _uid = Basic.guid(type + "_"), defaultMode = preferredMode || "browser";
        options = options || {};
        runtimes[_uid] = this;
        caps = Basic.extend(
          {
            access_binary: false,
            access_image_binary: false,
            display_media: false,
            do_cors: false,
            drag_and_drop: false,
            filter_by_extension: true,
            resize_image: false,
            report_upload_progress: false,
            return_response_headers: false,
            return_response_type: false,
            return_status_code: true,
            send_custom_headers: false,
            select_file: false,
            select_folder: false,
            select_multiple: true,
            send_binary_string: false,
            send_browser_cookies: true,
            send_multipart: true,
            slice_blob: false,
            stream_upload: false,
            summon_file_dialog: false,
            upload_filesize: true,
            use_http_method: true
          },
          caps
        );
        if (options.preferred_caps) {
          defaultMode = Runtime.getMode(modeCaps, options.preferred_caps, defaultMode);
        }
        _shim = function() {
          var objpool = {};
          return {
            exec: function(uid, comp, fn, args) {
              if (_shim[comp]) {
                if (!objpool[uid]) {
                  objpool[uid] = {
                    context: this,
                    instance: new _shim[comp]()
                  };
                }
                if (objpool[uid].instance[fn]) {
                  return objpool[uid].instance[fn].apply(this, args);
                }
              }
            },
            removeInstance: function(uid) {
              delete objpool[uid];
            },
            removeAllInstances: function() {
              var self2 = this;
              Basic.each(objpool, function(obj, uid) {
                if (Basic.typeOf(obj.instance.destroy) === "function") {
                  obj.instance.destroy.call(obj.context);
                }
                self2.removeInstance(uid);
              });
            }
          };
        }();
        Basic.extend(this, {
          initialized: false,
          uid: _uid,
          type,
          mode: Runtime.getMode(modeCaps, options.required_caps, defaultMode),
          shimid: _uid + "_container",
          clients: 0,
          options,
          can: function(cap, value) {
            var refCaps = arguments[2] || caps;
            if (Basic.typeOf(cap) === "string" && Basic.typeOf(value) === "undefined") {
              cap = Runtime.parseCaps(cap);
            }
            if (Basic.typeOf(cap) === "object") {
              for (var key in cap) {
                if (!this.can(key, cap[key], refCaps)) {
                  return false;
                }
              }
              return true;
            }
            if (Basic.typeOf(refCaps[cap]) === "function") {
              return refCaps[cap].call(this, value);
            } else {
              return value === refCaps[cap];
            }
          },
          getShimContainer: function() {
            var container, shimContainer = Dom.get(this.shimid);
            if (!shimContainer) {
              container = Dom.get(this.options.container) || document.body;
              shimContainer = document.createElement("div");
              shimContainer.id = this.shimid;
              shimContainer.className = "moxie-shim moxie-shim-" + this.type;
              Basic.extend(shimContainer.style, {
                position: "absolute",
                top: "0px",
                left: "0px",
                width: "1px",
                height: "1px",
                overflow: "hidden"
              });
              container.appendChild(shimContainer);
              container = null;
            }
            return shimContainer;
          },
          getShim: function() {
            return _shim;
          },
          shimExec: function(component, action) {
            var args = [].slice.call(arguments, 2);
            return self.getShim().exec.call(this, this.uid, component, action, args);
          },
          exec: function(component, action) {
            var args = [].slice.call(arguments, 2);
            if (self[component] && self[component][action]) {
              return self[component][action].apply(this, args);
            }
            return self.shimExec.apply(this, arguments);
          },
          destroy: function() {
            if (!self) {
              return;
            }
            var shimContainer = Dom.get(this.shimid);
            if (shimContainer) {
              shimContainer.parentNode.removeChild(shimContainer);
            }
            if (_shim) {
              _shim.removeAllInstances();
            }
            this.unbindAll();
            delete runtimes[this.uid];
            this.uid = null;
            _uid = self = _shim = shimContainer = null;
          }
        });
        if (this.mode && options.required_caps && !this.can(options.required_caps)) {
          this.mode = false;
        }
      }
      Runtime.order = "html5,flash,silverlight,html4";
      Runtime.getRuntime = function(uid) {
        return runtimes[uid] ? runtimes[uid] : false;
      };
      Runtime.addConstructor = function(type, constructor) {
        constructor.prototype = EventTarget.instance;
        runtimeConstructors[type] = constructor;
      };
      Runtime.getConstructor = function(type) {
        return runtimeConstructors[type] || null;
      };
      Runtime.getInfo = function(uid) {
        var runtime = Runtime.getRuntime(uid);
        if (runtime) {
          return {
            uid: runtime.uid,
            type: runtime.type,
            mode: runtime.mode,
            can: function() {
              return runtime.can.apply(runtime, arguments);
            }
          };
        }
        return null;
      };
      Runtime.parseCaps = function(capStr) {
        var capObj = {};
        if (Basic.typeOf(capStr) !== "string") {
          return capStr || {};
        }
        Basic.each(capStr.split(","), function(key) {
          capObj[key] = true;
        });
        return capObj;
      };
      Runtime.can = function(type, caps) {
        var runtime, constructor = Runtime.getConstructor(type), mode;
        if (constructor) {
          runtime = new constructor({
            required_caps: caps
          });
          mode = runtime.mode;
          runtime.destroy();
          return !!mode;
        }
        return false;
      };
      Runtime.thatCan = function(caps, runtimeOrder) {
        var types = (runtimeOrder || Runtime.order).split(/\s*,\s*/);
        for (var i in types) {
          if (Runtime.can(types[i], caps)) {
            return types[i];
          }
        }
        return null;
      };
      Runtime.getMode = function(modeCaps, requiredCaps, defaultMode) {
        var mode = null;
        if (Basic.typeOf(defaultMode) === "undefined") {
          defaultMode = "browser";
        }
        if (requiredCaps && !Basic.isEmptyObj(modeCaps)) {
          Basic.each(requiredCaps, function(value, cap) {
            if (modeCaps.hasOwnProperty(cap)) {
              var capMode = modeCaps[cap](value);
              if (typeof capMode === "string") {
                capMode = [capMode];
              }
              if (!mode) {
                mode = capMode;
              } else if (!(mode = Basic.arrayIntersect(mode, capMode))) {
                return mode = false;
              }
            }
          });
          if (mode) {
            return Basic.inArray(defaultMode, mode) !== -1 ? defaultMode : mode[0];
          } else if (mode === false) {
            return false;
          }
        }
        return defaultMode;
      };
      Runtime.getGlobalEventTarget = function() {
        if (/^moxie\./.test(Env.global_event_dispatcher) && !Env.can("access_global_ns")) {
          var uniqueCallbackName = Basic.guid("moxie_event_target_");
          window[uniqueCallbackName] = function(e, data) {
            EventTarget.instance.dispatchEvent(e, data);
          };
          Env.global_event_dispatcher = uniqueCallbackName;
        }
        return Env.global_event_dispatcher;
      };
      Runtime.capTrue = function() {
        return true;
      };
      Runtime.capFalse = function() {
        return false;
      };
      Runtime.capTest = function(expr) {
        return function() {
          return !!expr;
        };
      };
      return Runtime;
    });
    define("moxie/runtime/RuntimeClient", [
      "moxie/core/utils/Env",
      "moxie/core/Exceptions",
      "moxie/core/utils/Basic",
      "moxie/runtime/Runtime"
    ], function(Env, x, Basic, Runtime) {
      return function RuntimeClient() {
        var runtime;
        Basic.extend(this, {
          connectRuntime: function(options) {
            var comp = this, ruid;
            function initialize(items) {
              var type, constructor;
              if (!items.length) {
                comp.trigger("RuntimeError", new x.RuntimeError(x.RuntimeError.NOT_INIT_ERR));
                runtime = null;
                return;
              }
              type = items.shift().toLowerCase();
              constructor = Runtime.getConstructor(type);
              if (!constructor) {
                initialize(items);
                return;
              }
              runtime = new constructor(options);
              runtime.bind("Init", function() {
                runtime.initialized = true;
                setTimeout(function() {
                  runtime.clients++;
                  comp.ruid = runtime.uid;
                  comp.trigger("RuntimeInit", runtime);
                }, 1);
              });
              runtime.bind("Error", function() {
                runtime.destroy();
                initialize(items);
              });
              runtime.bind("Exception", function(e, err) {
                var message = err.name + "(#" + err.code + ")" + (err.message ? ", from: " + err.message : "");
                comp.trigger("RuntimeError", new x.RuntimeError(x.RuntimeError.EXCEPTION_ERR, message));
              });
              if (!runtime.mode) {
                runtime.trigger("Error");
                return;
              }
              runtime.init();
            }
            if (Basic.typeOf(options) === "string") {
              ruid = options;
            } else if (Basic.typeOf(options.ruid) === "string") {
              ruid = options.ruid;
            }
            if (ruid) {
              runtime = Runtime.getRuntime(ruid);
              if (runtime) {
                comp.ruid = ruid;
                runtime.clients++;
                return runtime;
              } else {
                throw new x.RuntimeError(x.RuntimeError.NOT_INIT_ERR);
              }
            }
            initialize((options.runtime_order || Runtime.order).split(/\s*,\s*/));
          },
          disconnectRuntime: function() {
            if (runtime && --runtime.clients <= 0) {
              runtime.destroy();
            }
            runtime = null;
          },
          getRuntime: function() {
            if (runtime && runtime.uid) {
              return runtime;
            }
            return runtime = null;
          },
          exec: function() {
            return runtime ? runtime.exec.apply(this, arguments) : null;
          },
          can: function(cap) {
            return runtime ? runtime.can(cap) : false;
          }
        });
      };
    });
    define("moxie/file/Blob", [
      "moxie/core/utils/Basic",
      "moxie/core/utils/Encode",
      "moxie/runtime/RuntimeClient"
    ], function(Basic, Encode, RuntimeClient) {
      var blobpool = {};
      function Blob(ruid, blob) {
        function _sliceDetached(start, end, type) {
          var blob2, data = blobpool[this.uid];
          if (Basic.typeOf(data) !== "string" || !data.length) {
            return null;
          }
          blob2 = new Blob(null, {
            type,
            size: end - start
          });
          blob2.detach(data.substr(start, blob2.size));
          return blob2;
        }
        RuntimeClient.call(this);
        if (ruid) {
          this.connectRuntime(ruid);
        }
        if (!blob) {
          blob = {};
        } else if (Basic.typeOf(blob) === "string") {
          blob = { data: blob };
        }
        Basic.extend(this, {
          uid: blob.uid || Basic.guid("uid_"),
          ruid,
          size: blob.size || 0,
          type: blob.type || "",
          slice: function(start, end, type) {
            if (this.isDetached()) {
              return _sliceDetached.apply(this, arguments);
            }
            return this.getRuntime().exec.call(this, "Blob", "slice", this.getSource(), start, end, type);
          },
          getSource: function() {
            if (!blobpool[this.uid]) {
              return null;
            }
            return blobpool[this.uid];
          },
          detach: function(data) {
            if (this.ruid) {
              this.getRuntime().exec.call(this, "Blob", "destroy");
              this.disconnectRuntime();
              this.ruid = null;
            }
            data = data || "";
            if (data.substr(0, 5) == "data:") {
              var base64Offset = data.indexOf(";base64,");
              this.type = data.substring(5, base64Offset);
              data = Encode.atob(data.substring(base64Offset + 8));
            }
            this.size = data.length;
            blobpool[this.uid] = data;
          },
          isDetached: function() {
            return !this.ruid && Basic.typeOf(blobpool[this.uid]) === "string";
          },
          destroy: function() {
            this.detach();
            delete blobpool[this.uid];
          }
        });
        if (blob.data) {
          this.detach(blob.data);
        } else {
          blobpool[this.uid] = blob;
        }
      }
      return Blob;
    });
    define("moxie/core/I18n", ["moxie/core/utils/Basic"], function(Basic) {
      var i18n = {};
      return {
        addI18n: function(pack) {
          return Basic.extend(i18n, pack);
        },
        translate: function(str) {
          return i18n[str] || str;
        },
        _: function(str) {
          return this.translate(str);
        },
        sprintf: function(str) {
          var args = [].slice.call(arguments, 1);
          return str.replace(/%[a-z]/g, function() {
            var value = args.shift();
            return Basic.typeOf(value) !== "undefined" ? value : "";
          });
        }
      };
    });
    define("moxie/core/utils/Mime", ["moxie/core/utils/Basic", "moxie/core/I18n"], function(Basic, I18n) {
      var mimeData = "application/msword,doc dot,application/pdf,pdf,application/pgp-signature,pgp,application/postscript,ps ai eps,application/rtf,rtf,application/vnd.ms-excel,xls xlb xlt xla,application/vnd.ms-powerpoint,ppt pps pot ppa,application/zip,zip,application/x-shockwave-flash,swf swfl,application/vnd.openxmlformats-officedocument.wordprocessingml.document,docx,application/vnd.openxmlformats-officedocument.wordprocessingml.template,dotx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,xlsx,application/vnd.openxmlformats-officedocument.presentationml.presentation,pptx,application/vnd.openxmlformats-officedocument.presentationml.template,potx,application/vnd.openxmlformats-officedocument.presentationml.slideshow,ppsx,application/x-javascript,js,application/json,json,audio/mpeg,mp3 mpga mpega mp2,audio/x-wav,wav,audio/x-m4a,m4a,audio/ogg,oga ogg,audio/aiff,aiff aif,audio/flac,flac,audio/aac,aac,audio/ac3,ac3,audio/x-ms-wma,wma,image/bmp,bmp,image/gif,gif,image/jpeg,jpg jpeg jpe,image/photoshop,psd,image/png,png,image/svg+xml,svg svgz,image/tiff,tiff tif,text/plain,asc txt text diff log,text/html,htm html xhtml,text/css,css,text/csv,csv,text/rtf,rtf,video/mpeg,mpeg mpg mpe m2v,video/quicktime,qt mov,video/mp4,mp4,video/x-m4v,m4v,video/x-flv,flv,video/x-ms-wmv,wmv,video/avi,avi,video/webm,webm,video/3gpp,3gpp 3gp,video/3gpp2,3g2,video/vnd.rn-realvideo,rv,video/ogg,ogv,video/x-matroska,mkv,application/vnd.oasis.opendocument.formula-template,otf,application/octet-stream,exe";
      var mimes = {};
      var extensions = {};
      var addMimeType = function(mimeData2) {
        var items = mimeData2.split(/,/), i, ii, ext;
        for (i = 0; i < items.length; i += 2) {
          ext = items[i + 1].split(/ /);
          for (ii = 0; ii < ext.length; ii++) {
            mimes[ext[ii]] = items[i];
          }
          extensions[items[i]] = ext;
        }
      };
      var extList2mimes = function(filters, addMissingExtensions) {
        var ext, i, ii, type, mimes2 = [];
        for (i = 0; i < filters.length; i++) {
          ext = filters[i].extensions.toLowerCase().split(/\s*,\s*/);
          for (ii = 0; ii < ext.length; ii++) {
            if (ext[ii] === "*") {
              return [];
            }
            type = mimes2[ext[ii]];
            if (addMissingExtensions && /^\w+$/.test(ext[ii])) {
              mimes2.push("." + ext[ii]);
            } else if (type && Basic.inArray(type, mimes2) === -1) {
              mimes2.push(type);
            } else if (!type) {
              return [];
            }
          }
        }
        return mimes2;
      };
      var mimes2exts = function(mimes2) {
        var exts = [];
        Basic.each(mimes2, function(mime) {
          mime = mime.toLowerCase();
          if (mime === "*") {
            exts = [];
            return false;
          }
          var m = mime.match(/^(\w+)\/(\*|\w+)$/);
          if (m) {
            if (m[2] === "*") {
              Basic.each(extensions, function(arr, mime2) {
                if (new RegExp("^" + m[1] + "/").test(mime2)) {
                  [].push.apply(exts, extensions[mime2]);
                }
              });
            } else if (extensions[mime]) {
              [].push.apply(exts, extensions[mime]);
            }
          }
        });
        return exts;
      };
      var mimes2extList = function(mimes2) {
        var accept = [], exts = [];
        if (Basic.typeOf(mimes2) === "string") {
          mimes2 = Basic.trim(mimes2).split(/\s*,\s*/);
        }
        exts = mimes2exts(mimes2);
        accept.push({
          title: I18n.translate("Files"),
          extensions: exts.length ? exts.join(",") : "*"
        });
        return accept;
      };
      var getFileExtension = function(fileName) {
        var matches = fileName && fileName.match(/\.([^.]+)$/);
        if (matches) {
          return matches[1].toLowerCase();
        }
        return "";
      };
      var getFileMime = function(fileName) {
        return mimes[getFileExtension(fileName)] || "";
      };
      addMimeType(mimeData);
      return {
        mimes,
        extensions,
        addMimeType,
        extList2mimes,
        mimes2exts,
        mimes2extList,
        getFileExtension,
        getFileMime
      };
    });
    define("moxie/file/FileInput", [
      "moxie/core/utils/Basic",
      "moxie/core/utils/Env",
      "moxie/core/utils/Mime",
      "moxie/core/utils/Dom",
      "moxie/core/Exceptions",
      "moxie/core/EventTarget",
      "moxie/core/I18n",
      "moxie/runtime/Runtime",
      "moxie/runtime/RuntimeClient"
    ], function(Basic, Env, Mime, Dom, x, EventTarget, I18n, Runtime, RuntimeClient) {
      var dispatches = [
        "ready",
        "change",
        "cancel",
        "mouseenter",
        "mouseleave",
        "mousedown",
        "mouseup"
      ];
      function FileInput(options) {
        var container, browseButton, defaults;
        if (Basic.inArray(Basic.typeOf(options), ["string", "node"]) !== -1) {
          options = { browse_button: options };
        }
        browseButton = Dom.get(options.browse_button);
        if (!browseButton) {
          throw new x.DOMException(x.DOMException.NOT_FOUND_ERR);
        }
        defaults = {
          accept: [
            {
              title: I18n.translate("All Files"),
              extensions: "*"
            }
          ],
          multiple: false,
          required_caps: false,
          container: browseButton.parentNode || document.body
        };
        options = Basic.extend({}, defaults, options);
        if (typeof options.required_caps === "string") {
          options.required_caps = Runtime.parseCaps(options.required_caps);
        }
        if (typeof options.accept === "string") {
          options.accept = Mime.mimes2extList(options.accept);
        }
        container = Dom.get(options.container);
        if (!container) {
          container = document.body;
        }
        if (Dom.getStyle(container, "position") === "static") {
          container.style.position = "relative";
        }
        container = browseButton = null;
        RuntimeClient.call(this);
        Basic.extend(this, {
          uid: Basic.guid("uid_"),
          ruid: null,
          shimid: null,
          files: null,
          init: function() {
            var self = this;
            self.bind("RuntimeInit", function(e, runtime) {
              self.ruid = runtime.uid;
              self.shimid = runtime.shimid;
              self.bind(
                "Ready",
                function() {
                  self.trigger("Refresh");
                },
                999
              );
              self.bind("Refresh", function() {
                var pos, size, browseButton2, shimContainer, zIndex;
                browseButton2 = Dom.get(options.browse_button);
                shimContainer = Dom.get(runtime.shimid);
                if (browseButton2) {
                  pos = Dom.getPos(browseButton2, Dom.get(options.container));
                  size = Dom.getSize(browseButton2);
                  zIndex = parseInt(Dom.getStyle(browseButton2, "z-index"), 10) || 0;
                  if (shimContainer) {
                    Basic.extend(shimContainer.style, {
                      top: pos.y + "px",
                      left: pos.x + "px",
                      width: size.w + "px",
                      height: size.h + "px",
                      zIndex: zIndex + 1
                    });
                  }
                }
                shimContainer = browseButton2 = null;
              });
              runtime.exec.call(self, "FileInput", "init", options);
            });
            self.connectRuntime(
              Basic.extend({}, options, {
                required_caps: {
                  select_file: true
                }
              })
            );
          },
          getOption: function(name) {
            return options[name];
          },
          setOption: function(name, value) {
            if (!options.hasOwnProperty(name)) {
              return;
            }
            var oldValue = options[name];
            switch (name) {
              case "accept":
                if (typeof value === "string") {
                  value = Mime.mimes2extList(value);
                }
                break;
              case "container":
              case "required_caps":
                throw new x.FileException(x.FileException.NO_MODIFICATION_ALLOWED_ERR);
            }
            options[name] = value;
            this.exec("FileInput", "setOption", name, value);
            this.trigger("OptionChanged", name, value, oldValue);
          },
          disable: function(state) {
            var runtime = this.getRuntime();
            if (runtime) {
              this.exec("FileInput", "disable", Basic.typeOf(state) === "undefined" ? true : state);
            }
          },
          refresh: function() {
            this.trigger("Refresh");
          },
          destroy: function() {
            var runtime = this.getRuntime();
            if (runtime) {
              runtime.exec.call(this, "FileInput", "destroy");
              this.disconnectRuntime();
            }
            if (Basic.typeOf(this.files) === "array") {
              Basic.each(this.files, function(file) {
                file.destroy();
              });
            }
            this.files = null;
            this.unbindAll();
          }
        });
        this.handleEventProps(dispatches);
      }
      FileInput.prototype = EventTarget.instance;
      return FileInput;
    });
    define("moxie/file/File", [
      "moxie/core/utils/Basic",
      "moxie/core/utils/Mime",
      "moxie/file/Blob"
    ], function(Basic, Mime, Blob) {
      function File2(ruid, file) {
        if (!file) {
          file = {};
        }
        Blob.apply(this, arguments);
        if (!this.type) {
          this.type = Mime.getFileMime(file.name);
        }
        var name;
        if (file.name) {
          name = file.name.replace(/\\/g, "/");
          name = name.substr(name.lastIndexOf("/") + 1);
        } else if (this.type) {
          var prefix = this.type.split("/")[0];
          name = Basic.guid((prefix !== "" ? prefix : "file") + "_");
          if (Mime.extensions[this.type]) {
            name += "." + Mime.extensions[this.type][0];
          }
        }
        Basic.extend(this, {
          name: name || Basic.guid("file_"),
          relativePath: "",
          lastModifiedDate: file.lastModifiedDate || new Date().toLocaleString()
        });
      }
      File2.prototype = Blob.prototype;
      return File2;
    });
    define("moxie/file/FileDrop", [
      "moxie/core/I18n",
      "moxie/core/utils/Dom",
      "moxie/core/Exceptions",
      "moxie/core/utils/Basic",
      "moxie/core/utils/Env",
      "moxie/file/File",
      "moxie/runtime/RuntimeClient",
      "moxie/core/EventTarget",
      "moxie/core/utils/Mime"
    ], function(I18n, Dom, x, Basic, Env, File2, RuntimeClient, EventTarget, Mime) {
      var dispatches = [
        "ready",
        "dragenter",
        "dragleave",
        "drop",
        "error"
      ];
      function FileDrop(options) {
        var self = this, defaults;
        if (typeof options === "string") {
          options = { drop_zone: options };
        }
        defaults = {
          accept: [
            {
              title: I18n.translate("All Files"),
              extensions: "*"
            }
          ],
          required_caps: {
            drag_and_drop: true
          }
        };
        options = typeof options === "object" ? Basic.extend({}, defaults, options) : defaults;
        options.container = Dom.get(options.drop_zone) || document.body;
        if (Dom.getStyle(options.container, "position") === "static") {
          options.container.style.position = "relative";
        }
        if (typeof options.accept === "string") {
          options.accept = Mime.mimes2extList(options.accept);
        }
        RuntimeClient.call(self);
        Basic.extend(self, {
          uid: Basic.guid("uid_"),
          ruid: null,
          files: null,
          init: function() {
            self.bind("RuntimeInit", function(e, runtime) {
              self.ruid = runtime.uid;
              runtime.exec.call(self, "FileDrop", "init", options);
              self.dispatchEvent("ready");
            });
            self.connectRuntime(options);
          },
          destroy: function() {
            var runtime = this.getRuntime();
            if (runtime) {
              runtime.exec.call(this, "FileDrop", "destroy");
              this.disconnectRuntime();
            }
            this.files = null;
            this.unbindAll();
          }
        });
        this.handleEventProps(dispatches);
      }
      FileDrop.prototype = EventTarget.instance;
      return FileDrop;
    });
    define("moxie/file/FileReader", [
      "moxie/core/utils/Basic",
      "moxie/core/utils/Encode",
      "moxie/core/Exceptions",
      "moxie/core/EventTarget",
      "moxie/file/Blob",
      "moxie/runtime/RuntimeClient"
    ], function(Basic, Encode, x, EventTarget, Blob, RuntimeClient) {
      var dispatches = [
        "loadstart",
        "progress",
        "load",
        "abort",
        "error",
        "loadend"
      ];
      function FileReader2() {
        RuntimeClient.call(this);
        Basic.extend(this, {
          uid: Basic.guid("uid_"),
          readyState: FileReader2.EMPTY,
          result: null,
          error: null,
          readAsBinaryString: function(blob) {
            _read.call(this, "readAsBinaryString", blob);
          },
          readAsDataURL: function(blob) {
            _read.call(this, "readAsDataURL", blob);
          },
          readAsText: function(blob) {
            _read.call(this, "readAsText", blob);
          },
          abort: function() {
            this.result = null;
            if (Basic.inArray(this.readyState, [FileReader2.EMPTY, FileReader2.DONE]) !== -1) {
              return;
            } else if (this.readyState === FileReader2.LOADING) {
              this.readyState = FileReader2.DONE;
            }
            this.exec("FileReader", "abort");
            this.trigger("abort");
            this.trigger("loadend");
          },
          destroy: function() {
            this.abort();
            this.exec("FileReader", "destroy");
            this.disconnectRuntime();
            this.unbindAll();
          }
        });
        this.handleEventProps(dispatches);
        this.bind(
          "Error",
          function(e, err) {
            this.readyState = FileReader2.DONE;
            this.error = err;
          },
          999
        );
        this.bind(
          "Load",
          function(e) {
            this.readyState = FileReader2.DONE;
          },
          999
        );
        function _read(op, blob) {
          this.trigger("loadstart");
          if (this.readyState === FileReader2.LOADING) {
            this.trigger("error", new x.DOMException(x.DOMException.INVALID_STATE_ERR));
            this.trigger("loadend");
            return;
          }
          if (!(blob instanceof Blob)) {
            this.trigger("error", new x.DOMException(x.DOMException.NOT_FOUND_ERR));
            this.trigger("loadend");
            return;
          }
          this.result = null;
          this.readyState = FileReader2.LOADING;
          if (blob.isDetached()) {
            var src = blob.getSource();
            switch (op) {
              case "readAsText":
              case "readAsBinaryString":
                this.result = src;
                break;
              case "readAsDataURL":
                this.result = "data:" + blob.type + ";base64," + Encode.btoa(src);
                break;
            }
            this.readyState = FileReader2.DONE;
            this.trigger("load");
            this.trigger("loadend");
          } else {
            this.connectRuntime(blob.ruid);
            this.exec("FileReader", "read", op, blob);
          }
        }
      }
      FileReader2.EMPTY = 0;
      FileReader2.LOADING = 1;
      FileReader2.DONE = 2;
      FileReader2.prototype = EventTarget.instance;
      return FileReader2;
    });
    define("moxie/core/utils/Url", ["moxie/core/utils/Basic"], function(Basic) {
      var parseUrl = function(url, currentUrl) {
        var key = [
          "source",
          "scheme",
          "authority",
          "userInfo",
          "user",
          "pass",
          "host",
          "port",
          "relative",
          "path",
          "directory",
          "file",
          "query",
          "fragment"
        ], i = key.length, ports = {
          http: 80,
          https: 443
        }, uri = {}, regex = /^(?:([^:\/?#]+):)?(?:\/\/()(?:(?:()(?:([^:@\/]*):?([^:@\/]*))?@)?(\[[\da-fA-F:]+\]|[^:\/?#]*)(?::(\d*))?))?()(?:(()(?:(?:[^?#\/]*\/)*)()(?:[^?#]*))(?:\\?([^#]*))?(?:#(.*))?)/, m = regex.exec(url || ""), isRelative, isSchemeLess = /^\/\/\w/.test(url);
        switch (Basic.typeOf(currentUrl)) {
          case "undefined":
            currentUrl = parseUrl(document.location.href, false);
            break;
          case "string":
            currentUrl = parseUrl(currentUrl, false);
            break;
        }
        while (i--) {
          if (m[i]) {
            uri[key[i]] = m[i];
          }
        }
        isRelative = !isSchemeLess && !uri.scheme;
        if (isSchemeLess || isRelative) {
          uri.scheme = currentUrl.scheme;
        }
        if (isRelative) {
          uri.host = currentUrl.host;
          uri.port = currentUrl.port;
          var path = "";
          if (/^[^\/]/.test(uri.path)) {
            path = currentUrl.path;
            if (/\/[^\/]*\.[^\/]*$/.test(path)) {
              path = path.replace(/\/[^\/]+$/, "/");
            } else {
              path = path.replace(/\/?$/, "/");
            }
          }
          uri.path = path + (uri.path || "");
        }
        if (!uri.port) {
          uri.port = ports[uri.scheme] || 80;
        }
        uri.port = parseInt(uri.port, 10);
        if (!uri.path) {
          uri.path = "/";
        }
        delete uri.source;
        return uri;
      };
      var resolveUrl = function(url) {
        var ports = {
          http: 80,
          https: 443
        }, urlp = typeof url === "object" ? url : parseUrl(url);
        return urlp.scheme + "://" + urlp.host + (urlp.port !== ports[urlp.scheme] ? ":" + urlp.port : "") + urlp.path + (urlp.query ? urlp.query : "");
      };
      var hasSameOrigin = function(url) {
        function origin(url2) {
          return [url2.scheme, url2.host, url2.port].join("/");
        }
        if (typeof url === "string") {
          url = parseUrl(url);
        }
        return origin(parseUrl()) === origin(url);
      };
      return {
        parseUrl,
        resolveUrl,
        hasSameOrigin
      };
    });
    define("moxie/runtime/RuntimeTarget", [
      "moxie/core/utils/Basic",
      "moxie/runtime/RuntimeClient",
      "moxie/core/EventTarget"
    ], function(Basic, RuntimeClient, EventTarget) {
      function RuntimeTarget() {
        this.uid = Basic.guid("uid_");
        RuntimeClient.call(this);
        this.destroy = function() {
          this.disconnectRuntime();
          this.unbindAll();
        };
      }
      RuntimeTarget.prototype = EventTarget.instance;
      return RuntimeTarget;
    });
    define("moxie/file/FileReaderSync", [
      "moxie/core/utils/Basic",
      "moxie/runtime/RuntimeClient",
      "moxie/core/utils/Encode"
    ], function(Basic, RuntimeClient, Encode) {
      return function() {
        RuntimeClient.call(this);
        Basic.extend(this, {
          uid: Basic.guid("uid_"),
          readAsBinaryString: function(blob) {
            return _read.call(this, "readAsBinaryString", blob);
          },
          readAsDataURL: function(blob) {
            return _read.call(this, "readAsDataURL", blob);
          },
          readAsText: function(blob) {
            return _read.call(this, "readAsText", blob);
          }
        });
        function _read(op, blob) {
          if (blob.isDetached()) {
            var src = blob.getSource();
            switch (op) {
              case "readAsBinaryString":
                return src;
              case "readAsDataURL":
                return "data:" + blob.type + ";base64," + Encode.btoa(src);
              case "readAsText":
                var txt = "";
                for (var i = 0, length = src.length; i < length; i++) {
                  txt += String.fromCharCode(src[i]);
                }
                return txt;
            }
          } else {
            var result = this.connectRuntime(blob.ruid).exec.call(this, "FileReaderSync", "read", op, blob);
            this.disconnectRuntime();
            return result;
          }
        }
      };
    });
    define("moxie/xhr/FormData", [
      "moxie/core/Exceptions",
      "moxie/core/utils/Basic",
      "moxie/file/Blob"
    ], function(x, Basic, Blob) {
      function FormData() {
        var _blob, _fields = [];
        Basic.extend(this, {
          append: function(name, value) {
            var self = this, valueType = Basic.typeOf(value);
            if (value instanceof Blob) {
              _blob = {
                name,
                value
              };
            } else if ("array" === valueType) {
              name += "[]";
              Basic.each(value, function(value2) {
                self.append(name, value2);
              });
            } else if ("object" === valueType) {
              Basic.each(value, function(value2, key) {
                self.append(name + "[" + key + "]", value2);
              });
            } else if ("null" === valueType || "undefined" === valueType || "number" === valueType && isNaN(value)) {
              self.append(name, "false");
            } else {
              _fields.push({
                name,
                value: value.toString()
              });
            }
          },
          hasBlob: function() {
            return !!this.getBlob();
          },
          getBlob: function() {
            return _blob && _blob.value || null;
          },
          getBlobName: function() {
            return _blob && _blob.name || null;
          },
          each: function(cb) {
            Basic.each(_fields, function(field) {
              cb(field.value, field.name);
            });
            if (_blob) {
              cb(_blob.value, _blob.name);
            }
          },
          destroy: function() {
            _blob = null;
            _fields = [];
          }
        });
      }
      return FormData;
    });
    define("moxie/xhr/XMLHttpRequest", [
      "moxie/core/utils/Basic",
      "moxie/core/Exceptions",
      "moxie/core/EventTarget",
      "moxie/core/utils/Encode",
      "moxie/core/utils/Url",
      "moxie/runtime/Runtime",
      "moxie/runtime/RuntimeTarget",
      "moxie/file/Blob",
      "moxie/file/FileReaderSync",
      "moxie/xhr/FormData",
      "moxie/core/utils/Env",
      "moxie/core/utils/Mime"
    ], function(Basic, x, EventTarget, Encode, Url, Runtime, RuntimeTarget, Blob, FileReaderSync, FormData, Env, Mime) {
      var httpCode = {
        100: "Continue",
        101: "Switching Protocols",
        102: "Processing",
        200: "OK",
        201: "Created",
        202: "Accepted",
        203: "Non-Authoritative Information",
        204: "No Content",
        205: "Reset Content",
        206: "Partial Content",
        207: "Multi-Status",
        226: "IM Used",
        300: "Multiple Choices",
        301: "Moved Permanently",
        302: "Found",
        303: "See Other",
        304: "Not Modified",
        305: "Use Proxy",
        306: "Reserved",
        307: "Temporary Redirect",
        400: "Bad Request",
        401: "Unauthorized",
        402: "Payment Required",
        403: "Forbidden",
        404: "Not Found",
        405: "Method Not Allowed",
        406: "Not Acceptable",
        407: "Proxy Authentication Required",
        408: "Request Timeout",
        409: "Conflict",
        410: "Gone",
        411: "Length Required",
        412: "Precondition Failed",
        413: "Request Entity Too Large",
        414: "Request-URI Too Long",
        415: "Unsupported Media Type",
        416: "Requested Range Not Satisfiable",
        417: "Expectation Failed",
        422: "Unprocessable Entity",
        423: "Locked",
        424: "Failed Dependency",
        426: "Upgrade Required",
        500: "Internal Server Error",
        501: "Not Implemented",
        502: "Bad Gateway",
        503: "Service Unavailable",
        504: "Gateway Timeout",
        505: "HTTP Version Not Supported",
        506: "Variant Also Negotiates",
        507: "Insufficient Storage",
        510: "Not Extended"
      };
      function XMLHttpRequestUpload() {
        this.uid = Basic.guid("uid_");
      }
      XMLHttpRequestUpload.prototype = EventTarget.instance;
      var dispatches = [
        "loadstart",
        "progress",
        "abort",
        "error",
        "load",
        "timeout",
        "loadend"
      ];
      function XMLHttpRequest2() {
        var self = this, props = {
          timeout: 0,
          readyState: XMLHttpRequest2.UNSENT,
          withCredentials: false,
          status: 0,
          statusText: "",
          responseType: "",
          responseXML: null,
          responseText: null,
          response: null
        }, _async = true, _url, _method, _headers = {}, _user, _password, _encoding = null, _mimeType = null, _sync_flag = false, _send_flag = false, _upload_events_flag = false, _upload_complete_flag = false, _error_flag = false, _same_origin_flag = false, _options = {}, _xhr, _responseHeaders = "", _responseHeadersBag;
        Basic.extend(this, props, {
          uid: Basic.guid("uid_"),
          upload: new XMLHttpRequestUpload(),
          open: function(method, url, async, user, password) {
            var urlp;
            if (!method || !url) {
              throw new x.DOMException(x.DOMException.SYNTAX_ERR);
            }
            if (/[\u0100-\uffff]/.test(method) || Encode.utf8_encode(method) !== method) {
              throw new x.DOMException(x.DOMException.SYNTAX_ERR);
            }
            if (!!~Basic.inArray(method.toUpperCase(), [
              "CONNECT",
              "DELETE",
              "GET",
              "HEAD",
              "OPTIONS",
              "POST",
              "PUT",
              "TRACE",
              "TRACK"
            ])) {
              _method = method.toUpperCase();
            }
            if (!!~Basic.inArray(_method, ["CONNECT", "TRACE", "TRACK"])) {
              throw new x.DOMException(x.DOMException.SECURITY_ERR);
            }
            url = Encode.utf8_encode(url);
            urlp = Url.parseUrl(url);
            _same_origin_flag = Url.hasSameOrigin(urlp);
            _url = Url.resolveUrl(url);
            if ((user || password) && !_same_origin_flag) {
              throw new x.DOMException(x.DOMException.INVALID_ACCESS_ERR);
            }
            _user = user || urlp.user;
            _password = password || urlp.pass;
            _async = async || true;
            if (_async === false && (_p("timeout") || _p("withCredentials") || _p("responseType") !== "")) {
              throw new x.DOMException(x.DOMException.INVALID_ACCESS_ERR);
            }
            _sync_flag = !_async;
            _send_flag = false;
            _headers = {};
            _reset.call(this);
            _p("readyState", XMLHttpRequest2.OPENED);
            this.dispatchEvent("readystatechange");
          },
          setRequestHeader: function(header, value) {
            var isKeepOrigin = header.indexOf("KEEP_ORIGIN_") !== -1;
            if (isKeepOrigin) {
              header = header.split("KEEP_ORIGIN_")[1];
            }
            var uaHeaders = [
              "accept-charset",
              "accept-encoding",
              "access-control-request-headers",
              "access-control-request-method",
              "connection",
              "content-length",
              "cookie",
              "cookie2",
              "content-transfer-encoding",
              "date",
              "expect",
              "host",
              "keep-alive",
              "origin",
              "referer",
              "te",
              "trailer",
              "transfer-encoding",
              "upgrade",
              "user-agent",
              "via"
            ];
            if (_p("readyState") !== XMLHttpRequest2.OPENED || _send_flag) {
              throw new x.DOMException(x.DOMException.INVALID_STATE_ERR);
            }
            if (/[\u0100-\uffff]/.test(header) || Encode.utf8_encode(header) !== header) {
              throw new x.DOMException(x.DOMException.SYNTAX_ERR);
            }
            header = Basic.trim(header);
            if (!isKeepOrigin) {
              header = header.toLowerCase();
            }
            if (!!~Basic.inArray(header, uaHeaders) || /^(proxy\-|sec\-)/.test(header)) {
              return false;
            }
            if (!_headers[header]) {
              _headers[header] = value;
            } else {
              _headers[header] += ", " + value;
            }
            return true;
          },
          hasRequestHeader: function(header) {
            return header && _headers[header.toLowerCase()] || false;
          },
          getAllResponseHeaders: function() {
            return _responseHeaders || "";
          },
          getResponseHeader: function(header) {
            header = header.toLowerCase();
            if (_error_flag || !!~Basic.inArray(header, ["set-cookie", "set-cookie2"])) {
              return null;
            }
            if (_responseHeaders && _responseHeaders !== "") {
              if (!_responseHeadersBag) {
                _responseHeadersBag = {};
                Basic.each(_responseHeaders.split(/\r\n/), function(line) {
                  var pair = line.split(/:\s+/);
                  if (pair.length === 2) {
                    pair[0] = Basic.trim(pair[0]);
                    _responseHeadersBag[pair[0].toLowerCase()] = {
                      header: pair[0],
                      value: Basic.trim(pair[1])
                    };
                  }
                });
              }
              if (_responseHeadersBag.hasOwnProperty(header)) {
                return _responseHeadersBag[header].header + ": " + _responseHeadersBag[header].value;
              }
            }
            return null;
          },
          overrideMimeType: function(mime) {
            var matches;
            if (!!~Basic.inArray(_p("readyState"), [XMLHttpRequest2.LOADING, XMLHttpRequest2.DONE])) {
              throw new x.DOMException(x.DOMException.INVALID_STATE_ERR);
            }
            mime = Basic.trim(mime.toLowerCase());
            if (/;/.test(mime) && (matches = mime.match(/^([^;]+)(?:;\scharset\=)?(.*)$/))) {
              mime = matches[1];
              if (matches[2]) {
                matches[2];
              }
            }
            if (!Mime.mimes[mime]) {
              throw new x.DOMException(x.DOMException.SYNTAX_ERR);
            }
          },
          send: function(data, options) {
            if (Basic.typeOf(options) === "string") {
              _options = { ruid: options };
            } else if (!options) {
              _options = {};
            } else {
              _options = options;
            }
            if (this.readyState !== XMLHttpRequest2.OPENED || _send_flag) {
              throw new x.DOMException(x.DOMException.INVALID_STATE_ERR);
            }
            if (data instanceof Blob) {
              _options.ruid = data.ruid;
              _mimeType = data.type || "application/octet-stream";
            } else if (data instanceof FormData) {
              if (data.hasBlob()) {
                var blob = data.getBlob();
                _options.ruid = blob.ruid;
                _mimeType = blob.type || "application/octet-stream";
              }
            } else if (typeof data === "string") {
              _encoding = "UTF-8";
              _mimeType = "text/plain;charset=UTF-8";
              data = Encode.utf8_encode(data);
            }
            if (!this.withCredentials) {
              this.withCredentials = _options.required_caps && _options.required_caps.send_browser_cookies && !_same_origin_flag;
            }
            _upload_events_flag = !_sync_flag && this.upload.hasEventListener();
            _error_flag = false;
            _upload_complete_flag = !data;
            if (!_sync_flag) {
              _send_flag = true;
            }
            _doXHR.call(this, data);
          },
          abort: function() {
            _error_flag = true;
            _sync_flag = false;
            if (!~Basic.inArray(_p("readyState"), [XMLHttpRequest2.UNSENT, XMLHttpRequest2.OPENED, XMLHttpRequest2.DONE])) {
              _p("readyState", XMLHttpRequest2.DONE);
              _send_flag = false;
              if (_xhr) {
                _xhr.getRuntime().exec.call(_xhr, "XMLHttpRequest", "abort", _upload_complete_flag);
              } else {
                throw new x.DOMException(x.DOMException.INVALID_STATE_ERR);
              }
              _upload_complete_flag = true;
            } else {
              _p("readyState", XMLHttpRequest2.UNSENT);
            }
          },
          destroy: function() {
            if (_xhr) {
              if (Basic.typeOf(_xhr.destroy) === "function") {
                _xhr.destroy();
              }
              _xhr = null;
            }
            this.unbindAll();
            if (this.upload) {
              this.upload.unbindAll();
              this.upload = null;
            }
          }
        });
        this.handleEventProps(dispatches.concat(["readystatechange"]));
        this.upload.handleEventProps(dispatches);
        function _p(prop, value) {
          if (!props.hasOwnProperty(prop)) {
            return;
          }
          if (arguments.length === 1) {
            return Env.can("define_property") ? props[prop] : self[prop];
          } else {
            if (Env.can("define_property")) {
              props[prop] = value;
            } else {
              self[prop] = value;
            }
          }
        }
        function _doXHR(data) {
          var self2 = this;
          new Date().getTime();
          _xhr = new RuntimeTarget();
          function loadEnd() {
            if (_xhr) {
              _xhr.destroy();
              _xhr = null;
            }
            self2.dispatchEvent("loadend");
            self2 = null;
          }
          function exec(runtime) {
            _xhr.bind("LoadStart", function(e) {
              _p("readyState", XMLHttpRequest2.LOADING);
              self2.dispatchEvent("readystatechange");
              self2.dispatchEvent(e);
              if (_upload_events_flag) {
                self2.upload.dispatchEvent(e);
              }
            });
            _xhr.bind("Progress", function(e) {
              if (_p("readyState") !== XMLHttpRequest2.LOADING) {
                _p("readyState", XMLHttpRequest2.LOADING);
                self2.dispatchEvent("readystatechange");
              }
              self2.dispatchEvent(e);
            });
            _xhr.bind("UploadProgress", function(e) {
              if (_upload_events_flag) {
                self2.upload.dispatchEvent({
                  type: "progress",
                  lengthComputable: false,
                  total: e.total,
                  loaded: e.loaded
                });
              }
            });
            _xhr.bind("Load", function(e) {
              _p("readyState", XMLHttpRequest2.DONE);
              _p("status", Number(runtime.exec.call(_xhr, "XMLHttpRequest", "getStatus") || 0));
              _p("statusText", httpCode[_p("status")] || "");
              _p("response", runtime.exec.call(_xhr, "XMLHttpRequest", "getResponse", _p("responseType")));
              if (!!~Basic.inArray(_p("responseType"), ["text", ""])) {
                _p("responseText", _p("response"));
              } else if (_p("responseType") === "document") {
                _p("responseXML", _p("response"));
              }
              _responseHeaders = runtime.exec.call(_xhr, "XMLHttpRequest", "getAllResponseHeaders");
              self2.dispatchEvent("readystatechange");
              if (_p("status") > 0) {
                if (_upload_events_flag) {
                  self2.upload.dispatchEvent(e);
                }
                self2.dispatchEvent(e);
              } else {
                _error_flag = true;
                self2.dispatchEvent("error");
              }
              loadEnd();
            });
            _xhr.bind("Abort", function(e) {
              self2.dispatchEvent(e);
              loadEnd();
            });
            _xhr.bind("Error", function(e) {
              _error_flag = true;
              _p("readyState", XMLHttpRequest2.DONE);
              self2.dispatchEvent("readystatechange");
              _upload_complete_flag = true;
              self2.dispatchEvent(e);
              loadEnd();
            });
            runtime.exec.call(
              _xhr,
              "XMLHttpRequest",
              "send",
              {
                url: _url,
                method: _method,
                async: _async,
                user: _user,
                password: _password,
                headers: _headers,
                mimeType: _mimeType,
                encoding: _encoding,
                responseType: self2.responseType,
                withCredentials: self2.withCredentials,
                options: _options
              },
              data
            );
          }
          if (typeof _options.required_caps === "string") {
            _options.required_caps = Runtime.parseCaps(_options.required_caps);
          }
          _options.required_caps = Basic.extend({}, _options.required_caps, {
            return_response_type: self2.responseType
          });
          if (data instanceof FormData) {
            _options.required_caps.send_multipart = true;
          }
          if (!Basic.isEmptyObj(_headers)) {
            _options.required_caps.send_custom_headers = true;
          }
          if (!_same_origin_flag) {
            _options.required_caps.do_cors = true;
          }
          if (_options.ruid) {
            exec(_xhr.connectRuntime(_options));
          } else {
            _xhr.bind("RuntimeInit", function(e, runtime) {
              exec(runtime);
            });
            _xhr.bind("RuntimeError", function(e, err) {
              self2.dispatchEvent("RuntimeError", err);
            });
            _xhr.connectRuntime(_options);
          }
        }
        function _reset() {
          _p("responseText", "");
          _p("responseXML", null);
          _p("response", null);
          _p("status", 0);
          _p("statusText", "");
        }
      }
      XMLHttpRequest2.UNSENT = 0;
      XMLHttpRequest2.OPENED = 1;
      XMLHttpRequest2.HEADERS_RECEIVED = 2;
      XMLHttpRequest2.LOADING = 3;
      XMLHttpRequest2.DONE = 4;
      XMLHttpRequest2.prototype = EventTarget.instance;
      return XMLHttpRequest2;
    });
    define("moxie/runtime/Transporter", [
      "moxie/core/utils/Basic",
      "moxie/core/utils/Encode",
      "moxie/runtime/RuntimeClient",
      "moxie/core/EventTarget"
    ], function(Basic, Encode, RuntimeClient, EventTarget) {
      function Transporter() {
        var mod, _runtime, _data, _size, _pos, _chunk_size;
        RuntimeClient.call(this);
        Basic.extend(this, {
          uid: Basic.guid("uid_"),
          state: Transporter.IDLE,
          result: null,
          transport: function(data, type, options) {
            var self = this;
            options = Basic.extend(
              {
                chunk_size: 204798
              },
              options
            );
            if (mod = options.chunk_size % 3) {
              options.chunk_size += 3 - mod;
            }
            _chunk_size = options.chunk_size;
            _reset.call(this);
            _data = data;
            _size = data.length;
            if (Basic.typeOf(options) === "string" || options.ruid) {
              _run.call(self, type, this.connectRuntime(options));
            } else {
              var cb = function(e, runtime) {
                self.unbind("RuntimeInit", cb);
                _run.call(self, type, runtime);
              };
              this.bind("RuntimeInit", cb);
              this.connectRuntime(options);
            }
          },
          abort: function() {
            var self = this;
            self.state = Transporter.IDLE;
            if (_runtime) {
              _runtime.exec.call(self, "Transporter", "clear");
              self.trigger("TransportingAborted");
            }
            _reset.call(self);
          },
          destroy: function() {
            this.unbindAll();
            _runtime = null;
            this.disconnectRuntime();
            _reset.call(this);
          }
        });
        function _reset() {
          _size = _pos = 0;
          _data = this.result = null;
        }
        function _run(type, runtime) {
          var self = this;
          _runtime = runtime;
          self.bind(
            "TransportingProgress",
            function(e) {
              _pos = e.loaded;
              if (_pos < _size && Basic.inArray(self.state, [Transporter.IDLE, Transporter.DONE]) === -1) {
                _transport.call(self);
              }
            },
            999
          );
          self.bind(
            "TransportingComplete",
            function() {
              _pos = _size;
              self.state = Transporter.DONE;
              _data = null;
              self.result = _runtime.exec.call(self, "Transporter", "getAsBlob", type || "");
            },
            999
          );
          self.state = Transporter.BUSY;
          self.trigger("TransportingStarted");
          _transport.call(self);
        }
        function _transport() {
          var self = this, chunk, bytesLeft = _size - _pos;
          if (_chunk_size > bytesLeft) {
            _chunk_size = bytesLeft;
          }
          chunk = Encode.btoa(_data.substr(_pos, _chunk_size));
          _runtime.exec.call(self, "Transporter", "receive", chunk, _size);
        }
      }
      Transporter.IDLE = 0;
      Transporter.BUSY = 1;
      Transporter.DONE = 2;
      Transporter.prototype = EventTarget.instance;
      return Transporter;
    });
    define("moxie/image/Image", [
      "moxie/core/utils/Basic",
      "moxie/core/utils/Dom",
      "moxie/core/Exceptions",
      "moxie/file/FileReaderSync",
      "moxie/xhr/XMLHttpRequest",
      "moxie/runtime/Runtime",
      "moxie/runtime/RuntimeClient",
      "moxie/runtime/Transporter",
      "moxie/core/utils/Env",
      "moxie/core/EventTarget",
      "moxie/file/Blob",
      "moxie/file/File",
      "moxie/core/utils/Encode"
    ], function(Basic, Dom, x, FileReaderSync, XMLHttpRequest2, Runtime, RuntimeClient, Transporter, Env, EventTarget, Blob, File2, Encode) {
      var dispatches = [
        "progress",
        "load",
        "error",
        "resize",
        "embedded"
      ];
      function Image2() {
        RuntimeClient.call(this);
        Basic.extend(this, {
          uid: Basic.guid("uid_"),
          ruid: null,
          name: "",
          size: 0,
          width: 0,
          height: 0,
          type: "",
          meta: {},
          clone: function() {
            this.load.apply(this, arguments);
          },
          load: function() {
            _load.apply(this, arguments);
          },
          resize: function(options) {
            var self = this;
            var orientation;
            var scale;
            var srcRect = {
              x: 0,
              y: 0,
              width: self.width,
              height: self.height
            };
            var opts = Basic.extendIf(
              {
                width: self.width,
                height: self.height,
                type: self.type || "image/jpeg",
                quality: 90,
                crop: false,
                fit: true,
                preserveHeaders: true,
                resample: "default",
                multipass: true
              },
              options
            );
            try {
              if (!self.size) {
                throw new x.DOMException(x.DOMException.INVALID_STATE_ERR);
              }
              if (self.width > Image2.MAX_RESIZE_WIDTH || self.height > Image2.MAX_RESIZE_HEIGHT) {
                throw new x.ImageError(x.ImageError.MAX_RESOLUTION_ERR);
              }
              orientation = self.meta && self.meta.tiff && self.meta.tiff.Orientation || 1;
              if (Basic.inArray(orientation, [5, 6, 7, 8]) !== -1) {
                var tmp = opts.width;
                opts.width = opts.height;
                opts.height = tmp;
              }
              if (opts.crop) {
                scale = Math.max(opts.width / self.width, opts.height / self.height);
                if (options.fit) {
                  srcRect.width = Math.min(Math.ceil(opts.width / scale), self.width);
                  srcRect.height = Math.min(Math.ceil(opts.height / scale), self.height);
                  scale = opts.width / srcRect.width;
                } else {
                  srcRect.width = Math.min(opts.width, self.width);
                  srcRect.height = Math.min(opts.height, self.height);
                  scale = 1;
                }
                if (typeof opts.crop === "boolean") {
                  opts.crop = "cc";
                }
                switch (opts.crop.toLowerCase().replace(/_/, "-")) {
                  case "rb":
                  case "right-bottom":
                    srcRect.x = self.width - srcRect.width;
                    srcRect.y = self.height - srcRect.height;
                    break;
                  case "cb":
                  case "center-bottom":
                    srcRect.x = Math.floor((self.width - srcRect.width) / 2);
                    srcRect.y = self.height - srcRect.height;
                    break;
                  case "lb":
                  case "left-bottom":
                    srcRect.x = 0;
                    srcRect.y = self.height - srcRect.height;
                    break;
                  case "lt":
                  case "left-top":
                    srcRect.x = 0;
                    srcRect.y = 0;
                    break;
                  case "ct":
                  case "center-top":
                    srcRect.x = Math.floor((self.width - srcRect.width) / 2);
                    srcRect.y = 0;
                    break;
                  case "rt":
                  case "right-top":
                    srcRect.x = self.width - srcRect.width;
                    srcRect.y = 0;
                    break;
                  case "rc":
                  case "right-center":
                  case "right-middle":
                    srcRect.x = self.width - srcRect.width;
                    srcRect.y = Math.floor((self.height - srcRect.height) / 2);
                    break;
                  case "lc":
                  case "left-center":
                  case "left-middle":
                    srcRect.x = 0;
                    srcRect.y = Math.floor((self.height - srcRect.height) / 2);
                    break;
                  case "cc":
                  case "center-center":
                  case "center-middle":
                  default:
                    srcRect.x = Math.floor((self.width - srcRect.width) / 2);
                    srcRect.y = Math.floor((self.height - srcRect.height) / 2);
                }
                srcRect.x = Math.max(srcRect.x, 0);
                srcRect.y = Math.max(srcRect.y, 0);
              } else {
                scale = Math.min(opts.width / self.width, opts.height / self.height);
                if (scale > 1 && !opts.fit) {
                  scale = 1;
                }
              }
              this.exec("Image", "resize", srcRect, scale, opts);
            } catch (ex) {
              self.trigger("error", ex.code);
            }
          },
          downsize: function(options) {
            var defaults = {
              width: this.width,
              height: this.height,
              type: this.type || "image/jpeg",
              quality: 90,
              crop: false,
              fit: false,
              preserveHeaders: true,
              resample: "default"
            }, opts;
            if (typeof options === "object") {
              opts = Basic.extend(defaults, options);
            } else {
              opts = Basic.extend(defaults, {
                width: arguments[0],
                height: arguments[1],
                crop: arguments[2],
                preserveHeaders: arguments[3]
              });
            }
            this.resize(opts);
          },
          crop: function(width2, height2, preserveHeaders) {
            this.downsize(width2, height2, true, preserveHeaders);
          },
          getAsCanvas: function() {
            if (!Env.can("create_canvas")) {
              throw new x.RuntimeError(x.RuntimeError.NOT_SUPPORTED_ERR);
            }
            return this.exec("Image", "getAsCanvas");
          },
          getAsBlob: function(type, quality) {
            if (!this.size) {
              throw new x.DOMException(x.DOMException.INVALID_STATE_ERR);
            }
            return this.exec("Image", "getAsBlob", type || "image/jpeg", quality || 90);
          },
          getAsDataURL: function(type, quality) {
            if (!this.size) {
              throw new x.DOMException(x.DOMException.INVALID_STATE_ERR);
            }
            return this.exec("Image", "getAsDataURL", type || "image/jpeg", quality || 90);
          },
          getAsBinaryString: function(type, quality) {
            var dataUrl = this.getAsDataURL(type, quality);
            return Encode.atob(dataUrl.substring(dataUrl.indexOf("base64,") + 7));
          },
          embed: function(el, options) {
            var self = this, runtime;
            var opts = Basic.extend(
              {
                width: this.width,
                height: this.height,
                type: this.type || "image/jpeg",
                quality: 90,
                fit: true,
                resample: "nearest"
              },
              options
            );
            function render(type, quality) {
              var img = this;
              if (Env.can("create_canvas")) {
                var canvas = img.getAsCanvas();
                if (canvas) {
                  el.appendChild(canvas);
                  canvas = null;
                  img.destroy();
                  self.trigger("embedded");
                  return;
                }
              }
              var dataUrl = img.getAsDataURL(type, quality);
              if (!dataUrl) {
                throw new x.ImageError(x.ImageError.WRONG_FORMAT);
              }
              if (Env.can("use_data_uri_of", dataUrl.length)) {
                el.innerHTML = '<img src="' + dataUrl + '" width="' + img.width + '" height="' + img.height + '" alt="" />';
                img.destroy();
                self.trigger("embedded");
              } else {
                var tr = new Transporter();
                tr.bind("TransportingComplete", function() {
                  runtime = self.connectRuntime(this.result.ruid);
                  self.bind(
                    "Embedded",
                    function() {
                      Basic.extend(runtime.getShimContainer().style, {
                        top: "0px",
                        left: "0px",
                        width: img.width + "px",
                        height: img.height + "px"
                      });
                      runtime = null;
                    },
                    999
                  );
                  runtime.exec.call(self, "ImageView", "display", this.result.uid, width, height);
                  img.destroy();
                });
                tr.transport(Encode.atob(dataUrl.substring(dataUrl.indexOf("base64,") + 7)), type, {
                  required_caps: {
                    display_media: true
                  },
                  runtime_order: "flash,silverlight",
                  container: el
                });
              }
            }
            try {
              if (!(el = Dom.get(el))) {
                throw new x.DOMException(x.DOMException.INVALID_NODE_TYPE_ERR);
              }
              if (!this.size) {
                throw new x.DOMException(x.DOMException.INVALID_STATE_ERR);
              }
              if (this.width > Image2.MAX_RESIZE_WIDTH || this.height > Image2.MAX_RESIZE_HEIGHT) {
              }
              var imgCopy = new Image2();
              imgCopy.bind("Resize", function() {
                render.call(this, opts.type, opts.quality);
              });
              imgCopy.bind("Load", function() {
                this.downsize(opts);
              });
              if (this.meta.thumb && this.meta.thumb.width >= opts.width && this.meta.thumb.height >= opts.height) {
                imgCopy.load(this.meta.thumb.data);
              } else {
                imgCopy.clone(this, false);
              }
              return imgCopy;
            } catch (ex) {
              this.trigger("error", ex.code);
            }
          },
          destroy: function() {
            if (this.ruid) {
              this.getRuntime().exec.call(this, "Image", "destroy");
              this.disconnectRuntime();
            }
            if (this.meta && this.meta.thumb) {
              this.meta.thumb.data.destroy();
            }
            this.unbindAll();
          }
        });
        this.handleEventProps(dispatches);
        this.bind(
          "Load Resize",
          function() {
            return _updateInfo.call(this);
          },
          999
        );
        function _updateInfo(info) {
          try {
            if (!info) {
              info = this.exec("Image", "getInfo");
            }
            this.size = info.size;
            this.width = info.width;
            this.height = info.height;
            this.type = info.type;
            this.meta = info.meta;
            if (this.name === "") {
              this.name = info.name;
            }
            return true;
          } catch (ex) {
            this.trigger("error", ex.code);
            return false;
          }
        }
        function _load(src) {
          var srcType = Basic.typeOf(src);
          try {
            if (src instanceof Image2) {
              if (!src.size) {
                throw new x.DOMException(x.DOMException.INVALID_STATE_ERR);
              }
              _loadFromImage.apply(this, arguments);
            } else if (src instanceof Blob) {
              if (!~Basic.inArray(src.type, ["image/jpeg", "image/png"])) {
                throw new x.ImageError(x.ImageError.WRONG_FORMAT);
              }
              _loadFromBlob.apply(this, arguments);
            } else if (Basic.inArray(srcType, ["blob", "file"]) !== -1) {
              _load.call(this, new File2(null, src), arguments[1]);
            } else if (srcType === "string") {
              if (src.substr(0, 5) === "data:") {
                _load.call(this, new Blob(null, { data: src }), arguments[1]);
              } else {
                _loadFromUrl.apply(this, arguments);
              }
            } else if (srcType === "node" && src.nodeName.toLowerCase() === "img") {
              _load.call(this, src.src, arguments[1]);
            } else {
              throw new x.DOMException(x.DOMException.TYPE_MISMATCH_ERR);
            }
          } catch (ex) {
            this.trigger("error", ex.code);
          }
        }
        function _loadFromImage(img, exact) {
          var runtime = this.connectRuntime(img.ruid);
          this.ruid = runtime.uid;
          runtime.exec.call(this, "Image", "loadFromImage", img, Basic.typeOf(exact) === "undefined" ? true : exact);
        }
        function _loadFromBlob(blob, options) {
          var self = this;
          self.name = blob.name || "";
          function exec(runtime) {
            self.ruid = runtime.uid;
            runtime.exec.call(self, "Image", "loadFromBlob", blob);
          }
          if (blob.isDetached()) {
            this.bind("RuntimeInit", function(e, runtime) {
              exec(runtime);
            });
            if (options && typeof options.required_caps === "string") {
              options.required_caps = Runtime.parseCaps(options.required_caps);
            }
            this.connectRuntime(
              Basic.extend(
                {
                  required_caps: {
                    access_image_binary: true,
                    resize_image: true
                  }
                },
                options
              )
            );
          } else {
            exec(this.connectRuntime(blob.ruid));
          }
        }
        function _loadFromUrl(url, options) {
          var self = this, xhr;
          xhr = new XMLHttpRequest2();
          xhr.open("get", url);
          xhr.responseType = "blob";
          xhr.onprogress = function(e) {
            self.trigger(e);
          };
          xhr.onload = function() {
            _loadFromBlob.call(self, xhr.response, true);
          };
          xhr.onerror = function(e) {
            self.trigger(e);
          };
          xhr.onloadend = function() {
            xhr.destroy();
          };
          xhr.bind("RuntimeError", function(e, err) {
            self.trigger("RuntimeError", err);
          });
          xhr.send(null, options);
        }
      }
      Image2.MAX_RESIZE_WIDTH = 8192;
      Image2.MAX_RESIZE_HEIGHT = 8192;
      Image2.prototype = EventTarget.instance;
      return Image2;
    });
    define("moxie/runtime/html5/Runtime", [
      "moxie/core/utils/Basic",
      "moxie/core/Exceptions",
      "moxie/runtime/Runtime",
      "moxie/core/utils/Env"
    ], function(Basic, x, Runtime, Env) {
      var type = "html5", extensions = {};
      function Html5Runtime(options) {
        var I = this, Test = Runtime.capTest, True = Runtime.capTrue;
        var caps = Basic.extend(
          {
            access_binary: Test(window.FileReader || window.File && window.File.getAsDataURL),
            access_image_binary: function() {
              return I.can("access_binary") && !!extensions.Image;
            },
            display_media: Test(
              (Env.can("create_canvas") || Env.can("use_data_uri_over32kb")) && defined("moxie/image/Image")
            ),
            do_cors: Test(window.XMLHttpRequest && "withCredentials" in new XMLHttpRequest()),
            drag_and_drop: Test(
              function() {
                var div = document.createElement("div");
                return ("draggable" in div || "ondragstart" in div && "ondrop" in div) && (Env.browser !== "IE" || Env.verComp(Env.version, 9, ">"));
              }()
            ),
            filter_by_extension: Test(
              function() {
                return !(Env.browser === "Chrome" && Env.verComp(Env.version, 28, "<") || Env.browser === "IE" && Env.verComp(Env.version, 10, "<") || Env.browser === "Safari" && Env.verComp(Env.version, 7, "<") || Env.browser === "Firefox" && Env.verComp(Env.version, 37, "<"));
              }()
            ),
            return_response_headers: True,
            return_response_type: function(responseType) {
              if (responseType === "json" && !!window.JSON) {
                return true;
              }
              return Env.can("return_response_type", responseType);
            },
            return_status_code: True,
            report_upload_progress: Test(window.XMLHttpRequest && new XMLHttpRequest().upload),
            resize_image: function() {
              return I.can("access_binary") && Env.can("create_canvas");
            },
            select_file: function() {
              return Env.can("use_fileinput") && window.File;
            },
            select_folder: function() {
              return I.can("select_file") && (Env.browser === "Chrome" && Env.verComp(Env.version, 21, ">=") || Env.browser === "Firefox" && Env.verComp(Env.version, 42, ">="));
            },
            select_multiple: function() {
              return I.can("select_file") && !(Env.browser === "Safari" && Env.os === "Windows") && !(Env.os === "iOS" && Env.verComp(Env.osVersion, "7.0.0", ">") && Env.verComp(Env.osVersion, "8.0.0", "<"));
            },
            send_binary_string: Test(
              window.XMLHttpRequest && (new XMLHttpRequest().sendAsBinary || window.Uint8Array && window.ArrayBuffer)
            ),
            send_custom_headers: Test(window.XMLHttpRequest),
            send_multipart: function() {
              return !!(window.XMLHttpRequest && new XMLHttpRequest().upload && window.FormData) || I.can("send_binary_string");
            },
            slice_blob: Test(
              window.File && (File.prototype.mozSlice || File.prototype.webkitSlice || File.prototype.slice)
            ),
            stream_upload: function() {
              return I.can("slice_blob") && I.can("send_multipart");
            },
            summon_file_dialog: function() {
              return I.can("select_file") && !(Env.browser === "Firefox" && Env.verComp(Env.version, 4, "<") || Env.browser === "Opera" && Env.verComp(Env.version, 12, "<") || Env.browser === "IE" && Env.verComp(Env.version, 10, "<"));
            },
            upload_filesize: True,
            use_http_method: True
          },
          arguments[2]
        );
        Runtime.call(this, options, arguments[1] || type, caps);
        Basic.extend(this, {
          init: function() {
            this.trigger("Init");
          },
          destroy: function(destroy) {
            return function() {
              destroy.call(I);
              destroy = I = null;
            };
          }(this.destroy)
        });
        Basic.extend(this.getShim(), extensions);
      }
      Runtime.addConstructor(type, Html5Runtime);
      return extensions;
    });
    define("moxie/runtime/html5/file/Blob", [
      "moxie/runtime/html5/Runtime",
      "moxie/file/Blob"
    ], function(extensions, Blob) {
      function HTML5Blob() {
        function w3cBlobSlice(blob, start, end) {
          var blobSlice;
          if (window.File.prototype.slice) {
            try {
              blob.slice();
              return blob.slice(start, end);
            } catch (e) {
              return blob.slice(start, end - start);
            }
          } else if (blobSlice = window.File.prototype.webkitSlice || window.File.prototype.mozSlice) {
            return blobSlice.call(blob, start, end);
          } else {
            return null;
          }
        }
        this.slice = function() {
          return new Blob(this.getRuntime().uid, w3cBlobSlice.apply(this, arguments));
        };
        this.destroy = function() {
          this.getRuntime().getShim().removeInstance(this.uid);
        };
      }
      return extensions.Blob = HTML5Blob;
    });
    define("moxie/core/utils/Events", ["moxie/core/utils/Basic"], function(Basic) {
      var eventhash = {}, uid = "moxie_" + Basic.guid();
      function preventDefault() {
        this.returnValue = false;
      }
      function stopPropagation() {
        this.cancelBubble = true;
      }
      var addEvent = function(obj, name, callback, key) {
        var func, events;
        name = name.toLowerCase();
        if (obj.addEventListener) {
          func = callback;
          obj.addEventListener(name, func, false);
        } else if (obj.attachEvent) {
          func = function() {
            var evt = window.event;
            if (!evt.target) {
              evt.target = evt.srcElement;
            }
            evt.preventDefault = preventDefault;
            evt.stopPropagation = stopPropagation;
            callback(evt);
          };
          obj.attachEvent("on" + name, func);
        }
        if (!obj[uid]) {
          obj[uid] = Basic.guid();
        }
        if (!eventhash.hasOwnProperty(obj[uid])) {
          eventhash[obj[uid]] = {};
        }
        events = eventhash[obj[uid]];
        if (!events.hasOwnProperty(name)) {
          events[name] = [];
        }
        events[name].push({
          func,
          orig: callback,
          key
        });
      };
      var removeEvent = function(obj, name, callback) {
        var type, undef;
        name = name.toLowerCase();
        if (obj[uid] && eventhash[obj[uid]] && eventhash[obj[uid]][name]) {
          type = eventhash[obj[uid]][name];
        } else {
          return;
        }
        for (var i = type.length - 1; i >= 0; i--) {
          if (type[i].orig === callback || type[i].key === callback) {
            if (obj.removeEventListener) {
              obj.removeEventListener(name, type[i].func, false);
            } else if (obj.detachEvent) {
              obj.detachEvent("on" + name, type[i].func);
            }
            type[i].orig = null;
            type[i].func = null;
            type.splice(i, 1);
            if (callback !== undef) {
              break;
            }
          }
        }
        if (!type.length) {
          delete eventhash[obj[uid]][name];
        }
        if (Basic.isEmptyObj(eventhash[obj[uid]])) {
          delete eventhash[obj[uid]];
          try {
            delete obj[uid];
          } catch (e) {
            obj[uid] = undef;
          }
        }
      };
      var removeAllEvents = function(obj, key) {
        if (!obj || !obj[uid]) {
          return;
        }
        Basic.each(eventhash[obj[uid]], function(events, name) {
          removeEvent(obj, name, key);
        });
      };
      return {
        addEvent,
        removeEvent,
        removeAllEvents
      };
    });
    define("moxie/runtime/html5/file/FileInput", [
      "moxie/runtime/html5/Runtime",
      "moxie/file/File",
      "moxie/core/utils/Basic",
      "moxie/core/utils/Dom",
      "moxie/core/utils/Events",
      "moxie/core/utils/Mime",
      "moxie/core/utils/Env"
    ], function(extensions, File2, Basic, Dom, Events, Mime, Env) {
      function FileInput() {
        var _options, _browseBtnZIndex;
        Basic.extend(this, {
          init: function(options) {
            var comp = this, I = comp.getRuntime(), input, shimContainer, mimes, browseButton, zIndex, top;
            _options = options;
            mimes = Mime.extList2mimes(_options.accept, I.can("filter_by_extension"));
            shimContainer = I.getShimContainer();
            shimContainer.innerHTML = '<input id="' + I.uid + '" type="file" style="font-size:999px;opacity:0;"' + (_options.multiple && I.can("select_multiple") ? "multiple" : "") + (_options.directory && I.can("select_folder") ? "webkitdirectory directory" : "") + (mimes ? ' accept="' + mimes.join(",") + '"' : "") + " />";
            input = Dom.get(I.uid);
            Basic.extend(input.style, {
              position: "absolute",
              top: 0,
              left: 0,
              width: "100%",
              height: "100%"
            });
            browseButton = Dom.get(_options.browse_button);
            _browseBtnZIndex = Dom.getStyle(browseButton, "z-index") || "auto";
            if (I.can("summon_file_dialog")) {
              if (Dom.getStyle(browseButton, "position") === "static") {
                browseButton.style.position = "relative";
              }
              Events.addEvent(
                browseButton,
                "click",
                function(e) {
                  var input2 = Dom.get(I.uid);
                  if (input2 && !input2.disabled) {
                    input2.click();
                  }
                  e.preventDefault();
                },
                comp.uid
              );
              comp.bind("Refresh", function() {
                zIndex = parseInt(_browseBtnZIndex, 10) || 1;
                Dom.get(_options.browse_button).style.zIndex = zIndex;
                this.getRuntime().getShimContainer().style.zIndex = zIndex - 1;
              });
            }
            top = I.can("summon_file_dialog") ? browseButton : shimContainer;
            Events.addEvent(
              top,
              "mouseover",
              function() {
                comp.trigger("mouseenter");
              },
              comp.uid
            );
            Events.addEvent(
              top,
              "mouseout",
              function() {
                comp.trigger("mouseleave");
              },
              comp.uid
            );
            Events.addEvent(
              top,
              "mousedown",
              function() {
                comp.trigger("mousedown");
              },
              comp.uid
            );
            Events.addEvent(
              Dom.get(_options.container),
              "mouseup",
              function() {
                comp.trigger("mouseup");
              },
              comp.uid
            );
            (I.can("summon_file_dialog") ? input : browseButton).setAttribute("tabindex", -1);
            input.onchange = function onChange() {
              comp.files = [];
              Basic.each(this.files, function(file) {
                var relativePath = "";
                if (_options.directory) {
                  if (file.name == ".") {
                    return true;
                  }
                }
                if (file.webkitRelativePath) {
                  relativePath = "/" + file.webkitRelativePath.replace(/^\//, "");
                }
                file = new File2(I.uid, file);
                file.relativePath = relativePath;
                comp.files.push(file);
              });
              if (Env.browser !== "IE" && Env.browser !== "IEMobile") {
                this.value = "";
              } else {
                var clone = this.cloneNode(true);
                this.parentNode.replaceChild(clone, this);
                clone.onchange = onChange;
              }
              if (comp.files.length) {
                comp.trigger("change");
              }
            };
            comp.trigger({
              type: "ready",
              async: true
            });
            shimContainer = null;
          },
          setOption: function(name, value) {
            var I = this.getRuntime();
            var input = Dom.get(I.uid);
            switch (name) {
              case "accept":
                if (value) {
                  var mimes = value.mimes || Mime.extList2mimes(value, I.can("filter_by_extension"));
                  input.setAttribute("accept", mimes.join(","));
                } else {
                  input.removeAttribute("accept");
                }
                break;
              case "directory":
                if (value && I.can("select_folder")) {
                  input.setAttribute("directory", "");
                  input.setAttribute("webkitdirectory", "");
                } else {
                  input.removeAttribute("directory");
                  input.removeAttribute("webkitdirectory");
                }
                break;
              case "multiple":
                if (value && I.can("select_multiple")) {
                  input.setAttribute("multiple", "");
                } else {
                  input.removeAttribute("multiple");
                }
            }
          },
          disable: function(state) {
            var I = this.getRuntime(), input;
            if (input = Dom.get(I.uid)) {
              input.disabled = !!state;
            }
          },
          destroy: function() {
            var I = this.getRuntime(), shim = I.getShim(), shimContainer = I.getShimContainer(), container = _options && Dom.get(_options.container), browseButton = _options && Dom.get(_options.browse_button);
            if (container) {
              Events.removeAllEvents(container, this.uid);
            }
            if (browseButton) {
              Events.removeAllEvents(browseButton, this.uid);
              browseButton.style.zIndex = _browseBtnZIndex;
            }
            if (shimContainer) {
              Events.removeAllEvents(shimContainer, this.uid);
              shimContainer.innerHTML = "";
            }
            shim.removeInstance(this.uid);
            _options = shimContainer = container = browseButton = shim = null;
          }
        });
      }
      return extensions.FileInput = FileInput;
    });
    define("moxie/runtime/html5/file/FileDrop", [
      "moxie/runtime/html5/Runtime",
      "moxie/file/File",
      "moxie/core/utils/Basic",
      "moxie/core/utils/Dom",
      "moxie/core/utils/Events",
      "moxie/core/utils/Mime"
    ], function(extensions, File2, Basic, Dom, Events, Mime) {
      function FileDrop() {
        var _files = [], _allowedExts = [], _options, _ruid;
        Basic.extend(this, {
          init: function(options) {
            var comp = this, dropZone;
            _options = options;
            _ruid = comp.ruid;
            _allowedExts = _extractExts(_options.accept);
            dropZone = _options.container;
            Events.addEvent(
              dropZone,
              "dragover",
              function(e) {
                if (!_hasFiles(e)) {
                  return;
                }
                e.preventDefault();
                e.dataTransfer.dropEffect = "copy";
              },
              comp.uid
            );
            Events.addEvent(
              dropZone,
              "drop",
              function(e) {
                if (!_hasFiles(e)) {
                  return;
                }
                e.preventDefault();
                _files = [];
                if (e.dataTransfer.items && e.dataTransfer.items[0].webkitGetAsEntry) {
                  _readItems(e.dataTransfer.items, function() {
                    comp.files = _files;
                    comp.trigger("drop");
                  });
                } else {
                  Basic.each(e.dataTransfer.files, function(file) {
                    _addFile(file);
                  });
                  comp.files = _files;
                  comp.trigger("drop");
                }
              },
              comp.uid
            );
            Events.addEvent(
              dropZone,
              "dragenter",
              function(e) {
                comp.trigger("dragenter");
              },
              comp.uid
            );
            Events.addEvent(
              dropZone,
              "dragleave",
              function(e) {
                comp.trigger("dragleave");
              },
              comp.uid
            );
          },
          destroy: function() {
            Events.removeAllEvents(_options && Dom.get(_options.container), this.uid);
            _ruid = _files = _allowedExts = _options = null;
            this.getRuntime().getShim().removeInstance(this.uid);
          }
        });
        function _hasFiles(e) {
          if (!e.dataTransfer || !e.dataTransfer.types) {
            return false;
          }
          var types = Basic.toArray(e.dataTransfer.types || []);
          return Basic.inArray("Files", types) !== -1 || Basic.inArray("public.file-url", types) !== -1 || Basic.inArray("application/x-moz-file", types) !== -1;
        }
        function _addFile(file, relativePath) {
          if (_isAcceptable(file)) {
            var fileObj = new File2(_ruid, file);
            fileObj.relativePath = relativePath || "";
            _files.push(fileObj);
          }
        }
        function _extractExts(accept) {
          var exts = [];
          for (var i = 0; i < accept.length; i++) {
            [].push.apply(exts, accept[i].extensions.split(/\s*,\s*/));
          }
          return Basic.inArray("*", exts) === -1 ? exts : [];
        }
        function _isAcceptable(file) {
          if (!_allowedExts.length) {
            return true;
          }
          var ext = Mime.getFileExtension(file.name);
          return !ext || Basic.inArray(ext, _allowedExts) !== -1;
        }
        function _readItems(items, cb) {
          var entries = [];
          Basic.each(items, function(item) {
            var entry = item.webkitGetAsEntry();
            if (entry) {
              if (entry.isFile) {
                _addFile(item.getAsFile(), entry.fullPath);
              } else {
                entries.push(entry);
              }
            }
          });
          if (entries.length) {
            _readEntries(entries, cb);
          } else {
            cb();
          }
        }
        function _readEntries(entries, cb) {
          var queue = [];
          Basic.each(entries, function(entry) {
            queue.push(function(cbcb) {
              _readEntry(entry, cbcb);
            });
          });
          Basic.inSeries(queue, function() {
            cb();
          });
        }
        function _readEntry(entry, cb) {
          if (entry.isFile) {
            entry.file(
              function(file) {
                _addFile(file, entry.fullPath);
                cb();
              },
              function() {
                cb();
              }
            );
          } else if (entry.isDirectory) {
            _readDirEntry(entry, cb);
          } else {
            cb();
          }
        }
        function _readDirEntry(dirEntry, cb) {
          var entries = [], dirReader = dirEntry.createReader();
          function getEntries(cbcb) {
            dirReader.readEntries(function(moreEntries) {
              if (moreEntries.length) {
                [].push.apply(entries, moreEntries);
                getEntries(cbcb);
              } else {
                cbcb();
              }
            }, cbcb);
          }
          getEntries(function() {
            _readEntries(entries, cb);
          });
        }
      }
      return extensions.FileDrop = FileDrop;
    });
    define("moxie/runtime/html5/file/FileReader", [
      "moxie/runtime/html5/Runtime",
      "moxie/core/utils/Encode",
      "moxie/core/utils/Basic"
    ], function(extensions, Encode, Basic) {
      function FileReader2() {
        var _fr, _convertToBinary = false;
        Basic.extend(this, {
          read: function(op, blob) {
            var comp = this;
            comp.result = "";
            _fr = new window.FileReader();
            _fr.addEventListener("progress", function(e) {
              comp.trigger(e);
            });
            _fr.addEventListener("load", function(e) {
              comp.result = _convertToBinary ? _toBinary(_fr.result) : _fr.result;
              comp.trigger(e);
            });
            _fr.addEventListener("error", function(e) {
              comp.trigger(e, _fr.error);
            });
            _fr.addEventListener("loadend", function(e) {
              _fr = null;
              comp.trigger(e);
            });
            if (Basic.typeOf(_fr[op]) === "function") {
              _convertToBinary = false;
              _fr[op](blob.getSource());
            } else if (op === "readAsBinaryString") {
              _convertToBinary = true;
              _fr.readAsDataURL(blob.getSource());
            }
          },
          abort: function() {
            if (_fr) {
              _fr.abort();
            }
          },
          destroy: function() {
            _fr = null;
            this.getRuntime().getShim().removeInstance(this.uid);
          }
        });
        function _toBinary(str) {
          return Encode.atob(str.substring(str.indexOf("base64,") + 7));
        }
      }
      return extensions.FileReader = FileReader2;
    });
    define("moxie/runtime/html5/xhr/XMLHttpRequest", [
      "moxie/runtime/html5/Runtime",
      "moxie/core/utils/Basic",
      "moxie/core/utils/Mime",
      "moxie/core/utils/Url",
      "moxie/file/File",
      "moxie/file/Blob",
      "moxie/xhr/FormData",
      "moxie/core/Exceptions",
      "moxie/core/utils/Env"
    ], function(extensions, Basic, Mime, Url, File2, Blob, FormData, x, Env) {
      function XMLHttpRequest2() {
        var self = this, _xhr, _filename;
        Basic.extend(this, {
          send: function(meta, data) {
            var target = this, isGecko2_5_6 = Env.browser === "Mozilla" && Env.verComp(Env.version, 4, ">=") && Env.verComp(Env.version, 7, "<"), isAndroidBrowser = Env.browser === "Android Browser", mustSendAsBinary = false;
            _filename = meta.url.replace(/^.+?\/([\w\-\.]+)$/, "$1").toLowerCase();
            _xhr = _getNativeXHR();
            _xhr.open(meta.method, meta.url, meta.async, meta.user, meta.password);
            if (data instanceof Blob) {
              if (data.isDetached()) {
                mustSendAsBinary = true;
              }
              data = data.getSource();
            } else if (data instanceof FormData) {
              if (data.hasBlob()) {
                if (data.getBlob().isDetached()) {
                  data = _prepareMultipart.call(target, data);
                  mustSendAsBinary = true;
                } else if ((isGecko2_5_6 || isAndroidBrowser) && Basic.typeOf(data.getBlob().getSource()) === "blob" && window.FileReader) {
                  _preloadAndSend.call(target, meta, data);
                  return;
                }
              }
              if (data instanceof FormData) {
                var fd = new window.FormData();
                data.each(function(value, name) {
                  if (value instanceof Blob) {
                    fd.append(name, value.getSource());
                  } else {
                    fd.append(name, value);
                  }
                });
                data = fd;
              }
            }
            if (_xhr.upload) {
              if (meta.withCredentials) {
                _xhr.withCredentials = true;
              }
              _xhr.addEventListener("load", function(e) {
                target.trigger(e);
              });
              _xhr.addEventListener("error", function(e) {
                target.trigger(e);
              });
              _xhr.addEventListener("progress", function(e) {
                target.trigger(e);
              });
              _xhr.upload.addEventListener("progress", function(e) {
                target.trigger({
                  type: "UploadProgress",
                  loaded: e.loaded,
                  total: e.total
                });
              });
            } else {
              _xhr.onreadystatechange = function onReadyStateChange() {
                switch (_xhr.readyState) {
                  case 1:
                    break;
                  case 2:
                    break;
                  case 3:
                    var total, loaded;
                    try {
                      if (Url.hasSameOrigin(meta.url)) {
                        total = _xhr.getResponseHeader("Content-Length") || 0;
                      }
                      if (_xhr.responseText) {
                        loaded = _xhr.responseText.length;
                      }
                    } catch (ex) {
                      total = loaded = 0;
                    }
                    target.trigger({
                      type: "progress",
                      lengthComputable: !!total,
                      total: parseInt(total, 10),
                      loaded
                    });
                    break;
                  case 4:
                    _xhr.onreadystatechange = function() {
                    };
                    try {
                      if (_xhr.status >= 200 && _xhr.status < 400) {
                        target.trigger("load");
                        break;
                      }
                    } catch (ex) {
                    }
                    target.trigger("error");
                    break;
                }
              };
            }
            if (!Basic.isEmptyObj(meta.headers)) {
              Basic.each(meta.headers, function(value, header) {
                _xhr.setRequestHeader(header, value);
              });
            }
            if ("" !== meta.responseType && "responseType" in _xhr) {
              if ("json" === meta.responseType && !Env.can("return_response_type", "json")) {
                _xhr.responseType = "text";
              } else {
                _xhr.responseType = meta.responseType;
              }
            }
            if (!mustSendAsBinary) {
              _xhr.send(data);
            } else {
              if (_xhr.sendAsBinary) {
                _xhr.sendAsBinary(data);
              } else {
                (function() {
                  var ui8a = new Uint8Array(data.length);
                  for (var i = 0; i < data.length; i++) {
                    ui8a[i] = data.charCodeAt(i) & 255;
                  }
                  _xhr.send(ui8a.buffer);
                })();
              }
            }
            target.trigger("loadstart");
          },
          getStatus: function() {
            try {
              if (_xhr) {
                return _xhr.status;
              }
            } catch (ex) {
            }
            return 0;
          },
          getResponse: function(responseType) {
            var I = this.getRuntime();
            try {
              switch (responseType) {
                case "blob":
                  var file = new File2(I.uid, _xhr.response);
                  var disposition = _xhr.getResponseHeader("Content-Disposition");
                  if (disposition) {
                    var match = disposition.match(/filename=([\'\"'])([^\1]+)\1/);
                    if (match) {
                      _filename = match[2];
                    }
                  }
                  file.name = _filename;
                  if (!file.type) {
                    file.type = Mime.getFileMime(_filename);
                  }
                  return file;
                case "json":
                  if (!Env.can("return_response_type", "json")) {
                    return _xhr.status === 200 && !!window.JSON ? JSON.parse(_xhr.responseText) : null;
                  }
                  return _xhr.response;
                case "document":
                  return _getDocument(_xhr);
                default:
                  return _xhr.responseText !== "" ? _xhr.responseText : null;
              }
            } catch (ex) {
              return null;
            }
          },
          getAllResponseHeaders: function() {
            try {
              return _xhr.getAllResponseHeaders();
            } catch (ex) {
            }
            return "";
          },
          abort: function() {
            if (_xhr) {
              _xhr.abort();
            }
          },
          destroy: function() {
            self = _filename = null;
            this.getRuntime().getShim().removeInstance(this.uid);
          }
        });
        function _preloadAndSend(meta, data) {
          var target = this, blob, fr;
          blob = data.getBlob().getSource();
          fr = new window.FileReader();
          fr.onload = function() {
            data.append(
              data.getBlobName(),
              new Blob(null, {
                type: blob.type,
                data: fr.result
              })
            );
            self.send.call(target, meta, data);
          };
          fr.readAsBinaryString(blob);
        }
        function _getNativeXHR() {
          if (window.XMLHttpRequest && !(Env.browser === "IE" && Env.verComp(Env.version, 8, "<"))) {
            return new window.XMLHttpRequest();
          } else {
            return function() {
              var progIDs = ["Msxml2.XMLHTTP.6.0", "Microsoft.XMLHTTP"];
              for (var i = 0; i < progIDs.length; i++) {
                try {
                  return new ActiveXObject(progIDs[i]);
                } catch (ex) {
                }
              }
            }();
          }
        }
        function _getDocument(xhr) {
          var rXML = xhr.responseXML;
          var rText = xhr.responseText;
          if (Env.browser === "IE" && rText && rXML && !rXML.documentElement && /[^\/]+\/[^\+]+\+xml/.test(xhr.getResponseHeader("Content-Type"))) {
            rXML = new window.ActiveXObject("Microsoft.XMLDOM");
            rXML.async = false;
            rXML.validateOnParse = false;
            rXML.loadXML(rText);
          }
          if (rXML) {
            if (Env.browser === "IE" && rXML.parseError !== 0 || !rXML.documentElement || rXML.documentElement.tagName === "parsererror") {
              return null;
            }
          }
          return rXML;
        }
        function _prepareMultipart(fd) {
          var boundary = "----moxieboundary" + new Date().getTime(), dashdash = "--", crlf = "\r\n", multipart = "", I = this.getRuntime();
          if (!I.can("send_binary_string")) {
            throw new x.RuntimeError(x.RuntimeError.NOT_SUPPORTED_ERR);
          }
          _xhr.setRequestHeader("Content-Type", "multipart/form-data; boundary=" + boundary);
          fd.each(function(value, name) {
            if (value instanceof Blob) {
              multipart += dashdash + boundary + crlf + 'Content-Disposition: form-data; name="' + name + '"; filename="' + unescape(encodeURIComponent(value.name || "blob")) + '"' + crlf + "Content-Type: " + (value.type || "application/octet-stream") + crlf + crlf + value.getSource() + crlf;
            } else {
              multipart += dashdash + boundary + crlf + 'Content-Disposition: form-data; name="' + name + '"' + crlf + crlf + unescape(encodeURIComponent(value)) + crlf;
            }
          });
          multipart += dashdash + boundary + dashdash + crlf;
          return multipart;
        }
      }
      return extensions.XMLHttpRequest = XMLHttpRequest2;
    });
    define("moxie/runtime/html5/utils/BinaryReader", ["moxie/core/utils/Basic"], function(Basic) {
      function BinaryReader(data) {
        if (data instanceof ArrayBuffer) {
          ArrayBufferReader.apply(this, arguments);
        } else {
          UTF16StringReader.apply(this, arguments);
        }
      }
      Basic.extend(BinaryReader.prototype, {
        littleEndian: false,
        read: function(idx, size) {
          var sum, mv, i;
          if (idx + size > this.length()) {
            throw new Error("You are trying to read outside the source boundaries.");
          }
          mv = this.littleEndian ? 0 : -8 * (size - 1);
          for (i = 0, sum = 0; i < size; i++) {
            sum |= this.readByteAt(idx + i) << Math.abs(mv + i * 8);
          }
          return sum;
        },
        write: function(idx, num, size) {
          var mv, i;
          if (idx > this.length()) {
            throw new Error("You are trying to write outside the source boundaries.");
          }
          mv = this.littleEndian ? 0 : -8 * (size - 1);
          for (i = 0; i < size; i++) {
            this.writeByteAt(idx + i, num >> Math.abs(mv + i * 8) & 255);
          }
        },
        BYTE: function(idx) {
          return this.read(idx, 1);
        },
        SHORT: function(idx) {
          return this.read(idx, 2);
        },
        LONG: function(idx) {
          return this.read(idx, 4);
        },
        SLONG: function(idx) {
          var num = this.read(idx, 4);
          return num > 2147483647 ? num - 4294967296 : num;
        },
        CHAR: function(idx) {
          return String.fromCharCode(this.read(idx, 1));
        },
        STRING: function(idx, count) {
          return this.asArray("CHAR", idx, count).join("");
        },
        asArray: function(type, idx, count) {
          var values = [];
          for (var i = 0; i < count; i++) {
            values[i] = this[type](idx + i);
          }
          return values;
        }
      });
      function ArrayBufferReader(data) {
        var _dv = new DataView(data);
        Basic.extend(this, {
          readByteAt: function(idx) {
            return _dv.getUint8(idx);
          },
          writeByteAt: function(idx, value) {
            _dv.setUint8(idx, value);
          },
          SEGMENT: function(idx, size, value) {
            switch (arguments.length) {
              case 2:
                return data.slice(idx, idx + size);
              case 1:
                return data.slice(idx);
              case 3:
                if (value === null) {
                  value = new ArrayBuffer();
                }
                if (value instanceof ArrayBuffer) {
                  var arr = new Uint8Array(this.length() - size + value.byteLength);
                  if (idx > 0) {
                    arr.set(new Uint8Array(data.slice(0, idx)), 0);
                  }
                  arr.set(new Uint8Array(value), idx);
                  arr.set(new Uint8Array(data.slice(idx + size)), idx + value.byteLength);
                  this.clear();
                  data = arr.buffer;
                  _dv = new DataView(data);
                  break;
                }
              default:
                return data;
            }
          },
          length: function() {
            return data ? data.byteLength : 0;
          },
          clear: function() {
            _dv = data = null;
          }
        });
      }
      function UTF16StringReader(data) {
        Basic.extend(this, {
          readByteAt: function(idx) {
            return data.charCodeAt(idx);
          },
          writeByteAt: function(idx, value) {
            putstr(String.fromCharCode(value), idx, 1);
          },
          SEGMENT: function(idx, length, segment) {
            switch (arguments.length) {
              case 1:
                return data.substr(idx);
              case 2:
                return data.substr(idx, length);
              case 3:
                putstr(segment !== null ? segment : "", idx, length);
                break;
              default:
                return data;
            }
          },
          length: function() {
            return data ? data.length : 0;
          },
          clear: function() {
            data = null;
          }
        });
        function putstr(segment, idx, length) {
          length = arguments.length === 3 ? length : data.length - idx - 1;
          data = data.substr(0, idx) + segment + data.substr(length + idx);
        }
      }
      return BinaryReader;
    });
    define("moxie/runtime/html5/image/JPEGHeaders", [
      "moxie/runtime/html5/utils/BinaryReader",
      "moxie/core/Exceptions"
    ], function(BinaryReader, x) {
      return function JPEGHeaders(data) {
        var headers = [], _br, idx, marker, length = 0;
        _br = new BinaryReader(data);
        if (_br.SHORT(0) !== 65496) {
          _br.clear();
          throw new x.ImageError(x.ImageError.WRONG_FORMAT);
        }
        idx = 2;
        while (idx <= _br.length()) {
          marker = _br.SHORT(idx);
          if (marker >= 65488 && marker <= 65495) {
            idx += 2;
            continue;
          }
          if (marker === 65498 || marker === 65497) {
            break;
          }
          length = _br.SHORT(idx + 2) + 2;
          if (marker >= 65505 && marker <= 65519) {
            headers.push({
              hex: marker,
              name: "APP" + (marker & 15),
              start: idx,
              length,
              segment: _br.SEGMENT(idx, length)
            });
          }
          idx += length;
        }
        _br.clear();
        return {
          headers,
          restore: function(data2) {
            var max, i, br;
            br = new BinaryReader(data2);
            idx = br.SHORT(2) == 65504 ? 4 + br.SHORT(4) : 2;
            for (i = 0, max = headers.length; i < max; i++) {
              br.SEGMENT(idx, 0, headers[i].segment);
              idx += headers[i].length;
            }
            data2 = br.SEGMENT();
            br.clear();
            return data2;
          },
          strip: function(data2) {
            var br, headers2, jpegHeaders, i;
            jpegHeaders = new JPEGHeaders(data2);
            headers2 = jpegHeaders.headers;
            jpegHeaders.purge();
            br = new BinaryReader(data2);
            i = headers2.length;
            while (i--) {
              br.SEGMENT(headers2[i].start, headers2[i].length, "");
            }
            data2 = br.SEGMENT();
            br.clear();
            return data2;
          },
          get: function(name) {
            var array = [];
            for (var i = 0, max = headers.length; i < max; i++) {
              if (headers[i].name === name.toUpperCase()) {
                array.push(headers[i].segment);
              }
            }
            return array;
          },
          set: function(name, segment) {
            var array = [], i, ii, max;
            if (typeof segment === "string") {
              array.push(segment);
            } else {
              array = segment;
            }
            for (i = ii = 0, max = headers.length; i < max; i++) {
              if (headers[i].name === name.toUpperCase()) {
                headers[i].segment = array[ii];
                headers[i].length = array[ii].length;
                ii++;
              }
              if (ii >= array.length) {
                break;
              }
            }
          },
          purge: function() {
            this.headers = headers = [];
          }
        };
      };
    });
    define("moxie/runtime/html5/image/ExifParser", [
      "moxie/core/utils/Basic",
      "moxie/runtime/html5/utils/BinaryReader",
      "moxie/core/Exceptions"
    ], function(Basic, BinaryReader, x) {
      function ExifParser(data) {
        var __super__, tags, tagDescs, offsets, idx, Tiff;
        BinaryReader.call(this, data);
        tags = {
          tiff: {
            274: "Orientation",
            270: "ImageDescription",
            271: "Make",
            272: "Model",
            305: "Software",
            34665: "ExifIFDPointer",
            34853: "GPSInfoIFDPointer"
          },
          exif: {
            36864: "ExifVersion",
            40961: "ColorSpace",
            40962: "PixelXDimension",
            40963: "PixelYDimension",
            36867: "DateTimeOriginal",
            33434: "ExposureTime",
            33437: "FNumber",
            34855: "ISOSpeedRatings",
            37377: "ShutterSpeedValue",
            37378: "ApertureValue",
            37383: "MeteringMode",
            37384: "LightSource",
            37385: "Flash",
            37386: "FocalLength",
            41986: "ExposureMode",
            41987: "WhiteBalance",
            41990: "SceneCaptureType",
            41988: "DigitalZoomRatio",
            41992: "Contrast",
            41993: "Saturation",
            41994: "Sharpness"
          },
          gps: {
            0: "GPSVersionID",
            1: "GPSLatitudeRef",
            2: "GPSLatitude",
            3: "GPSLongitudeRef",
            4: "GPSLongitude"
          },
          thumb: {
            513: "JPEGInterchangeFormat",
            514: "JPEGInterchangeFormatLength"
          }
        };
        tagDescs = {
          ColorSpace: {
            1: "sRGB",
            0: "Uncalibrated"
          },
          MeteringMode: {
            0: "Unknown",
            1: "Average",
            2: "CenterWeightedAverage",
            3: "Spot",
            4: "MultiSpot",
            5: "Pattern",
            6: "Partial",
            255: "Other"
          },
          LightSource: {
            1: "Daylight",
            2: "Fliorescent",
            3: "Tungsten",
            4: "Flash",
            9: "Fine weather",
            10: "Cloudy weather",
            11: "Shade",
            12: "Daylight fluorescent (D 5700 - 7100K)",
            13: "Day white fluorescent (N 4600 -5400K)",
            14: "Cool white fluorescent (W 3900 - 4500K)",
            15: "White fluorescent (WW 3200 - 3700K)",
            17: "Standard light A",
            18: "Standard light B",
            19: "Standard light C",
            20: "D55",
            21: "D65",
            22: "D75",
            23: "D50",
            24: "ISO studio tungsten",
            255: "Other"
          },
          Flash: {
            0: "Flash did not fire",
            1: "Flash fired",
            5: "Strobe return light not detected",
            7: "Strobe return light detected",
            9: "Flash fired, compulsory flash mode",
            13: "Flash fired, compulsory flash mode, return light not detected",
            15: "Flash fired, compulsory flash mode, return light detected",
            16: "Flash did not fire, compulsory flash mode",
            24: "Flash did not fire, auto mode",
            25: "Flash fired, auto mode",
            29: "Flash fired, auto mode, return light not detected",
            31: "Flash fired, auto mode, return light detected",
            32: "No flash function",
            65: "Flash fired, red-eye reduction mode",
            69: "Flash fired, red-eye reduction mode, return light not detected",
            71: "Flash fired, red-eye reduction mode, return light detected",
            73: "Flash fired, compulsory flash mode, red-eye reduction mode",
            77: "Flash fired, compulsory flash mode, red-eye reduction mode, return light not detected",
            79: "Flash fired, compulsory flash mode, red-eye reduction mode, return light detected",
            89: "Flash fired, auto mode, red-eye reduction mode",
            93: "Flash fired, auto mode, return light not detected, red-eye reduction mode",
            95: "Flash fired, auto mode, return light detected, red-eye reduction mode"
          },
          ExposureMode: {
            0: "Auto exposure",
            1: "Manual exposure",
            2: "Auto bracket"
          },
          WhiteBalance: {
            0: "Auto white balance",
            1: "Manual white balance"
          },
          SceneCaptureType: {
            0: "Standard",
            1: "Landscape",
            2: "Portrait",
            3: "Night scene"
          },
          Contrast: {
            0: "Normal",
            1: "Soft",
            2: "Hard"
          },
          Saturation: {
            0: "Normal",
            1: "Low saturation",
            2: "High saturation"
          },
          Sharpness: {
            0: "Normal",
            1: "Soft",
            2: "Hard"
          },
          GPSLatitudeRef: {
            N: "North latitude",
            S: "South latitude"
          },
          GPSLongitudeRef: {
            E: "East longitude",
            W: "West longitude"
          }
        };
        offsets = {
          tiffHeader: 10
        };
        idx = offsets.tiffHeader;
        __super__ = {
          clear: this.clear
        };
        Basic.extend(this, {
          read: function() {
            try {
              return ExifParser.prototype.read.apply(this, arguments);
            } catch (ex) {
              throw new x.ImageError(x.ImageError.INVALID_META_ERR);
            }
          },
          write: function() {
            try {
              return ExifParser.prototype.write.apply(this, arguments);
            } catch (ex) {
              throw new x.ImageError(x.ImageError.INVALID_META_ERR);
            }
          },
          UNDEFINED: function() {
            return this.BYTE.apply(this, arguments);
          },
          RATIONAL: function(idx2) {
            return this.LONG(idx2) / this.LONG(idx2 + 4);
          },
          SRATIONAL: function(idx2) {
            return this.SLONG(idx2) / this.SLONG(idx2 + 4);
          },
          ASCII: function(idx2) {
            return this.CHAR(idx2);
          },
          TIFF: function() {
            return Tiff || null;
          },
          EXIF: function() {
            var Exif = null;
            if (offsets.exifIFD) {
              try {
                Exif = extractTags.call(this, offsets.exifIFD, tags.exif);
              } catch (ex) {
                return null;
              }
              if (Exif.ExifVersion && Basic.typeOf(Exif.ExifVersion) === "array") {
                for (var i = 0, exifVersion = ""; i < Exif.ExifVersion.length; i++) {
                  exifVersion += String.fromCharCode(Exif.ExifVersion[i]);
                }
                Exif.ExifVersion = exifVersion;
              }
            }
            return Exif;
          },
          GPS: function() {
            var GPS = null;
            if (offsets.gpsIFD) {
              try {
                GPS = extractTags.call(this, offsets.gpsIFD, tags.gps);
              } catch (ex) {
                return null;
              }
              if (GPS.GPSVersionID && Basic.typeOf(GPS.GPSVersionID) === "array") {
                GPS.GPSVersionID = GPS.GPSVersionID.join(".");
              }
            }
            return GPS;
          },
          thumb: function() {
            if (offsets.IFD1) {
              try {
                var IFD1Tags = extractTags.call(this, offsets.IFD1, tags.thumb);
                if ("JPEGInterchangeFormat" in IFD1Tags) {
                  return this.SEGMENT(
                    offsets.tiffHeader + IFD1Tags.JPEGInterchangeFormat,
                    IFD1Tags.JPEGInterchangeFormatLength
                  );
                }
              } catch (ex) {
              }
            }
            return null;
          },
          setExif: function(tag, value) {
            if (tag !== "PixelXDimension" && tag !== "PixelYDimension") {
              return false;
            }
            return setTag.call(this, "exif", tag, value);
          },
          clear: function() {
            __super__.clear();
            data = tags = tagDescs = Tiff = offsets = __super__ = null;
          }
        });
        if (this.SHORT(0) !== 65505 || this.STRING(4, 5).toUpperCase() !== "EXIF\0") {
          throw new x.ImageError(x.ImageError.INVALID_META_ERR);
        }
        this.littleEndian = this.SHORT(idx) == 18761;
        if (this.SHORT(idx += 2) !== 42) {
          throw new x.ImageError(x.ImageError.INVALID_META_ERR);
        }
        offsets.IFD0 = offsets.tiffHeader + this.LONG(idx += 2);
        Tiff = extractTags.call(this, offsets.IFD0, tags.tiff);
        if ("ExifIFDPointer" in Tiff) {
          offsets.exifIFD = offsets.tiffHeader + Tiff.ExifIFDPointer;
          delete Tiff.ExifIFDPointer;
        }
        if ("GPSInfoIFDPointer" in Tiff) {
          offsets.gpsIFD = offsets.tiffHeader + Tiff.GPSInfoIFDPointer;
          delete Tiff.GPSInfoIFDPointer;
        }
        if (Basic.isEmptyObj(Tiff)) {
          Tiff = null;
        }
        var IFD1Offset = this.LONG(offsets.IFD0 + this.SHORT(offsets.IFD0) * 12 + 2);
        if (IFD1Offset) {
          offsets.IFD1 = offsets.tiffHeader + IFD1Offset;
        }
        function extractTags(IFD_offset, tags2extract) {
          var data2 = this;
          var length, i, tag, type, count, size, offset, value, values = [], hash = {};
          var types = {
            1: "BYTE",
            7: "UNDEFINED",
            2: "ASCII",
            3: "SHORT",
            4: "LONG",
            5: "RATIONAL",
            9: "SLONG",
            10: "SRATIONAL"
          };
          var sizes = {
            BYTE: 1,
            UNDEFINED: 1,
            ASCII: 1,
            SHORT: 2,
            LONG: 4,
            RATIONAL: 8,
            SLONG: 4,
            SRATIONAL: 8
          };
          length = data2.SHORT(IFD_offset);
          for (i = 0; i < length; i++) {
            values = [];
            offset = IFD_offset + 2 + i * 12;
            tag = tags2extract[data2.SHORT(offset)];
            if (tag === undefined$1) {
              continue;
            }
            type = types[data2.SHORT(offset += 2)];
            count = data2.LONG(offset += 2);
            size = sizes[type];
            if (!size) {
              throw new x.ImageError(x.ImageError.INVALID_META_ERR);
            }
            offset += 4;
            if (size * count > 4) {
              offset = data2.LONG(offset) + offsets.tiffHeader;
            }
            if (offset + size * count >= this.length()) {
              throw new x.ImageError(x.ImageError.INVALID_META_ERR);
            }
            if (type === "ASCII") {
              hash[tag] = Basic.trim(data2.STRING(offset, count).replace(/\0$/, ""));
              continue;
            } else {
              values = data2.asArray(type, offset, count);
              value = count == 1 ? values[0] : values;
              if (tagDescs.hasOwnProperty(tag) && typeof value != "object") {
                hash[tag] = tagDescs[tag][value];
              } else {
                hash[tag] = value;
              }
            }
          }
          return hash;
        }
        function setTag(ifd, tag, value) {
          var offset, length, tagOffset, valueOffset = 0;
          if (typeof tag === "string") {
            var tmpTags = tags[ifd.toLowerCase()];
            for (var hex in tmpTags) {
              if (tmpTags[hex] === tag) {
                tag = hex;
                break;
              }
            }
          }
          offset = offsets[ifd.toLowerCase() + "IFD"];
          length = this.SHORT(offset);
          for (var i = 0; i < length; i++) {
            tagOffset = offset + 12 * i + 2;
            if (this.SHORT(tagOffset) == tag) {
              valueOffset = tagOffset + 8;
              break;
            }
          }
          if (!valueOffset) {
            return false;
          }
          try {
            this.write(valueOffset, value, 4);
          } catch (ex) {
            return false;
          }
          return true;
        }
      }
      ExifParser.prototype = BinaryReader.prototype;
      return ExifParser;
    });
    define("moxie/runtime/html5/image/JPEG", [
      "moxie/core/utils/Basic",
      "moxie/core/Exceptions",
      "moxie/runtime/html5/image/JPEGHeaders",
      "moxie/runtime/html5/utils/BinaryReader",
      "moxie/runtime/html5/image/ExifParser"
    ], function(Basic, x, JPEGHeaders, BinaryReader, ExifParser) {
      function JPEG(data) {
        var _br, _hm, _ep, _info;
        _br = new BinaryReader(data);
        if (_br.SHORT(0) !== 65496) {
          throw new x.ImageError(x.ImageError.WRONG_FORMAT);
        }
        _hm = new JPEGHeaders(data);
        try {
          _ep = new ExifParser(_hm.get("app1")[0]);
        } catch (ex) {
        }
        _info = _getDimensions.call(this);
        Basic.extend(this, {
          type: "image/jpeg",
          size: _br.length(),
          width: _info && _info.width || 0,
          height: _info && _info.height || 0,
          setExif: function(tag, value) {
            if (!_ep) {
              return false;
            }
            if (Basic.typeOf(tag) === "object") {
              Basic.each(tag, function(value2, tag2) {
                _ep.setExif(tag2, value2);
              });
            } else {
              _ep.setExif(tag, value);
            }
            _hm.set("app1", _ep.SEGMENT());
          },
          writeHeaders: function() {
            if (!arguments.length) {
              return _hm.restore(data);
            }
            return _hm.restore(arguments[0]);
          },
          stripHeaders: function(data2) {
            return _hm.strip(data2);
          },
          purge: function() {
            _purge.call(this);
          }
        });
        if (_ep) {
          this.meta = {
            tiff: _ep.TIFF(),
            exif: _ep.EXIF(),
            gps: _ep.GPS(),
            thumb: _getThumb()
          };
        }
        function _getDimensions(br) {
          var idx = 0, marker, length;
          if (!br) {
            br = _br;
          }
          while (idx <= br.length()) {
            marker = br.SHORT(idx += 2);
            if (marker >= 65472 && marker <= 65475) {
              idx += 5;
              return {
                height: br.SHORT(idx),
                width: br.SHORT(idx += 2)
              };
            }
            length = br.SHORT(idx += 2);
            idx += length - 2;
          }
          return null;
        }
        function _getThumb() {
          var data2 = _ep.thumb(), br, info;
          if (data2) {
            br = new BinaryReader(data2);
            info = _getDimensions(br);
            br.clear();
            if (info) {
              info.data = data2;
              return info;
            }
          }
          return null;
        }
        function _purge() {
          if (!_ep || !_hm || !_br) {
            return;
          }
          _ep.clear();
          _hm.purge();
          _br.clear();
          _info = _hm = _ep = _br = null;
        }
      }
      return JPEG;
    });
    define("moxie/runtime/html5/image/PNG", [
      "moxie/core/Exceptions",
      "moxie/core/utils/Basic",
      "moxie/runtime/html5/utils/BinaryReader"
    ], function(x, Basic, BinaryReader) {
      function PNG(data) {
        var _br, _info;
        _br = new BinaryReader(data);
        (function() {
          var idx = 0, i = 0, signature = [35152, 20039, 3338, 6666];
          for (i = 0; i < signature.length; i++, idx += 2) {
            if (signature[i] != _br.SHORT(idx)) {
              throw new x.ImageError(x.ImageError.WRONG_FORMAT);
            }
          }
        })();
        function _getDimensions() {
          var chunk, idx;
          chunk = _getChunkAt.call(this, 8);
          if (chunk.type == "IHDR") {
            idx = chunk.start;
            return {
              width: _br.LONG(idx),
              height: _br.LONG(idx += 4)
            };
          }
          return null;
        }
        function _purge() {
          if (!_br) {
            return;
          }
          _br.clear();
          data = _info = _br = null;
        }
        _info = _getDimensions.call(this);
        Basic.extend(this, {
          type: "image/png",
          size: _br.length(),
          width: _info.width,
          height: _info.height,
          purge: function() {
            _purge.call(this);
          }
        });
        _purge.call(this);
        function _getChunkAt(idx) {
          var length, type, start, CRC;
          length = _br.LONG(idx);
          type = _br.STRING(idx += 4, 4);
          start = idx += 4;
          CRC = _br.LONG(idx + length);
          return {
            length,
            type,
            start,
            CRC
          };
        }
      }
      return PNG;
    });
    define("moxie/runtime/html5/image/ImageInfo", [
      "moxie/core/utils/Basic",
      "moxie/core/Exceptions",
      "moxie/runtime/html5/image/JPEG",
      "moxie/runtime/html5/image/PNG"
    ], function(Basic, x, JPEG, PNG) {
      return function(data) {
        var _cs = [JPEG, PNG], _img;
        _img = function() {
          for (var i = 0; i < _cs.length; i++) {
            try {
              return new _cs[i](data);
            } catch (ex) {
            }
          }
          throw new x.ImageError(x.ImageError.WRONG_FORMAT);
        }();
        Basic.extend(this, {
          type: "",
          size: 0,
          width: 0,
          height: 0,
          setExif: function() {
          },
          writeHeaders: function(data2) {
            return data2;
          },
          stripHeaders: function(data2) {
            return data2;
          },
          purge: function() {
            data = null;
          }
        });
        Basic.extend(this, _img);
        this.purge = function() {
          _img.purge();
          _img = null;
        };
      };
    });
    define("moxie/runtime/html5/image/ResizerCanvas", [], function() {
      function scale(image, ratio, resample) {
        var sD = image.width > image.height ? "width" : "height";
        var dD = Math.round(image[sD] * ratio);
        var scaleCapped = false;
        if (resample !== "nearest" && (ratio < 0.5 || ratio > 2)) {
          ratio = ratio < 0.5 ? 0.5 : 2;
          scaleCapped = true;
        }
        var tCanvas = _scale(image, ratio);
        if (scaleCapped) {
          return scale(tCanvas, dD / tCanvas[sD], resample);
        } else {
          return tCanvas;
        }
      }
      function _scale(image, ratio) {
        var sW = image.width;
        var sH = image.height;
        var dW = Math.round(sW * ratio);
        var dH = Math.round(sH * ratio);
        var canvas = document.createElement("canvas");
        canvas.width = dW;
        canvas.height = dH;
        canvas.getContext("2d").drawImage(image, 0, 0, sW, sH, 0, 0, dW, dH);
        image = null;
        return canvas;
      }
      return {
        scale
      };
    });
    define("moxie/runtime/html5/image/Image", [
      "moxie/runtime/html5/Runtime",
      "moxie/core/utils/Basic",
      "moxie/core/Exceptions",
      "moxie/core/utils/Encode",
      "moxie/file/Blob",
      "moxie/file/File",
      "moxie/runtime/html5/image/ImageInfo",
      "moxie/runtime/html5/image/ResizerCanvas",
      "moxie/core/utils/Mime",
      "moxie/core/utils/Env"
    ], function(extensions, Basic, x, Encode, Blob, File2, ImageInfo, ResizerCanvas, Mime, Env) {
      function HTML5Image() {
        var me = this, _img, _imgInfo, _canvas, _binStr, _blob, _modified = false, _preserveHeaders = true;
        Basic.extend(this, {
          loadFromBlob: function(blob) {
            var I = this.getRuntime(), asBinary = arguments.length > 1 ? arguments[1] : true;
            if (!I.can("access_binary")) {
              throw new x.RuntimeError(x.RuntimeError.NOT_SUPPORTED_ERR);
            }
            _blob = blob;
            if (blob.isDetached()) {
              _binStr = blob.getSource();
              _preload.call(this, _binStr);
              return;
            } else {
              _readAsDataUrl.call(this, blob.getSource(), function(dataUrl) {
                if (asBinary) {
                  _binStr = _toBinary(dataUrl);
                }
                _preload.call(this, dataUrl);
              });
            }
          },
          loadFromImage: function(img, exact) {
            this.meta = img.meta;
            _blob = new File2(null, {
              name: img.name,
              size: img.size,
              type: img.type
            });
            _preload.call(this, exact ? _binStr = img.getAsBinaryString() : img.getAsDataURL());
          },
          getInfo: function() {
            var I = this.getRuntime(), info;
            if (!_imgInfo && _binStr && I.can("access_image_binary")) {
              _imgInfo = new ImageInfo(_binStr);
            }
            info = {
              width: _getImg().width || 0,
              height: _getImg().height || 0,
              type: _blob.type || Mime.getFileMime(_blob.name),
              size: _binStr && _binStr.length || _blob.size || 0,
              name: _blob.name || "",
              meta: null
            };
            if (_preserveHeaders) {
              info.meta = _imgInfo && _imgInfo.meta || this.meta || {};
              if (info.meta && info.meta.thumb && !(info.meta.thumb.data instanceof Blob)) {
                info.meta.thumb.data = new Blob(null, {
                  type: "image/jpeg",
                  data: info.meta.thumb.data
                });
              }
            }
            return info;
          },
          resize: function(rect, ratio, options) {
            var canvas = document.createElement("canvas");
            canvas.width = rect.width;
            canvas.height = rect.height;
            canvas.getContext("2d").drawImage(_getImg(), rect.x, rect.y, rect.width, rect.height, 0, 0, canvas.width, canvas.height);
            _canvas = ResizerCanvas.scale(canvas, ratio);
            _preserveHeaders = options.preserveHeaders;
            if (!_preserveHeaders) {
              var orientation = this.meta && this.meta.tiff && this.meta.tiff.Orientation || 1;
              _canvas = _rotateToOrientaion(_canvas, orientation);
            }
            this.width = _canvas.width;
            this.height = _canvas.height;
            _modified = true;
            this.trigger("Resize");
          },
          getAsCanvas: function() {
            if (!_canvas) {
              _canvas = _getCanvas();
            }
            _canvas.id = this.uid + "_canvas";
            return _canvas;
          },
          getAsBlob: function(type, quality) {
            if (type !== this.type) {
              _modified = true;
              return new File2(null, {
                name: _blob.name || "",
                type,
                data: me.getAsDataURL(type, quality)
              });
            }
            return new File2(null, {
              name: _blob.name || "",
              type,
              data: me.getAsBinaryString(type, quality)
            });
          },
          getAsDataURL: function(type) {
            var quality = arguments[1] || 90;
            if (!_modified) {
              return _img.src;
            }
            _getCanvas();
            if ("image/jpeg" !== type) {
              return _canvas.toDataURL("image/png");
            } else {
              try {
                return _canvas.toDataURL("image/jpeg", quality / 100);
              } catch (ex) {
                return _canvas.toDataURL("image/jpeg");
              }
            }
          },
          getAsBinaryString: function(type, quality) {
            if (!_modified) {
              if (!_binStr) {
                _binStr = _toBinary(me.getAsDataURL(type, quality));
              }
              return _binStr;
            }
            if ("image/jpeg" !== type) {
              _binStr = _toBinary(me.getAsDataURL(type, quality));
            } else {
              var dataUrl;
              if (!quality) {
                quality = 90;
              }
              _getCanvas();
              try {
                dataUrl = _canvas.toDataURL("image/jpeg", quality / 100);
              } catch (ex) {
                dataUrl = _canvas.toDataURL("image/jpeg");
              }
              _binStr = _toBinary(dataUrl);
              if (_imgInfo) {
                _binStr = _imgInfo.stripHeaders(_binStr);
                if (_preserveHeaders) {
                  if (_imgInfo.meta && _imgInfo.meta.exif) {
                    _imgInfo.setExif({
                      PixelXDimension: this.width,
                      PixelYDimension: this.height
                    });
                  }
                  _binStr = _imgInfo.writeHeaders(_binStr);
                }
                _imgInfo.purge();
                _imgInfo = null;
              }
            }
            _modified = false;
            return _binStr;
          },
          destroy: function() {
            me = null;
            _purge.call(this);
            this.getRuntime().getShim().removeInstance(this.uid);
          }
        });
        function _getImg() {
          if (!_canvas && !_img) {
            throw new x.ImageError(x.DOMException.INVALID_STATE_ERR);
          }
          return _canvas || _img;
        }
        function _getCanvas() {
          var canvas = _getImg();
          if (canvas.nodeName.toLowerCase() == "canvas") {
            return canvas;
          }
          _canvas = document.createElement("canvas");
          _canvas.width = canvas.width;
          _canvas.height = canvas.height;
          _canvas.getContext("2d").drawImage(canvas, 0, 0);
          return _canvas;
        }
        function _toBinary(str) {
          return Encode.atob(str.substring(str.indexOf("base64,") + 7));
        }
        function _toDataUrl(str, type) {
          return "data:" + (type || "") + ";base64," + Encode.btoa(str);
        }
        function _preload(str) {
          var comp = this;
          _img = new Image();
          _img.onerror = function() {
            _purge.call(this);
            comp.trigger("error", x.ImageError.WRONG_FORMAT);
          };
          _img.onload = function() {
            comp.trigger("load");
          };
          _img.src = str.substr(0, 5) == "data:" ? str : _toDataUrl(str, _blob.type);
        }
        function _readAsDataUrl(file, callback) {
          var comp = this, fr;
          if (window.FileReader) {
            fr = new FileReader();
            fr.onload = function() {
              callback.call(comp, this.result);
            };
            fr.onerror = function() {
              comp.trigger("error", x.ImageError.WRONG_FORMAT);
            };
            fr.readAsDataURL(file);
          } else {
            return callback.call(this, file.getAsDataURL());
          }
        }
        function _rotateToOrientaion(img, orientation) {
          var RADIANS = Math.PI / 180;
          var canvas = document.createElement("canvas");
          var ctx = canvas.getContext("2d");
          var width2 = img.width;
          var height2 = img.height;
          if (Basic.inArray(orientation, [5, 6, 7, 8]) > -1) {
            canvas.width = height2;
            canvas.height = width2;
          } else {
            canvas.width = width2;
            canvas.height = height2;
          }
          switch (orientation) {
            case 2:
              ctx.translate(width2, 0);
              ctx.scale(-1, 1);
              break;
            case 3:
              ctx.translate(width2, height2);
              ctx.rotate(180 * RADIANS);
              break;
            case 4:
              ctx.translate(0, height2);
              ctx.scale(1, -1);
              break;
            case 5:
              ctx.rotate(90 * RADIANS);
              ctx.scale(1, -1);
              break;
            case 6:
              ctx.rotate(90 * RADIANS);
              ctx.translate(0, -height2);
              break;
            case 7:
              ctx.rotate(90 * RADIANS);
              ctx.translate(width2, -height2);
              ctx.scale(-1, 1);
              break;
            case 8:
              ctx.rotate(-90 * RADIANS);
              ctx.translate(-width2, 0);
              break;
          }
          ctx.drawImage(img, 0, 0, width2, height2);
          return canvas;
        }
        function _purge() {
          if (_imgInfo) {
            _imgInfo.purge();
            _imgInfo = null;
          }
          _binStr = _img = _canvas = _blob = null;
          _modified = false;
        }
      }
      return extensions.Image = HTML5Image;
    });
    define("moxie/runtime/flash/Runtime", [
      "moxie/core/utils/Basic",
      "moxie/core/utils/Env",
      "moxie/core/utils/Dom",
      "moxie/core/Exceptions",
      "moxie/runtime/Runtime"
    ], function(Basic, Env, Dom, x, Runtime) {
      var type = "flash", extensions = {};
      function getShimVersion() {
        var version;
        try {
          version = navigator.plugins["Shockwave Flash"];
          version = version.description;
        } catch (e1) {
          try {
            version = new ActiveXObject("ShockwaveFlash.ShockwaveFlash").GetVariable("$version");
          } catch (e2) {
            version = "0.0";
          }
        }
        version = version.match(/\d+/g);
        return parseFloat(version[0] + "." + version[1]);
      }
      function removeSWF(id) {
        var obj = Dom.get(id);
        if (obj && obj.nodeName == "OBJECT") {
          if (Env.browser === "IE") {
            obj.style.display = "none";
            (function onInit() {
              if (obj.readyState == 4) {
                removeObjectInIE(id);
              } else {
                setTimeout(onInit, 10);
              }
            })();
          } else {
            obj.parentNode.removeChild(obj);
          }
        }
      }
      function removeObjectInIE(id) {
        var obj = Dom.get(id);
        if (obj) {
          for (var i in obj) {
            if (typeof obj[i] == "function") {
              obj[i] = null;
            }
          }
          obj.parentNode.removeChild(obj);
        }
      }
      function FlashRuntime(options) {
        var I = this, initTimer;
        options = Basic.extend({ swf_url: Env.swf_url }, options);
        Runtime.call(
          this,
          options,
          type,
          {
            access_binary: function(value) {
              return value && I.mode === "browser";
            },
            access_image_binary: function(value) {
              return value && I.mode === "browser";
            },
            display_media: Runtime.capTest(defined("moxie/image/Image")),
            do_cors: Runtime.capTrue,
            drag_and_drop: false,
            report_upload_progress: function() {
              return I.mode === "client";
            },
            resize_image: Runtime.capTrue,
            return_response_headers: false,
            return_response_type: function(responseType) {
              if (responseType === "json" && !!window.JSON) {
                return true;
              }
              return !Basic.arrayDiff(responseType, ["", "text", "document"]) || I.mode === "browser";
            },
            return_status_code: function(code) {
              return I.mode === "browser" || !Basic.arrayDiff(code, [200, 404]);
            },
            select_file: Runtime.capTrue,
            select_multiple: Runtime.capTrue,
            send_binary_string: function(value) {
              return value && I.mode === "browser";
            },
            send_browser_cookies: function(value) {
              return value && I.mode === "browser";
            },
            send_custom_headers: function(value) {
              return value && I.mode === "browser";
            },
            send_multipart: Runtime.capTrue,
            slice_blob: function(value) {
              return value && I.mode === "browser";
            },
            stream_upload: function(value) {
              return value && I.mode === "browser";
            },
            summon_file_dialog: false,
            upload_filesize: function(size) {
              return Basic.parseSizeStr(size) <= 2097152 || I.mode === "client";
            },
            use_http_method: function(methods) {
              return !Basic.arrayDiff(methods, ["GET", "POST"]);
            }
          },
          {
            access_binary: function(value) {
              return value ? "browser" : "client";
            },
            access_image_binary: function(value) {
              return value ? "browser" : "client";
            },
            report_upload_progress: function(value) {
              return value ? "browser" : "client";
            },
            return_response_type: function(responseType) {
              return Basic.arrayDiff(responseType, ["", "text", "json", "document"]) ? "browser" : ["client", "browser"];
            },
            return_status_code: function(code) {
              return Basic.arrayDiff(code, [200, 404]) ? "browser" : ["client", "browser"];
            },
            send_binary_string: function(value) {
              return value ? "browser" : "client";
            },
            send_browser_cookies: function(value) {
              return value ? "browser" : "client";
            },
            send_custom_headers: function(value) {
              return value ? "browser" : "client";
            },
            slice_blob: function(value) {
              return value ? "browser" : "client";
            },
            stream_upload: function(value) {
              return value ? "client" : "browser";
            },
            upload_filesize: function(size) {
              return Basic.parseSizeStr(size) >= 2097152 ? "client" : "browser";
            }
          },
          "client"
        );
        if (getShimVersion() < 11.3) {
          this.mode = false;
        }
        Basic.extend(
          this,
          {
            getShim: function() {
              return Dom.get(this.uid);
            },
            shimExec: function(component, action) {
              var args = [].slice.call(arguments, 2);
              return I.getShim().exec(this.uid, component, action, args);
            },
            init: function() {
              var html, el, container;
              container = this.getShimContainer();
              Basic.extend(container.style, {
                position: "absolute",
                top: "-8px",
                left: "-8px",
                width: "9px",
                height: "9px",
                overflow: "hidden"
              });
              html = '<object id="' + this.uid + '" type="application/x-shockwave-flash" data="' + options.swf_url + '" ';
              if (Env.browser === "IE") {
                html += 'classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" ';
              }
              html += 'width="100%" height="100%" style="outline:0"><param name="movie" value="' + options.swf_url + '" /><param name="flashvars" value="uid=' + escape(this.uid) + "&target=" + Runtime.getGlobalEventTarget() + '" /><param name="wmode" value="transparent" /><param name="allowscriptaccess" value="always" /></object>';
              if (Env.browser === "IE") {
                el = document.createElement("div");
                container.appendChild(el);
                el.outerHTML = html;
                el = container = null;
              } else {
                container.innerHTML = html;
              }
              initTimer = setTimeout(function() {
                if (I && !I.initialized) {
                  I.trigger("Error", new x.RuntimeError(x.RuntimeError.NOT_INIT_ERR));
                }
              }, 5e3);
            },
            destroy: function(destroy) {
              return function() {
                removeSWF(I.uid);
                destroy.call(I);
                clearTimeout(initTimer);
                options = initTimer = destroy = I = null;
              };
            }(this.destroy)
          },
          extensions
        );
      }
      Runtime.addConstructor(type, FlashRuntime);
      return extensions;
    });
    define("moxie/runtime/flash/file/Blob", [
      "moxie/runtime/flash/Runtime",
      "moxie/file/Blob"
    ], function(extensions, Blob) {
      var FlashBlob = {
        slice: function(blob, start, end, type) {
          var self = this.getRuntime();
          if (start < 0) {
            start = Math.max(blob.size + start, 0);
          } else if (start > 0) {
            start = Math.min(start, blob.size);
          }
          if (end < 0) {
            end = Math.max(blob.size + end, 0);
          } else if (end > 0) {
            end = Math.min(end, blob.size);
          }
          blob = self.shimExec.call(this, "Blob", "slice", start, end, type || "");
          if (blob) {
            blob = new Blob(self.uid, blob);
          }
          return blob;
        }
      };
      return extensions.Blob = FlashBlob;
    });
    define("moxie/runtime/flash/file/FileInput", [
      "moxie/runtime/flash/Runtime",
      "moxie/file/File",
      "moxie/core/utils/Dom",
      "moxie/core/utils/Basic"
    ], function(extensions, File2, Dom, Basic) {
      var FileInput = {
        init: function(options) {
          var comp = this, I = this.getRuntime();
          var browseButton = Dom.get(options.browse_button);
          if (browseButton) {
            browseButton.setAttribute("tabindex", -1);
            browseButton = null;
          }
          this.bind(
            "Change",
            function() {
              var files = I.shimExec.call(comp, "FileInput", "getFiles");
              comp.files = [];
              Basic.each(files, function(file) {
                comp.files.push(new File2(I.uid, file));
              });
            },
            999
          );
          this.getRuntime().shimExec.call(this, "FileInput", "init", {
            accept: options.accept,
            multiple: options.multiple
          });
          this.trigger("ready");
        }
      };
      return extensions.FileInput = FileInput;
    });
    define("moxie/runtime/flash/file/FileReader", [
      "moxie/runtime/flash/Runtime",
      "moxie/core/utils/Encode"
    ], function(extensions, Encode) {
      function _formatData(data, op) {
        switch (op) {
          case "readAsText":
            return Encode.atob(data, "utf8");
          case "readAsBinaryString":
            return Encode.atob(data);
          case "readAsDataURL":
            return data;
        }
        return null;
      }
      var FileReader2 = {
        read: function(op, blob) {
          var comp = this;
          comp.result = "";
          if (op === "readAsDataURL") {
            comp.result = "data:" + (blob.type || "") + ";base64,";
          }
          comp.bind(
            "Progress",
            function(e, data) {
              if (data) {
                comp.result += _formatData(data, op);
              }
            },
            999
          );
          return comp.getRuntime().shimExec.call(this, "FileReader", "readAsBase64", blob.uid);
        }
      };
      return extensions.FileReader = FileReader2;
    });
    define("moxie/runtime/flash/file/FileReaderSync", [
      "moxie/runtime/flash/Runtime",
      "moxie/core/utils/Encode"
    ], function(extensions, Encode) {
      function _formatData(data, op) {
        switch (op) {
          case "readAsText":
            return Encode.atob(data, "utf8");
          case "readAsBinaryString":
            return Encode.atob(data);
          case "readAsDataURL":
            return data;
        }
        return null;
      }
      var FileReaderSync = {
        read: function(op, blob) {
          var result, self = this.getRuntime();
          result = self.shimExec.call(this, "FileReaderSync", "readAsBase64", blob.uid);
          if (!result) {
            return null;
          }
          if (op === "readAsDataURL") {
            result = "data:" + (blob.type || "") + ";base64," + result;
          }
          return _formatData(result, op, blob.type);
        }
      };
      return extensions.FileReaderSync = FileReaderSync;
    });
    define("moxie/runtime/flash/runtime/Transporter", [
      "moxie/runtime/flash/Runtime",
      "moxie/file/Blob"
    ], function(extensions, Blob) {
      var Transporter = {
        getAsBlob: function(type) {
          var self = this.getRuntime(), blob = self.shimExec.call(this, "Transporter", "getAsBlob", type);
          if (blob) {
            return new Blob(self.uid, blob);
          }
          return null;
        }
      };
      return extensions.Transporter = Transporter;
    });
    define("moxie/runtime/flash/xhr/XMLHttpRequest", [
      "moxie/runtime/flash/Runtime",
      "moxie/core/utils/Basic",
      "moxie/file/Blob",
      "moxie/file/File",
      "moxie/file/FileReaderSync",
      "moxie/runtime/flash/file/FileReaderSync",
      "moxie/xhr/FormData",
      "moxie/runtime/Transporter",
      "moxie/runtime/flash/runtime/Transporter"
    ], function(extensions, Basic, Blob, File2, FileReaderSync, FileReaderSyncFlash, FormData, Transporter, TransporterFlash) {
      var XMLHttpRequest2 = {
        send: function(meta, data) {
          var target = this, self = target.getRuntime();
          function send() {
            meta.transport = self.mode;
            self.shimExec.call(target, "XMLHttpRequest", "send", meta, data);
          }
          function appendBlob(name, blob2) {
            self.shimExec.call(target, "XMLHttpRequest", "appendBlob", name, blob2.uid);
            data = null;
            send();
          }
          function attachBlob(blob2, cb) {
            var tr = new Transporter();
            tr.bind("TransportingComplete", function() {
              cb(this.result);
            });
            tr.transport(blob2.getSource(), blob2.type, {
              ruid: self.uid
            });
          }
          if (!Basic.isEmptyObj(meta.headers)) {
            Basic.each(meta.headers, function(value, header) {
              self.shimExec.call(target, "XMLHttpRequest", "setRequestHeader", header, value.toString());
            });
          }
          if (data instanceof FormData) {
            var blobField;
            data.each(function(value, name) {
              if (value instanceof Blob) {
                blobField = name;
              } else {
                self.shimExec.call(target, "XMLHttpRequest", "append", name, value);
              }
            });
            if (!data.hasBlob()) {
              data = null;
              send();
            } else {
              var blob = data.getBlob();
              if (blob.isDetached()) {
                attachBlob(blob, function(attachedBlob) {
                  blob.destroy();
                  appendBlob(blobField, attachedBlob);
                });
              } else {
                appendBlob(blobField, blob);
              }
            }
          } else if (data instanceof Blob) {
            if (data.isDetached()) {
              attachBlob(data, function(attachedBlob) {
                data.destroy();
                data = attachedBlob.uid;
                send();
              });
            } else {
              data = data.uid;
              send();
            }
          } else {
            send();
          }
        },
        getResponse: function(responseType) {
          var frs, blob, self = this.getRuntime();
          blob = self.shimExec.call(this, "XMLHttpRequest", "getResponseAsBlob");
          if (blob) {
            blob = new File2(self.uid, blob);
            if ("blob" === responseType) {
              return blob;
            }
            try {
              frs = new FileReaderSync();
              if (!!~Basic.inArray(responseType, ["", "text"])) {
                return frs.readAsText(blob);
              } else if ("json" === responseType && !!window.JSON) {
                return JSON.parse(frs.readAsText(blob));
              }
            } finally {
              blob.destroy();
            }
          }
          return null;
        },
        abort: function(upload_complete_flag) {
          var self = this.getRuntime();
          self.shimExec.call(this, "XMLHttpRequest", "abort");
          this.dispatchEvent("readystatechange");
          this.dispatchEvent("abort");
        }
      };
      return extensions.XMLHttpRequest = XMLHttpRequest2;
    });
    define("moxie/runtime/flash/image/Image", [
      "moxie/runtime/flash/Runtime",
      "moxie/core/utils/Basic",
      "moxie/runtime/Transporter",
      "moxie/file/Blob",
      "moxie/file/FileReaderSync"
    ], function(extensions, Basic, Transporter, Blob, FileReaderSync) {
      var Image2 = {
        loadFromBlob: function(blob) {
          var comp = this, self = comp.getRuntime();
          function exec(srcBlob) {
            self.shimExec.call(comp, "Image", "loadFromBlob", srcBlob.uid);
            comp = self = null;
          }
          if (blob.isDetached()) {
            var tr = new Transporter();
            tr.bind("TransportingComplete", function() {
              exec(tr.result.getSource());
            });
            tr.transport(blob.getSource(), blob.type, { ruid: self.uid });
          } else {
            exec(blob.getSource());
          }
        },
        loadFromImage: function(img) {
          var self = this.getRuntime();
          return self.shimExec.call(this, "Image", "loadFromImage", img.uid);
        },
        getInfo: function() {
          var self = this.getRuntime(), info = self.shimExec.call(this, "Image", "getInfo");
          if (info.meta && info.meta.thumb && info.meta.thumb.data && !(self.meta.thumb.data instanceof Blob)) {
            info.meta.thumb.data = new Blob(self.uid, info.meta.thumb.data);
          }
          return info;
        },
        getAsBlob: function(type, quality) {
          var self = this.getRuntime(), blob = self.shimExec.call(this, "Image", "getAsBlob", type, quality);
          if (blob) {
            return new Blob(self.uid, blob);
          }
          return null;
        },
        getAsDataURL: function() {
          var self = this.getRuntime(), blob = self.Image.getAsBlob.apply(this, arguments), frs;
          if (!blob) {
            return null;
          }
          frs = new FileReaderSync();
          return frs.readAsDataURL(blob);
        }
      };
      return extensions.Image = Image2;
    });
    define("moxie/runtime/silverlight/Runtime", [
      "moxie/core/utils/Basic",
      "moxie/core/utils/Env",
      "moxie/core/utils/Dom",
      "moxie/core/Exceptions",
      "moxie/runtime/Runtime"
    ], function(Basic, Env, Dom, x, Runtime) {
      var type = "silverlight", extensions = {};
      function isInstalled(version) {
        var isVersionSupported = false, control = null, actualVer, actualVerArray, reqVerArray, requiredVersionPart, actualVersionPart, index = 0;
        try {
          try {
            control = new ActiveXObject("AgControl.AgControl");
            if (control.IsVersionSupported(version)) {
              isVersionSupported = true;
            }
            control = null;
          } catch (e) {
            var plugin = navigator.plugins["Silverlight Plug-In"];
            if (plugin) {
              actualVer = plugin.description;
              if (actualVer === "1.0.30226.2") {
                actualVer = "2.0.30226.2";
              }
              actualVerArray = actualVer.split(".");
              while (actualVerArray.length > 3) {
                actualVerArray.pop();
              }
              while (actualVerArray.length < 4) {
                actualVerArray.push(0);
              }
              reqVerArray = version.split(".");
              while (reqVerArray.length > 4) {
                reqVerArray.pop();
              }
              do {
                requiredVersionPart = parseInt(reqVerArray[index], 10);
                actualVersionPart = parseInt(actualVerArray[index], 10);
                index++;
              } while (index < reqVerArray.length && requiredVersionPart === actualVersionPart);
              if (requiredVersionPart <= actualVersionPart && !isNaN(requiredVersionPart)) {
                isVersionSupported = true;
              }
            }
          }
        } catch (e2) {
          isVersionSupported = false;
        }
        return isVersionSupported;
      }
      function SilverlightRuntime(options) {
        var I = this, initTimer;
        options = Basic.extend({ xap_url: Env.xap_url }, options);
        Runtime.call(
          this,
          options,
          type,
          {
            access_binary: Runtime.capTrue,
            access_image_binary: Runtime.capTrue,
            display_media: Runtime.capTest(defined("moxie/image/Image")),
            do_cors: Runtime.capTrue,
            drag_and_drop: false,
            report_upload_progress: Runtime.capTrue,
            resize_image: Runtime.capTrue,
            return_response_headers: function(value) {
              return value && I.mode === "client";
            },
            return_response_type: function(responseType) {
              if (responseType !== "json") {
                return true;
              } else {
                return !!window.JSON;
              }
            },
            return_status_code: function(code) {
              return I.mode === "client" || !Basic.arrayDiff(code, [200, 404]);
            },
            select_file: Runtime.capTrue,
            select_multiple: Runtime.capTrue,
            send_binary_string: Runtime.capTrue,
            send_browser_cookies: function(value) {
              return value && I.mode === "browser";
            },
            send_custom_headers: function(value) {
              return value && I.mode === "client";
            },
            send_multipart: Runtime.capTrue,
            slice_blob: Runtime.capTrue,
            stream_upload: true,
            summon_file_dialog: false,
            upload_filesize: Runtime.capTrue,
            use_http_method: function(methods) {
              return I.mode === "client" || !Basic.arrayDiff(methods, ["GET", "POST"]);
            }
          },
          {
            return_response_headers: function(value) {
              return value ? "client" : "browser";
            },
            return_status_code: function(code) {
              return Basic.arrayDiff(code, [200, 404]) ? "client" : ["client", "browser"];
            },
            send_browser_cookies: function(value) {
              return value ? "browser" : "client";
            },
            send_custom_headers: function(value) {
              return value ? "client" : "browser";
            },
            use_http_method: function(methods) {
              return Basic.arrayDiff(methods, ["GET", "POST"]) ? "client" : ["client", "browser"];
            }
          }
        );
        if (!isInstalled("2.0.31005.0") || Env.browser === "Opera") {
          this.mode = false;
        }
        Basic.extend(
          this,
          {
            getShim: function() {
              return Dom.get(this.uid).content.Moxie;
            },
            shimExec: function(component, action) {
              var args = [].slice.call(arguments, 2);
              return I.getShim().exec(this.uid, component, action, args);
            },
            init: function() {
              var container;
              container = this.getShimContainer();
              container.innerHTML = '<object id="' + this.uid + '" data="data:application/x-silverlight," type="application/x-silverlight-2" width="100%" height="100%" style="outline:none;"><param name="source" value="' + options.xap_url + '"/><param name="background" value="Transparent"/><param name="windowless" value="true"/><param name="enablehtmlaccess" value="true"/><param name="initParams" value="uid=' + this.uid + ",target=" + Runtime.getGlobalEventTarget() + '"/></object>';
              initTimer = setTimeout(
                function() {
                  if (I && !I.initialized) {
                    I.trigger("Error", new x.RuntimeError(x.RuntimeError.NOT_INIT_ERR));
                  }
                },
                Env.OS !== "Windows" ? 1e4 : 5e3
              );
            },
            destroy: function(destroy) {
              return function() {
                destroy.call(I);
                clearTimeout(initTimer);
                options = initTimer = destroy = I = null;
              };
            }(this.destroy)
          },
          extensions
        );
      }
      Runtime.addConstructor(type, SilverlightRuntime);
      return extensions;
    });
    define("moxie/runtime/silverlight/file/Blob", [
      "moxie/runtime/silverlight/Runtime",
      "moxie/core/utils/Basic",
      "moxie/runtime/flash/file/Blob"
    ], function(extensions, Basic, Blob) {
      return extensions.Blob = Basic.extend({}, Blob);
    });
    define("moxie/runtime/silverlight/file/FileInput", [
      "moxie/runtime/silverlight/Runtime",
      "moxie/file/File",
      "moxie/core/utils/Dom",
      "moxie/core/utils/Basic"
    ], function(extensions, File2, Dom, Basic) {
      function toFilters(accept) {
        var filter = "";
        for (var i = 0; i < accept.length; i++) {
          filter += (filter !== "" ? "|" : "") + accept[i].title + " | *." + accept[i].extensions.replace(/,/g, ";*.");
        }
        return filter;
      }
      var FileInput = {
        init: function(options) {
          var comp = this, I = this.getRuntime();
          var browseButton = Dom.get(options.browse_button);
          if (browseButton) {
            browseButton.setAttribute("tabindex", -1);
            browseButton = null;
          }
          this.bind(
            "Change",
            function() {
              var files = I.shimExec.call(comp, "FileInput", "getFiles");
              comp.files = [];
              Basic.each(files, function(file) {
                comp.files.push(new File2(I.uid, file));
              });
            },
            999
          );
          I.shimExec.call(this, "FileInput", "init", toFilters(options.accept), options.multiple);
          this.trigger("ready");
        },
        setOption: function(name, value) {
          if (name == "accept") {
            value = toFilters(value);
          }
          this.getRuntime().shimExec.call(this, "FileInput", "setOption", name, value);
        }
      };
      return extensions.FileInput = FileInput;
    });
    define("moxie/runtime/silverlight/file/FileDrop", [
      "moxie/runtime/silverlight/Runtime",
      "moxie/core/utils/Dom",
      "moxie/core/utils/Events"
    ], function(extensions, Dom, Events) {
      var FileDrop = {
        init: function() {
          var comp = this, self = comp.getRuntime(), dropZone;
          dropZone = self.getShimContainer();
          Events.addEvent(
            dropZone,
            "dragover",
            function(e) {
              e.preventDefault();
              e.stopPropagation();
              e.dataTransfer.dropEffect = "copy";
            },
            comp.uid
          );
          Events.addEvent(
            dropZone,
            "dragenter",
            function(e) {
              e.preventDefault();
              var flag = Dom.get(self.uid).dragEnter(e);
              if (flag) {
                e.stopPropagation();
              }
            },
            comp.uid
          );
          Events.addEvent(
            dropZone,
            "drop",
            function(e) {
              e.preventDefault();
              var flag = Dom.get(self.uid).dragDrop(e);
              if (flag) {
                e.stopPropagation();
              }
            },
            comp.uid
          );
          return self.shimExec.call(this, "FileDrop", "init");
        }
      };
      return extensions.FileDrop = FileDrop;
    });
    define("moxie/runtime/silverlight/file/FileReader", [
      "moxie/runtime/silverlight/Runtime",
      "moxie/core/utils/Basic",
      "moxie/runtime/flash/file/FileReader"
    ], function(extensions, Basic, FileReader2) {
      return extensions.FileReader = Basic.extend({}, FileReader2);
    });
    define("moxie/runtime/silverlight/file/FileReaderSync", [
      "moxie/runtime/silverlight/Runtime",
      "moxie/core/utils/Basic",
      "moxie/runtime/flash/file/FileReaderSync"
    ], function(extensions, Basic, FileReaderSync) {
      return extensions.FileReaderSync = Basic.extend({}, FileReaderSync);
    });
    define("moxie/runtime/silverlight/runtime/Transporter", [
      "moxie/runtime/silverlight/Runtime",
      "moxie/core/utils/Basic",
      "moxie/runtime/flash/runtime/Transporter"
    ], function(extensions, Basic, Transporter) {
      return extensions.Transporter = Basic.extend({}, Transporter);
    });
    define("moxie/runtime/silverlight/xhr/XMLHttpRequest", [
      "moxie/runtime/silverlight/Runtime",
      "moxie/core/utils/Basic",
      "moxie/runtime/flash/xhr/XMLHttpRequest",
      "moxie/runtime/silverlight/file/FileReaderSync",
      "moxie/runtime/silverlight/runtime/Transporter"
    ], function(extensions, Basic, XMLHttpRequest2, FileReaderSyncSilverlight, TransporterSilverlight) {
      return extensions.XMLHttpRequest = Basic.extend({}, XMLHttpRequest2);
    });
    define("moxie/runtime/silverlight/image/Image", [
      "moxie/runtime/silverlight/Runtime",
      "moxie/core/utils/Basic",
      "moxie/file/Blob",
      "moxie/runtime/flash/image/Image"
    ], function(extensions, Basic, Blob, Image2) {
      return extensions.Image = Basic.extend({}, Image2, {
        getInfo: function() {
          var self = this.getRuntime(), grps = ["tiff", "exif", "gps", "thumb"], info = { meta: {} }, rawInfo = self.shimExec.call(this, "Image", "getInfo");
          if (rawInfo.meta) {
            Basic.each(grps, function(grp) {
              var meta = rawInfo.meta[grp], tag, i, length, value;
              if (meta && meta.keys) {
                info.meta[grp] = {};
                for (i = 0, length = meta.keys.length; i < length; i++) {
                  tag = meta.keys[i];
                  value = meta[tag];
                  if (value) {
                    if (/^(\d|[1-9]\d+)$/.test(value)) {
                      value = parseInt(value, 10);
                    } else if (/^\d*\.\d+$/.test(value)) {
                      value = parseFloat(value);
                    }
                    info.meta[grp][tag] = value;
                  }
                }
              }
            });
            if (info.meta && info.meta.thumb && info.meta.thumb.data && !(self.meta.thumb.data instanceof Blob)) {
              info.meta.thumb.data = new Blob(self.uid, info.meta.thumb.data);
            }
          }
          info.width = parseInt(rawInfo.width, 10);
          info.height = parseInt(rawInfo.height, 10);
          info.size = parseInt(rawInfo.size, 10);
          info.type = rawInfo.type;
          info.name = rawInfo.name;
          return info;
        },
        resize: function(rect, ratio, opts) {
          this.getRuntime().shimExec.call(
            this,
            "Image",
            "resize",
            rect.x,
            rect.y,
            rect.width,
            rect.height,
            ratio,
            opts.preserveHeaders,
            opts.resample
          );
        }
      });
    });
    define("moxie/runtime/html4/Runtime", [
      "moxie/core/utils/Basic",
      "moxie/core/Exceptions",
      "moxie/runtime/Runtime",
      "moxie/core/utils/Env"
    ], function(Basic, x, Runtime, Env) {
      var type = "html4", extensions = {};
      function Html4Runtime(options) {
        var I = this, Test = Runtime.capTest, True = Runtime.capTrue;
        Runtime.call(this, options, type, {
          access_binary: Test(window.FileReader || window.File && File.getAsDataURL),
          access_image_binary: false,
          display_media: Test(
            (Env.can("create_canvas") || Env.can("use_data_uri_over32kb")) && defined("moxie/image/Image")
          ),
          do_cors: false,
          drag_and_drop: false,
          filter_by_extension: Test(
            function() {
              return !(Env.browser === "Chrome" && Env.verComp(Env.version, 28, "<") || Env.browser === "IE" && Env.verComp(Env.version, 10, "<") || Env.browser === "Safari" && Env.verComp(Env.version, 7, "<") || Env.browser === "Firefox" && Env.verComp(Env.version, 37, "<"));
            }()
          ),
          resize_image: function() {
            return extensions.Image && I.can("access_binary") && Env.can("create_canvas");
          },
          report_upload_progress: false,
          return_response_headers: false,
          return_response_type: function(responseType) {
            if (responseType === "json" && !!window.JSON) {
              return true;
            }
            return !!~Basic.inArray(responseType, ["text", "document", ""]);
          },
          return_status_code: function(code) {
            return !Basic.arrayDiff(code, [200, 404]);
          },
          select_file: function() {
            return Env.can("use_fileinput");
          },
          select_multiple: false,
          send_binary_string: false,
          send_custom_headers: false,
          send_multipart: true,
          slice_blob: false,
          stream_upload: function() {
            return I.can("select_file");
          },
          summon_file_dialog: function() {
            return I.can("select_file") && !(Env.browser === "Firefox" && Env.verComp(Env.version, 4, "<") || Env.browser === "Opera" && Env.verComp(Env.version, 12, "<") || Env.browser === "IE" && Env.verComp(Env.version, 10, "<"));
          },
          upload_filesize: True,
          use_http_method: function(methods) {
            return !Basic.arrayDiff(methods, ["GET", "POST"]);
          }
        });
        Basic.extend(this, {
          init: function() {
            this.trigger("Init");
          },
          destroy: function(destroy) {
            return function() {
              destroy.call(I);
              destroy = I = null;
            };
          }(this.destroy)
        });
        Basic.extend(this.getShim(), extensions);
      }
      Runtime.addConstructor(type, Html4Runtime);
      return extensions;
    });
    define("moxie/runtime/html4/file/FileInput", [
      "moxie/runtime/html4/Runtime",
      "moxie/file/File",
      "moxie/core/utils/Basic",
      "moxie/core/utils/Dom",
      "moxie/core/utils/Events",
      "moxie/core/utils/Mime",
      "moxie/core/utils/Env"
    ], function(extensions, File2, Basic, Dom, Events, Mime, Env) {
      function FileInput() {
        var _uid, _mimes = [], _options, _browseBtnZIndex;
        function addInput() {
          var comp = this, I = comp.getRuntime(), shimContainer, browseButton, currForm, form, input, uid;
          uid = Basic.guid("uid_");
          shimContainer = I.getShimContainer();
          if (_uid) {
            currForm = Dom.get(_uid + "_form");
            if (currForm) {
              Basic.extend(currForm.style, { top: "100%" });
              currForm.firstChild.setAttribute("tabindex", -1);
            }
          }
          form = document.createElement("form");
          form.setAttribute("id", uid + "_form");
          form.setAttribute("method", "post");
          form.setAttribute("enctype", "multipart/form-data");
          form.setAttribute("encoding", "multipart/form-data");
          Basic.extend(form.style, {
            overflow: "hidden",
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%"
          });
          input = document.createElement("input");
          input.setAttribute("id", uid);
          input.setAttribute("type", "file");
          input.setAttribute("accept", _mimes.join(","));
          if (I.can("summon_file_dialog")) {
            input.setAttribute("tabindex", -1);
          }
          Basic.extend(input.style, {
            fontSize: "999px",
            opacity: 0
          });
          form.appendChild(input);
          shimContainer.appendChild(form);
          Basic.extend(input.style, {
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%"
          });
          if (Env.browser === "IE" && Env.verComp(Env.version, 10, "<")) {
            Basic.extend(input.style, {
              filter: "progid:DXImageTransform.Microsoft.Alpha(opacity=0)"
            });
          }
          input.onchange = function() {
            var file;
            if (!this.value) {
              return;
            }
            if (this.files) {
              file = this.files[0];
            } else {
              file = {
                name: this.value
              };
            }
            file = new File2(I.uid, file);
            this.onchange = function() {
            };
            addInput.call(comp);
            comp.files = [file];
            input.setAttribute("id", file.uid);
            form.setAttribute("id", file.uid + "_form");
            comp.trigger("change");
            input = form = null;
          };
          if (I.can("summon_file_dialog")) {
            browseButton = Dom.get(_options.browse_button);
            Events.removeEvent(browseButton, "click", comp.uid);
            Events.addEvent(
              browseButton,
              "click",
              function(e) {
                if (input && !input.disabled) {
                  input.click();
                }
                e.preventDefault();
              },
              comp.uid
            );
          }
          _uid = uid;
          shimContainer = currForm = browseButton = null;
        }
        Basic.extend(this, {
          init: function(options) {
            var comp = this, I = comp.getRuntime(), shimContainer;
            _options = options;
            _mimes = Mime.extList2mimes(options.accept, I.can("filter_by_extension"));
            shimContainer = I.getShimContainer();
            (function() {
              var browseButton, zIndex, top;
              browseButton = Dom.get(options.browse_button);
              _browseBtnZIndex = Dom.getStyle(browseButton, "z-index") || "auto";
              if (I.can("summon_file_dialog")) {
                if (Dom.getStyle(browseButton, "position") === "static") {
                  browseButton.style.position = "relative";
                }
                comp.bind("Refresh", function() {
                  zIndex = parseInt(_browseBtnZIndex, 10) || 1;
                  Dom.get(_options.browse_button).style.zIndex = zIndex;
                  this.getRuntime().getShimContainer().style.zIndex = zIndex - 1;
                });
              } else {
                browseButton.setAttribute("tabindex", -1);
              }
              top = I.can("summon_file_dialog") ? browseButton : shimContainer;
              Events.addEvent(
                top,
                "mouseover",
                function() {
                  comp.trigger("mouseenter");
                },
                comp.uid
              );
              Events.addEvent(
                top,
                "mouseout",
                function() {
                  comp.trigger("mouseleave");
                },
                comp.uid
              );
              Events.addEvent(
                top,
                "mousedown",
                function() {
                  comp.trigger("mousedown");
                },
                comp.uid
              );
              Events.addEvent(
                Dom.get(options.container),
                "mouseup",
                function() {
                  comp.trigger("mouseup");
                },
                comp.uid
              );
              browseButton = null;
            })();
            addInput.call(this);
            shimContainer = null;
            comp.trigger({
              type: "ready",
              async: true
            });
          },
          setOption: function(name, value) {
            var I = this.getRuntime();
            var input;
            if (name == "accept") {
              _mimes = value.mimes || Mime.extList2mimes(value, I.can("filter_by_extension"));
            }
            input = Dom.get(_uid);
            if (input) {
              input.setAttribute("accept", _mimes.join(","));
            }
          },
          disable: function(state) {
            var input;
            if (input = Dom.get(_uid)) {
              input.disabled = !!state;
            }
          },
          destroy: function() {
            var I = this.getRuntime(), shim = I.getShim(), shimContainer = I.getShimContainer(), container = _options && Dom.get(_options.container), browseButton = _options && Dom.get(_options.browse_button);
            if (container) {
              Events.removeAllEvents(container, this.uid);
            }
            if (browseButton) {
              Events.removeAllEvents(browseButton, this.uid);
              browseButton.style.zIndex = _browseBtnZIndex;
            }
            if (shimContainer) {
              Events.removeAllEvents(shimContainer, this.uid);
              shimContainer.innerHTML = "";
            }
            shim.removeInstance(this.uid);
            _uid = _mimes = _options = shimContainer = container = browseButton = shim = null;
          }
        });
      }
      return extensions.FileInput = FileInput;
    });
    define("moxie/runtime/html4/file/FileReader", [
      "moxie/runtime/html4/Runtime",
      "moxie/runtime/html5/file/FileReader"
    ], function(extensions, FileReader2) {
      return extensions.FileReader = FileReader2;
    });
    define("moxie/runtime/html4/xhr/XMLHttpRequest", [
      "moxie/runtime/html4/Runtime",
      "moxie/core/utils/Basic",
      "moxie/core/utils/Dom",
      "moxie/core/utils/Url",
      "moxie/core/Exceptions",
      "moxie/core/utils/Events",
      "moxie/file/Blob",
      "moxie/xhr/FormData"
    ], function(extensions, Basic, Dom, Url, x, Events, Blob, FormData) {
      function XMLHttpRequest2() {
        var _status, _response, _iframe;
        function cleanup(cb) {
          var target = this, uid, form, inputs, i, hasFile = false;
          if (!_iframe) {
            return;
          }
          uid = _iframe.id.replace(/_iframe$/, "");
          form = Dom.get(uid + "_form");
          if (form) {
            inputs = form.getElementsByTagName("input");
            i = inputs.length;
            while (i--) {
              switch (inputs[i].getAttribute("type")) {
                case "hidden":
                  inputs[i].parentNode.removeChild(inputs[i]);
                  break;
                case "file":
                  hasFile = true;
                  break;
              }
            }
            inputs = [];
            if (!hasFile) {
              form.parentNode.removeChild(form);
            }
            form = null;
          }
          setTimeout(function() {
            Events.removeEvent(_iframe, "load", target.uid);
            if (_iframe.parentNode) {
              _iframe.parentNode.removeChild(_iframe);
            }
            var shimContainer = target.getRuntime().getShimContainer();
            if (!shimContainer.children.length) {
              shimContainer.parentNode.removeChild(shimContainer);
            }
            shimContainer = _iframe = null;
            cb();
          }, 1);
        }
        Basic.extend(this, {
          send: function(meta, data) {
            var target = this, I = target.getRuntime(), uid, form, input, blob;
            _status = _response = null;
            function createIframe() {
              var container = I.getShimContainer() || document.body, temp = document.createElement("div");
              temp.innerHTML = '<iframe id="' + uid + '_iframe" name="' + uid + '_iframe" src="javascript:&quot;&quot;" style="display:none"></iframe>';
              _iframe = temp.firstChild;
              container.appendChild(_iframe);
              Events.addEvent(
                _iframe,
                "load",
                function() {
                  var el;
                  try {
                    el = _iframe.contentWindow.document || _iframe.contentDocument || window.frames[_iframe.id].document;
                    if (/^4(0[0-9]|1[0-7]|2[2346])\s/.test(el.title)) {
                      _status = el.title.replace(/^(\d+).*$/, "$1");
                    } else {
                      _status = 200;
                      _response = Basic.trim(el.body.innerHTML);
                      target.trigger({
                        type: "progress",
                        loaded: _response.length,
                        total: _response.length
                      });
                      if (blob) {
                        target.trigger({
                          type: "uploadprogress",
                          loaded: blob.size || 1025,
                          total: blob.size || 1025
                        });
                      }
                    }
                  } catch (ex) {
                    if (Url.hasSameOrigin(meta.url)) {
                      _status = 404;
                    } else {
                      cleanup.call(target, function() {
                        target.trigger("error");
                      });
                      return;
                    }
                  }
                  cleanup.call(target, function() {
                    target.trigger("load");
                  });
                },
                target.uid
              );
            }
            if (data instanceof FormData && data.hasBlob()) {
              blob = data.getBlob();
              uid = blob.uid;
              input = Dom.get(uid);
              form = Dom.get(uid + "_form");
              if (!form) {
                throw new x.DOMException(x.DOMException.NOT_FOUND_ERR);
              }
            } else {
              uid = Basic.guid("uid_");
              form = document.createElement("form");
              form.setAttribute("id", uid + "_form");
              form.setAttribute("method", meta.method);
              form.setAttribute("enctype", "multipart/form-data");
              form.setAttribute("encoding", "multipart/form-data");
              I.getShimContainer().appendChild(form);
            }
            form.setAttribute("target", uid + "_iframe");
            if (data instanceof FormData) {
              data.each(function(value, name) {
                if (value instanceof Blob) {
                  if (input) {
                    input.setAttribute("name", name);
                  }
                } else {
                  var hidden = document.createElement("input");
                  Basic.extend(hidden, {
                    type: "hidden",
                    name,
                    value
                  });
                  if (input) {
                    form.insertBefore(hidden, input);
                  } else {
                    form.appendChild(hidden);
                  }
                }
              });
            }
            form.setAttribute("action", meta.url);
            createIframe();
            form.submit();
            target.trigger("loadstart");
          },
          getStatus: function() {
            return _status;
          },
          getResponse: function(responseType) {
            if ("json" === responseType) {
              if (Basic.typeOf(_response) === "string" && !!window.JSON) {
                try {
                  return JSON.parse(_response.replace(/^\s*<pre[^>]*>/, "").replace(/<\/pre>\s*$/, ""));
                } catch (ex) {
                  return null;
                }
              }
            }
            return _response;
          },
          abort: function() {
            var target = this;
            if (_iframe && _iframe.contentWindow) {
              if (_iframe.contentWindow.stop) {
                _iframe.contentWindow.stop();
              } else if (_iframe.contentWindow.document.execCommand) {
                _iframe.contentWindow.document.execCommand("Stop");
              } else {
                _iframe.src = "about:blank";
              }
            }
            cleanup.call(this, function() {
              target.dispatchEvent("abort");
            });
          },
          destroy: function() {
            this.getRuntime().getShim().removeInstance(this.uid);
          }
        });
      }
      return extensions.XMLHttpRequest = XMLHttpRequest2;
    });
    define("moxie/runtime/html4/image/Image", [
      "moxie/runtime/html4/Runtime",
      "moxie/runtime/html5/image/Image"
    ], function(extensions, Image2) {
      return extensions.Image = Image2;
    });
    expose([
      "moxie/core/utils/Basic",
      "moxie/core/utils/Encode",
      "moxie/core/utils/Env",
      "moxie/core/Exceptions",
      "moxie/core/utils/Dom",
      "moxie/core/EventTarget",
      "moxie/runtime/Runtime",
      "moxie/runtime/RuntimeClient",
      "moxie/file/Blob",
      "moxie/core/I18n",
      "moxie/core/utils/Mime",
      "moxie/file/FileInput",
      "moxie/file/File",
      "moxie/file/FileDrop",
      "moxie/file/FileReader",
      "moxie/core/utils/Url",
      "moxie/runtime/RuntimeTarget",
      "moxie/xhr/FormData",
      "moxie/xhr/XMLHttpRequest",
      "moxie/image/Image",
      "moxie/core/utils/Events",
      "moxie/runtime/html5/image/ResizerCanvas"
    ]);
  })(this);
});
var plupload = function(global, factory) {
  var extract = function() {
    var ctx = {};
    factory.apply(ctx, arguments);
    return ctx.plupload;
  };
  return extract(moxie);
}(window, function(moxie2) {
  (function(exports, o, undef) {
    var delay = window.setTimeout;
    var fileFilters = {};
    var u = o.core.utils;
    var Runtime = o.runtime.Runtime;
    function normalizeCaps(settings) {
      var features = settings.required_features, caps = {};
      function resolve(feature, value, strict) {
        var map = {
          chunks: "slice_blob",
          jpgresize: "send_binary_string",
          pngresize: "send_binary_string",
          progress: "report_upload_progress",
          multi_selection: "select_multiple",
          dragdrop: "drag_and_drop",
          drop_element: "drag_and_drop",
          headers: "send_custom_headers",
          urlstream_upload: "send_binary_string",
          canSendBinary: "send_binary",
          triggerDialog: "summon_file_dialog"
        };
        if (map[feature]) {
          caps[map[feature]] = value;
        } else if (!strict) {
          caps[feature] = value;
        }
      }
      if (typeof features === "string") {
        plupload2.each(features.split(/\s*,\s*/), function(feature) {
          resolve(feature, true);
        });
      } else if (typeof features === "object") {
        plupload2.each(features, function(value, feature) {
          resolve(feature, value);
        });
      } else if (features === true) {
        if (settings.chunk_size && settings.chunk_size > 0) {
          caps.slice_blob = true;
        }
        if (!plupload2.isEmptyObj(settings.resize) || settings.multipart === false) {
          caps.send_binary_string = true;
        }
        if (settings.http_method) {
          caps.use_http_method = settings.http_method;
        }
        plupload2.each(settings, function(value, feature) {
          resolve(feature, !!value, true);
        });
      }
      return caps;
    }
    var plupload2 = {
      VERSION: "2.3.6",
      STOPPED: 1,
      STARTED: 2,
      QUEUED: 1,
      UPLOADING: 2,
      FAILED: 4,
      DONE: 5,
      GENERIC_ERROR: -100,
      HTTP_ERROR: -200,
      IO_ERROR: -300,
      SECURITY_ERROR: -400,
      INIT_ERROR: -500,
      FILE_SIZE_ERROR: -600,
      FILE_EXTENSION_ERROR: -601,
      FILE_DUPLICATE_ERROR: -602,
      IMAGE_FORMAT_ERROR: -700,
      MEMORY_ERROR: -701,
      IMAGE_DIMENSIONS_ERROR: -702,
      moxie: o,
      mimeTypes: u.Mime.mimes,
      ua: u.Env,
      typeOf: u.Basic.typeOf,
      extend: u.Basic.extend,
      guid: u.Basic.guid,
      getAll: function get(ids) {
        var els = [], el;
        if (plupload2.typeOf(ids) !== "array") {
          ids = [ids];
        }
        var i = ids.length;
        while (i--) {
          el = plupload2.get(ids[i]);
          if (el) {
            els.push(el);
          }
        }
        return els.length ? els : null;
      },
      get: u.Dom.get,
      each: u.Basic.each,
      getPos: u.Dom.getPos,
      getSize: u.Dom.getSize,
      xmlEncode: function(str) {
        var xmlEncodeChars = { "<": "lt", ">": "gt", "&": "amp", '"': "quot", "'": "#39" }, xmlEncodeRegExp = /[<>&\"\']/g;
        return str ? ("" + str).replace(xmlEncodeRegExp, function(chr) {
          return xmlEncodeChars[chr] ? "&" + xmlEncodeChars[chr] + ";" : chr;
        }) : str;
      },
      toArray: u.Basic.toArray,
      inArray: u.Basic.inArray,
      inSeries: u.Basic.inSeries,
      addI18n: o.core.I18n.addI18n,
      translate: o.core.I18n.translate,
      sprintf: u.Basic.sprintf,
      isEmptyObj: u.Basic.isEmptyObj,
      hasClass: u.Dom.hasClass,
      addClass: u.Dom.addClass,
      removeClass: u.Dom.removeClass,
      getStyle: u.Dom.getStyle,
      addEvent: u.Events.addEvent,
      removeEvent: u.Events.removeEvent,
      removeAllEvents: u.Events.removeAllEvents,
      cleanName: function(name) {
        var i, lookup;
        lookup = [
          /[\300-\306]/g,
          "A",
          /[\340-\346]/g,
          "a",
          /\307/g,
          "C",
          /\347/g,
          "c",
          /[\310-\313]/g,
          "E",
          /[\350-\353]/g,
          "e",
          /[\314-\317]/g,
          "I",
          /[\354-\357]/g,
          "i",
          /\321/g,
          "N",
          /\361/g,
          "n",
          /[\322-\330]/g,
          "O",
          /[\362-\370]/g,
          "o",
          /[\331-\334]/g,
          "U",
          /[\371-\374]/g,
          "u"
        ];
        for (i = 0; i < lookup.length; i += 2) {
          name = name.replace(lookup[i], lookup[i + 1]);
        }
        name = name.replace(/\s+/g, "_");
        name = name.replace(/[^a-z0-9_\-\.]+/gi, "");
        return name;
      },
      buildUrl: function(url, items) {
        var query = "";
        plupload2.each(items, function(value, name) {
          query += (query ? "&" : "") + encodeURIComponent(name) + "=" + encodeURIComponent(value);
        });
        if (query) {
          url += (url.indexOf("?") > 0 ? "&" : "?") + query;
        }
        return url;
      },
      formatSize: function(size) {
        if (size === undef || /\D/.test(size)) {
          return plupload2.translate("N/A");
        }
        function round(num, precision) {
          return Math.round(num * Math.pow(10, precision)) / Math.pow(10, precision);
        }
        var boundary = Math.pow(1024, 4);
        if (size > boundary) {
          return round(size / boundary, 1) + " " + plupload2.translate("tb");
        }
        if (size > (boundary /= 1024)) {
          return round(size / boundary, 1) + " " + plupload2.translate("gb");
        }
        if (size > (boundary /= 1024)) {
          return round(size / boundary, 1) + " " + plupload2.translate("mb");
        }
        if (size > 1024) {
          return Math.round(size / 1024) + " " + plupload2.translate("kb");
        }
        return size + " " + plupload2.translate("b");
      },
      parseSize: u.Basic.parseSizeStr,
      predictRuntime: function(config, runtimes) {
        var up, runtime;
        up = new plupload2.Uploader(config);
        runtime = Runtime.thatCan(up.getOption().required_features, runtimes || config.runtimes);
        up.destroy();
        return runtime;
      },
      addFileFilter: function(name, cb) {
        fileFilters[name] = cb;
      }
    };
    plupload2.addFileFilter("mime_types", function(filters, file, cb) {
      if (filters.length && !filters.regexp.test(file.name)) {
        this.trigger("Error", {
          code: plupload2.FILE_EXTENSION_ERROR,
          message: plupload2.translate("File extension error."),
          file
        });
        cb(false);
      } else {
        cb(true);
      }
    });
    plupload2.addFileFilter("max_file_size", function(maxSize, file, cb) {
      var undef2;
      maxSize = plupload2.parseSize(maxSize);
      if (file.size !== undef2 && maxSize && file.size > maxSize) {
        this.trigger("Error", {
          code: plupload2.FILE_SIZE_ERROR,
          message: plupload2.translate("File size error."),
          file
        });
        cb(false);
      } else {
        cb(true);
      }
    });
    plupload2.addFileFilter("prevent_duplicates", function(value, file, cb) {
      if (value) {
        var ii = this.files.length;
        while (ii--) {
          if (file.name === this.files[ii].name && file.size === this.files[ii].size) {
            this.trigger("Error", {
              code: plupload2.FILE_DUPLICATE_ERROR,
              message: plupload2.translate("Duplicate file error."),
              file
            });
            cb(false);
            return;
          }
        }
      }
      cb(true);
    });
    plupload2.addFileFilter("prevent_empty", function(value, file, cb) {
      if (value && !file.size && file.size !== undef) {
        this.trigger("Error", {
          code: plupload2.FILE_SIZE_ERROR,
          message: plupload2.translate("File size error."),
          file
        });
        cb(false);
      } else {
        cb(true);
      }
    });
    plupload2.Uploader = function(options) {
      var uid = plupload2.guid(), settings, files = [], preferred_caps = {}, fileInputs = [], fileDrops = [], startTime, total, disabled = false, xhr;
      function uploadNext() {
        var file, count = 0, i;
        if (this.state == plupload2.STARTED) {
          for (i = 0; i < files.length; i++) {
            if (!file && files[i].status == plupload2.QUEUED) {
              file = files[i];
              if (this.trigger("BeforeUpload", file)) {
                file.status = plupload2.UPLOADING;
                this.trigger("UploadFile", file);
              }
            } else {
              count++;
            }
          }
          if (count == files.length) {
            if (this.state !== plupload2.STOPPED) {
              this.state = plupload2.STOPPED;
              this.trigger("StateChanged");
            }
            this.trigger("UploadComplete", files);
          }
        }
      }
      function calcFile(file) {
        file.percent = file.size > 0 ? Math.ceil(file.loaded / file.size * 100) : 100;
        calc();
      }
      function calc() {
        var i, file;
        var loaded;
        var loadedDuringCurrentSession = 0;
        total.reset();
        for (i = 0; i < files.length; i++) {
          file = files[i];
          if (file.size !== undef) {
            total.size += file.origSize;
            loaded = file.loaded * file.origSize / file.size;
            if (!file.completeTimestamp || file.completeTimestamp > startTime) {
              loadedDuringCurrentSession += loaded;
            }
            total.loaded += loaded;
          } else {
            total.size = undef;
          }
          if (file.status == plupload2.DONE) {
            total.uploaded++;
          } else if (file.status == plupload2.FAILED) {
            total.failed++;
          } else {
            total.queued++;
          }
        }
        if (total.size === undef) {
          total.percent = files.length > 0 ? Math.ceil(total.uploaded / files.length * 100) : 0;
        } else {
          total.bytesPerSec = Math.ceil(loadedDuringCurrentSession / ((+new Date() - startTime || 1) / 1e3));
          total.percent = total.size > 0 ? Math.ceil(total.loaded / total.size * 100) : 0;
        }
      }
      function getRUID() {
        var ctrl = fileInputs[0] || fileDrops[0];
        if (ctrl) {
          return ctrl.getRuntime().uid;
        }
        return false;
      }
      function bindEventListeners() {
        this.bind("FilesAdded FilesRemoved", function(up) {
          up.trigger("QueueChanged");
          up.refresh();
        });
        this.bind("CancelUpload", onCancelUpload);
        this.bind("BeforeUpload", onBeforeUpload);
        this.bind("UploadFile", onUploadFile);
        this.bind("UploadProgress", onUploadProgress);
        this.bind("StateChanged", onStateChanged);
        this.bind("QueueChanged", calc);
        this.bind("Error", onError);
        this.bind("FileUploaded", onFileUploaded);
        this.bind("Destroy", onDestroy);
      }
      function initControls(settings2, cb) {
        var self = this, inited = 0, queue = [];
        var options2 = {
          runtime_order: settings2.runtimes,
          required_caps: settings2.required_features,
          preferred_caps,
          swf_url: settings2.flash_swf_url,
          xap_url: settings2.silverlight_xap_url
        };
        plupload2.each(settings2.runtimes.split(/\s*,\s*/), function(runtime) {
          if (settings2[runtime]) {
            options2[runtime] = settings2[runtime];
          }
        });
        if (settings2.browse_button) {
          plupload2.each(settings2.browse_button, function(el) {
            queue.push(function(cb2) {
              var fileInput = new o.file.FileInput(
                plupload2.extend({}, options2, {
                  accept: settings2.filters.mime_types,
                  name: settings2.file_data_name,
                  multiple: settings2.multi_selection,
                  container: settings2.container,
                  browse_button: el
                })
              );
              fileInput.onready = function() {
                var info = Runtime.getInfo(this.ruid);
                plupload2.extend(self.features, {
                  chunks: info.can("slice_blob"),
                  multipart: info.can("send_multipart"),
                  multi_selection: info.can("select_multiple")
                });
                inited++;
                fileInputs.push(this);
                cb2();
              };
              fileInput.onchange = function() {
                self.addFile(this.files);
              };
              fileInput.bind("mouseenter mouseleave mousedown mouseup", function(e) {
                if (!disabled) {
                  if (settings2.browse_button_hover) {
                    if ("mouseenter" === e.type) {
                      plupload2.addClass(el, settings2.browse_button_hover);
                    } else if ("mouseleave" === e.type) {
                      plupload2.removeClass(el, settings2.browse_button_hover);
                    }
                  }
                  if (settings2.browse_button_active) {
                    if ("mousedown" === e.type) {
                      plupload2.addClass(el, settings2.browse_button_active);
                    } else if ("mouseup" === e.type) {
                      plupload2.removeClass(el, settings2.browse_button_active);
                    }
                  }
                }
              });
              fileInput.bind("mousedown", function() {
                self.trigger("Browse");
              });
              fileInput.bind("error runtimeerror", function() {
                fileInput = null;
                cb2();
              });
              fileInput.init();
            });
          });
        }
        if (settings2.drop_element) {
          plupload2.each(settings2.drop_element, function(el) {
            queue.push(function(cb2) {
              var fileDrop = new o.file.FileDrop(
                plupload2.extend({}, options2, {
                  drop_zone: el
                })
              );
              fileDrop.onready = function() {
                var info = Runtime.getInfo(this.ruid);
                plupload2.extend(self.features, {
                  chunks: info.can("slice_blob"),
                  multipart: info.can("send_multipart"),
                  dragdrop: info.can("drag_and_drop")
                });
                inited++;
                fileDrops.push(this);
                cb2();
              };
              fileDrop.ondrop = function() {
                self.addFile(this.files);
              };
              fileDrop.bind("error runtimeerror", function() {
                fileDrop = null;
                cb2();
              });
              fileDrop.init();
            });
          });
        }
        plupload2.inSeries(queue, function() {
          if (typeof cb === "function") {
            cb(inited);
          }
        });
      }
      function resizeImage(blob, params, runtimeOptions, cb) {
        var img = new o.image.Image();
        try {
          img.onload = function() {
            if (params.width > this.width && params.height > this.height && params.quality === undef && params.preserve_headers && !params.crop) {
              this.destroy();
              cb(blob);
            } else {
              img.downsize(params.width, params.height, params.crop, params.preserve_headers);
            }
          };
          img.onresize = function() {
            var resizedBlob = this.getAsBlob(blob.type, params.quality);
            this.destroy();
            cb(resizedBlob);
          };
          img.bind("error runtimeerror", function() {
            this.destroy();
            cb(blob);
          });
          img.load(blob, runtimeOptions);
        } catch (ex) {
          cb(blob);
        }
      }
      function setOption(option, value, init) {
        var self = this, reinitRequired = false;
        function _setOption(option2, value2, init2) {
          var oldValue = settings[option2];
          switch (option2) {
            case "max_file_size":
              if (option2 === "max_file_size") {
                settings.max_file_size = settings.filters.max_file_size = value2;
              }
              break;
            case "chunk_size":
              if (value2 = plupload2.parseSize(value2)) {
                settings[option2] = value2;
                settings.send_file_name = true;
              }
              break;
            case "multipart":
              settings[option2] = value2;
              if (!value2) {
                settings.send_file_name = true;
              }
              break;
            case "http_method":
              settings[option2] = value2.toUpperCase() === "PUT" ? "PUT" : "POST";
              break;
            case "unique_names":
              settings[option2] = value2;
              if (value2) {
                settings.send_file_name = true;
              }
              break;
            case "filters":
              if (plupload2.typeOf(value2) === "array") {
                value2 = {
                  mime_types: value2
                };
              }
              if (init2) {
                plupload2.extend(settings.filters, value2);
              } else {
                settings.filters = value2;
              }
              if (value2.mime_types) {
                if (plupload2.typeOf(value2.mime_types) === "string") {
                  value2.mime_types = o.core.utils.Mime.mimes2extList(value2.mime_types);
                }
                value2.mime_types.regexp = function(filters) {
                  var extensionsRegExp = [];
                  plupload2.each(filters, function(filter) {
                    plupload2.each(filter.extensions.split(/,/), function(ext) {
                      if (/^\s*\*\s*$/.test(ext)) {
                        extensionsRegExp.push("\\.*");
                      } else {
                        extensionsRegExp.push(
                          "\\." + ext.replace(new RegExp("[" + "/^$.*+?|()[]{}\\".replace(/./g, "\\$&") + "]", "g"), "\\$&")
                        );
                      }
                    });
                  });
                  return new RegExp("(" + extensionsRegExp.join("|") + ")$", "i");
                }(value2.mime_types);
                settings.filters.mime_types = value2.mime_types;
              }
              break;
            case "resize":
              if (value2) {
                settings.resize = plupload2.extend(
                  {
                    preserve_headers: true,
                    crop: false
                  },
                  value2
                );
              } else {
                settings.resize = false;
              }
              break;
            case "prevent_duplicates":
              settings.prevent_duplicates = settings.filters.prevent_duplicates = !!value2;
              break;
            case "container":
            case "browse_button":
            case "drop_element":
              value2 = "container" === option2 ? plupload2.get(value2) : plupload2.getAll(value2);
            case "runtimes":
            case "multi_selection":
            case "flash_swf_url":
            case "silverlight_xap_url":
              settings[option2] = value2;
              if (!init2) {
                reinitRequired = true;
              }
              break;
            default:
              settings[option2] = value2;
          }
          if (!init2) {
            self.trigger("OptionChanged", option2, value2, oldValue);
          }
        }
        if (typeof option === "object") {
          plupload2.each(option, function(value2, option2) {
            _setOption(option2, value2, init);
          });
        } else {
          _setOption(option, value, init);
        }
        if (init) {
          settings.required_features = normalizeCaps(plupload2.extend({}, settings));
          preferred_caps = normalizeCaps(
            plupload2.extend({}, settings, {
              required_features: true
            })
          );
        } else if (reinitRequired) {
          self.trigger("Destroy");
          initControls.call(self, settings, function(inited) {
            if (inited) {
              self.runtime = Runtime.getInfo(getRUID()).type;
              self.trigger("Init", { runtime: self.runtime });
              self.trigger("PostInit");
            } else {
              self.trigger("Error", {
                code: plupload2.INIT_ERROR,
                message: plupload2.translate("Init error.")
              });
            }
          });
        }
      }
      function onBeforeUpload(up, file) {
        if (up.settings.unique_names) {
          var matches = file.name.match(/\.([^.]+)$/), ext = "part";
          if (matches) {
            ext = matches[1];
          }
          file.target_name = file.id + "." + ext;
        }
      }
      function onUploadFile(up, file) {
        var url = up.settings.url;
        var chunkSize = up.settings.chunk_size;
        var retries = up.settings.max_retries;
        var features = up.features;
        var offset = 0;
        var blob;
        var runtimeOptions = {
          runtime_order: up.settings.runtimes,
          required_caps: up.settings.required_features,
          preferred_caps,
          swf_url: up.settings.flash_swf_url,
          xap_url: up.settings.silverlight_xap_url
        };
        if (file.loaded) {
          offset = file.loaded = chunkSize ? chunkSize * Math.floor(file.loaded / chunkSize) : 0;
        }
        function handleError() {
          if (retries-- > 0) {
            delay(uploadNextChunk, 1e3);
          } else {
            file.loaded = offset;
            up.trigger("Error", {
              code: plupload2.HTTP_ERROR,
              message: plupload2.translate("HTTP Error."),
              file,
              response: xhr.responseText,
              status: xhr.status,
              responseHeaders: xhr.getAllResponseHeaders()
            });
          }
        }
        function uploadNextChunk() {
          var chunkBlob, args = {}, curChunkSize;
          if (file.status !== plupload2.UPLOADING || up.state === plupload2.STOPPED) {
            return;
          }
          if (up.settings.send_file_name) {
            args.name = file.target_name || file.name;
          }
          if (chunkSize && features.chunks && blob.size > chunkSize) {
            curChunkSize = Math.min(chunkSize, blob.size - offset);
            chunkBlob = blob.slice(offset, offset + curChunkSize);
          } else {
            curChunkSize = blob.size;
            chunkBlob = blob;
          }
          if (chunkSize && features.chunks) {
            if (up.settings.send_chunk_number) {
              args.chunk = Math.ceil(offset / chunkSize);
              args.chunks = Math.ceil(blob.size / chunkSize);
            } else {
              args.offset = offset;
              args.total = blob.size;
            }
          }
          if (up.trigger("BeforeChunkUpload", file, args, chunkBlob, offset)) {
            uploadChunk(args, chunkBlob, curChunkSize);
          }
        }
        function uploadChunk(args, chunkBlob, curChunkSize) {
          var formData;
          xhr = new o.xhr.XMLHttpRequest();
          if (xhr.upload) {
            xhr.upload.onprogress = function(e) {
              file.loaded = Math.min(file.size, offset + e.loaded);
              up.trigger("UploadProgress", file);
            };
          }
          xhr.onload = function() {
            if (xhr.status < 200 || xhr.status >= 400) {
              handleError();
              return;
            }
            retries = up.settings.max_retries;
            if (curChunkSize < blob.size) {
              chunkBlob.destroy();
              offset += curChunkSize;
              file.loaded = Math.min(offset, blob.size);
              up.trigger("ChunkUploaded", file, {
                offset: file.loaded,
                total: blob.size,
                response: xhr.responseText,
                status: xhr.status,
                responseHeaders: xhr.getAllResponseHeaders()
              });
              if (plupload2.ua.browser === "Android Browser") {
                up.trigger("UploadProgress", file);
              }
            } else {
              file.loaded = file.size;
            }
            chunkBlob = formData = null;
            if (!offset || offset >= blob.size) {
              if (file.size != file.origSize) {
                blob.destroy();
                blob = null;
              }
              up.trigger("UploadProgress", file);
              file.status = plupload2.DONE;
              file.completeTimestamp = +new Date();
              up.trigger("FileUploaded", file, {
                response: xhr.responseText,
                status: xhr.status,
                responseHeaders: xhr.getAllResponseHeaders()
              });
            } else {
              delay(uploadNextChunk, 1);
            }
          };
          xhr.onerror = function() {
            handleError();
          };
          xhr.onloadend = function() {
            this.destroy();
          };
          if (up.settings.multipart && features.multipart) {
            xhr.open(up.settings.http_method, url, true);
            plupload2.each(up.settings.headers, function(value, name) {
              xhr.setRequestHeader(name, value);
            });
            formData = new o.xhr.FormData();
            plupload2.each(plupload2.extend(args, up.settings.multipart_params), function(value, name) {
              formData.append(name, value);
            });
            formData.append(up.settings.file_data_name, chunkBlob);
            xhr.send(formData, runtimeOptions);
          } else {
            url = plupload2.buildUrl(up.settings.url, plupload2.extend(args, up.settings.multipart_params));
            xhr.open(up.settings.http_method, url, true);
            plupload2.each(up.settings.headers, function(value, name) {
              xhr.setRequestHeader(name, value);
            });
            if (!xhr.hasRequestHeader("Content-Type")) {
              xhr.setRequestHeader("Content-Type", "application/octet-stream");
            }
            xhr.send(chunkBlob, runtimeOptions);
          }
        }
        blob = file.getSource();
        if (!plupload2.isEmptyObj(up.settings.resize) && plupload2.inArray(blob.type, ["image/jpeg", "image/png"]) !== -1) {
          resizeImage(blob, up.settings.resize, runtimeOptions, function(resizedBlob) {
            blob = resizedBlob;
            file.size = resizedBlob.size;
            uploadNextChunk();
          });
        } else {
          uploadNextChunk();
        }
      }
      function onUploadProgress(up, file) {
        calcFile(file);
      }
      function onStateChanged(up) {
        if (up.state == plupload2.STARTED) {
          startTime = +new Date();
        } else if (up.state == plupload2.STOPPED) {
          for (var i = up.files.length - 1; i >= 0; i--) {
            if (up.files[i].status == plupload2.UPLOADING) {
              up.files[i].status = plupload2.QUEUED;
              calc();
            }
          }
        }
      }
      function onCancelUpload() {
        if (xhr) {
          xhr.abort();
        }
      }
      function onFileUploaded(up) {
        calc();
        delay(function() {
          uploadNext.call(up);
        }, 1);
      }
      function onError(up, err) {
        if (err.code === plupload2.INIT_ERROR) {
          up.destroy();
        } else if (err.code === plupload2.HTTP_ERROR) {
          err.file.status = plupload2.FAILED;
          err.file.completeTimestamp = +new Date();
          calcFile(err.file);
          if (up.state == plupload2.STARTED) {
            up.trigger("CancelUpload");
            delay(function() {
              uploadNext.call(up);
            }, 1);
          }
        }
      }
      function onDestroy(up) {
        up.stop();
        plupload2.each(files, function(file) {
          file.destroy();
        });
        files = [];
        if (fileInputs.length) {
          plupload2.each(fileInputs, function(fileInput) {
            fileInput.destroy();
          });
          fileInputs = [];
        }
        if (fileDrops.length) {
          plupload2.each(fileDrops, function(fileDrop) {
            fileDrop.destroy();
          });
          fileDrops = [];
        }
        preferred_caps = {};
        disabled = false;
        startTime = xhr = null;
        total.reset();
      }
      settings = {
        chunk_size: 0,
        file_data_name: "file",
        filters: {
          mime_types: [],
          max_file_size: 0,
          prevent_duplicates: false,
          prevent_empty: true
        },
        flash_swf_url: "js/Moxie.swf",
        http_method: "POST",
        max_retries: 0,
        multipart: true,
        multi_selection: true,
        resize: false,
        runtimes: Runtime.order,
        send_file_name: true,
        send_chunk_number: true,
        silverlight_xap_url: "js/Moxie.xap"
      };
      setOption.call(this, options, null, true);
      total = new plupload2.QueueProgress();
      plupload2.extend(this, {
        id: uid,
        uid,
        state: plupload2.STOPPED,
        features: {},
        runtime: null,
        files,
        settings,
        total,
        init: function() {
          var self = this, preinitOpt, err;
          preinitOpt = self.getOption("preinit");
          if (typeof preinitOpt == "function") {
            preinitOpt(self);
          } else {
            plupload2.each(preinitOpt, function(func, name) {
              self.bind(name, func);
            });
          }
          bindEventListeners.call(self);
          plupload2.each(["container", "browse_button", "drop_element"], function(el) {
            if (self.getOption(el) === null) {
              err = {
                code: plupload2.INIT_ERROR,
                message: plupload2.sprintf(plupload2.translate("%s specified, but cannot be found."), el)
              };
              return false;
            }
          });
          if (err) {
            return self.trigger("Error", err);
          }
          if (!settings.browse_button && !settings.drop_element) {
            return self.trigger("Error", {
              code: plupload2.INIT_ERROR,
              message: plupload2.translate("You must specify either browse_button or drop_element.")
            });
          }
          initControls.call(self, settings, function(inited) {
            var initOpt = self.getOption("init");
            if (typeof initOpt == "function") {
              initOpt(self);
            } else {
              plupload2.each(initOpt, function(func, name) {
                self.bind(name, func);
              });
            }
            if (inited) {
              self.runtime = Runtime.getInfo(getRUID()).type;
              self.trigger("Init", { runtime: self.runtime });
              self.trigger("PostInit");
            } else {
              self.trigger("Error", {
                code: plupload2.INIT_ERROR,
                message: plupload2.translate("Init error.")
              });
            }
          });
        },
        setOption: function(option, value) {
          setOption.call(this, option, value, !this.runtime);
        },
        getOption: function(option) {
          if (!option) {
            return settings;
          }
          return settings[option];
        },
        refresh: function() {
          if (fileInputs.length) {
            plupload2.each(fileInputs, function(fileInput) {
              fileInput.trigger("Refresh");
            });
          }
          this.trigger("Refresh");
        },
        start: function() {
          if (this.state != plupload2.STARTED) {
            this.state = plupload2.STARTED;
            this.trigger("StateChanged");
            uploadNext.call(this);
          }
        },
        stop: function() {
          if (this.state != plupload2.STOPPED) {
            this.state = plupload2.STOPPED;
            this.trigger("StateChanged");
            this.trigger("CancelUpload");
          }
        },
        disableBrowse: function() {
          disabled = arguments[0] !== undef ? arguments[0] : true;
          if (fileInputs.length) {
            plupload2.each(fileInputs, function(fileInput) {
              fileInput.disable(disabled);
            });
          }
          this.trigger("DisableBrowse", disabled);
        },
        getFile: function(id) {
          var i;
          for (i = files.length - 1; i >= 0; i--) {
            if (files[i].id === id) {
              return files[i];
            }
          }
        },
        addFile: function(file, fileName) {
          var self = this, queue = [], filesAdded = [], ruid;
          function filterFile(file2, cb) {
            var queue2 = [];
            plupload2.each(self.settings.filters, function(rule, name) {
              if (fileFilters[name]) {
                queue2.push(function(cb2) {
                  fileFilters[name].call(self, rule, file2, function(res) {
                    cb2(!res);
                  });
                });
              }
            });
            plupload2.inSeries(queue2, cb);
          }
          function resolveFile(file2) {
            var type = plupload2.typeOf(file2);
            if (file2 instanceof o.file.File) {
              if (!file2.ruid && !file2.isDetached()) {
                if (!ruid) {
                  return false;
                }
                file2.ruid = ruid;
                file2.connectRuntime(ruid);
              }
              resolveFile(new plupload2.File(file2));
            } else if (file2 instanceof o.file.Blob) {
              resolveFile(file2.getSource());
              file2.destroy();
            } else if (file2 instanceof plupload2.File) {
              if (fileName) {
                file2.name = fileName;
              }
              queue.push(function(cb) {
                filterFile(file2, function(err) {
                  if (!err) {
                    files.push(file2);
                    filesAdded.push(file2);
                    self.trigger("FileFiltered", file2);
                  }
                  delay(cb, 1);
                });
              });
            } else if (plupload2.inArray(type, ["file", "blob"]) !== -1) {
              resolveFile(new o.file.File(null, file2));
            } else if (type === "node" && plupload2.typeOf(file2.files) === "filelist") {
              plupload2.each(file2.files, resolveFile);
            } else if (type === "array") {
              fileName = null;
              plupload2.each(file2, resolveFile);
            }
          }
          ruid = getRUID();
          resolveFile(file);
          if (queue.length) {
            plupload2.inSeries(queue, function() {
              if (filesAdded.length) {
                self.trigger("FilesAdded", filesAdded);
              }
            });
          }
        },
        removeFile: function(file) {
          var id = typeof file === "string" ? file : file.id;
          for (var i = files.length - 1; i >= 0; i--) {
            if (files[i].id === id) {
              return this.splice(i, 1)[0];
            }
          }
        },
        splice: function(start, length) {
          var removed = files.splice(start === undef ? 0 : start, length === undef ? files.length : length);
          var restartRequired = false;
          if (this.state == plupload2.STARTED) {
            plupload2.each(removed, function(file) {
              if (file.status === plupload2.UPLOADING) {
                restartRequired = true;
                return false;
              }
            });
            if (restartRequired) {
              this.stop();
            }
          }
          this.trigger("FilesRemoved", removed);
          plupload2.each(removed, function(file) {
            file.destroy();
          });
          if (restartRequired) {
            this.start();
          }
          return removed;
        },
        dispatchEvent: function(type) {
          var list, args;
          type = type.toLowerCase();
          list = this.hasEventListener(type);
          if (list) {
            list.sort(function(a, b) {
              return b.priority - a.priority;
            });
            args = [].slice.call(arguments);
            args.shift();
            args.unshift(this);
            for (var i = 0; i < list.length; i++) {
              if (list[i].fn.apply(list[i].scope, args) === false) {
                return false;
              }
            }
          }
          return true;
        },
        bind: function(name, fn, scope, priority) {
          plupload2.Uploader.prototype.bind.call(this, name, fn, priority, scope);
        },
        destroy: function() {
          this.trigger("Destroy");
          settings = total = null;
          this.unbindAll();
        }
      });
    };
    plupload2.Uploader.prototype = o.core.EventTarget.instance;
    plupload2.File = function() {
      var filepool = {};
      function PluploadFile(file) {
        plupload2.extend(this, {
          id: plupload2.guid(),
          name: file.name || file.fileName,
          type: file.type || "",
          relativePath: file.relativePath || "",
          size: file.fileSize || file.size,
          origSize: file.fileSize || file.size,
          loaded: 0,
          percent: 0,
          status: plupload2.QUEUED,
          lastModifiedDate: file.lastModifiedDate || new Date().toLocaleString(),
          completeTimestamp: 0,
          getNative: function() {
            var file2 = this.getSource().getSource();
            return plupload2.inArray(plupload2.typeOf(file2), ["blob", "file"]) !== -1 ? file2 : null;
          },
          getSource: function() {
            if (!filepool[this.id]) {
              return null;
            }
            return filepool[this.id];
          },
          destroy: function() {
            var src = this.getSource();
            if (src) {
              src.destroy();
              delete filepool[this.id];
            }
          }
        });
        filepool[this.id] = file;
      }
      return PluploadFile;
    }();
    plupload2.QueueProgress = function() {
      var self = this;
      self.size = 0;
      self.loaded = 0;
      self.uploaded = 0;
      self.failed = 0;
      self.queued = 0;
      self.percent = 0;
      self.bytesPerSec = 0;
      self.reset = function() {
        self.size = self.loaded = self.uploaded = self.failed = self.queued = self.percent = self.bytesPerSec = 0;
      };
    };
    exports.plupload = plupload2;
  })(this, moxie2);
});
export { plupload as default };
