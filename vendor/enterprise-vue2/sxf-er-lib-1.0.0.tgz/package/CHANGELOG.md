# @sxf/er-lib

## 1.0.0

### Major Changes

- 7875a24a: feat: eresh1.0 正式版发布

### Patch Changes

- Updated dependencies [ba95de09]
- Updated dependencies [8197c813]
- Updated dependencies [db191806]
- Updated dependencies [77719cfb]
- Updated dependencies [6e39bddc]
- Updated dependencies [6260bb87]
- Updated dependencies [59e243b3]
- Updated dependencies [b049d503]
- Updated dependencies [a3ae5ee0]
- Updated dependencies [e86f9574]
- Updated dependencies [6533c596]
- Updated dependencies [63818025]
- Updated dependencies [95ed3396]
- Updated dependencies [72650ffa]
- Updated dependencies [d97114b4]
- Updated dependencies [7875a24a]
- Updated dependencies [0a66303a]
- Updated dependencies [4145c62f]
  - @sxf/er-config@1.0.0

## 1.0.0-beta.0

### Major Changes

- 0b0e74eb: chore: init beta version release

### Patch Changes

- Updated dependencies [0b0e74eb]
  - @sxf/er-config@1.0.0-beta.0

## 0.1.1

### Patch Changes

- 15c540c: fix(lib): 修复引入 file-saver 导致原生 Blob 被覆盖

## 0.1.0

### Minor Changes

- b597743: build: er-config 和 er-style 改为 peer 依赖

## 0.0.5

### Patch Changes

- fd66168: fix: pkg 中的依赖补全

## 0.0.4

### Patch Changes

- 00e2312: fix: 修复图片构建问题

## 0.0.3

### Patch Changes

- f467d2f: build: 使用 tsup 打包 utils, validator 等纯 js 包，生成 d.ts 文件

## 0.0.2

### Patch Changes

- release

## 0.0.1

### Patch Changes

- chore: release
