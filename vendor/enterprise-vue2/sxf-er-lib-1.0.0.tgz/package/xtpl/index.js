function isType(type) {
  return function(obj) {
    return {}.toString.call(obj) == "[object " + type + "]";
  };
}
const util = {
  isArray: Array.isArray || isType("Array"),
  apply: function(o, c, defaults) {
    if (defaults) {
      util.apply(o, defaults);
    }
    if (o && c && typeof c == "object") {
      for (const p in c) {
        o[p] = c[p];
      }
    }
    return o;
  },
  htmlDecode: function(value) {
    if (!value) {
      return value;
    }
    return String(value).replace(/&gt;/g, ">").replace(/&lt;/g, "<").replace(/&quot;/g, '"').replace(/&amp;/g, "&");
  },
  htmlEncode: function(value) {
    return !value ? value : String(value).replace(/&/g, "&amp;").replace(/>/g, "&gt;").replace(/</g, "&lt;").replace(/"/g, "&quot;");
  }
};
var Parser = {
  doTpl() {
  },
  parse(str) {
    let me = this, len = str.length, aliases = { elseif: "elif" }, topRe = me.topRe, actionsRe = me.actionsRe, index, stack, s, m, t, prev, frame, subMatch, begin, end, actions, prop;
    me.level = 0;
    me.stack = stack = [];
    for (index = 0; index < len; index = end) {
      topRe.lastIndex = index;
      m = topRe.exec(str);
      if (!m) {
        me.doText(str.substring(index, len));
        break;
      }
      begin = m.index;
      end = topRe.lastIndex;
      if (index < begin) {
        me.doText(str.substring(index, begin));
      }
      if (m[1]) {
        end = str.indexOf("%}", begin + 2);
        me.doEval(str.substring(begin + 2, end));
        end += 2;
      } else if (m[2]) {
        end = str.indexOf("]}", begin + 2);
        me.doExpr(str.substring(begin + 2, end));
        end += 2;
      } else if (m[3]) {
        me.doTag(m[3]);
      } else if (m[4]) {
        actions = null;
        while ((subMatch = actionsRe.exec(m[4])) !== null) {
          s = subMatch[2] || subMatch[3];
          if (s) {
            s = util.htmlDecode(s);
            t = subMatch[1];
            t = aliases[t] || t;
            actions = actions || {};
            prev = actions[t];
            if (typeof prev == "string") {
              actions[t] = [prev, s];
            } else if (prev) {
              actions[t].push(s);
            } else {
              actions[t] = s;
            }
          }
        }
        if (!actions) {
          if (me.elseRe.test(m[4])) {
            me.doElse();
          } else if (me.defaultRe.test(m[4])) {
            me.doDefault();
          } else {
            me.doTpl();
            stack.push({ type: "tpl" });
          }
        } else if (actions["if"]) {
          me.doIf(actions["if"], actions);
          stack.push({ type: "if" });
        } else if (actions["switch"]) {
          me.doSwitch(actions["switch"], actions);
          stack.push({ type: "switch" });
        } else if (actions["case"]) {
          me.doCase(actions["case"], actions);
        } else if (actions["elif"]) {
          me.doElseIf(actions["elif"], actions);
        } else if (actions["for"]) {
          ++me.level;
          if (prop = me.propRe.exec(m[4])) {
            actions.propName = prop[1] || prop[2];
          }
          me.doFor(actions["for"], actions);
          stack.push({ type: "for", actions });
        } else if (actions["foreach"]) {
          ++me.level;
          if (prop = me.propRe.exec(m[4])) {
            actions.propName = prop[1] || prop[2];
          }
          me.doForEach(actions["foreach"], actions);
          stack.push({ type: "foreach", actions });
        } else if (actions.exec) {
          me.doExec(actions.exec, actions);
          stack.push({ type: "exec", actions });
        }
      } else if (m[0].length === 5) {
        stack.push({ type: "tpl" });
      } else {
        frame = stack.pop();
        me.doEnd(frame.type, frame.actions);
        if (frame.type == "for" || frame.type == "foreach") {
          --me.level;
        }
      }
    }
  },
  topRe: /(?:(\{\%)|(\{\[)|\{([^{}]+)\})|(?:<tpl([^>]*)\>)|(?:<\/tpl>)/g,
  actionsRe: /\s*(elif|elseif|if|for|foreach|exec|switch|case|eval|between)\s*\=\s*(?:(?:"([^"]*)")|(?:'([^']*)'))\s*/g,
  propRe: /prop=(?:(?:"([^"]*)")|(?:'([^']*)'))/,
  defaultRe: /^\s*default\s*$/,
  elseRe: /^\s*else\s*$/
};
const Compiler = function(config) {
  util.apply(this, config);
};
const CPROTO = Compiler.prototype = {};
util.apply(CPROTO, Parser);
const ua = typeof navigator !== "undefined" ? navigator.userAgent : "";
let useEval = /gecko/i.test(ua) && !/webkit/i.test(ua);
try {
  useEval && eval("with ({}) {}");
} catch (err) {
  useEval = false;
}
util.apply(CPROTO, {
  useEval,
  useIndex: false,
  useFormat: true,
  propNameRe: /^[\w\d\$]*$/,
  compile: function(tpl) {
    const me = this, code = me.generate(tpl);
    return me.useEval ? me.evalTpl(code) : new Function("_Format", code)(me._Format);
  },
  generate: function(tpl) {
    let me = this, definitions = "var fm=_Format,ts=Object.prototype.toString;", code;
    me.maxLevel = 0;
    me.body = ["var c0=values, a0=" + me.createArrayTest(0) + ", p0=parent, n0=xcount, i0=xindex, k0, v;\n"];
    if (me.definitions) {
      if (typeof me.definitions === "string") {
        me.definitions = [me.definitions, definitions];
      } else {
        me.definitions.push(definitions);
      }
    } else {
      me.definitions = [definitions];
    }
    me.switches = [];
    me.parse(tpl);
    me.definitions.push((me.useEval ? "$=" : "return") + " function (" + me.fnArgs + ") {", me.body.join(""), "}");
    code = me.definitions.join("\n");
    me.definitions.length = me.body.length = me.switches.length = 0;
    delete me.definitions;
    delete me.body;
    delete me.switches;
    return code;
  },
  doText: function(text) {
    const me = this, out = me.body;
    text = text.replace(me.aposRe, "\\'").replace(me.newLineRe, "\\n");
    if (me.useIndex) {
      out.push("out[out.length]='", text, "'\n");
    } else {
      out.push("out.push('", text, "')\n");
    }
  },
  doExpr: function(expr) {
    const out = this.body;
    out.push("if ((v=" + expr + ") != null) out");
    if (this.useIndex) {
      out.push("[out.length]=v+''\n");
    } else {
      out.push(".push(v+'')\n");
    }
  },
  doTag: function(tag) {
    const expr = this.parseTag(tag);
    if (expr) {
      this.doExpr(expr);
    } else {
      this.doText("{" + tag + "}");
    }
  },
  doElse: function() {
    this.body.push("} else {\n");
  },
  doEval: function(text) {
    this.body.push(text, "\n");
  },
  doIf: function(action, actions) {
    const me = this;
    if (action === ".") {
      me.body.push("if (values) {\n");
    } else if (me.propNameRe.test(action)) {
      me.body.push("if (", me.parseTag(action), ") {\n");
    } else {
      me.body.push("if (", me.addFn(action), me.callFn, ") {\n");
    }
    if (actions.exec) {
      me.doExec(actions.exec);
    }
  },
  doElseIf: function(action, actions) {
    const me = this;
    if (action === ".") {
      me.body.push("else if (values) {\n");
    } else if (me.propNameRe.test(action)) {
      me.body.push("} else if (", me.parseTag(action), ") {\n");
    } else {
      me.body.push("} else if (", me.addFn(action), me.callFn, ") {\n");
    }
    if (actions.exec) {
      me.doExec(actions.exec);
    }
  },
  doSwitch: function(action) {
    const me = this;
    if (action === ".") {
      me.body.push("switch (values) {\n");
    } else if (me.propNameRe.test(action)) {
      me.body.push("switch (", me.parseTag(action), ") {\n");
    } else {
      me.body.push("switch (", me.addFn(action), me.callFn, ") {\n");
    }
    me.switches.push(0);
  },
  doCase: function(action) {
    let me = this, cases = util.isArray(action) ? action : [action], n = me.switches.length - 1, match, i;
    if (me.switches[n]) {
      me.body.push("break;\n");
    } else {
      me.switches[n]++;
    }
    for (i = 0, n = cases.length; i < n; ++i) {
      match = me.intRe.exec(cases[i]);
      cases[i] = match ? match[1] : "'" + cases[i].replace(me.aposRe, "\\'") + "'";
    }
    me.body.push("case ", cases.join(": case "), ":\n");
  },
  doDefault: function() {
    const me = this, n = me.switches.length - 1;
    if (me.switches[n]) {
      me.body.push("break;\n");
    } else {
      me.switches[n]++;
    }
    me.body.push("default:\n");
  },
  doEnd: function(type, actions) {
    const me = this, L = me.level - 1;
    if (type == "for" || type == "foreach") {
      if (actions.exec) {
        me.doExec(actions.exec);
      }
      me.body.push("}\n");
      me.body.push("parent=p", L, ";values=r", L + 1, ";xcount=n" + L + ";xindex=i", L, "+1;xkey=k", L, ";\n");
    } else if (type == "if" || type == "switch") {
      me.body.push("}\n");
    }
  },
  doFor: function(action, actions) {
    let me = this, s, L = me.level, up = L - 1, parentAssignment;
    if (action === ".") {
      s = "values";
    } else if (me.propNameRe.test(action)) {
      s = me.parseTag(action);
    } else {
      s = me.addFn(action) + me.callFn;
    }
    if (me.maxLevel < L) {
      me.maxLevel = L;
      me.body.push("var ");
    }
    if (action == ".") {
      parentAssignment = "c" + L;
    } else {
      parentAssignment = "a" + up + "?c" + up + "[i" + up + "]:c" + up;
    }
    me.body.push(
      "i",
      L,
      "=0,n",
      L,
      "=0,c",
      L,
      "=",
      s,
      ",a",
      L,
      "=",
      me.createArrayTest(L),
      ",r",
      L,
      "=values,p",
      L,
      ",k",
      L,
      ";\n",
      "p",
      L,
      "=parent=",
      parentAssignment,
      "\n",
      "if (c",
      L,
      "){if(a",
      L,
      "){n",
      L,
      "=c",
      L,
      ".length;}",
      "else{c",
      L,
      "=[c",
      L,
      "];n",
      L,
      "=1;}}\n",
      "for (xcount=n",
      L,
      ";i",
      L,
      "<n" + L + ";++i",
      L,
      "){\n",
      "values=c",
      L,
      "[i",
      L,
      "]"
    );
    if (actions.propName) {
      me.body.push(".", actions.propName);
    }
    me.body.push("\n", "xindex=i", L, "+1\n");
    if (actions.between) {
      me.body.push('if(xindex>1){ out.push("', actions.between, '"); } \n');
    }
  },
  doForEach: function(action, actions) {
    let me = this, s, L = me.level, up = L - 1, parentAssignment;
    if (action === ".") {
      s = "values";
    } else if (me.propNameRe.test(action)) {
      s = me.parseTag(action);
    } else {
      s = me.addFn(action) + me.callFn;
    }
    if (me.maxLevel < L) {
      me.maxLevel = L;
      me.body.push("var ");
    }
    if (action == ".") {
      parentAssignment = "c" + L;
    } else {
      parentAssignment = "a" + up + "?c" + up + "[i" + up + "]:c" + up;
    }
    me.body.push(
      "i",
      L,
      "=-1,n",
      L,
      "=0,c",
      L,
      "=",
      s,
      ",a",
      L,
      "=",
      me.createArrayTest(L),
      ",r",
      L,
      "=values,p",
      L,
      ",k",
      L,
      ";\n",
      "p",
      L,
      "=parent=",
      parentAssignment,
      "\n",
      "for(k",
      L,
      " in c",
      L,
      "){\n",
      "xindex=++i",
      L,
      "+1;\n",
      "xkey=k",
      L,
      ";\n",
      "values=c",
      L,
      "[k",
      L,
      "];"
    );
    if (actions.propName) {
      me.body.push(".", actions.propName);
    }
    if (actions.between) {
      me.body.push('if(xindex>1){ out.push("', actions.between, '"); } \n');
    }
  },
  createArrayTest: "isArray" in Array ? function(L) {
    return "Array.isArray(c" + L + ")";
  } : function(L) {
    return "ts.call(c" + L + ')==="[object Array]"';
  },
  doExec: function(action) {
    const me = this, name = "f" + me.definitions.length;
    me.definitions.push(
      "function " + name + "(" + me.fnArgs + ") {",
      " try { with(values) {",
      "  " + action,
      " }} catch(e) {",
      'typeof console !== "undefined" && console.log("XTemplate Error: " + e.message);',
      "}",
      "}"
    );
    me.body.push(name + me.callFn + "\n");
  },
  addFn: function(body) {
    const me = this, name = "f" + me.definitions.length;
    if (body === ".") {
      me.definitions.push("function " + name + "(" + me.fnArgs + ") {", " return values", "}");
    } else if (body === "..") {
      me.definitions.push("function " + name + "(" + me.fnArgs + ") {", " return parent", "}");
    } else {
      me.definitions.push(
        "function " + name + "(" + me.fnArgs + ") {",
        " try { with(values) {",
        "  return(" + body + ")",
        " }} catch(e) {",
        'typeof console !== "undefined" && console.log("XTemplate Error: " + e.message);',
        "}",
        "}"
      );
    }
    return name;
  },
  parseTag: function(tag) {
    let me = this, m = me.tagRe.exec(tag), name, format, args, math, v;
    if (!m) {
      return null;
    }
    name = m[1];
    format = m[2];
    args = m[3];
    math = m[4];
    if (name == ".") {
      if (!me.validTypes) {
        me.definitions.push("var validTypes={string:1,number:1,boolean:1};");
        me.validTypes = true;
      }
      v = 'validTypes[typeof values] || ts.call(values) === "[object Date]" ? values : ""';
    } else if (name == "#") {
      v = "xindex";
    } else if (name == "$") {
      v = "xkey";
    } else if (name.substr(0, 7) == "parent.") {
      v = name;
    } else if (isNaN(name) && name.indexOf("-") == -1 && name.indexOf(".") != -1) {
      v = "values." + name;
    } else {
      v = "values['" + name + "']";
    }
    if (math) {
      v = "(" + v + math + ")";
    }
    if (format && me.useFormat) {
      args = args ? "," + args : "";
      if (format.substr(0, 5) != "this.") {
        format = "fm." + format + "(";
      } else {
        format += "(";
      }
    } else {
      return v;
    }
    return format + v + args + ")";
  },
  evalTpl: function($) {
    this._Format;
    eval($);
    return $;
  },
  newLineRe: /\r\n|\r|\n/g,
  aposRe: /[']/g,
  intRe: /^\s*(\d+)\s*$/,
  tagRe: /^([\w-\.\#\$]+)(?:\:([\w\.]*)(?:\((.*?)?\))?)?(\s?[\+\-\*\/]\s?[\d\.\+\-\*\/\(\)]+)?$/
});
CPROTO.fnArgs = "out,values,parent,xindex,xcount,xkey";
CPROTO.callFn = ".call(this," + CPROTO.fnArgs + ")";
function Tpl(html) {
  let me = this, args = arguments, buffer = [], i = 0, length = args.length, value;
  me.initialConfig = {};
  if (length === 1 && util.isArray(html)) {
    args = html;
    length = args.length;
  }
  if (length > 1) {
    for (; i < length; i++) {
      value = args[i];
      if (typeof value == "object") {
        util.apply(me.initialConfig, value);
        util.apply(me, value);
      } else {
        buffer.push(value);
      }
    }
  } else {
    buffer.push(html);
  }
  me.html = buffer.join("");
  if (me.compiled) {
    me.compile();
  }
  me._Format = {};
}
Tpl.prototype = {
  disableFormats: false,
  re: /\{([\w\-]+)(?:\:([\w\.]*)(?:\((.*?)?\))?)?\}/g,
  setFormats(opts) {
    util.apply(this._Format, opts);
  },
  applyTemplate() {
    return this.apply.apply(this, arguments);
  },
  set(html, compile) {
    const me = this;
    me.html = html;
    me.compiled = null;
    return compile ? me.compile() : me;
  },
  compileARe: /\\/g,
  compileBRe: /(\r\n|\n)/g,
  compileCRe: /'/g,
  emptyObj: {},
  apply(values, parent) {
    return this.applyOut(values, [], parent).join("");
  },
  applyOut(values, out, parent) {
    let me = this, compiler;
    if (!me.fn) {
      compiler = new Compiler({
        useFormat: me.disableFormats !== true,
        _Format: me._Format,
        definitions: me.definitions
      });
      me.fn = compiler.compile(me.html);
    }
    try {
      me.fn(out, values, parent || me.emptyObj, 1, 1);
    } catch (e) {
      typeof console !== "undefined" && console.log("Error: " + e.message);
    }
    return out;
  },
  compile() {
    return this;
  },
  insertFirst() {
  },
  insertBefore() {
  },
  insertAfter() {
  },
  append() {
  },
  doInsert() {
  },
  overwrite() {
  }
};
export { Tpl as default };
