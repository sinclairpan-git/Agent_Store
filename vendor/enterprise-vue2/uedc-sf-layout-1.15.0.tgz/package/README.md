# @uedc/sf-layout

UI 4.0 布局组件库 [在线文档链接](http://uedc.sangfor.org/common/docs/sf-layout/sf-layout-card/)

## 快速使用

#### npm 安装

```bash
yarn add @uedc/sf-layout -D
```

#### 代码引入

```js
import Vue from 'vue';
import SfLayout from '@uedc/sf-layout';
import '@uedc/sf-layout/dist/themes/standard.css';

Vue.use(SfLayout);
```

#### 全局配置

```js
// 默认配置
const layoutConfig = {
    // 配置页面类型布局的初始默认值
    page: {
        // 布局的配置：包含最小高度
        minHeight: 500,
    },

    // 两列布局
    twoColumn: {
        // 默认右侧固定左侧自适应
        fixedType: 'right',

        // 左侧固定时，左侧默认宽度
        leftDefaultWidth: 240,

        // 右侧固定式，右侧默认宽度
        rightDefaultWidth: 324,

        // 左和右侧之间间距
        containerSpacing: 4,
    },

    mixin: {
        // 是否使用原生滚动条
        nativeScroll: false,
    },
};

// 初始化的时候传入全局配置，会与默认配置合并
Vue.use(SfLayout, {
    layout: layoutConfig,
});
```

## 调试、写文档

```bash

# 打开 vuepress 文档调试
yarn docs:dev

# 另起一个命令行 监听 __demo__ 与 __docs__ 目录变化，生成文档
yarn docs:gen:watch
```

## 构建

```bash
# 安装依赖
yarn install

# 代码检查
yarn lint

# 打包
yarn build
```

## FAQ

#### 不使用虚拟的滚动条，想用原生的滚动条怎么办？

组件可单独配置 `nativeScroll` 为 `false`，也可以作为全局配置初始化的时候传入
