import components from './layout/index';

/**
 * 安装接口
 * @param {Vue} Vue
 * @param {{}} [opts] - 配置
 */
const install = function(Vue, opts = {}) {
    components.forEach(component => {
        if (typeof component.install === 'function') {
            component.install(Vue, opts);
        } else {
            Vue.component(component.name, component);
        }
    });
};

export { install };

export * from './layout/index';
