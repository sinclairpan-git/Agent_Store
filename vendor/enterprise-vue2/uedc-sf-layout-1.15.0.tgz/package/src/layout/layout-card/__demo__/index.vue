<template>
    <sf-layout-card>
        <sf-title slot="header"
                  font-size="l">
            卡片标题
        </sf-title>
        <div class="previewer-demo-overflow">
            内容区域
        </div>
        <sf-button slot="footer">
            底部按钮
        </sf-button>
    </sf-layout-card>
</template>
