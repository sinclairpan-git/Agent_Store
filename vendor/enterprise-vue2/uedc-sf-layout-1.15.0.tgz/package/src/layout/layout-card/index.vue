<template>
    <div :class="[
             getPrefixedClassName('sf-layout-card'),
             {
                 [getPrefixedClassName('sf-layout-card--has-header')]: $slots.header,
                 [getPrefixedClassName('sf-layout-card--has-footer')]: $slots.footer,
                 [getPrefixedClassName('sf-layout-card--inline')]: config && config.isInline,
                 ...noPaddingClass,
                 ...shadowClass
             }
         ]"
         :style="style">
        <div v-if="$slots.header"
             :class="[
                 getPrefixedClassName('sf-layout-card__header'),
                 {
                     ...noPaddingXClass
                 }
             ]">
            <slot name="header"></slot>
        </div>
        <sf-layout-scrollbar :class="[
                                 getPrefixedClassName('sf-layout-card__content'),
                                 {
                                     ...noPaddingXClass
                                 }
                             ]"
                             :view-class="getPrefixedClassName('sf-layout-card__content-inner')"
                             v-bind="scrollbarConfig">
            <slot></slot>
        </sf-layout-scrollbar>
        <div v-if="$slots.footer"
             :class="getPrefixedClassName('sf-layout-card__footer')">
            <slot name="footer"></slot>
        </div>
    </div>
</template>

<script>
/**
 * @file 卡片容器
 */

import layoutMixin from '../layout-mixin';

export default {
    name: 'SfLayoutCard',

    componentName: 'SfLayoutCard',

    mixins: [layoutMixin],

    props: {
        config: {
            type: Object,
            default: () => ({}),
        },
    },

    computed: {
        style() {
            let { width, height } = this.config;

            return {
                ...(width
                    ? {
                          width,
                      }
                    : {}),
                ...(height
                    ? {
                          height,
                      }
                    : {}),
            };
        },
    },
};
</script>
