<template>
    <sf-layout-tree-page>
        <sf-title slot="title"
                  font-size="l">
            包含内部左右布局sf-layout-two-column：上标题+左右结构+tab适用+内页也是左右布局
        </sf-title>
        <div slot="tree"
             class="previewer-demo-overflow-y">左树结构</div>
        <sf-title slot="subtitle"
                  size="large"
                  font-size="xl"
                  no-border>
            sf-layout-two-column
        </sf-title>
        <sf-layout-two-column>
            <div slot="left-content"
                 class="previewer-demo-overflow">左侧内容</div>
            <div slot="right-content"
                 class="previewer-demo-overflow">右侧内容</div>
        </sf-layout-two-column>
    </sf-layout-tree-page>
</template>
