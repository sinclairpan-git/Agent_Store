<template>
    <div :class="getPrefixedClassName('sf-layout-two-column')">
        <sf-layout-scrollbar :class="getPrefixedClassName('sf-layout-two-column__left')"
                             :style="leftStyles"
                             :view-class="getPrefixedClassName('sf-layout-two-column__left-inner')"
                             v-bind="scrollbarConfig">
            <slot name="left-content"></slot>
        </sf-layout-scrollbar>
        <sf-layout-scrollbar :class="getPrefixedClassName('sf-layout-two-column__right')"
                             :style="rightStyles"
                             :view-class="getPrefixedClassName('sf-layout-two-column__right-inner')"
                             v-bind="scrollbarConfig">
            <slot name="right-content"></slot>
        </sf-layout-scrollbar>
    </div>
</template>

<script>
/**
 * @file 内容区域对应两列-左右布局
 */

import { getDefaultConfig } from '../config';
import layoutMixin from '../layout-mixin';

export default {
    name: 'SfLayoutTwoColumn',

    componentName: 'SfLayoutTwoColumn',

    mixins: [layoutMixin],

    props: {
        /**
         * 左侧固定右侧宽度自适应，则fixedType为left
         */
        fixedType: {
            type: String,
            default() {
                return getDefaultConfig().twoColumn.fixedType;
            },
            validator: value => ['left', 'right'].includes(value),
        },

        /**
         * 固定侧宽度
         */
        fixedWidth: {
            type: [Number, String],
            default() {
                let { leftDefaultWidth, rightDefaultWidth } = getDefaultConfig().twoColumn;
                return this.fixedType === 'left' ? leftDefaultWidth : rightDefaultWidth;
            },
        },
    },

    computed: {
        style() {
            let { containerSpacing } = getDefaultConfig().twoColumn;
            let isFixedLeft = this.fixedType === 'left';
            let fixedWidth = isNaN(Number(this.fixedWidth)) ? this.fixedWidth : this.fixedWidth + 'px';
            let selfAdaptionWidth = `calc(100% - ${fixedWidth} - ${containerSpacing}px)`;

            return {
                leftWidth: isFixedLeft ? fixedWidth : selfAdaptionWidth,
                rightWidth: isFixedLeft ? selfAdaptionWidth : fixedWidth,
            };
        },

        leftStyles() {
            return {
                width: this.style.leftWidth,
            };
        },

        rightStyles() {
            return {
                width: this.style.rightWidth,
            };
        },
    },
};
</script>