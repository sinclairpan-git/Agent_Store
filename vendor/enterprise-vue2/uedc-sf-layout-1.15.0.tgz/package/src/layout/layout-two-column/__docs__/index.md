## Props

| Name         | Description                                  | Type    | Required | Default |
| ------------ | -------------------------------------------- | ------- | -------- | ------- | ------- |
| `fixedType`  | 左侧固定右侧宽度自适应，则 fixedType 为 left | `left   | right`   | `false` | `right` |
| `fixedWidth` | 固定侧宽度                                   | `number | string`  | `false` | `324`   |

## Slots

| Name            | Description | Default Slot Content |
| --------------- | ----------- | -------------------- |
| `left-content`  | 左侧内容    | -                    |
| `right-content` | 右侧内容    | -                    |

### 继承自 Mixin

#### Props

| Name           | Description                                                              | Type      | Default |
| -------------- | ------------------------------------------------------------------------ | --------- | ------- |
| `noPaddingX`   | 左右间距                                                                 | `Boolean` | `false` |
| `noPaddingY`   | 上下间距                                                                 | `Boolean` | `false` |
| `shadow`       | 阴影                                                                     | `Boolean` | `true`  |
| `resizeScroll` | 监听滚动条容器尺寸变化，动态改变滚动条高度（当容器尺寸会变化时需要配置） | `Boolean` | `false` |
| `nativeScroll` | 使用原生的滚动条                                                         | `Boolean` | `false` |
| `showScrollX`  | 是否显示横向滚动条（配置成原生的滚动条生效）                             | `Boolean` | `true`  |
| `showScrollY`  | 是否显示纵向滚动条 （配置成原生的滚动条生效）                            | `Boolean` | `true`  |
