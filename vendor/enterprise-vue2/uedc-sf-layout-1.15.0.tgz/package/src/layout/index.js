/**
 * @file 布局组件的入口文件
 */

import LayoutFrame from './layout-frame/frame.vue';
import LayoutHeader from './layout-frame/header.vue';
import LayoutBanner from './layout-frame/banner.vue';
import LayoutMain from './layout-frame/main.vue';
import LayoutTwoColumn from './layout-two-column/index.vue';
import LayoutContent from './layout-content/index.vue';
import LayoutTreeContainer from './layout-tree-container/index.vue';
import LayoutTreePage from './layout-tree-page/index.vue';
import LayoutPage from './layout-page/index.vue';
import LayoutCard from './layout-card/index.vue';
import { updateConfig } from './config';

let Components = [
    LayoutFrame,
    LayoutHeader,
    LayoutBanner,
    LayoutMain,
    LayoutTreePage,
    LayoutPage,
    LayoutTwoColumn,
    LayoutCard,
    LayoutContent,
    LayoutTreeContainer,
];

Components.forEach(item => {
    item.install = function (Vue, opts = {}) {
        updateConfig(opts?.layout || {});
        Vue.component(item.name, item);
    };
});

export default Components;

export {
    LayoutFrame,
    LayoutHeader,
    LayoutBanner,
    LayoutMain,
    LayoutTwoColumn,
    LayoutContent,
    LayoutTreeContainer,
    LayoutTreePage,
    LayoutPage,
    LayoutCard,
    updateConfig,
};
