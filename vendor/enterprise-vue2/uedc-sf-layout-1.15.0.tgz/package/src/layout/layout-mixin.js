/**
 * @file 用于页面布局的mixin，是否有滚动条
 */

import SfLayoutScrollbar from './components/scrollbar';
import SfLayoutResize from './components/sf-layout-resize.vue';
import SfLayoutNoMarginResize from './components/sf-layout-no-margin-resize.vue';
import { getDefaultConfig, getPrefixedClassName } from './config';

export default {
    components: {
        SfLayoutScrollbar,
        SfLayoutResize,
        SfLayoutNoMarginResize
    },

    props: {
        showScrollX: {
            type: Boolean,
            default: true,
        },

        showScrollY: {
            type: Boolean,
            default: true,
        },

        noPaddingX: {
            type: Boolean,
            default: false,
        },

        noPaddingY: {
            type: Boolean,
            default: false,
        },

        shadow: {
            type: Boolean,
            default: true,
        },

        nativeScroll: {
            type: Boolean,
            default() {
                return getDefaultConfig().mixin.nativeScroll;
            },
        },

        resizeScroll: {
            type: Boolean,
            default: false,
        },
    },

    computed: {
        scrollbarConfig() {
            return {
                native: this.nativeScroll,
                noresize: !this.resizeScroll,
                showScrollX: this.showScrollX,
                showScrollY: this.showScrollY,
            };
        },

        noPaddingYClass() {
            return {
                [getPrefixedClassName('sf-layout-no-padding-y')]: this.noPaddingY,
            };
        },

        noPaddingXClass() {
            return {
                [getPrefixedClassName('sf-layout-no-padding-x')]: this.noPaddingX,
            };
        },

        noPaddingClass() {
            return {
                ...this.noPaddingXClass,
                ...this.noPaddingYClass,
            };
        },

        shadowClass() {
            return {
                [getPrefixedClassName('sf-layout-shadow')]: this.shadow,
            };
        },
    },
    methods: {
        getPrefixedClassName
    }
};
