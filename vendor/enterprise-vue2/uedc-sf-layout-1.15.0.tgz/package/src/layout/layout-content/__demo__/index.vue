<template>
    <sf-layout-page>
        <sf-title slot="title"
                  font-size="l">左侧Tab目录 + 内容区域（一般嵌套在 sf-layout-page 内）</sf-title>
        <sf-layout-content :sidebar-collapsed="collapsed">
            <template slot="title">右侧内容标题</template>
            <template slot="sidebar">左侧Tab区域</template>
            <div class="previewer-demo-overflow">
                内容区域
            </div>
            <template slot="footer">
                <button @click="handleClick">点击</button>
            </template>
        </sf-layout-content>
    </sf-layout-page>
</template>

<script>
export default {
    data() {
        return {
            collapsed: false,
        };
    },

    methods: {
        handleClick () {
            this.collapsed = !this.collapsed
        },
    }
};
</script>

<style scoped>
.example {
    display: flex;
    flex-direction: column;
    align-items: center;
    box-sizing: border-box;
    height: 100%;
    padding-top: 16px;
}
</style>