<template>
    <div :class="[getPrefixedClassName('sf-layout-content'), {
            [getPrefixedClassName('sf-layout-content--has-title')]: $slots.title,
            [getPrefixedClassName('sf-layout-content--has-sidebar')]: $slots.sidebar,
            [getPrefixedClassName('sf-layout-content--sidebar-collapsed')]: sidebarCollapsed
         }]">
        <div v-if="$slots.sidebar"
             :class="[getPrefixedClassName('sf-layout-content__sidebar'), {
                 [sfLayoutContentCls.sideBarCls]: true,
                 [getPrefixedClassName('sf-layout-content__sidebar--padding')]: sidebarPadding
             }]"
             :style="sideBarStyle">
            <slot name="sidebar"></slot>
        </div>
        <div :class="[getPrefixedClassName('sf-layout-content__right'), {
                ...noPaddingClass,
                [sfLayoutContentCls.contentCls]: true
             }]">
            <div v-if="$slots.title"
                 :class="[getPrefixedClassName('sf-layout-content__right-title'), {
                    ...noPaddingXClass
                 }]">
                <slot name="title"></slot>
            </div>
            <sf-layout-scrollbar :class="[getPrefixedClassName('sf-layout-content__right-content'), {
                                    ...noPaddingXClass
                                }]"
                                 :view-class="getPrefixedClassName('sf-layout-content__right-content-inner')"
                                 v-bind="scrollbarConfig">
                <slot></slot>
            </sf-layout-scrollbar>
            <div v-if="$slots.footer"
                 :class="getPrefixedClassName('sf-layout-content__right-footer')">
                <slot name="footer"></slot>
            </div>
        </div>
    </div>
</template>
<script>
/**
 * @file 目录+内容区域
 */

import layoutMixin from '../layout-mixin';
import { getPrefixedClassName } from "../config";

export default {
    name: 'SfLayoutContent',

    componentName: 'SfLayoutContent',

    mixins: [layoutMixin],

    props: {
        /**
         * sidebar区域的padding
         */
        sidebarPadding: {
            type: Boolean,
            default: true,
        },
        sidebarCollapsed: {
            type: Boolean,
            default: false
        },
        size: {
            type: String,
            default: 'normal',
            validator: function(value) {
                return ['small', 'normal'].includes(value);
            }
        },
        sidebarWidth: {
            type: String,
        }
    },
    computed: {
        sfLayoutContentCls() {
            if (this.size === 'small') {
                return {
                    sideBarCls: getPrefixedClassName('sf-layout-content__sidebar--small'),
                    contentCls: getPrefixedClassName('sf-layout-content__right--small')
                }
            }
            return {
                sideBarCls: getPrefixedClassName('sf-layout-content__sidebar--normal'),
                contentCls: getPrefixedClassName('sf-layout-content__right--normal')
            }
        },
        sideBarStyle() {
            return {
                ...(this.sidebarWidth ? { width: this.sidebarWidth } : {}),
            };
        },
    }
};
</script>
