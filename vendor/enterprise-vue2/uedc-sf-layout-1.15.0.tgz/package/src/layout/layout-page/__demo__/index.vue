<template>
    <sf-layout-page :show-banner="showBanner">
        <sf-title slot="title"
                  font-size="l">
            上下结构页面布局
        </sf-title>
        <sf-alert slot="banner">这里是 banner 插槽，一般用来放 sf-alert</sf-alert>
        <sf-toolbar slot="toolbar">
            <sf-button>工具栏按钮</sf-button>
        </sf-toolbar>
        <div class="previewer-demo-overflow"
             style="background-color: #fff">内容区域</div>
    </sf-layout-page>
</template>

<script>
export default {
    data() {
        return {
            showBanner: true,
        };
    }
};
</script>