<template>
    <sf-page-wrap>
        <div :class="[getPrefixedClassName('sf-layout-page'), getPrefixedClassName('sf-layout-common-page'), ...pageCls]">
            <div v-if="$slots.title"
                 :class="getPrefixedClassName('sf-layout__title')">
                <slot name="title">
                    {{ config.title }}
                </slot>
            </div>
            <div v-if="showBanner" :class="getPrefixedClassName('sf-layout__banner')">
                <slot name="banner"></slot>
            </div>
            <div v-if="$slots.toolbar"
                 :class="getPrefixedClassName('sf-layout__toolbar')">
                <slot name="toolbar"></slot>
            </div>
            <sf-layout-scrollbar :class="getPrefixedClassName('sf-layout__content')"
                                 :view-class="getPrefixedClassName('sf-layout__content-inner')"
                                 v-bind="scrollbarConfig">
                <slot></slot>
            </sf-layout-scrollbar>
        </div>
    </sf-page-wrap>
</template>

<script>
/**
 * @file 详情页布局-上中下结构
 */

import SfPageWrap from '../components/page-wrap.vue';
import layoutMixin from '../layout-mixin';

export default {
    name: 'SfLayoutPage',

    componentName: 'SfLayoutPage',

    components: {
        SfPageWrap,
    },

    mixins: [layoutMixin],

    props: {
        /**
         * 标题等配置项
         * @readonly
         * @returns {Object} 标题（title）
         */
        config: {
            type: Object,
            default: () => {
                return {
                    title: '',
                };
            },
        },
        showBanner: {
            type: Boolean,
            default: false
        }
    },

    computed: {
        pageCls() {
            const clsList = [];
            const hasToolbar = !!this.$slots.toolbar;
            const hasBanner = !!this.showBanner;

            if (hasToolbar && hasBanner) {
                clsList.push(this.getPrefixedClassName('sf-layout-page--has-all'));
            } else if (hasToolbar) {
                clsList.push(this.getPrefixedClassName('sf-layout-page--has-toolbar'));
            } else if (hasBanner) {
                clsList.push(this.getPrefixedClassName('sf-layout-page--has-banner'));
            } else {
                // do-nothing
            }
            // 保留 no-toolbar 类名，防止业务中有用到，但内部实际样式不用这个类控制
            if (!hasToolbar) {
                clsList.push(this.getPrefixedClassName('sf-layout-page--no-toolbar'));
            }

            return clsList;
        }
    },
};
</script>