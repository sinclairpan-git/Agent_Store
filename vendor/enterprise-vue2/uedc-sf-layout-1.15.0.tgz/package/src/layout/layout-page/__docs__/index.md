## Props

| Name              | Description                                     | Type      | Required | Default |
| ----------------- | ----------------------------------------------- | --------- | -------- | ------- |
| `showBanner`    | 是否显示 banner 区域                       | `Boolean` | `false`  | `false`  |

## Slots

| Name      | Description | Default Slot Content |
| --------- | ----------- | -------------------- |
| `title`   | 标题区域    | -                    |
| `toolbar` | 工具栏区域  | -                    |
| `default` | 内容区域    | -                    |
| `banner` | 横幅提示区域，位于标题和工具栏区域之间 | -                    |


### 继承自 Mixin

#### Props

| Name           | Description                                                              | Type      | Default |
| -------------- | ------------------------------------------------------------------------ | --------- | ------- |
| `noPaddingX`   | 左右间距                                                                 | `Boolean` | `false` |
| `noPaddingY`   | 上下间距                                                                 | `Boolean` | `false` |
| `shadow`       | 阴影                                                                     | `Boolean` | `true`  |
| `resizeScroll` | 监听滚动条容器尺寸变化，动态改变滚动条高度（当容器尺寸会变化时需要配置） | `Boolean` | `false` |
| `nativeScroll` | 使用原生的滚动条                                                         | `Boolean` | `false` |
| `showScrollX`  | 是否显示横向滚动条（配置成原生的滚动条生效）                             | `Boolean` | `true`  |
| `showScrollY`  | 是否显示纵向滚动条 （配置成原生的滚动条生效）                            | `Boolean` | `true`  |
