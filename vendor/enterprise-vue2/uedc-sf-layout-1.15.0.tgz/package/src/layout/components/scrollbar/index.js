// reference https://github.com/noeldelgado/gemini-scrollbar/blob/master/index.js

import { addResizeListener, removeResizeListener } from './resize-event';
import { toObject, getScrollbarWidth } from './util';
import Bar from './bar';
import { getPrefixedClassName } from '../../config';

export default {
    name: 'SfLayoutScrollbar',

    components: { Bar },

    props: {
        showScrollX: {
            type: Boolean,
            default: true,
        },

        showScrollY: {
            type: Boolean,
            default: true,
        },
        native: Boolean,
        wrapStyle: {},
        wrapClass: {},
        viewClass: {},
        viewStyle: {},

        // 如果 container 尺寸不会发生变化，最好设置它可以优化性能
        noresize: {
            type: Boolean,
            default: true
        },

        tag: {
            type: String,
            default: 'div'
        }
    },

    data() {
        return {
            sizeWidth: '0',
            sizeHeight: '0',
            moveX: 0,
            moveY: 0,

            elGutter: {
                right: 0,
                bottom: 0
            }
        };
    },

    computed: {
        wrap() {
            return this.$refs.wrap;
        }
    },

    render(h) {
        if (this.native) {
            return h(
                'div',
                {
                    class: [
                        getPrefixedClassName('sf-layout-scrollbar'),
                        getPrefixedClassName('sf-layout-scrollbar--native'),
                        this.showScrollX && getPrefixedClassName('sf-layout-overflow-x-auto'),
                        this.showScrollY && getPrefixedClassName('sf-layout-overflow-y-auto'),
                    ],
                },
                this.$slots.default,
            );
        }

        let gutter = getScrollbarWidth();
        let style = this.wrapStyle;
        if (gutter && !this.native) {
            const rightGutter = gutter + this.elGutter.right;
            const bottomGutter = gutter + this.elGutter.bottom;
            let gutterStyle = '';

            if (parseFloat(this.sizeWidth)) {
                gutterStyle += `margin-bottom: -${bottomGutter}px;`;
                gutterStyle += `height: calc(100% + ${bottomGutter}px);`;
            }

            if (parseFloat(this.sizeHeight)) {
                gutterStyle += `margin-right: -${rightGutter}px;`;
            }

            if (Array.isArray(this.wrapStyle)) {
                style = toObject(this.wrapStyle);
                style.marginRight = style.marginRight || `-${rightGutter}px`;
                style.marginBottom = style.marginBottom || `-${bottomGutter}px`;
            } else if (typeof this.wrapStyle === 'string') {
                style += gutterStyle;
            } else {
                style = gutterStyle;
            }
        }

        const viewClass = [getPrefixedClassName('sf-layout-scrollbar__view'), this.viewClass];

        if (this.noresize) {
            viewClass.push(getPrefixedClassName('sf-layout-scrollbar__view--fill'));
        }

        const view = h(
            this.tag,
            {
                class: viewClass,
                style: this.viewStyle,
                ref: 'resize'
            },
            this.$slots.default
        );
        const wrap = (
            <div
                ref="wrap"
                style={style}
                onScroll={this.handleScroll}
                class={[
                    this.wrapClass,
                    getPrefixedClassName('sf-layout-scrollbar__wrap'),
                    gutter ? '' : getPrefixedClassName('sf-layout-scrollbar__wrap--hidden-default')
                ]}
            >
                {[view]}
            </div>
        );
        return h('div', { class: getPrefixedClassName('sf-layout-scrollbar') }, [
            wrap,
            this.sizeWidth && <Bar move={this.moveX} size={this.sizeWidth} />,
            this.sizeHeight && <Bar vertical move={this.moveY} size={this.sizeHeight} />
        ]);
    },

    methods: {
        handleScroll() {
            const wrap = this.wrap;

            this.moveY = (wrap.scrollTop * 100) / wrap.clientHeight;
            this.moveX = (wrap.scrollLeft * 100) / wrap.clientWidth;
        },

        update() {
            let heightPercentage;
            let widthPercentage;
            const wrap = this.wrap;
            if (!wrap) return;

            heightPercentage = (wrap.clientHeight * 100) / wrap.scrollHeight;
            widthPercentage = (wrap.clientWidth * 100) / wrap.scrollWidth;

            this.sizeHeight =
                heightPercentage < 100 ? heightPercentage + '%' : '';
            this.sizeWidth = widthPercentage < 100 ? widthPercentage + '%' : '';
        },

        setElGutter () {
            let styles = getComputedStyle(this.$el);
            let pr = parseFloat(styles.paddingRight);
            let pb = parseFloat(styles.paddingBottom);

            if (pr) {
                this.elGutter.right = pr;

            }

            if (pb) {
                this.elGutter.bottom = pb;
            }
        }
    },

    mounted() {
        if (this.native) return;

        this.setElGutter();

        this.$nextTick(this.update);
        !this.noresize && addResizeListener(this.$refs.resize, this.update);
    },

    beforeDestroy() {
        if (this.native) return;
        !this.noresize && removeResizeListener(this.$refs.resize, this.update);
    }
};
