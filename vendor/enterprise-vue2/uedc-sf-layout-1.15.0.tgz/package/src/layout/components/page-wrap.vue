<template>
    <div :class="pageWrapCls">
        <slot></slot>
    </div>
</template>

<script>
/**
 * @file 布局组件外部container
 */
 import { getPrefixedClassName } from '../config';
export default {
    name: 'SfPageWrap',
    computed: {
        pageWrapCls() {
            return ['sf-layout-page-wrap', 'sf-layout-auto-fit-padding'].map(cls => getPrefixedClassName(cls)).join(' ');
        }
    }
};
</script>
