<template>
    <div :class="[getPrefixedClassName('sf-resize-container'), viewClass]"
         @mousedown.self="startListeningMouseMove">
        <div :class="[
                getPrefixedClassName(collapsed ? 'sf-resize-handle-collapsed' : 'sf-resize-handle-expanded'),
                getPrefixedClassName('sf-resize-handle')
             ]"
             @click="handleClick">
            <i :class="[
                  getPrefixedClassName('sf-resize-handle-icon'),
                  { [getPrefixedClassName('sf-resize-handle-icon-collapsed')]: collapsed }
               ]" />
        </div>
        <div :class="[
                getPrefixedClassName('sf-resize-handle-shell'),
                collapsed ? getPrefixedClassName('sf-resize-handle-collapsed-shell') : null
             ]"></div>
    </div>
</template>

<script>
import { getPrefixedClassName } from "../config";
export default {
    name: 'SfLayoutResize',
    componentName: 'SfLayoutResize',
    props: {
        viewClass: {
            type: String,
            required: false,
        },
        changeWidth: {
            type: Function,
            required: true,
        },
        getWidth: {
            type: Function,
            required: true,
        },
        minWidth: {
            type: Number,
            required: true,
        },
        maxWidth: {
            type: Number,
            required: true,
        },
        defaultWidth: {
            type: Number,
            required: true,
        },
        collapsed: {
            type: Boolean,
            required: true,
        },
        collapsedWidth: {
            type: Number,
            required: true,
        },
    },
    data() {
        return { lastX: 0, lastExpandWidth: this.defaultWidth };
    },
    beforeDestroy() {
        this.removeMouseEventListener();
    },
    methods: {
        getPrefixedClassName,
        handleClick() {
            // 收起则展开
            if (this.collapsed) {
                this.changeWidth(this.lastExpandWidth);
                return;
            }
            // 展开则收起
            this.lastExpandWidth = this.getWidth();
            this.changeWidth(this.collapsedWidth);
        },
        startListeningMouseMove(event) {
            event.preventDefault();
            this.lastX = event.pageX;
            this.$emit('before-stretch');
            this.addMouseEventListener();
        },
        handleMouseMove(event) {
            let width = this.getWidth();
            const offSet = event.pageX - this.lastX;
            let newWidth = this.isValidWidth(width + offSet);
            if (newWidth) {
                this.changeWidth(newWidth);
                this.lastExpandWidth = newWidth;
                this.lastX = event.pageX;
            }
        },
        stopListeningMouseMove() {
            this.$emit('after-stretch');
            this.removeMouseEventListener();
            this.dispatchResize();
        },
        isValidWidth(width) {
            if (width > this.maxWidth) {
                return false;
            }
            if (width < this.minWidth) {
                return false;
            }
            return width;
        },
        addMouseEventListener() {
            document.addEventListener('mousemove', this.handleMouseMove);
            document.addEventListener('mouseup', this.stopListeningMouseMove);
        },
        removeMouseEventListener() {
            document.removeEventListener('mousemove', this.handleMouseMove);
            document.removeEventListener('mouseup', this.stopListeningMouseMove);
        },
        async dispatchResize() {
            await this.$nextTick();
            window.dispatchEvent(new Event('resize'));
        },
    },
};
</script>
