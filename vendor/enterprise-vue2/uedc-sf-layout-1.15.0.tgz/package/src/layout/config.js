/**
 * @file 布局组件统一配置
 */

let isObject = obj => obj && typeof obj === 'object';

function mergeDeep(target, source) {
    if (!isObject(target) || !isObject(source)) {
        return source;
    }

    Object.keys(source).forEach(key => {
        let targetValue = target[key];
        let sourceValue = source[key];

        if (Array.isArray(targetValue) && Array.isArray(sourceValue)) {
            target[key] = targetValue.concat(sourceValue);
        } else if (isObject(targetValue) && isObject(sourceValue)) {
            target[key] = mergeDeep({ ...targetValue }, sourceValue);
        } else {
            target[key] = sourceValue;
        }
    });

    return target;
}

let config = {
    // 配置页面类型布局的初始默认值
    page: {
        // 布局的配置：包含最小高度
        minHeight: 500,
    },

    // 两列布局
    twoColumn: {
        // 默认右侧固定左侧自适应
        fixedType: 'right',

        // 左侧固定时，左侧默认宽度
        leftDefaultWidth: 240,

        // 右侧固定式，右侧默认宽度
        rightDefaultWidth: 324,

        // 左和右侧之间间距
        containerSpacing: 4,
    },

    mixin: {
        nativeScroll: false,
    },

    classNamePrefix: {
        prefix: null,
        preserve: true
    }
};

/**
 * 更新统一配置
 * @param {Object} opts 配置传入的对象
 */
export function updateConfig(opts) {
    mergeDeep(config, opts);
}

export function getDefaultConfig() {
    return config;
}

export function getPrefixedClassName(className) {
    if (!className?.trim()) {
        return '';
    }
    const { prefix, preserve } = getDefaultConfig().classNamePrefix;
    if (prefix) {
        return preserve ? `${prefix}-${className} ${className}` : `${prefix}-${className}`;
    }
    return className;
}
