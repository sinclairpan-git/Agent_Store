<template>
    <sf-layout-frame class="app-page-frame">
        <sf-layout-header class="app-page-header">
            header
        </sf-layout-header>
        <sf-layout-banner class="app-page-banner">
            global banner
        </sf-layout-banner>
        <sf-layout-main class="app-page-main"></sf-layout-main>
    </sf-layout-frame>
</template>

<style>
.app-page-frame {
    height: 100%;
}

.app-page-header {
    height: 52px;
    color: #fff;
    background-color: #242833;
}
.app-page-banner {
    height: 32px;
}

.app-page-main {
    background-color: #f5f5f5;
}
</style>
