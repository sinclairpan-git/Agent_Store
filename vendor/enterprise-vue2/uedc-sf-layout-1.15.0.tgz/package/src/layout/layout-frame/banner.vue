<template>
    <section :class="layoutBannerCls">
        <slot></slot>
    </section>
</template>

<script>
 import { getPrefixedClassName } from '../config';
export default {
    name: 'SfLayoutBanner',
    computed: {
        layoutBannerCls () {
            return getPrefixedClassName('sf-layout-banner')
        }
    }
};
</script>
