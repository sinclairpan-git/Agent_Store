<template>
    <main :class="layoutMainCls" :style="{
        height: height + 'px'
    }">
        <slot></slot>
    </main>
</template>

<script>
/**
 * @file 内容区块
 */

import { getDefaultConfig, getPrefixedClassName } from '../config';

export default {
    name: 'SfLayoutMain',

    props: {
        height: {
            type: Number,
            default () {
                return getDefaultConfig().page.minHeight;
            },
        },
    },
    computed: {
        layoutMainCls () {
            return getPrefixedClassName('sf-layout-main');
        }
    }
};
</script>
