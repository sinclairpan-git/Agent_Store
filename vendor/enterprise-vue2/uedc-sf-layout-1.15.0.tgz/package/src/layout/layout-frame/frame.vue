<template>
    <section :class="layoutFrameCls">
        <slot></slot>
    </section>
</template>

<script>
/**
 * @file 整个页面布局区块
 */
import { getPrefixedClassName } from '../config';
export default {
    name: 'SfLayoutFrame',
    computed: {
        layoutFrameCls () {
            return getPrefixedClassName('sf-layout-frame')
        }
    }
};
</script>
