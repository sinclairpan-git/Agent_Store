<template>
    <header :class="layoutHeaderCls">
        <slot></slot>
    </header>
</template>

<script>
/**
 * @file header区域
 */
import { getPrefixedClassName } from '../config';

export default {
    name: 'SfLayoutHeader',
    computed: {
        layoutHeaderCls () {
            return getPrefixedClassName('sf-layout-header')
        }
    }
};
</script>
