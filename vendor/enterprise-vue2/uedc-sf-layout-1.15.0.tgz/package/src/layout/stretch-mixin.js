/**
 * @file 用于左树布局伸缩的mixin
 */

function propsWidthValidator(val) {
    if (typeof val === 'number') {
        return true;
    }
    if (typeof val === 'string' && !isNaN(val.replace('px', ''))) {
        return true;
    }
    return false;
}

export default {
    props: {
        defaultExpand: {
            type: Boolean,
            default: true,
        },
        allowStretch: {
            type: Boolean,
            default: false,
        },
        maxSidebarWidth: {
            validator: propsWidthValidator,
            default: 400,
        },
        minSidebarWidth: {
            validator: propsWidthValidator,
            default: 240,
        },
        defaultExpandSidebarWidth: {
            validator: propsWidthValidator,
            default: 240,
        },
        collapsedWidth: {
            validator: propsWidthValidator,
            default: 0,
        },
    },
};
