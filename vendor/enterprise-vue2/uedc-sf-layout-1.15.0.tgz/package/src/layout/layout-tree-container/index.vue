<template>
    <div :class="[getPrefixedClassName('sf-layout__tree-container'), {
            [getPrefixedClassName('sf-layout__tree-container--border')]: hasBorder
        }]">
        <template v-if="allowStretch">
            <div :style="{ width: cssWidth }"
                 :class="[getPrefixedClassName('sf-layout__tree-container-side'), 
                         { transition, 'no-padding': !expand }]"
                 @transitionend="onTransitionEnd">
                <sf-layout-scrollbar ref="leftSidebar"
                                     :class="[getPrefixedClassName('sf-layout-overflow-hidden'), 
                                             getPrefixedClassName('sf-layout-scrollbar__tree-container-side--allow-stretch'),
                                             { [getPrefixedClassName('sf-layout__tree-container-side--has-sidebar-title')]: hasSidebarTitle }]"
                                     :view-class="getPrefixedClassName('sf-layout__tree-container-side-inner')"
                                     v-bind="{ ...scrollbarConfig, noresize: false }">
                    <div v-show="expand">
                        <slot name="tree"></slot>
                    </div>
                </sf-layout-scrollbar>
            </div>
            <sf-layout-resize v-if="hasMargin"
                              ref="resizeRef"
                              :change-width="setWidth"
                              :get-width="getWidth"
                              :view-class="viewClass"
                              :max-width="getNumericalWidth(maxSidebarWidth)"
                              :min-width="getNumericalWidth(minSidebarWidth)"
                              :default-width="getNumericalWidth(defaultExpandSidebarWidth)"
                              :collapsed="!expand"
                              :collapsed-width="getNumericalWidth(collapsedWidth)"
                              @before-stretch="handleBeforeStretch"
                              @after-stretch="handleAfterStretch"></sf-layout-resize>
            <sf-layout-no-margin-resize v-else
                                        ref="resizeRef"
                                        :change-width="setWidth"
                                        :get-width="getWidth"
                                        :view-class="viewClass"
                                        :max-width="getNumericalWidth(maxSidebarWidth)"
                                        :min-width="getNumericalWidth(minSidebarWidth)"
                                        :default-width="getNumericalWidth(defaultExpandSidebarWidth)"
                                        :collapsed="!expand"
                                        :collapsed-width="getNumericalWidth(getCollapsedWidth)"
                                        @before-stretch="handleBeforeStretch"
                                        @after-stretch="handleAfterStretch"></sf-layout-no-margin-resize>
        </template>
        <sf-layout-scrollbar v-else
                             ref="leftSidebar"
                             :class="[getPrefixedClassName('sf-layout__tree-container-side'), 
                                     getPrefixedClassName('sf-layout-overflow-hidden'),
                                     { [getPrefixedClassName('sf-layout__tree-container-side--has-sidebar-title')]: hasSidebarTitle }]"
                             :view-class="getPrefixedClassName('sf-layout__tree-container-side-inner')"
                             v-bind="scrollbarConfig">
            <slot name="tree"></slot>
        </sf-layout-scrollbar>
        <div :class="[getPrefixedClassName('sf-layout__tree-container-wrapper'),
                     { ...noPaddingClass, transition: allowStretch && transition }]"
             :style="{ marginLeft: rightSideMarginLeft }">
            <div v-if="$slots.title"
                 :class="getPrefixedClassName('sf-layout__tree-container-title')">
                <slot name="title"></slot>
            </div>
            <sf-layout-scrollbar :class="[getPrefixedClassName('sf-layout__tree-container-content'), 
                                        getPrefixedClassName('sf-layout-overflow-hidden')]"
                                 :view-class="getPrefixedClassName('sf-layout__tree-container-content-inner')"
                                 v-bind="scrollbarConfig">
                <slot></slot>
            </sf-layout-scrollbar>
        </div>
    </div>
</template>

<script>
/**
 * @file 树容器组件
 */
import layoutMixin from '../layout-mixin';
import stretchMixin from '../stretch-mixin';

// 下面的变量与css强相关，慎改
const leftSidebarWidth_noStretch = 240; // 不开启伸缩功能时，左侧的固定宽度
const space = 4; // 左侧内容与右侧内容之间的间隔
const resizeHandleWidth = 12; // 折叠/收起按钮的宽度 ps:此处handle为名词，取"把手，抓手，把柄"之意
const leftSideBarNoMarginBaseWidth = 10; // 无间距折叠时的左树基础宽度

export default {
    name: 'SfLayoutTreeContainer',

    componentName: 'SfLayoutTreeContainer',

    mixins: [layoutMixin, stretchMixin],

    props: {
        hasSidebarTitle: {
            type: Boolean,
            default: true,
        },

        hasBorder: {
            type: Boolean,
            default: false,
        },

        hasMargin: {
            type: Boolean,
            default: true,
        },
    },
    data() {
        return {
            width: 0,
            transition: true,
        };
    },
    computed: {
        expand() {
            return this.width > this.getNumericalWidth(this.getCollapsedWidth);
        },
        cssWidth() {
            return this.width + 'px';
        },
        getCollapsedWidth() {
            return this.hasMargin ? this.collapsedWidth : this.collapsedWidth + leftSideBarNoMarginBaseWidth;
        },
        viewClass() {
            let classGroup = 'sf-layout-resize_side-resize sf-layout-resize_no-margin';
            if (!this.expand) {
                classGroup += ' sf-layout-resize_no-width';
            }
            return classGroup
        },
        rightSideMarginLeft() {
            if (this.allowStretch) {
                if (this.expand) {
                    if (this.hasMargin) {
                        return `${this.width + resizeHandleWidth + space}px`;
                    }
                    return `${this.width}px`;
                }

                if (this.hasMargin) {
                    return `${resizeHandleWidth}px`;
                }

                return `${this.getCollapsedWidth + 1}px`;

            }
            return `${leftSidebarWidth_noStretch + space}px`;
        },
    },
    created() {
        this.width = this.getNumericalWidth(this.defaultExpand ? this.defaultExpandSidebarWidth : this.getCollapsedWidth);
    },
    methods: {
        onTransitionEnd(event) {
            // 由于有0.3s的动画，所以当动画结束之后，触发页面的刷新
            if (event.propertyName === 'width' || event.propertyName === 'left') {
                window.dispatchEvent(new Event('resize'));
            }
        },

        setWidth(width) {
            this.width = width;
        },
        getWidth() {
            return this.width;
        },
        getNumericalWidth(widthVal) {
            if (typeof widthVal === 'number') {
                return widthVal;
            }
            return Number(widthVal.replace('px', ''));
        },
        handleBeforeStretch() {
            this.$emit('before-stretch');
            this.transition = false;
        },
        handleAfterStretch() {
            this.$emit('after-stretch');
            this.transition = true;
        },
    },
};
</script>