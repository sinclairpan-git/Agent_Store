<template>
    <sf-layout-page>
        <sf-title slot="title"
                  font-size="l">
            树容器组件（一般只作为内嵌组件使用，页面级别用sf-layout-tree-page）
        </sf-title>
        <sf-layout-tree-container :has-border="hasBorder"
                                  :has-margin="hasMargin"
                                  :collapsed-width="collapsedWidth"
                                  allow-stretch
                                  :has-sidebar-title="hasSidebarTitle">
            <div slot="tree"
                 class="previewer-demo-overflow-y">
                所以说这里会被放个树
            </div>
            <sf-title slot="title"
                      size="large"
                      font-size="xl"
                      no-border>
                右侧标题
            </sf-title>
            <div class="previewer-demo-overflow">
                <button @click="handleClickBorder">点击切换hasBorder</button>
                <button @click="handleClickTitle">点击切换hasSidebarTitle</button>
                <button @click="handleClickMargin">点击切换hasMargin</button>
                <button @click="handleClickPlus">点击+左树折叠宽度</button>
                <button @click="handleClickMinus">点击-左树折叠宽度</button>
            </div>
        </sf-layout-tree-container>
    </sf-layout-page>
</template>

<script>
export default {
    data() {
        return {
            hasBorder: false,
            hasSidebarTitle: true,
            hasMargin: true,
            collapsedWidth: 0
        };
    },

    methods: {
        handleClickBorder () {
            this.hasBorder = !this.hasBorder
        },
        handleClickTitle () {
            this.hasSidebarTitle = !this.hasSidebarTitle
        },
        handleClickMargin () {
            this.hasMargin = !this.hasMargin;
        },
        handleClickPlus () {
            this.collapsedWidth++;
        },
        handleClickMinus () {
            this.collapsedWidth--;
        }
    },
};
</script>