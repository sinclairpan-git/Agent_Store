<template>
    <sf-page-wrap>
        <div :class="[getPrefixedClassName('sf-layout-tree-page'), getPrefixedClassName('sf-layout-common-page'), ...treePageCls]">
            <div v-if="$slots.title"
                 :class="getPrefixedClassName('sf-layout__title')">
                <slot name="title">
                    {{ config.title }}
                </slot>
            </div>
            <div v-if="showBanner" :class="getPrefixedClassName('sf-layout__banner')">
                <slot name="banner"></slot>
            </div>
            <div v-if="$slots.toolbar"
                 :class="getPrefixedClassName('sf-layout__toolbar')">
                <slot name="toolbar"></slot>
            </div>
            <div :class="getPrefixedClassName('sf-layout__container')">
                <sf-layout-tree-container :has-sidebar-title="hasSidebarTitle"
                                          :allow-stretch="allowStretch"
                                          :default-expand="defaultExpand"
                                          :max-sidebar-width="maxSidebarWidth"
                                          :min-sidebar-width="minSidebarWidth"
                                          :default-expand-sidebar-width="defaultExpandSidebarWidth"
                                          :collapsed-width="collapsedWidth"
                                          :has-margin="hasMargin"
                                          @before-stretch="handleBeforeStretch"
                                          @after-stretch="handleAfterStretch">
                    <template slot="tree">
                        <slot name="tree"></slot>
                    </template>
                    <template v-if="$slots.subtitle"
                              slot="title">
                        <slot name="subtitle"></slot>
                    </template>
                    <slot></slot>
                </sf-layout-tree-container>
            </div>
        </div>
    </sf-page-wrap>
</template>

<script>
/**
 * @file 带有左树结构的格局类布局
 */

import SfPageWrap from '../components/page-wrap.vue';
import layoutMixin from '../layout-mixin';
import stretchMixin from '../stretch-mixin';

export default {
    name: 'SfLayoutTreePage',

    componentName: 'SfLayoutTreePage',

    components: {
        SfPageWrap,
    },

    mixins: [layoutMixin, stretchMixin],

    props: {
        // 是否有sidebar的title
        hasSidebarTitle: {
            type: Boolean,
            default: true,
        },

        hasMargin: {
            type: Boolean,
            default: true,
        },

        /**
         * 标题等配置项
         * @readonly
         * @returns {Object} 包含标题（title）和副标题（subtitle）名称
         */
        config: {
            type: Object,
            default: () => {
                return {
                    title: '',
                    subtitle: '',
                };
            },
        },

        showBanner: {
            type: Boolean,
            default: false
        }
    },

    computed: {
        treePageCls() {
            const clsList = [];
            const hasToolbar = !!this.$slots.toolbar;
            const hasBanner = !!this.showBanner;

            if (hasToolbar && hasBanner) {
                clsList.push(this.getPrefixedClassName('sf-layout-tree-page--has-all'));
            } else if (hasToolbar) {
                clsList.push(this.getPrefixedClassName('sf-layout-tree-page--has-toolbar'));
            } else if (hasBanner) {
                clsList.push(this.getPrefixedClassName('sf-layout-tree-page--has-banner'));
            } else {
                // do-nothing
            }
            // 保留 no-toolbar 类名，防止业务中有用到，但内部实际样式不用这个类控制
            if (!hasToolbar) {
                clsList.push(this.getPrefixedClassName('sf-layout-tree-page--no-toolbar'));
            }

            return clsList;
        }
    },

    methods: {
        handleBeforeStretch() {
            this.$emit('before-stretch');
        },
        handleAfterStretch() {
            this.$emit('after-stretch');
        }
    },
};
</script>