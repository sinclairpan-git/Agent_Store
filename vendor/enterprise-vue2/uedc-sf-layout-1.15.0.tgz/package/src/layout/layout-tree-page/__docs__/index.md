## Props

| Name              | Description                                     | Type      | Required | Default |
| ----------------- | ----------------------------------------------- | --------- | -------- | ------- |
| `hasSidebarTitle` | 左侧树区域是否有标题（配置为 false 没有上间距）  | `Boolean` | `false`  | `true`  |
| `showBanner`    | 是否显示 banner 区域                       | `Boolean` | `false`  | `false`  |

## Slots

| Name       | Description    | Default Slot Content |
| ---------- | -------------- | -------------------- |
| `toolbar`  | 工具栏区域     | -                    |
| `title`    | 顶部标题区域   | -                    |
| `tree`     | 树区域         | -                    |
| `subtitle` | 右侧子标题区域 | -                    |
| `default`  | 内容区域       | -                    |
| `banner` | 横幅提示区域，位于标题和工具栏区域之间 | -                    |

## Events

| Name              | Description                                                              | Default |
| ----------------- | ------------------------------------------------------------------------ | ------- |
| `before-stretch`  | 改变宽度之前触发                                                         | `-`     |
| `after-stretch`   | 改变宽度之后触发                                                         | `-`     |

### 继承自 Mixin

#### Props

| Name           | Description                                                              | Type      | Default |
| -------------- | ------------------------------------------------------------------------ | --------- | ------- |
| `noPaddingX`   | 左右间距                                                                 | `Boolean` | `false` |
| `noPaddingY`   | 上下间距                                                                 | `Boolean` | `false` |
| `shadow`       | 阴影                                                                     | `Boolean` | `true`  |
| `resizeScroll` | 监听滚动条容器尺寸变化，动态改变滚动条高度（当容器尺寸会变化时需要配置） | `Boolean` | `false` |
| `nativeScroll` | 使用原生的滚动条                                                         | `Boolean` | `false` |
| `showScrollX`  | 是否显示横向滚动条（配置成原生的滚动条生效）                             | `Boolean` | `true`  |
| `showScrollY`  | 是否显示纵向滚动条 （配置成原生的滚动条生效）                            | `Boolean` | `true`  |
| `allowStretch` | 是否支持左树折叠伸缩                                                     | `Boolean` | `false` |
| `defaultExpand`| 是否默认展开左树                                                             | `Boolean` | `true` |
| `maxSidebarWidth` | 左树伸缩最大的宽度                                                        | `Number | String` | `400` |
| `minSidebarWidth` | 左树伸缩最小的宽度                                                        | `Number | String` | `240` |
| `defaultExpandSidebarWidth` | 左树默认展开的宽度                                              | `Number | String` | `240` |
| `collapsedWidth`  | 左树收起的宽度                                                            | `Number | String` | `0`   |
| `hasMargin`  | 左树和右边区域内容是否具备间距                                                            | `Boolean` | `true`  |
