<template>
    <sf-layout-tree-page :has-sidebar-title="hasSidebarTitle"
                         allow-stretch
                         :has-margin="hasMargin"
                         :default-expand="true"
                         :show-banner="showBanner"
                         @before-stretch="handleBeforeStretch"
                         @after-stretch="handleAfterStretch">
        <sf-title slot="title"
                  font-size="l">
            左树布局sf-layout-tree-page：左树+表格结构适用
        </sf-title>
        <sf-alert slot="banner">这里是 banner 插槽，一般用来放 sf-alert</sf-alert>
        <sf-toolbar slot="toolbar">
            <button @click="switchMarginType">切换间距模式</button>
        </sf-toolbar>
        <div slot="tree"
             class="previewer-demo-overflow-y">
            左树内容
        </div>
        <template v-if="showSubTitle"
                  slot="subtitle">
            <sf-title size="large"
                      font-size="xl"
                      no-border>
                subtitle
            </sf-title>
        </template>
        <div class="previewer-demo-overflow">
            <sf-checkbox v-model="hasSidebarTitle">
                hasSidebarTitle
            </sf-checkbox>
            <sf-checkbox v-model="showSubTitle">
                showSubTitle
            </sf-checkbox>
            <sf-checkbox v-model="showBanner">
                showBanner
            </sf-checkbox>
        </div>
    </sf-layout-tree-page>
</template>

<script>
export default {
    data() {
        return {
            hasSidebarTitle: true,
            showSubTitle: true,
            showBanner: true,
            hasMargin: true
        };
    },

    methods: {
        handleBeforeStretch () {
            window.console.log('before-stretch 改变宽度之前触发');
        },
        handleAfterStretch () {
            window.console.log('after-stretch 改变宽度之后触发');
        },
        switchMarginType () {
            this.hasMargin = !this.hasMargin;
        }
    }
};
</script>

<style scoped>
.example {
    display: flex;
    flex-direction: column;
    align-items: center;
    box-sizing: border-box;
    height: 100%;
    padding-top: 16px;
}
</style>