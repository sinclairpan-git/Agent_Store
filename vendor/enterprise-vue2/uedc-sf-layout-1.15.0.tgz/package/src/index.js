import { version } from '../package.json';
import { install as installComponent } from './init_component';

/**
 * 注册
 *
 * @param {object} Vue Vue对象
 * @param {object} opts 配置项
 * @returns {object} SfLayout
 */
function install(Vue, opts = {}) {
    // 注册组件
    installComponent(Vue, {
        ...opts
    });
}

export default {
    install,
    version
};

export * from './init_component';
