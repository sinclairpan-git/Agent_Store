# @sxf/er-validator

## 1.2.0 (2025-02-13)

### Minor Changes

- 14788914: chore: 更新主线包发布版本号

## 1.1.0-scp-6111-patch.1 (2024-12-19)

### Patch Changes

- af892e14: fix(validator:validation-functions): 校验器 vsdesc 中包含单引号或反引号的校验信息不再单独提示

## 1.1.0 (2024-08-01)

### Minor Changes

- c15ae678: fix: 文本框长度校验添加考虑 utf8 配置进行校验

### Patch Changes

- Updated dependencies [fe7e3406]
  - @sxf/er-widget@1.1.1

## 1.0.0 (2024-05-13)

### Major Changes

- 7875a24a: feat: eresh1.0 正式版发布

### Patch Changes

- Updated dependencies [9ab15bd4]
- Updated dependencies [2af59f99]
- Updated dependencies [2a3e4504]
- Updated dependencies [ba95de09]
- Updated dependencies [27619a2f]
- Updated dependencies [8197c813]
- Updated dependencies [42a5301a]
- Updated dependencies [db191806]
- Updated dependencies [9ba2738b]
- Updated dependencies [77719cfb]
- Updated dependencies [2ce08330]
- Updated dependencies [4dcd108d]
- Updated dependencies [6e39bddc]
- Updated dependencies [6260bb87]
- Updated dependencies [9b919361]
- Updated dependencies [59e243b3]
- Updated dependencies [4953065a]
- Updated dependencies [340fbf0a]
- Updated dependencies [ba60dc70]
- Updated dependencies [c1256828]
- Updated dependencies [b049d503]
- Updated dependencies [ccb9d0b1]
- Updated dependencies [64b604c2]
- Updated dependencies [ab8d5223]
- Updated dependencies [2068d4e7]
- Updated dependencies [afc6eefe]
- Updated dependencies [cc4d2bf2]
- Updated dependencies [6ee618c0]
- Updated dependencies [a3ae5ee0]
- Updated dependencies [b9af929b]
- Updated dependencies [e86f9574]
- Updated dependencies [6533c596]
- Updated dependencies [4fc7947f]
- Updated dependencies [63818025]
- Updated dependencies [0238b816]
- Updated dependencies [eb88cdca]
- Updated dependencies [4b78d4ed]
- Updated dependencies [95ed3396]
- Updated dependencies [974a4171]
- Updated dependencies [72650ffa]
- Updated dependencies [cc37b1aa]
- Updated dependencies [ba60dc70]
- Updated dependencies [7b2e95ae]
- Updated dependencies [d97114b4]
- Updated dependencies [7875a24a]
- Updated dependencies [c99513d4]
- Updated dependencies [0a66303a]
- Updated dependencies [9099a218]
- Updated dependencies [d2607c2b]
- Updated dependencies [178e5a4b]
- Updated dependencies [33927303]
- Updated dependencies [40e1e10f]
- Updated dependencies [386ea7fa]
- Updated dependencies [d2607c2b]
- Updated dependencies [d2607c2b]
- Updated dependencies [e692c2cc]
- Updated dependencies [77719cfb]
- Updated dependencies [387fc9b5]
- Updated dependencies [5d247376]
- Updated dependencies [9f3d0c43]
- Updated dependencies [4145c62f]
- Updated dependencies [e19e9265]
- Updated dependencies [fc78b913]
- Updated dependencies [1f45755a]
- Updated dependencies [f53b15b0]
- Updated dependencies [4f470494]
- Updated dependencies [2327d438]
- Updated dependencies [cb7bc047]
- Updated dependencies [fc78b913]
  - @sxf/er-widget@1.0.0
  - @sxf/er-config@1.0.0
  - @sxf/er-utils@1.0.0

## 1.0.0-beta.0 (2024-01-17)

### Major Changes

- 0b0e74eb: chore: init beta version release

### Patch Changes

- Updated dependencies [0b0e74eb]
- Updated dependencies [0b0e74eb]
  - @sxf/er-widget@1.0.0-beta.0
  - @sxf/er-config@1.0.0-beta.0
  - @sxf/er-utils@1.0.0-beta.0

## 0.2.0 (2023-12-08)

### Minor Changes

- c9f5e0cf: feat(validator): jquery 和 Eresh 子包之间的依赖全部声明成 peer

### Patch Changes

- Updated dependencies [c9f5e0cf]
- Updated dependencies [c9f5e0cf]
- Updated dependencies [c9f5e0cf]
  - @sxf/er-widget@0.11.0
  - @sxf/er-utils@0.3.0

## 0.1.2 (2023-11-24)

### Patch Changes

- f0155cb2: fix(validator): maxLength 优先级要高于 textOptions.maxLength
- Updated dependencies [55af86e7]
- Updated dependencies [c8d6bb26]
- Updated dependencies [4dd80aab]
- Updated dependencies [542ae705]
  - @sxf/er-widget@0.10.1
  - @sxf/er-config@0.2.1

## 0.1.1 (2023-09-04)

### Patch Changes

- d095c5a: fix(validator:validation-functions): 修改 vmname 校验规则，新增支持空格

## 0.1.0 (2023-08-18)

### Minor Changes

- b597743: build: er-config 和 er-style 改为 peer 依赖

### Patch Changes

- Updated dependencies [b597743]
  - @sxf/er-widget@0.3.0
  - @sxf/er-utils@0.1.0

## 0.0.19 (2023-07-27)

### Patch Changes

- Updated dependencies [c8162dd]
  - @sxf/er-widget@0.2.5

## 0.0.18 (2023-07-26)

### Patch Changes

- Updated dependencies [dbb94fa]
- Updated dependencies [e7b0bf4]
- Updated dependencies [a9f8da5]
  - @sxf/er-widget@0.2.4

## 0.0.17 (2023-07-12)

### Patch Changes

- fd66168: fix: pkg 中的依赖补全
- Updated dependencies [fd66168]
  - @sxf/er-widget@0.2.3

## 0.0.15 (2023-07-11)

### Patch Changes

- 5f48871: feat: 修改 workspace 依赖包版本
- Updated dependencies [5f48871]
  - @sxf/er-utils@0.0.15

## 0.0.14 (2023-06-09)

### Patch Changes

- 4701fcb: feat: 添加 module 字段导出
- Updated dependencies [4701fcb]
  - @sxf/er-config@0.0.9
  - @sxf/er-utils@0.0.13

## 0.0.13 (2023-05-16)

### Patch Changes

- 800ea0a: fix(comp:form): 修复表单组件动态修改 disable 时校验规则不更新的问题
- Updated dependencies [62f2915]
  - @sxf/er-utils@0.0.11

## 0.0.12 (2023-05-15)

### Patch Changes

- 57f95f2: feat(utils:ip): 把 validator 中的 ip 解析相关内容放到 utils/ip 包下
- 25abf45: refactor(comp:form): 表单校验重构

  - SfForm 取消绑定 vtype，实现脱离 dom 元素校验
  - 各表单组件校验失败的红显逻辑放在组件内部实现

- Updated dependencies [57f95f2]
- Updated dependencies [25abf45]
- Updated dependencies [e4dab5f]
  - @sxf/er-utils@0.0.10

## 0.0.11 (2023-05-12)

### Patch Changes

- Updated dependencies [a119fa7]
  - @sxf/er-utils@0.0.9

## 0.0.10 (2023-04-23)

### Patch Changes

- 7e2d09e: refactor(validator:vtype): 配合 jQuery 插件 hint 挂载方式的修改
- Updated dependencies [7e2d09e]
  - @sxf/er-config@0.0.7
  - @sxf/er-utils@0.0.8

## 0.0.9 (2023-04-21)

### Patch Changes

- 87d27cc: fix: 修复依赖 i18n 初始化的问题

## 0.0.8 (2023-04-18)

### Patch Changes

- 047cc95: refactor(validator:\*): 校验信息 text 改为函数调用获取

## 0.0.7 (2023-04-17)

### Patch Changes

- Updated dependencies [b1158d4]
  - @sxf/er-config@0.0.6
  - @sxf/er-utils@0.0.7

## 0.0.6 (2023-04-14)

### Patch Changes

- Updated dependencies [9e25dc7]
  - @sxf/er-utils@0.0.6

## 0.0.5 (2023-04-13)

### Patch Changes

- 80ecd83: fix: 修复构建 external 问题
- Updated dependencies [80ecd83]
  - @sxf/er-config@0.0.5
  - @sxf/er-utils@0.0.5

## 0.0.4 (2023-04-12)

### Patch Changes

- eab5ae6: refactor: 提供业务的全局配置接口

  1. `globalConfig.search` 参数对组件全覆盖
  2. 业务中使用到了的 `$.searchInputLimit` 放到 `trigger` 组件来注册
  3. 表格 `headerCeilTip`
  4. `validator` 包提供 `extendValidator` 方法扩展 `vtype`

- Updated dependencies [bde581a]
- Updated dependencies [9876ea5]
- Updated dependencies [9dedad4]
- Updated dependencies [dfce2dc]
- Updated dependencies [c769e65]
- Updated dependencies [95ce2b0]
- Updated dependencies [be1fa10]
- Updated dependencies [dfce2dc]
  - @sxf/er-utils@0.0.4
  - @sxf/er-config@0.0.4

## 0.0.3 (2023-04-03)

### Patch Changes

- f467d2f: build: 使用 tsup 打包 utils, validator 等纯 js 包，生成 d.ts 文件
- 1daafc1: refactor: 去除所有的全局 VMP 与 install 接口
- 419340c: refactor: 将所有获取国际化词条的配置内容不在初始化执行
- 0b96e14: refactor(validator:\*): validator 对外暴露 utils/verify

  - 原 `validator/utils/validate` 重命名为 `validator/utils/verify`
  - `@er/components/_utils/popper` 对外暴露 `PopperJS` 源码

- Updated dependencies [f467d2f]
- Updated dependencies [1daafc1]
- Updated dependencies [419340c]
  - @sxf/er-config@0.0.3
  - @sxf/er-utils@0.0.3

## 0.0.2 (2023-03-29)

### Patch Changes

- release
- Updated dependencies
  - @sxf/er-config@0.0.2
  - @sxf/er-utils@0.0.2

## 0.0.1 (2023-03-29)

### Patch Changes

- chore: release
- Updated dependencies
  - @sxf/er-config@0.0.1
  - @sxf/er-utils@0.0.1
