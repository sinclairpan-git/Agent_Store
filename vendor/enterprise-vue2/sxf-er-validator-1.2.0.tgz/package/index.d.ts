/**
 * 校验并触发回调函数
 *
 * @param {Object} options - 参数对象
 * @param {JQuery<HTMLElement>} [options.element] - 表单元素的jQuery实例，可选
 * @param {Object} options.rule - 规则对象，必选
 * @param {boolean} [options.silent] - 是否静默处理，可选
 * @returns {true|string[]} 校验结果
 */
declare function validate(options: {
    element?: JQuery<HTMLElement> | undefined;
    rule: Object;
    silent?: boolean | undefined;
}): true | string[];
declare function isValid$1(dom: any, sel: any, silent: any): any[];
declare function clearInvalid(dom: any, sel: any): void;

declare namespace _default$1 {
    export { checkInput };
    export { checkError };
    export { isValid };
    export { setVTypeResult };
    export { checkInput as inputVTypeCb };
    export { selectValidator };
    export { selectVTypeCb };
    export { treeselectValidator };
    export { treeselectVTypeCb };
    export { combogridValidator };
    export { combogridVTypeCb };
    export { cascaderVTypeCb };
}

/**
 * 验证输入是否正确
 *
 * @param ret
 * @param el 直接作为vtype的cb函数时不会有el参数
 */
declare function checkInput(ret: any, cfg: any, el: any): void;
/**
 * 对 vtype.isValid 函数返回的结果进行处理
 *
 * @param {{dom: JQuery, isValid: boolean | string[]}[]} errList
 * @param {Function} fn
 */
declare function checkError(errList: {
    dom: JQuery;
    isValid: boolean | string[];
}[], fn: Function): boolean;
declare function isValid(el: any, sel: any, silent: any): true | any[] | undefined;
declare function setVTypeResult($el: any, result: any, hideHint: any): void;
declare function selectValidator(): any;
declare namespace selectValidator {
    export { getSelectValidator as getInstance };
}
declare function selectVTypeCb(result: any): void;
declare function treeselectValidator(): any;
declare namespace treeselectValidator {
    export { getTreeselectValidator as getInstance };
}
declare function treeselectVTypeCb(result: any): void;
declare function combogridValidator(): any;
declare namespace combogridValidator {
    export { getCombogridValidator as getInstance };
}
declare function combogridVTypeCb(result: any): void;
declare function cascaderVTypeCb(result: any): void;
declare function getSelectValidator(opt: any): () => any;
declare function getTreeselectValidator(opt: any): () => any;
declare function getCombogridValidator(opt: any): () => any;

declare const VALIDATE_TIME: 200;

declare function vtype(options: any, ...args: any[]): any;

declare namespace _default {
    export { validateAll };
    export { validateSingle };
}

/**
 * 根据提供的校验配置，进行多次校验
 *
 * @param {Object.<string, Object>} validateCfg - 校验配置对象，目前键是元素选择器，值为校验规则
 * @param {boolean|undefined} silent - 是否对结果不做响应
 * @returns {Array|true} - 格式化后的校验结果数组或true
 */
declare function validateAll(validateCfg: {
    [x: string]: Object;
}, silent: boolean | undefined): any[] | true;
/**
 * 根据提供的校验配置，进行单次校验
 *
 * @param {Object} rule - 校验规则
 * @param {boolean|undefined} silent - 是否对结果不做响应
 * @returns {Array|true} - 格式化后的校验结果数组或true
 */
declare function validateSingle(rule: Object, silent: boolean | undefined): any[] | true;

/**
 * 增加中文字符长度判断，在UTF8中，通常中文字符占三字节，所以一个中文字符长度==3个英文字符长度
 *
 * @param {string} s
 * @return {number}
 */
declare function getUTF8Length(s: string): number;

declare function maskTest(mask: any, key: any, o: any): any;

declare namespace verify {
    function ip(v: any, trim: any): boolean;
    function ipv6(v: string, trim: string): boolean;
    function isDuid(v: string): boolean;
    function isIaid(v: string, isDecimal: boolean): boolean;
    function ipTypeEqual(v1: any, v2: any, trim: any): string | boolean;
    function ipCompare(v1: any, v2: any): number;
    function isIncludeIp(ip: string, rangeArr: string[]): boolean;
    function dns(v: any): boolean | 0;
    function mask(v: string): boolean;
    function prefix(v: any): boolean;
    function port(v: string): boolean;
    function portGroup(v: any): string | true;
    function number(v: string): boolean;
    function mac(v: string): boolean;
    function allMac(v: string): boolean;
    function mtu(v: string): boolean;
    function domain(v: string): boolean;
    function domainip(v: string): boolean;
    function time(v: any): boolean;
    function date(v: any): boolean;
    function vlan(v: any): boolean;
    function emailIP(v: any): any;
    function uuid(v: string): boolean;
    function ipMaskGateway(ip: string, mask: string, gateway: string): boolean;
    function checkIpRangeGateway(ipValue: string, mask: string, gateway: string): boolean;
    function checkNetworkSegment(ip1: string, mask: string | number, ip2: string): boolean;
}
declare function typeVerify(value: any, rule: any): any;

declare function getValidator(type: string): PortValidator;
declare function extendValidator(types: Object): Object;

export { VALIDATE_TIME, clearInvalid, extendValidator, getUTF8Length, getValidator, isValid$1 as isValid, maskTest, _default as pureValidate, typeVerify, validate, _default$1 as validateUtil, verify, vtype };
