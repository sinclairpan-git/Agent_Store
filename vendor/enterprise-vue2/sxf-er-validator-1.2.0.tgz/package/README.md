# @sxf/er-validator

校验相关内容，包括原来的 vtype

```js
import { verify } from '@sxf/er-validator'

verify.ip('192.168.1.1'); // true
```