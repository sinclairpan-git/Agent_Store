// packages/validator/vtype/pureValidate.js
import { $i as $i54 } from "@sxf/er-config";

// packages/validator/vtype/validate.js
import $12 from "jquery";
import { $i as $i53 } from "@sxf/er-config";
import lang2 from "@sxf/er-utils/lang";

// packages/validator/vtype/validateAdapter.js
import $ from "jquery";
import lang from "@sxf/er-utils/lang";
var { isNumber, isFunction, isEmpty } = lang;
var getFullRule = (rule, element) => {
  var _a2, _b2, _c;
  const fullRule = $.extend(true, {}, rule);
  if (!isEmpty(fullRule.maxLength) && !isEmpty(fullRule.textOptions)) {
    fullRule.textOptions.maxLength = fullRule.maxLength;
  }
  if (!isEmpty(fullRule.useUTF8Len) && !isEmpty(fullRule.textOptions)) {
    fullRule.textOptions.useUTF8Len = fullRule.useUTF8Len;
  }
  if (element === void 0 || element === null) {
    return fullRule;
  }
  if (!fullRule.type) {
    fullRule.type = $(element).attr("type");
  }
  fullRule.noValidate = (_a2 = fullRule.noValidate) != null ? _a2 : $(element).is(":disabled");
  if (fullRule.type === "num") {
    fullRule.minValue = (_b2 = fullRule.minValue) != null ? _b2 : getEdgeValueFromAttr(element, "min", fullRule.minValue);
    fullRule.maxValue = (_c = fullRule.maxValue) != null ? _c : getEdgeValueFromAttr(element, "max", fullRule.maxValue);
  }
  if (fullRule.validator) {
    fullRule.validator = fullRule.validator.bind(element);
  }
  return fullRule;
};
var getFieldValue = (fullValidateRules, dom) => {
  if (isFunction(fullValidateRules.getFieldValue)) {
    return fullValidateRules.getFieldValue();
  }
  if (!dom) {
    throw Error("\u6821\u9A8C\u89C4\u5219\u4E2D\u4E0D\u63D0\u4F9BgetFieldValue\u65F6\uFF0C\u5FC5\u987B\u63D0\u4F9B\u5BF9\u5E94\u7684\u8868\u5355\u5143\u7D20");
  }
  return $(dom).val() || "";
};
function getEdgeValueFromAttr(element, attrName, originValue) {
  const stringVal = $(element).attr(attrName);
  if (stringVal) {
    const numberVal = Number(stringVal);
    if (isNumber(numberVal)) {
      return numberVal;
    }
  }
  return originValue;
}

// packages/validator/utils/opr.js
import $2 from "jquery";
function opr(arr, callback) {
  let errList = [];
  $2.each(arr, function(idx, cur) {
    const ret = callback.call(arr, cur);
    if (ret === true) {
      switch (cur.opr) {
        case "&":
          break;
        default:
          errList = true;
          return false;
      }
    } else {
      errList.push(ret);
      if (cur.opr === "|") {
        return true;
      }
      return false;
    }
  });
  return errList;
}
function getOprList(optionsType) {
  const oprList = [];
  const reg = /([\da-zA-Z_\-]+)(\||&)?/g;
  let match;
  while (match = reg.exec(optionsType)) {
    const type = match[1];
    const opr2 = match[2];
    if (!type) {
      break;
    }
    oprList.push({
      value: type,
      opr: opr2
    });
  }
  return oprList;
}

// packages/validator/utils/keycode.js
import UA from "@sxf/er-utils/ua";
function normalizeKey(key) {
  const safariKeys = {
    3: 13,
    // enter
    63234: 37,
    // left
    63235: 39,
    // right
    63232: 38,
    // up
    63233: 40,
    // down
    63276: 33,
    // page up
    63277: 34,
    // page down
    63272: 46,
    // delete
    63273: 36,
    // home
    63275: 35
    // end
  };
  return UA.isWebKit ? safariKeys[key] || key : key;
}
function isNavKeyPress(keyCode) {
  const k = normalizeKey(keyCode);
  return k >= 33 && k <= 40 || // Page Up/Down, End, Home, Left, Up, Right, Down
  k === 13 || // RETURN
  k === 9 || // TAB
  k === 27;
}
function isSpecialKey(keyCode, event) {
  const k = normalizeKey(keyCode);
  return event.type === "keypress" && event.ctrlKey || isNavKeyPress(keyCode) || k === 8 || // Backspace
  k >= 16 && k <= 20 || // Shift, Ctrl, Alt, Pause, Caps Lock
  k >= 44 && k <= 46;
}
function filterKey(event) {
  if (event.ctrlKey && !event.altKey) {
    return true;
  }
  if (event.metaKey) {
    return true;
  }
  const key = normalizeKey(event.keyCode || event.charCode), charCode = String.fromCharCode(event.keyCode || event.charCode);
  if ((UA.isGecko || UA.isOpera) && (isNavKeyPress(event.keyCode) || key === 8 || key === 46 && (event.button ? (UA.isIE ? { 1: 0, 4: 1, 2: 2 } : { 0: 0, 1: 1, 2: 2 })[event.button] : event.which ? event.which - 1 : -1) === -1)) {
    return true;
  }
  if (!UA.isGecko && !UA.isOpera && isSpecialKey(event.keyCode, event) && !charCode) {
    return true;
  }
  return false;
}

// packages/validator/utils/getLength.js
function getUTF8Length(s) {
  let totalLength = 0;
  s = String(s);
  for (let i = 0; i < s.length; i++) {
    const charCode = s.charCodeAt(i);
    if (charCode < 127) {
      totalLength = totalLength + 1;
    } else if (128 <= charCode && charCode <= 2047) {
      totalLength += 2;
    } else if (2048 <= charCode && charCode <= 65535) {
      totalLength += 3;
    }
  }
  return totalLength;
}

// packages/validator/utils/mask.js
function maskTest(mask, key, o) {
  if (mask instanceof RegExp) {
    if (!mask.test(key)) {
      return false;
    }
  } else if (typeof mask === "function") {
    const newMask = mask.call(this, o);
    return maskTest.apply(this, [newMask, key, o]);
  }
  return true;
}

// packages/validator/utils/verify.js
import { $i as $i51 } from "@sxf/er-config";
import format22 from "@sxf/er-utils/format";
import { ipRegex, ipv6Parse as ipv6Parse2 } from "@sxf/er-utils/ip";

// packages/validator/validation-functions/adName.js
import { $i } from "@sxf/er-config";
var adName_default = {
  validate(v, o) {
    const maxLength = o && o.maxLength || 63;
    const maxLengthText = $i("scp.vt_component.common.plugins.jquery.vtype.lib.ad_name.length_of_input_tip", {
      0: maxLength,
      1: Math.floor(maxLength / 3)
    });
    const reg = /[&|"',:%<>/\\]/;
    const regText = $i("scp.vt_component.common.plugins.jquery.vtype.lib.ad_name.input_format_tip");
    if (getUTF8Length(v) > maxLength) {
      return maxLengthText;
    }
    if (reg.test(v)) {
      return regText;
    }
    if (v.length) {
      if (v.charAt(0) === "." || v.substring(0, 2) === ".." && v.charAt(2) !== ".") {
        return $i("scp.vt_component.common.plugins.jquery.vtype.lib.ad_name.invalid_value");
      }
    }
    return true;
  }
};

// packages/validator/validation-functions/allIp.js
import { $i as $i4 } from "@sxf/er-config";
import format3 from "@sxf/er-utils/format";

// packages/validator/validation-functions/ip.js
import { $i as $i2 } from "@sxf/er-config";
import format from "@sxf/er-utils/format";
var m_multicastBegin = format.ip2int("224.0.0.0");
var m_multicastEnd = format.ip2int("239.255.255.255");
var m_classEBegin = format.ip2int("240.0.0.1");
var m_classEEnd = format.ip2int("255.255.255.254");
var m_maxIp = format.ip2int("255.255.255.255");
var getTextConfig = () => {
  return {
    lookbackText: $i2("scp.vt_component.common.plugins.jquery.vtype.lib.ip.loopback_address_err_msg"),
    multicastText: $i2("scp.vt_component.common.plugins.jquery.vtype.lib.ip.multicast_address_err_msg"),
    classEText: $i2("scp.vt_component.common.plugins.jquery.vtype.lib.ip.class_e_ip_address_err_msg"),
    broadcastText: $i2("scp.vt_component.common.plugins.jquery.vtype.lib.ip.broadcast_address_err_msg"),
    hostZeroText: $i2("scp.vt_component.common.plugins.jquery.vtype.lib.ip.network_address_err_msg"),
    zeroBeginText: $i2("scp.vt_component.common.plugins.jquery.vtype.lib.ip.first_octet_err_msg"),
    zeroEndText: $i2("scp.vt_component.common.plugins.jquery.vtype.lib.ip.last_octet_err_msg"),
    "!lookbackText": $i2("scp.vt_component.common.plugins.jquery.vtype.lib.ip.loopback_address_success_msg"),
    "!multicastText": $i2("scp.vt_component.common.plugins.jquery.vtype.lib.ip.multicast_address_success_msg"),
    "!classEText": $i2("scp.vt_component.common.plugins.jquery.vtype.lib.ip.class_e_ip_address_success_msg"),
    "!broadcastText": $i2("scp.vt_component.common.plugins.jquery.vtype.lib.ip.broadcast_address_success_msg"),
    "!hostZeroText": $i2("scp.vt_component.common.plugins.jquery.vtype.lib.ip.network_address_success_msg"),
    "!zeroBeginText": $i2("scp.vt_component.common.plugins.jquery.vtype.lib.ip.valid_ip_address"),
    "!zeroEndText": $i2("scp.vt_component.common.plugins.jquery.vtype.lib.ip.last_octet_success_msg")
  };
};
var validator = {
  // TODO
  /**
   * 网口ip地址、dhcp验证，同后台一致
   */
  sfIp: function(v, nIp, arrIp, o) {
    const items = ["broadcast", "multicast", "classE", "lookback", "zeroBegin", "hostZero"];
    const textConfig = getTextConfig();
    let item;
    for (let i = 0, len = items.length; i < len; i++) {
      item = items[i];
      if (validator[item](v, nIp, arrIp, o)) {
        return textConfig["!" + item + "Text"] || false;
      }
    }
    return true;
  },
  /**
   * 不进行需要mask的验证
   */
  noMaskSfIp: function(v, nIp, arrIp, o) {
    const items = ["multicast", "classE", "lookback", "zeroBegin"];
    const textConfig = getTextConfig();
    let item;
    for (let i = 0, len = items.length; i < len; i++) {
      item = items[i];
      if (validator[item](v, nIp, arrIp, o)) {
        return textConfig["!" + item + "Text"] || false;
      }
    }
    return true;
  },
  // 回环地址
  lookback: function(v, nIp, arrIp) {
    return arrIp[0] === "127";
  },
  // 多播地址
  multicast: function(v, nIp) {
    return nIp >= m_multicastBegin && nIp <= m_multicastEnd;
  },
  // e类地址
  classE: function(v, nIp) {
    return nIp >= m_classEBegin && nIp <= m_classEEnd;
  },
  // 以0开始
  zeroBegin: function(v, nIp, arrIp) {
    return arrIp[0] === "0";
  },
  // 以0结束
  zeroEnd: function(v, nIp, arrIp) {
    return arrIp[3] === "0";
  },
  // 是否是广播地址
  broadcast: function(v, nIp, arrIp, o) {
    let mask = getVar(o.netmask);
    if (mask === void 0) {
      mask = "255.255.255.0";
    }
    const nMask = format.ip2int(mask);
    const nMaxIp = m_maxIp;
    if (nMask === nMaxIp) {
      return nIp === nMaxIp;
    }
    return bitEqual(nIp | nMask, nMaxIp);
  },
  // 主机号是否全0
  hostZero: function(v, nIp, arrIp, o) {
    let mask = getVar(o.netmask);
    if (mask === void 0) {
      mask = "255.255.255.0";
    }
    const nMask = format.ip2int(mask);
    const nMaxIp = m_maxIp;
    const nMinIp = 0;
    if (nMask === nMaxIp) {
      return nIp === 0;
    }
    return bitEqual(nIp & ~nMask, nMinIp);
  }
};
var ip_default = {
  /**
   *
   * @param v
   * @param o
   * {
   *      check: 'sfIp, broadcast, multicast, classE, hostZero, zeroBegin, zeroEnd, lookback, !sfIp, !boradcast, !multicast...'  // 检测是否符合这个类型
   *      valid: '1.2.3.4, 2.3.4.5' or /regexp/,  // 白名单，例外的项
   *      invalid: '1.2.3.4, 2.3.4.5' or /regexp/,  // 黑名单，无效的项
   *      sfIpText: '{0}xxx',
   *      broadcastText: '{0}xxx',
   *
   *      checkText: '{0}xxx',
   *
   *      errorText: '{0}xxx'
   *      errText: '{0}xxx'
   * }
   * @returns {Boolean | String}
   */
  validate(v, o) {
    o = o || {};
    o.errorText = o.errorText || o.errText;
    v = format.trim(v);
    let ret = verify.ip(v);
    if (!ret) {
      return getErrorText(o.errorText, v) || false;
    }
    if (o.valid) {
      ret = isStrIn(v, o.valid);
      if (ret) {
        return ret;
      }
    }
    if (o.invalid) {
      ret = isStrIn(v, o.invalid);
      if (ret) {
        return getErrorText(o.invalidText || o.errorText, v) || false;
      }
    }
    if (o.check) {
      const checkText = o.checkText || $i2("scp.vt_component.common.plugins.jquery.vtype.lib.ip.invalid_value");
      const checkList = o.check.split(",");
      const ipArray = v.replace(/\s/g, "").split(".");
      const nIp = format.ip2int(v);
      let isItemValid;
      let item;
      let validateFn;
      for (let i = 0, len = checkList.length; i < len; i++) {
        item = format.trim(checkList[i]);
        validateFn = validator[item.replace("!", "")];
        if (validateFn) {
          isItemValid = validateFn(v, nIp, ipArray, o, item);
          isItemValid = item[0] === "!" ? isItemValid !== true : isItemValid;
          if (isItemValid !== true) {
            const textConfig = getTextConfig();
            const str = typeof isItemValid === "string" ? isItemValid : o[item + "Text"] || textConfig[item + "Text"] || checkText || o.errText;
            if (o.netmask) {
              v = $i2("scp.vt_component.common.plugins.jquery.vtype.lib.ip.specified_ip", {
                0: v,
                1: o.netmask
              });
            }
            return getErrorText(str, v) || false;
          }
        }
      }
    }
    return true;
  },
  getText: () => $i2("scp.vt_component.common.plugins.jquery.vtype.lib.ip.valid_ip_address_text"),
  mask: /[\d\.]/i
};
function getErrorText(str, v) {
  if (str) {
    return str.replace("{0}", v);
  }
}
function isStrIn(v, regExp) {
  let ret = true;
  if (typeof regExp === "string") {
    ret = regExp.indexOf(v) !== -1;
  } else if (Object.prototype.toString(regExp).indexOf("RegExp") !== -1) {
    ret = regExp.test(v);
  }
  return ret;
}
function getVar(arg) {
  if (arg === void 0) {
    return;
  }
  return typeof arg === "function" ? arg() : arg;
}
function bitEqual(a, b) {
  return a >>> 0 === b >>> 0;
}

// packages/validator/validation-functions/ipv6.js
import { $i as $i3 } from "@sxf/er-config";
import format2 from "@sxf/er-utils/format";
import { ipv6Parse } from "@sxf/er-utils/ip";
var TYPES = {
  unspecified: "unspecified",
  linkLocal: "linkLocal",
  multicast: "multicast",
  lookback: "loopback"
};
var getTextConfig2 = () => {
  return {
    unspecifiedText: $i3("scp.vt_component.common.plugins.jquery.vtype.lib.ipv6.err_unspecified_address"),
    lookbackText: $i3("scp.vt_component.common.plugins.jquery.vtype.lib.ipv6.err_lookback_address"),
    multicastText: $i3("scp.vt_component.common.plugins.jquery.vtype.lib.ipv6.err_multicast_address"),
    linkLocalText: $i3("scp.vt_component.common.plugins.jquery.vtype.lib.ipv6.err_link_local_address"),
    unicastText: $i3("scp.vt_component.common.plugins.jquery.vtype.lib.ipv6.err_unicast_address"),
    "!unspecifiedText": $i3("scp.vt_component.common.plugins.jquery.vtype.lib.ipv6.unspecified_address"),
    "!lookbackText": $i3("scp.vt_component.common.plugins.jquery.vtype.lib.ipv6.lookback_address"),
    "!multicastText": $i3("scp.vt_component.common.plugins.jquery.vtype.lib.ipv6.multicast_address"),
    "!linkLocalText": $i3("scp.vt_component.common.plugins.jquery.vtype.lib.ipv6.link_local_address"),
    "!unicastText": $i3("scp.vt_component.common.plugins.jquery.vtype.lib.ipv6.unicast_address")
  };
};
var validator2 = {
  unspecified: function(addr) {
    return addr.range() === TYPES.unspecified;
  },
  lookback: function(addr) {
    return addr.range() === TYPES.lookback;
  },
  multicast: function(addr) {
    return addr.range() === TYPES.multicast;
  },
  linkLocal: function(addr) {
    return addr.range() === TYPES.linkLocal;
  },
  /**
   * 除了TYPES中的类型，其他的都是全球单播地址
   *
   * @param {object} addr
   */
  unicast: function(addr) {
    return ["unspecified", "lookback", "multicast", "linkLocal"].map(function(type) {
      return !validator2[type](addr);
    }).every(Boolean);
  }
};
var ipv6_default = {
  /**
   *
   * @param v
   * @param o
   * {
   *      check: 'unspecified,lookback,multicast...'  // 检测是否符合这个类型
   *      valid: '::1' or /regexp/,  // 白名单，例外的项
   *      invalid: 'FF00::' or /regexp/,  // 黑名单，无效的项
   *      checkText: '{0}xxx',
   *      errText: '{0}xxx'
   * }
   * @returns {Boolean | String}
   */
  validate(v, o) {
    o = o || {};
    v = format2.trim(v);
    let ret = verify.ipv6(v);
    if (!ret) {
      return getErrorText2(o.errText, v) || false;
    }
    if (o.valid) {
      ret = isStrIn2(v, o.valid);
      if (ret) {
        return ret;
      }
    }
    if (o.invalid) {
      ret = isStrIn2(v, o.invalid);
      if (ret) {
        return getErrorText2(o.invalidText || o.errText, v) || false;
      }
    }
    if (o.check) {
      const checkText = o.checkText || $i3("scp.vt_component.common.plugins.jquery.vtype.lib.ipv6.invaild_value");
      const checkList = o.check.split(",");
      let isItemValid, item, validateFn;
      const ipv6Addr = ipv6Parse.parse(v);
      for (let i = 0, len = checkList.length; i < len; i++) {
        item = format2.trim(checkList[i]);
        validateFn = validator2[item.replace("!", "")];
        if (validateFn) {
          isItemValid = validateFn(ipv6Addr);
          isItemValid = item[0] === "!" ? isItemValid !== true : isItemValid;
          if (isItemValid !== true) {
            const textConfig = getTextConfig2();
            if (o.netprefix) {
              v = $i3("scp.vt_component.common.plugins.jquery.vtype.lib.ipv6.specified_ip", {
                0: v,
                1: o.netprefix
              });
            }
            return getErrorText2(
              typeof isItemValid === "string" ? isItemValid : o[item + "Text"] || textConfig[item + "Text"] || checkText || o.errText,
              v
            ) || false;
          }
        }
      }
    }
    return true;
  },
  getText: () => $i3("scp.vt_component.common.plugins.jquery.vtype.lib.ipv6.valid_ip_address_text"),
  mask: /[\d\.\:A-F]/i
};
function getErrorText2(str, v) {
  if (str) {
    return str.replace("{0}", v);
  }
}
function isStrIn2(v, regExp) {
  let ret = true;
  if (typeof regExp === "string") {
    ret = regExp.indexOf(v) !== -1;
  } else if (Object.prototype.toString(regExp).indexOf("RegExp") !== -1) {
    ret = regExp.test(v);
  }
  return ret;
}

// packages/validator/validation-functions/allIp.js
var allIp_default = {
  /**
   * @param v
   * @param o
   * {
   *      // 过滤规则可以单独设置ipv4和ipv6，规则相同可以设为字符串
   *      Check: 'multicast' || {ipv4: 'lookback', ipv6: 'multicast'}  // 检测ipv4/ipv6是否符合这个类型
   *      valid: '1.2.3.4, 2.3.4.5' or /regexp/ || {ipv4: '1.2.3.4', ipv6: 'FF00::'},  // 白名单，例外的项
   *      invalid: '1.2.3.4, 2.3.4.5' or /regexp/ || {ipv4: '1.2.3.4', ipv6: 'FF00::'},  // 黑名单，无效的项
   *      checkText: '{0}xxx' || {ipv4: '{0}xxxx}', ipv6: '{0}xxxx}'},
   *      errText: '{0}xxx'  || {ipv4: '{0}xxxx', ipv6: '{0}xxxx}'}
   *
   *      // 类型校验提示语
   *      sfIpText: '{0}xxx',
   *      broadcastText: '{0}xxx',
   * }
   * @returns {Boolean | String}
   */
  validate(v, o) {
    o = o || {};
    v = format3.trim(v);
    if (verify.ip(v)) {
      return ip_default.validate(v, getOptions(o, "ipv4"));
    }
    if (verify.ipv6(v)) {
      return ipv6_default.validate(v, getOptions(o, "ipv6"));
    }
    return false;
  },
  getText: () => $i4("scp.vt_component.common.plugins.jquery.vtype.lib.all_ip.input_valid_ip_address"),
  mask: /[\d\.\:A-F]/i
};
function getOptions(params, type) {
  const options = {};
  for (const name in params) {
    if (params.hasOwnProperty(name)) {
      const value = params[name];
      if (typeof value === "object") {
        options[name] = value[type];
      } else {
        options[name] = value;
      }
    }
  }
  return options;
}

// packages/validator/validation-functions/date.js
import { $i as $i5 } from "@sxf/er-config";
import format4 from "@sxf/er-utils/format";
var date_default = {
  validate(v, o) {
    let minDate, maxDate;
    v = format4.trim(v);
    const ret = verify.date(v);
    if (!ret) {
      return false;
    }
    const curDate = format4.getTime(v);
    if (o.minValue !== void 0 && o.minValue !== null) {
      if (typeof o.minValue === "number" && !isNaN(o.minValue)) {
        minDate = new Date(o.minValue);
      } else if (typeof o.minValue === "string") {
        minDate = format4.getTime(o.minValue);
      } else if (o.minValue instanceof Date) {
        minDate = o.minValue;
      }
      if (minDate) {
        if (+curDate < +minDate) {
          return o.minValueText || $i5("scp.vt_component.common.plugins.jquery.vtype.lib.date.min_input_value", {
            0: format4.date(minDate, "Y-m-d")
          });
        }
      }
    }
    if (o.maxValue !== void 0 && o.maxValue !== null) {
      if (typeof o.maxValue === "number" && !isNaN(o.maxValue)) {
        maxDate = new Date(o.maxValue);
      } else if (typeof o.maxValue === "string") {
        maxDate = format4.getTime(o.maxValue);
      } else if (o.maxValue instanceof Date) {
        maxDate = o.maxValue;
      }
      if (maxDate) {
        if (+curDate > +maxDate) {
          return o.maxValueText || $i5("scp.vt_component.common.plugins.jquery.vtype.lib.date.max_input_value", {
            0: format4.date(maxDate, "Y-m-d")
          });
        }
      }
    }
    return true;
  },
  getText: () => $i5("scp.vt_component.common.plugins.jquery.vtype.lib.date.input_date"),
  mask: /[\d\-]/i
};

// packages/validator/validation-functions/des.js
import $3 from "jquery";
import { $i as $i6 } from "@sxf/er-config";
var des_default = {
  validate(v, options) {
    options = $3.extend(
      {
        maxLength: 100
      },
      options
    );
    if (getUTF8Length(v) > options.maxLength) {
      return $i6("scp.vt_component.common.plugins.jquery.vtype.lib.des.length_of_input_tip", {
        0: options.maxLength,
        1: Math.floor(options.maxLength / 3)
      });
    }
    const reg = /^[\.\(\)\,\/\!~\:，。！、￥……：；（）【】｛｝“”‘’@\d\u4E00-\u9FA5a-zA-Z_+=\-\s]*$/;
    const regText = $i6("scp.vt_component.common.plugins.jquery.vtype.lib.des.input_format_tip");
    if (!reg.test(v)) {
      return regText;
    }
    return true;
  }
};

// packages/validator/validation-functions/devname.js
import $4 from "jquery";
import { $i as $i7 } from "@sxf/er-config";
var devnameConfig = {
  // maxLength: undefined
};
var devname_default = {
  install(o) {
    devnameConfig = $4.extend(true, {}, devnameConfig, o);
  },
  validate(v, o) {
    const maxLength = o && o.maxLength || devnameConfig.maxLength || 78, maxLengthText = $i7("scp.vt_component.common.plugins.jquery.vtype.lib.devname.length_of_input_tip", {
      0: maxLength,
      1: Math.floor(maxLength / 3)
    }), reg = /^[\.\d\u4E00-\u9FA5a-zA-Z_\-\s]+$/, regText = $i7("scp.vt_component.common.plugins.jquery.vtype.lib.devname.input_format_tip");
    if (getUTF8Length(v) > maxLength) {
      return maxLengthText;
    }
    if (!reg.test(v)) {
      return regText;
    }
    if (/^\./.test(v)) {
      return $i7("scp.vt_component.common.plugins.jquery.vtype.lib.devname.cannot_begin_with_dot");
    }
    return true;
  }
};

// packages/validator/validation-functions/dns.js
import { $i as $i8 } from "@sxf/er-config";
import format5 from "@sxf/er-utils/format";
var dns_default = {
  validate(v) {
    v = format5.trim(v);
    return verify.dns(v);
  },
  getText: () => $i8("scp.vt_component.common.plugins.jquery.vtype.lib.dns.valid_dns_server_address"),
  mask: /[\d\.]/i
};

// packages/validator/validation-functions/domain.js
import { $i as $i9 } from "@sxf/er-config";
import format6 from "@sxf/er-utils/format";
var domain_default = {
  validate(v) {
    v = format6.trim(v);
    if (!/\./.test(v)) {
      return $i9("scp.vt_component.common.plugins.jquery.vtype.lib.domain.dot_is_required");
    }
    if (/^\./.test(v)) {
      return $i9("scp.vt_component.common.plugins.jquery.vtype.lib.domain.cannot_begin_with_dot");
    }
    const domainList = v.split(".");
    const baseDomain = domainList.pop() || domainList.pop();
    const baseDomainRegex = /^\d+$/g, baseDomainMinLength = 2, maxLength = 255;
    if (baseDomain.length < baseDomainMinLength) {
      return $i9("scp.vt_component.common.plugins.jquery.vtype.lib.domain.least_two_characters_for_top_level_domain");
    }
    if (baseDomainRegex.test(baseDomain)) {
      return $i9("scp.vt_component.common.plugins.jquery.vtype.lib.domain.top_level_domain_cannot_contain_digits_only");
    }
    if (!v.length || v.length > maxLength) {
      return $i9("scp.vt_component.common.plugins.jquery.vtype.lib.domain.characters_length");
    }
    return verify.domain(v);
  },
  getText: () => $i9("scp.vt_component.common.plugins.jquery.vtype.lib.domain.domain_format"),
  mask: /[\da-zA-Z\.-]/i
};

// packages/validator/validation-functions/domainip.js
import { $i as $i10 } from "@sxf/er-config";
var domainip_default = {
  validate(v) {
    const MAX_LENGTH = 256;
    if (getUTF8Length(v) > MAX_LENGTH) {
      return $i10("scp.vt_component.common.plugins.jquery.vtype.lib.domainip.domain_max_length");
    }
    return verify.domainip(v);
  },
  getText: () => $i10("scp.vt_component.common.plugins.jquery.vtype.lib.domainip.valid_url_or_ip_address")
};

// packages/validator/validation-functions/duid.js
import { $i as $i11 } from "@sxf/er-config";
var duid_default = {
  /**
   * duid校验
   *
   * @param {string} value
   * @param {object} opt
   * @returns {boolean | array}
   */
  validate(value, opt) {
    opt = opt || {};
    if (verify.isDuid(value) !== true) {
      return opt.errText || false;
    }
    return true;
  },
  getText: () => $i11("scp.vt_component.common.plugins.jquery.vtype.lib.duid.vaild_uuid"),
  mask: /[a-fA-F\d\:\-]/
};

// packages/validator/validation-functions/eipname.js
import { $i as $i12 } from "@sxf/er-config";
var eipname_default = {
  validate(v) {
    const maxLength = 78, maxLengthText = $i12("scp.vt_component.common.plugins.jquery.vtype.lib.eipname.max_length_text"), reg = /^[\.\d\u4E00-\u9FA5a-zA-Z_\-\s]+$/, regText = $i12("scp.vt_component.common.plugins.jquery.vtype.lib.eipname.value_format");
    if (getUTF8Length(v) > maxLength) {
      return maxLengthText;
    }
    if (!reg.test(v)) {
      return regText;
    }
    if (/^\./.test(v)) {
      return $i12("scp.vt_component.common.plugins.jquery.vtype.lib.eipname.cannot_begin_with_dot");
    }
    return true;
  }
};

// packages/validator/validation-functions/hostName.js
import { $i as $i13 } from "@sxf/er-config";
var hostName_default = {
  validate(v) {
    const maxLength = 30, maxLengthText = $i13("scp.vt_component.common.plugins.jquery.vtype.lib.host_name.max_length_text", {
      0: maxLength
    }), reg = /^[a-zA-Z0-9\-]+$/, regText = $i13("scp.vt_component.common.plugins.jquery.vtype.lib.host_name.value_format");
    if (getUTF8Length(v) > maxLength) {
      return maxLengthText;
    }
    if (!reg.test(v)) {
      return regText;
    }
    return true;
  }
};

// packages/validator/validation-functions/http.js
import { $i as $i14 } from "@sxf/er-config";
import format7 from "@sxf/er-utils/format";
var MIN_LEN = 10;
var MAX_LEN = 100;
var http_default = {
  validate(v, o) {
    const value = format7.trim(v), httpRegWithoutZh = /^https?\:\/\/(\w|[\:#\&\=\-\?\.\\\/\{\}])+$/i, httpReg = /^https?\:\/\/([a-zA-Z0-9_\u4e00-\u9fa5]|[\:#\&\=\-\?\.\\\/\{\}])+$/i, len = getUTF8Length(value), minLen = o.minLength || MIN_LEN, maxLen = o.maxLength || MAX_LEN, withoutZhErrMsg = $i14("scp.vt_component.common.plugins.jquery.vtype.lib.http.url_winthout_zh_error_msg", {
      0: minLen,
      1: maxLen
    }), errMsg = $i14("scp.vt_component.common.plugins.jquery.vtype.lib.http.url_error_msg", {
      0: minLen,
      1: maxLen,
      2: Math.floor(minLen / 3),
      3: Math.floor(maxLen / 3)
    });
    if (len < minLen || len > maxLen) {
      return o.withoutZh ? withoutZhErrMsg : errMsg;
    }
    if (o.withoutZh) {
      return httpRegWithoutZh.test(value) ? true : withoutZhErrMsg;
    }
    return httpReg.test(value) ? true : errMsg;
  }
};

// packages/validator/validation-functions/iaid.js
import { $i as $i15 } from "@sxf/er-config";
var iaid_default = {
  /**
   * iaid校验
   *
   * @param {string} value
   * @param {object} o  {isDecimal: boolean}
   * @returns {boolean | array}
   */
  validate(value, o) {
    o = o || {};
    return verify.isIaid(value, o.isDecimal);
  },
  getText: () => $i15("scp.vt_component.common.plugins.jquery.vtype.lib.iaid.vaild_iaid"),
  mask: /[a-fA-F0-9]/
};

// packages/validator/validation-functions/icmp.js
import { $i as $i16 } from "@sxf/er-config";
import format8 from "@sxf/er-utils/format";
var getIcmpMessage = () => {
  return [
    {
      type: 0,
      code: 0,
      query: 1,
      error: 0,
      desc_eng: "Echo Reply",
      desc_cha: $i16("scp.vt_component.common.util.icmp.ba.echo_reply")
    },
    {
      type: 3,
      code: 0,
      query: 0,
      error: 1,
      desc_eng: "Network Unreachable",
      desc_cha: $i16("scp.vt_component.common.util.icmp.network_unreachable")
    },
    {
      type: 3,
      code: 1,
      query: 0,
      error: 1,
      desc_eng: "Host Unreachable",
      desc_cha: $i16("scp.vt_component.common.util.icmp.host_unreachable")
    },
    {
      type: 3,
      code: 2,
      query: 0,
      error: 1,
      desc_eng: "Protocol Unreachable",
      desc_cha: $i16("scp.vt_component.common.util.icmp.protocol_unreachable")
    },
    {
      type: 3,
      code: 3,
      query: 0,
      error: 1,
      desc_eng: "Port Unreachable",
      desc_cha: $i16("scp.vt_component.common.util.icmp.port_unreachable")
    },
    {
      type: 3,
      code: 4,
      query: 0,
      error: 1,
      desc_eng: "Fragmentation needed but no frag bit set",
      desc_cha: $i16("scp.vt_component.common.util.icmp.fragmentation_needed_but_no_frag_bit_set")
    },
    {
      type: 3,
      code: 5,
      query: 0,
      error: 1,
      desc_eng: "Source routing failed",
      desc_cha: $i16("scp.vt_component.common.util.icmp.source_routing_failed")
    },
    {
      type: 3,
      code: 6,
      query: 0,
      error: 1,
      desc_eng: "Destination network unknown",
      desc_cha: $i16("scp.vt_component.common.util.icmp.destination_network_unknown")
    },
    {
      type: 3,
      code: 7,
      query: 0,
      error: 1,
      desc_eng: "Destination host unknown",
      desc_cha: $i16("scp.vt_component.common.util.icmp.destination_host_unknown")
    },
    {
      type: 3,
      code: 9,
      query: 0,
      error: 1,
      desc_eng: "Destination network administratively prohibited",
      desc_cha: $i16("scp.vt_component.common.util.icmp.destination_network_administratively_prohibited")
    },
    {
      type: 3,
      code: 10,
      query: 0,
      error: 1,
      desc_eng: "Destination host administratively prohibited",
      desc_cha: $i16("scp.vt_component.common.util.icmp.destination_host_administratively_prohibited")
    },
    {
      type: 3,
      code: 11,
      query: 0,
      error: 1,
      desc_eng: "Network unreachable for TOS",
      desc_cha: $i16("scp.vt_component.common.util.icmp.network_unreachable_for_tos")
    },
    {
      type: 3,
      code: 12,
      query: 0,
      error: 1,
      desc_eng: "Host unreachable for TOS",
      desc_cha: $i16("scp.vt_component.common.util.icmp.host_unreachable_for_tos")
    },
    {
      type: 3,
      code: 13,
      query: 0,
      error: 1,
      desc_eng: "Communication administratively prohibited by filtering",
      desc_cha: $i16("scp.vt_component.common.util.icmp.communication_administratively_prohibited_by_filtering")
    },
    {
      type: 3,
      code: 14,
      query: 0,
      error: 1,
      desc_eng: "Host precedence violation",
      desc_cha: $i16("scp.vt_component.common.util.icmp.host_precedence_violation")
    },
    {
      type: 3,
      code: 15,
      query: 0,
      error: 1,
      desc_eng: "Precedence cutoff in effect",
      desc_cha: $i16("scp.vt_component.common.util.icmp.precedence_cutoff_in_effect")
    },
    {
      type: 4,
      code: 0,
      query: 0,
      error: 0,
      desc_eng: "Source quench",
      desc_cha: $i16("scp.vt_component.common.util.icmp.source_quench")
    },
    {
      type: 5,
      code: 0,
      query: 0,
      error: 0,
      desc_eng: "Redirect for network",
      desc_cha: $i16("scp.vt_component.common.util.icmp.redirect_for_network")
    },
    {
      type: 5,
      code: 1,
      query: 0,
      error: 0,
      desc_eng: "Redirect for host",
      desc_cha: $i16("scp.vt_component.common.util.icmp.redirect_for_host")
    },
    {
      type: 5,
      code: 2,
      query: 0,
      error: 0,
      desc_eng: "Redirect for TOS and network",
      desc_cha: $i16("scp.vt_component.common.util.icmp.redirect_for_tos_and_network")
    },
    {
      type: 5,
      code: 3,
      query: 0,
      error: 0,
      desc_eng: "Redirect for TOS and host",
      desc_cha: $i16("scp.vt_component.common.util.icmp.redirect_for_tos_and_host")
    },
    {
      type: 8,
      code: 0,
      query: 1,
      error: 0,
      desc_eng: "Echo request",
      desc_cha: $i16("scp.vt_component.common.util.icmp.echo_request")
    },
    {
      type: 9,
      code: 0,
      query: 0,
      error: 0,
      desc_eng: "Router advertisement",
      desc_cha: $i16("scp.vt_component.common.util.icmp.router_advertisement")
    },
    {
      type: 10,
      code: 0,
      query: 0,
      error: 0,
      desc_eng: "Route solicitation",
      desc_cha: $i16("scp.vt_component.common.util.icmp.route_solicitation")
    },
    {
      type: 11,
      code: 0,
      query: 0,
      error: 1,
      desc_eng: "TTL equals 0 during transit",
      desc_cha: $i16("scp.vt_component.common.util.icmp.ttl_equals_zero_during_transit")
    },
    {
      type: 11,
      code: 1,
      query: 0,
      error: 1,
      desc_eng: "TTL equals 0 during reassembly",
      desc_cha: $i16("scp.vt_component.common.util.icmp.ttl_equals_zero_during_reassembly")
    },
    {
      type: 12,
      code: 0,
      query: 0,
      error: 1,
      desc_eng: "IP header bad (catchall error)",
      desc_cha: $i16("scp.vt_component.common.util.icmp.ip_header_bad")
    },
    {
      type: 12,
      code: 1,
      query: 0,
      error: 1,
      desc_eng: "Required options missing",
      desc_cha: $i16("scp.vt_component.common.util.icmp.required_options_missing")
    },
    {
      type: 17,
      code: 0,
      query: 1,
      error: 0,
      desc_eng: "Address mask request",
      desc_cha: $i16("scp.vt_component.common.util.icmp.address_mask_request")
    },
    {
      type: 18,
      code: 0,
      query: 0,
      error: 0,
      desc_eng: "Address mask reply",
      desc_cha: $i16("scp.vt_component.common.util.icmp.address_mask_reply")
    }
  ];
};
function checkIcmp(type, code) {
  if (!type || !code) {
    return false;
  }
  const M_ICMP_MESSAGE = getIcmpMessage();
  let icmp;
  for (let i = 0; i < M_ICMP_MESSAGE.length; i++) {
    icmp = M_ICMP_MESSAGE[i];
    if (icmp.type + "" === type + "" && icmp.code + "" === code + "") {
      return true;
    }
  }
  return false;
}
var icmp_default = {
  validate(v) {
    v = format8.trim(v).replace(/(^[\s;]+)|([\s;]+$)/g, "").replace(/(\s)*;(\s)*/g, ";").replace(/(\s)*,(\s)*/, ",").replace(/(\s)*:(\s)*/g, ":");
    const arr = v.split(";");
    if (arr.length > 6) {
      return $i16("scp.vt_component.common.plugins.jquery.vtype.lib.icmp.value_rule");
    }
    for (let i = 0; i < arr.length; i++) {
      if (!/(^type:\d+,code:\d+$)/.test(arr[i])) {
        return $i16("scp.vt_component.common.plugins.jquery.vtype.lib.icmp.value_format");
      }
    }
    for (let j = 0; j < arr.length; j++) {
      const icmp = arr[j].match(/[\d]+/g);
      if (!checkIcmp(icmp[0], icmp[1])) {
        return $i16("scp.vt_component.common.plugins.jquery.vtype.lib.icmp.error_icmp_type");
      }
    }
    return true;
  }
};

// packages/validator/validation-functions/illegal.js
import { $i as $i17 } from "@sxf/er-config";
var illegal_default = {
  validate(v) {
    return !/[<>?\/|+=^&]/.test(v);
  },
  getText: () => $i17("scp.vt_component.common.plugins.jquery.vtype.lib.illegal.value_rule")
};

// packages/validator/validation-functions/ipRange.js
import $5 from "jquery";
import { $i as $i18 } from "@sxf/er-config";
import format9 from "@sxf/er-utils/format";
var DEFAULT_VISITOR = {
  single: singleFn,
  range: rangeFn,
  subnet: subnetFn
};
var SPLIT_LEN = 2;
var ipRange_default = {
  /**
   * 多行IPv4/IPv6地址范围校验
   *
   * @param {*} value
   * @param {*} option
   * {
   *  mod: 'ipv4','ipv6','all'不配置则为'all'
   *  maxline: 50 最大输入行数
   *  withSubnet: false 是否校验前缀长度如：::/128这种写法
   *  check：ip类型过滤
   *  visitor: {  自定义每种输入类型的校验规则
   *      single: function (node, validateFn, rule) {
   *          ...
   *      },
   *      range: function ...,
   *      subnet: functon ...
   *  }
   * }
   */
  validate(value, option) {
    option = option || {};
    option.mod = option.mod || "all";
    option.maxline = option.maxline || 50;
    option.separator = option.separator || "\n";
    option.visitor = $5.extend({}, DEFAULT_VISITOR, option.visitor);
    return ipRangeMulti(value, option);
  }
};
function trimSplit(separator, str) {
  return str.split(separator).map(function(item) {
    return item.trim();
  });
}
function parse(parts, option) {
  let result = [], array = [];
  parts.forEach(function(part) {
    if (part.indexOf("-") !== -1) {
      array = trimSplit("-", part);
      result.push({
        type: "range",
        parts: array,
        // 原始值
        origin: part,
        // 开始地址
        start: array[0],
        // 结束地址
        end: array[1]
      });
    } else if (part.indexOf("/") !== -1 && option.withSubnet) {
      array = trimSplit("/", part);
      result.push({
        type: "subnet",
        parts: array,
        origin: part,
        prefix: array[1],
        ip: array[0]
      });
    } else {
      result.push({
        type: "single",
        origin: part.trim()
      });
    }
  });
  return result;
}
function ipRangeMulti(value, option) {
  let errList = [], visitor = option.visitor, separator = option.separator, parts = value.split(separator), nodeList;
  if (option.maxline && parts.length > option.maxline) {
    errList.push(
      $i18("scp.vt_component.common.plugins.jquery.vtype.lib.ip_range.max_line_of_ip_address_list", {
        0: option.maxline
      })
    );
    return errList;
  }
  nodeList = parse(parts, option);
  nodeList.forEach(function(node, index) {
    let validateOpt = getValidateFn(option), ipValidateFn = validateOpt.validateFn, ipRule = {
      check: validateOpt.check
    }, ip = node.origin.replace(/(^\s*)|(\s*$)/g, ""), visitorFn = visitor[node.type], errMsg = $i18("scp.vt_component.common.plugins.jquery.vtype.lib.ip_range.line_is_invalid_msg", {
      0: index + 1,
      1: format9.htmlEncode(node.origin)
    }), result;
    if (!ip) {
      return;
    }
    result = visitorFn(node, ipValidateFn, ipRule);
    result !== true && errList.push(
      errMsg + (result || $i18("scp.vt_component.common.plugins.jquery.vtype.lib.ip_range.error_ip_format"))
    );
  });
  return errList.length ? option.combineErr ? errList.join("<br/>") : errList : true;
}
function singleFn(node, validateFn, rule) {
  return validateFn(node.origin, rule);
}
function rangeFn(node, validateFn, rule) {
  let start = node.start, end = node.end;
  if (node.parts.length > SPLIT_LEN) {
    return $i18("scp.vt_component.common.plugins.jquery.vtype.lib.ip_range.ip_range_cannot_contain_multiple_hyphens");
  }
  let rs;
  if ((rs = validateFn(start, rule)) !== true || (rs = validateFn(end, rule)) !== true) {
    return rs;
  }
  if (!verify.ipTypeEqual(start, end)) {
    return $i18("scp.vt_component.common.plugins.jquery.vtype.lib.ip_range.start_and_end_ip_addresses_format");
  }
  if (verify.ipCompare(start, end) !== 1) {
    return $i18("scp.vt_component.common.plugins.jquery.vtype.lib.ip_range.ip_range_rule");
  }
  return true;
}
function subnetFn(node, validateFn, rule) {
  let prefix = node.prefix, ip = node.ip, v4Prefix = {
    min: 1,
    max: 32
  }, v6Prefix = {
    min: 0,
    max: 128
  }, isIPv4;
  if (node.parts.length > SPLIT_LEN) {
    return $i18("scp.vt_component.common.plugins.jquery.vtype.lib.ip_range.ip_range_cannot_contain_multiple_slashes");
  }
  const rs = validateFn(ip, rule);
  if (rs !== true) {
    return rs;
  }
  isIPv4 = verify.ip(ip);
  if (!verify.number(prefix)) {
    return $i18("scp.vt_component.common.plugins.jquery.vtype.lib.ip_range.prefix_length_must_be_digit");
  }
  prefix = parseInt(prefix, 10);
  if (isIPv4 && (prefix > v4Prefix.max || prefix < v4Prefix.min)) {
    return $i18("scp.vt_component.common.plugins.jquery.vtype.lib.ip_range.netmask_format", {
      0: v4Prefix.min,
      1: v4Prefix.max
    });
  }
  if (!isIPv4 && (prefix < v6Prefix.min || prefix > v6Prefix.max)) {
    return $i18("scp.vt_component.common.plugins.jquery.vtype.lib.ip_range.prefix_format", {
      0: v6Prefix.min,
      1: v6Prefix.max
    });
  }
  return true;
}
function getValidateFn(option) {
  let check = option.check || "", v4DefaultCheck = "!lookback,!multicast,!broadcast", v6DefaultCheck = "unicast", ipValidateFn;
  const getCheck = function(v, mod) {
    if (typeof v === "string") {
      return v;
    }
    if (typeof v === "object" && v[mod]) {
      return v[mod];
    }
    return false;
  };
  switch (option.mod) {
    case "ipv4":
      ipValidateFn = ip_default.validate;
      check = getCheck(check, "ipv4") || v4DefaultCheck;
      break;
    case "ipv6":
      ipValidateFn = ipv6_default.validate;
      check = getCheck(check, "ipv6") || v6DefaultCheck;
      break;
    case "all":
    default:
      ipValidateFn = allIp_default.validate;
      check = {
        ipv4: getCheck(check, "ipv4") || v4DefaultCheck,
        ipv6: getCheck(check, "ipv6") || v6DefaultCheck
      };
  }
  return {
    validateFn: ipValidateFn,
    check
  };
}

// packages/validator/validation-functions/ipRangeMulti.js
import { $i as $i19 } from "@sxf/er-config";
import format10 from "@sxf/er-utils/format";
var ipRangeMulti_default = {
  validate(value, option) {
    return ipRangeMulti2(value, option);
  }
};
function ipRangeMulti2(value, option = {}) {
  const errList = [];
  const maxline = option.maxline || 50;
  const ipRule = {
    check: option.check || "!lookback,!multicast,!broadcast",
    netmask: option.netmask
  };
  const array = value.indexOf("\n") > -1 ? value.split("\n") : value.split(",");
  if (maxline && array.length > maxline) {
    errList.push(
      $i19("scp.vt_component.common.plugins.jquery.vtype.lib.ip_range_multi.max_line_of_ip_address_list", {
        0: maxline
      })
    );
    return errList;
  }
  array.forEach(function(item, index) {
    const ip = item.replace(/(^\s*)|(\s*$)/g, "");
    const errMsg = $i19("scp.vt_component.common.plugins.jquery.vtype.lib.ip_range_multi.line_is_invalid_msg", {
      0: index + 1,
      1: format10.htmlEncode(item)
    });
    if (!ip) {
      return;
    }
    if (ip.indexOf("-") > -1) {
      const rang = ip.split("-");
      if (rang.length !== 2) {
        errList.push(
          errMsg + $i19(
            "scp.vt_component.common.plugins.jquery.vtype.lib.ip_range_multi.ip_range_cannot_contain_multiple_hyphens"
          ) + "</br>"
        );
        return;
      }
      if (ip_default.validate(rang[0], ipRule) !== true) {
        errList.push(
          errMsg + (ip_default.validate(rang[0], ipRule) || $i19("scp.vt_component.common.plugins.jquery.vtype.lib.ip_range_multi.ip_address_format_err_msg")) + "</br>"
        );
        return;
      }
      if (ip_default.validate(rang[1], ipRule) !== true) {
        errList.push(
          errMsg + (ip_default.validate(rang[1], ipRule) || $i19("scp.vt_component.common.plugins.jquery.vtype.lib.ip_range_multi.ip_address_format_error_msg")) + "</br>"
        );
        return;
      }
      if (format10.ip2int(rang[0]) - format10.ip2int(rang[1]) > 0) {
        errList.push(
          errMsg + $i19("scp.vt_component.common.plugins.jquery.vtype.lib.ip_range_multi.ip_range_rule") + "</br>"
        );
        return;
      }
    } else if (ip_default.validate(ip, ipRule) !== true) {
      errList.push(
        errMsg + (ip_default.validate(ip, ipRule) || $i19("scp.vt_component.common.plugins.jquery.vtype.lib.ip_range_multi.error_ip_format")) + "</br>"
      );
    }
  });
  return errList.length ? errList : true;
}

// packages/validator/validation-functions/ips.js
import { $i as $i20 } from "@sxf/er-config";
import format11 from "@sxf/er-utils/format";
var ips_default = {
  validate(value) {
    const errList = [];
    const array = format11.getLines(value);
    array.forEach(function(item, index) {
      const ip = item.trim(), errMsg = $i20("scp.vt_component.common.plugins.jquery.vtype.lib.ips.line_is_invalid_msg", {
        0: index + 1,
        1: format11.htmlEncode(item)
      });
      if (!ip) {
        return;
      }
      if (ip.indexOf("-") > -1) {
        const rang = ip.split("-");
        if (rang.length !== 2) {
          errList.push(
            errMsg + $i20("scp.vt_component.common.plugins.jquery.vtype.lib.ips.ip_range_cannot_contain_multiple_hyphens")
          );
          return;
        }
        if (!verify.ip(rang[0], true) || !verify.ip(rang[1], true)) {
          errList.push(errMsg + $i20("scp.vt_component.common.plugins.jquery.vtype.lib.ips.error_ip_format"));
          return;
        }
        if (format11.ip2int(rang[0]) - format11.ip2int(rang[1]) > 0) {
          errList.push(errMsg + $i20("scp.vt_component.common.plugins.jquery.vtype.lib.ips.ip_range_rule"));
          return;
        }
      } else if (!verify.ip(ip, true)) {
        errList.push(errMsg + $i20("scp.vt_component.common.plugins.jquery.vtype.lib.ips.fail_ip_format"));
      }
    });
    return errList.length ? errList : true;
  }
};

// packages/validator/validation-functions/ipv4Range.js
var ipv4Range_default = {
  /**
   * 多行IPv4地址范围校验
   *
   * @param {*} value
   * @param {*} option
   * {
   *  maxline: 50 最大输入行数
   *  withSubnet: false 是否校验前缀长度如：1.1.1.1/64这种写法
   *  check：ip类型过滤
   * }
   */
  validate(value, option) {
    option = option || {};
    option.mod = "ipv4";
    return ipRange_default.validate(value, option);
  }
};

// packages/validator/validation-functions/ipv6Range.js
var ipv6Range_default = {
  /**
   * 多行IPv6地址范围校验
   *
   * @param {*} value
   * @param {*} option
   * {
   *  maxline: 50 最大输入行数
   *  withSubnet: false 是否校验前缀长度如：::/128这种写法
   *  check：ip类型过滤
   * }
   */
  validate(value, option) {
    option = option || {};
    option.mod = "ipv6";
    return ipRange_default.validate(value, option);
  }
};

// packages/validator/validation-functions/keyCode.js
import { $i as $i21 } from "@sxf/er-config";
var keyCode_default = {
  validate(v) {
    const reg = /^[\.\da-zA-Z\u4E00-\u9FA5！（）——【】：；'、'《》？，。、……￥‘’“”\-\~\@\#\%\&\*\+·\-\=\{\}\"\|\!\$\^\(\)\_\`\[\]\:\"\;\'\\\<\>\?\,\.\/\s]+$/, regText = $i21("scp.vt_component.common.plugins.jquery.vtype.lib.key_code.valid_characters");
    if (!reg.test(v)) {
      return regText;
    }
    return true;
  }
};

// packages/validator/validation-functions/mac.js
import $6 from "jquery";
import { $i as $i22 } from "@sxf/er-config";
import format12 from "@sxf/er-utils/format";
var macConfig = {
  supportUpperCase: false
};
var mac_default = {
  install: function(o) {
    macConfig = $6.extend(true, {}, macConfig, o);
  },
  validate(v) {
    v = format12.trim(v);
    if (macConfig.supportUpperCase) {
      if (!verify.allMac(v)) {
        return $i22("scp.vt_component.common.plugins.jquery.vtype.lib.mac.valid_mac_tip");
      }
    } else {
      if (!verify.mac(v)) {
        return $i22("scp.vt_component.common.plugins.jquery.vtype.lib.mac.valid_lowercase_mac_tip");
      }
    }
    return true;
  }
};

// packages/validator/validation-functions/mail.js
import { $i as $i23 } from "@sxf/er-config";
import format13 from "@sxf/er-utils/format";
var mail_default = {
  validate(v) {
    const maxLength = 64, maxLengthText = $i23("scp.vt_component.common.plugins.jquery.vtype.lib.mail.max_value_length", {
      0: maxLength
    }), illegalReg = /[^A-z0-9-_.@]/, illegalText = $i23("scp.vt_component.common.plugins.jquery.vtype.lib.mail.vlaue_rule");
    v = format13.trim(v);
    if (illegalReg.test(v)) {
      return illegalText;
    }
    if (getUTF8Length(v) > maxLength) {
      return maxLengthText;
    }
    return verify.emailIP(v);
  },
  getText: () => $i23("scp.vt_component.common.plugins.jquery.vtype.lib.mail.vaild_e_mail_address")
};

// packages/validator/validation-functions/mask.js
import { $i as $i24 } from "@sxf/er-config";
import format14 from "@sxf/er-utils/format";
var validator3 = {
  // 全零的子网掩码
  fullZero: function(v) {
    return format14.ip2int(v) === 0;
  }
};
var mask_default = {
  /**
   * @param {String} o.check 检测是否符合这个类型 eg.'fullZero, !fullZero...'
   * */
  validate(v, o) {
    let isValid3 = verify.mask(v), checkList, isNot, checkFn;
    if (!isValid3) {
      return o && o.errorText || false;
    }
    if (o && o.check) {
      checkList = o.check.split(",");
      for (let i = 0; i < checkList.length; i++) {
        checkFn = checkList[i].replace(/\s/g, "");
        isNot = checkFn.indexOf("!") === 0;
        if (validator3[isNot ? checkFn.slice(1) : checkFn](v) === isNot) {
          isValid3 = o.checkText || validator3[checkFn + "Text"] || false;
          break;
        }
      }
    }
    return isValid3;
  },
  getText: () => $i24("scp.vt_component.common.plugins.jquery.vtype.lib.mask.valid_netmask"),
  mask: /[\d\.]/i
};

// packages/validator/validation-functions/mtu.js
import { $i as $i25 } from "@sxf/er-config";
import format15 from "@sxf/er-utils/format";
var mtu_default = {
  validate(v) {
    v = format15.trim(v);
    return verify.mtu(v);
  },
  getText: () => $i25("scp.vt_component.common.plugins.jquery.vtype.lib.mtu.valid_mtu"),
  mask: /[\d]/i
};

// packages/validator/validation-functions/name.js
import { $i as $i26 } from "@sxf/er-config";
var _a, _b;
var nameConfig = {
  // maxLength: undefined
  isInternational: (_b = (_a = window.VMP) == null ? void 0 : _a.data) == null ? void 0 : _b.isInternational
};
var name_default = {
  install(o) {
    Object.assign(nameConfig, o);
  },
  // 安全整改后严格的名称校验
  // 正则表达式里有｛｝，提示里没有是故意的，由于中文半角的花括号和英文的花括号太像了，难以区分，所以也为了兼容旧版本用户，去掉了提示里面｛｝
  validate(v, o) {
    const maxLength = o && o.maxLength || nameConfig.maxLength || 100;
    const maxLengthText = $i26("scp.vt_component.common.plugins.jquery.vtype.lib.name.max_value_length", {
      0: maxLength,
      1: Math.floor(maxLength / 3)
    });
    let reg = /^[\.\(\)（）【】｛｝@\d\u4E00-\u9FA5a-zA-Z_+\-]+$/, regText = $i26("scp.vt_component.common.plugins.jquery.vtype.lib.name.value_format");
    if (nameConfig.isInternational) {
      reg = /^[\.\(\)（）【】｛｝@\d\u4E00-\u9FA5a-zA-Z_+\-\s]+$/;
      regText = $i26("scp.vt_component.common.plugins.jquery.vtype.lib.name.value_format_en");
    }
    if (getUTF8Length(v) > maxLength) {
      return maxLengthText;
    }
    if (!reg.test(v)) {
      return regText;
    }
    if (v.length) {
      if (v.charAt(0) === ".") {
        return $i26("scp.vt_component.common.plugins.jquery.vtype.lib.name.cannot_begin_with_dot");
      }
    }
    return true;
  }
};

// packages/validator/validation-functions/num.js
import { $i as $i27 } from "@sxf/er-config";
import format16 from "@sxf/er-utils/format";
var baseChars = "-0123456789";
var num_default = {
  validate(v, o) {
    let allowed = baseChars;
    v = format16.trim(v);
    if (o.allDecimals) {
      allowed += ".";
    }
    const reg = new RegExp("^[" + allowed + "]*$");
    if (!reg.test(v)) {
      if (!o.allDecimals) {
        return $i27("scp.vt_component.common.plugins.jquery.vtype.lib.num.valid_integer_tip");
      }
      return false;
    }
    if (!/^\-?\d+(\.\d+)?$/.test(v)) {
      return false;
    }
    if (o.minValue !== void 0 && o.minValue !== null) {
      o.minValue = Number(o.minValue);
      if (!isNaN(o.minValue) && !isNaN(v)) {
        if (Number(v) < o.minValue) {
          return o.minValueText || $i27("scp.vt_component.common.plugins.jquery.vtype.lib.num.min_value", {
            0: o.minValue
          });
        }
      }
    }
    if (o.maxValue !== void 0 && o.maxValue !== null) {
      o.maxValue = Number(o.maxValue);
      if (!isNaN(o.maxValue) && !isNaN(v)) {
        if (Number(v) > o.maxValue) {
          return o.maxValueText || $i27("scp.vt_component.common.plugins.jquery.vtype.lib.num.max_value", {
            0: o.maxValue
          });
        }
      }
    }
    return true;
  },
  getText: () => $i27("scp.vt_component.common.plugins.jquery.vtype.lib.num.valid_number_tip"),
  mask: function(o) {
    let allowed = baseChars;
    if (o.allDecimals) {
      allowed += ".";
    }
    return new RegExp("[" + allowed + "]");
  }
};

// packages/validator/validation-functions/phone.js
import { $i as $i28, globalConfig } from "@sxf/er-config";
var phone_default = {
  validate(v) {
    const phone = String(v);
    if (globalConfig.isInternational) {
      return /^[\d\-\+\(\)\s]{1,30}$/.test(phone);
    }
    if (phone.indexOf("+") === 0) {
      return /^\+\d{13}$/.test(phone);
    }
    return /^1[03-9]\d{9}$/.test(phone);
  },
  getText: () => $i28("scp.vt_component.common.plugins.jquery.vtype.lib.phone.valid_phone_number")
};

// packages/validator/validation-functions/port.js
import { $i as $i29 } from "@sxf/er-config";
import format17 from "@sxf/er-utils/format";
var port_default = {
  validate(v) {
    v = format17.trim(v);
    return verify.port(v);
  },
  getText: () => $i29("scp.vt_component.common.plugins.jquery.vtype.lib.port.valid_port"),
  mask: /[\d]/i
};

// packages/validator/validation-functions/portGroup.js
var portGroup_default = {
  validate(v) {
    return verify.portGroup(v);
  }
};

// packages/validator/validation-functions/prefix.js
import { $i as $i30 } from "@sxf/er-config";
var prefix_default = {
  /**
   * ipv6前缀验证
   *
   * @param {string} v
   * @param {object} o
   * {
   *  maxValue: 最大值，默认128
   *  minValue：最小值，默认1
   *  errText: 错误提示
   * }
   * @returns {boolean|string}
   */
  validate(v, o) {
    const minLen = 1, maxLen = 128;
    if (!verify.prefix(v)) {
      return false;
    }
    o = o || {};
    o.minValue = verify.prefix(o.minValue) ? Number(o.minValue) : minLen;
    o.maxValue = verify.prefix(o.maxValue) ? Number(o.maxValue) : maxLen;
    const min = Math.min(o.minValue, o.maxValue);
    const max = Math.max(o.minValue, o.maxValue);
    v = Number(v);
    if (v < min || v > max) {
      return o.errText || $i30("scp.vt_component.common.plugins.jquery.vtype.lib.prefix.number_range", {
        0: min,
        1: max
      });
    }
    return true;
  },
  getText: () => $i30("scp.vt_component.common.plugins.jquery.vtype.lib.prefix.valid_prefix_length"),
  mask: /[\d]/
};

// packages/validator/validation-functions/pswd.js
import $7 from "jquery";
import { $i as $i31 } from "@sxf/er-config";
var DEFAULT_MIN_LENGTH = 8;
var DEFAULT_MAX_LENGTH = 64;
var DEFAULT_MIN_TYPE_COUNT = 4;
var SPECIAL_CHARACTER = "~`@#%&<>\"',;_-^$.*+?=!:|{}()[]/\\";
var getSpecialCharacterText = () => $i31("scp.vt_component.common.util.password_rule.special_character_tip_text", {
  0: SPECIAL_CHARACTER
});
var MIN_CHAR_TYPE = {
  capital: true,
  letter: true,
  num: true,
  special: true
};
function getLengthTipText(options) {
  options = options || {};
  const minLens = options.minLens || DEFAULT_MIN_LENGTH, maxLens = options.maxLens || DEFAULT_MAX_LENGTH;
  return $i31("scp.vt_component.common.util.password_rule.data_length", {
    0: minLens,
    1: maxLens
  });
}
function getCharacterTipText(options) {
  return getCharacterTypeTipText(options) + $i31("scp.vt_component.common.util.password_rule.character_tip_text") + getSpecialCharacterText();
}
function getFullTipText(options) {
  return getLengthTipText(options) + $i31("scp.vt_component.common.util.password_rule.text_dot") + getCharacterTipText(options);
}
function getCharacterTypeTipText(options) {
  options = options || {};
  const innerTypeCount = options.minTypeCount || getDefaultMinTypeCount(options);
  let innerContent = "";
  if (innerTypeCount === getDefaultMinTypeCount(options)) {
    innerContent = innerTypeCount;
  } else {
    innerContent = $i31("scp.vt_component.common.util.password_rule.innner_content", {
      0: innerTypeCount
    });
  }
  const minCharType = $7.extend({}, MIN_CHAR_TYPE, options.minCharType);
  const charTextList = [];
  if (minCharType.capital) {
    charTextList.push($i31("scp.vt_component.common.util.password_rule.uppercase_letters"));
  }
  if (minCharType.letter) {
    charTextList.push($i31("scp.vt_component.common.util.password_rule.lowercase_letters"));
  }
  if (minCharType.num) {
    charTextList.push($i31("scp.vt_component.common.util.password_rule.digits"));
  }
  if (minCharType.special) {
    charTextList.push($i31("scp.vt_component.common.util.password_rule.special_characters"));
  }
  if (charTextList.length) {
    const content = charTextList.reduce((str, text, idx) => {
      if (idx !== charTextList.length - 1) {
        return $i31("scp.vt_component.common.util.password_rule.content_multiterm", {
          0: str,
          1: text
        });
      }
      if (charTextList.length - 1) {
        return $i31("scp.vt_component.common.util.password_rule.content_multiterms", {
          0: str,
          1: text
        });
      }
      return text;
    }, "");
    return $i31("scp.vt_component.common.util.password_rule.char_text_list", {
      0: content,
      1: innerContent
    });
  }
  return $i31("scp.vt_component.common.util.password_rule.character_type_tip_text");
}
function getTips(options) {
  const lengthTipText = getLengthTipText(options), characterTipText = getCharacterTipText(options), formatTipText = getCharacterTypeTipText(options), fullTipText = getFullTipText(options), stripedFormatText = [
    $i31("scp.vt_component.common.util.password_rule.tips_first", {
      0: lengthTipText
    }),
    $i31("scp.vt_component.common.util.password_rule.tips_second", {
      0: formatTipText
    }),
    $i31("scp.vt_component.common.util.password_rule.tips_thirdly", {
      0: getSpecialCharacterText()
    })
  ].join("<br/>");
  return {
    lengthTipText,
    characterTipText,
    fullTipText,
    stripedFormatText
  };
}
function getDefaultMinTypeCount(options) {
  options = options || {};
  const minCharTypeCount = options.minCharTypeCount || DEFAULT_MIN_TYPE_COUNT, minCharType = $7.extend({}, MIN_CHAR_TYPE, options.minCharType), count = Object.values(minCharType).reduce((num, v) => num += Number(v), 0);
  return Math.min(count, minCharTypeCount);
}
var pswdConfig = {
  // minCharTypeCount: undefined
};
var pswd_default = {
  defaultOptions: {
    autoTrim: false
  },
  install: function(o) {
    pswdConfig = $7.extend(true, {}, pswdConfig, o);
  },
  validate(v, options) {
    options = options || {};
    const maxLength = options.maxLength || DEFAULT_MAX_LENGTH, minLength = options.minLength || DEFAULT_MIN_LENGTH, minCharType = $7.extend({}, MIN_CHAR_TYPE, options.minCharType), minCharTypeCount = getDefaultMinTypeCount({
      minCharTypeCount: (options == null ? void 0 : options.minCharTypeCount) || pswdConfig.minCharTypeCount || DEFAULT_MIN_TYPE_COUNT,
      minCharType
    }), length = v.length, reg = /^[a-zA-Z0-9~`@#%&<>"',;_\-\^\$\.\*\+\?\=\!\:\|\{\}\(\)\[\]\/\\]+$/, tips = getTips({
      minLens: minLength,
      maxLens: maxLength,
      minTypeCount: minCharTypeCount,
      minCharType
    });
    const INCLUDE_ADMIN_TIP_TEXT = $i31("scp.vt_component.common.util.password_rule.include_admin_tip_text");
    const INCLUDE_BLANK_TIP_TEXT = $i31("scp.vt_component.common.util.password_rule.include_blank_tip_text");
    if (options.withoutUsername && options.username && v && v.indexOf(options.username) > -1) {
      return INCLUDE_ADMIN_TIP_TEXT;
    }
    if (v.indexOf(" ") > -1) {
      return INCLUDE_BLANK_TIP_TEXT;
    }
    const lower = /[a-z]+/;
    const upper = /[A-Z]+/;
    const number = /[0-9]+/;
    const special = /[~`@#%&<>"',;_\-\^\$\.\*\+\?\=\!\:\|\{\}\(\)\[\]\/\\]+/;
    let kindCnt = 0;
    if (minCharType.capital) {
      kindCnt += upper.test(v) ? 1 : 0;
    }
    if (minCharType.letter) {
      kindCnt += lower.test(v) ? 1 : 0;
    }
    if (minCharType.num) {
      kindCnt += number.test(v) ? 1 : 0;
    }
    if (minCharType.special) {
      kindCnt += special.test(v) ? 1 : 0;
    }
    if (length > maxLength || length < minLength) {
      if (!reg.test(v) || kindCnt < minCharTypeCount) {
        return tips.fullTipText;
      }
      return tips.lengthTipText;
    }
    if (!reg.test(v) || kindCnt < minCharTypeCount) {
      return tips.characterTipText;
    }
    return true;
  }
};

// packages/validator/validation-functions/subnet.js
import { $i as $i32 } from "@sxf/er-config";
import format18 from "@sxf/er-utils/format";
var subnet_default = {
  /**
   * @param {String} v
   * @param {String} o
   * mask:check 检测是否符合这个类型 eg.'fullZero, !fullZero...'
   * prefix: maxValue,minValue
   * errText: 错误提示
   */
  validate(v, o) {
    o = o || {};
    v = format18.trim(v);
    if (verify.mask(v)) {
      return mask_default.validate(v, o.mask || {});
    }
    if (verify.prefix(v)) {
      return prefix_default.validate(v, o.prefix || {});
    }
    return o.errText || false;
  },
  getText: () => $i32("scp.vt_component.common.plugins.jquery.vtype.lib.subnet.valid_netmask_or_prefix_length"),
  mask: /[\d\.]/i
};

// packages/validator/validation-functions/subnetname.js
import { $i as $i33 } from "@sxf/er-config";
var subnetname_default = {
  validate(v) {
    const maxLength = 90, maxLengthText = $i33("scp.vt_component.common.plugins.jquery.vtype.lib.subnetname.max_length_text"), reg = /^[\.\d\u4E00-\u9FA5a-zA-Z_\-\s]+$/, regText = $i33("scp.vt_component.common.plugins.jquery.vtype.lib.subnetname.valid_data_rule");
    if (getUTF8Length(v) > maxLength) {
      return maxLengthText;
    }
    if (!reg.test(v)) {
      return regText;
    }
    if (/^\./.test(v)) {
      return $i33("scp.vt_component.common.plugins.jquery.vtype.lib.subnetname.cannot_begin_with_dot");
    }
    return true;
  }
};

// packages/validator/validation-functions/telephone.js
import { $i as $i34, globalConfig as globalConfig2 } from "@sxf/er-config";
import format19 from "@sxf/er-utils/format";
var telephone_default = {
  validate(v) {
    const value = format19.trim(String(v));
    if (globalConfig2.isInternational) {
      return /^[\d\-\+\(\)\s]{7,30}$/.test(value);
    }
    const reg = /^\d{5,8}$/;
    if (reg.test(value)) {
      return true;
    }
    const ret = /^(((\d{2,3}|\+)?(\d{2,3}(?:-| )))?((\d{11})|(\d{3}[- ]{1}\d{3,4}[- ]{1}\d{4})|((\d{2,4}[- ]){1}(\d{7,8}|(\d{3,4}[- ]{1}\d{3,4}))([- ]{1}\d{1,4})?))(\(\d+\))*)$/.test(
      value
    );
    return ret;
  },
  getText: () => $i34("scp.vt_component.common.plugins.jquery.vtype.lib.telephone.valid_phone_number")
};

// packages/validator/validation-functions/tenantname.js
import { $i as $i35 } from "@sxf/er-config";
var tenantname_default = {
  validate(v, o) {
    const maxLength = o && o.maxLength || 100, maxLengthText = $i35("scp.vt_component.common.plugins.jquery.vtype.lib.tenantname.max_length_text", {
      0: maxLength,
      1: Math.floor(maxLength / 3)
    }), reg = /^[\.\(\)（）【】@\d\u4E00-\u9FA5a-zA-Z_+\-\s]+$/, regText = $i35("scp.vt_component.common.plugins.jquery.vtype.lib.tenantname.data_format");
    if (getUTF8Length(v) > maxLength) {
      return maxLengthText;
    }
    if (!reg.test(v)) {
      return regText;
    }
    if (v.length) {
      if (v.charAt(0) === ".") {
        return $i35("scp.vt_component.common.plugins.jquery.vtype.lib.tenantname.cannot_begin_with_dot");
      }
    }
    return true;
  }
};

// packages/validator/validation-functions/text.js
import $8 from "jquery";
import { $i as $i36 } from "@sxf/er-config";
var text_default = {
  validate(v, options = {}) {
    options = $8.extend(
      {
        maxLength: 255,
        useUTF8Len: true
      },
      options.textOptions
    );
    const len = options.useUTF8Len ? getUTF8Length(v) : v.length;
    if (len > options.maxLength) {
      return $i36("scp.vt_component.common.plugins.jquery.vtype.lib.text.data_max_length", {
        0: options.maxLength,
        1: options.useUTF8Len ? Math.floor(options.maxLength / 3) : options.maxLength
      });
    }
    return true;
  }
};

// packages/validator/validation-functions/time.js
import { $i as $i37 } from "@sxf/er-config";
import format20 from "@sxf/er-utils/format";
var time_default = {
  validate(v) {
    v = format20.trim(v);
    return verify.time(v);
  },
  getText: () => $i37("scp.vt_component.common.plugins.jquery.vtype.lib.time.valid_time"),
  mask: /[\d:]/i
};

// packages/validator/validation-functions/username.js
import { $i as $i38 } from "@sxf/er-config";
var username_default = {
  validate(v) {
    const maxLength = 32, maxLengthText = $i38("scp.vt_component.common.plugins.jquery.vtype.lib.username.data_max_length"), reg = /^[a-zA-Z0-9\_]+$/, regText = $i38("scp.vt_component.common.plugins.jquery.vtype.lib.username.data_format");
    if (getUTF8Length(v) > maxLength) {
      return maxLengthText;
    }
    if (!reg.test(v)) {
      return regText;
    }
    return true;
  }
};

// packages/validator/validation-functions/vlan.js
import { $i as $i39 } from "@sxf/er-config";
import format21 from "@sxf/er-utils/format";
var vlan_default = {
  validate(v) {
    v = format21.trim(v);
    return verify.vlan(v);
  },
  getText: () => $i39("scp.vt_component.common.plugins.jquery.vtype.lib.vlan.valid_vlan_id"),
  mask: /[\d]/i
};

// packages/validator/validation-functions/vlanRange.js
import { $i as $i40 } from "@sxf/er-config";
var vlanRange_default = {
  validate(v) {
    const ret = String(v).match(/(\d)-(\d)/);
    if (ret && ret.length === 3 && ret[1] < ret[2]) {
      return /^([2-9]\d{0,2}|[1-3]\d{3}|40[0-8]\d{1}|409[0-4])$/.test(ret[1]) && /^([2-9]\d{0,2}|[1-3]\d{3}|40[0-8]\d{1}|409[0-4])$/.test(ret[2]);
    }
    return false;
  },
  getText: () => $i40("scp.vt_component.common.plugins.jquery.vtype.lib.vlan_range.valid_vlan_id_range")
};

// packages/validator/validation-functions/vmname.js
import $9 from "jquery";
import { $i as $i41, globalConfig as globalConfig3 } from "@sxf/er-config";
var vmnameConfig = {
  // maxLength: undefined
};
var vmname_default = {
  install: function(o) {
    vmnameConfig = $9.extend(true, {}, vmnameConfig, o);
  },
  // 安全整改后严格的名称校验
  // 正则表达式里有｛｝，提示里没有是故意的，由于中文半角的花括号和英文的花括号太像了，难以区分，所以也为了兼容旧版本用户，去掉了提示里面｛｝
  validate(v, o) {
    const maxLength = o && o.maxLength || vmnameConfig.maxLength || 70, maxLengthText = $i41("scp.vt_component.common.plugins.jquery.vtype.lib.vmname.data_max_length", {
      0: maxLength,
      1: Math.floor(maxLength / 3)
    }), reg = /^[\.\(\)（）【】｛｝@\d\u4E00-\u9FA5a-zA-Z_+\-\s]+$/, regText = $i41("scp.vt_component.common.plugins.jquery.vtype.lib.vmname.data_format");
    if (getUTF8Length(v) > maxLength) {
      return maxLengthText;
    }
    if (!reg.test(v)) {
      return regText;
    }
    if (v.length) {
      if (v.charAt(0) === ".") {
        return $i41("scp.vt_component.common.plugins.jquery.vtype.lib.vmname.cannot_begin_with_dot");
      }
    }
    return true;
  },
  getErrText() {
    const maxLength = vmnameConfig.maxLength || 70;
    if (globalConfig3.isInternational) {
      return $i41("scp.vt_component.common.plugins.jquery.vtype.lib.vmname.Internation_error_text", {
        0: maxLength
      });
    }
    return $i41("scp.vt_component.common.plugins.jquery.vtype.lib.vmname.error_text", {
      0: maxLength,
      1: Math.floor(maxLength / 3)
    });
  }
};

// packages/validator/validation-functions/vmpassword.js
import { $i as $i42 } from "@sxf/er-config";
var vmpassword_default = {
  defaultOptions: {
    autoTrim: false
  },
  validate(v, options) {
    options = options || {};
    const maxLength = options.maxLength || 64, minLength = options.minLength || 8, length = getUTF8Length(v), reg = /^[a-zA-Z0-9`~@#%_&;'<>,\$\(\)\^\*\!\+\=\|\{\}\.\?\:\[\]\-\/]+$/, errMsg = $i42("scp.vt_component.common.plugins.jquery.vtype.lib.vmpassword.password_err_msg", {
      0: minLength,
      1: maxLength,
      2: "()`~!@#$%^&*_-+=|{}[]:;'<>,.?/"
    });
    if (options.isWindowsOs) {
      if (/^\//.test(v)) {
        return $i42("scp.vt_component.common.plugins.jquery.vtype.lib.vmpassword.password_without_win_err_msg", {
          0: minLength,
          1: maxLength,
          2: "()`~!@#$%^&*_-+=|{}[]:;'<>,.?/"
        });
      }
    }
    if (options.withoutUsername && options.username && v && v.indexOf(options.username) > -1) {
      return $i42("scp.vt_component.common.plugins.jquery.vtype.lib.vmpassword.password_cannot_contain_username");
    }
    if (v.indexOf(" ") > -1) {
      return $i42("scp.vt_component.common.plugins.jquery.vtype.lib.vmpassword.password_cannot_contain_spaces");
    }
    if (length > maxLength || length < minLength || !reg.test(v)) {
      return errMsg;
    }
    const lower = /[a-z]+/;
    const upper = /[A-Z]+/;
    const number = /[0-9]+/;
    const special = /[`~@#%_&;'<>,\$\(\)\^\*\!\+\=\|\{\}\.\?\:\[\]\-\/]+/;
    let kindCnt = 0;
    kindCnt += lower.test(v) ? 1 : 0;
    kindCnt += upper.test(v) ? 1 : 0;
    kindCnt += number.test(v) ? 1 : 0;
    kindCnt += special.test(v) ? 1 : 0;
    if (kindCnt < 3) {
      return $i42("scp.vt_component.common.plugins.jquery.vtype.lib.vmpassword.password_format", {
        0: "()`~!@#$%^&*_-+=|{}[]:;'<>,.?/"
      });
    }
    return true;
  }
};

// packages/validator/validation-functions/vmwareRecoverName.js
import { $i as $i43 } from "@sxf/er-config";
var vmwareRecoverName_default = {
  validate(v) {
    const maxLength = 80, maxLengthText = $i43("scp.vt_component.common.plugins.jquery.vtype.lib.vmware_recover_name.data_max_length"), reg = /(%)|(\/)/gi, result = v.match(reg) || [];
    if (/[\\?#]/.test(v)) {
      return $i43("scp.vt_component.common.plugins.jquery.vtype.lib.vmware_recover_name.prohibited_entry");
    }
    if (getUTF8Length(v) + 2 * result.length > maxLength) {
      return maxLengthText;
    }
    return true;
  },
  getErrText() {
    return $i43("scp.vt_component.common.plugins.jquery.vtype.lib.vmware_recover_name.name_err_text");
  }
};

// packages/validator/validation-functions/vmwarename.js
import { $i as $i44 } from "@sxf/er-config";
var vmwarename_default = {
  validate(v) {
    const maxLength = 80, maxLengthText = $i44("scp.vt_component.common.plugins.jquery.vtype.lib.vmwarename.vm_name_max_length_text"), reg = /(%)|(\\)|(\/)/gi, result = v.match(reg) || [];
    if (getUTF8Length(v) + 2 * result.length > maxLength) {
      return maxLengthText;
    }
    return true;
  }
};

// packages/validator/validation-functions/vnetname.js
import $10 from "jquery";
import { $i as $i45 } from "@sxf/er-config";
var vnetnameConfig = {
  // maxLength: undefined
};
var vnetname_default = {
  install: function(o) {
    vnetnameConfig = $10.extend(true, {}, vnetnameConfig, o);
  },
  validate(v, o) {
    const maxLength = o && o.maxLength || vnetnameConfig.maxLength || 60, maxLengthText = $i45("scp.vt_component.common.plugins.jquery.vtype.lib.vnetname.vnet_name_max_length_text", {
      0: maxLength,
      1: Math.floor(maxLength / 3)
    }), reg = /^[\.\d\u4E00-\u9FA5a-zA-Z_\s]+$/, regText = $i45("scp.vt_component.common.plugins.jquery.vtype.lib.vnetname.vnet_name_format");
    if (getUTF8Length(v) > maxLength) {
      return maxLengthText;
    }
    if (!reg.test(v)) {
      return regText;
    }
    if (/^\./.test(v)) {
      return $i45("scp.vt_component.common.plugins.jquery.vtype.lib.vnetname.vnet_name_cannot_begin_with_dot");
    }
    return true;
  }
};

// packages/validator/validation-functions/vsdesc.js
import $11 from "jquery";
import { $i as $i46 } from "@sxf/er-config";
var vsdesc_default = {
  validate(v, options = {}) {
    options = $11.extend(
      {
        maxLength: 255
      },
      options.textOptions
    );
    if (getUTF8Length(v) > options.maxLength) {
      return $i46("scp.vt_component.common.plugins.jquery.vtype.lib.vsdesc.vsdesc_max_length_text", {
        0: options.maxLength,
        1: Math.floor(options.maxLength / 3)
      });
    }
    if (/^-/.test(v)) {
      return $i46("scp.vt_component.common.plugins.jquery.vtype.lib.vsdesc.cannot_begin_with_hyphen");
    }
    const reg = /^[\.\(\)\,\/\!~\:，。！、￥……：；（）【】｛｝“”‘’@\d\u4E00-\u9FA5a-zA-Z_+=\-\s]*$/;
    const regText = $i46("scp.vt_component.common.plugins.jquery.vtype.lib.vsdesc.data_format");
    if (!reg.test(v)) {
      return regText;
    }
    return true;
  }
};

// packages/validator/validation-functions/vsname.js
import { $i as $i47, globalConfig as globalConfig4 } from "@sxf/er-config";
var vsname_default = {
  validate(v) {
    const maxLength = 64;
    const reg = /^[\d\u4E00-\u9FA5a-zA-Z_]+$/;
    let maxLengthText = $i47("scp.vt_component.common.plugins.jquery.vtype.lib.vsname.data_max_length", {
      0: maxLength,
      1: Math.floor(maxLength / 3)
    });
    let regText = $i47("scp.vt_component.common.plugins.jquery.vtype.lib.vsname.data_format_zh");
    if (globalConfig4.isInternational) {
      regText = $i47("scp.vt_component.common.plugins.jquery.vtype.lib.vsname.data_format_en");
      maxLengthText = $i47("scp.vt_component.common.plugins.jquery.vtype.lib.vsname.data_en_max_length_text", {
        0: maxLength
      });
    }
    if (getUTF8Length(v) > maxLength) {
      return maxLengthText;
    }
    if (!reg.test(v)) {
      return regText;
    }
    return true;
  }
};

// packages/validator/validation-functions/xycloudsAccountName.js
import { $i as $i48 } from "@sxf/er-config";
var xycloudsAccountName_default = {
  validate(v, o) {
    const maxLength = o && o.maxLength || 100;
    if (!phone_default.validate(v) && !verify.emailIP(v)) {
      return $i48("scp.vt_component.common.plugins.jquery.vtype.lib.xyclouds_account_name.valid_e_mail_or_phone");
    }
    if (getUTF8Length(v) > maxLength) {
      return $i48("scp.vt_component.common.plugins.jquery.vtype.lib.xyclouds_account_name.data_max_length", {
        0: maxLength
      });
    }
    return true;
  }
};

// packages/validator/validation-functions/xycloudsDomain.js
import { $i as $i49 } from "@sxf/er-config";
var xycloudsDomain_default = {
  validate(v) {
    let maxLength = 100, minSectionCount = 2, maxSectionLength = 63, maxLengthText = $i49("scp.vt_component.common.plugins.jquery.vtype.lib.xyclouds_domain.data_max_length", {
      0: maxLength
    }), isValidated = true, lastSectionReg = /^(?![0-9]+$)[a-zA-Z0-9-]{2,63}$/, illegalReg = /[^a-zA-Z0-9-]/, arr = v.split("."), arrLength = arr.length, illegalText, i;
    if (arrLength < minSectionCount) {
      return false;
    }
    for (i = 0; i < arrLength; i++) {
      if (arr[i].length > maxSectionLength) {
        isValidated = false;
        break;
      }
      if (arr[i].charAt(arr[i].length - 1) === "-" || arr[i].charAt(0) === "-") {
        illegalText = '"-"' + $i49("scp.vt_component.common.plugins.jquery.vtype.lib.xyclouds_domain.data_cannot_start_or_end_with_hyphen");
        break;
      }
      if (illegalReg.test(arr[i])) {
        illegalText = $i49("scp.vt_component.common.plugins.jquery.vtype.lib.xyclouds_domain.domain_format");
        break;
      }
      if (i === arrLength - 1 && !lastSectionReg.test(arr[i])) {
        isValidated = false;
      }
    }
    if (getUTF8Length(v) > maxLength) {
      illegalText = maxLengthText;
    }
    return illegalText || isValidated;
  },
  getText: () => $i49("scp.vt_component.common.plugins.jquery.vtype.lib.xyclouds_domain.valid_domain")
};

// packages/validator/validation-functions/xycloudsVmName.js
import { $i as $i50 } from "@sxf/er-config";
var xycloudsVmName_default = {
  validate(v, o) {
    const maxLength = o && o.maxLength || 90, maxLengthText = $i50("scp.vt_component.common.plugins.jquery.vtype.lib.xyclouds_vm_name.data_max_length", {
      0: maxLength,
      1: Math.floor(maxLength / 3)
    }), reg = /^[\.\[\]\{\}（）【】｛｝@\d\u4E00-\u9FA5a-zA-Z_+\-?\s]+$/, regText = $i50("scp.vt_component.common.plugins.jquery.vtype.lib.xyclouds_vm_name.data_format");
    if (getUTF8Length(v) > maxLength) {
      return maxLengthText;
    }
    if (!reg.test(v)) {
      return regText;
    }
    if (v.length) {
      if (v.charAt(0) === ".") {
        return $i50(
          "scp.vt_component.common.plugins.jquery.vtype.lib.xyclouds_vm_name.data_cannot_start_or_end_with_character"
        );
      }
    }
    return true;
  }
};

// packages/validator/validation-functions/index.js
var map = {
  name: name_default,
  "ad-name": adName_default,
  vmname: vmname_default,
  devname: devname_default,
  vnetname: vnetname_default,
  ip: ip_default,
  ipv6: ipv6_default,
  duid: duid_default,
  iaid: iaid_default,
  "all-ip": allIp_default,
  "ip-range": ipRange_default,
  "ipv6-range": ipv6Range_default,
  "ipv4-range": ipv4Range_default,
  mask: mask_default,
  prefix: prefix_default,
  subnet: subnet_default,
  dns: dns_default,
  mail: mail_default,
  mtu: mtu_default,
  vlan: vlan_default,
  domain: domain_default,
  domainip: domainip_default,
  date: date_default,
  time: time_default,
  mac: mac_default,
  num: num_default,
  port: port_default,
  pswd: pswd_default,
  username: username_default,
  "vlan-range": vlanRange_default,
  text: text_default,
  phone: phone_default,
  telephone: telephone_default,
  illegal: illegal_default,
  des: des_default,
  subnetname: subnetname_default,
  "xyclouds-vm-name": xycloudsVmName_default,
  "xyclouds-account-name": xycloudsAccountName_default,
  tenantname: tenantname_default,
  eipname: eipname_default,
  vmpassword: vmpassword_default,
  "ip-range-multi": ipRangeMulti_default,
  icmp: icmp_default,
  "key-code": keyCode_default,
  ips: ips_default,
  "port-group": portGroup_default,
  vmwarename: vmwarename_default,
  vsdesc: vsdesc_default,
  vsname: vsname_default,
  "xyclouds-domain": xycloudsDomain_default,
  hostname: hostName_default,
  http: http_default,
  // 新增 type
  "vmware-recover-name": vmwareRecoverName_default
};
var getValidator = (type) => {
  return map[type];
};
var extendValidator = (types) => {
  return Object.assign(map, types);
};
var NO_ZH_CN_TYPE = ["password", "pswd", "num", "vmpassword", "hostname", "username"];

// packages/validator/utils/verify.js
var IPV6 = ipRegex.v6({ exact: true });
var verify = {
  /**
   * 校验是否是IPv4
   *
   * @param {string} v 验证的IP
   * @param {string} trim 要不要去除前后空格
   * @return {boolean} 成功返回true
   */
  ip: function() {
    const IPAddress = new RegExp(
      format22.format("^({0}\\.{0}\\.{0}\\.{0})$", "(?:\\d|[1-9]\\d|1\\d\\d|2[0-4]\\d|25[0-5])")
    );
    return function(v, trim) {
      if (typeof v !== "string") {
        return false;
      }
      if (trim) {
        return IPAddress.test(format22.trim(v));
      } else {
        return IPAddress.test(v);
      }
    };
  }(),
  /**
   * 校验是否是IPv6
   *
   * @param {string} v 验证的IP
   * @param {string} trim 要不要去除前后空格
   * @return {boolean} 成功返回true
   */
  ipv6: function(v, trim) {
    if (typeof v !== "string") {
      return false;
    }
    if (trim) {
      return IPV6.test(format22.trim(v));
    } else {
      return IPV6.test(v);
    }
  },
  /**
   * 12-20字节的十六进制字符，可以以:连接如：af:af:...，或者afaf...或者af-af...
   * 如果有分隔符，每一块不足2位的自动补0
   *
   * @param {string} v
   * @returns {boolean}
   */
  isDuid: function(v) {
    if (typeof v !== "string") {
      return false;
    }
    const separators = [":", "-"];
    let currSep = "";
    let pattern = "([a-fA-F\\d]{2}){12,20}";
    separators.map((item) => {
      pattern += `|([a-fA-F\\d]{2}\\${item}){11,19}[a-fA-F\\d]{2}`;
      if (v.includes(item)) {
        currSep = item;
      }
    });
    pattern = new RegExp(`^(${pattern})$`);
    if (currSep) {
      const parts = v.split(currSep);
      v = parts.map((part) => {
        if (part.length === 1) {
          part = "0" + part;
        }
        return part;
      }).join(currSep);
    }
    return pattern.test(v);
  },
  /**
   * 4字节的十六进制字符，可以省略前置0，也可以是十进制
   *
   * @param {string} v
   * @param {boolean} isDecimal 是否是十进制
   * @returns {boolean}
   */
  isIaid: function(v, isDecimal) {
    if (isDecimal) {
      const maxBase = 2;
      const maxIndex = 32;
      const max = Math.pow(maxBase, maxIndex) - 1;
      v = +v;
      return v <= max && v >= 0;
    }
    const IAID_LEN = 8;
    const pattern = /^[a-fA-F0-9]{8}$/;
    while (IAID_LEN - v.length > 0) {
      v = "0" + v;
    }
    return pattern.test(v);
  },
  /**
   * 校验两个ip是否同为ipv4或ipv6
   */
  ipTypeEqual: function(v1, v2, trim) {
    v1 = trim ? format22.trim(v1) : v1;
    v2 = trim ? format22.trim(v2) : v2;
    if (!verify.ip(v1) && !IPV6.test(v1) || !verify.ip(v2) && !IPV6.test(v2)) {
      return $i51("scp.vt_component.common.util.Validate.fail_ip_format");
    }
    if (verify.ip(v1) && verify.ip(v2) || IPV6.test(v1) && IPV6.test(v2)) {
      return true;
    }
    return false;
  },
  /**
   * 对比ip大小
   *
   * @param {*} v1
   * @param {*} v2
   * @return {number} -1: v1 > v2, 0: v1 = v2, 1: v1 < v2
   */
  ipCompare: function(v1, v2) {
    const errCode = -2;
    let result;
    v1 = format22.trim(v1);
    v2 = format22.trim(v2);
    if (verify.ipTypeEqual(v1, v2) !== true) {
      return errCode;
    }
    if (verify.ip(v1)) {
      result = format22.ip2int(v1) - format22.ip2int(v2);
      if (result > 0) {
        return -1;
      }
      if (result < 0) {
        return 1;
      }
      return 0;
    }
    if (verify.ipv6(v1)) {
      result = ipv6Parse2.compareIp(v1, v2);
      return result;
    }
  },
  /**
   * 判断ip是否在某一个范围里
   *
   * @param {string} ip
   * @param {string[]} rangeArr // [min, max]
   * @returns {boolean}
   */
  isIncludeIp: function(ip, rangeArr) {
    const min = rangeArr[0] || "", max = rangeArr[1] || "";
    return verify.ipCompare(ip, min) <= 0 && verify.ipCompare(ip, max) >= 0;
  },
  /**
   * 校验是否是合法DNS ip
   *
   * @param {string} v
   * @return {boolean} 成功返回true
   */
  dns: function() {
    const dStart = format22.ip2int("224.0.0.0");
    const dEnd = format22.ip2int("239.255.255.255");
    const all = format22.ip2int("255.255.255.255");
    return function(v) {
      if (verify.ip(v)) {
        const ipNum = format22.ip2int(v);
        return ipNum && ipNum !== all && (ipNum < dStart || ipNum > dEnd);
      }
      return false;
    };
  }(),
  /**
   * 校验是否是mask
   *
   * @param {string} v
   * @return {boolean} 成功返回true
   */
  mask: function(v) {
    let num, binMask;
    if (verify.ip(v)) {
      num = format22.ip2int(v);
      binMask = format22.leftPad(num.toString(2), 32, "0");
      if (/^(1+0*|0+)$/.test(binMask)) {
        return true;
      }
    }
    return false;
  },
  /**
   * 校验是否是前缀
   *
   * @param {*} v
   */
  prefix: function(v) {
    const pattern = /^(\d|([1-9]\d{0,2}))$/;
    if (!pattern.test(v)) {
      return false;
    }
    v = parseInt(v, 10);
    return v >= 0 && v <= 128;
  },
  /**
   * 校验是否是端口
   *
   * @param {string} v
   * @return {boolean}
   */
  port: function(v) {
    return /^([1-9]\d{0,3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])$/.test(v);
  },
  /**
   * 端口号的校验规则
   * */
  portGroup: function(v) {
    if (/[^0-9,\-]/.test(v)) {
      return $i51("scp.vt_component.common.util.Validate.valid_text");
    }
    v = v.replace(/(^[\s,]+)|([\s,]+$)/g, "").replace(/[,\s]+/g, ",");
    const ports = v.split(",");
    const MIN_PORT = 1;
    const MAX_PORT = 65535;
    for (let i = 0; i < ports.length; i++) {
      const value = ports[i];
      if (value.indexOf("-") > -1) {
        const rang = value.split("-");
        if (rang.length !== 2 || !rang[0] || !rang[1]) {
          return $i51("scp.vt_component.common.util.Validate.valid_range");
        }
        const portStart = format22.trim(rang[0]);
        const portEnd = format22.trim(rang[1]);
        if (Number(portStart) < MIN_PORT || Number(portStart) > MAX_PORT || Number(portEnd) < MIN_PORT || Number(portEnd) > MAX_PORT) {
          return $i51("scp.vt_component.common.util.Validate.valid_prot_range");
        }
        if (Number(portEnd) - Number(portStart) <= 0) {
          return $i51("scp.vt_component.common.util.Validate.valid_prot_format");
        }
      } else if (Number(value) < MIN_PORT || Number(value) > MAX_PORT) {
        return $i51("scp.vt_component.common.util.Validate.valid_prot_scope");
      }
    }
    return true;
  },
  /**
   * 校验输入的是否是1至10位的数字
   *
   * @param {string} v
   * @return {boolean}
   */
  number: function(v) {
    return /^\d{1,10}$/.test(v);
  },
  /**
   * 校验MAC地址是否合法(不含大写字母)，如：00:e0:4c:0e:9a:2f
   *
   * @param {string} v
   * @return {boolean}
   */
  mac: function(v) {
    return /^((\d|[a-f]){2}:){5}(\d|[a-f]){2}$/.test(v);
  },
  /**
   * 校验MAC地址是否合法（包含大写），例：00:E0:4C:0E:9A:2F或00-E0-4C-0E-9A-2F
   *
   * @param {string} v
   * @return {boolean}
   */
  allMac: function(v) {
    return /^((\d|([a-f]|[A-F])){2}:){5}(\d|([a-f]|[A-F])){2}$/.test(v) || /^((\d|([a-f]|[A-F])){2}-){5}(\d|([a-f]|[A-F])){2}$/.test(v);
  },
  /**
   * 校验MTU是否合法，范围200-1500
   *
   * @param {string} v
   * @return {boolean}
   */
  mtu: function(v) {
    const isNumber2 = /^\d{1,4}$/.test(v);
    const isOut = v >= 1e3 && v <= 1500;
    return isNumber2 && isOut;
  },
  /**
   * 校验域名是否合法，
   * 以RFC 1035作为标准，可以用于校验内网的私有域名。
   * 但需注意的是为了和IP区分开，根域名不能是全数字，且长度必须大于1。
   *
   * @param {string} v
   * @returns {boolean}
   */
  domain: function(v) {
    const regex = /^([a-z\d]([-a-z\d]{0,61}[a-z\d])?\.)+[a-z\d]([-a-z\d]{0,61}[a-z\d])?\.?$/i;
    return regex.test(v);
  },
  /**
   * 校验域名或者IP
   *
   * @param {string} v
   * @returns {boolean}
   */
  domainip: function(v) {
    return this.domain(v) || this.ip(v);
  },
  /**
   * 校验时间是否合法，例如：12:12:12
   *
   * @param v
   * @returns {boolean}
   */
  time: function(v) {
    return /^(\d|[0-1]\d|2[0-3]):(\d|[0-5]\d):(\d|[0-5]\d)$/.test(v);
  },
  /**
   * 校验日期是否合法，例如：2010-05-30
   *
   * @param v
   * @returns {boolean}
   */
  date: function(v) {
    if (/^([1-9]\d*)([\-\/])(10|12|0?[13578])([\-\/])(3[01]|[12][0-9]|0?[1-9])$/.test(v)) {
      return true;
    }
    if (/^([1-9]\d*)([\-\/])(11|0?[469])([\-\/])(30|[12][0-9]|0?[1-9])$/.test(v)) {
      return true;
    }
    if (/^([1-9]\d*)([\-\/])(0?2)([\-\/])(2[0-8]|1[0-9]|0?[1-9])$/.test(v)) {
      return true;
    }
    if (/^(([1-9]\d*)?[2468][048]00)([\-\/])(0?2)([\-\/])(29)$/.test(v)) {
      return true;
    }
    if (/^(([1-9]\d*)?[13579][26]00)([\-\/])(0?2)([\-\/])(29)$/.test(v)) {
      return true;
    }
    if (/^(((([1-9]\d*)?[2468])|([1-9]\d*[02468]))?[48])([\-\/])(0?2)([\-\/])(29)$/.test(v)) {
      return true;
    }
    if (/^(([1-9]\d*)?[2468][0])([\-\/])(0?2)([\-\/])(29)$/.test(v)) {
      return true;
    }
    if (/^(([1-9]\d*)?[1357][26])([\-\/])(0?2)([\-\/])(29)$/.test(v)) {
      return true;
    }
    return false;
  },
  /**
   * 校验VLAN ID是否合法，1-4094
   *
   * @param v
   * @returns {boolean}
   */
  vlan: function(v) {
    return /^([1-9]\d{0,2}|[1-3]\d{3}|40[0-8]\d{1}|409[0-4])$/.test(v);
  },
  /**
   * 校验email是否合法，支持中文
   *
   * @param v
   * @returns {*}
   */
  emailIP: function(v) {
    const email = /^[\w\-]+(\.[\w\-]+)*@[\w\u4e00-\u9fa5\-]+(\.[\w\u4e00-\u9fa5\-]+){1,}$/;
    return email.test(v);
  },
  /**
   * 校验是否uuid格式
   *
   * @param {string} v
   * @return {boolean}
   */
  uuid: function(v) {
    return /^[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}$/.test(v);
  },
  /**
   * 校验ipv4，掩码，网关(ipv4与网关必须在同网段内)
   *
   * @param {string} ip 例如：'1.1.1.1'
   * @param {string} mask 例如：'255.0.0.0'
   * @param {string} gateway 例如：'1.1.1.2'
   */
  ipMaskGateway: function(ip, mask, gateway) {
    const ipBitOperation = function(ip2, mask2) {
      return format22.ip2int(ip2) & format22.ip2int(mask2);
    };
    return ipBitOperation(ip, mask) === ipBitOperation(gateway, mask);
  },
  /**
   * ipv4范围校验网关是否同一网段
   *
   * @param {String} ipValue ip范围输入框原始值
   * @param {String} mask    子网掩码
   * @param {String} gateway 网关
   * @returns {Boolean}
   */
  checkIpRangeGateway: function(ipValue, mask, gateway) {
    const { ipRanges, singleIps } = format22.transformIpRange(ipValue);
    const ips = singleIps;
    ipRanges.forEach((range) => {
      ips.push(...range);
    });
    return ips.every((ip) => verify.ipMaskGateway(ip, mask, gateway));
  },
  /**
   * 判断ipv4/ipv6地址是否同网段
   *
   * @param {string} ip1
   * @param {string|number} mask
   * @param {string} ip2
   * @returns {boolean}
   */
  checkNetworkSegment: function(ip1, mask, ip2) {
    ip1 = format22.trim(ip1);
    ip2 = format22.trim(ip2);
    mask = format22.trim(String(mask));
    if (verify.ip(ip1) && verify.ip(ip2) && verify.mask(mask)) {
      return verify.ipMaskGateway(ip1, mask, ip2);
    }
    if (verify.ipv6(ip1) && verify.ipv6(ip2) && verify.prefix(mask)) {
      return ipv6Parse2.isSameSegment(ip1, mask, ip2);
    }
    return false;
  }
};
function typeVerify(value, rule) {
  const type = rule.type;
  const typeList = getOprList(type);
  if (typeList.length) {
    const access = opr(typeList, function(t) {
      const validator4 = getValidator(t.value);
      if (validator4 && validator4.mask) {
        return maskTest(validator4.mask, value, rule);
      }
      return true;
    });
    return access;
  }
  return true;
}

// packages/validator/utils/formatResult.js
import { $i as $i52 } from "@sxf/er-config";
function formatValidateResult(result, rule) {
  if (result && result !== true && rule.label && Array.isArray(result)) {
    const returnValue = [];
    for (let i = 0; i < result.length; i++) {
      let br = "";
      if (/<br\s*.?>/.test(result[i]) && rule.combineErr) {
        br = "<br/>";
      }
      returnValue[i] = rule.label + $i52("scp.vt_component.common.plugins.jquery.vtype.key.symbol") + br + result[i];
    }
    return returnValue;
  }
  return result;
}

// packages/validator/vtype/validate.js
var { isEmpty: isEmpty2 } = lang2;
function errCb(ret, option) {
  if (option && typeof option.cb === "function") {
    if (ret !== true) {
      if (!$12.isArray(ret)) {
        ret = [ret];
      }
    }
    option.cb.call(this, ret, option);
  }
}
function _isValid(v, o) {
  var _a2;
  const UN_KNOW_ERR = $i53("scp.vt_component.common.plugins.jquery.vtype.lib.unknow_error");
  const optionsType = o.type;
  const typeOptions = (_a2 = getValidator(optionsType)) == null ? void 0 : _a2.defaultOptions;
  const isStringValue = typeof v === "string";
  let errMsg;
  if (typeOptions) {
    o = $12.extend(true, typeOptions, o);
  }
  if (o.noValidate) {
    return true;
  }
  if (isStringValue && o.autoTrim !== false) {
    v = v.trim();
  }
  if (isEmpty2(v)) {
    if (o.allowBlank === false) {
      return o.blankText || $i53("scp.vt_component.common.plugins.jquery.vtype.lib.this_field_is_required");
    } else if (o.allowBlank === true) {
      return true;
    }
  }
  if (isStringValue) {
    if (o.minLength !== void 0 && o.minLength !== null) {
      o.minLength = parseInt(o.minLength, 10);
      const len = o.useUTF8Len ? getUTF8Length(v) : v.length;
      if (len < o.minLength) {
        if (NO_ZH_CN_TYPE.indexOf(optionsType) > -1 || o.withoutZh) {
          errMsg = $i53("scp.vt_component.common.plugins.jquery.vtype.lib.min_value_length_error", {
            0: o.minLength
          });
        } else {
          errMsg = $i53("scp.vt_component.common.plugins.jquery.vtype.lib.value_without_zh_length_error", {
            0: o.minLength,
            1: o.useUTF8Len ? Math.ceil(o.minLength / 3) : o.minLength
          });
        }
        return o.minLengthText || errMsg;
      }
    }
    if (o.maxLength !== void 0 && o.maxLength !== null) {
      o.maxLength = parseInt(o.maxLength, 10);
      const len = o.useUTF8Len ? getUTF8Length(v) : v.length;
      if (len > o.maxLength) {
        if (NO_ZH_CN_TYPE.indexOf(optionsType) > -1 || o.withoutZh) {
          errMsg = $i53("scp.vt_component.common.plugins.jquery.vtype.lib.max_value_length_error", {
            0: o.maxLength
          });
        } else {
          errMsg = $i53("scp.vt_component.common.plugins.jquery.vtype.lib.max_value_without_zh_length_error", {
            0: o.maxLength,
            1: o.useUTF8Len ? parseInt(o.maxLength / 3, 10) : o.maxLength
          });
        }
        return o.maxLengthText || errMsg;
      }
    }
    if (optionsType instanceof RegExp) {
      if (!optionsType.test(v)) {
        return o.errText || $i53("scp.vt_component.common.plugins.jquery.vtype.lib.value_format");
      }
    } else if (typeof optionsType === "string") {
      const typeList = getOprList(optionsType);
      if (typeList.length) {
        const access = opr(typeList, function(t) {
          const validator4 = getValidator(t.value);
          if (validator4 && typeof validator4.validate === "function") {
            let ret = validator4.validate(v, o);
            ret = ret || validator4.text || validator4.getText() || UN_KNOW_ERR;
            return ret;
          }
          return true;
        });
        if (access !== true) {
          return access;
        }
      }
    }
  }
  if (typeof o.validator === "function") {
    return o.validator(v, o) || UN_KNOW_ERR;
  }
  return true;
}
function getSelList(dom, sel) {
  let selList = [], options;
  if (sel === null || sel === void 0) {
    options = $12.data(dom, "vtype-options");
    if (options) {
      for (const key in options) {
        if (options.hasOwnProperty(key)) {
          selList.push(key);
        }
      }
    }
  } else {
    if (typeof sel === "string") {
      selList = sel.split(/\s*,\s*/g);
    }
  }
  return selList;
}
function getOption(item, s, options) {
  let o = $12.data(item, "vtype-option");
  if (!o) {
    if (options) {
      o = options[s];
    }
  }
  return o;
}
function validate(options) {
  const { element, rule, silent } = options;
  const validateRules = getFullRule(rule, element);
  const fieldValue = getFieldValue(validateRules, element);
  let ret = _isValid(fieldValue, validateRules);
  if (ret !== true && !$12.isArray(ret)) {
    ret = [ret];
  }
  if (silent !== true) {
    errCb.call(element, ret, validateRules);
  }
  return ret;
}
function isValid(dom, sel, silent) {
  const ret = [], selList = getSelList(dom, sel), options = $12.data(dom, "vtype-options");
  selList.forEach(function(s) {
    $12(s, dom).each(function(idx, item) {
      const o = getOption(item, s, options);
      if (o) {
        const param = { element: item, rule: o, silent };
        const v = validate(param);
        ret.push({
          dom: item,
          isValid: formatValidateResult(v, o)
        });
      }
    });
  });
  return ret;
}
function clearInvalid(dom, sel) {
  const selList = getSelList(dom, sel), options = $12.data(dom, "vtype-options");
  selList.forEach(function(s) {
    $12(s, dom).each(function(idx, item) {
      const o = getOption(item, s, options);
      if (o) {
        if (typeof o.cb === "function") {
          o.cb.call(item, true, o);
        }
      }
    });
  });
}

// packages/validator/vtype/pureValidate.js
function validateSingle(rule, silent) {
  if (!rule) {
    return true;
  }
  const result = validate({ rule, silent });
  return formatValidateResult(result, rule);
}
function validateAll(validateCfg, silent) {
  const keys = Object.keys(validateCfg);
  const allRes = [];
  keys.forEach((key) => {
    const res = validateSingle(validateCfg[key], silent);
    if (res !== true) {
      allRes.push(res.join($i54("scp.vt_component.sf_widget.src.utils.validate_util.error_msg_connector")));
    }
  });
  return allRes.length ? allRes : true;
}
var pureValidate_default = { validateAll, validateSingle };

// packages/validator/vtype/index.js
import $15 from "jquery";

// packages/validator/vtype/event.js
import $13 from "jquery";
import logger from "@sxf/er-utils/logger";
var vtypeLogger = logger("vtype");
var VALIDATE_TIME = 200;
function bindKeyPress(dom, sel, options) {
  if (!options) {
    return;
  }
  const eventName = fixEventName("keypress");
  $13(dom).off(eventName, sel).on(eventName, sel, function(event) {
    const o = options[sel];
    const me = this;
    if (!o) {
      return;
    }
    if (filterKey(event)) {
      return;
    }
    const optionsType = o.type || $13(this).attr("type");
    const key = String.fromCharCode(event.which);
    if (!maskTest.call(me, o.mask, key, o)) {
      event.stopPropagation();
      event.preventDefault();
      return false;
    }
    if (optionsType instanceof RegExp) {
      return;
    }
    const typeList = getOprList(optionsType);
    if (typeList.length) {
      const access = opr(typeList, function(t) {
        const validator4 = getValidator(t.value);
        if (validator4 && validator4.mask) {
          return maskTest.call(me, validator4.mask, key, o);
        }
        return true;
      });
      if (access !== true) {
        event.stopPropagation();
        event.preventDefault();
        return false;
      }
    }
    return true;
  });
}
function bindEvent(dom, sel, options, oldOptions) {
  if (!options) {
    return;
  }
  const $dom = $13(dom);
  const validateID = $dom.data("vtype.delay.id");
  if (validateID) {
    clearTimeout(validateID);
  }
  const $field = $dom.find(sel);
  if ($field.length) {
    $13.data($field.get(0), "vtype-option", options[sel]);
  } else {
    vtypeLogger.error("can't find element: ", sel);
  }
  const fn = function() {
    let isRunning = false;
    let id = $dom.data("vtype.delay.id");
    if (id) {
      clearTimeout(id);
    }
    return function() {
      const me = this;
      function run() {
        const o = options[sel];
        isRunning = false;
        if (!o) {
          return;
        }
        const param = { element: me, rule: o };
        validate(param);
      }
      if (isRunning) {
        clearTimeout(id);
      }
      id = setTimeout(run, VALIDATE_TIME);
      $dom.data("vtype.delay.id", id);
      isRunning = true;
    };
  }();
  const oldEventname = fixEventName(
    oldOptions && oldOptions[sel] && oldOptions[sel].event || "keypress blur",
    "vtype.custom"
  );
  const eventName = fixEventName(options[sel].event || "keypress blur", "vtype.custom");
  $13(dom).off(oldEventname, sel).on(eventName, sel, fn);
  $13(dom).off(fixEventName("keydown", "vtype.backspace"), sel).on(fixEventName("keydown", "vtype.backspace"), sel, function(event) {
    const key = normalizeKey(event.keyCode || event.charCode);
    if (key === 8) {
      fn.apply(this, arguments);
    }
  });
}
function fixEventName(eventName, id) {
  id = id || "vtypes";
  return eventName.split(/\s+/).map(function(name) {
    return name ? name + "." + id : "";
  }).join(" ");
}
function bind(dom, sel, options) {
  const oldOptions = $13.data(dom, "vtype-options");
  const args = $13.makeArray(arguments);
  $13.data(dom, "vtype-options", options);
  bindKeyPress.apply(this, args);
  bindEvent.apply(this, args.concat([oldOptions]));
}

// packages/validator/vtype/validateUtil.js
import $14 from "jquery";
import { $i as $i55 } from "@sxf/er-config";
import apply from "@sxf/er-utils/apply";
import { showErr } from "@sxf/er-widget/messageBox";
import { hint, toggleTip } from "@sxf/er-widget/tooltip";
var checkInput = function(ret, cfg, el) {
  el = $14(el || this);
  setVTypeResult(el, ret);
};
var checkError = function(errList, fn) {
  const e = [];
  errList.forEach(function(item) {
    if (item.isValid !== true) {
      Array.prototype.push.apply(e, item.isValid);
    }
  });
  if (e.length) {
    showErr(e.join("\n"), $i55("scp.vt_component.sf_widget.src.utils.validate_util.check_error_msg"), function() {
      if (typeof fn === "function") {
        fn();
      }
    });
  }
  return !e.length;
};
var isValid2 = function(el, sel, silent) {
  if (!el) {
    return;
  }
  const errList = el.vtype("isValid", sel, silent), ret = [];
  if ($14.isArray(errList)) {
    errList.forEach(function(item) {
      if (item.isValid !== true) {
        ret.push(item.isValid.join($i55("scp.vt_component.sf_widget.src.utils.validate_util.error_msg_connector")));
      }
    });
  }
  return ret.length ? ret : true;
};
var valueFnMap = {
  select: ($el) => $el.fixselect("value"),
  treeselect: ($el) => $el.fixtreeselect("value"),
  combogrid: ($el) => $el.fixcombogrid("value")
};
function getValidator2(opt = {}) {
  const fn = valueFnMap[opt.type];
  if (!fn) {
    return () => true;
  }
  return function() {
    let v = fn($14(this));
    if ($14.isFunction(opt.processValue)) {
      v = opt.processValue(v);
    }
    if (!v || !v.length) {
      return opt.emptyMsg || $i55("scp.vt_component.sf_widget.src.utils.validate_util.data_empty_msg");
    }
    return true;
  };
}
var getSelectValidator = function(opt) {
  opt = apply(
    {
      type: "select"
    },
    opt
  );
  return getValidator2(opt);
};
var getTreeselectValidator = function(opt) {
  opt = apply(
    {
      type: "treeselect"
    },
    opt
  );
  return getValidator2(opt);
};
var getCombogridValidator = function(opt) {
  opt = apply(
    {
      type: "combogrid"
    },
    opt
  );
  return getValidator2(opt);
};
var selectValidator = getSelectValidator();
var treeselectValidator = getTreeselectValidator();
var combogridValidator = getCombogridValidator();
selectValidator.getInstance = getSelectValidator;
treeselectValidator.getInstance = getTreeselectValidator;
combogridValidator.getInstance = getCombogridValidator;
function setVTypeResult($el, result, hideHint) {
  if (!$el || !result) {
    return;
  }
  if (result === true) {
    $el.removeClass("invalid");
    hint.call($el, "clear");
  } else {
    $el.addClass("invalid");
    if (!hideHint) {
      hint.call(
        $el,
        "error",
        "bottom",
        result.join($i55("scp.vt_component.sf_widget.src.utils.validate_util.hint_msg_connector"))
      );
    } else {
      hint.call($el, "clear");
    }
  }
  if ($el.is(":focus")) {
    toggleTip($el.get(0));
  }
}
var selectVTypeCb = function(result) {
  setVTypeResult($14(this).next(), result);
};
var treeselectVTypeCb = function(result) {
  setVTypeResult($14(this), result);
};
var combogridVTypeCb = function(result) {
  setVTypeResult($14(this).next().children(".sfis-combogrid-input"), result);
};
var cascaderVTypeCb = function(result) {
  setVTypeResult($14(this), result);
};
var validateUtil_default = {
  checkInput,
  checkError,
  isValid: isValid2,
  setVTypeResult,
  inputVTypeCb: checkInput,
  selectValidator,
  selectVTypeCb,
  treeselectValidator,
  treeselectVTypeCb,
  combogridValidator,
  combogridVTypeCb,
  cascaderVTypeCb
};

// packages/validator/vtype/index.js
function vtype(options) {
  if (typeof options === "string") {
    const sel = arguments[1], still = arguments[2];
    let ret = [];
    this.each(function(idx, dom) {
      switch (options) {
        case "isValid":
          Array.prototype.push.apply(ret, isValid(dom, sel, still));
          break;
        case "clearInvalid":
          clearInvalid(dom, sel);
          break;
        case "options":
          ret.push($15(dom).data("vtype-options"));
          break;
        default:
          break;
      }
    });
    if (options === "options") {
      ret = ret[0];
    }
    return ret;
  } else {
    return this.each(function(idx, dom) {
      for (const sel in options) {
        if (options.hasOwnProperty(sel)) {
          bind(dom, sel, options);
        }
      }
    });
  }
}
$15.fn.vtype = vtype;
export {
  VALIDATE_TIME,
  clearInvalid,
  extendValidator,
  getUTF8Length,
  getValidator,
  isValid,
  maskTest,
  pureValidate_default as pureValidate,
  typeVerify,
  validate,
  validateUtil_default as validateUtil,
  verify,
  vtype
};
