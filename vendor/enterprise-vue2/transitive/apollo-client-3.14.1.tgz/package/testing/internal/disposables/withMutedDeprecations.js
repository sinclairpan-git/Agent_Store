import { withCleanup } from "./withCleanup.js";
import { global as untypedGlobal } from "../../../utilities/globals/index.js";
var muteAllDeprecations = Symbol.for("apollo.deprecations");
var global = untypedGlobal;
export function withMutedDeprecations() {
    var prev = { prevMuted: global[muteAllDeprecations] };
    global[muteAllDeprecations] = true;
    return withCleanup(prev, function (_a) {
        var prevMuted = _a.prevMuted;
        global[muteAllDeprecations] = prevMuted;
    });
}
//# sourceMappingURL=withMutedDeprecations.js.map