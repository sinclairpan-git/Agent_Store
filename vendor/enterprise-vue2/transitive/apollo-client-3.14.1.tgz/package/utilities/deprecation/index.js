var _a;
import { __spreadArray } from "tslib";
import { Slot } from "optimism";
import { invariant, global as untypedGlobal } from "../globals/index.js";
var muteAllDeprecations = Symbol.for("apollo.deprecations");
var deprecationsSlot = Symbol.for("apollo.deprecations.slot");
var global = untypedGlobal;
var slot = ((_a = global[deprecationsSlot]) !== null && _a !== void 0 ? _a : (global[deprecationsSlot] = new Slot()));
function isMuted(name) {
    return global[muteAllDeprecations] || (slot.getValue() || []).includes(name);
}
export function muteDeprecations(name) {
    var args = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        args[_i - 1] = arguments[_i];
    }
    return slot.withValue.apply(slot, __spreadArray([Array.isArray(name) ? name : [name]], args, false));
}
export function warnRemovedOption(options, name, callSite, recommendation) {
    if (recommendation === void 0) { recommendation = "Please remove this option."; }
    warnDeprecated(name, function () {
        if (name in options) {
            globalThis.__DEV__ !== false && invariant.warn(103, callSite, name, recommendation);
        }
    });
}
export function warnDeprecated(name, cb) {
    if (!isMuted(name)) {
        cb();
    }
}
//# sourceMappingURL=index.js.map