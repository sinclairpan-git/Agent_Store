import { Formatters, MessageDescriptor, CustomFormats, OnErrorFn } from './types';
import { FormatXMLElementFn, PrimitiveType, Options } from 'intl-messageformat';
import { MessageFormatElement } from '@formatjs/icu-messageformat-parser';
export declare function formatMessage(config: {
    locale: string;
    timeZone?: string;
    formats: CustomFormats;
    messages: Record<string, string> | Record<string, MessageFormatElement[]>;
    defaultLocale: string;
    defaultFormats: CustomFormats;
    onError: OnErrorFn;
}, state: Formatters, messageDescriptor?: MessageDescriptor, values?: Record<string, PrimitiveType | FormatXMLElementFn<string, string>>, opts?: Options): string;
//# sourceMappingURL=message.d.ts.map