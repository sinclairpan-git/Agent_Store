"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatListToParts = exports.formatList = void 0;
var tslib_1 = require("tslib");
var utils_1 = require("./utils");
var intl_messageformat_1 = require("intl-messageformat");
var error_1 = require("./error");
var LIST_FORMAT_OPTIONS = [
    'localeMatcher',
    'type',
    'style',
];
var now = Date.now();
function generateToken(i) {
    return "".concat(now, "_").concat(i, "_").concat(now);
}
function formatList(opts, getListFormat, values, options) {
    if (options === void 0) { options = {}; }
    var results = formatListToParts(opts, getListFormat, values, options).reduce(function (all, el) {
        var val = el.value;
        if (typeof val !== 'string') {
            all.push(val);
        }
        else if (typeof all[all.length - 1] === 'string') {
            all[all.length - 1] += val;
        }
        else {
            all.push(val);
        }
        return all;
    }, []);
    return results.length === 1 ? results[0] : results;
}
exports.formatList = formatList;
function formatListToParts(_a, getListFormat, values, options) {
    var locale = _a.locale, onError = _a.onError;
    if (options === void 0) { options = {}; }
    var ListFormat = Intl.ListFormat;
    if (!ListFormat) {
        onError(new intl_messageformat_1.FormatError("Intl.ListFormat is not available in this environment.\nTry polyfilling it using \"@formatjs/intl-listformat\"\n", intl_messageformat_1.ErrorCode.MISSING_INTL_API));
    }
    var filteredOptions = (0, utils_1.filterProps)(options, LIST_FORMAT_OPTIONS);
    try {
        var richValues_1 = {};
        var serializedValues = values.map(function (v, i) {
            if (typeof v === 'object') {
                var id = generateToken(i);
                richValues_1[id] = v;
                return id;
            }
            return String(v);
        });
        return getListFormat(locale, filteredOptions)
            .formatToParts(serializedValues)
            .map(function (part) {
            return part.type === 'literal'
                ? part
                : (0, tslib_1.__assign)((0, tslib_1.__assign)({}, part), { value: richValues_1[part.value] || part.value });
        });
    }
    catch (e) {
        onError(new error_1.IntlError(error_1.IntlErrorCode.FORMAT_ERROR, 'Error formatting list.', e));
    }
    // @ts-ignore
    return values;
}
exports.formatListToParts = formatListToParts;
