"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatNumberToParts = exports.formatNumber = exports.getFormatter = void 0;
var utils_1 = require("./utils");
var error_1 = require("./error");
var NUMBER_FORMAT_OPTIONS = [
    'localeMatcher',
    'style',
    'currency',
    'currencyDisplay',
    'unit',
    'unitDisplay',
    'useGrouping',
    'minimumIntegerDigits',
    'minimumFractionDigits',
    'maximumFractionDigits',
    'minimumSignificantDigits',
    'maximumSignificantDigits',
    // ES2020 NumberFormat
    'compactDisplay',
    'currencyDisplay',
    'currencySign',
    'notation',
    'signDisplay',
    'unit',
    'unitDisplay',
    'numberingSystem',
];
function getFormatter(_a, getNumberFormat, options) {
    var locale = _a.locale, formats = _a.formats, onError = _a.onError;
    if (options === void 0) { options = {}; }
    var format = options.format;
    var defaults = ((format &&
        (0, utils_1.getNamedFormat)(formats, 'number', format, onError)) ||
        {});
    var filteredOptions = (0, utils_1.filterProps)(options, NUMBER_FORMAT_OPTIONS, defaults);
    return getNumberFormat(locale, filteredOptions);
}
exports.getFormatter = getFormatter;
function formatNumber(config, getNumberFormat, value, options) {
    if (options === void 0) { options = {}; }
    try {
        return getFormatter(config, getNumberFormat, options).format(value);
    }
    catch (e) {
        config.onError(new error_1.IntlError(error_1.IntlErrorCode.FORMAT_ERROR, 'Error formatting number.', e));
    }
    return String(value);
}
exports.formatNumber = formatNumber;
function formatNumberToParts(config, getNumberFormat, value, options) {
    if (options === void 0) { options = {}; }
    try {
        return getFormatter(config, getNumberFormat, options).formatToParts(value);
    }
    catch (e) {
        config.onError(new error_1.IntlError(error_1.IntlErrorCode.FORMAT_ERROR, 'Error formatting number.', e));
    }
    return [];
}
exports.formatNumberToParts = formatNumberToParts;
