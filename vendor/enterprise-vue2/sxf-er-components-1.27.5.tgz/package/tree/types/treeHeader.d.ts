import Vue from 'vue';

interface SfTreeHeaderProps {
  placeholder: string;
  tree?: string;
  noExpand?: boolean;
  isOnlyOneTreeHeaderBtn?: boolean;
  searchOptions?: {
    [key: string]: any;
  };
  lazySearch?: boolean;
  autoExpandAll?: boolean;
}

export declare type SfTreeHeader = Readonly<SfTreeHeaderProps> & Vue;
