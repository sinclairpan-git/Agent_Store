export interface SfTreeOptions<T = Record<string, any>> {
  /**
   * tree组件的class
   */
  cls?: string;
  /**
   * 加在$view上的css类
   */
  viewCls?: string;
  treeHeight?: string;
  treeMinHeight?: string;
  treeMaxHeight?: string;

  /**
   * 每一个节点的高度
   */
  lineHeight?: string;

  /**
   * 是否显示头部栏
   */
  needHeader?: boolean;
  /**
   * 树组件头部以下区域的背景色
   */
  treeBgColor?: string;

  /**
   *  是否是虚线样式，默认为true
   */
  treeDottedStyle?: boolean;

  /**
   * tree组件的层级缩进，当treeDottedStyle为true时强制为22px
   */
  indentWidth?: string;
  /**
   * 搜索框的占位符
   */
  searchString?: string;

  /**
   * 搜索输入框输入长度限制
   */
  searchLimit?: boolean | number;
  /**
   * 长度限制计算utf8长度
   */
  searchUseUTF8Len?: boolean | number;
  /**
   * 搜索时是否区分大小写
   */
  searchCaseSensitive?: boolean;

  /**
   * 是否默认展开所有节点
   */
  autoExpandAll?: boolean;
  /**
   * 是否自动排序，默认true。排序时，组节点先排在前面
   */
  isSort?: boolean;
  /**
   * 默认分组的id
   */
  theDftGrpId?: string;
  /**
   * 组排序时，是否把"默认分组"放到最后
   */
  pushTheDftGrpLast?: boolean;
  /**
   * 是否显示树的根节点
   */
  showRoot?: boolean;
  /**
   * 是否显示分组里面的数据节点
   */
  showNode?: boolean;

  /**
   * 是否有横向滚动条，为false时，将自动计算name的width
   */
  autoScrollX?: boolean;
  /**
   * 节点描述的字段，为非真时代表不显示描述
   */
  descField?: string;
  /**
   * 节点描述的行高
   */
  descLineHeight?: string;
  /**
   * 根节点的默认数据
   */
  rootInfo?: {
    id?: string;
    name?: string;
    type?: string;
  };
  /**
   * 是否双击展开和收缩
   */
  toggleGroupWhenDblclick?: boolean;
  /**
   * 是否响应鼠标右键，配置为true时，组件触发view-r-click事件
   */
  bindViewRClick?: boolean;
  /**
   * 数据节点是否可拖拽
   */
  nodeDraggable?: boolean;

  /**
   * uuid的字段，配置此项需保证唯一性，否则会出现数据覆盖。不配此项uuid将由所有祖先节点的id加此节点的id用uuidSeparator拼接而成
   */
  uuidField?: string;
  /**
   * uuid的连接符
   */
  uuidSeparator?: string;
  /**
   * 数据节点和分组节点的id字段，若配置了下方的IdField，则该值不起效
   */
  idField?: string;
  /**
   *  数据节点和分组节点的name字段，若配置了下方的NameField，则该值不起效
   */
  nameField?: string;
  nodeIdField?: string;
  groupIdField?: string;
  nodeNameField?: string;
  groupNameField?: string;
  /**
   * 子节点的字段
   */
  childrenField?: string;
  /**
   * 节点是否有菜单
   */
  hasMenu?: boolean;
  /**
   * 根据当前节点数据判断是否显示菜单，与配置项hasMenu搭配使用
   *
   * @param data 节点数据
   */
  isShowMenu?: (data: T) => boolean;
  /**
   * 判断当前数据为分组
   *
   * @param data 节点数据
   */
  isGroupFn?: (data: T) => boolean;
  /**
   * 重新渲染节点
   *
   * @param name 节点显示的数据
   * @param data 节点数据
   */
  renNameFn?: (name: string, data: T) => string;
  /**
   * 重新渲染节点名称
   *
   * @param name 节点显示的数据
   * @param data 节点数据
   */
  renNameTextFn?: (name: string, data: T) => string;
  /**
   * .name-line元素 后面追加的内容，比如横向滚动时，把图标放到该位置
   *
   * @param data 节点数据
   */
  renRowExtraContent?: (data: T) => string;
  /**
   * 在节点的右侧显示信息提示
   *
   * @param name 用于显示的文字
   * @param data 节点数据
   */
  tipFn?: (name: string, data: T) => string;
  /**
   * 组的排序方法。 当isSort为true时生效，默认为localeCompare。null时不排序
   *
   * @param pre 需要比较的节点
   * @param next 需要比较的另一个节点
   */
  groupSortFn?: (pre: T, next: T) => boolean;
  /**
   * 叶子的排序方法。 当isSort为true时生效，默认为localeCompare。null时不排序
   *
   * @param pre 需要比较的节点
   * @param next 需要比较的另一个节点
   */
  nodeSortFn?: (pre: T, next: T) => boolean;
  /**
   * 是否多选
   */
  multiSelect?: boolean;
  /**
   * 多选时是否把复选框放在最左边
   */
  pushCheckboxLeftSide?: boolean;
  /**
   * 多选时是否只对当前节点有反应，跟父节点和子节点没关系
   */
  selectAlone?: boolean;
  /**
   * 多选时是否只在点击复选框时触发选中
   */
  selectSimple?: boolean;
  /**
   * 禁用check的规则
   *
   * @param data 节点数据
   */
  disableCheckFn?: (data: T) => boolean;
  /**
   * 不可选的check，适用于单选，与disable的区别在于：disabled有禁用样式
   *
   * @param data 节点数据
   */
  unselectableCheckFn?: (data: T) => boolean;
  /**
   * 是否忽略该条数据，即不显示该数据，也不计入节点总数中
   *
   * @param data 节点数据
   */
  ignoreItemFn?: (data: T) => boolean;
  /**
   * 分组节点图标的class，可以是string,也可以是function
   *
   * @param data 节点数据
   */
  groupIconCls?: (data: T) => string;
  /**
   * 数据节点图标的class，可以是string,也可以是function
   *
   * @param data 节点数据
   */
  nodeIconCls?: (data: T) => string;
  /**
   * 监听事件列表
   */
  listeners?: {
    'item-select'?: (data: T) => void;
  };
  ajax?: { api: any };
  /**
   * 对请求的数据进行处理
   *
   * @param data 节点数据
   */
  processData?: (data: T[]) => T[];
}

interface ActiveOptions {
  inactivateOthers?: boolean;
  emitSelectEvent?: boolean;
  activeAllChildren?: boolean;
  updateParentStatus?: boolean;
  inactiveAllChildren?: boolean;
}

interface DescendantOptions {
  /**
   * 只取数据节点
   */
  onlyNode?: boolean;
  /**
   * 只取分组节点
   */
  onlyGroup?: boolean;
}

interface TreeNodeStatus {
  /**
   * 同一父级分组下的第一个元素
   */
  isTop: boolean;

  /**
   * 同一父级分组下的最后一个元素
   */
  isBottom: boolean;

  /**
   * 选中
   */
  isSelected: boolean;

  isAllLabel: boolean;

  /**
   * 层级（最外层为 0 ）
   */
  deep: number;
}

interface ExpandOptions {
  /**
   * 是否同时更改所有父节点的展开/收起状态
   */
  affectParents?: boolean;

  /**
   * 是否收起指定分组下的所有子分组
   */
  affectChildren?: boolean;

  /**
   * 是否展开指定的节点，为true则展开，否则保持原来的状态
   */
  expandSelf?: boolean;
}

interface ItemOptions {
  getGroup?: boolean;
  getNode?: boolean;
  selectable?: boolean;
  unselectable?: boolean;
  enable?: boolean;
  disable?: boolean;
  expanded?: boolean;
  searched?: boolean;
  collapsed?: boolean;
  unsearched?: boolean;
  hasChild?: boolean;
  uuid?: string;
  deep?: number;
}

interface ScrollOptions {
  /**
   * 如果指定的节点未显示，是否展开到此节点来让这个节点显示出来
   */
  autoExpand?: boolean;
  /**
   * 自定义的偏移值，默认显示到最顶部
   */
  offsetTop?: boolean;
}

export interface SfTreeProps<T = Record<string, any>> {
  /**
   * 传入Tree配置
   */
  readonly options: SfTreeOptions<T>;
}

export interface SfTreeMethods<T = Record<string, any>> {
  /**
   * 展开 收缩 数据加载 搜索 等操作
   */
  updateScrollbar(): void;

  /**
   * 展示
   */
  show(): void;

  /**
   * 隐藏
   */
  hide(): void;

  /**
   * 更新view里元素的样式
   *
   * @param style 样式
   */
  updateViewStyle(style: string): void;

  /**
   * 设置为选中
   *
   * @param uuid 唯一标识
   * @param opt 判断条件
   */
  setItemActive(uuid: string, opt?: ActiveOptions): void;

  /**
   * 设置为未选中
   *
   * @param uuid 唯一标识
   * @param opt 判断条件
   */
  setItemInactive(uuid: string, opt?: ActiveOptions): void;

  /**
   * 实时更新树头搜索框的placeholder
   *
   * @param placeholder placeholder值
   */
  updateSearchString(placeholder: string): void;

  /**
   * 设置为半选中状态
   *
   * @param uuid  唯一标识
   */
  setItemHalfActive(uuid: string): void;

  /**
   * 设置父类状态
   *
   * @param uuid 唯一标识
   */
  setParentStatus(uuid: string): void;

  /**
   * 获取某一节点的所有父级节点数据
   *
   * @param uuid 唯一标识
   */
  getAllParentsRecord(uuid: string): T[];

  /**
   * 获取某一分组下所有的后代数据
   *
   * @param uuid 唯一标识
   * @param opt 参数
   */
  getAllDescendantRecord(uuid: string, opt?: DescendantOptions): T[];

  /**
   * 只取数据节点下所有的后代数据
   *
   * @param uuid 唯一标识
   */
  getAllDescendantNodeRecord(uuid: string): T[];

  /**
   * 只取分组节点下所有的后代数据
   *
   * @param uuid 唯一标识
   */
  getAllDescendantGroupRecord(uuid: string): T[];

  /**
   * 获取某个item的record通过uuid
   *
   * @param uuid 指定节点的uuid
   */
  getItemRecord(uuid: string): T;

  /**
   * 获取某个item的record通过dom
   *
   * @param dom 指定节点的dom或jQuery对象
   */
  getItemRecordByDom(dom: Element | JQuery): T;

  /**
   * 获取选中的结果
   */
  getSelectedValue(): T[];

  /**
   * 获取某个item的一些状态信息
   *
   * @param uuid 指定节点的uuid
   */
  getItemStatus(uuid: string): TreeNodeStatus;

  /**
   * 设置选中的结果
   *
   * @param uuids 指定节点的uuid数组或单个uuid
   */
  setSelectedValue(uuids: string[] | string): void;

  /**
   * 当ID是唯一的时候可以通过此函数来获取对应的uuid
   */
  getUuidById(ids: string[] | string): string[] | string;

  /**
   * 取消选择全部
   */
  unSelectAll(): void;

  /**
   * 设置节点的展开/收起状态，
   *
   * @param  {[type]}  $item    [description] jq对象
   * @param  {boolean} stateVal 指定的展开/收起状态，不传时，根据当前的展开/收起状态来改变
   * @param  {object}  opt
   *         {boolean} opt.affectParents   是否同时更改所有父节点的展开/收起状态
   *         {boolean} opt.affectChildren  是否同时更改所有子节点的展开/收起状态
   */
  toggleItemExpanded($item: JQuery, stateVal?: boolean, opt?: ExpandOptions): void;

  /**
   * 设置节点的展开/收起状态，
   *
   * @param $item 节点
   * @param stateVal 指定的展开/收起状态，不传时，根据当前的展开/收起状态来改变
   */
  setItemExpanded($item: JQuery, stateVal?: boolean): void;

  /**
   * （用的地方太多了，也不好搜，暂保留此方法）
   * 展开指定节点
   *
   * @param  {[type]} uuid              指定节点的uuid
   * @param  {[type]} expandAllParents  是否展开指定分组父级的所有分组
   * @param  {[type]} expandAllChildren 是否展开指定分组下的所有分组
   */
  expand(uuid: string, expandAllParents: boolean, expandAllChildren: boolean): void;

  /**
   * 展开指定节点
   *
   * @param $item 节点
   * @param opt 参数
   */
  expandItem($item: JQuery, opt?: ExpandOptions): void;

  /**
   * 展开指定节点
   *
   * @param uuid uuid
   * @param opt 参数
   */
  expandItemByUuid(uuid: string, opt?: ExpandOptions): void;

  /**
   * 某一节点是否在视野中，（被$view的滚动条滚没了也当作不可视）
   *
   * @param $item 指定节点的jQuery对象
   */
  isItemVisibleInView($item: JQuery): boolean;

  /**
   * 展开树的分组，直到指定节点显示出来。
   *
   * @param $item 指定item
   * @param opt 参数
   */
  expandToItem($item: JQuery, opt?: ExpandOptions): void;

  /**
   * 通过uuid展开树的分组，直到指定节点显示出来。
   *
   * @param uuid 标识
   * @param opt 参数
   */
  expandToItemByUuid(uuid: string, opt?: ExpandOptions): void;

  /**
   * 收起指定分组
   *
   * @param uuid 标识
   * @param collapseAllChildren 是否收起指定分组下的所有子分组
   */
  collapse(uuid: string, collapseAllChildren: boolean): void;

  /**
   * 收起指定分组
   *
   * @param $item  指定item
   * @param opt 参数
   */
  collapseItem($item: JQuery, opt?: ExpandOptions): void;

  /**
   * 收起指定分组
   *
   * @param uuid  标识
   * @param opt 参数
   */
  collapseItemByUuid(uuid: string, opt?: ExpandOptions): void;

  /**
   * 展开全部
   */
  expandAll(): void;

  /**
   * 合上全部
   */
  collapseAll(): void;

  /**
   * 展开第几层
   *
   * @param deep 层数
   * @param expandAllParents 是否同时更改所有父节点的展开/收起状态
   */
  expandNthDeep(deep: number, expandAllParents: boolean): void;

  /**
   * 收起第几层
   *
   * @param deep 层数
   * @param expandAllParents 是否同时更改所有子节点的展开/收起状态
   */
  collapseNthDeep(deep: number, expandAllParents: boolean): void;

  /**
   * 获取满足opt条件的.tree-item。具体配置看getItemSel函数。
   *
   * @param opt 参数
   */
  getItem(opt?: ItemOptions): JQuery;

  /**
   * 通过uuid获取
   *
   * @param uuid 标识
   */
  getItemByUuid(uuid: string): JQuery;

  /**
   * 通过jq对象获取到他的uuid
   *
   * @param $item jq节点对象
   */
  getUuidByItem($item: JQuery): string;

  /**
   * 判断指定节点是否是此tree的tree-item。
   *
   * @param $item 节点对象
   */
  isTreeItem($item: JQuery): boolean;

  /**
   * 滚动tree.$view，使指定的item显示出来
   *
   * @param  {string} $item 指定item
   * @param  {object} opt
   *                  opt.autoExpand 如果指定的节点未显示，是否展开到此节点来让这个节点显示出来
   *                  opt.offsetTop  自定义的偏移值，默认显示到最顶部
   */
  scrollToItem($item: JQuery, opt?: ScrollOptions): void;

  /**
   * 滚动tree.$view，使指定的uuid显示出来
   *
   * @param uuid 指定uuid
   * @param opt 参数
   */
  scrollToItemByUuid(uuid: string, opt?: ScrollOptions): void;

  /**
   * 搜索关键字
   *
   * @param str 关键字
   */
  search(str: string): void;

  /**
   * 清除搜索
   */
  endSearch(): void;

  /**
   * 在父节点中插入当前el
   *
   * @param parent 目标元素
   */
  render(parent: string): void;

  /**
   * 加载数据
   *
   * @param data 树结构
   */
  loadData(data: T[]): void;

  /**
   * 重新绘制
   */
  redraw(): void;

  /**
   * 对数据进行重新组合，每个数据节点有个唯一的uuid，计算出子节点和所有后代节点中分组和节点的数量
   *
   * @example
   * ```
   *     [{
   *         id: 'a',
   *         data: [{
   *             id: 'm',
   *             name: 'mm'
   *         }, {
   *             id: 'n',
   *             name: 'nn'
   *         }]
   *     }, {
   *         id: 'b'
   *     }];
   * ```
   * 会保存为
   * ```
   *     {
   *         'a': {
   *             id: 'a',
   *             data: [{
   *                 id: 'm',
   *                 name: 'mm'
   *             }, {
   *                 id: 'n',
   *                 name: 'nn'
   *             }],
   *             __childrenNodeCount: N,
   *             __childrenGroupCount: N,
   *             __descendantNodeCount: N,
   *             __descendantGroupCount: N,
   *         },
   *         'a.m': {
   *             id: 'm',
   *             name: 'mm'
   *         },
   *         'a.n': {
   *             id: 'n',
   *             name: 'nn'
   *         },
   *         'b': {
   *             id: 'b'
   *         }
   *     }
   * ```
   */
  transformToHash(treeData: T[]): Record<string, any>;

  /**
   * 根据树结构获取到对应的html
   *
   * @param treeData 树结构
   */
  getTreeHtml(treeData: T[]): string;

  /**
   * 获取当前数据是否是根节点
   *
   * @param record 转换后，新增了很多参数的T
   */
  isRoot(record: any): boolean;

  /**
   * 获取当前节点的__id
   *
   * @param node 节点
   */
  getNodeId(node: JQuery): string;

  /**
   * 获取第一个数据
   *
   * @param opt 参数
   */
  getFirstItemRecord(opt?: ItemOptions): T;

  /**
   * 通过节点显示菜单
   *
   * @param target 节点
   */
  showMenuBtn(target: Element): void;

  /**
   * 隐藏菜单
   */
  hideMenuBtn(): void;

  /**
   * 设置高度样式
   *
   * @param height 高度如 40px
   */
  setTreeHeight(height: string): void;

  /**
   * 获取树的实例
   */
  getTreeEl(): Element;
}

export interface SfTreeEvents<T = Record<string, any>> {
  /**
   * 点击选中
   *
   * @param event 事件类型
   * @param data 对应的数据
   */
  $emit(event: 'item-select', data: T): this;

  /**
   * 点击取消选中
   *
   * @param event 事件类型
   * @param data 对应的数据
   */
  $emit(event: 'item-unselect', data: T): this;

  /**
   * 设置选中
   *
   * @param event 事件类型
   * @param data 对应的数据
   */
  $emit(event: 'item-active', data: T): this;

  /**
   * 设置非选中
   *
   * @param event 事件类型
   * @param data 对应的数据
   */
  $emit(event: 'item-inactive', data: T): this;

  /**
   * 设置非选中
   *
   * @param event 事件类型
   * @param $group 对应的节点JQ对象
   */
  $emit(event: 'hand-toggle-group', $group: JQuery): this;

  /**
   * 当存在横向滚动条时触发
   *
   * @param event 事件类型
   */
  $emit(event: 'hand-toggle-all-group'): this;

  /**
   * 搜索
   *
   * @param event 事件类型
   * @param str 搜索的关键字
   * @param $searched 搜索到的节点的对象数组
   */
  $emit(event: 'search-done', str: string, $searched: JQuery[]): this;

  /**
   * 清除搜索
   */
  $emit(event: 'end-search'): this;

  /**
   * $view上右键单击
   *
   * @param event 事件类型
   * @param e 事件对象
   */
  $emit(event: 'view-r-click', e: MouseEvent): this;

  /**
   * 重绘完成
   */
  $emit(event: 'redraw-done'): this;

  /**
   * 加载数据
   *
   * @param event 事件类型
   * @param data 加载的数据
   */
  $emit(event: 'load-data', data: T[]): this;

  /**
   * 调用方法展开收起，非手动触发
   */
  $emit(event: 'fn-toggle-group'): this;

  /**
   * 调用方法展开收起全部，非手动触发
   */
  $emit(event: 'fn-toggle-all-group'): this;

  /**
   * 树菜单点击
   *
   * @param event 事件类型
   * @param e 事件对象
   */
  $emit(event: 'tree-menu-click', e: MouseEvent): this;
}

export declare type SfTree<T = Record<string, any>> = Readonly<SfTreeProps<T> & SfTreeEvents<T> & SfTreeMethods<T>> &
  Vue;
