import $ from 'jquery';
import { componentName } from '@sxf/er-components/_const';
import { AddComponentMixin } from '@sxf/er-components/_mixins';
import { getPrefixedClassName } from '@sxf/er-feature';
import Tree, { getTreeDefaultConfig } from '@sxf/er-widget/tree';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
import { isPropEnabled } from '@sxf/er-components/_utils/vue-utils';
import { SfButton } from '@sxf/er-components/button';
import { SfSearch } from '@sxf/er-components/search';
import { SfToolbar } from '@sxf/er-components/toolbar';
import { $i, globalConfig } from '@sxf/er-config';
import { SfGrid, SfGridColumn, gridEventName } from '@sxf/er-components/grid';
import { when } from '@sxf/er-utils/when';
import { Model } from '@sxf/er-widget/grid';
const methods = Object.keys(Tree.prototype).reduce(function(map, name) {
  if (typeof Tree.prototype[name] === "function" && name !== "constructor") {
    map[name] = function(...args) {
      return this.tree[name](...args);
    };
  }
  return map;
}, {});
var script$2 = {
  name: componentName.tree,
  componentName: componentName.tree,
  mixins: [AddComponentMixin],
  props: {
    treeDottedStyle: {
      type: Boolean,
      default: true
    },
    options: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      records: []
    };
  },
  mounted() {
    this.tree = new Tree(
      $.extend(
        true,
        {},
        {
          treeDottedStyle: this.treeDottedStyle
        },
        this.options
      )
    );
    Object.keys(this.tree.events).forEach((eventName) => {
      this.tree.on(eventName, (...args) => {
        this.$emit(eventName, ...args);
      });
    });
    this.tree.render(this.$refs.tree);
  },
  beforeDestroy() {
    this.tree.destroy();
    this.tree = null;
  },
  methods: {
    ...methods,
    getPrefixedClassName,
    __renderSlot(name, data) {
      return this.$slots[name] || this.$scopedSlots[name] && this.$scopedSlots[name](data);
    },
    __hasSlot(name) {
      return this.$slots[name] || this.$scopedSlots[name];
    }
  }
};
const __vue_script__$2 = script$2;
var __vue_render__$2 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c("div", [
    _c("div", { ref: "tree" }),
    _vm._v(" "),
    _c("div", { class: _vm.getPrefixedClassName("sf-tree_hidden-wrap") })
  ]);
};
var __vue_staticRenderFns__$2 = [];
__vue_render__$2._withStripped = true;
const __vue_inject_styles__$2 = void 0;
const __vue_scope_id__$2 = void 0;
const __vue_module_identifier__$2 = void 0;
const __vue_is_functional_template__$2 = false;
const __vue_component__$2 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$2, staticRenderFns: __vue_staticRenderFns__$2 },
  __vue_inject_styles__$2,
  __vue_script__$2,
  __vue_scope_id__$2,
  __vue_is_functional_template__$2,
  __vue_module_identifier__$2,
  false,
  void 0,
  void 0,
  void 0
);
var script$1 = {
  name: componentName.treeHeader,
  componentName: componentName.treeHeader,
  components: {
    SfButton,
    SfSearch,
    SfToolbar
  },
  props: {
    placeholder: {
      type: String,
      default: () => $i("scp.vt_component.sf_widget.packages.tree.tree_header.search_placeholder")
    },
    tree: String,
    noExpand: Boolean,
    isOnlyOneTreeHeaderBtn: {
      type: Boolean,
      default: true
    },
    searchOptions: {
      default() {
        return {
          ...globalConfig.search
        };
      }
    },
    lazySearch: {
      type: Boolean,
      default: false
    },
    autoExpandAll: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      searchValue: "",
      isExpanded: this.autoExpandAll,
      expandAllTitle: $i("scp.vt_component.sf_widget.packages.tree.tree_header.expand_all_btn"),
      collapseAllTitle: $i("scp.vt_component.sf_widget.packages.tree.tree_header.collapse_bll_btn")
    };
  },
  computed: {
    isNoExpand() {
      return isPropEnabled(this.noExpand);
    },
    searchSlot() {
      return this.isNoExpand ? "stretch" : "right";
    },
    searchClass() {
      return {
        [getPrefixedClassName("is-full")]: this.isNoExpand
      };
    },
    slotScope() {
      return {
        search: this.search,
        searchHandler: this.__handleSearch,
        expandAll: this.__expandAll,
        collapseAll: this.__collapseAll
      };
    }
  },
  watch: {
    searchValue() {
      if (!this.lazySearch) {
        this.search(this.searchValue);
      }
    }
  },
  mounted() {
    if (this.tree) {
      this.setTarget(this.$vnode.context.$refs[this.tree]);
      if (this.isNoExpand) {
        this.treeVm.$on("update-toolbar-stutas", (data) => {
          this.isExpanded = data;
        });
      }
    }
  },
  methods: {
    getPrefixedClassName,
    getFullUtid(utidBase) {
      return this.$attrs.utid ? `${this.$attrs.utid}-${utidBase}` : utidBase;
    },
    setTarget(target) {
      this.treeVm = target;
    },
    search(value) {
      if (this.treeVm) {
        this.treeVm.search(value);
        return;
      }
      this.$emit("search", value);
    },
    clearSearch() {
      this.searchValue = "";
    },
    __handleSearch(data, isEndSearch) {
      if (this.treeVm) {
        if (isEndSearch) {
          this.treeVm.endSearch();
          return;
        }
        this.treeVm.search(data.value);
      } else {
        this.$emit("search", data, isEndSearch);
      }
    },
    __handleClear() {
      this.__handleSearch({ value: "" }, true);
      this.$emit("clear-search");
    },
    __expandAll() {
      if (this.treeVm) {
        this.treeVm.expandAll();
      } else {
        this.$emit("expand-all");
      }
      this.isExpanded = true;
    },
    __collapseAll() {
      if (this.treeVm) {
        this.treeVm.collapseAll();
      } else {
        this.$emit("collapse-all");
      }
      this.isExpanded = false;
    }
  }
};
const __vue_script__$1 = script$1;
var __vue_render__$1 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    { class: _vm.getPrefixedClassName("sf-tree-header") },
    [
      _vm._t(
        "default",
        [
          _c(
            "sf-toolbar",
            [
              !_vm.isNoExpand ? [
                !_vm.isOnlyOneTreeHeaderBtn || !_vm.isExpanded ? _c("sf-button", {
                  key: "expand",
                  class: [
                    "btn-icon",
                    _vm.getPrefixedClassName("icon-tree-wrap")
                  ],
                  attrs: {
                    utid: _vm.getFullUtid("tree-header-expand"),
                    type: "normal",
                    icon: "tree-folded",
                    "icon-only": "",
                    title: _vm.expandAllTitle
                  },
                  on: { click: _vm.__expandAll }
                }) : _vm._e(),
                _vm._v(" "),
                !_vm.isOnlyOneTreeHeaderBtn || _vm.isExpanded ? _c("sf-button", {
                  key: "collapse",
                  class: [
                    "btn-icon",
                    _vm.getPrefixedClassName("icon-tree-expand")
                  ],
                  attrs: {
                    utid: _vm.getFullUtid("tree-header-collapse"),
                    type: "normal",
                    icon: "tree-expanded",
                    "icon-only": "",
                    title: _vm.collapseAllTitle
                  },
                  on: { click: _vm.__collapseAll }
                }) : _vm._e()
              ] : _vm._e(),
              _vm._v(" "),
              _c(
                "template",
                { slot: _vm.searchSlot },
                [
                  _c(
                    "sf-search",
                    _vm._b(
                      {
                        class: [
                          _vm.getPrefixedClassName("sf-tree-header_search"),
                          _vm.searchClass
                        ],
                        attrs: {
                          utid: _vm.getFullUtid("tree-header-search"),
                          placeholder: _vm.placeholder
                        },
                        on: {
                          search: _vm.__handleSearch,
                          clear: _vm.__handleClear
                        },
                        model: {
                          value: _vm.searchValue,
                          callback: function($$v) {
                            _vm.searchValue = $$v;
                          },
                          expression: "searchValue"
                        }
                      },
                      "sf-search",
                      _vm.searchOptions,
                      false
                    )
                  )
                ],
                1
              )
            ],
            2
          )
        ],
        null,
        _vm.slotScope
      )
    ],
    2
  );
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
const TREE_METHODS = Object.keys(Tree.prototype).filter((fnName) => {
  return typeof Tree.prototype[fnName] === "function" && fnName !== "constructor";
});
var script = {
  name: componentName.treeTable,
  componentName: componentName.treeTable,
  components: {
    SfGrid,
    SfGridColumn,
    SfTreeHeader: __vue_component__$1
  },
  props: {
    options: {
      type: Object,
      default: () => ({})
    },
    treeHeaderOptions: {
      type: Object,
      default: () => ({})
    },
    beforeExpandAll: {
      type: [Function, null],
      default: () => true
    },
    loadChildren: {
      type: [Function, null],
      default: null
    }
  },
  data() {
    return {
      treeOptions: this.transformTreeOptions()
    };
  },
  computed: {
    cls() {
      return this.treeOptions.cls;
    },
    needHeader() {
      return this.treeOptions.needHeader;
    },
    autoExpandAll() {
      return this.treeOptions.autoExpandAll;
    },
    searchString() {
      return this.treeOptions.searchString;
    },
    treeField() {
      return this.treeOptions.nameField;
    },
    curTreeHeaderOptions() {
      return {
        lazySearch: true,
        placeholder: this.searchString,
        autoExpandAll: this.autoExpandAll,
        ...this.treeHeaderOptions
      };
    },
    treeGridOptions() {
      return {
        noHeader: true,
        size: "small",
        border: false,
        store: {
          idProperty: "path"
        },
        ...this.treeOptions.gridOpt,
        height: this.parseHeight(this.treeOptions.treeHeight),
        minHeight: this.parseHeight(this.treeOptions.treeMinHeight),
        maxHeight: this.parseHeight(this.treeOptions.treeMaxHeight),
        plugins: [
          {
            pluginID: "RadioSelection",
            hideRadio: true,
            silentSelect: true,
            listeners: {
              change: (sel, records) => {
                var _a;
                const listeners = this.treeOptions.listeners;
                if (!listeners["item-select"]) {
                  return;
                }
                const selectedRecord = ((_a = records[0]) == null ? void 0 : _a.data) || {};
                listeners["item-select"](selectedRecord);
              }
            }
          },
          {
            pluginID: "Tree",
            needRoot: this.treeOptions.showRoot,
            rootText: this.treeOptions.rootInfo.name,
            multiRoot: true,
            radioCanSelectGroup: true,
            hiddenIcon: true,
            autoScrollX: true,
            rowCls: (record) => {
              if (typeof this.treeOptions.disableCheckFn !== "function") {
                return "";
              }
              return getPrefixedClassName(this.treeOptions.disableCheckFn(record.data) ? "disabled" : "");
            },
            search: {
              includeGroup: true
            },
            selectAbleFn: (record) => {
              const disabled = typeof this.treeOptions.disableCheckFn === "function" ? this.treeOptions.disableCheckFn(record.data) : false;
              const unselectable = typeof this.treeOptions.unselectableCheckFn === "function" ? this.treeOptions.unselectableCheckFn(record.data) : false;
              return !disabled && !unselectable;
            },
            ...this.treeOptions,
            nodeDraggable: !!this.treeOptions.nodeDraggable
          }
        ]
      };
    },
    stepLoad() {
      return this.treeOptions.stepLoad;
    }
  },
  mounted() {
    this.initData();
    if (this.stepLoad && typeof this.loadChildren === "function") {
      this.handleStepLoad();
    }
  },
  methods: {
    getPrefixedClassName,
    getGrid() {
      return this.$refs.treeGrid;
    },
    getTree() {
      return this.$refs.treeGrid.getPlugin("Tree");
    },
    updateSearchPlaceholder(value) {
      this.treeOptions.searchString = value;
    },
    setTreeTarget() {
      const tree = this.getTree();
      this.$refs.treeHeader.setTarget(tree);
    },
    reload() {
      const grid = this.getGrid();
      grid.reload();
    },
    initData() {
      this.tree = this.getTree();
    },
    transformTreeOptions() {
      const options = {
        gridOpt: {},
        ...getTreeDefaultConfig(),
        ...this.options
      };
      options.listeners = {
        ...this.$listeners,
        ...options.listeners || {}
      };
      if (typeof options.renNameFn !== "undefined") {
        options.renderer = function(name, record) {
          return options.renNameFn.call(this, name, record.data);
        };
      }
      if (typeof options.isShowMenu !== "undefined") {
        const isShowMenu = options.isShowMenu;
        options.isShowMenu = function(record) {
          return isShowMenu.call(this, record.data);
        };
      }
      return options;
    },
    groupIconCls(record) {
      return typeof this.treeOptions.groupIconCls === "function" ? this.treeOptions.groupIconCls(record == null ? void 0 : record.data) : this.treeOptions.groupIconCls;
    },
    nodeIconCls(record) {
      return typeof this.treeOptions.nodeIconCls === "function" ? this.treeOptions.nodeIconCls(record == null ? void 0 : record.data) : this.treeOptions.nodeIconCls;
    },
    parseHeight(height) {
      return typeof height === "string" && /^\d+px$/.test(height) ? parseInt(height, 10) : height;
    },
    ...TREE_METHODS.reduce((methods2, fnName) => {
      methods2[fnName] = function() {
        const tree = this.getTree();
        const res = tree[fnName].apply(tree, arguments);
        return res instanceof Model ? res.data : res;
      };
      return methods2;
    }, {}),
    expandAll(...args) {
      const tree = this.getTree();
      tree.expandAll.call(tree, ...args);
      if (this.needHeader) {
        this.$refs.treeHeader.isExpanded = true;
      }
    },
    collapseAll(...args) {
      const tree = this.getTree();
      tree.collapseAll.call(tree, ...args);
      if (this.needHeader) {
        this.$refs.treeHeader.isExpanded = false;
      }
    },
    loadData(...args) {
      const tree = this.getTree();
      tree.loadData.apply(tree, args);
      this.getGrid().redraw();
    },
    scrollToNode(nodeId, options = {}) {
      var _a, _b;
      const expandAll = (_a = options.expandAll) != null ? _a : true;
      const active = (_b = options.active) != null ? _b : false;
      if (expandAll) {
        this.expandAll();
      } else {
        this.getTree().expandTo(nodeId);
      }
      const start = this.getGrid().store.dataList.findIndex((id) => id === nodeId);
      this.getTree().grid.renderView(start);
      this.getTree().grid.resetScrollPosition();
      if (active) {
        this.getTree().setItemActive(nodeId);
      }
    },
    loadingTo(ids, state) {
      const tree = this.getTree();
      tree.loadingTo.apply(tree, [ids, state]);
    },
    refresh() {
      const tree = this.getTree();
      tree.refresh.apply(tree);
    },
    dispatchSearch(data, isEndSearch) {
      if (this.stepLoad) {
        this.$emit("step-load-search", data.value, isEndSearch);
        return;
      }
      this.$emit("load-search", data.value, isEndSearch);
      if (isEndSearch) {
        this.tree.endSearch();
        return;
      }
      this.tree.search(data.value);
    },
    async dispatchExpandAll() {
      await this.beforeExpandAll();
      this.tree.expandAll({ silent: true });
      this.$emit("hand-toggle-all-group", { expanded: true });
    },
    dispatchCollapseAll() {
      this.tree.collapseAll(false, { silent: true });
      this.$emit("hand-toggle-all-group", { expanded: false });
    },
    handleStepLoad() {
      this.tree.on(gridEventName.tree.expand, (treePlugin, id, nodeRecord) => {
        if (!nodeRecord) {
          return;
        }
        const nodeData = nodeRecord.data;
        when(this.loadChildren({ nodeData })).then((children) => {
          this.mergeTreeData({ id, children });
        });
      });
    },
    mergeTreeData(params) {
      if (!Array.isArray(params)) {
        params = [params];
      }
      this.tree.batchUpdateTreeNodeData(params);
    },
    handleClearSearch() {
      this.$emit("clear-search");
    }
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    { class: [_vm.getPrefixedClassName("sf-tree-table"), _vm.cls] },
    [
      _vm.needHeader ? _c(
        "sf-tree-header",
        _vm._b(
          {
            ref: "treeHeader",
            on: {
              search: _vm.dispatchSearch,
              "expand-all": _vm.dispatchExpandAll,
              "collapse-all": _vm.dispatchCollapseAll,
              "clear-search": _vm.handleClearSearch
            }
          },
          "sf-tree-header",
          _vm.curTreeHeaderOptions,
          false
        )
      ) : _vm._e(),
      _vm._v(" "),
      _c(
        "sf-grid",
        { ref: "treeGrid", attrs: { options: _vm.treeGridOptions } },
        [
          _c("sf-grid-column", {
            attrs: {
              field: _vm.treeField,
              tip: "auto",
              "group-icon-cls": _vm.groupIconCls,
              "icon-cls": _vm.nodeIconCls,
              width: "100%",
              "is-auto-fit-width": true
            }
          })
        ],
        1
      )
    ],
    1
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__$2 as SfTree, __vue_component__$1 as SfTreeHeader, __vue_component__ as SfTreeTable };
