import { componentName } from '@sxf/er-components/_const';
import { vOnShow } from '@sxf/er-components/_directives';
import { getPrefixedClassName } from '@sxf/er-feature';
import { throttle } from '@sxf/er-utils/delay';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
function fixName(name) {
  return name.replace(/[A-Z]/g, (value) => "-" + value.toLowerCase());
}
var script$1 = {
  name: componentName.flex,
  componentName: componentName.flex,
  directives: {
    "on-show": vOnShow
  },
  props: {
    flexDirection: String,
    flexWrap: String,
    justifyContent: String,
    alignItems: String,
    alignContent: String,
    gutter: [Number, String]
  },
  data() {
    return {
      paddingBottom: "0px",
      paddingTop: "0px",
      borderBottomWidth: "0px",
      borderTopWidth: "0px"
    };
  },
  computed: {
    cls() {
      return ["flexDirection", "flexWrap", "justifyContent", "alignItems", "alignContent"].reduce((arr, name) => {
        const cssValue = this[name];
        if (cssValue) {
          arr.push(getPrefixedClassName(`sf-flex--${fixName(name)}-${cssValue}`));
        }
        return arr;
      }, []);
    },
    style() {
      const gutter = Number(this.gutter) || 0;
      const style = {
        maxWidth: "100%"
      };
      if (gutter) {
        style.marginLeft = style.marginRight = style.marginTop = style.marginBottom = `-${gutter / 2}px`;
        style.maxWidth = `calc(100% + ${gutter}px)`;
      }
      return style;
    },
    holderStyle() {
      const gap = [this.paddingTop, this.paddingBottom, this.borderTopWidth, this.borderBottomWidth].reduce(
        (sum, value) => sum + parseFloat(value),
        0
      );
      return {
        marginTop: `-${gap}px`
      };
    }
  },
  mounted() {
    this.__transitionendFn = throttle(this.__updateBox);
    this.$el.addEventListener("transitionend", this.__transitionendFn);
    this.__updateBox();
  },
  beforeDestroy() {
    this.$el.removeEventListener("transitionend", this.__transitionendFn);
    this.__transitionendFn = null;
  },
  methods: {
    __updateBox() {
      const style = getComputedStyle(this.$el);
      Object.keys(this.$data).forEach((name) => {
        if (name.match(/^(padding|border)/)) {
          this[name] = style[name];
        }
      });
    },
    getPrefixedClassName
  }
};
const __vue_script__$1 = script$1;
var __vue_render__$1 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      directives: [
        {
          name: "on-show",
          rawName: "v-on-show",
          value: _vm.__updateBox,
          expression: "__updateBox"
        }
      ],
      class: _vm.getPrefixedClassName("sf-flex")
    },
    [
      _c(
        "div",
        {
          ref: "inner",
          class: [_vm.getPrefixedClassName("sf-flex_inner")].concat(_vm.cls),
          style: _vm.style
        },
        [_vm._t("default")],
        2
      ),
      _vm._v(" "),
      _c("div", {
        class: _vm.getPrefixedClassName("sf-flex_min-height-holder"),
        style: _vm.holderStyle
      })
    ]
  );
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
function cssValueIsEmpty(value) {
  return !value || value === "none" || parseInt(value, 10) === 0;
}
function hasPadding(computedStyle) {
  return ![
    computedStyle.paddingLeft,
    computedStyle.paddingTop,
    computedStyle.paddingRight,
    computedStyle.paddingBottom
  ].every(cssValueIsEmpty);
}
function hasBorder(computedStyle) {
  return ![
    computedStyle.borderLeftWidth,
    computedStyle.borderTopWidth,
    computedStyle.borderRightWidth,
    computedStyle.borderBottomWidth
  ].every(cssValueIsEmpty);
}
function isStringNumber(str) {
  return str && str.match && str.match(/^\d+$/);
}
function isUnitNumber(str) {
  return str && str.match && str.match(/^\d+[^\d]+$/);
}
var script = {
  name: componentName.flexItem,
  componentName: componentName.flexItem,
  props: {
    order: {},
    flex: {
      default: 1
    },
    alignSelf: {},
    basisWidth: Boolean
  },
  computed: {
    gutter() {
      return this.$parent ? Number(this.$parent.gutter) || 0 : 0;
    },
    cls() {
      const cls = [];
      if (typeof this.alignSelf !== "undefined") {
        cls.push(getPrefixedClassName(`sf-flex-item--align-self-${this.alignSelf}`));
      }
      if (this.basisWidth) {
        cls.push(getPrefixedClassName("sf-flex-item--basis-width"));
      }
      return cls;
    },
    currentFlex() {
      if (!this.flex && this.flex !== 0) {
        return;
      }
      let value = String(this.flex);
      const arr = String(value).trim().split(/\s+/g);
      if (arr.length === 1) {
        if (value === "none") {
          value = "0 0 auto";
        } else if (value === "initial") {
          value = "0 1 auto";
        } else if (value === "auto") {
          value = "1 1 auto";
        } else if (isStringNumber(value)) {
          value = `${value} 1 0%`;
        } else if (isUnitNumber(value)) {
          value = `1 1 ${value}`;
        }
      }
      if (arr.length === 2 && !isStringNumber(arr[1])) {
        value = `${arr[0]} 1 ${arr[1]}`;
      }
      const third = arr[2];
      if (isStringNumber(third)) {
        value = [arr[0], arr[1], `${third}%`].join(" ");
      }
      return value;
    },
    style() {
      const obj = {};
      if (typeof this.order !== "undefined") {
        Object.assign(obj, {
          msFlexOrder: this.order,
          order: this.order
        });
      }
      if (typeof this.flex !== "undefined") {
        obj.flex = this.currentFlex;
      }
      if (this.gutter) {
        obj.marginLeft = obj.marginRight = obj.marginTop = obj.marginBottom = `${this.gutter / 2}px`;
      }
      return obj;
    }
  },
  mounted() {
    const computedStyle = window.getComputedStyle(this.$el);
    const flexBasis = computedStyle.flexBasis;
    if (flexBasis && flexBasis !== "auto" && !cssValueIsEmpty(flexBasis) && (hasPadding(computedStyle) || hasBorder(computedStyle))) {
      throw new Error(
        [
          'Not allow applying "padding" or "border" to a flex item,',
          "when a non-auto flex-basis is specified,",
          "IE 10-11 always uses a content-box box model to calculate the size of it,",
          'even if "box-sizing: border-box" is applied to the element'
        ].join(" ")
      );
    }
  },
  methods: {
    getPrefixedClassName
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      class: [_vm.getPrefixedClassName("sf-flex-item")].concat(_vm.cls),
      style: _vm.style
    },
    [_vm._t("default")],
    2
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__$1 as SfFlex, __vue_component__ as SfFlexItem };
