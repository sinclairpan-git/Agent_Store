import type { SfInputMethods, SfInputProps } from '@sxf/er-components/input/types';

export declare type SfUploadTriggerAccept = string;

export interface SfUploadTriggerProps extends SfInputProps<string> {
  /**
   * 接受上传的文件类型
   */
  accept: SfUploadTriggerAccept;

  /**
   * 上传的api
   */
  api: any;

  /**
   * 上传文件之前的钩子
   * - 应该返回jquery的deffer对象
   */
  beforeUpload: () => JQuery.Promise<any> | false;

  /**
   * 文件上传时的钩子
   */
  onProgress: () => void;

  /**
   * 文件上传成功时的钩子
   */
  onSuccess: () => void;

  /**
   * 文件上传失败时的钩子
   */
  onError: () => void;

  /**
   * 是否需要选择文件按钮
   */
  needChooseFileBtn: boolean;
  /**
   * 是否需要展示上传进度信息
   */
  needProgressInfo: boolean;

  /**
   * 选择文件按钮的类型
   * 与SfButton类型一致
   */
  chooseFileBtnType: string;
  /**
   * 上传时是否按照Text读取
   * 会触发 on-read-success on-read-fail 事件
   */
  readAsText: boolean;
}

export interface SfUploadTriggerEvents {
  $emit(eventName: 'file-change'): this;
}

export interface SfUploadTriggerMethods extends SfInputMethods {
  chooseFile: () => void;
  submit: () => void;
  reset: () => void;
  abort: () => void;
}

export declare type SfUploadTrigger = Readonly<SfUploadTriggerProps & SfUploadTriggerEvents & SfUploadTriggerMethods> &
  Vue;
