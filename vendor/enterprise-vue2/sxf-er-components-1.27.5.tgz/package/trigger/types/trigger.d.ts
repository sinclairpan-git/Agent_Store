import type { SfInputMethods, SfInputProps, SfInputSlots } from '@sxf/er-components/input/types';

import { VNode } from 'vue';

interface SfTriggerProps extends Omit<SfInputProps<string>, 'type'> {
  /**
   * 对应的框类型，如搜索框、日期框
   */
  type?: 'date' | 'time' | 'more' | 'browser' | 'search';
}

export interface SfTriggerSlots extends SfInputSlots {
  $slots: {
    prefix?: VNode[];
    suffix?: VNode[];
  };
}

export interface SfTriggerEvents {
  /**
   * 获得焦点
   */
  $emit(eventName: 'focus', event: FocusEvent): this;

  /**
   * 失去焦点
   */
  $emit(eventName: 'blur', event: UIEvent): this;

  /**
   * 值输入时触发
   */
  $emit(eventName: 'input', value: string): this;

  /**
   * 值改变时触发
   */
  $emit(eventName: 'change', value: string): this;

  $emit(eventName: 'click', event: MouseEvent): this;

  $emit(eventName: 'clear', event: MouseEvent): this;

  /**
   * 验证失败时触发
   *
   * @param eventName
   * @param eventData
   */
  $emit(eventName: 'invalid', eventData: boolean | string | Array<string>): this;

  /**
   * 验证成功时触发
   *
   * @param eventName
   * @param eventData
   */
  $emit(eventName: 'valid', eventData: true): this;

  $emit(eventName: 'hide', inputValue: string): this;

  $emit(eventName: 'show'): this;

  /**
   * 值输入时触发
   *
   * @deprecated Use `input` instead.
   */
  $emit(eventName: 'value', eventData: string): this;

  /**
   * 值改变时触发
   *
   * @deprecated Use `change` instead.
   */
  $emit(eventName: 'end', eventData: string): this;
}

export interface SfTriggerMethods extends SfInputMethods {
  /**
   * 显示加载的icon
   */
  showLoading: () => void;

  /**
   * 隐藏加载的icon
   */
  hideLoading: () => void;

  /**
   * 清空数据
   */
  clear: () => void;

  /**
   * 清空数据，并上报最后的数据
   */
  end: () => void;
}

export type SfTrigger = Readonly<SfTriggerProps & SfTriggerSlots & SfTriggerEvents & SfTriggerMethods> & Vue;

export type SfSearchTrigger = SfTrigger;
export type SfDateTrigger = SfTrigger;
export type SfMoreTrigger = SfTrigger;
export type SfTimeTrigger = SfTrigger;
export type SfBrowserTrigger = SfTrigger;
