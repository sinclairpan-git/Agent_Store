import Vue from 'vue';
import $ from 'jquery';
import { componentName } from '@sxf/er-components/_const';
import { vOnShow } from '@sxf/er-components/_directives';
import { MgrClientMixin } from '@sxf/er-components/_mixins';
import { isPropEnabled } from '@sxf/er-components/_utils/vue-utils';
import { SfInput } from '@sxf/er-components/input';
import { getPrefixedClassName } from '@sxf/er-feature';
import textMetrics from '@sxf/er-utils/textMetrics';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
import { SfButton } from '@sxf/er-components/button';
import { globalConfig, $i } from '@sxf/er-config';
import { throttle } from '@sxf/er-utils/delay';
import format from '@sxf/er-utils/format';
import notify from '@sxf/er-widget/notify';
import numberic from '@sxf/er-utils/numberic';
import '@sxf/er-utils/ua';
import '@sxf/er-validator';
const ICON_CLS = {
  date: "vtv-icon-calendar",
  time: "vtv-icon-time",
  more: "vtv-icon-menu-more",
  browser: "vtv-icon-file",
  search: "vtv-icon-search",
  list: "vtv-icon-view-list"
};
const component$1 = {
  name: componentName.trigger,
  componentName: componentName.trigger,
  components: {
    SfInput
  },
  directives: {
    "on-show": vOnShow
  },
  mixins: [MgrClientMixin],
  model: {
    event: "value"
  },
  props: {
    type: true,
    value: true,
    autoWidth: {
      type: Boolean,
      default: true
    },
    showTipType: {
      type: Array,
      default: () => ["more"]
    },
    tip: {
      type: String,
      default: ""
    }
  },
  data() {
    return {
      loading: false,
      inputValue: this.value || "",
      isFocus: false,
      isValid: true,
      tipOffsetX: 0,
      tipOffsetY: 0
    };
  },
  watch: {
    value() {
      this.inputValue = this.value;
    },
    placeholder() {
      this.$nextTick(() => {
        this.calcPlaceholder();
      });
    }
  },
  computed: {
    className() {
      const className = {
        [getPrefixedClassName("is-loading")]: this.loading,
        [getPrefixedClassName("is-focus")]: this.isFocus,
        [getPrefixedClassName("is-disabled")]: this.isDisabled,
        [getPrefixedClassName("is-readonly")]: this.isReadonly,
        [getPrefixedClassName("is-invalid")]: !this.isValid
      };
      if (this.type) {
        className[getPrefixedClassName("is-type-" + this.type)] = true;
      }
      return className;
    },
    iconCls() {
      if (this.loading) {
        return "vtv-icon-comp-loading";
      }
      return ICON_CLS[this.type];
    },
    isDisabled() {
      return isPropEnabled(this.disabled);
    },
    isReadonly() {
      return isPropEnabled(this.readonly);
    },
    inputProps() {
      return $.extend({}, this.$props, {
        type: "text"
      });
    },
    dataTip() {
      if (this.showTipType.includes(this.type)) {
        return this.tip || this.value;
      }
      return "";
    }
  },
  mounted() {
    this.calcPlaceholder();
    this.calcPrefixWidth();
  },
  methods: {
    getPrefixedClassName,
    showLoading() {
      this.loading = true;
    },
    hideLoading() {
      this.loading = false;
    },
    clear() {
      this.inputValue = "";
      this.$emit("value", "");
    },
    end() {
      const oldValue = this.inputValue;
      this.clear();
      this.$emit("end", oldValue);
    },
    _onInput() {
      this.$emit("input", this.inputValue);
      this.$emit("value", this.inputValue);
    },
    _onFieldClick() {
      if (this.isReadonly) {
        this._emitTriggerEvent();
        this.blur();
      }
    },
    _onFieldClear(e) {
      this.isFocus = false;
      this.clear();
      this.$emit("clear", e);
    },
    _onFieldFocus(e) {
      this.isFocus = true;
      this.$emit("focus", e);
    },
    _onFieldBlur(e) {
      this.isFocus = false;
      this.$emit("blur", e);
    },
    _onFieldValid(result) {
      this.isValid = true;
      this.$emit("valid", result);
    },
    _onFieldInvalid(result) {
      this.isValid = false;
      this.$emit("invalid", result);
    },
    __onTriggerButtonClick() {
      if (!this.isReadonly) {
        this._emitTriggerEvent();
      }
    },
    _emitTriggerEvent() {
      if (!this.isDisabled) {
        this.$emit("trigger", this.inputValue);
      }
    },
    calcPlaceholder() {
      if (!this.autoWidth || !this.placeholder) {
        return;
      }
      const $el = $(this.$el);
      const $input = $el.find("input");
      if (!$input.length) {
        return;
      }
      const innerWidth = $input.width();
      const allWidth = $input.get(0).getBoundingClientRect().width;
      if (!innerWidth || !allWidth) {
        return;
      }
      const space = allWidth - innerWidth;
      const textSize = textMetrics.measure($input, this.placeholder);
      if (textSize.width <= innerWidth) {
        return;
      }
      $el.css("width", `${textSize.width + space}px`);
    },
    calcPrefixWidth() {
      this.$nextTick(() => {
        if (this.$slots.prefix) {
          this.tipOffsetX = this.$refs.input.calcIconOffset("pre");
        }
      });
    }
  }
};
const extendSfInputComponent = () => {
  const SfInputOptions = Vue.extend(SfInput).options;
  const props = SfInputOptions.props;
  const methods = Object.keys(SfInputOptions.methods).reduce(function(map, name) {
    if (typeof SfInputOptions.methods[name] === "function" && name !== "constructor") {
      map[name] = function(...args) {
        return this.$refs.input[name](...args);
      };
    }
    return map;
  }, {});
  component$1.props = {
    ...props,
    ...component$1.props
  };
  component$1.methods = {
    ...methods,
    ...component$1.methods
  };
};
const __vue_script__$1 = component$1;
var __vue_render__$1 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      directives: [
        {
          name: "on-show",
          rawName: "v-on-show.once",
          value: _vm.calcPlaceholder,
          expression: "calcPlaceholder",
          modifiers: { once: true }
        }
      ],
      class: [_vm.getPrefixedClassName("sf-trigger"), _vm.className]
    },
    [
      _c(
        "sf-input",
        _vm._b(
          {
            ref: "input",
            class: _vm.getPrefixedClassName("sf-trigger_input"),
            attrs: {
              limit: _vm.limit,
              placeholder: _vm.placeholder,
              "can-clear": _vm.canClear,
              "data-tip": _vm.dataTip,
              "data-hint-offsets": _vm.tipOffsetX + ", " + _vm.tipOffsetY
            },
            on: {
              input: _vm._onInput,
              clear: _vm._onFieldClear,
              focus: _vm._onFieldFocus,
              blur: _vm._onFieldBlur,
              valid: _vm._onFieldValid,
              invalid: _vm._onFieldInvalid
            },
            nativeOn: {
              keyup: [
                function($event) {
                  if (!$event.type.indexOf("key") && _vm._k($event.keyCode, "enter", 13, $event.key, "Enter")) {
                    return null;
                  }
                  return _vm._emitTriggerEvent();
                },
                function($event) {
                  if (!$event.type.indexOf("key") && _vm._k($event.keyCode, "esc", 27, $event.key, [
                    "Esc",
                    "Escape"
                  ])) {
                    return null;
                  }
                  return _vm.end();
                }
              ],
              click: function($event) {
                return _vm._onFieldClick();
              }
            },
            model: {
              value: _vm.inputValue,
              callback: function($$v) {
                _vm.inputValue = $$v;
              },
              expression: "inputValue"
            }
          },
          "sf-input",
          _vm.inputProps,
          false
        ),
        [
          _vm.$slots.prefix ? _c("template", { slot: "prefix" }, [_vm._t("prefix")], 2) : _vm._e(),
          _vm._v(" "),
          _c(
            "template",
            { slot: "suffix" },
            [
              _vm._t(
                "suffix",
                [
                  _c("i", {
                    ref: "trigger",
                    class: [
                      "iconfont",
                      _vm.getPrefixedClassName("sf-trigger_icon"),
                      _vm.iconCls
                    ],
                    on: {
                      click: function($event) {
                        return _vm.__onTriggerButtonClick();
                      }
                    }
                  })
                ],
                {
                  isLoading: _vm.loading,
                  isFocus: _vm.isFocus,
                  isInvalid: !_vm.isValid,
                  isDisabled: _vm.isDisabled,
                  isReadonly: _vm.isReadonly,
                  trigger: _vm.__onTriggerButtonClick
                }
              )
            ],
            2
          )
        ],
        2
      )
    ],
    1
  );
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
const factory = (type, name) => {
  return {
    name,
    componentName: name,
    extends: __vue_component__$1,
    props: {
      type: {
        type: String,
        default: type,
        validator(value) {
          if (value !== type) {
            throw new Error('Avoid overwriting "type" prop of which the value must be "' + type + '"');
          }
          return true;
        }
      }
    }
  };
};
const SfSearchTrigger = {
  name: componentName.searchTrigger,
  componentName: componentName.searchTrigger,
  extends: __vue_component__$1,
  props: {
    type: {
      type: String,
      default: "search",
      validator(value) {
        if (value !== "search") {
          throw new Error('Avoid overwriting "type" prop of which the value must be "search"');
        }
        return true;
      }
    },
    limit: {
      type: Number,
      default: () => {
        var _a, _b;
        return (_b = (_a = globalConfig.search) == null ? void 0 : _a.limit) != null ? _b : 0;
      }
    },
    useUTF8Len: {
      type: Boolean,
      default: () => {
        var _a, _b;
        return (_b = (_a = globalConfig.search) == null ? void 0 : _a.useUTF8Len) != null ? _b : true;
      }
    }
  }
};
const SfDateTrigger = factory("date", componentName.dateTrigger);
const SfMoreTrigger = factory("more", componentName.moreTrigger);
const SfBrowserTrigger = factory("browser", componentName.browserTrigger);
const SfTimeTrigger = factory("time", componentName.timeTrigger);
const M_AVERAGE_COUNT = 40;
const getNeedTime = function() {
  let lastUploadSize = 0, unitUploadSizes = [], lastUploadTime = 0, unitUploadTime = [];
  const updateUnitUploadSizes = function(size) {
    if (unitUploadSizes.length < M_AVERAGE_COUNT) {
      unitUploadSizes.push(size);
    } else {
      unitUploadSizes.shift();
      unitUploadSizes.push(size);
    }
  }, updateUnitTime = function(unitTime) {
    if (unitUploadTime.length < M_AVERAGE_COUNT) {
      unitUploadTime.push(unitTime);
    } else {
      unitUploadTime.shift();
      unitUploadTime.push(unitTime);
    }
  }, getAverageSpeed = function() {
    let total = 0, usedTime = 0, i = 0;
    for (i = 0; i < unitUploadSizes.length; i++) {
      total += unitUploadSizes[i] || 0;
    }
    for (i = 0; i < unitUploadTime.length; i++) {
      usedTime += unitUploadTime[i] || 0;
    }
    if (!usedTime || !total || total < 0 || !unitUploadSizes.length) {
      return -1;
    } else {
      return total / (usedTime / 1e3);
    }
  };
  return {
    get: function(upload, total) {
      if (lastUploadSize) {
        updateUnitUploadSizes(upload - lastUploadSize);
      }
      lastUploadSize = upload;
      if (lastUploadTime) {
        updateUnitTime(new Date().getTime() - lastUploadTime);
      }
      lastUploadTime = new Date().getTime();
      const averageSpeed = getAverageSpeed();
      if (averageSpeed === -1) {
        return -1;
      } else {
        return (total - upload) / averageSpeed * 1e3;
      }
    },
    reset: function() {
      lastUploadSize = 0;
      unitUploadSizes = [];
      lastUploadTime = new Date().getTime();
      unitUploadTime = [];
    }
  };
}();
const getSpeed = function() {
  let lastUploadSize = 0, unitUploadSizes = [], lastUploadTime = 0, unitUploadTime = [];
  const updateUnitUploadSizes = function(size) {
    if (unitUploadSizes.length < M_AVERAGE_COUNT) {
      unitUploadSizes.push(size);
    } else {
      unitUploadSizes.shift();
      unitUploadSizes.push(size);
    }
  }, updateUnitTime = function(unitTime) {
    if (unitUploadTime.length < M_AVERAGE_COUNT) {
      unitUploadTime.push(unitTime);
    } else {
      unitUploadTime.shift();
      unitUploadTime.push(unitTime);
    }
  }, getAverageSpeed = function() {
    let total = 0, usedTime = 0, i = 0;
    for (i = 0; i < unitUploadSizes.length; i++) {
      total += unitUploadSizes[i] || 0;
    }
    for (i = 0; i < unitUploadTime.length; i++) {
      usedTime += unitUploadTime[i] || 0;
    }
    if (!usedTime || !total || total < 0 || !unitUploadSizes.length) {
      return -1;
    } else {
      return total / (usedTime / 1e3);
    }
  };
  return {
    get: function(upload) {
      if (lastUploadSize) {
        updateUnitUploadSizes(upload - lastUploadSize);
      }
      lastUploadSize = upload;
      if (lastUploadTime) {
        updateUnitTime(new Date().getTime() - lastUploadTime);
      }
      lastUploadTime = new Date().getTime();
      const averageSpeed = getAverageSpeed();
      if (averageSpeed === -1) {
        return "-";
      } else {
        return numberic.byteSize(averageSpeed, 2).toString() + "/s";
      }
    },
    reset: function() {
      lastUploadSize = 0;
      unitUploadSizes = [];
      lastUploadTime = new Date().getTime();
      unitUploadTime = [];
    }
  };
}();
const UPLOAD_STATUS = {
  unUpload: "unUpload",
  uploading: "uploading",
  uploadFail: "uploadFail",
  uploadSuccess: "uploadSuccess"
};
const component = {
  name: componentName.uploadTrigger,
  componentName: componentName.uploadTrigger,
  components: {
    SfButton,
    SfBrowserTrigger
  },
  props: {
    accept: String,
    api: {
      type: Function
    },
    beforeUpload: {
      type: Function,
      default: $.noop
    },
    onProgress: Function,
    onSuccess: Function,
    onError: Function,
    needChooseFileBtn: {
      type: Boolean,
      default: false
    },
    needProgressInfo: {
      type: Boolean,
      default: false
    },
    chooseFileBtnType: {
      type: String,
      default: "primary"
    },
    readAsText: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      fileName: this.value || "",
      file: null,
      uploadStatus: UPLOAD_STATUS.unUpload,
      uploadPercent: 0
    };
  },
  computed: {
    isShowPercentInfo() {
      return this.uploadStatus === UPLOAD_STATUS.uploading;
    },
    selectFileText() {
      return $i("scp.vt_component.sf_widget.packages.upload_trigger.select_file_btn");
    },
    uploadWaitText() {
      return $i("scp.vt_component.sf_widget.packages.upload_trigger.upload_wait_text");
    }
  },
  watch: {
    fileName(val) {
      this.$emit("input", val);
    }
  },
  methods: {
    getPrefixedClassName,
    beautifyTime(ms) {
      const s = parseInt(Number(ms) / 1e3, 10) || 0;
      return format.secToDate(s) || "-";
    },
    chooseFile() {
      this.$refs.fileInput.click();
    },
    onFileChange() {
      const fileInputEl = this.$refs.fileInput;
      if (fileInputEl.files.length) {
        this.file = fileInputEl.files[0];
        this.fileName = this.file.name;
      }
      this.$nextTick(() => {
        const valid = this.$refs.browserTrigger.validate();
        if (valid === true && this.readAsText) {
          this.loadFileContent(this.file);
        }
      });
      this.$emit("file-change");
    },
    loadFileContent(file) {
      const reader = new FileReader();
      reader.onload = (result) => {
        if (result) {
          const content = result.target.result;
          this.$emit("on-read-success", content);
        }
      };
      reader.onerror = (err) => {
        this.$emit("on-read-fail", err);
      };
      reader.readAsText(file);
    },
    submit() {
      var _a;
      this.uploadStatus = UPLOAD_STATUS.unUpload;
      if (!((_a = this.file) == null ? void 0 : _a.size)) {
        notify.fail($i("scp.vt_component.sf_widget.packages.upload_trigger.empty_file_tip"));
        return;
      }
      const params = {
        file: this.file
      };
      $.when(this.beforeUpload()).then((result) => {
        if (result === false) {
          return;
        }
        params.beforeUploadResult = result;
        this.startTime = new Date();
        getNeedTime.reset();
        getSpeed.reset();
        this.httpReq = this.api(params).progress(
          throttle((e) => {
            if (this.uploadStatus === UPLOAD_STATUS.uploadFail) {
              return;
            }
            const uploadedSize = e.loaded, totalSize = e.total, usedTime = new Date() - this.startTime, needTime = getNeedTime.get(uploadedSize, totalSize), speed = getSpeed.get(uploadedSize);
            if (e.total > 0) {
              e.percent = e.loaded / e.total * 100;
            } else {
              e.percent = 0;
            }
            e.totalSize = format.fileSize(totalSize);
            e.uploadedSize = format.fileSize(uploadedSize);
            e.speed = speed;
            e.usedTime = this.beautifyTime(usedTime);
            e.needTime = needTime > -1 ? this.beautifyTime(needTime) : "-";
            this.uploadPercent = e.percent;
            this.uploadStatus = UPLOAD_STATUS.uploading;
            this.onProgress(e);
          }, 100)
        ).done((res) => {
          this.uploadStatus = UPLOAD_STATUS.uploadSuccess;
          this.onSuccess(res);
        }).fail((err) => {
          this.uploadStatus = UPLOAD_STATUS.uploadFail;
          this.onError(err);
        }).error((err) => {
          this.uploadStatus = UPLOAD_STATUS.uploadFail;
          this.onError(err);
        });
      });
    },
    reset() {
      this.file = null;
      this.fileName = "";
      this.$refs.fileInput.value = "";
    },
    abort() {
      this.httpReq.abort();
    },
    getFile() {
      return this.file;
    }
  }
};
const extendSfBrowserTriggerComponent = () => {
  const SfBrowserTriggerOptions = Vue.extend(SfBrowserTrigger).options;
  const props = SfBrowserTriggerOptions.props;
  const methods = Object.keys(SfBrowserTriggerOptions.methods).reduce(function(map, name) {
    if (typeof SfBrowserTriggerOptions.methods[name] === "function" && name !== "constructor") {
      map[name] = function(args) {
        return this.$refs.browserTrigger[name](...args);
      };
    }
    return map;
  }, {});
  component.props = {
    ...props,
    ...component.props
  };
  component.methods = {
    ...methods,
    ...component.methods
  };
};
const __vue_script__ = component;
var __vue_render__ = function() {
  var _obj;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      class: [
        _vm.getPrefixedClassName("sf-upload-trigger"),
        (_obj = {}, _obj[_vm.getPrefixedClassName("sf-upload-trigger--btn-mode")] = _vm.needChooseFileBtn, _obj)
      ]
    },
    [
      _c(
        "sf-browser-trigger",
        _vm._g(
          _vm._b(
            {
              ref: "browserTrigger",
              attrs: { readonly: "", value: _vm.fileName },
              on: { trigger: _vm.chooseFile }
            },
            "sf-browser-trigger",
            _vm.$props,
            false
          ),
          _vm.$listeners
        )
      ),
      _vm._v(" "),
      _vm.needChooseFileBtn ? _c(
        "sf-button",
        {
          class: _vm.getPrefixedClassName("sf-upload-trigger_file-btn"),
          attrs: { type: _vm.chooseFileBtnType, disabled: _vm.disabled },
          on: {
            click: function($event) {
              return _vm.chooseFile();
            }
          }
        },
        [_vm._v("\n    " + _vm._s(_vm.selectFileText) + "\n  ")]
      ) : _vm._e(),
      _vm._v(" "),
      _c("input", {
        ref: "fileInput",
        staticStyle: { display: "none" },
        attrs: { type: "file", accept: _vm.accept },
        on: { change: _vm.onFileChange }
      }),
      _vm._v(" "),
      _vm.needProgressInfo && _vm.isShowPercentInfo ? _c(
        "div",
        { class: _vm.getPrefixedClassName("sf-upload-trigger_progress") },
        [
          _c("i", {
            class: [
              "iconfont",
              "vtv-icon-comp-loading",
              _vm.getPrefixedClassName("sf-upload-trigger_progress_icon")
            ]
          }),
          _vm._v(" "),
          _c(
            "div",
            {
              class: _vm.getPrefixedClassName(
                "sf-upload-trigger_progress_info"
              )
            },
            [
              _c("span", [_vm._v(_vm._s(_vm.uploadWaitText))]),
              _vm._v(" "),
              _c("div", [_vm._v(_vm._s(_vm.uploadPercent) + "%")])
            ]
          )
        ]
      ) : _vm._e()
    ],
    1
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
extendSfInputComponent();
extendSfBrowserTriggerComponent();
export { SfBrowserTrigger, SfDateTrigger, SfMoreTrigger, SfSearchTrigger, SfTimeTrigger, __vue_component__$1 as SfTrigger, __vue_component__ as SfUploadTrigger };
