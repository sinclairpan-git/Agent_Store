import { componentName } from '@sxf/er-components/_const';
import { getPrefixedClassName } from '@sxf/er-feature';
import { getScrollParent, on, off } from '@sxf/er-utils/dom';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
const ANCHOR_TOKEN = Symbol("anchorToken");
function easeInOutCubic(elapsed, initialValue, amountOfChange, duration) {
  if (duration <= 0) {
    return amountOfChange + initialValue;
  }
  elapsed /= duration / 2;
  if (elapsed < 1) {
    return amountOfChange / 2 * elapsed * elapsed * elapsed + initialValue;
  }
  elapsed -= 2;
  return amountOfChange / 2 * (elapsed * elapsed * elapsed + 2) + initialValue;
}
function getScroll(target) {
  if (target === window) {
    return {
      scrollTop: window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop,
      scrollLeft: window.pageXOffset || document.documentElement.scrollLeft || document.body.scrollLeft
    };
  }
  if (target instanceof HTMLElement) {
    return {
      scrollTop: target.scrollTop,
      scrollLeft: target.scrollLeft
    };
  }
  return { scrollTop: 0, scrollLeft: 0 };
}
function scrollToTop(options = {}) {
  const {
    top = 0,
    amountOfChange,
    target = window,
    duration = 450,
    easing = easeInOutCubic,
    callback,
    beforeRAF
  } = options;
  const { scrollTop: startScrollTop } = getScroll(target);
  const change = amountOfChange != null ? amountOfChange : top - startScrollTop;
  const startTime = Date.now();
  const frameFunction = () => {
    const timeElapsed = Date.now() - startTime;
    const time = Math.min(timeElapsed, duration);
    const nextScrollTop = easing(time, startScrollTop, change, duration);
    if (target === window) {
      window.scrollTo(window.pageXOffset, nextScrollTop);
    } else {
      target.scrollTop = nextScrollTop;
    }
    if (typeof beforeRAF === "function") {
      beforeRAF();
    }
    if (timeElapsed < duration) {
      requestAnimationFrame(frameFunction);
    } else if (typeof callback === "function") {
      callback();
    }
  };
  requestAnimationFrame(frameFunction);
}
function getOffset(element, target = window) {
  if (!(element == null ? void 0 : element.getClientRects().length)) {
    return { top: 0, left: 0 };
  }
  const rect = element.getBoundingClientRect();
  let rectTop = rect.top;
  let rectLeft = rect.left;
  if (target !== window) {
    const targetRect = target.getBoundingClientRect();
    rectTop -= targetRect.top;
    rectLeft -= targetRect.left;
  } else {
    rectTop += window.pageYOffset;
    rectLeft += window.pageXOffset;
  }
  return { top: rectTop, left: rectLeft };
}
function scrollElIntoView(container, el) {
  requestAnimationFrame(() => {
    const elRect = el.getBoundingClientRect();
    const containerRect = container.getBoundingClientRect();
    const elTopToContainer = elRect.top - containerRect.top;
    const elBottomToContainer = elRect.bottom - containerRect.top;
    if (elTopToContainer < 0) {
      container.scrollTop += elTopToContainer;
    } else if (elBottomToContainer > container.clientHeight) {
      container.scrollTop += elBottomToContainer - container.clientHeight;
    }
  });
}
var script$1 = {
  name: componentName.anchor,
  componentName: componentName.anchor,
  provide() {
    return {
      [ANCHOR_TOKEN]: {
        registerLink: this.registerLink,
        unregisterLink: this.unregisterLink,
        getCurActiveLink: () => this.activeLink,
        handleLinkClick: this.handleLinkClick
      }
    };
  },
  props: {
    affix: {
      type: Boolean,
      default: false
    },
    bounds: {
      type: Number,
      default: 5
    },
    offsetTop: {
      type: Number,
      default: 0
    },
    targetOffset: Number,
    currentAnchor: String,
    target: Function,
    onChange: Function,
    onClick: Function
  },
  data() {
    return {
      links: [],
      activeLink: "",
      lineBallTop: null,
      container: null,
      lineNodeHeight: 16,
      animating: false,
      wrapperStyle: {}
    };
  },
  computed: {
    wrapperRef() {
      return this.$refs.wrapperRef;
    },
    anchorRef() {
      return this.$refs.anchorRef;
    },
    lineBallRef() {
      return this.$refs.lineBallRef;
    },
    lineBallClass() {
      return [
        getPrefixedClassName("sf-anchor__line-ball"),
        { [getPrefixedClassName("sf-anchor__line-ball-visible")]: !!this.activeLink }
      ];
    },
    realTargetOffset() {
      var _a, _b;
      return (_b = (_a = this.targetOffset) != null ? _a : this.offsetTop) != null ? _b : 0;
    },
    wrapperCls() {
      return getPrefixedClassName("sf-anchor__wrapper");
    },
    contentCls() {
      return getPrefixedClassName("sf-anchor__content");
    },
    lineCls() {
      return getPrefixedClassName("sf-anchor__line");
    }
  },
  watch: {
    activeLink: {
      handler() {
        this.updateLineBallPosition();
        this.updateActiveLinkScrollPosition();
      }
    },
    currentAnchor: {
      handler() {
        this.activateCurrentAnchor();
      }
    }
  },
  mounted() {
    this.container = this.target ? this.target() : getScrollParent(this.$el);
    this.registerEvents();
    this.handleScroll();
    this.activateCurrentAnchor();
  },
  beforeDestroy() {
    this.unregisterEvents();
  },
  methods: {
    registerLink(link) {
      if (!this.links.includes(link)) {
        this.links.push(link);
      }
    },
    unregisterLink(link) {
      const index = this.links.indexOf(link);
      if (index !== -1) {
        this.links.splice(index, 1);
      }
    },
    getTargetTop(link, container) {
      const targetElement = document.querySelector(`[data-anchor="${link}"]`) || document.querySelector(link);
      if (targetElement) {
        const { top } = getOffset(targetElement, container);
        return top;
      }
      return null;
    },
    getActiveLink(links, container, offsetTop, bounds) {
      if (!links.length) {
        return "";
      }
      const linkSections = [];
      links.forEach((link) => {
        const top = this.getTargetTop(link, container);
        if (top !== null && top < offsetTop + bounds) {
          linkSections.push({ link, top });
        }
      });
      if (linkSections.length) {
        const maxSection = linkSections.reduce((prev, curr) => curr.top > prev.top ? curr : prev);
        return maxSection.link;
      }
      return "";
    },
    setActiveLink(link) {
      var _a;
      if (this.activeLink !== link) {
        this.activeLink = link;
        (_a = this.onChange) == null ? void 0 : _a.call(this, link);
      }
    },
    handleLinkClick(event, linkObj) {
      var _a;
      if (this.animating) {
        return;
      }
      (_a = this.onClick) == null ? void 0 : _a.call(this, event, linkObj);
      this.scrollTo(linkObj.href);
    },
    handleScroll() {
      if (this.animating) {
        return;
      }
      const currentLink = this.getActiveLink(this.links, this.container, this.realTargetOffset, this.bounds);
      this.setActiveLink(currentLink);
      if (this.affix) {
        this.resizePosition();
      }
    },
    scrollTo(link) {
      this.setActiveLink(link);
      const scrollTop = this.getTargetTop(link, this.container);
      if (scrollTop === null) {
        return;
      }
      this.animating = true;
      scrollToTop({
        amountOfChange: scrollTop - this.realTargetOffset,
        target: this.container,
        callback: () => {
          this.animating = false;
        },
        beforeRAF: () => {
          if (this.affix) {
            this.resizePosition();
          }
        }
      });
    },
    registerEvents() {
      on(this.container, "scroll", this.handleScroll);
    },
    unregisterEvents() {
      off(this.container, "scroll", this.handleScroll);
    },
    updateLineBallPosition() {
      this.$nextTick(() => {
        var _a;
        const activeLinkElement = this.anchorRef.querySelector(`span[data-href="${this.activeLink}"]`);
        if (!activeLinkElement) {
          return;
        }
        const inkBallHeight = (_a = this.lineBallRef.getBoundingClientRect().height) != null ? _a : this.lineNodeHeight;
        const { offsetTop, clientHeight } = activeLinkElement;
        this.lineBallTop = `${offsetTop + clientHeight / 2 - inkBallHeight / 2}px`;
      });
    },
    updateActiveLinkScrollPosition() {
      this.$nextTick(() => {
        const activeLinkElement = this.anchorRef.querySelector(`span[data-href="${this.activeLink}"]`);
        if (!activeLinkElement) {
          return;
        }
        scrollElIntoView(this.wrapperRef, activeLinkElement);
      });
    },
    resizePosition() {
      if (this.container === window) {
        return;
      }
      this.wrapperStyle = { top: `${this.container.scrollTop}px` };
    },
    activateCurrentAnchor() {
      if (this.currentAnchor && this.links.includes(this.currentAnchor)) {
        this.$nextTick(() => {
          this.scrollTo(this.currentAnchor);
        });
      }
    }
  }
};
const __vue_script__$1 = script$1;
var __vue_render__$1 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    { ref: "wrapperRef", class: _vm.wrapperCls, style: _vm.wrapperStyle },
    [
      _c(
        "div",
        { ref: "anchorRef", class: _vm.contentCls },
        [
          _c("div", { class: _vm.lineCls }, [
            _c("span", {
              ref: "lineBallRef",
              class: _vm.lineBallClass,
              style: { top: _vm.lineBallTop }
            })
          ]),
          _vm._v(" "),
          _vm._t("default")
        ],
        2
      )
    ]
  );
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
var script = {
  name: componentName.anchorLink,
  componentName: componentName.anchorLink,
  inject: { anchor: ANCHOR_TOKEN },
  props: {
    href: {
      type: String,
      required: true
    },
    title: String
  },
  data() {
    return {
      linkTitleStyle: {}
    };
  },
  computed: {
    isActive() {
      const activeLink = this.anchor.getCurActiveLink();
      return activeLink === this.href;
    },
    linkCls() {
      return getPrefixedClassName("sf-anchor-link");
    },
    linkTitleCls() {
      return getPrefixedClassName("sf-anchor-link__title");
    },
    activeLinkCls() {
      return getPrefixedClassName("sf-active-link");
    }
  },
  watch: {
    href: {
      immediate: true,
      handler(newVal, oldVal) {
        this.anchor.unregisterLink(oldVal);
        this.anchor.registerLink(newVal);
      }
    }
  },
  mounted() {
    this.anchor.registerLink(this.href);
    this.linkTitleStyle = { marginLeft: `${this.getPaddingLeft()}px` };
  },
  beforeDestroy() {
    this.anchor.unregisterLink(this.href);
  },
  methods: {
    handleClick(event) {
      this.anchor.handleLinkClick(event, { title: this.title, href: this.href });
    },
    getPaddingLeft(basis = 12) {
      let level = 1;
      let parent = this.$parent;
      while (parent) {
        if (parent.$options._componentTag === this.$options._componentTag) {
          level++;
        }
        parent = parent.$parent;
      }
      return level * basis;
    },
    getFullUtid(utidBase) {
      return this.$attrs.utid ? `${this.$attrs.utid}-${utidBase}` : utidBase;
    }
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    { class: [_vm.linkCls, _vm.isActive && _vm.activeLinkCls] },
    [
      _c(
        "span",
        {
          class: _vm.linkTitleCls,
          style: _vm.linkTitleStyle,
          attrs: {
            utid: _vm.getFullUtid(_vm.href),
            "data-tip": _vm.title,
            "data-href": _vm.href
          },
          on: {
            click: function($event) {
              $event.preventDefault();
              return _vm.handleClick($event);
            }
          }
        },
        [_vm._t("title", [_vm._v(_vm._s(_vm.title))])],
        2
      ),
      _vm._v(" "),
      _vm._t("default")
    ],
    2
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__$1 as SfAnchor, __vue_component__ as SfAnchorLink };
