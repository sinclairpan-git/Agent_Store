import { componentName } from '@sxf/er-components/_const';
import { SfSeparator } from '@sxf/er-components/separator';
import { getPrefixedClassName } from '@sxf/er-feature';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
var script = {
  name: componentName.fieldset,
  componentName: componentName.fieldset,
  components: {
    SfSeparator
  },
  props: {
    title: {
      type: String,
      default: ""
    },
    desc: {
      type: String,
      default: ""
    },
    withCheckbox: {
      type: Boolean,
      default: false
    }
  },
  methods: {
    getPrefixedClassName
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _obj;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c("fieldset", [
    _c(
      "legend",
      [_vm._t("header", [_vm._v("\n      " + _vm._s(_vm.title) + "\n    ")])],
      2
    ),
    _vm._v(" "),
    _vm.desc ? _c(
      "div",
      {
        class: [
          _vm.getPrefixedClassName("fieldset-desc"),
          (_obj = {}, _obj[_vm.getPrefixedClassName("fieldset-desc--with-checkbox")] = _vm.withCheckbox, _obj)
        ]
      },
      [_vm._v("\n    " + _vm._s(_vm.desc) + "\n  ")]
    ) : _vm._e(),
    _vm._v(" "),
    _c(
      "div",
      { class: _vm.getPrefixedClassName("fieldset-content") },
      [_vm._t("default")],
      2
    ),
    _vm._v(" "),
    _vm.$slots.footer ? _c(
      "div",
      { class: _vm.getPrefixedClassName("fieldset-footer") },
      [
        _c("sf-separator", { attrs: { shape: "form-line" } }),
        _vm._v(" "),
        _c(
          "div",
          { class: _vm.getPrefixedClassName("fieldset-footer_content") },
          [_vm._t("footer")],
          2
        )
      ],
      1
    ) : _vm._e()
  ]);
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__ as SfFieldset };
