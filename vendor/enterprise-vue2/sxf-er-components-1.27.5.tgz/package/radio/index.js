import $ from 'jquery';
import { componentName } from '@sxf/er-components/_const';
import { EmitterMixin, FormTipMixin, PathnameMixin } from '@sxf/er-components/_mixins';
import { isPropEnabled, getVueParent, getSlot } from '@sxf/er-components/_utils/vue-utils';
import { getPrefixedClassName } from '@sxf/er-feature';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
import { FormFieldMixin } from '@sxf/er-components/form';
import { $i } from '@sxf/er-config';
import { SfLayer } from '@sxf/er-components/layer';
var script$2 = {
  name: componentName.radio,
  componentName: componentName.radio,
  mixins: [EmitterMixin, FormTipMixin],
  props: {
    value: {},
    label: {},
    disabled: {
      type: Boolean,
      default: false
    },
    name: String,
    desc: String,
    ctrlContent: {
      type: Boolean,
      default: false
    },
    disabledTip: String
  },
  data() {
    return {
      focus: false,
      descHoverTip: "",
      labelHoverTip: ""
    };
  },
  computed: {
    isGroup() {
      let parent = this.$parent;
      while (parent) {
        if (parent.$options.componentName !== componentName.radioGroup) {
          parent = parent.$parent;
        } else {
          this._radioGroup = parent;
          return true;
        }
      }
      return false;
    },
    model: {
      get() {
        return this.isGroup ? this._radioGroup.value : this.value;
      },
      set(val) {
        if (this.isGroup) {
          this.dispatch(componentName.radioGroup, "input", [val]);
        } else {
          this.$emit("input", val);
        }
      }
    },
    isDisabled() {
      return this.isGroup ? this._radioGroup.isDisabled || isPropEnabled(this.disabled) : isPropEnabled(this.disabled);
    },
    isShowContent() {
      if (!this.isGroup || !this.ctrlContent) {
        return true;
      }
      return this.model === this.label;
    },
    hasTip() {
      return Array.isArray(this.tip) ? this.tip.length > 0 : !!this.tip;
    }
  },
  mounted() {
    this.updateRadioHoverTipContent();
  },
  methods: {
    getPrefixedClassName,
    updateRadioHoverTipContent() {
      if (!this.$el) {
        return;
      }
      this.descHoverTip = $(this.$el).find(`[data-id=radio-desc-${this._uid}]`).text().trim();
      this.labelHoverTip = $(this.$el).find(`[data-id=radio-label-${this._uid}]`).text().trim();
    }
  }
};
const __vue_script__$2 = script$2;
var __vue_render__$2 = function() {
  var _obj;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c("span", { class: _vm.getPrefixedClassName("el-radio") }, [
    _c("label", [
      _c(
        "span",
        {
          class: (_obj = {}, _obj[_vm.getPrefixedClassName("el-radio__input")] = true, _obj[_vm.getPrefixedClassName("is-disabled")] = _vm.isDisabled, _obj[_vm.getPrefixedClassName("is-checked")] = _vm.model === _vm.label, _obj[_vm.getPrefixedClassName("is-focus")] = _vm.focus, _obj),
          attrs: {
            "data-tip": _vm.isDisabled && _vm.disabledTip ? _vm.disabledTip : false
          }
        },
        [
          _c("input", {
            directives: [
              {
                name: "model",
                rawName: "v-model",
                value: _vm.model,
                expression: "model"
              }
            ],
            class: [_vm.getPrefixedClassName("el-radio__original"), "hidden"],
            attrs: {
              type: "radio",
              "style-key": "radio",
              name: _vm.name,
              disabled: _vm.isDisabled
            },
            domProps: {
              value: _vm.label,
              checked: _vm._q(_vm.model, _vm.label)
            },
            on: {
              focus: function($event) {
                _vm.focus = true;
              },
              blur: function($event) {
                _vm.focus = false;
              },
              change: function($event) {
                _vm.model = _vm.label;
              }
            }
          }),
          _vm._v(" "),
          _c("span", {
            class: [_vm.getPrefixedClassName("el-radio__inner"), "radio-wrap"]
          })
        ]
      ),
      _vm._v(" "),
      _c(
        "span",
        {
          class: _vm.getPrefixedClassName("el-radio__label"),
          attrs: {
            "data-id": "radio-label-" + _vm._uid,
            "data-tip": _vm.labelHoverTip
          }
        },
        [_vm._t("default", [_vm._v(_vm._s(_vm.label))])],
        2
      ),
      _vm._v(" "),
      _vm.hasTip ? _c("i", {
        staticClass: "icon-tip",
        attrs: { "data-hint": _vm.contentTip }
      }) : _vm._e(),
      _vm._v(" "),
      _vm.$slots.desc || _vm.desc ? _c(
        "div",
        {
          class: _vm.getPrefixedClassName("el-radio__desc"),
          attrs: {
            "data-id": "radio-desc-" + _vm._uid,
            "data-tip": _vm.descHoverTip
          }
        },
        [
          _vm._t("desc"),
          _vm._v(" "),
          !_vm.$slots.desc ? [_vm._v(_vm._s(_vm.desc))] : _vm._e()
        ],
        2
      ) : _vm._e()
    ]),
    _vm._v(" "),
    _vm.$slots.content ? _c(
      "div",
      {
        directives: [
          {
            name: "show",
            rawName: "v-show",
            value: _vm.isShowContent,
            expression: "isShowContent"
          }
        ],
        class: _vm.getPrefixedClassName("el-radio__content-wrap")
      },
      [
        _c("span", {
          class: _vm.getPrefixedClassName("el-radio__item-triangle")
        }),
        _vm._v(" "),
        _c(
          "div",
          { class: _vm.getPrefixedClassName("el-radio__content") },
          [_vm._t("content")],
          2
        )
      ]
    ) : _vm._e()
  ]);
};
var __vue_staticRenderFns__$2 = [];
__vue_render__$2._withStripped = true;
const __vue_inject_styles__$2 = void 0;
const __vue_scope_id__$2 = void 0;
const __vue_module_identifier__$2 = void 0;
const __vue_is_functional_template__$2 = false;
const __vue_component__$2 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$2, staticRenderFns: __vue_staticRenderFns__$2 },
  __vue_inject_styles__$2,
  __vue_script__$2,
  __vue_scope_id__$2,
  __vue_is_functional_template__$2,
  __vue_module_identifier__$2,
  false,
  void 0,
  void 0,
  void 0
);
var RadioButton = {
  name: componentName.radioButton,
  componentName: componentName.radioButton,
  props: {
    label: {},
    disabled: {
      type: Boolean,
      default: false
    },
    name: String,
    width: String,
    beforeChange: Function,
    icon: String,
    disabledTip: String
  },
  computed: {
    value: {
      get() {
        return this._radioGroup.value;
      },
      set(value) {
        this._radioGroup.$emit("input", value);
      }
    },
    _radioGroup() {
      return getVueParent(this, componentName.radioGroup);
    },
    size() {
      return this._radioGroup.size;
    },
    isDisabled() {
      const parent = this._radioGroup;
      return isPropEnabled(this.disabled) || parent.isDisabled;
    }
  },
  render(createElem) {
    const renderInner = () => {
      const content = [getSlot(this, "default") || this.label];
      if (this.icon) {
        content.unshift(
          createElem("i", {
            class: ["iconfont", "vtv-icon-" + this.icon]
          })
        );
      }
      return createElem(
        "span",
        {
          class: getPrefixedClassName("el-radio-button__inner"),
          style: {
            width: this.width
          },
          attrs: {
            "data-tip": this.isDisabled && this.disabledTip ? this.disabledTip : false
          }
        },
        content
      );
    };
    return createElem(
      "label",
      {
        class: [
          getPrefixedClassName("el-radio-button"),
          getPrefixedClassName(this.size ? "el-radio-button--" + this.size : ""),
          {
            [getPrefixedClassName("is-active")]: this.value === this.label,
            [getPrefixedClassName("is-disabled")]: this.isDisabled
          }
        ],
        ref: "label",
        attrs: {
          tabindex: "0"
        }
      },
      [
        createElem("input", {
          class: getPrefixedClassName("el-radio-button__orig-radio"),
          attrs: {
            type: "radio",
            "style-key": "radio",
            name: this.name
          },
          domProps: {
            value: this.label,
            checked: this.value === this.label,
            disabled: this.isDisabled
          },
          on: {
            change: () => {
              if (!this.beforeChange) {
                this.value = this.label;
                return;
              }
              this.beforeChange().then(
                () => {
                  this.value = this.label;
                },
                () => {
                  const isChecked = this.value === this.label;
                  this.$refs.inputEl.checked = isChecked;
                }
              );
            }
          },
          ref: "inputEl"
        }),
        renderInner()
      ]
    );
  }
};
var SfRadioGroup = {
  name: componentName.radioGroup,
  componentName: componentName.radioGroup,
  mixins: [FormFieldMixin, PathnameMixin],
  props: {
    value: {},
    size: String,
    textColor: String,
    disabled: Boolean,
    theme: String,
    multiline: Boolean,
    round: {
      type: Boolean,
      default: false
    },
    wrap: Boolean
  },
  computed: {
    isDisabled() {
      return isPropEnabled(this.disabled);
    },
    disabledStatus() {
      return this.isDisabled;
    },
    errorMessage() {
      return $i("scp.vt_component.sf_widget.packages.radio.radio_group.error_message", {
        message: this.validateTip
      });
    }
  },
  watch: {
    value(value) {
      this.$emit("change", value);
      this.validate();
      this.setPathName(value);
    }
  },
  created() {
    if (!this.pathName) {
      return;
    }
    const name = this.getPathName();
    if (name) {
      this.$emit("input", name);
    }
    this.watchPathNameRouter(({ value }) => {
      if (value === this.value) {
        return;
      }
      this.$emit("input", value);
    });
  },
  methods: {
    getData() {
      return this.value;
    },
    getValue() {
      return this.getData();
    },
    processRule(rule) {
      rule.getFieldValue = () => {
        return String(this.getValue());
      };
      rule.blankText = rule.blankText || $i("scp.vt_component.sf_widget.packages.radio.radio_group.select_least_one");
      return rule;
    },
    checkIsDisabled() {
      return this.isDisabled;
    },
    setValue(val) {
      this.$emit("input", val);
    }
  },
  render(createElem) {
    const defaultSlot = this.$slots.default;
    const isWithIcon = defaultSlot && defaultSlot.filter((vnode) => {
      var _a, _b;
      return (_b = (_a = vnode == null ? void 0 : vnode.componentOptions) == null ? void 0 : _a.propsData) == null ? void 0 : _b.icon;
    }).length;
    const errorTipVNode = createElem("p", {
      class: [getPrefixedClassName("el-radio-group--error-tip")],
      domProps: {
        textContent: this.errorMessage
      }
    });
    return createElem("div", {}, [
      createElem(
        "div",
        {
          class: [
            getPrefixedClassName("el-radio-group"),
            getPrefixedClassName(this.theme ? "el-radio-group--" + this.theme : ""),
            getPrefixedClassName(this.multiline ? "el-radio-group--multiline" : ""),
            getPrefixedClassName(this.round ? "el-radio-group--round" : ""),
            getPrefixedClassName(this.wrap ? "el-radio-group--wrap" : ""),
            getPrefixedClassName(isWithIcon ? "el-radio-group--with-icon" : ""),
            this.invalidCls
          ],
          attrs: {
            id: this.fieldSelectorID
          },
          props: this.$props
        },
        defaultSlot ? defaultSlot.filter((vnode) => vnode.tag) : []
      ),
      this.invalidCls ? errorTipVNode : null
    ]);
  }
};
var RadioSelect = {
  name: componentName.radioSelect,
  componentName: componentName.radioSelect,
  components: {
    SfLayer
  },
  props: {
    disabled: {},
    layerCls: String
  },
  data() {
    return {
      childSlot: null,
      label: null,
      isShow: false
    };
  },
  computed: {
    value() {
      return this._radioGroup.value;
    },
    _radioButtons() {
      return this.$children[0] && this.$children[0].$children;
    },
    _radioGroup() {
      return getVueParent(this, componentName.radioGroup);
    },
    size() {
      return this._radioGroup.size;
    },
    theme() {
      return this._radioGroup.theme;
    },
    isDisabled() {
      return isPropEnabled(this.disabled) || this._radioGroup.isDisabled;
    },
    _layerRef() {
      return this.isDisabled ? "" : "label";
    }
  },
  watch: {
    value() {
      this.__updateChildSlot();
      this.$refs.layer.hide();
    },
    isDisabled() {
      this.$refs.layer.setTarget(this.isDisabled ? "" : "label");
    }
  },
  mounted() {
    this.__updateChildSlot();
    this.$refs.layer.$on("before-show", () => {
      this.isShow = true;
      this.__updateLayerCss();
    });
    this.$refs.layer.$on("before-hide", () => {
      this.isShow = false;
    });
  },
  methods: {
    __updateChildSlot() {
      if (!this.childSlot) {
        this.childSlot = getSlot(this._radioButtons[0], "default");
        this.label = this._radioButtons[0].label;
      }
      const child = this._radioButtons.filter((child2) => child2.label === this.value)[0];
      if (child) {
        this.childSlot = getSlot(child, "default");
        this.label = child.label;
      }
    },
    __updateLayerCss() {
      $(this.$refs.layer.$refs.layer).css({
        "min-width": $(this.$el).outerWidth()
      });
    }
  },
  render(createElem) {
    return createElem(
      "div",
      {
        class: [
          `${getPrefixedClassName("el-radio-button")} ${getPrefixedClassName("el-radio-select")}`,
          this.isShow ? `${getPrefixedClassName("is-active")} ${getPrefixedClassName("el-radio-select--shown")}` : "",
          getPrefixedClassName(this.size ? "el-radio-button--" + this.size : ""),
          {
            [getPrefixedClassName("is-active")]: this.value === this.label,
            [getPrefixedClassName("is-disabled")]: this.isDisabled
          }
        ],
        ref: "label"
      },
      [
        createElem(
          "span",
          {
            class: getPrefixedClassName("el-radio-button__inner"),
            ref: "inner"
          },
          [
            this.label,
            createElem("i", {
              class: `iconfont vtv-icon-triangle-unfold ${getPrefixedClassName("el-radio-button_unfold-icon")}`
            })
          ]
        ),
        createElem(
          SfLayer,
          {
            props: {
              cls: `
                ${getPrefixedClassName("el-radio-select-layer")} 
                ${getPrefixedClassName(this.theme ? "el-radio-group--" + this.theme : "")} 
                ${this.layerCls ? this.layerCls : ""}
              `,
              "default-target": "label",
              transition: "enter"
            },
            ref: "layer"
          },
          [getSlot(this, "default")]
        )
      ]
    );
  }
};
var script$1 = {
  name: componentName.radioSwitch,
  componentName: componentName.radioSwitch,
  components: {
    SfRadio: __vue_component__$2,
    SfRadioGroup
  },
  model: {
    prop: "value",
    event: "radio-changed"
  },
  props: {
    disabled: Boolean,
    activeFirst: Boolean,
    value: String
  },
  data() {
    return {
      modelKey: this.value,
      contentConfig: []
    };
  },
  computed: {
    isShowContent: function() {
      const typeMap = (this.contentConfig || []).map(function(item) {
        return item.value;
      });
      return typeMap.indexOf(this.modelKey) !== -1;
    }
  },
  watch: {
    modelKey() {
      this.active(this.modelKey);
      this.$emit("radio-changed", this.modelKey);
    },
    value(val) {
      this.modelKey = val;
    }
  },
  mounted() {
    this.__init();
  },
  methods: {
    getPrefixedClassName,
    __init() {
      if (!this.$el || this.mountedChildCount !== this.children.length || this.__hasBeenInit) {
        return;
      }
      this.__hasBeenInit = true;
      const activeRadio = this.modelKey || this.__getContentConfig();
      if (this.modelKey) {
        this.active(this.modelKey);
      }
      if (!this.modelKey && this.contentConfig.length) {
        if (activeRadio) {
          this.modelKey = activeRadio;
        } else if (this.activeFirst) {
          this.modelKey = this.contentConfig[0].value;
        }
      }
    },
    __isCheckedItem(value) {
      return this.modelKey === value;
    },
    __registerChild(child) {
      if (!this.children) {
        this.children = [];
        this.mountedChildCount = 0;
      }
      this.children.push(child);
      child.$on("mounted", () => {
        this.mountedChildCount += 1;
        this.__init();
      });
      child.$on("changed", () => {
        this.__getContentConfig();
      });
      child.$on("destroyed", () => {
        this.mountedChildCount -= 1;
        const index = this.children.findIndex((item) => item.value === child.value);
        this.children.splice(index, 1);
        this.__getContentConfig();
      });
    },
    __getContentConfig() {
      let activeRadio;
      this.contentConfig = this.children.reduce(function(list, child) {
        const config = child.getConfig();
        if (config.active && !config.hidden) {
          activeRadio = config.value;
        }
        list.push(config);
        return list;
      }, []);
      if (this.modelKey && !activeRadio && this.contentConfig.length) {
        const currentSelect = this.contentConfig.filter(function(item) {
          return !item.hidden && !item.disabled;
        });
        this.modelKey = currentSelect.length ? currentSelect[0].value : "";
      }
      return activeRadio;
    },
    getHideContent() {
      const current = this.contentConfig.find((child) => child.value === this.modelKey);
      return !!current && current.hideContent;
    },
    active(key) {
      this.children.forEach(function(child) {
        child.setActive(child.value === key);
      });
    },
    setValue(val) {
      this.modelKey = val;
    },
    getValue() {
      return this.modelKey;
    }
  }
};
const __vue_script__$1 = script$1;
var __vue_render__$1 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    { ref: "radioSwitch" },
    [
      _c(
        "sf-radio-group",
        {
          class: _vm.getPrefixedClassName("sf-radio-switch__group"),
          attrs: { disabled: _vm.disabled },
          model: {
            value: _vm.modelKey,
            callback: function($$v) {
              _vm.modelKey = $$v;
            },
            expression: "modelKey"
          }
        },
        _vm._l(_vm.contentConfig, function(item) {
          return _c(
            "sf-radio",
            {
              directives: [
                {
                  name: "show",
                  rawName: "v-show",
                  value: !item.hidden,
                  expression: "!item.hidden"
                }
              ],
              key: item.value,
              class: _vm.getPrefixedClassName("sf-radio-switch__item-radio"),
              attrs: {
                disabled: item.disabled,
                label: item.value,
                "data-hint": item.hint,
                tip: item.tip
              }
            },
            [
              _vm._t(item.value, [
                _vm._v("\n        " + _vm._s(item.content) + "\n      ")
              ]),
              _vm._v(" "),
              _c("span", {
                directives: [
                  {
                    name: "show",
                    rawName: "v-show",
                    value: _vm.__isCheckedItem(item.value) && !_vm.getHideContent(),
                    expression: "__isCheckedItem(item.value) && !getHideContent()"
                  }
                ],
                class: _vm.getPrefixedClassName(
                  "sf-radio-switch__item-triangle"
                )
              })
            ],
            2
          );
        }),
        1
      ),
      _vm._v(" "),
      _c(
        "div",
        {
          directives: [
            {
              name: "show",
              rawName: "v-show",
              value: _vm.isShowContent && !_vm.getHideContent(),
              expression: "isShowContent && !getHideContent()"
            }
          ],
          class: _vm.getPrefixedClassName("sf-radio-switch__content-wrap")
        },
        [_vm._t("default")],
        2
      )
    ],
    1
  );
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
var script = {
  name: componentName.radioSwitchContent,
  componentName: componentName.radioSwitchContent,
  props: {
    label: String,
    active: Boolean,
    hidden: {
      type: Boolean,
      default: false
    },
    value: {
      type: String,
      required: true
    },
    disabled: Boolean,
    hint: String,
    tip: {
      type: [String, Array],
      default: ""
    },
    hideContent: {
      type: Boolean,
      default: false
    }
  },
  data: function() {
    return {
      currentValue: this.value,
      isActive: this.active
    };
  },
  computed: {
    isHidden() {
      return isPropEnabled(this.hidden);
    },
    isDisabled() {
      return isPropEnabled(this.disabled);
    },
    radioSwitchComponent() {
      if (this.$parent && this.$parent.$options.componentName === componentName.radioSwitch) {
        return this.$parent;
      }
      return false;
    }
  },
  watch: {
    isActive() {
      this.$emit("changed");
    },
    isHidden() {
      this.$emit("changed");
    },
    isDisabled() {
      this.$emit("changed");
    },
    hint() {
      this.$emit("changed");
    }
  },
  created() {
    this.radioSwitchComponent.__registerChild(this);
    this.currentValue = this.currentValue || this.radioSwitchComponent.children.length - 1;
  },
  mounted() {
    this.$emit("mounted");
  },
  beforeDestroy() {
    this.$emit("destroyed", this);
  },
  methods: {
    getPrefixedClassName,
    getConfig() {
      return {
        content: this.label,
        active: this.isActive,
        value: this.currentValue,
        hidden: this.isHidden,
        disabled: this.isDisabled,
        hint: this.hint,
        tip: this.tip,
        hideContent: this.hideContent
      };
    },
    setActive(active) {
      this.isActive = active;
    }
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _obj;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      class: (_obj = {}, _obj[_vm.getPrefixedClassName("sf-radio-switch__content")] = true, _obj.hidden = !_vm.isActive || _vm.isHidden, _obj)
    },
    [_vm._t("default")],
    2
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__$2 as SfRadio, RadioButton as SfRadioButton, SfRadioGroup, RadioSelect as SfRadioSelect, __vue_component__$1 as SfRadioSwitch, __vue_component__ as SfRadioSwitchContent };
