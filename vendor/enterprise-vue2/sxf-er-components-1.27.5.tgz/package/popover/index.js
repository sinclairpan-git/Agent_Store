import { globalConfig, $i } from '@sxf/er-config';
import $ from 'jquery';
import { componentName } from '@sxf/er-components/_const';
import { SfButton } from '@sxf/er-components/button';
import { getPrefixedClassName } from '@sxf/er-feature';
import { getEventPath, getScrollParentList } from '@sxf/er-utils/dom';
import { when } from '@sxf/er-utils/when';
import Vtip from '@sxf/er-widget/tip';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
import { vPopover } from '@sxf/er-components/_directives';
import uuid from '@sxf/er-utils/uuid';
function Logger(name) {
  this.name = name ? "[" + name + "]" : "";
}
Logger.prototype.log = _logger("log");
Logger.prototype.warn = _logger("warn");
Logger.prototype.error = _logger("error");
Logger.prototype.debug = _logger("debug");
Logger.prototype.info = _logger("info");
function _logger(type) {
  return function() {
    const enabled = globalConfig.debug;
    const args = [].slice.call(arguments, 0);
    const prefix = this.name ? this.name + " " : "";
    args[0] = prefix + (args[0] || "");
    window.console && enabled && console[type || (type = "log")] && console[type].apply && console[type].apply(console, args);
  };
}
var logger = (name) => new Logger(name);
let id = 0;
const badUsageLogger = logger("props.anchorHide");
var script$1 = {
  name: componentName.popover,
  componentName: componentName.popover,
  components: { SfButton },
  props: {
    trigger: {
      type: String,
      default: "click",
      validator: function(value) {
        return ["click", "hover", "manual"].indexOf(value) >= 0;
      }
    },
    offsetX: {
      type: [Number, String],
      default: 0
    },
    offsetY: {
      type: [Number, String],
      default: 0
    },
    anchorOffset: {
      type: Number,
      default: 1
    },
    anchorSize: {
      type: Number,
      default: 8
    },
    align: {
      type: String,
      default: "rl-bt"
    },
    footer: {
      type: Boolean,
      default: false
    },
    hiddenFooterSeparator: {
      type: Boolean,
      default: false
    },
    cls: {
      type: String,
      default: ""
    },
    theme: {
      type: String,
      default: ""
    },
    cancelBtnText: {
      type: String,
      default: () => $i("scp.vt_component.sf_widget.packages.popover.cancel_btn")
    },
    beforeSubmit: {
      type: [Function, Boolean],
      default: true
    },
    autoHide: {
      type: Boolean,
      default: true
    },
    noPadding: {
      type: Boolean,
      default: false
    },
    anchorHide: {
      type: [Boolean, String],
      default: void 0
    },
    delayHideTime: {
      type: Number,
      default: 400
    },
    submitDisabled: Boolean,
    appendToBody: {
      type: Boolean,
      default: true
    }
  },
  data: function() {
    return {
      popoverID: `popover-${id++}`,
      hasInitFooterHeight: false,
      scrollParentList: [],
      bindTargetSet: /* @__PURE__ */ new Set()
    };
  },
  computed: {
    themeCls() {
      return getPrefixedClassName(this.theme ? `sf-popover-tip--${this.theme} ` : "");
    },
    formattedAnchorHideProp() {
      if (typeof this.anchorHide === "string") {
        badUsageLogger.warn("anchorHide \u63A8\u8350\u4F7F\u7528 Boolean\uFF0C\u5EFA\u8BAE\u4FEE\u6539");
        if (this.anchorHide === "true") {
          return true;
        }
        if (this.anchorHide === "false") {
          return false;
        }
        return void 0;
      }
      return this.anchorHide;
    },
    isAnchorHide() {
      if (typeof this.formattedAnchorHideProp === "undefined") {
        return this.trigger === "hover";
      }
      return Boolean(this.formattedAnchorHideProp);
    },
    popoverCls() {
      return getPrefixedClassName(this.isAnchorHide ? "sf-popover--no-arrow" : "");
    },
    confirmBtnText() {
      return $i("scp.vt_component.sf_widget.packages.popover.confirm_btn");
    }
  },
  watch: {
    offsetX: function(value) {
      if (this.vtip) {
        this.vtip.offsets[0] = Number(value);
        this.vtip.alignTo(this.triggerElem);
      }
    },
    offsetY: function(value) {
      if (this.vtip) {
        this.vtip.offsets[1] = Number(value);
        this.vtip.alignTo(this.triggerElem);
      }
    },
    align: function(value) {
      if (this.vtip) {
        this.vtip.align = value;
        this.vtip.alignTo(this.triggerElem);
      }
    },
    cls: function(newVal, oldVal) {
      var _a;
      if (!this.vtip || ((_a = this.vtip) == null ? void 0 : _a.cls) === newVal) {
        return;
      }
      this.vtip.updateCls(newVal, oldVal);
    }
  },
  mounted: function() {
    const vm = this, vtipCls = [getPrefixedClassName("sf-popover-vtip"), this.themeCls, this.cls, this.popoverCls];
    vm._initMouseInArea();
    if (this.noPadding) {
      vtipCls.push(getPrefixedClassName("sf-popover-vtip--nopadding"));
    }
    this.vtip = new Vtip({
      cls: vtipCls.filter(Boolean).join(" "),
      offsets: [Number(this.offsetX), Number(this.offsetY)],
      anchorOffset: this.anchorOffset,
      anchorHide: this.isAnchorHide,
      anchorSize: this.anchorSize,
      align: this.align,
      hideOnClick: false,
      autoHide: false,
      autoDestroy: false,
      autoRemoveEl: false,
      parent: this.appendToBody ? null : this.$parent.$el
    });
    this.vtip.update(this.$el);
    $(this.vtip.el).off(vm._eventName("mouseenter")).on(vm._eventName("mouseenter"), function() {
      vm._mouseEnterVtipEl();
      if (vm.triggerElem && vm._getTrigger(vm.triggerElem) !== "hover") {
        return;
      }
      vm.show();
    });
    $(this.vtip.el).off(vm._eventName("mouseleave")).on(vm._eventName("mouseleave"), function() {
      vm._mouseLeaveVtipEl();
      if (vm.triggerElem && vm._getTrigger(vm.triggerElem) !== "hover" || !vm.isShown()) {
        return;
      }
      vm._setHideTimer();
    });
    $(document).off(vm._eventName("mousedown")).on(vm._eventName("mousedown"), function(e) {
      var _a, _b;
      const $et = $(e.target);
      const isInQtip = $et.parents(".v-qtip").length;
      const isTriggerElem = getEventPath(e.originalEvent).includes(vm.triggerElem);
      if (!vm.autoHide || ((_b = (_a = $et.closest(vm.vtip.el)) == null ? void 0 : _a.size) == null ? void 0 : _b.call(_a)) || isInQtip || isTriggerElem) {
        return;
      }
      if ($(vm.vtip.el).is(":hidden")) {
        return;
      }
      const ensureToHide = !vm._getMouseInArea();
      ensureToHide && vm.hide();
    });
  },
  beforeDestroy: function() {
    $(document).off(this._eventName());
    this.bindTargetSet.forEach((target) => {
      $(target).off(this._eventName());
    });
    this.unbindScrollEvent();
    this._clearHideTimer();
    this.$vtipEl = this.vtip.el;
    $(this.vtip.el).off(this._eventName());
    this.vtip.destroy();
    this.vtip = null;
    this.triggerElem = null;
    this.bindTargetSet.clear();
    this.scrollParentList = [];
  },
  destroyed: function() {
    this.$vtipEl.remove();
    this.$vtipEl = null;
  },
  methods: {
    getPrefixedClassName,
    getFullUtid(utidBase) {
      return this.$attrs.utid ? `${this.$attrs.utid}-${utidBase}` : utidBase;
    },
    getEl(el) {
      const Vue = this.constructor.super;
      return el instanceof Vue ? el.$el : el;
    },
    bindTarget: function(el) {
      const vm = this;
      el = this.getEl(el);
      if (this.isTargetBind(el)) {
        return;
      }
      $(el).off(vm._eventName("click")).on(vm._eventName("click"), function() {
        const elem = this;
        if (vm._getTrigger(elem) !== "click") {
          return;
        }
        const isDisabledButton = elem.classList.contains("el-button") && elem.classList.contains("is-disabled");
        if (isDisabledButton) {
          return;
        }
        if (vm.isShown() && vm.triggerElem === elem) {
          vm.hide();
        } else {
          vm.show(elem);
          $(document).off(vm._eventName("click")).on(vm._eventName("click"), function(e) {
            const $target = $(e.target);
            const isInQtip = $target.parents(".v-qtip").length;
            if (!$target.closest(elem).length && !$target.closest(vm.vtip.el).length && !isInQtip && vm.autoHide) {
              const ensureToHide = !vm._getMouseInArea();
              ensureToHide && vm.hide();
            }
          });
        }
      });
      $(el).off(vm._eventName("mouseenter")).on(vm._eventName("mouseenter"), function() {
        const elem = this;
        if (vm._getTrigger(elem) !== "hover") {
          return;
        }
        vm.show(elem);
      });
      $(el).off(vm._eventName("mouseleave")).on(vm._eventName("mouseleave"), function() {
        const elem = this;
        if (vm._getTrigger(elem) !== "hover" || !vm.isShown()) {
          return;
        }
        vm._setHideTimer();
      });
      this.saveBindTarget(el);
    },
    unbindTarget: function(el) {
      el = this.getEl(el);
      $(el).off(this._eventName());
      this.removeBindTarget(el);
    },
    show: function(el) {
      el = this.getEl(el);
      this._clearHideTimer();
      this.vtip.show();
      if (el && !$(el).closest(this.vtip.el).length) {
        this.vtip.alignTo(el);
        this.triggerElem = el;
      }
      if (this.footer && !this.hasInitFooterHeight) {
        const FOOTER_HEIGHT = $(this.$refs.footer).height();
        $(this.$refs.popover).parents(".v-tip-body").css({
          "padding-bottom": FOOTER_HEIGHT
        });
        this.hasInitFooterHeight = true;
      }
      this.bindScrollEvent(el);
      this.$emit("shown", this.vtip.el);
    },
    hide: function() {
      this._clearHideTimer();
      $(document).off(this._eventName("click"));
      this.vtip.hide.apply(this.vtip, arguments);
      this.unbindScrollEvent();
      this.$emit("hidden");
    },
    isShown: function() {
      return this.vtip.isShown.apply(this.vtip, arguments);
    },
    _getTrigger: function(el) {
      return $(el).data("popoverTrigger") || this.trigger;
    },
    _setHideTimer: function() {
      const vm = this;
      if (vm.hideTimer) {
        return;
      }
      vm.hideTimer = window.setTimeout(function() {
        vm.hide();
      }, this.delayHideTime);
    },
    _clearHideTimer: function() {
      if (this.hideTimer) {
        window.clearTimeout(this.hideTimer);
        this.hideTimer = null;
      }
    },
    _eventName: function(type) {
      return (type || "") + "." + this.popoverID;
    },
    onSubmit() {
      when(this._fixBefore(this.beforeSubmit)).then((result) => {
        if (result === false) {
          return;
        }
        this.$emit("submit");
        this.hide();
      });
    },
    _fixBefore(value) {
      return typeof value === "boolean" ? value : value();
    },
    onCancel() {
      this.$emit("cancel");
      this.hide();
    },
    bindScrollEvent(target) {
      this.scrollParentList = [];
      const scrollParentList = getScrollParentList(target);
      const vm = this;
      vm.unbindScrollEvent();
      if (scrollParentList.length) {
        vm.scrollParentList = scrollParentList;
        scrollParentList.forEach(function(el) {
          $(el).on(vm._eventName("mousewheel"), vm.scrollHandler);
          $(el).on(vm._eventName("DOMMouseScroll"), vm.scrollHandler);
        });
      }
    },
    unbindScrollEvent() {
      const vm = this;
      if (vm.scrollParentList.length) {
        vm.scrollParentList.forEach(function(el) {
          $(el).off(vm._eventName("mousewheel"));
          $(el).off(vm._eventName("DOMMouseScroll"));
        });
      }
    },
    scrollHandler(e) {
      if (!e.deltaY && !e.deltaX) {
        return;
      }
      if ($(e.target).closest(this.vtip.el).size()) {
        return;
      }
      if ($(this.vtip.el).is(":hidden")) {
        return;
      }
      this.hide();
    },
    _initMouseInArea() {
      this.mouseInArea = false;
    },
    _mouseEnterVtipEl() {
      this.mouseInArea = true;
    },
    _mouseLeaveVtipEl() {
      this.mouseInArea = false;
    },
    _getMouseInArea() {
      return this.mouseInArea;
    },
    saveBindTarget(target) {
      this.bindTargetSet.add(target);
    },
    removeBindTarget(target) {
      this.bindTargetSet.delete(target);
    },
    isTargetBind(target) {
      return this.bindTargetSet.has(target);
    },
    getBindTarget() {
      return [...this.bindTargetSet];
    }
  }
};
const __vue_script__$1 = script$1;
var __vue_render__$1 = function() {
  var _obj;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    { ref: "popover", class: _vm.getPrefixedClassName("sf-popover") },
    [
      _c(
        "div",
        {
          class: [
            _vm.getPrefixedClassName("sf-popover_body"),
            _vm.getPrefixedClassName("sf-layer-locate-container")
          ]
        },
        [
          _vm._t("default", [
            _c(
              "div",
              { class: _vm.getPrefixedClassName("sf-popover_body-inner") },
              [_vm._t("body-inner")],
              2
            )
          ])
        ],
        2
      ),
      _vm._v(" "),
      _vm.footer ? _c(
        "div",
        {
          ref: "footer",
          class: (_obj = {}, _obj[_vm.getPrefixedClassName("sf-popover_footer")] = true, _obj[_vm.getPrefixedClassName("sf-popover_footer-no-border")] = _vm.hiddenFooterSeparator, _obj)
        },
        [
          _vm._t("footer", [
            _c(
              "div",
              {
                class: _vm.getPrefixedClassName("sf-popover_footer-inner")
              },
              [
                _vm._t("footer-inner", [
                  _c(
                    "sf-button",
                    {
                      class: [
                        _vm.getPrefixedClassName(
                          "sf-popover_footer-inner-confirm-btn"
                        ),
                        _vm.getPrefixedClassName(
                          "sf-popover_footer-submit-btn"
                        )
                      ],
                      attrs: {
                        type: "primary",
                        size: "small",
                        utid: _vm.getFullUtid("submit"),
                        disabled: _vm.submitDisabled
                      },
                      on: { click: _vm.onSubmit }
                    },
                    [_c("span", [_vm._v(_vm._s(_vm.confirmBtnText))])]
                  ),
                  _vm._v(" "),
                  _c(
                    "sf-button",
                    {
                      class: _vm.getPrefixedClassName(
                        "sf-popover_footer-cancel-btn"
                      ),
                      attrs: {
                        type: "cancel",
                        size: "small",
                        utid: _vm.getFullUtid("cancel")
                      },
                      on: { click: _vm.onCancel }
                    },
                    [
                      _vm._v(
                        "\n            " + _vm._s(_vm.cancelBtnText) + "\n          "
                      )
                    ]
                  )
                ])
              ],
              2
            )
          ])
        ],
        2
      ) : _vm._e()
    ]
  );
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
var script = {
  name: componentName.popoverForm,
  componentName: componentName.popoverForm,
  components: {
    SfButton,
    SfPopover: __vue_component__$1
  },
  directives: {
    popover: vPopover
  },
  props: {
    popoverCls: {
      type: String,
      default: ""
    },
    popoverTipCls: {
      type: String,
      default: ""
    },
    triggerText: {
      type: String,
      default: () => $i("scp.vt_component.sf_widget.packages.popover_form.src.btn_default_text")
    },
    noResetData: Boolean,
    beforeSubmit: {
      type: [Function, Boolean],
      default: true
    },
    showFooter: {
      type: Boolean,
      default: true
    },
    autoHide: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      popoverID: "",
      lastData: {},
      form: null
    };
  },
  computed: {
    popoverRef() {
      return this.$refs.popover;
    }
  },
  mounted() {
    this.setForm();
    this.popoverID = uuid("popover-form-popover-");
    this.$vnode.context.$refs[this.popoverID] = this.$refs.popover;
  },
  beforeDestroy() {
    this.$vnode.context.$refs[this.popoverID] = null;
  },
  methods: {
    getPrefixedClassName,
    setForm() {
      this.form = this.$refs.popover.$children.find((item) => {
        return item.$options.componentName === componentName.form;
      });
    },
    submit() {
      this.lastData = this.getData() || {};
      this.$emit("submit", this.lastData);
    },
    cancel() {
      this.$emit("cancel", JSON.parse(JSON.stringify(this.lastData)));
    },
    getPopoverID() {
      return this.popoverID;
    },
    getData() {
      if (this.form) {
        return this.form.getValue();
      }
    },
    setData(data) {
      if (this.form) {
        this.form.setValue(data);
      }
    },
    resetLastData() {
      const hasLastData = Object.keys(this.lastData).length;
      this.$emit("shown", this.lastData);
      if (this.noResetData || !hasLastData) {
        return;
      }
      this.setData(this.lastData);
    },
    getPopoverRef() {
      return this.popoverRef;
    },
    hide() {
      this.popoverRef.hide();
    },
    show() {
      this.popoverRef.show();
    }
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    { class: _vm.getPrefixedClassName("popover-form") },
    [
      _c(
        "sf-popover",
        {
          ref: "popover",
          class: [
            _vm.getPrefixedClassName("popover-form__popover"),
            _vm.getPrefixedClassName("sf-popover-form"),
            _vm.popoverCls
          ],
          attrs: {
            align: "bt-rl",
            "auto-hide": _vm.autoHide,
            footer: _vm.showFooter,
            cls: _vm.popoverTipCls,
            "before-submit": _vm.beforeSubmit
          },
          on: {
            submit: _vm.submit,
            cancel: _vm.cancel,
            shown: _vm.resetLastData
          }
        },
        [_c("template", { slot: "body-inner" }, [_vm._t("default")], 2)],
        2
      ),
      _vm._v(" "),
      _vm._t(
        "trigger",
        [
          _c(
            "sf-button",
            {
              directives: [
                {
                  name: "popover",
                  rawName: "v-popover:popover.click",
                  arg: "popover",
                  modifiers: { click: true }
                }
              ]
            },
            [_vm._v(_vm._s(_vm.triggerText))]
          )
        ],
        {
          submit: _vm.submit,
          cancel: _vm.cancel,
          triggerText: _vm.triggerText,
          popover: _vm.popoverID
        }
      )
    ],
    2
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__$1 as SfPopover, __vue_component__ as SfPopoverForm };
