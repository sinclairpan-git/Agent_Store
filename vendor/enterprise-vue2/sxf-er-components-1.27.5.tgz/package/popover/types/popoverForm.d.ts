import type { SfPopover } from './popover';

import Vue, { VNode } from 'vue';

export interface SfPopoverFormProps {
  /**
   * 样式 class
   *
   * @default ''
   */
  popoverCls: string;
  /**
   * tip的class
   *
   * @default ''
   */
  popoverTipCls: string;
  /**
   * 按钮文本
   *
   * @default '默认文本'
   */
  triggerText: string;

  /**
   * 不需要复位为上次点击确定按钮时的值
   */
  noResetData: boolean;

  /**
   * 提交钩子，可返回promise或布尔值
   * 如果返回false，或promise resolve(false) reject，则阻止提交
   *
   * @default true
   */
  beforeSubmit: boolean | (() => JQuery.Promise<any> | boolean);

  /**
   * 是否点击popover以外的地方就自动关闭popover
   *
   * @default true
   */
  autoHide: boolean;
}

export interface SfPopoverFormSlots {
  $slots: {
    default: VNode[];
    trigger?: VNode[];
  };
}

export interface SfPopoverFormEvents {
  $emit(eventName: 'submit', data: Record<string, any>): this;
  $emit(eventName: 'cancel', data: Record<string, any>): this;
  $emit(eventName: 'shown', data: Record<string, any>): this;
}

export interface SfPopoverFormMethods {
  /**
   * 设置表单
   */
  setForm: () => void;

  /**
   * 提交数据
   */
  submit: () => void;

  /**
   * 取消
   */
  cancel: () => void;

  /**
   * 获取表单数据
   */
  getData: () => Record<string, any>;

  /**
   * 设置表单数据
   *
   * @param data 表单的数据
   */
  setData: (data: Record<string, any>) => void;

  /**
   * 复位为上次点击确定按钮时的值
   */
  resetLastData: () => void;

  /**
   * 获取当前的popover refs
   */
  getPopoverRef: () => SfPopover;

  /**
   * 主动隐藏当前popover
   */
  hide: () => void;

  /**
   * 主动显示当前popover
   */
  show: () => void;
}

export type SfPopoverForm = Readonly<SfPopoverFormProps & SfPopoverFormSlots & SfPopoverFormMethods> & Vue;
