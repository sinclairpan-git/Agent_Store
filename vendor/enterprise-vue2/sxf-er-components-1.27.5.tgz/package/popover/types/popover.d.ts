import { VNode } from 'vue';

export declare type SfPopoverTrigger = 'click' | 'hover' | 'manual';

export declare type SfPopoverAlign = 'lr-tb' | 'lr-bt' | 'tb-rl' | 'tb-lr' | 'bt-lr' | 'bt-rl' | 'rl-bt' | 'rl-tb';

export interface SfPopoverProps {
  /**
   * 触发方式，支持 'click', 'hover'
   * 手动触发请设置 'manual'
   *
   * @default 'click'
   */
  trigger: SfPopoverTrigger;

  /**
   * 水平偏移量
   *
   * @default 0
   */
  offsetX: string | number;

  /**
   * 垂直偏移量
   *
   * @default 0
   */
  offsetY: string | number;

  /**
   * 小三角偏移量
   *
   * @default 0
   */
  anchorOffset: number;

  /**
   * 小三角大小
   *
   * @default 0
   */
  anchorSize: number;

  /**
   * 对齐方式
   *
   * @default 'rl-bt'
   */
  align: SfPopoverAlign;

  /**
   * 是否使用footer
   *
   * @default false
   */
  footer: boolean;

  /**
   * 增加自定义样式
   *
   * @default ''
   */
  cls: string;

  /**
   * 取消按钮文案
   *
   * @default '取消'
   */
  cancelBtnText: string;

  /**
   * 提交钩子，可返回promise或布尔值
   *
   * @default true
   */
  beforeSubmit: boolean | (() => JQuery.Promise<any> | boolean);

  /**
   * 是否点击popover以外的地方就自动关闭popover
   *
   * @default true
   */
  autoHide: boolean;
}

export interface SfPopoverSlots {
  $slots: {
    default: VNode[];
    'body-inner'?: VNode[];
    'footer-inner'?: VNode[];
    footer?: VNode[];
  };
}

export interface SfPopoverEvents {
  $emit(eventName: 'shown'): this;
  $emit(eventName: 'hidden'): this;
  $emit(eventName: 'submit'): this;
  $emit(eventName: 'cancel'): this;
}

export interface SfPopoverMethods {
  bindTarget: (el: Element | Vue | JQuery) => void;
  unbindTarget: (el: Element | Vue | JQuery) => void;
  show: (el?: Element | Vue | JQuery) => void;
  hide: () => void;
  isShown: () => boolean;
}

export declare type SfPopover = Readonly<SfPopoverProps & SfPopoverSlots & SfPopoverMethods> & Vue;
