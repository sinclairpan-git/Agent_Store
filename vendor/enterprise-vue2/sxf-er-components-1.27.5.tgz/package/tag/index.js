import { componentName } from '@sxf/er-components/_const';
import { getPrefixedClassName } from '@sxf/er-feature';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
import { SfIconText } from '@sxf/er-components/_pro/icon-text';
import { SfPopover } from '@sxf/er-components/popover';
var script$1 = {
  name: componentName.tag,
  componentName: componentName.tag,
  props: {
    type: {
      type: String,
      default: "gray",
      validator(v) {
        return [
          "gray",
          "primary",
          "success",
          "danger",
          "warning",
          "critical",
          "alarm",
          "minor",
          "multiple-select"
        ].includes(v);
      }
    },
    closeable: {
      type: Boolean,
      default: false
    },
    size: {
      type: String,
      default: "small",
      validator(v) {
        return ["large", "normal", "small"].includes(v);
      }
    },
    effect: {
      type: String,
      default: "light",
      validator(v) {
        return ["dark", "light"].includes(v);
      }
    },
    isOval: {
      type: Boolean,
      default: false
    },
    tagTextStyle: {
      type: Object
    },
    icon: {
      type: String
    },
    maxWidth: {
      type: [Number, String]
    }
  },
  data() {
    return {
      closeIconCls: "vtv-icon-comp-tip-close"
    };
  },
  computed: {
    tagCls() {
      return [
        getPrefixedClassName("sf-tag"),
        getPrefixedClassName("sf-tag_" + this.effect),
        getPrefixedClassName("sf-tag_" + this.type),
        getPrefixedClassName("sf-tag_" + this.size),
        this.closeable ? getPrefixedClassName("sf-tag-with-icon") : "",
        this.isOval ? getPrefixedClassName("sf-tag-oval") : "",
        this.type === `multiple-select` ? getPrefixedClassName("sf-tag_multiple-select_" + this.size) : ""
      ];
    },
    labelClasses() {
      return {
        [getPrefixedClassName("sf-tag-label")]: true,
        [getPrefixedClassName("sf-tag-label_ellipsis")]: this.maxWidth
      };
    },
    labelStyle() {
      const style = { ...this.tagTextStyle };
      if (this.maxWidth != null) {
        style.maxWidth = typeof this.maxWidth === "number" ? `${this.maxWidth}px` : this.maxWidth;
      }
      return style;
    },
    iconCls() {
      return [getPrefixedClassName("sf-tag-before-icon"), `iconfont`, this.icon];
    },
    closeBtnCls() {
      return [getPrefixedClassName("sf-tag-close-icon"), `iconfont`, this.closeIconCls];
    }
  },
  methods: {
    handleClick(event) {
      this.$emit("click", event);
    },
    handleClose(event) {
      event.stopPropagation();
      this.$emit("close", event);
    },
    getPrefixedClassName
  }
};
const __vue_script__$1 = script$1;
var __vue_render__$1 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c("div", { class: _vm.tagCls, on: { click: _vm.handleClick } }, [
    _c("div", { class: [_vm.getPrefixedClassName("sf-tag-inner")] }, [
      _vm.icon ? _c("i", { class: _vm.iconCls }) : _vm._e(),
      _vm._v(" "),
      _c(
        "span",
        { class: _vm.labelClasses, style: _vm.labelStyle },
        [_vm._t("default")],
        2
      ),
      _vm._v(" "),
      _vm.closeable ? _c("i", {
        class: _vm.closeBtnCls,
        on: {
          click: _vm.handleClose,
          mouseleave: function($event) {
            _vm.closeIconCls = "vtv-icon-comp-tip-close";
          }
        }
      }) : _vm._e()
    ])
  ]);
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
var script = {
  name: componentName.tagGroup,
  componentName: componentName.tagGroup,
  components: {
    SfTag: __vue_component__$1,
    SfIconText,
    SfPopover
  },
  props: {
    tagType: {
      type: String,
      default: "tag",
      validator(v) {
        return ["tag", "iconText"].includes(v);
      }
    },
    tagOptions: {
      type: Array,
      default: () => []
    },
    maxLength: {
      type: Number,
      default: 3
    },
    maxWidth: {
      type: [Number, String],
      default: "100%"
    }
  },
  data() {
    return {
      defaultTextStyle: {
        textAlign: "left"
      },
      popoverElement: null,
      canShowTip: false,
      hideTipTimer: null
    };
  },
  computed: {
    tagComponentType() {
      return this.tagType === "tag" ? componentName.tag : componentName.iconText;
    },
    tagComponentOptions() {
      return this.tagOptions.slice(0, this.maxLength);
    },
    canShowEllipsis() {
      return this.tagOptions.length - this.maxLength > 0 && this.tagOptions.length !== 1;
    }
  },
  watch: {
    tagOptions() {
      this.popoverElement = null;
      this.canShowTip = false;
      this.initPopover();
    }
  },
  mounted() {
    this.initPopover();
  },
  beforeDestroy() {
    clearTimeout(this.hideTipTimer);
    this.hideTipTimer = null;
  },
  methods: {
    initPopover() {
      if (this.tagOptions.length === 1) {
        const tagGroupWraps = this.$refs.tagGroupWraps;
        this.$nextTick(() => {
          const ellipsisElement = tagGroupWraps.querySelector(".sf-tag-label_ellipsis");
          if (ellipsisElement && ellipsisElement.scrollWidth > ellipsisElement.clientWidth) {
            this.canShowTip = true;
          }
          this.setupPopoverEventListeners();
        });
      }
      if (this.tagOptions.length > this.maxLength) {
        this.canShowTip = true;
      }
      this.setupPopoverEventListeners();
    },
    setupPopoverEventListeners() {
      if (this.canShowTip) {
        this.$nextTick(() => {
          this.popoverElement = this.$refs.popover;
          const popoverWrap = this.popoverElement.$el.closest(".sf-popover-vtip");
          popoverWrap.addEventListener("mouseenter", this.enterTip);
          popoverWrap.addEventListener("mouseleave", this.hideTip);
        });
      }
    },
    handleClick(text, index) {
      this.$emit("click", text, index);
    },
    handleClose(text, index) {
      this.$emit("close", text, index);
    },
    showTip(event) {
      const target = event.target;
      if (this.hideTipTimer) {
        clearTimeout(this.hideTipTimer);
        this.hideTipTimer = null;
      }
      if (this.canShowTip) {
        this.popoverElement.show(target);
      }
    },
    hideTip() {
      if (this.popoverElement) {
        this.hideTipTimer = setTimeout(() => {
          this.popoverElement.hide();
        }, this.popoverElement.delayHideTime);
      }
    },
    enterTip() {
      if (this.hideTipTimer) {
        clearTimeout(this.hideTipTimer);
        this.hideTipTimer = null;
      }
    },
    getPrefixedClassName
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    [
      _c(
        "div",
        {
          ref: "tagGroupWraps",
          class: _vm.getPrefixedClassName("sf-tag-group-wraps"),
          on: { mouseenter: _vm.showTip, mouseleave: _vm.hideTip }
        },
        [
          _vm._l(_vm.tagComponentOptions, function(item, index) {
            var _obj;
            return _c(
              _vm.tagComponentType,
              _vm._b(
                {
                  key: _vm.tagComponentType + "-show-" + index,
                  tag: "component",
                  class: (_obj = {}, _obj[_vm.getPrefixedClassName("sf-tag-group-item")] = _vm.tagOptions.length !== 1, _obj),
                  attrs: {
                    "tag-text-style": _vm.defaultTextStyle,
                    "max-width": _vm.maxWidth
                  },
                  on: {
                    click: function($event) {
                      return _vm.handleClick(item.value, index);
                    },
                    close: function($event) {
                      return _vm.handleClose(item.value, index);
                    }
                  }
                },
                "component",
                item,
                false
              ),
              [_vm._v("\n      " + _vm._s(item.value) + "\n    ")]
            );
          }),
          _vm._v(" "),
          _vm.canShowEllipsis ? _c(
            "div",
            { class: _vm.getPrefixedClassName("sf-tag-group-ellipsis") },
            [_vm._v("...")]
          ) : _vm._e()
        ],
        2
      ),
      _vm._v(" "),
      _vm.canShowTip ? _c(
        "sf-popover",
        {
          ref: "popover",
          attrs: {
            align: "bt-rl",
            cls: _vm.getPrefixedClassName("sf-tag-group-popover")
          }
        },
        _vm._l(_vm.tagOptions, function(item, index) {
          return _c(
            _vm.tagComponentType,
            _vm._b(
              {
                key: _vm.tagComponentType + "-tip-" + index,
                tag: "component",
                class: _vm.getPrefixedClassName(
                  "sf-tag-group-item__popover-innner"
                ),
                attrs: {
                  "tag-text-style": _vm.defaultTextStyle,
                  closeable: false
                }
              },
              "component",
              item,
              false
            ),
            [_vm._v("\n      " + _vm._s(item.value) + "\n    ")]
          );
        }),
        1
      ) : _vm._e()
    ],
    1
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__$1 as SfTag, __vue_component__ as SfTagGroup };
