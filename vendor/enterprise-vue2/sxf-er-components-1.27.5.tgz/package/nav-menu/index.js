import $ from 'jquery';
import { componentName } from '@sxf/er-components/_const';
import { EmitterMixin } from '@sxf/er-components/_mixins';
import { isPropEnabled, getVueParent } from '@sxf/er-components/_utils/vue-utils';
import { SfScrollbar } from '@sxf/er-components/scrollbar';
import { getPrefixedClassName } from '@sxf/er-feature';
import loggerUtil from '@sxf/er-utils/logger';
import { when } from '@sxf/er-utils/when';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
import { SfFlexItem, SfFlex } from '@sxf/er-components/flex';
let PaddingLeft = 20;
let count = 0;
const MenuMixin = {
  updateDefaultOptions(options = {}) {
    if (options.paddingLeft) {
      PaddingLeft = options.paddingLeft;
    }
  },
  computed: {
    indexPath: function() {
      const path = [this.index];
      let parent = this.$parent;
      while (parent.$options.componentName !== componentName.navMenu) {
        if (parent.index) {
          path.unshift(parent.index);
        }
        parent = parent.$parent;
      }
      return path;
    },
    rootMenu: function() {
      let parent = this.$parent;
      while (parent && parent.$options.componentName !== componentName.navMenu) {
        parent = parent.$parent;
      }
      return parent;
    },
    parentMenu: function() {
      let parent = this.$parent;
      while (parent && [componentName.navMenu, componentName.navSubMenu].indexOf(parent.$options.componentName) === -1) {
        parent = parent.$parent;
      }
      return parent;
    },
    paddingStyle: function() {
      let padding = 0;
      let parent = this.$parent;
      if (this.collapse) {
        padding = PaddingLeft;
      } else {
        while (parent && parent.$options.componentName !== componentName.navMenu) {
          if (parent.$options.componentName === componentName.navSubMenu) {
            padding += PaddingLeft;
          }
          parent = parent.$parent;
        }
      }
      return { paddingLeft: padding + "px" };
    },
    count: function() {
      return count++;
    }
  },
  methods: {
    clickItem: function() {
      this.$children.forEach(function(child) {
        if (child.$options.componentName === componentName.navMenuItem) {
          child.isActive = false;
        }
      });
      this.$parent.$emit("click.item");
    },
    onClickFn: function(e, menuItem) {
      const data = menuItem.data;
      if (data.disabled) {
        return;
      }
      if (typeof data.click === "function") {
        data.click(e, menuItem);
      }
    }
  }
};
var script$5 = {
  name: componentName.navMenuItem,
  componentName: componentName.navMenuItem,
  mixins: [MenuMixin, EmitterMixin],
  props: {
    index: {
      type: String,
      required: true
    },
    hideTip: {
      type: Boolean,
      default: false
    },
    icon: String,
    image: String,
    disabled: true,
    dataHint: {
      type: String,
      default: ""
    },
    contentHint: {
      type: String,
      default: ""
    },
    data: Object,
    showDot: {
      type: Boolean,
      default: false
    },
    iconCollapseMode: {
      type: Boolean,
      default: false
    }
  },
  data: function() {
    return {
      contentTip: ""
    };
  },
  computed: {
    isActive: function() {
      return this.index === this.rootMenu.activeIndex;
    },
    isDisabled: function() {
      return isPropEnabled(this.disabled);
    },
    menuItemstyle: function() {
      return `background-image: url('${this.image}')`;
    }
  },
  updated: function() {
    this.$nextTick(() => {
      if (this.hideTip) {
        this.contentTip = "";
        return;
      }
      this.contentTip = this.contentHint || $(this.$refs.navMenuItem).text().trim();
    });
  },
  created() {
    this.parentMenu.addItem(this);
    this.rootMenu.addItem(this);
  },
  beforeDestroy() {
    this.parentMenu.removeItem(this);
    this.rootMenu.removeItem(this);
  },
  methods: {
    onClick: function(e) {
      if (this.disabled || this.isActive) {
        return;
      }
      this.$emit("click", e, this);
      this.dispatch(componentName.navMenu, "click.item", [e, this]);
    },
    getPrefixedClassName
  }
};
const __vue_script__$6 = script$5;
var __vue_render__$6 = function() {
  var _obj;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "li",
    {
      ref: "navMenuItem",
      class: [
        _vm.getPrefixedClassName("sf-nav-menu-list-item"),
        (_obj = {}, _obj[_vm.getPrefixedClassName("active")] = _vm.isActive, _obj[_vm.getPrefixedClassName("disable")] = _vm.isDisabled, _obj[_vm.getPrefixedClassName("collapsed")] = _vm.iconCollapseMode, _obj)
      ],
      style: _vm.paddingStyle,
      attrs: { disabled: _vm.isDisabled, count: _vm.count },
      on: { click: _vm.onClick }
    },
    [
      _c(
        "div",
        { class: _vm.getPrefixedClassName("sf-nav-menu-list-item-dot-before") },
        [
          _vm.isActive && !_vm.isDisabled && _vm.showDot ? _c("div", {
            class: _vm.getPrefixedClassName(
              "sf-nav-menu-list-item_pointer"
            )
          }) : _vm._e()
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        {
          class: _vm.getPrefixedClassName("sf-nav-menu-list-content"),
          style: _vm.paddingStyle
        },
        [
          _vm.icon ? _c("i", {
            class: [
              "iconfont",
              "vtv-icon-" + _vm.icon,
              _vm.getPrefixedClassName("sf-nav-menu-icon")
            ],
            attrs: { "data-tip": _vm.dataHint }
          }) : _vm._e(),
          _vm._v(" "),
          _vm.image ? _c("i", {
            class: _vm.getPrefixedClassName("sf-group-menu-image-before"),
            style: _vm.menuItemstyle,
            attrs: { "data-tip": _vm.dataHint }
          }) : _vm._e(),
          _vm._v(" "),
          _c(
            "span",
            {
              class: [
                _vm.getPrefixedClassName("sf-nav-menu-item-text"),
                "ellipsis"
              ],
              attrs: {
                "data-tip": _vm.contentTip,
                "data-hint-offsets": "0, 0"
              }
            },
            [_vm._t("default")],
            2
          )
        ]
      )
    ]
  );
};
var __vue_staticRenderFns__$6 = [];
__vue_render__$6._withStripped = true;
const __vue_inject_styles__$6 = void 0;
const __vue_scope_id__$6 = void 0;
const __vue_module_identifier__$6 = void 0;
const __vue_is_functional_template__$6 = false;
const __vue_component__$6 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$6, staticRenderFns: __vue_staticRenderFns__$6 },
  __vue_inject_styles__$6,
  __vue_script__$6,
  __vue_scope_id__$6,
  __vue_is_functional_template__$6,
  __vue_module_identifier__$6,
  false,
  void 0,
  void 0,
  void 0
);
const SfNavSubMenu = {
  name: componentName.navSubMenu,
  componentName: componentName.navSubMenu,
  mixins: [MenuMixin, EmitterMixin],
  props: {
    options: {
      type: Array,
      default: function() {
        return [];
      }
    },
    index: {
      type: String,
      required: true
    },
    icon: {
      type: String,
      default: ""
    },
    openedIcon: {
      type: String,
      default: "comp-arrow-down-big"
    },
    closedIcon: {
      type: String,
      default: "comp-arrow-right-big"
    },
    disableToggle: {
      type: Boolean,
      default: false
    },
    iconCollapseMode: {
      type: Boolean,
      default: false
    }
  },
  data: function() {
    return {
      items: {},
      subMenus: {},
      hintTitle: ""
    };
  },
  computed: {
    isActive: function() {
      let active = false;
      const subMenus = this.subMenus, items = this.items;
      Object.keys(items).forEach(function(index) {
        if (items[index].isActive) {
          active = true;
          return false;
        }
      });
      Object.keys(subMenus).forEach(function(index) {
        if (subMenus[index].isActive) {
          active = true;
          return false;
        }
      });
      return active;
    },
    isOpened: function() {
      return this.rootMenu.openedMenus.indexOf(this.index) !== -1;
    },
    subMenuOptions() {
      return this.options;
    },
    navSubmenuIconCls() {
      return ["iconfont", `vtv-icon-${this.isOpened ? this.openedIcon : this.closedIcon}`];
    }
  },
  updated: function() {
    const vm = this;
    vm.$nextTick(function() {
      vm.hintTitle = $(vm.$refs.navSubmenuTitle).text().trim();
    });
  },
  created: function() {
    this.parentMenu.addSubMenu(this);
    this.rootMenu.addSubMenu(this);
  },
  beforeDestroy: function() {
    this.parentMenu.removeSubMenu(this);
    this.rootMenu.removeSubMenu(this);
  },
  methods: {
    addItem: function(item) {
      this.$set(this.items, item.index, item);
    },
    removeItem: function(item) {
      delete this.items[item.index];
    },
    addSubMenu: function(submenu) {
      this.$set(this.subMenus, submenu.index, submenu);
    },
    removeSubMenu: function(submenu) {
      delete this.subMenus[submenu.index];
    },
    handleSubMenuClick: function() {
      if (this.disableToggle) {
        return;
      }
      this.dispatch(componentName.navMenu, "click.submenu", [this]);
    },
    getPrefixedClassName
  }
};
SfNavSubMenu.components = {
  SfNavMenuItem: __vue_component__$6,
  SfNavSubMenu
};
const __vue_script__$5 = SfNavSubMenu;
var __vue_render__$5 = function() {
  var _obj;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "li",
    {
      class: (_obj = {}, _obj[_vm.getPrefixedClassName("sf-nav-sub-menu")] = true, _obj[_vm.getPrefixedClassName("active")] = _vm.isActive, _obj[_vm.getPrefixedClassName("opened")] = _vm.isOpened, _obj)
    },
    [
      _c(
        "div",
        {
          ref: "navSubmenuTitle",
          class: _vm.getPrefixedClassName("sf-nav-sub-menu_title"),
          style: _vm.paddingStyle,
          attrs: { "data-tip": _vm.hintTitle },
          on: { click: _vm.handleSubMenuClick }
        },
        [
          _c(
            "div",
            {
              class: [
                _vm.getPrefixedClassName("sf-nav-sub-menu_title-content"),
                "ellipsis"
              ]
            },
            [
              _vm.icon ? _c("i", {
                class: [
                  _vm.getPrefixedClassName("sf-nav-menu-icon"),
                  "iconfont",
                  "vtv-icon-" + _vm.icon
                ]
              }) : _vm._e(),
              _vm._v(" "),
              _vm._t("title")
            ],
            2
          ),
          _vm._v(" "),
          !_vm.disableToggle ? _c(
            "div",
            { class: _vm.getPrefixedClassName("sf-nav-sub-menu_icon") },
            [_c("i", { class: _vm.navSubmenuIconCls })]
          ) : _vm._e()
        ]
      ),
      _vm._v(" "),
      _c("transition", { attrs: { name: "sf-menu-transition" } }, [
        _vm.subMenuOptions.length ? _c(
          "ul",
          {
            directives: [
              {
                name: "show",
                rawName: "v-show",
                value: _vm.isOpened,
                expression: "isOpened"
              }
            ],
            class: _vm.getPrefixedClassName("sf-nav-sub-menu_content")
          },
          [
            _vm._l(_vm.subMenuOptions, function(item) {
              return [
                !item.child ? _c(
                  "sf-nav-menu-item",
                  {
                    key: item.index,
                    attrs: {
                      index: item.index,
                      icon: item.icon,
                      image: item.image,
                      disabled: item.disabled,
                      "data-hint": item.dataHint,
                      "content-hint": item.contentHint,
                      data: item
                    },
                    on: { click: _vm.onClickFn }
                  },
                  [
                    _vm._v(
                      "\n          " + _vm._s(item.contentText) + "\n        "
                    )
                  ]
                ) : _vm._e(),
                _vm._v(" "),
                item.child ? _c(
                  "sf-nav-sub-menu",
                  {
                    key: item.index,
                    attrs: {
                      index: item.index,
                      icon: item.icon,
                      options: item.child,
                      "disable-toggle": item.disableToggle
                    }
                  },
                  [
                    _c(
                      "span",
                      { attrs: { slot: "title" }, slot: "title" },
                      [_vm._v(_vm._s(item.title))]
                    )
                  ]
                ) : _vm._e()
              ];
            })
          ],
          2
        ) : _c(
          "ul",
          {
            directives: [
              {
                name: "show",
                rawName: "v-show",
                value: _vm.isOpened,
                expression: "isOpened"
              }
            ],
            class: _vm.getPrefixedClassName("sf-nav-sub-menu_content")
          },
          [_vm._t("default")],
          2
        )
      ])
    ],
    1
  );
};
var __vue_staticRenderFns__$5 = [];
__vue_render__$5._withStripped = true;
const __vue_inject_styles__$5 = void 0;
const __vue_scope_id__$5 = void 0;
const __vue_module_identifier__$5 = void 0;
const __vue_is_functional_template__$5 = false;
const __vue_component__$5 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$5, staticRenderFns: __vue_staticRenderFns__$5 },
  __vue_inject_styles__$5,
  __vue_script__$5,
  __vue_scope_id__$5,
  __vue_is_functional_template__$5,
  __vue_module_identifier__$5,
  false,
  void 0,
  void 0,
  void 0
);
const name = "SfNavMenuTitle";
var script$4 = {
  name,
  componentName: name,
  props: {
    title: true,
    titleIcon: {
      type: String,
      default: ""
    },
    titleIconImage: {
      type: String,
      default: ""
    }
  },
  computed: {
    iconCls() {
      if (!this.titleIcon) {
        return this.titleIconImage ? getPrefixedClassName("use-image-background") : "";
      }
      return "iconfont vtv-icon-" + this.titleIcon;
    },
    iconStyle() {
      if (!this.titleIconImage || this.titleIcon) {
        return {};
      }
      return {
        background: `url(${this.titleIconImage}) center center no-repeat`
      };
    }
  },
  methods: {
    getHeight() {
      return $(this.$el).outerHeight() || 0;
    },
    getPrefixedClassName
  }
};
const __vue_script__$4 = script$4;
var __vue_render__$4 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c("div", { class: _vm.getPrefixedClassName("sf-nav-menu_title") }, [
    _vm.titleIcon || _vm.titleIconImage ? _c("i", {
      class: [_vm.getPrefixedClassName("sf-nav-menu-icon"), _vm.iconCls],
      style: _vm.iconStyle
    }) : _vm._e(),
    _vm._v(" "),
    _c("span", { class: _vm.getPrefixedClassName("sf-nav-menu_title-text") }, [
      _vm._v(" " + _vm._s(_vm.title) + " ")
    ])
  ]);
};
var __vue_staticRenderFns__$4 = [];
__vue_render__$4._withStripped = true;
const __vue_inject_styles__$4 = void 0;
const __vue_scope_id__$4 = void 0;
const __vue_module_identifier__$4 = void 0;
const __vue_is_functional_template__$4 = false;
const __vue_component__$4 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$4, staticRenderFns: __vue_staticRenderFns__$4 },
  __vue_inject_styles__$4,
  __vue_script__$4,
  __vue_scope_id__$4,
  __vue_is_functional_template__$4,
  __vue_module_identifier__$4,
  false,
  void 0,
  void 0,
  void 0
);
const logger = loggerUtil(componentName.navMenu);
var script$3 = {
  name: componentName.navMenu,
  componentName: componentName.navMenu,
  components: {
    SfScrollbar,
    SfNavMenuItem: __vue_component__$6,
    SfNavMenuTitle: __vue_component__$4,
    SfNavSubMenu: __vue_component__$5
  },
  mixins: [EmitterMixin, MenuMixin],
  props: {
    options: {
      type: Array,
      default: function() {
        return [];
      }
    },
    title: true,
    titleUrl: "",
    showExpandIcon: {
      type: Boolean,
      default: true
    },
    titleShow: {
      type: Boolean,
      default: false
    },
    titleIcon: {
      type: String,
      default: ""
    },
    titleIconImage: {
      type: String,
      default: ""
    },
    defaultActive: {
      type: String,
      default: ""
    },
    defaultOpeneds: [Array, String],
    uniqueOpened: true,
    expandAll: true,
    pathName: String,
    autoActivePanel: {
      type: Boolean,
      default: true
    },
    hidden: {
      type: Boolean,
      default: false
    },
    before: {
      type: [Function, Boolean],
      default: true
    },
    showDot: {
      type: Boolean,
      default: false
    },
    emitEvent: {
      type: Boolean,
      default: false
    },
    iconCollapseMode: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      bodyStyle: {},
      activeIndex: "",
      openedMenus: [],
      subMenus: {},
      items: {},
      firstActive: true,
      isExpanded: true
    };
  },
  computed: {
    isTitleShow: function() {
      return isPropEnabled(this.titleShow);
    },
    isUniqueOpened: function() {
      return isPropEnabled(this.uniqueOpened);
    },
    isExpandAll: function() {
      return isPropEnabled(this.expandAll);
    },
    menuDefaultOpeneds: function() {
      return this.defaultOpeneds;
    },
    menuOptions: function() {
      return this.options;
    },
    navWrap() {
      let parent = this.$parent;
      let depth = 0;
      const limit = 10;
      while (parent && parent.$options.componentName !== componentName.navWrap && parent.$options.componentName !== componentName.pageNavWrap && depth < limit) {
        parent = parent.$parent;
        depth++;
      }
      if (parent && parent.$options.componentName !== componentName.navWrap && parent.$options.componentName !== componentName.pageNavWrap) {
        return null;
      }
      return parent;
    },
    toggleIconCls() {
      return [
        "iconfont",
        getPrefixedClassName("sf-nav-menu_slider-icon"),
        this.isExpanded ? "vtv-icon-prev-month" : "vtv-icon-next-month"
      ];
    },
    navMenuCls() {
      return {
        hidden: this.hidden,
        [getPrefixedClassName("sf-nav-menu")]: true,
        [getPrefixedClassName("sf-nav-menu--expanded")]: !this.isExpanded,
        [getPrefixedClassName("sf-nav-menu--icon-collapse")]: this.iconCollapseMode
      };
    }
  },
  watch: {
    isTitleShow: function() {
      this.updateContentHeight();
    },
    defaultActive: function(value) {
      this.$nextTick(() => {
        const item = this.items[value];
        if (item) {
          this.activeIndex = item.index;
          this.initOpenedMenu();
        } else {
          this.activeIndex = "";
        }
      });
    },
    menuDefaultOpeneds: function(value) {
      this.expandCustom(value);
    },
    isExpandAll: function(v) {
      this.openedMenus = [];
      if (!v) {
        return;
      }
      this.initOpenedMenu();
    },
    activeIndex: function(v) {
      let query;
      if (this.pathName && this.APP_ROOT && this.APP_ROOT.$router) {
        query = Object.assign({}, this.APP_ROOT.$route.query);
        query[this.pathName] = v;
        this.APP_ROOT.$router.push({
          query
        });
      }
    },
    menuOptions(newMenuOption) {
      if (!this.hasInitMenu && newMenuOption.length) {
        this.$nextTick(() => {
          this.initOpenedMenu();
          this.hasInitMenu = true;
        });
      }
    },
    isExpanded(value) {
      this.$nextTick(() => {
        this.$emit("on-expand-change", value);
      });
    }
  },
  mounted: function() {
    this.initOpenedMenu();
    this.$on("click.item", this.handleClickItem);
    this.$on("click.submenu", this.handleClickSubmenu);
    this.$on("expand.all", this.expandAllMennu);
    this.$on("collapse.all", this.collapseAllMenu);
    this.$on("expand.custom", this.expandCustom);
    this.$on("collapse.custom", this.collapseCustom);
    this.$nextTick(() => {
      if (this.autoActivePanel) {
        this.activePanel();
      }
      this.updateContentHeight();
    });
    this.dispatch([componentName.navWrap, componentName.pageNavWrap], "nav-menu-mounted", [this]);
  },
  beforeDestroy: function() {
    if (this.__routerAfterEachDestroy) {
      this.__routerAfterEachDestroy();
    }
  },
  methods: {
    getFullUtid(utidBase) {
      return this.$attrs.utid ? `${this.$attrs.utid}-${utidBase}` : utidBase;
    },
    toggleMenuStatus() {
      this.isExpanded = !this.isExpanded;
    },
    updateContentHeight() {
      let height = "";
      if (this.isTitleShow) {
        height = this.$refs.title.getHeight() + "px";
      }
      this.bodyStyle = {
        height: height ? `calc(100% - ${height})` : "100%"
      };
    },
    addItem: function(item) {
      this.$set(this.items, item.index, item);
    },
    removeItem: function(item) {
      delete this.items[item.index];
    },
    addSubMenu: function(submenu) {
      this.$set(this.subMenus, submenu.index, submenu);
    },
    removeSubMenu: function(submenu) {
      delete this.subMenus[submenu.index];
    },
    expandAllMennu: function() {
      let submenu, submenuIndex;
      for (submenuIndex in this.subMenus) {
        if (!this.subMenus.hasOwnProperty(submenuIndex)) {
          continue;
        }
        if (this.openedMenus.indexOf(submenuIndex) === -1) {
          submenu = this.subMenus[submenuIndex];
          this.openMenu(submenuIndex, submenu.indexPath);
        }
      }
    },
    isIndexInItem: function(index) {
      let isValid = false;
      Object.keys(this.items).forEach(function(itemIndex) {
        if (itemIndex === index) {
          isValid = true;
          return false;
        }
      });
      return isValid;
    },
    isIndexInSubmenu: function(index) {
      let isValid = false;
      Object.keys(this.subMenus).forEach(function(submenuIndex) {
        if (submenuIndex === index) {
          isValid = true;
          return false;
        }
      });
      return isValid;
    },
    expandToItem: function(index) {
      const getItemParent = () => {
        return this.items[index].$parent;
      }, indexPath = getItemParent().indexPath, activeIndex = index;
      indexPath.forEach((index2) => {
        if (this.openedMenus.indexOf(index2) === -1) {
          this.openMenu(index2, indexPath);
        }
      });
      if (!this.activeIndex) {
        this.activeIndex = activeIndex;
      }
    },
    expandToSubMenu: function(index) {
      if (!this.subMenus[index]) {
        return;
      }
      const indexPath = this.subMenus[index].indexPath;
      indexPath.forEach((indexItem) => {
        if (this.openedMenus.indexOf(indexItem) === -1) {
          this.openedMenus.push(indexItem);
        }
      });
    },
    expandCustom: function(indexs) {
      let indexInSubmenu = false, indexInItem = false;
      if (!Array.isArray(indexs)) {
        indexs = indexs ? indexs.split(",") : [];
      }
      indexs.forEach((index) => {
        indexInItem = this.isIndexInItem(index);
        indexInSubmenu = this.isIndexInSubmenu(index);
        if (!indexInItem && !indexInSubmenu) {
          throw new Error("the menu has no such index");
        }
        if (indexInItem) {
          this.expandToItem(index);
        }
        if (indexInSubmenu) {
          this.expandToSubMenu(index);
        }
      });
    },
    collapseAllMenu: function() {
      this.openedMenus = [];
    },
    collapseToItem: function(index) {
      this.openedMenus.forEach((path) => {
        if (path.indexOf(index)) {
          this.closeMenu(path);
        }
      });
    },
    collapseCustom: function(indexs) {
      let indexInSubmenu = false, indexInItem = false;
      if (!Array.isArray(indexs)) {
        indexs = indexs ? [indexs] : [];
      }
      indexs.forEach((index) => {
        indexInItem = this.isIndexInItem(index);
        indexInSubmenu = this.isIndexInSubmenu(index);
        if (!indexInItem && !indexInSubmenu) {
          throw new Error("the menu has no such index");
        }
        this.openedMenus.forEach((path) => {
          if (path.indexOf(index) !== -1) {
            this.closeMenu(path);
          }
        });
      });
    },
    openMenu: function(index, indexPath) {
      const openedMenus = this.openedMenus;
      if (openedMenus.indexOf(index) !== -1) {
        return;
      }
      if (this.isUniqueOpened) {
        this.openedMenus = openedMenus.filter(function(index2) {
          return indexPath.indexOf(index2) !== -1;
        });
      }
      this.openedMenus.push(index);
    },
    closeMenu: function(index) {
      this.openedMenus.splice(this.openedMenus.indexOf(index), 1);
    },
    getItemKeys: function() {
      return Object.keys(this.items);
    },
    getFirstEnableItem: function() {
      let firstEnableitem = {};
      $.each(this.items, function(key, item) {
        if (!item.isDisabled) {
          firstEnableitem = item;
          return false;
        }
      });
      return firstEnableitem;
    },
    autoEmitEvent(newItem, oldItem) {
      const ctx = this.$vnode.context;
      if (!ctx) {
        return;
      }
      if (newItem.index) {
        const comp = $.makeArray(ctx.$refs[newItem.index])[0];
        if (comp && comp.$emit) {
          comp.$emit("show");
        }
      }
      if (oldItem.index) {
        const comp = $.makeArray(ctx.$refs[oldItem.index])[0];
        if (comp && comp.$emit) {
          comp.$emit("hide");
        }
      }
    },
    handleClickItem: function(e, item) {
      const vm = this;
      when(vm._fixBefore(vm.before)).then(function(result) {
        if (result === false) {
          return;
        }
        let oldItem = vm.items[vm.activeIndex];
        if (vm.firstActive) {
          vm.firstActive = false;
          oldItem = {};
        }
        vm.activeIndex = item.index;
        vm.$emit("clickitem", e, item, oldItem);
        vm.dispatch([componentName.navWrap, componentName.pageNavWrap], "clickitem", [e, item]);
        if (vm.emitEvent) {
          vm.autoEmitEvent(item, oldItem);
        }
      });
    },
    _fixBefore: function(value) {
      return typeof value === "boolean" ? value : value();
    },
    handleClickSubmenu: function(submenu) {
      const index = submenu.index;
      const indexPath = submenu.indexPath;
      const isOpened = this.openedMenus.indexOf(index) !== -1;
      if (isOpened) {
        this.closeMenu(index);
        this.$emit("close", index, indexPath);
      } else {
        this.openMenu(index, indexPath);
        this.$emit("open", index, indexPath);
      }
    },
    selectFirstSubmenuItem(index) {
      if (!this.subMenus[index]) {
        return;
      }
      const firstItem = this.subMenus[index].$children.filter((item) => !item.isDisabled)[0];
      firstItem == null ? void 0 : firstItem.onClick();
    },
    initOpenedMenu: function() {
      const firstEnableItem = this.getFirstEnableItem();
      let index = this.defaultActive || firstEnableItem.index;
      const defaultOpenmenus = this.menuDefaultOpeneds;
      const activeItem = this.items[index] || firstEnableItem;
      if (this.APP_ROOT && this.APP_ROOT.$route && this.pathName) {
        index = this.APP_ROOT.$route.query[this.pathName] || index;
      }
      this.activeIndex = index;
      if (this.isExpandAll) {
        this.expandAllMennu();
        return;
      }
      this.expandCustom(defaultOpenmenus);
      const indexPath = activeItem.indexPath || [];
      indexPath.forEach((index2) => {
        const submenu = this.subMenus[index2];
        submenu && this.openMenu(index2, indexPath);
      });
      if (!this.pathName || !(this.APP_ROOT && this.APP_ROOT.$router)) {
        return;
      }
      this.__routerAfterEachDestroy = this.APP_ROOT.$router.afterEach((to) => {
        const v = to.query[this.pathName] || index;
        if (this.activeIndex !== v) {
          this.activeIndex = v;
          this.$nextTick(() => this.activePanel());
        }
      });
    },
    activePanel() {
      if (!this.navWrap) {
        logger.warn("can not find navWrap");
        return;
      }
      let item = this.items[this.activeIndex];
      if (!item) {
        logger.warn("can not find activeIndex: ", this.activeIndex);
        const firstIndex = Object.keys(this.items)[0];
        item = this.items[firstIndex];
      }
      this.$emit("click.item", null, item);
    },
    getPrefixedClassName
  }
};
const __vue_script__$3 = script$3;
var __vue_render__$3 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    { ref: "navMenu", class: _vm.navMenuCls },
    [
      _c(
        "div",
        {
          directives: [
            {
              name: "show",
              rawName: "v-show",
              value: _vm.showExpandIcon,
              expression: "showExpandIcon"
            }
          ],
          class: _vm.getPrefixedClassName("sf-nav-menu_slider-wrap"),
          attrs: { utid: _vm.getFullUtid("nav-menu-expand") },
          on: { click: _vm.toggleMenuStatus }
        },
        [_c("i", { class: _vm.toggleIconCls })]
      ),
      _vm._v(" "),
      _c("sf-nav-menu-title", {
        directives: [
          {
            name: "show",
            rawName: "v-show",
            value: _vm.isExpanded && _vm.isTitleShow && _vm.title,
            expression: "isExpanded && isTitleShow && title"
          }
        ],
        ref: "title",
        attrs: {
          "title-icon": _vm.titleIcon,
          "title-icon-image": _vm.titleIconImage,
          title: _vm.title,
          "data-tip": _vm.title
        }
      }),
      _vm._v(" "),
      _c(
        "div",
        {
          directives: [
            {
              name: "show",
              rawName: "v-show",
              value: _vm.isExpanded,
              expression: "isExpanded"
            }
          ],
          class: _vm.getPrefixedClassName("sf-nav-menu_content-body"),
          style: _vm.bodyStyle
        },
        [
          _c("sf-scrollbar", [
            _c(
              "div",
              { class: _vm.getPrefixedClassName("sf-nav-menu_real_width") },
              [
                _vm.menuOptions.length ? _c(
                  "ul",
                  {
                    class: _vm.getPrefixedClassName("sf-nav-menu_content")
                  },
                  [
                    _vm._l(_vm.menuOptions, function(item) {
                      return [
                        !item.child ? _c(
                          "sf-nav-menu-item",
                          {
                            key: item.index,
                            attrs: {
                              "show-dot": _vm.showDot,
                              index: item.index,
                              icon: item.icon,
                              image: item.image,
                              disabled: item.disabled,
                              "data-tip": item.dataHint,
                              "icon-collapse-mode": _vm.iconCollapseMode,
                              data: item,
                              "hide-tip": item.hideTip,
                              utid: _vm.getFullUtid(item.index)
                            },
                            on: { click: _vm.onClickFn }
                          },
                          [
                            _vm._v(
                              "\n              " + _vm._s(item.contentText) + "\n            "
                            )
                          ]
                        ) : _vm._e(),
                        _vm._v(" "),
                        item.child && item.child.length ? _c(
                          "sf-nav-sub-menu",
                          {
                            key: item.index,
                            attrs: {
                              index: item.index,
                              icon: item.icon,
                              "icon-collapse-mode": _vm.iconCollapseMode,
                              options: item.child,
                              "disable-toggle": item.disableToggle,
                              utid: _vm.getFullUtid("nav-sub-menu")
                            }
                          },
                          [
                            _c(
                              "span",
                              {
                                attrs: { slot: "title" },
                                slot: "title"
                              },
                              [_vm._v(_vm._s(item.title))]
                            )
                          ]
                        ) : _vm._e()
                      ];
                    })
                  ],
                  2
                ) : _c(
                  "ul",
                  {
                    class: _vm.getPrefixedClassName("sf-nav-menu_content")
                  },
                  [_vm._t("default")],
                  2
                )
              ]
            )
          ])
        ],
        1
      )
    ],
    1
  );
};
var __vue_staticRenderFns__$3 = [];
__vue_render__$3._withStripped = true;
const __vue_inject_styles__$3 = void 0;
const __vue_scope_id__$3 = void 0;
const __vue_module_identifier__$3 = void 0;
const __vue_is_functional_template__$3 = false;
const __vue_component__$3 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$3, staticRenderFns: __vue_staticRenderFns__$3 },
  __vue_inject_styles__$3,
  __vue_script__$3,
  __vue_scope_id__$3,
  __vue_is_functional_template__$3,
  __vue_module_identifier__$3,
  false,
  void 0,
  void 0,
  void 0
);
var script$2 = {
  name: componentName.navMenuPanel,
  componentName: componentName.navMenuPanel,
  props: {
    forMenu: {
      type: String,
      required: true,
      default: ""
    }
  },
  data() {
    return {
      isActive: false
    };
  },
  watch: {
    isActive(v) {
      if (v) {
        this.$nextTick(() => this.$emit("show", this.forMenu));
      } else {
        this.$emit("hide", this.forMenu);
      }
    }
  },
  created() {
    const navComponent = getVueParent(this, [componentName.navWrap, componentName.pageNavWrap]);
    if (navComponent) {
      navComponent.$on("clickitem", (e, menuItem) => {
        this.isActive = menuItem.index === this.forMenu;
      });
    }
  },
  methods: {
    getPrefixedClassName
  }
};
const __vue_script__$2 = script$2;
var __vue_render__$2 = function() {
  var _obj;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      directives: [
        {
          name: "show",
          rawName: "v-show",
          value: _vm.isActive,
          expression: "isActive"
        }
      ],
      class: [
        _vm.getPrefixedClassName("sf-nav-menu-panel"),
        (_obj = {}, _obj[_vm.getPrefixedClassName("isActive")] = _vm.isActive, _obj)
      ],
      attrs: { "data-index": _vm.forMenu }
    },
    [_vm._t("default")],
    2
  );
};
var __vue_staticRenderFns__$2 = [];
__vue_render__$2._withStripped = true;
const __vue_inject_styles__$2 = void 0;
const __vue_scope_id__$2 = void 0;
const __vue_module_identifier__$2 = void 0;
const __vue_is_functional_template__$2 = false;
const __vue_component__$2 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$2, staticRenderFns: __vue_staticRenderFns__$2 },
  __vue_inject_styles__$2,
  __vue_script__$2,
  __vue_scope_id__$2,
  __vue_is_functional_template__$2,
  __vue_module_identifier__$2,
  false,
  void 0,
  void 0,
  void 0
);
var script$1 = {
  name: componentName.navMenuPanelWrap,
  componentName: componentName.navMenuPanelWrap,
  components: {
    SfFlexItem
  },
  computed: {
    activeIndex: function() {
      let ret = "";
      if (this.navWrap) {
        ret = this.navWrap.activeItem.index;
      }
      return ret;
    },
    navWrap() {
      let parent = this.$parent;
      let depth = 0;
      const limit = 10;
      while (parent && parent.$options.componentName !== componentName.pageNavWrap && parent.$options.componentName !== componentName.navWrap && depth < limit) {
        parent = parent.$parent;
        depth++;
      }
      return parent;
    }
  },
  methods: {
    getPrefixedClassName
  }
};
const __vue_script__$1 = script$1;
var __vue_render__$1 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "sf-flex-item",
    {
      ref: "navMenuPanelWrap",
      class: _vm.getPrefixedClassName("sf-nav-menu-panel-wrap"),
      attrs: { "active-index": _vm.activeIndex }
    },
    [_vm._t("default")],
    2
  );
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
var NavWrap = {
  name: componentName.navWrap,
  componentName: componentName.navWrap,
  data: function() {
    return {
      activeItem: {}
    };
  },
  render: function(createElem) {
    return createElem(
      SfFlex,
      {
        class: ["sf-nav-wrap"],
        ref: "NavWrap"
      },
      this.$slots.default
    );
  },
  created: function() {
    this.$on("clickitem", this.handleClickItem);
  },
  methods: {
    handleClickItem(e, menuItem) {
      this.activeItem = menuItem;
    }
  }
};
var script = {
  name: componentName.pageNavWrap,
  componentName: componentName.pageNavWrap,
  components: {
    SfFlex
  },
  extends: NavWrap,
  data: function() {
    return {
      activeItem: {}
    };
  },
  created: function() {
    this.$on("clickitem", this.handleClickItem);
  },
  methods: {
    handleClickItem: function(e, menuItem) {
      this.activeItem = menuItem;
    },
    getPrefixedClassName
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "sf-flex",
    { ref: "NavWrap", class: [_vm.getPrefixedClassName("sf-page-nav-wrap")] },
    [_vm._t("default")],
    2
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__$3 as SfNavMenu, __vue_component__$6 as SfNavMenuItem, __vue_component__$2 as SfNavMenuPanel, __vue_component__$1 as SfNavMenuPanelWrap, __vue_component__$5 as SfNavSubMenu, NavWrap as SfNavWrap, __vue_component__ as SfPageNavWrap };
