interface SfMenuMixinClickItem {
  /**
   * 点击某一项
   */
  clickItem(): void;
}

export type SfMenuMixin = Readonly<SfMenuMixinClickItem> & Vue;
