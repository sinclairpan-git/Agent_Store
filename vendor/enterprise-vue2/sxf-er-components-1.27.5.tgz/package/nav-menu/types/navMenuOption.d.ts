import type { SfNavMenuItem } from './navMenuItem';
export interface SfNavMenuOption {
  index: string;
  title?: string;
  disabled?: boolean;
  contentText?: string;
  click?: (e: MouseEvent, menu: SfNavMenuItem) => void;
  child?: SfNavMenuOption[];
}
