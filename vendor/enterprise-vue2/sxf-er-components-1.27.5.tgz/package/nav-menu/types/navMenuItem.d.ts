import type { SfMenuMixin } from './menuMixin';
import type { SfNavMenuOption } from './navMenuOption';
import type { VNode } from 'vue';

export interface SfNavMenuItemProps {
  /**
   * 唯一确定叶子节点的标识
   */
  index: string;

  /**
   * 是否隐藏提示
   *
   * @default false
   */
  hideTip?: boolean;

  /**
   * 叶子节点的图标
   */
  icon?: string;

  /**
   * 叶子节点的图标可以是图片，和icon选一个配就可以了
   */
  image?: string;

  /**
   * 叶子节点是否可用
   */
  disabled?: boolean;

  /**
   * 叶子上图标的悬浮提示
   *
   * @default ''
   */
  dataHint?: string;

  /**
   * menu动态配置时，叶子的数据
   */
  data?: SfNavMenuOption;

  /**
   * 是否显示菜单项前面那个圆点
   *
   * @default false
   */
  showDot?: boolean;
}

export interface SfNavMenuItemEvents {
  /**
   * 点击菜单项
   *
   * @param event 事件
   * @param args 自身实例
   */
  $emit(eventName: 'click', event: MouseEvent, menu: SfNavMenuItem): this;
}

export interface SfNavMenuItemSlots {
  $slots: {
    default?: VNode[];
  };
}

export interface SfNavMenuItemMethods {
  onClick: (event: MouseEvent) => void;
}

export declare type SfNavMenuItem = Readonly<SfNavMenuItemProps & SfNavMenuItemSlots & SfNavMenuItemMethods> &
  Vue &
  SfMenuMixin;
