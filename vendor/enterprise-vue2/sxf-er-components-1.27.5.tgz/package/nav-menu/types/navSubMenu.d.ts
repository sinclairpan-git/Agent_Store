import type { SfNavMenuItem } from './navMenuItem';
import type { SfNavMenuOption } from './navMenuOption';
import type { VNode } from 'vue';

export interface SfNavSubMenuProps {
  /**
   * 动态配置menu项，如nav-menu中options的child
   *
   * @default []
   */
  options: SfNavMenuOption[];

  /**
   * 唯一确定叶子节点的标识
   */
  index: string;

  /**
   * 展开图标
   *
   * @default 'expand'
   */
  openedIcon: string;

  /**
   * 关闭图标
   *
   * @default ‘unexpand’
   */
  closedIcon: string;

  /**
   * 禁用title的点击，隐藏展开/收缩按钮
   *
   * @default false
   */
  disableToggle: boolean;
}

export interface SfNavSubMenuSlots {
  $slots: {
    default?: VNode[];
    title?: VNode[];
  };
}

export interface SfNavSubMenuMethods {
  /**
   * 将菜单节点放进去
   *
   * @param item 菜单实例
   */
  addItem(item: SfNavMenuItem): void;

  /**
   * 移除
   *
   * @param item 菜单实例
   */
  removeItem(item: SfNavMenuItem): void;

  /**
   * 新增有子标题的项
   *
   * @param subMenu 带标题的项
   */
  addSubMenu(subMenu: SfNavSubMenu): void;

  /**
   * 移除
   *
   * @param subMenu 带标题的项
   */
  removeSubMenu(subMenu: SfNavSubMenu): void;
}

export type SfNavSubMenu = Readonly<SfNavSubMenuProps & SfNavSubMenuSlots & SfNavSubMenuMethods>;
