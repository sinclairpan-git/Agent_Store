import type { SfNavMenuItem } from './navMenuItem';
import type { SfNavMenuOption } from './navMenuOption';
import type { SfNavSubMenu } from './navSubMenu';
import type { VNode } from 'vue';

export interface SfNavMenuProps {
  options: SfNavMenuOption[];
  title: string;
  titleUrl: string;
  showExpandIcon: boolean;
  titleShow: boolean;
  titleIcon: boolean;
  titleIconImage: string;
  defaultActive: string;
  defaultOpeneds: string | string[];
  uniqueOpened: boolean;
  expandAll: boolean;
  pathName: string;
  activeIndex: string;
  autoActivePanel: boolean;
  hidden: boolean;
  before: () => JQuery.Promise<any> | boolean;
  showDot: boolean;
}

export interface SfNavMenuSlots {
  $slots: {
    default?: VNode[];
    title?: VNode[];
  };
}

export interface SfNavMenuEvents {
  $emit(eventName: 'clickitem', e: MouseEvent, newItem: SfNavMenuItem, oldItem: SfNavMenuItem): this;
  $emit(eventName: 'close', index: string, indexPath: string[]): this;
  $emit(eventName: 'open', index: string, indexPath: string[]): this;
  $emit(eventName: 'click.item', e: MouseEvent, item: SfNavMenuItem): this;
}

export interface SfNavMenuMethods {
  toggleMenuStatus: () => void;
  updateContentHeight: () => void;
  updateItemWidth: () => void;
  addItem: (item: SfNavMenuItem) => void;
  removeItem: (item: SfNavMenuItem) => void;
  addSubMenu: (item: SfNavSubMenu) => void;
  removeSubMenu: (item: SfNavSubMenu) => void;
  expandAllMennu: () => void;
  isIndexInItem: (index: string) => boolean;
  isIndexInSubmenu: (index: string) => boolean;
  expandToItem: (index: string) => void;
  expandToSubMenu: (index: string) => void;
  expandCustom: (indexs: string[] | string) => void;
  collapseAllMenu: () => void;
  collapseToItem: (index: string) => void;
  collapseCustom: (indexs: string[] | string) => void;
  openMenu: (index: string, indexPath: string[]) => void;
  closeMenu: (index: string) => void;
  getItemKeys: () => string[];
  getFirstEnableItem: () => SfNavMenuItem;
  activePanel: () => void;
}

export declare type SfNavMenu = Readonly<SfNavMenuProps & SfNavMenuSlots & SfNavMenuMethods> & Vue;
