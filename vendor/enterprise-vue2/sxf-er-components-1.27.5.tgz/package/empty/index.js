import { componentName } from '@sxf/er-components/_const';
import { $i } from '@sxf/er-config';
import { getPrefixedClassName } from '@sxf/er-feature';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
var script = {
  name: componentName.empty,
  componentName: componentName.empty,
  props: {
    icon: {
      type: String,
      default: "empty"
    },
    title: {
      type: String,
      default: ""
    },
    description: {
      type: String,
      default: ""
    },
    tip: {
      type: String,
      default: () => $i("scp.vt_component.sf_widget.packages.empty.empty_tip")
    },
    image: {
      type: String,
      default: ""
    }
  },
  computed: {
    iconCls() {
      return "vtv-icon-" + this.icon;
    }
  },
  methods: {
    getPrefixedClassName
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c("div", { class: _vm.getPrefixedClassName("sf-empty") }, [
    _c(
      "div",
      { class: _vm.getPrefixedClassName("sf-empty__image") },
      [
        _vm._t("image", [
          _vm.image ? _c("img", { attrs: { src: _vm.image, alt: _vm.description } }) : _c("i", {
            class: [
              "iconfont",
              _vm.iconCls,
              _vm.getPrefixedClassName("sf-empty__icon")
            ]
          })
        ])
      ],
      2
    ),
    _vm._v(" "),
    _vm.title ? _c("div", { class: _vm.getPrefixedClassName("sf-empty__title") }, [
      _vm._v("\n    " + _vm._s(_vm.title) + "\n  ")
    ]) : _vm._e(),
    _vm._v(" "),
    _vm.description ? _c(
      "div",
      { class: _vm.getPrefixedClassName("sf-empty__description") },
      [_vm._v("\n    " + _vm._s(_vm.description) + "\n  ")]
    ) : _vm._e(),
    _vm._v(" "),
    !_vm.title && !_vm.description ? _c(
      "div",
      { class: _vm.getPrefixedClassName("sf-empty__tip") },
      [_vm._t("tip", [_vm._v(_vm._s(_vm.tip))])],
      2
    ) : _vm._e(),
    _vm._v(" "),
    _vm.$slots.footer ? _c(
      "div",
      { class: _vm.getPrefixedClassName("sf-empty__footer") },
      [_vm._t("footer")],
      2
    ) : _vm._e()
  ]);
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
var EmptyWrap = {
  name: componentName.emptyWrap,
  componentName: componentName.emptyWrap,
  props: __vue_component__.props,
  render(createElem) {
    const children = [
      createElem(__vue_component__, {
        props: this.$props
      })
    ];
    return createElem(
      "div",
      {
        class: getPrefixedClassName(`sf-empty-wrap`)
      },
      this.$slots.default ? [this.$slots.default] : children
    );
  }
};
export { __vue_component__ as SfEmpty, EmptyWrap as SfEmptyWrap };
