import { componentName } from '@sxf/er-components/_const';
import { SfFlex, SfFlexItem } from '@sxf/er-components/flex';
import { SfTitle } from '@sxf/er-components/title';
import { getPrefixedClassName } from '@sxf/er-feature';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
var script$1 = {
  name: componentName.card,
  componentName: componentName.card,
  props: {
    shadow: {
      type: String,
      default: "",
      validator: (type) => ["always", "hover", ""].includes(type)
    },
    border: {
      type: Boolean,
      default: false
    },
    padding: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    cls() {
      return [
        getPrefixedClassName("sf-card"),
        this.shadow ? getPrefixedClassName("is-" + this.shadow + "-shadow") : "",
        this.border ? getPrefixedClassName("sf-card--border") : "",
        this.padding ? getPrefixedClassName("sf-card--padding") : ""
      ];
    }
  },
  methods: {
    getPrefixedClassName
  }
};
const __vue_script__$1 = script$1;
var __vue_render__$1 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c("div", { class: _vm.cls }, [_vm._t("default")], 2);
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
var script = {
  name: componentName.block,
  componentName: componentName.block,
  components: { SfCard: __vue_component__$1, SfFlex, SfFlexItem, SfTitle },
  props: {
    mode: {
      type: String,
      default: "shadow",
      validator: (val) => ["shadow", "border", "none"].includes(val)
    },
    title: {
      type: String
    },
    autoOverflow: {
      type: Boolean,
      default: false
    },
    contentBorder: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    containerCls() {
      return [
        getPrefixedClassName("sf-block"),
        getPrefixedClassName(`sf-block--mode-${this.mode}`),
        this.title || this.$slots.title ? "" : getPrefixedClassName("sf-block--padding-top")
      ];
    },
    cardProps() {
      if (this.mode === "shadow") {
        return {
          shadow: "always"
        };
      }
      if (this.mode === "border") {
        return {
          border: true
        };
      }
      return {};
    },
    contentCls() {
      return {
        [getPrefixedClassName("sf-block-content-wrap--overflow")]: this.autoOverflow,
        [getPrefixedClassName("sf-block-content-wrap--border")]: this.contentBorder
      };
    },
    footerCls() {
      return {
        [getPrefixedClassName("sf-block-footer")]: true,
        [getPrefixedClassName("sf-block-footer--margin")]: this.contentBorder
      };
    }
  },
  methods: {
    getPrefixedClassName
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "sf-card",
    _vm._b({ class: _vm.containerCls }, "sf-card", _vm.cardProps, false),
    [
      _c(
        "sf-flex",
        {
          class: _vm.getPrefixedClassName("sf-block-flex-wrap"),
          attrs: { "flex-direction": "column" }
        },
        [
          _vm.title || _vm.$slots.title ? _c("sf-flex-item", { attrs: { flex: "none" } }, [
            _c(
              "div",
              { class: _vm.getPrefixedClassName("sf-block-title") },
              [
                _vm._t("title", [
                  _c("sf-title", { attrs: { title: _vm.title } })
                ])
              ],
              2
            )
          ]) : _vm._e(),
          _vm._v(" "),
          _c(
            "sf-flex-item",
            { class: _vm.contentCls, attrs: { flex: "1 1 auto" } },
            [
              _c(
                "div",
                { class: _vm.getPrefixedClassName("sf-block-content") },
                [_vm._t("default")],
                2
              )
            ]
          ),
          _vm._v(" "),
          _vm.$slots.footer ? _c("sf-flex-item", { attrs: { flex: "none" } }, [
            _c("div", { class: _vm.footerCls }, [_vm._t("footer")], 2)
          ]) : _vm._e()
        ],
        1
      )
    ],
    1
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__ as SfBlock, __vue_component__$1 as SfCard };
