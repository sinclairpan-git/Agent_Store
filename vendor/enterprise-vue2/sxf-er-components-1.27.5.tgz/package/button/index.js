import { componentName } from '@sxf/er-components/_const';
import { MgrClientMixin, MenuTargetMixin } from '@sxf/er-components/_mixins';
import { isPropEnabled, getVueParent } from '@sxf/er-components/_utils/vue-utils';
import { getPrefixedClassName } from '@sxf/er-feature';
import { throttle } from '@sxf/er-utils/delay';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
const staticSafariVersion = "18.1";
function checkSafariVersion() {
  const userAgent = navigator.userAgent;
  const isSafari = /^((?!chrome|android).)*safari/i.test(userAgent);
  if (isSafari) {
    const versionMatch = userAgent.match(/version\/(\d+(\.\d+)?)/i);
    const version = versionMatch ? versionMatch[1] : "0.0";
    return version.includes(staticSafariVersion);
  }
  return false;
}
const CLICK_WAIT = 300;
var script = {
  name: componentName.button,
  componentName: componentName.button,
  mixins: [MgrClientMixin, MenuTargetMixin],
  inject: {
    toolbarDisabled: {
      default: false
    }
  },
  model: {
    prop: "disabled",
    event: "change"
  },
  props: {
    type: {
      type: String,
      default: "normal"
    },
    size: String,
    icon: {
      type: String,
      default: ""
    },
    iconRight: {
      type: String,
      default: ""
    },
    nativeType: {
      type: String,
      default: "button"
    },
    disabled: true,
    loading: Boolean,
    tip: String,
    href: {
      type: String,
      default: ""
    },
    target: {
      type: String,
      default: "_blank",
      validator: (v) => {
        return ["_blank", "_self", "_top", "_parent"].includes(v);
      }
    }
  },
  data() {
    return {
      showTip: false,
      buttonTip: "",
      isSafari: false
    };
  },
  computed: {
    iconRightValue() {
      if (this.iconRight) {
        return this.iconRight;
      }
      if (this.menuRef && !this.isLinkType) {
        return this.menuShow ? "comp-angle-up" : "comp-angle-down";
      }
      return "";
    },
    hasIconRight() {
      return this.iconRightValue !== "";
    },
    isDisabled() {
      return isPropEnabled(this.disabled) || this.toolbarDisabled || this.externalDisabled;
    },
    isLinkType() {
      return this.type === "link" || this.type === "plain-link";
    },
    componentType() {
      return this.isLinkType ? "a" : "button";
    }
  },
  watch: {
    isDisabled(value) {
      this.$emit("change", value);
    }
  },
  created() {
    this.handleClick = throttle(this.__click, CLICK_WAIT, {
      trailing: false
    });
  },
  mounted() {
    this.isSafari = checkSafariVersion();
    if (this.isLinkType) {
      const formComponent = getVueParent(this, "SfForm");
      const formItemComponent = getVueParent(this, "SfFormItem");
      if ((formItemComponent == null ? void 0 : formItemComponent.mode) === "detail" || (formComponent == null ? void 0 : formComponent.mode) === "detail") {
        this.showTip = true;
        this.__setLinkButtonTip();
      }
    }
  },
  beforeUpdate() {
    this.__setLinkButtonTip();
  },
  methods: {
    getPrefixedClassName,
    __click(evt) {
      if (this.loading) {
        return;
      }
      if (!this.isDisabled) {
        this.$el.blur();
        if (this.href) {
          const newWin = window.open("", this.target);
          newWin.opener = null;
          newWin.location = this.href;
          return;
        }
        this.$emit("click", evt);
      }
    },
    handleInnerClick(evt) {
      if (this.isDisabled) {
        evt.stopPropagation();
      }
      if (this.isSafari && !this.isDisabled) {
        evt.stopPropagation();
        this.$el.click();
      }
    },
    handleRightClick(evt) {
      if (this.isDisabled) {
        evt.stopPropagation();
        return;
      }
      this.$emit("click-right");
    },
    toggleEnable(enabled) {
      this.externalDisabled = !enabled;
    },
    onToggleState(enabled) {
      this.toggleEnable(enabled);
    },
    __setLinkButtonTip() {
      var _a, _b;
      if (!this.showTip) {
        return;
      }
      const text = String(((_b = (_a = this.$slots.default) == null ? void 0 : _a[0]) == null ? void 0 : _b.text) || "").trim();
      if (text !== this.buttonTip) {
        this.buttonTip = text;
      }
    }
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _obj;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    _vm.componentType,
    {
      tag: "component",
      class: [
        _vm.getPrefixedClassName("el-button"),
        _vm.getPrefixedClassName(_vm.type ? "el-button--" + _vm.type : ""),
        _vm.getPrefixedClassName(_vm.size ? "el-button--" + _vm.size : ""),
        (_obj = {}, _obj[_vm.getPrefixedClassName("is-disabled")] = _vm.isDisabled, _obj[_vm.getPrefixedClassName("is-loading")] = _vm.loading, _obj[_vm.getPrefixedClassName("has-icon-right")] = _vm.hasIconRight, _obj[_vm.getPrefixedClassName("el-button_align-left")] = _vm.icon, _obj)
      ],
      attrs: {
        type: _vm.nativeType,
        "data-hint": _vm.isDisabled && _vm.tip ? _vm.tip : false
      },
      on: { click: _vm.handleClick }
    },
    [
      _vm.icon || _vm.loading ? _c(
        "span",
        {
          class: [
            _vm.getPrefixedClassName("sf-button_left-icon"),
            _vm.getPrefixedClassName("sf-button_span")
          ]
        },
        [
          _vm.loading ? _c("i", {
            staticClass: "iconfont vtv-icon-refresh",
            on: { click: _vm.handleInnerClick }
          }) : _vm._e(),
          _vm._v(" "),
          _vm.icon && !_vm.loading ? _c("i", {
            staticClass: "iconfont",
            class: "vtv-icon-" + _vm.icon,
            on: { click: _vm.handleInnerClick }
          }) : _vm._e()
        ]
      ) : _vm._e(),
      _vm._v(" "),
      _vm.$slots.default ? _c(
        "span",
        {
          class: [
            _vm.getPrefixedClassName("sf-button_span"),
            _vm.getPrefixedClassName("sf-button__content")
          ],
          attrs: { "data-tip": _vm.buttonTip },
          on: { click: _vm.handleInnerClick }
        },
        [_vm._t("default")],
        2
      ) : _vm._e(),
      _vm._v(" "),
      _vm.hasIconRight ? _c(
        "span",
        { class: _vm.getPrefixedClassName("sf-button_right-icon") },
        [
          _c("i", {
            staticClass: "iconfont",
            class: "vtv-icon-" + _vm.iconRightValue,
            on: { click: _vm.handleRightClick }
          })
        ]
      ) : _vm._e()
    ]
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__ as SfButton };
