import { componentName } from '@sxf/er-components/_const';
import { getPrefixedClassName } from '@sxf/er-feature';
var Col = {
  name: componentName.col,
  componentName: componentName.col,
  props: {
    span: {
      type: Number,
      default: 24
    },
    tag: {
      type: String,
      default: "div"
    },
    offset: Number,
    pull: Number,
    push: Number,
    xs: [Number, Object],
    sm: [Number, Object],
    md: [Number, Object],
    lg: [Number, Object]
  },
  computed: {
    gutter() {
      let parent = this.$parent;
      while (parent && parent.$options.componentName !== componentName.row) {
        parent = parent.$parent;
      }
      return parent ? parent.gutter : 0;
    }
  },
  render(h) {
    const classList = [];
    const style = {};
    if (this.gutter) {
      style.paddingLeft = this.gutter / 2 + "px";
      style.paddingRight = style.paddingLeft;
    }
    ["span", "offset", "pull", "push"].forEach((prop) => {
      if (this[prop]) {
        classList.push(getPrefixedClassName(prop !== "span" ? `el-col-${prop}-${this[prop]}` : `el-col-${this[prop]}`));
      }
    });
    ["xs", "sm", "md", "lg"].forEach((size) => {
      if (typeof this[size] === "number") {
        classList.push(getPrefixedClassName(`el-col-${size}-${this[size]}`));
      } else if (typeof this[size] === "object") {
        const props = this[size];
        Object.keys(props).forEach((prop) => {
          classList.push(
            getPrefixedClassName(
              prop !== "span" ? `el-col-${size}-${prop}-${props[prop]}` : `el-col-${size}-${props[prop]}`
            )
          );
        });
      }
    });
    return h(
      this.tag,
      {
        class: [getPrefixedClassName("el-col"), classList],
        style
      },
      this.$slots.default
    );
  }
};
var Row = {
  name: componentName.row,
  componentName: componentName.row,
  props: {
    tag: {
      type: String,
      default: "div"
    },
    gutter: Number,
    type: String,
    justify: {
      type: String,
      default: "start"
    },
    align: {
      type: String,
      default: "top"
    }
  },
  computed: {
    style() {
      const ret = {};
      if (this.gutter) {
        ret.marginLeft = `-${this.gutter / 2}px`;
        ret.marginRight = ret.marginLeft;
      }
      return ret;
    }
  },
  render(h) {
    return h(
      this.tag,
      {
        class: [
          getPrefixedClassName("el-row"),
          getPrefixedClassName(this.justify !== "start" ? `is-justify-${this.justify}` : ""),
          getPrefixedClassName(this.align !== "top" ? `is-align-${this.align}` : ""),
          { [getPrefixedClassName("el-row--flex")]: this.type === "flex" }
        ],
        style: this.style
      },
      this.$slots.default
    );
  }
};
export { Col as SfCol, Row as SfRow };
