import { componentName } from '@sxf/er-components/_const';
import { FormTipMixin } from '@sxf/er-components/_mixins';
import { SfSeparator } from '@sxf/er-components/separator';
import { getPrefixedClassName } from '@sxf/er-feature';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
const BASE_CLS = {
  normal: "sf-title-normal",
  small: "sf-title-small",
  large: "sf-title-large"
};
const SIZE_LIMIT_FONT = {
  normal: ["m", "l"],
  small: ["s", "m"],
  large: ["m", "l", "xl", "2xl"]
};
var script = {
  name: componentName.title,
  componentName: componentName.title,
  components: {
    SfSeparator
  },
  mixins: [FormTipMixin],
  props: {
    bar: {
      type: Boolean,
      default: false
    },
    barShape: {
      type: String,
      default: "bar",
      validator: (v) => ["dot", "diamond", "bar"].includes(v)
    },
    lineThrough: {
      type: Boolean,
      default: false
    },
    withCheckbox: {
      type: Boolean,
      default: false
    },
    title: {
      type: String,
      default: ""
    },
    subTitle: {
      type: String,
      default: ""
    },
    subTitleColor: String,
    size: {
      type: String,
      default: "normal",
      validator: (v) => ["normal", "large", "small"].includes(v)
    },
    fontSize: {
      type: String,
      default: "m",
      validator: (v) => ["s", "m", "l", "xl", "2xl"].includes(v)
    },
    align: {
      type: String,
      default: "",
      validator: (v) => ["", "left", "center", "right"].includes(v)
    },
    ignoreOverflow: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      titleWrapMaxWidth: "100%"
    };
  },
  computed: {
    hasLineThrough() {
      return this.lineThrough || this.withCheckbox;
    },
    titleClass() {
      const __titleClass = [];
      let titleFontSize = "m";
      if (this.bar) {
        __titleClass.push(getPrefixedClassName("sf-title-bar"));
        __titleClass.push(getPrefixedClassName(`sf-title-bar--${this.barShape}`));
      }
      if (this.hasLineThrough) {
        __titleClass.push(getPrefixedClassName("sf-title-line"));
      }
      if (this.withCheckbox) {
        __titleClass.push(getPrefixedClassName("sf-title--with-checkbox"));
      }
      if (this.$slots.right) {
        __titleClass.push(getPrefixedClassName("sf-title-with-right"));
      }
      if (this.align) {
        __titleClass.push(getPrefixedClassName(`sf-title--${this.align}`));
      }
      titleFontSize = !SIZE_LIMIT_FONT[this.size].includes(this.fontSize) ? SIZE_LIMIT_FONT[this.size][0] : this.fontSize;
      __titleClass.push(getPrefixedClassName(BASE_CLS[this.size]));
      __titleClass.push(getPrefixedClassName(`${BASE_CLS[this.size]}--${titleFontSize}`));
      __titleClass.push(this.cls);
      return __titleClass;
    },
    overflowEllipsis() {
      return this.title || !this.ignoreOverflow;
    }
  },
  mounted() {
    this.setTitleWrapMaxWidth();
  },
  updated() {
    this.setTitleWrapMaxWidth();
  },
  methods: {
    getPrefixedClassName,
    setTitleWrapMaxWidth() {
      var _a, _b;
      if (!this.overflowEllipsis) {
        return;
      }
      let margin = 0;
      const rightSlotWidth = (_a = this.$refs.rightSlot) == null ? void 0 : _a.getBoundingClientRect().width;
      const leftSlotWidth = (_b = this.$refs.leftSlot) == null ? void 0 : _b.getBoundingClientRect().width;
      if (rightSlotWidth) {
        margin += 16 + Math.ceil(rightSlotWidth);
      }
      if (leftSlotWidth) {
        margin += 17 + Math.ceil(leftSlotWidth);
      }
      if (this.tip) {
        margin += 20;
      }
      this.titleWrapMaxWidth = margin ? `calc(100% - ${margin}px)` : "100%";
    }
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _obj;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c("div", { class: _vm.getPrefixedClassName("sf-title-wrap") }, [
    _c(
      "div",
      {
        class: [_vm.getPrefixedClassName("sf-title")].concat(_vm.titleClass, [
          _vm.getPrefixedClassName(
            _vm.subTitle || _vm.$slots.subTitle ? "sf-title--has-sub" : ""
          )
        ])
      },
      [
        _c(
          "div",
          { class: _vm.getPrefixedClassName("sf-title_title") },
          [
            _c(
              "span",
              {
                class: (_obj = {}, _obj[_vm.getPrefixedClassName("sf-title_title-wrap")] = true, _obj.ellipsis = _vm.overflowEllipsis, _obj),
                style: { "max-width": _vm.titleWrapMaxWidth },
                attrs: { "data-tip": _vm.title }
              },
              [_vm._t("default", [_vm._v(_vm._s(_vm.title))])],
              2
            ),
            _vm._v(" "),
            _vm.tip ? _c("i", {
              staticClass: "icon-tip",
              attrs: { "data-hint": _vm.contentTip }
            }) : _vm._e(),
            _vm._v(" "),
            _vm.$slots.left ? [
              _c("sf-separator"),
              _vm._v(" "),
              _c(
                "span",
                {
                  ref: "leftSlot",
                  class: _vm.getPrefixedClassName("sf-title_left")
                },
                [_vm._t("left")],
                2
              )
            ] : _vm._e(),
            _vm._v(" "),
            _vm.hasLineThrough ? _c("i", { class: _vm.getPrefixedClassName("sf-title_line") }) : _vm._e(),
            _vm._v(" "),
            _vm.$slots.right ? _c(
              "div",
              {
                ref: "rightSlot",
                class: _vm.getPrefixedClassName("sf-title_right")
              },
              [_vm._t("right")],
              2
            ) : _vm._e()
          ],
          2
        ),
        _vm._v(" "),
        _vm.subTitle || _vm.$slots.subTitle ? _c(
          "div",
          {
            class: _vm.getPrefixedClassName("sf-title_subhead"),
            style: [_vm.subTitleColor ? { color: _vm.subTitleColor } : ""]
          },
          [_vm._t("subTitle", [_vm._v(_vm._s(_vm.subTitle))])],
          2
        ) : _vm._e()
      ]
    )
  ]);
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__ as SfTitle };
