import $ from 'jquery';
import { on, once } from '@sxf/er-utils/dom';
const nodeList = [];
const ctx = "@@clickoutsideContext";
let startClick;
document.addEventListener("mousedown", (e) => startClick = e, true);
document.addEventListener(
  "mouseup",
  (e) => {
    nodeList.forEach((node) => node[ctx].documentHandler(e, startClick));
    startClick = null;
  },
  true
);
var index$1 = {
  bind(el, binding, vnode) {
    const id = nodeList.push(el) - 1;
    const documentHandler = function(mouseup = {}, mousedown = {}) {
      if (!mousedown || !mouseup) {
        return;
      }
      if (!vnode.context || !mouseup.target || !mousedown.target || el.contains(mouseup.target) || el.contains(mousedown.target) || el === mouseup.target || vnode.context.popperElm && (vnode.context.popperElm.contains(mouseup.target) || vnode.context.popperElm.contains(mousedown.target))) {
        return;
      }
      if (binding.expression && el[ctx].methodName && vnode.context[el[ctx].methodName]) {
        vnode.context[el[ctx].methodName]();
      } else {
        el[ctx].bindingFn && el[ctx].bindingFn();
      }
    };
    el[ctx] = {
      id,
      documentHandler,
      methodName: binding.expression,
      bindingFn: binding.value
    };
  },
  update(el, binding) {
    el[ctx].methodName = binding.expression;
    el[ctx].bindingFn = binding.value;
  },
  unbind(el) {
    const len = nodeList.length;
    for (let i = 0; i < len; i++) {
      if (nodeList[i][ctx].id === el[ctx].id) {
        nodeList.splice(i, 1);
        break;
      }
    }
  }
};
const EVENT = (() => {
  const el = document.createElement("fakeelement");
  const animations = {
    animation: "animationend",
    OAnimation: "oAnimationEnd",
    MozAnimation: "animationend",
    WebkitAnimation: "webkitAnimationEnd"
  };
  for (const t of Object.keys(animations)) {
    if (el.style[t] !== void 0) {
      return animations[t];
    }
  }
})();
var vOnShow = {
  bind(el, binding) {
    const $el = $(el);
    let enable = false;
    let callback = () => {
    };
    if ($.isFunction(binding.value)) {
      enable = true;
      callback = binding.value;
    } else if ($.isPlainObject(binding.value)) {
      enable = !!binding.value.enable;
      callback = binding.value.callback || callback;
    }
    if (!enable) {
      return;
    }
    $el.on(`${EVENT}.on-show-detector`, (e) => {
      if (e.originalEvent.animationName !== "on-show-detector") {
        return;
      }
      callback();
      if (binding.modifiers.once) {
        $el.off(`${EVENT}.on-show-detector`);
      }
    });
    $el.css({
      animation: "on-show-detector 0.01s"
    });
  },
  unbind(el) {
    $(el).off(".on-show-detector");
  }
};
var vPopover = {
  bind(el, binding, vnode) {
    const popover = getPopoverFromDirective(binding, vnode);
    if (!popover) {
      vnode.context.$nextTick(() => {
        updatePopover(el, binding, vnode);
      });
      return;
    }
    setTriggerAttr(el, binding.modifiers);
    bindPopoverTarget(popover, el);
  },
  update(el, binding, vnode) {
    updatePopover(el, binding, vnode);
  }
};
function updatePopover(el, binding, vnode) {
  const popover = getPopoverFromDirective(binding, vnode);
  const oldPopover = getPopoverFromDirective(binding, vnode, true);
  if (oldPopover && oldPopover !== popover) {
    unbindPopoverTarget(oldPopover, el);
  }
  if (!popover) {
    return;
  }
  setTriggerAttr(el, binding.modifiers);
  bindPopoverTarget(popover, el);
}
function bindPopoverTarget(popover, el) {
  popover.bindTarget(el);
}
function unbindPopoverTarget(popover, el) {
  popover.unbindTarget(el);
}
function setTriggerAttr(el, modifiers) {
  const trigger = Object.keys(modifiers).filter(function(key) {
    return ["click", "hover", "manual"].indexOf(key) >= 0;
  })[0];
  if (trigger) {
    $(el).attr("data-popover-trigger", trigger);
  } else {
    $(el).removeAttr("data-popover-trigger");
  }
}
function getPopoverFromDirective(binding, vnode, old) {
  const vm = vnode.context;
  let popoverReference;
  if (binding.arg) {
    popoverReference = binding.arg;
  } else if (typeof binding.value === "string") {
    popoverReference = binding.value;
  }
  if (old && typeof binding.oldValue === "string") {
    popoverReference = binding.oldValue;
  }
  return vm.$refs[popoverReference];
}
var index = {
  bind(el, binding, vnode) {
    let interval = null;
    let startTime;
    let timeout = null;
    const handler = () => vnode.context[binding.expression].apply();
    const clear = () => {
      if (timeout) {
        clearTimeout(timeout);
        timeout = null;
      }
      if (new Date() - startTime < 300) {
        handler();
      }
      clearInterval(interval);
      interval = null;
    };
    on(el, "mousedown", (e) => {
      if (e.button !== 0) {
        return;
      }
      startTime = new Date();
      once(document, "mouseup", clear);
      clearInterval(interval);
      clearTimeout(timeout);
      timeout = setTimeout(() => {
        timeout = null;
        handler();
        interval = setInterval(handler, 100);
      }, 300);
    });
  }
};
const installDirectives = (Vue, option = {}) => {
  const { prefix = "" } = option;
  const directivePrefix = prefix.trim() ? `${prefix.trim()}-` : "";
  Vue.directive(`${directivePrefix}on-show`, vOnShow);
  Vue.directive(`${directivePrefix}popover`, vPopover);
};
export { installDirectives, index$1 as vClickoutside, vOnShow, vPopover, index as vRepeatClick };
