import { omit } from 'lodash-es';
import { componentName } from '@sxf/er-components/_const';
import { vPopover } from '@sxf/er-components/_directives';
import { SfButton } from '@sxf/er-components/button';
import { SfPopover, SfPopoverForm } from '@sxf/er-components/popover';
import { SfSearchTrigger } from '@sxf/er-components/trigger';
import { $i } from '@sxf/er-config';
import { getPrefixedClassName } from '@sxf/er-feature';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
import { FormFieldMixin } from '@sxf/er-components/form';
import { SfSelect } from '@sxf/er-components/select';
import { SfSeparator } from '@sxf/er-components/separator';
var script$2 = {
  name: componentName.search,
  componentName: componentName.search,
  components: {
    SfButton,
    SfPopover,
    SfSearchTrigger
  },
  directives: {
    popover: vPopover
  },
  extends: SfPopoverForm,
  model: {
    prop: "searchValue"
  },
  props: {
    searchValue: {
      type: String,
      default: ""
    },
    trim: {
      type: Boolean,
      default: true
    },
    placeholder: {
      type: String,
      default: ""
    },
    advance: {
      type: Boolean,
      default: false
    },
    triggerText: {
      type: String,
      default: () => $i("scp.vt_component.sf_widget.packages.search.src.search.advanced_btn_default_text")
    },
    triggerInputCls: {
      type: String,
      default: ""
    },
    popoverCls: {
      type: String,
      default: ""
    },
    popoverTipCls: {
      type: String,
      default: ""
    },
    popoverCancelBtnText: {
      type: String,
      default: () => $i("scp.vt_component.sf_widget.packages.search.src.search.popover_cancel_btn_text")
    },
    limit: Number,
    useUTF8Len: Boolean,
    inputProps: {
      type: Object
    }
  },
  data() {
    return {
      value: this.searchValue,
      lastData: {},
      isSearching: false,
      isAdvanceSearching: false,
      isValid: true
    };
  },
  computed: {
    mergedInputProps() {
      return Object.assign({}, { canClear: true }, this.inputProps);
    }
  },
  watch: {
    searchValue() {
      this.value = this.searchValue;
    }
  },
  methods: {
    getPrefixedClassName,
    __handleFocus() {
      this.$emit("focus");
    },
    __handleBlur() {
      this.$emit("blur");
    },
    quickSearch() {
      if (this.advance && this.form) {
        this.form.reset();
      }
      this.doSearch();
    },
    endQuickSearch() {
      if (this.advance && this.form) {
        this.form.reset();
      }
      this.doSearch(true);
    },
    doSearch(endSearch, advanceSearch) {
      this.lastData = this.getData();
      const data = Object.assign({}, this.lastData);
      if (data.advance) {
        data.advance = Object.assign({}, this.lastData.advance);
        if (data.advance && !advanceSearch) {
          Object.keys(data.advance).forEach((key) => {
            data.advance[key] = "";
          });
        }
      }
      if (endSearch) {
        this.value = "";
        this.$emit("input", "");
      }
      if (this.trim && typeof data.value === "string") {
        data.value = data.value.trim();
      }
      this.isSearching = !endSearch;
      this.isAdvanceSearching = this.isSearching && !!advanceSearch;
      this.$emit("search", data, !!endSearch, !!advanceSearch);
    },
    submit() {
      this.value = "";
      this.$emit("input", "");
      this.doSearch(false, true);
    },
    cancel() {
      if (this.advance && this.form) {
        this.form.reset();
      }
      if (this.advance) {
        this.doSearch(true, true);
      }
    },
    resetLastData() {
      const hasLastData = Object.keys(this.lastData).length;
      this.$emit("shown", this.lastData);
      if (this.noResetData || !hasLastData) {
        return;
      }
      this.setData(omit(this.lastData, ["value"]));
    },
    getData() {
      const data = {
        value: this.value
      };
      if (this.advance && this.form) {
        data.advance = this.form.getValue();
      }
      return data;
    },
    setData(data) {
      if (data.hasOwnProperty("value")) {
        this.value = data.value;
        this.$emit("input", data.value);
      }
      if (data.advance && this.form) {
        this.form.setValue(data.advance);
      }
    },
    __onInput(value) {
      this.$emit("input", value);
    },
    __onInvalid(result) {
      this.isValid = false;
      this.$emit("invalid", result);
    },
    __onValid(result) {
      this.isValid = true;
      this.$emit("valid", result);
    },
    __onClear(event) {
      this.$emit("clear", event);
    }
  }
};
const __vue_script__$2 = script$2;
var __vue_render__$2 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      class: [
        _vm.getPrefixedClassName("popover-form"),
        _vm.getPrefixedClassName("sf-search")
      ]
    },
    [
      _c(
        "sf-popover",
        {
          ref: "popover",
          class: [
            _vm.getPrefixedClassName("popover-form__popover"),
            _vm.popoverCls
          ],
          attrs: {
            align: "bt-rl",
            "auto-hide": _vm.autoHide,
            footer: true,
            cls: _vm.popoverTipCls,
            "cancel-btn-text": _vm.popoverCancelBtnText
          },
          on: {
            submit: _vm.submit,
            cancel: _vm.cancel,
            shown: _vm.resetLastData
          }
        },
        [_c("template", { slot: "body-inner" }, [_vm._t("default")], 2)],
        2
      ),
      _vm._v(" "),
      _c(
        "sf-search-trigger",
        _vm._b(
          {
            class: [
              _vm.getPrefixedClassName("sf-search__trigger-input"),
              _vm.triggerInputCls
            ],
            attrs: {
              placeholder: _vm.placeholder,
              limit: _vm.limit,
              "use-UTF8-len": _vm.useUTF8Len
            },
            on: {
              focus: _vm.__handleFocus,
              blur: _vm.__handleBlur,
              valid: _vm.__onValid,
              invalid: _vm.__onInvalid,
              input: _vm.__onInput,
              trigger: function($event) {
                return _vm.quickSearch(arguments[0]);
              },
              end: _vm.endQuickSearch,
              clear: _vm.__onClear
            },
            model: {
              value: _vm.value,
              callback: function($$v) {
                _vm.value = $$v;
              },
              expression: "value"
            }
          },
          "sf-search-trigger",
          _vm.mergedInputProps,
          false
        )
      ),
      _vm._v(" "),
      _vm._t(
        "trigger",
        [
          _vm.advance ? _c(
            "sf-button",
            {
              directives: [
                {
                  name: "popover",
                  rawName: "v-popover:popover.click",
                  arg: "popover",
                  modifiers: { click: true }
                }
              ],
              class: _vm.getPrefixedClassName("sf-search__advance-button"),
              attrs: { "icon-right": "expand" }
            },
            [_vm._v("\n      " + _vm._s(_vm.triggerText) + "\n    ")]
          ) : _vm._e()
        ],
        {
          submit: _vm.submit,
          cancel: _vm.cancel,
          triggerText: _vm.triggerText,
          popover: _vm.popoverID
        }
      )
    ],
    2
  );
};
var __vue_staticRenderFns__$2 = [];
__vue_render__$2._withStripped = true;
const __vue_inject_styles__$2 = void 0;
const __vue_scope_id__$2 = void 0;
const __vue_module_identifier__$2 = void 0;
const __vue_is_functional_template__$2 = false;
const __vue_component__$2 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$2, staticRenderFns: __vue_staticRenderFns__$2 },
  __vue_inject_styles__$2,
  __vue_script__$2,
  __vue_scope_id__$2,
  __vue_is_functional_template__$2,
  __vue_module_identifier__$2,
  false,
  void 0,
  void 0,
  void 0
);
var script$1 = {
  name: componentName.filter,
  componentName: componentName.filter,
  components: {
    SfButton,
    SfPopover,
    SfSearchTrigger
  },
  directives: {
    popover: vPopover
  },
  extends: __vue_component__$2,
  props: {
    disabled: {
      type: Boolean,
      default: false
    },
    needTriangle: {
      type: Boolean,
      default: true
    },
    btnType: {
      type: String,
      default: "normal"
    },
    advance: {
      type: Boolean,
      default: true
    },
    triggerText: {
      type: String,
      default: () => $i("scp.vt_component.sf_widget.packages.search.src.filter.filter_btn_text")
    },
    showInput: {
      type: Boolean,
      default: true
    },
    lazyRender: {
      type: Boolean,
      default: false
    },
    inputRef: {
      type: String,
      default: ""
    }
  },
  data() {
    return {
      showPopoverForm: !this.lazyRender,
      isFilter: false,
      isShowInput: this.showInput,
      isActive: false
    };
  },
  computed: {
    hasPrefix() {
      return !!this.$slots.prefix;
    },
    prefixForm() {
      let form;
      if (this.hasPrefix) {
        this.$slots.prefix.some((item) => {
          if (item.componentInstance && item.componentInstance.$options.componentName === componentName.form) {
            form = item.componentInstance;
            return true;
          }
        });
      }
      return form;
    },
    buttonIconRight() {
      if (!this.needTriangle) {
        return "";
      }
      return this.isActive ? "comp-angle-up" : "comp-angle-down";
    },
    cancelBtnText() {
      return this.isFilter ? $i("scp.vt_component.sf_widget.packages.search.src.filter.clear_all_btn_text") : $i("scp.vt_component.sf_widget.packages.search.src.filter.cancel_btn_text");
    },
    popoverTipClass() {
      return `${this.popoverTipCls} ${getPrefixedClassName("sf-filter-popover")}`;
    }
  },
  mounted() {
    if (this.inputRef) {
      const searchInput = this.$vnode.context.$refs[this.inputRef];
      if (searchInput) {
        this.isShowInput = false;
        this.bindSearchEvent(searchInput);
      }
    }
  },
  methods: {
    getPrefixedClassName,
    popoverFormShown() {
      this.showPopoverForm = true;
      this.isActive = true;
      this.$nextTick(() => {
        this.setForm();
        this.resetLastData();
        this.$emit("lazy-rendered");
      });
    },
    resetLastData() {
      const hasLastData = Object.keys(this.lastData).length;
      this.$emit("shown", this.lastData);
      if (this.noResetData || !hasLastData) {
        return;
      }
      this.setData(omit(this.lastData, ["value"]));
    },
    popoverFormHide() {
      this.isActive = false;
    },
    quickSearch() {
      this.doSearch();
    },
    endInputQuickSearch() {
      this.value = "";
      this.$emit("input", "");
      this.doSearch(this.checkIsEndSearch());
    },
    submit() {
      this.isFilter = true;
      this.doSearch();
    },
    cancel() {
      this.form && this.form.reset();
      if (this.isFilter) {
        this.isFilter = false;
        this.doSearch(this.checkIsEndSearch());
      }
    },
    endQuickSearch() {
      if (this.isFilter) {
        this.form && this.form.reset();
        this.isFilter = false;
      }
      if (this.prefixForm) {
        this.prefixForm.reset();
      }
      this.value = "";
      this.$emit("input", "");
      this.doSearch(true);
    },
    checkIsEndSearch() {
      if (this.prefixForm) {
        return false;
      }
      return !this.value && !this.isFilter;
    },
    enterFilterMode() {
      this.isFilter = true;
    },
    doSearch(endSearch) {
      this.lastData = this.getData();
      const data = Object.assign({}, this.lastData);
      if (data.advance) {
        data.advance = Object.assign({}, this.lastData.advance);
      }
      if (this.prefixForm) {
        const prefixData = this.prefixForm.getValue() || {};
        data.advance = Object.assign({}, data.advance, prefixData);
      }
      if (this.trim && typeof data.value === "string") {
        data.value = data.value.trim();
      }
      this.$emit("search", data, !!endSearch, this.isFilter);
    },
    bindSearchEvent(searchInput) {
      const search = (value) => {
        this.value = value;
        this.quickSearch();
      };
      const endSearch = () => {
        this.value = "";
        this.endInputQuickSearch();
      };
      const name = searchInput.$options.componentName;
      if (name === componentName.searchTrigger) {
        searchInput.$on("trigger", (value) => {
          if (value.trim()) {
            search(value);
          } else {
            endSearch();
          }
        });
        searchInput.$on("end", () => {
          endSearch();
        });
      } else if (name === componentName.search) {
        searchInput.$on("search", ({ value }, isEndSearch) => {
          if (isEndSearch) {
            endSearch();
          } else {
            search(value);
          }
        });
      }
    }
  }
};
const __vue_script__$1 = script$1;
var __vue_render__$1 = function() {
  var _obj, _obj$1;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    { class: _vm.getPrefixedClassName("sf-filter-wrap") },
    [
      _vm.hasPrefix ? _c(
        "div",
        {
          class: [
            _vm.getPrefixedClassName("sf-filter-prefix"),
            _vm.getPrefixedClassName("sf-filter__item")
          ]
        },
        [_vm._t("prefix")],
        2
      ) : _vm._e(),
      _vm._v(" "),
      _c(
        "sf-popover",
        {
          ref: "popover",
          class: [
            _vm.getPrefixedClassName("popover-form__popover"),
            _vm.popoverCls
          ],
          attrs: {
            align: "bt-rl",
            "auto-hide": _vm.autoHide,
            footer: true,
            "anchor-hide": true,
            "no-padding": true,
            cls: _vm.popoverTipClass,
            "cancel-btn-text": _vm.cancelBtnText,
            theme: "beauty"
          },
          on: {
            submit: _vm.submit,
            cancel: _vm.cancel,
            shown: _vm.popoverFormShown,
            hidden: _vm.popoverFormHide
          }
        },
        [
          _c(
            "template",
            { slot: "body-inner" },
            [_vm.showPopoverForm ? _vm._t("default") : _vm._e()],
            2
          )
        ],
        2
      ),
      _vm._v(" "),
      _c(
        "div",
        {
          class: (_obj = {}, _obj[_vm.getPrefixedClassName("sf-filter__item")] = _vm.advance || _vm.$scopedSlots.trigger, _obj)
        },
        [
          _vm._t(
            "trigger",
            [
              _vm.advance ? _c(
                "sf-button",
                {
                  directives: [
                    {
                      name: "popover",
                      rawName: "v-popover:popover.click",
                      arg: "popover",
                      modifiers: { click: true }
                    }
                  ],
                  class: (_obj$1 = {}, _obj$1[_vm.getPrefixedClassName("sf-filter__advance-button")] = true, _obj$1[_vm.getPrefixedClassName("hover")] = _vm.isFilter, _obj$1[_vm.getPrefixedClassName("is-active")] = _vm.isActive, _obj$1),
                  attrs: {
                    type: _vm.btnType,
                    icon: "filter",
                    disabled: _vm.disabled,
                    "icon-right": _vm.buttonIconRight
                  }
                },
                [
                  _vm._v(
                    "\n        " + _vm._s(_vm.triggerText) + "\n      "
                  )
                ]
              ) : _vm._e()
            ],
            {
              submit: _vm.submit,
              cancel: _vm.cancel,
              triggerText: _vm.triggerText,
              popover: _vm.popoverID,
              isActive: _vm.isActive
            }
          )
        ],
        2
      ),
      _vm._v(" "),
      _vm.isShowInput ? _c(
        "sf-search-trigger",
        _vm._b(
          {
            class: [
              _vm.getPrefixedClassName("sf-filter__trigger-input"),
              _vm.getPrefixedClassName("sf-filter__item"),
              _vm.triggerInputCls
            ],
            attrs: {
              placeholder: _vm.placeholder,
              disabled: _vm.disabled,
              limit: _vm.limit,
              "use-UTF8-len": _vm.useUTF8Len
            },
            on: {
              input: _vm.__onInput,
              clear: _vm.__onClear,
              trigger: function($event) {
                return _vm.quickSearch(arguments[0]);
              },
              end: function($event) {
                return _vm.endInputQuickSearch();
              }
            },
            model: {
              value: _vm.value,
              callback: function($$v) {
                _vm.value = $$v;
              },
              expression: "value"
            }
          },
          "sf-search-trigger",
          _vm.inputProps,
          false
        )
      ) : _vm._e()
    ],
    1
  );
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
const getDefaultSelectConfig = () => ({
  placeholder: $i("scp.vt_component.sf_widget.packages.select.src.select.select_placeholder"),
  disabled: false,
  width: 80,
  options: [
    {
      id: "all",
      text: $i("scp.vt_component.sf_widget.packages.type_search.select.options_default")
    }
  ]
});
const getDefaultSearchConfig = () => ({
  inputProps: {
    disabled: false
  }
});
var script = {
  name: componentName.typeSearch,
  componentName: componentName.typeSearch,
  components: {
    SfSelect,
    SfSeparator,
    SfSearch: __vue_component__$2
  },
  mixins: [FormFieldMixin],
  props: {
    disabled: {
      type: Boolean,
      default: false
    },
    selectCfg: {
      type: Object,
      default: getDefaultSelectConfig
    },
    searchCfg: {
      type: Object,
      default: getDefaultSearchConfig
    },
    defaultSearchValue: {
      type: String,
      default: ""
    }
  },
  data() {
    return {
      searchValue: this.defaultSearchValue,
      isSelectActive: false,
      isSearchActive: false
    };
  },
  computed: {
    selectProps() {
      var _a;
      const { disabled, selectCfg } = this;
      const originCfg = {
        ...getDefaultSelectConfig(),
        ...selectCfg,
        ...disabled ? { disabled: true } : {}
      };
      if ((_a = originCfg == null ? void 0 : originCfg.ajax) == null ? void 0 : _a.api) {
        delete originCfg.options;
      }
      return originCfg;
    },
    searchProps() {
      const { disabled, searchCfg } = this;
      const defaultSearchCfg = getDefaultSearchConfig();
      const searchNewProps = {
        ...defaultSearchCfg,
        ...searchCfg,
        inputProps: {
          ...defaultSearchCfg.inputProps,
          ...searchCfg == null ? void 0 : searchCfg.inputProps,
          ...disabled ? { disabled: true } : {}
        }
      };
      return searchNewProps;
    },
    isActive() {
      return this.isSelectActive || this.isSearchActive;
    },
    isDisabled() {
      var _a, _b, _c;
      return ((_a = this.selectProps) == null ? void 0 : _a.disabled) && ((_c = (_b = this.searchProps) == null ? void 0 : _b.inputProps) == null ? void 0 : _c.disabled) || this.disabled;
    }
  },
  mounted() {
    this.__bindEvents();
  },
  methods: {
    getPrefixedClassName,
    getFullUtid(utidBase) {
      return this.$attrs.utid ? `${this.$attrs.utid}-${utidBase}` : utidBase;
    },
    __bindEvents() {
      this.$refs.select.$on("focus", () => {
        this.isSelectActive = true;
      });
      this.$refs.select.$on("blur", () => {
        this.isSelectActive = false;
      });
      this.$refs.search.$on("focus", () => {
        this.isSearchActive = true;
      });
      this.$refs.search.$on("blur", () => {
        this.isSearchActive = false;
      });
    },
    onSearch() {
      var _a, _b;
      this.isSelectActive = false;
      const type = (_a = this.$refs.select) == null ? void 0 : _a.getValue();
      const value = (_b = this.$refs.search) == null ? void 0 : _b.value;
      this.$emit("search", { type, value });
    },
    __onInput() {
      this.$emit("input", this.searchValue);
    },
    __onClear(event) {
      this.$emit("clear", event);
    },
    __onTypeChange(info, event) {
      this.$emit("type-change", info, event);
    },
    getValue() {
      var _a, _b;
      const type = (_a = this.$refs.select) == null ? void 0 : _a.getValue();
      const value = (_b = this.$refs.search) == null ? void 0 : _b.value;
      return { type, value };
    },
    __onInvalid(result) {
      this.setValidateState(false, true);
      this.$emit("invalid", result);
    },
    __onValid(result) {
      this.setValidateState(true, true);
      this.$emit("valid", result);
    },
    shouldAddToForm() {
      return false;
    }
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _obj;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      class: [
        (_obj = {}, _obj[_vm.getPrefixedClassName("sf-type-search")] = true, _obj[_vm.getPrefixedClassName("sf-type-search--active")] = _vm.isActive, _obj[_vm.getPrefixedClassName("sf-type-search--disabled")] = _vm.isDisabled, _obj),
        _vm.invalidCls
      ]
    },
    [
      _c(
        "div",
        { class: _vm.getPrefixedClassName("sf-type-search__container") },
        [
          _c(
            "sf-select",
            _vm._b(
              { ref: "select", on: { change: _vm.__onTypeChange } },
              "sf-select",
              _vm.selectProps,
              false
            )
          ),
          _vm._v(" "),
          _c("sf-separator", {
            class: _vm.getPrefixedClassName(
              "sf-type-search__container-separator"
            ),
            attrs: { shape: "line" }
          }),
          _vm._v(" "),
          _c(
            "sf-search",
            _vm._b(
              {
                ref: "search",
                attrs: { utid: _vm.getFullUtid("search") },
                on: {
                  search: _vm.onSearch,
                  input: _vm.__onInput,
                  clear: _vm.__onClear,
                  valid: _vm.__onValid,
                  invalid: _vm.__onInvalid
                },
                model: {
                  value: _vm.searchValue,
                  callback: function($$v) {
                    _vm.searchValue = $$v;
                  },
                  expression: "searchValue"
                }
              },
              "sf-search",
              _vm.searchProps,
              false
            )
          )
        ],
        1
      )
    ]
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__$1 as SfFilter, __vue_component__$2 as SfSearch, __vue_component__ as SfTypeSearch };
