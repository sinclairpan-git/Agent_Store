import $ from 'jquery';
import { $i } from '@sxf/er-config';
import { isInstanceofAjax, ajax } from '@sxf/er-utils/ajax';
import DelayedTask from '@sxf/er-utils/delayedTask';
import IntervalTask from '@sxf/er-utils/intervalTask';
class Pool {
  constructor() {
    this.pool = /* @__PURE__ */ new Set();
  }
  create() {
    throw new Error();
  }
  add(...arg) {
    const instance = this.create(...arg);
    this.pool.add(instance);
    return instance;
  }
  remove(instance) {
    if (this.pool) {
      this.pool.delete(instance);
    }
  }
  destroy() {
    if (this.pool) {
      this.pool.forEach((instance) => {
        instance.__destroy();
      });
      this.pool.clear();
      this.pool = null;
    }
  }
}
class IntervalTaskPool extends Pool {
  create(opt) {
    const instance = opt instanceof IntervalTask ? opt : Reflect.construct(IntervalTask, [opt]);
    instance.__destroy = () => {
      instance.stop();
    };
    return instance;
  }
}
class DelayedTaskPool extends Pool {
  create(fn, scope, args) {
    const instance = fn instanceof DelayedTask ? fn : Reflect.construct(DelayedTask, [fn, scope, args]);
    instance.__destroy = () => {
      instance.cancel();
    };
    return instance;
  }
}
class AjaxPool extends Pool {
  create(url, options) {
    const instance = isInstanceofAjax(url) ? url : ajax(url, options);
    instance.always(() => {
      this && this.remove(instance);
    });
    instance.__destroy = () => {
    };
    return instance;
  }
}
class EventPool extends Pool {
  create(instance) {
    if (!(instance.el && instance.event && instance.fn)) {
      throw new Error($i("scp.vt_component.sf_widget.src.mixins.auto_destroy_utils.parameter_missing_err_msg"));
    }
    const $el = $(instance.el);
    $el.on(instance.event, instance.selector, instance.fn);
    instance.__destroy = () => {
      $el.off(instance.event, instance.selector, instance.fn);
    };
    return instance;
  }
}
const poolsConf = [
  {
    poolClass: IntervalTaskPool,
    poolName: "__intervalTaskPool",
    utilName: "$createIntervalTask"
  },
  {
    poolClass: DelayedTaskPool,
    poolName: "__delayedTaskPool",
    utilName: "$createDelayedTask"
  },
  {
    poolClass: AjaxPool,
    poolName: "__ajaxPool",
    utilName: "$createAjax"
  },
  {
    poolClass: EventPool,
    poolName: "__eventPool",
    utilName: "$createEvent"
  }
];
const poolFuncs = poolsConf.reduce((funcs, poolConf) => {
  funcs[poolConf.utilName] = function(...args) {
    const poolName = poolConf.poolName;
    this[poolName] = this[poolName] || Reflect.construct(poolConf.poolClass, []);
    return this[poolName].add(...args);
  };
  return funcs;
}, {});
poolFuncs.$destroyPools = function() {
  for (const poolConf of poolsConf) {
    let pool = this[poolConf.poolName];
    if (pool) {
      pool.destroy();
      pool = null;
    }
  }
};
poolFuncs.$getAjaxPool = function() {
  return this.__ajaxPool;
};
export { poolFuncs };
