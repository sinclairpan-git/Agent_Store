import nprogress from '@sxf/er-lib/nprogress';
export { default as nprogress } from '@sxf/er-lib/nprogress';
var index = (router) => {
  router.beforeEach((to, from, next) => {
    if (to.path !== from.path) {
      nprogress.start();
    }
    next();
  });
  router.afterEach(() => {
    nprogress.done();
  });
};
export { index as default };
