import $ from 'jquery';
import logger from '@sxf/er-utils/logger';
const menuGridUtillogger = logger("menu-grid-util");
class MenuUtil {
  constructor(opt = {}) {
    if (!opt.menu || !opt.grid) {
      menuGridUtillogger.error("menu or grid cannot be empty");
      return;
    }
    this.opt = $.extend({}, this.opt, opt);
  }
  init() {
    this.bindMouseWheelEvent();
    this.bindRefreshEvent();
  }
  destroy() {
    this.opt.menu.$off("before-show");
    this.opt.menu.$off("after-hide");
    this.opt.grid.grid.off("viewready", this.mouseWheelFn);
    this.mouseWheelFn = null;
    this.opt = null;
  }
  bindRefreshEvent(opt) {
    opt = opt || this.opt;
    if (opt.refresh === false) {
      return;
    }
    opt.menu.$on("before-show", function() {
      if (opt.fn && typeof opt.fn.stopRefresh === "function") {
        opt.fn.stopRefresh();
      }
    });
    opt.menu.$on("after-hide", function() {
      if (opt.fn && typeof opt.fn.startRefresh === "function") {
        opt.fn.startRefresh();
      }
    });
  }
  bindMouseWheelEvent(opt) {
    opt = opt || this.opt;
    this.mouseWheelFn = function() {
      if (!opt.menu.hidden) {
        opt.menu.hide();
      }
    };
    opt.grid.grid.on("viewready", this.mouseWheelFn);
  }
}
var index = {
  init(opt) {
    const m = new MenuUtil(opt);
    m.init();
    return m;
  }
};
export { index as default };
