import $ from 'jquery';
const isPropEnabled = function(value) {
  return Boolean(value || value === "");
};
const hasDefinedProp = function(vueInstance, propName) {
  var _a;
  return Boolean((_a = vueInstance.$options.propsData) == null ? void 0 : _a.hasOwnProperty(propName));
};
function getVueParent(vm, parentName) {
  const parentNames = Array.isArray(parentName) ? parentName : [parentName];
  let parent = vm.$parent;
  while (parent) {
    if (parentNames.includes(parent.$options.componentName)) {
      return parent;
    }
    parent = parent.$parent;
  }
  return false;
}
const getSlot = function(vm, slotName, data) {
  var _a, _b;
  const slot = ((_a = vm.$slots) == null ? void 0 : _a[slotName]) || ((_b = vm.$scopedSlots) == null ? void 0 : _b[slotName]);
  if (!slot) {
    return;
  }
  return typeof slot === "function" ? slot(data || {}) : slot;
};
function findVnodeComponent(vnodes, match, options) {
  options = {
    fromLevel: 0,
    toLevel: 1,
    ...options
  };
  return findVnode(
    vnodes,
    (vnode) => {
      return vnode.componentOptions && match(vnode);
    },
    {
      ...options,
      toLevel: (vnode, level) => {
        if (level > options.toLevel) {
          return false;
        }
        return vnode.componentOptions ? level + 1 : level;
      }
    }
  );
}
function findVnode(vnodes, match, options) {
  options = {
    fromLevel: 0,
    toLevel: 1,
    ...options
  };
  if (!(typeof options.toLevel === "function")) {
    const toLevel = options.toLevel;
    options.toLevel = function(vnode, level) {
      return level >= toLevel ? false : level + 1;
    };
  }
  const __innerData = arguments[3] || {
    result: [],
    levels: []
  };
  vnodes = $.makeArray(vnodes);
  if (options.fromLevel > 0) {
    return findVnode(
      getVnodeChildren(vnodes),
      match,
      {
        ...options,
        fromLevel: options.fromLevel - 1
      },
      __innerData
    );
  }
  let levels = [];
  let children = [];
  vnodes = vnodes.filter((vnode, i) => {
    const level = options.toLevel(vnode, __innerData.levels[i] || 0);
    if (level === false) {
      return false;
    }
    const vnodeChildren = getVnodeChildren(vnode);
    children = children.concat(vnodeChildren);
    levels = levels.concat(Array.apply(null, Array(vnodeChildren.length)).map(() => level));
    return true;
  });
  for (const vnode of vnodes) {
    if (match(vnode)) {
      __innerData.result.push(vnode);
    }
  }
  if (children.length) {
    return findVnode(children, match, options, {
      ...__innerData,
      levels
    });
  }
  return __innerData.result;
}
function getVnodeChildren(vnodes) {
  return $.makeArray(vnodes).reduce((children, vnode) => {
    return children.concat((vnode.componentOptions ? vnode.componentOptions.children : vnode.children) || []);
  }, []);
}
function getProp(ret, item, defaultProp) {
  ret = ret || {};
  if (typeof item === "string") {
    ret[item] = defaultProp;
  }
  if (!item) {
    return;
  }
  if (item.constructor === Object) {
    if ("propName" in item && "propValue" in item) {
      ret[item.propName] = item.propValue;
    } else {
      Object.keys(item).forEach((key) => {
        ret[key] = item[key];
      });
    }
  }
  return ret;
}
function formatProps(...args) {
  const ret = {};
  const getDefaultProp = function(value) {
    return {
      default: value
    };
  };
  args.forEach((item) => {
    if (Array.isArray(item)) {
      item.forEach((prop) => {
        getProp(ret, prop, getDefaultProp());
      });
    } else {
      getProp(ret, item, getDefaultProp());
    }
  });
  return ret;
}
export { findVnode, findVnodeComponent, formatProps, getSlot, getVnodeChildren, getVueParent, hasDefinedProp, isPropEnabled };
