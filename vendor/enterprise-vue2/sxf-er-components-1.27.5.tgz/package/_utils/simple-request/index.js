import $ from 'jquery';
import { poolFuncs } from '@sxf/er-components/_utils/auto-destroy-utils';
import { globalConfig, $i } from '@sxf/er-config';
import { getRequestID } from '@sxf/er-utils/request';
import LoadMask from '@sxf/er-widget/mask';
import notifier from '@sxf/er-widget/notify';
import { isInstanceofAjax, ajax } from '@sxf/er-utils/ajax';
const isUPID = /^UPID/i;
const TASK_STATE = {
  FAILURE: "failure",
  WAITING: "waiting",
  DOING: "doing",
  FINISH: "finish",
  CANCELING: "canceling",
  CANCELED: "canceled"
};
const getMonitorConfig = () => {
  var _a;
  return {
    dataKey: "ulog_id",
    processKey: "process",
    logKey: "log_id",
    api(data, options) {
      return ajax({
        url: options.url || "/vapi/json/log/process",
        data,
        method: "get",
        keepAlive: true
      });
    },
    arrayTask: {
      api() {
        return ajax({
          url: "/vapi/extjs/log?running=1",
          method: "get"
        });
      },
      dataKey: "log_uuid"
    },
    ...(_a = globalConfig.apiConfig) == null ? void 0 : _a.monitor
  };
};
const SIXTY_SECONDS = 60 * 1e3;
const Deferred = function(upid, options) {
  const deferred = $.Deferred();
  deferred.upid = upid;
  deferred.noerror = options.noerror;
  deferred.async = function() {
    this.async = true;
    return this;
  };
  deferred.abort = function() {
    if (this.pending) {
      clearTimeout(this.pending);
      this.pending = null;
    }
    if (this.requesting) {
      this.requesting.abort();
      this.requesting = null;
    }
    this.reject({}, "abort");
  };
  deferred.start = function(pid) {
    $request(pid || this.upid, this, null, options);
    return this;
  };
  deferred.startMulti = function(taskIDs) {
    deferred.startTime = Date.now();
    $requestArrayTask(taskIDs, this);
    return this;
  };
  setTimeout(function() {
    if (true !== deferred.async) {
      deferred.start();
    }
  }, 15);
  return deferred;
};
function monitor(pid, options) {
  options = options || {};
  if (typeof pid === "string") {
    return Deferred(pid, options);
  }
  if (Array.isArray(pid)) {
    const taskIDs = pid.map((item) => item[getMonitorConfig().dataKey]), deferred = Deferred(null, options).async();
    return deferred.startMulti(taskIDs);
  }
  if (isInstanceofAjax(pid)) {
    return monitorAjax(pid, options);
  }
  return Deferred(pid && Object.values(pid)[0], options);
}
function monitorAjax(ajax2, options) {
  let deferred = Deferred(null, options).async();
  ajax2.done(function(json) {
    const data = json.data;
    let taskIDs = [];
    let taskID;
    if (Array.isArray(data)) {
      taskIDs = data.map((item) => item[getMonitorConfig().dataKey]);
    } else if (typeof data === "string") {
      taskID = data;
    } else if ($.isPlainObject(data)) {
      taskID = Object.values(data)[0];
    }
    if (taskIDs.length > 1) {
      deferred.startMulti(taskIDs);
    } else if (taskIDs.length === 1) {
      deferred.start(taskIDs[0]);
    } else if (taskID) {
      deferred.start(taskID);
    } else {
      deferred.abort();
    }
    deferred = null;
  });
  return deferred;
}
function $requestArrayTask(taskIds, deferred, ttl) {
  const MAX = 10;
  ttl = Math.min(ttl || MAX, MAX);
  const arrayTask = getMonitorConfig().arrayTask;
  deferred.requesting = arrayTask.api().done((json) => {
    const data = json.data || [];
    const isRunning = data.some((item) => {
      return taskIds.indexOf(item[arrayTask.dataKey]) !== -1;
    });
    const timeout = Date.now() - deferred.startTime > SIXTY_SECONDS;
    if (isRunning && !timeout) {
      deferred.pending = setTimeout(function() {
        $requestArrayTask(taskIds, deferred);
      }, 1e3);
    } else {
      deferred.resolve(data, "success", { isSingle: false });
    }
  }).fail((p, type) => {
    if (type === "abort") {
      return;
    }
    if (ttl < 1) {
      deferred.reject({}, "timeout");
      return;
    }
    if (p.status === 500) {
      deferred.reject(p.responseJSON || {}, "timeout");
      return;
    }
    deferred.pending = setTimeout(function() {
      $requestArrayTask(taskIds, deferred, ttl - 1);
    }, (MAX - ttl) * 1e3);
  }).error(function() {
    deferred.pending = setTimeout(function() {
      $requestArrayTask(taskIds, deferred);
    }, 1e3);
  }).always(function() {
    deferred.requesting = null;
  });
}
function $request(pid, deferred, ttl, options) {
  const monitorConfig = getMonitorConfig();
  options = options || {};
  const MAX = 10;
  ttl = Math.min(ttl || MAX, MAX);
  const obj = {}, key = options.key || (isUPID.test(pid) ? "upid" : monitorConfig.logKey);
  obj[key] = pid;
  if (deferred.noerror) {
    obj.noerr = 1;
  }
  deferred.requesting = monitorConfig.api(obj, options).done(function(json) {
    const data = json.data;
    const proc = parseInt(data[monitorConfig.processKey], 10);
    const state = data.state;
    if (proc === -1 || state === TASK_STATE.FAILURE) {
      data.message = data.message || data.description;
      deferred.reject(data, "error");
    } else if (state === TASK_STATE.CANCELED) {
      const canceledMessage = data.description || $i("scp.vt_component.common.util.ajax.cancel_msg");
      deferred.reject(
        {
          description: canceledMessage,
          message: canceledMessage,
          success: false
        },
        "canceled"
      );
    } else if (proc < 100) {
      if (proc >= 0) {
        deferred.notify(proc);
      }
      deferred.pending = setTimeout(function() {
        $request(pid, deferred, null, options);
      }, 1e3);
    } else {
      deferred.resolve(data, "success", { isSingle: true });
    }
  }).fail(function(p, type) {
    if (type === "abort") {
      return;
    }
    if (ttl < 1) {
      deferred.reject({}, "timeout");
      return;
    }
    if (p.status === 500) {
      deferred.reject(p.responseJSON || {}, "timeout");
      return;
    }
    deferred.pending = setTimeout(function() {
      $request(pid, deferred, ttl - 1, options);
    }, (MAX - ttl) * 1e3);
  }).error(function() {
    deferred.pending = setTimeout(function() {
      $request(pid, deferred, null, options);
    }, 1e3);
  }).always(function() {
    deferred.requesting = null;
  });
}
const getMessageConfig = () => ({
  requestSubmitted: $i("scp.vt_component.sf_widget.src.mixins.simple_request.request_submitted_msg"),
  success: $i("scp.vt_component.sf_widget.src.mixins.simple_request.operation_successful_msg"),
  fail: $i("scp.vt_component.sf_widget.src.mixins.simple_request.operation_fail_msg"),
  loadFail: $i("scp.vt_component.sf_widget.src.mixins.simple_request.operation_fail_to_load_data_msg"),
  asyncSuccess: $i("scp.vt_component.sf_widget.src.mixins.simple_request.data_submitted_success_msg"),
  asyncFail: $i("scp.vt_component.sf_widget.src.mixins.simple_request.data_submitted_fail_msg"),
  taskSuccess(actionText) {
    if (actionText) {
      return $i("scp.vt_component.sf_widget.src.mixins.simple_request.task_success_msg", {
        0: actionText
      });
    }
    return $i("scp.vt_component.sf_widget.src.mixins.simple_request.task_success_action_text");
  },
  taskFail(actionText) {
    if (actionText) {
      return $i("scp.vt_component.sf_widget.src.mixins.simple_request.task_fail_msg", {
        0: actionText
      });
    }
    return $i("scp.vt_component.sf_widget.src.mixins.simple_request.task_fail_action_text");
  },
  asyncTaskSuccess(text) {
    if (text) {
      return $i("scp.vt_component.sf_widget.src.mixins.simple_request.async_task_success_msg", {
        0: text
      });
    }
    return $i("scp.vt_component.sf_widget.src.mixins.simple_request.async_task_success_text");
  },
  asyncTaskFail(text) {
    if (text) {
      return $i("scp.vt_component.sf_widget.src.mixins.simple_request.async_task_fail_msg", {
        0: text
      });
    }
    return $i("scp.vt_component.sf_widget.src.mixins.simple_request.async_task_fail_text");
  }
});
function simpleRequest({
  request,
  ajaxParams,
  notify,
  mask,
  maskText,
  abortLast,
  actionText,
  withMonitor,
  maskImmediate
} = {}) {
  if (Array.isArray(request)) {
    return simpleWhen.call(this, ...arguments);
  }
  if (typeof request === "function") {
    request = request(ajaxParams);
  }
  if (abortLast) {
    const ajaxPool = poolFuncs.$getAjaxPool.call(this);
    (ajaxPool && ajaxPool.pool || []).forEach((ajax2) => {
      if (getRequestID(ajax2.ajaxOptions) === getRequestID(request.ajaxOptions)) {
        ajax2.abort();
      }
    });
  }
  const maskDefer = handleMask.call(this, mask, maskImmediate, maskText);
  const defer = poolFuncs.$createAjax.call(this, request).always((success, json = {}, args) => {
    var _a;
    maskDefer.resolve();
    if (args && (args[1] === "abort" || ((_a = args[0]) == null ? void 0 : _a.statusText) === "abort")) {
      return;
    }
    handleNotify(json, notify, actionText);
  });
  if (withMonitor) {
    simpleMonitor.call(this, defer, withMonitor);
  }
  return defer;
}
function simpleMonitor(pid = "", asyncOptions = {}) {
  const { mask, maskImmediate = true, notify = "sync", callback, actionText, monitorOptions } = asyncOptions;
  const maskDefer = handleMask.call(this, mask, maskImmediate);
  return monitor(pid, monitorOptions).always((json, state) => {
    const isTaskSuccess = state === "success";
    json.success = isTaskSuccess;
    handleNotify(json, notify, actionText);
    maskDefer.resolve();
    if (callback) {
      callback.call(this, isTaskSuccess, json);
    }
  });
}
function simpleWhen({ notify, mask, maskImmediate, request } = {}) {
  const maskDefer = handleMask.call(this, mask, maskImmediate);
  return $.when(...request).always((json) => {
    maskDefer.resolve();
    handleNotify(json, notify);
  });
}
function handleNotify(json, notifyMsg, actionText) {
  if (!notifyMsg) {
    return;
  }
  let { okText, failText } = notifyMsg;
  json = json || {};
  if (typeof notifyMsg === "string") {
    const MESSAGE = getMessageConfig();
    switch (notifyMsg) {
      case "post":
      case "delete":
      case "put":
      case "sync":
        okText = MESSAGE.taskSuccess(actionText);
        failText = MESSAGE.taskFail(actionText);
        break;
      case "async":
        okText = MESSAGE.asyncSuccess;
        failText = MESSAGE.asyncFail;
        break;
      case "load":
      case "get":
      default:
        failText = MESSAGE.loadFail;
    }
  }
  if (json.success && okText) {
    notifier.ok(okText);
  }
  if (!json.success && failText) {
    notifier.fail(json && json.message || failText);
  }
}
function handleMask(mask, immediate, maskText) {
  const defer = $.Deferred();
  if (!mask) {
    return defer;
  }
  const loadMaskConfig = this.$options.loadMask || this.loadMask || {};
  const configIsObject = loadMaskConfig && typeof loadMaskConfig === "object";
  const maskOptions = {
    ...configIsObject ? loadMaskConfig : {},
    ...maskText ? { msg: maskText } : {}
  };
  const initLoadMask = () => {
    const loadMaskConfig2 = typeof this.__getLoadMaskConfig === "function" ? this.__getLoadMaskConfig() : null;
    if (loadMaskConfig2) {
      const { target, option } = loadMaskConfig2;
      return new LoadMask(target, { ...option, ...maskOptions });
    }
    if (this.$el) {
      return new LoadMask(this.$el, maskOptions);
    }
  };
  const loadMask = mask instanceof LoadMask ? mask : initLoadMask();
  loadMask == null ? void 0 : loadMask.show(immediate);
  defer.always(() => {
    if (!this._isDestroyed) {
      loadMask == null ? void 0 : loadMask.hide();
    }
  });
  return defer;
}
export { getMessageConfig, simpleMonitor, simpleRequest, simpleWhen };
