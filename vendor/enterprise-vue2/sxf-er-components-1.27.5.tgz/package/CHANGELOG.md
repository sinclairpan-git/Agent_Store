# @sxf/er-components

## 1.27.5 (2026-02-04)

### Patch Changes

- 12c4a087: feat(comp:grid): 优化 grid 组件列渲染性能

## 1.27.4 (2026-01-26)

### Patch Changes

- a22a77d3: fix(comp:title): 修复 sf-title 组件在不同尺寸下字体权重不一致问题
- 265cb2d7: fix(comp:button): 修复图标按钮悬浮出现抖动

## 1.27.3 (2026-01-21)

### Patch Changes

- 957df9c0: feat(pro:page-steps,pro:transfer-select): 修正组件 utid
- 43a63233: feat(comp:cover-window,comp:window,comp:tab,comp:nav-menu,comp:alert-list,widget:tab,widget:window,pro:page-steps,pro:transfer-selecat): 修正组件库 utid
- Updated dependencies [43a63233]
  - @sxf/er-widget@1.15.1

## 1.27.2 (2026-01-16)

### Patch Changes

- 86a65525: 调整 select pathname 跳转方式，使用 replace 代替 push

## 1.27.1 (2026-01-15)

### Patch Changes

- 14002b30: fix(comp:tree-tabel): 修复树形表格，在 win11 系统火狐浏览器下长文案不显示问题

## 1.27.0 (2026-01-09)

### Minor Changes

- 51c205dc: refactor: 为 grid-form popover window 组件中的按钮添加统一的类名前缀，配合 cypress 指令修改
- 51c205dc: refactor: 组件内部声明的 utid 属性支持拼接使用组件时传入的 utid 属性

### Patch Changes

- Updated dependencies [51c205dc]
  - @sxf/er-widget@1.15.0

## 1.26.1 (2025-12-30)

### Patch Changes

- 9cc6e17e: fix(comp:\_global): 启用并重构全局销毁插件，只保留移除组件 DOM 元素

## 1.26.0 (2025-12-25)

### Minor Changes

- 766c3b79: feat: 处理组件库内存泄漏问题

### Patch Changes

- Updated dependencies [766c3b79]
  - @sxf/er-widget@1.14.0
  - @sxf/er-utils@1.4.0

## 1.25.1 (2025-12-10)

### Patch Changes

- 9f12359d: fix(comp:alert): 解决 alertList 组件 utid 告警问题

## 1.25.0 (2025-11-26)

### Minor Changes

- 1b04b643: feat(comp:step): 添加 delay 属性支持步骤内容延迟显示

### Patch Changes

- c0ccf6d0: feat(comp:cover-window,comp:window): 修复组件上下步按钮 utid 不会随步骤变更的问题

## 1.24.2 (2025-11-17)

### Patch Changes

- caad89bd: feat(utils:format): 新增 formatToData 方法的导出

  feat(comp:cover-window): 处理 coverWindow 组件上下步不会随步骤变更的问题

- Updated dependencies [caad89bd]
  - @sxf/er-utils@1.3.2
  - @sxf/er-validator@1.2.1
  - @sxf/er-widget@1.13.2

## 1.24.1 (2025-11-13)

### Patch Changes

- feat(comp/widget/pro): 支持设置自定义 utid
- Updated dependencies [4176d2d0]
- Updated dependencies
  - @sxf/er-widget@1.13.1
  - @sxf/er-validator@1.2.1

## 1.24.0 (2025-10-29)

### Minor Changes

- 7ce2c84e: feat(widget:group):表格分组插件增加懒加载子节点功能

### Patch Changes

- 47a347e5: fix(comp:grid): 修复嵌套表格同时展开两个子表格以上刷新表格会导致列表滚动高度异常
- Updated dependencies [7ce2c84e]
- Updated dependencies [a90ccc41]
  - @sxf/er-widget@1.13.0
  - @sxf/er-validator@2.0.0

## 1.23.4 (2025-10-22)

### Patch Changes

- sync: 6112 改动合入主线发版

## 1.23.3 (2025-10-14)

### Patch Changes

- 0b54142f: fix(comp:checkbox): 修复复选框提示图标和标题对齐问题
- Updated dependencies [0b54142f]
  - @sxf/er-style@1.2.1

## 1.23.2 (2025-09-18)

### Patch Changes

- sync: 同步 release/scp-6112-new 分支改动

## 1.23.1 (2025-09-15)

### Patch Changes

- 00e2f77d: fix(comp:checkbox): 修复复选框与文字垂直居中对齐

## 1.23.0 (2025-09-02) (2025-09-02)

### Minor Changes

- 95151b54: feat(comp: select): 添加下拉框分组全选功能

## 1.22.0 (2025-07-18)

### Minor Changes

- 063e115e: feat(comp:grid): 将列标题提示交互从点击改为悬停触发
- chore: 统一更新主线版本
- 6adf9685: feat: 添加下拉禁用提示 demo

### Patch Changes

- bd2321ff: fix: 修改 grid 组件空状态文案色号错误
- 8c648123: fix(grid): 修复静态数据下 noSelections 禁用未生效的问题
- b19bfd5f: feat(comp:cascader): 优化级联菜单宽度计算逻辑
- f6cf3631: 在分组表格中，对于没有子项的行，添加一个类名，并增加背景色白色的样式表
- c17ec170: 修复表格表单在配置隐藏底部按钮后表格表单仍存在下边距问题
- 9b592a84: feat(comp:select): 优化多选标签溢出判断逻辑
- 7cfd0648: fix(comp:combo): 修复 loading 状态下 icon 不居中
- f8280028: fix(comp:drawer): 修复当设置 top 属性时高度计算不正确的问题
- 9aef6f22: 修复 comboGrid 组件静态数据下 noSelections 禁用未生效的问题
- 178ec000: feat(comp:date-picker): 优化日期输入处理逻辑
- 78feb52e: feat(comp:select): 优化全选禁用状态交互和样式
- be5c9927: feat(comp:select): 优化标签前缀样式结构,修复样式问题
- 3e6aba24: fix(comp:input): 修复文本域手动调整宽度后字符计数显示问题
- 661a36ea: feat(select): 1.补充遗漏 less 2.修复前缀图片被挤没了 3.修复已选择悬浮 tip 将塞入的 dom 节点渲染成文本

## 1.21.2 (2025-05-20)

### Patch Changes

- 7654217c: fix(pro:page-steps): 增加 steps 按钮文本的自定义支持
- 2c312e40: fix(comp:radio): radio hint 响应式支持

## 1.21.0-xaas-patch.8 (2025-05-07)

### Patch Changes

- ca34c586: fix(pro:page-steps): 增加 steps 按钮文本的自定义支持
- f22e7b6d: fix(comp:upload): 多个文件上传，出现重复请求的问题
- 07d37e36: feat(comp:combo): 增加 clearable 属性和 clear 事件
  feat(widget:combo): 增加 clearable 属性和 clear 事件
- e6f4c5bf: fix(comp:radio): radio hint 响应式支持

## 1.21.0-xaas-patch.7 (2025-04-25)

### Patch Changes

- 【重新梳理场景，单独确认】撤销 "合并分支: fix(comp:form): 修复 label-tip 显示问题，优化 label 样式…"

## 1.21.0-xaas-patch.6 (2025-04-22)

### Patch Changes

- c3dc4318: fix(comp:form): [form-item]配置了 label-tip，当 label 文案过多，出现...把小 i 标签隐藏了
- d4a6bfdf: fix(comp:input-number): 修复 input 元素对齐不一致的问题

## 1.21.0-xaas-patch.5 (2025-03-26)

### Patch Changes

- 1d34e695: fix(comp:\*):所有不加前缀的样式内容挪入 style 包里面
- 6d1432a4: fix(comp:\_utils): simpleRequest 中 mask 初始化时如果没有挂载元素，则取消初始化 mask，不再用 body 兜底。此改动是完全还原 xaas 解耦之前的 mask 行为
- 49f17149: fix(comp:\*): 修复 er-components 打包 less 产物前缀变量名错误的问题

## 1.21.0-xaas-patch.4 (2025-03-22)

### Patch Changes

- 93366e6d: fix(comp:button): 修复 button 迁移过程中丢失 css 变量 --color-text-link-disabled;移除无定义的 css 变量 --button-right-icon-wrap-margin-right-l 及其对应样式规则
- 93366e6d: fix: 修复由于跨组件引用 css 变量, 打包时没有提供全局 css 变量, less math 配置不是 strict 导致的样式打包产物有误

## 1.21.0-xaas-patch.3 (2025-03-20)

### Patch Changes

- 951e500e: fix(comp:window): 修复用 vueWindowCreator 打开 cover-window 后，simpleRequest 配置 mask 报错

## 1.21.0-xaas-patch.2 (2025-03-19)

### Patch Changes

- 72b81ba9: fix(comp:window): messageBox 补充 $windowLoadMask 代理

## 1.21.0-xaas-patch.1 (2025-03-19)

### Patch Changes

- e870eecd: fix(comp:form): 修复代码合入导致的 css 变量丢失
- chore: 合入 xaas 变更后更新版本号，统一升级

## 1.18.0-scp-6112-patch.3 (2025-09-29)

### Patch Changes

- c3dd6c00: fix(comp:layout-height): 修复在子应用弹窗中使用时高度计算异常的问题

## 1.18.0-scp-6112-patch.2 (2025-09-26)

### Minor Changes

- 9e45632f: feat(comp:radio): 单选框组件增加禁用提示
- e5eeb383: feat(widget:grid): 表格插件 plugins 的 Group 插件，增加配置 isHideGroupColumnWhenNoGroup

## 1.18.0-scp-6112-patch.1 (2025-09-10)

### Patch Changes

- 18c46071: fix(comp:input-number): 修复一直点击增加或者减少按钮会存在漏增加或者漏减少的情况
- ce9a38d9: fix(comp:search): 修复打开 popover 时外部输入框内容被重置的问题

## 1.18.0-scp-6111-patch.50 (2025-04-22)

### Patch Changes

- 3c313c2c: fix(comp:window): 修复默认无 submit 按钮的 MessageBox 配置显示 submit 按钮后 cancel 按钮文本显示为“我知道了”，应显示为“取消”

## 1.18.0-scp-6111-patch.49 (2025-04-07)

### Patch Changes

- 5bc2eab3: feat(widget:grid): 优化列宽调整功能

  定义：列 A = 非操作列的最后一列

  1. 拖拽的时候，会将宽度分配给 列 A

     - 向左拖会增大 列 A 的宽度
     - 向右拖会减少 列 A 的宽度
     - 列 A 最小宽度为 `96px`

  2. 默认情况下列的最小拖拽宽度为 40px，除非业务有设置列的 minWidth

  3. 操作列、列 A 不可拖动（除非只剩下两列的情况）

  4. 拖拽后的列，在排序、窗口大小改变等情况会保留拖拽后的列宽

  5. 增大鼠标悬浮上去的拖拽范围（原来的 2px 调整为 6px）

  6. 减少自定义列的宽度 （32px -> 24px）

- Updated dependencies [5bc2eab3]
  - @sxf/er-widget@1.7.0
  - @sxf/er-validator@1.1.0

## 1.18.0-scp-6111-patch.48 (2025-03-25)

### Patch Changes

- bf7da8bb: fix(comp:\*): 修复 er-components 打包 less 产物前缀变量名错误的问题

## 1.18.0-scp-6111-patch.47 (2025-03-25)

### Patch Changes

- 44cf2805: fix(comp:\*):所有不加前缀的样式内容挪入 style 包里面
- 0f27193c: fix(comp:\_utils): simpleRequest 中 mask 初始化时如果没有挂载元素，则取消初始化 mask，不再用 body 兜底。此改动是完全还原 xaas 解耦之前的 mask 行为
- Updated dependencies [44cf2805]
  - @sxf/er-style@1.0.4

## 1.18.0-scp-6111-patch.46 (2025-03-21)

### Patch Changes

- 7a7cd79a: fix(comp:button): 修复 button 迁移过程中丢失 css 变量 --color-text-link-disabled;移除无定义的 css 变量 --button-right-icon-wrap-margin-right-l 及其对应样式规则
- 7a7cd79a: fix: 修复由于跨组件引用 css 变量, 打包时没有提供全局 css 变量, less math 配置不是 strict 导致的样式打包产物有误
- Updated dependencies [7a7cd79a]
  - @sxf/er-style@1.0.4-scp-6111-patch.4

## 1.18.0-scp-6111-patch.45 (2025-03-20)

### Patch Changes

- 4ca8b46b: fix(comp:window): 修复用 vueWindowCreator 打开 cover-window 后，simpleRequest 配置 mask 报错

## 1.18.0-scp-6111-patch.44 (2025-03-18)

### Patch Changes

- ccea9f33: fix(comp:window): messageBox 补充 $windowLoadMask 代理

## 1.18.0-scp-6111-patch.43 (2025-03-18)

### Minor Changes

- c856ef17: feat(comp:window): 弹窗 $loadMask 新增 $windowLoadMask 别名
- c856ef17: feat(comp:grid): 表格 $loadMask 新增 $gridLoadMask 别名

### Patch Changes

- c856ef17: fix(comp:\_utils): 修复弹窗内调用 simpleRequest 配置遮罩时，遮罩范围有误
- d310b157: fix(comp:nav-menu):补充 NavMenuTitle 样式前缀逻辑

## 1.18.0-scp-6111-patch.42 (2025-03-16)

### Minor Changes

- ea65a2ee: refactor(comp:\_utils): simpleRequest 等方法不再直接依赖组件实例上的 $loadMask
- b2d9968e: feat(cmop:global): 支持部分插件和指令的前缀配置

### Patch Changes

- a3038085: refactor: 组件库内部对 layout 组件的依赖改为显式引用并局部注册

## 1.18.0-scp-6111-patch.41 (2025-03-14)

### Patch Changes

- 4994997f: fix(comp:drawer): 修复抽屉组件动画样式打包后 less 报错

## 1.18.0-scp-6111-patch.40 (2025-03-13)

### Minor Changes

- f4339dfa: refactor(widget:radio): 支持样式类名前缀配置并优化样式文件结构
- 199061de: refactor(comp:date-picker): datePicker 组件支持样式类名前缀可配置
- 96daaed5: refactor(comp:select): 支持样式类名前缀配置并迁移至 LESS
- dcd14fb2: refactor(widget:progress): 支持样式类名前缀配置并优化样式文件结构
- 40ca6953: refactor(comp:button): 支持样式类名前缀配置并优化样式文件结构
- b9d8cc02: feat(comp:pagination): pagination 组件支持样式类名前缀可配置
- 579d6d36: refactor(comp:combo): 支持样式类名前缀配置并迁移至 LESS
- 1c5c66d9: refactor(widget:scrollbar): 支持样式类名前缀配置并优化样式文件结构
- 03309e30: refactor(widget:mask): 支持样式类名前缀配置并优化样式文件结构
  widget 下增加自定义 class 前缀支持，\_global/mask/style 增加 less 前缀变量，components/loading 增加前缀自动化用例
- 994122b4: refactor(comp:\_pro): enable-staus icon-text page 支持自定义样式前缀
- b181bf22: refactor(widget:search): 支持样式类名前缀配置并优化样式文件结构
- 6cdfac15: feat(comp:alert): alert 组件支持样式类名前缀可配置
- 2351f28e: feat(comp:anchor): anchor 组件支持样式类名前缀可配置
- 2df69a04: refactor(comp:drag): 支持样式类名前缀配置并迁移至 LESS
- d59a1424: refactor(comp:cover-window): 支持样式类名前缀配置并优化样式文件结构
- 16a47a48: refactor(comp:tree-select): 支持样式类名前缀配置并迁移至 LESS
- ba7008d6: refactor(comp:grid): 支持样式类名前缀配置并迁移至 LESS
- 32e83424: refactor(comp:menu): 支持样式类名前缀配置并迁移至 LESS
- ab2dc999: refactor(comp:tabs): widget/tabs、comp/tabs 支持样式类名前缀配置并优化样式文件结构
- b5b40e6c: refactor(comp:layer): 支持样式类名前缀配置并优化样式文件结构
- a5ea20ce: refactor(comp:space): 支持样式类名前缀配置并迁移至 LESS
- 5d8da1f6: refactor(widget:toolbar): 支持样式类名前缀配置并优化样式文件结构
- 0e2fa186: refactor(comp:switch): 支持样式类名前缀配置并迁移至 LESS
- e9d118e1: refactor(comp:step): 支持样式类名前缀配置并迁移至 LESS
- 8c39d031: refactor(comp:layout): 支持样式类名前缀配置并优化样式文件结构
- 5aab533f: refactor(comp:form): 支持样式类名前缀配置并优化样式文件结构
- 8c38e269: refactor(comp:flex): 支持样式类名前缀配置并优化样式实现
- f42371de: refactor(comp:path): 支持样式类名前缀配置并迁移至 LESS
- a5044929: feat(comp:\*): 组件全局配置改为从 feature 包中获取
- 06a09a10: refactor(comp:drawer): 支持样式类名前缀配置并迁移至 LESS
- b524f19a: feat(comp:badge): badge 组件支持样式类名前缀可配置
- 7d994c83: refactor(comp:grid-form): 支持样式类名前缀配置并迁移至 LESS
- 2659a877: refactor(comp:card): 添加 prefix 配置
- 49ce81a4: refactor(widget:title): 支持样式类名前缀配置并优化样式文件结构
- 54eb3e10: refactor(widget:search-tip): 支持样式类名前缀配置并优化样式文件结构
- aff48fef: feat(comp:empty): empty 组件支持样式类名前缀可配置
- 4373a204: refactor(comp:cascader): 支持样式类名前缀配置并优化样式文件结构
- 478c25ee: refactor(comp:window): 支持样式类名前缀配置并迁移至 LESS
- 2c544341: refactor(widget:button): 撤回 btn.css 文件
- eeffa6fa: refactor(comp:input-number): 支持样式类名前缀配置并迁移至 LESS
- 9a67f67e: feat(comp:collapse): 支持样式类名前缀配置并优化样式实现
- 929f6dac: fix(comp:button): 替换按钮样式中的 mixin 定义和调用方式
- 69158915: refactor(comp:fieldset): 支持样式类名前缀配置并迁移至 LESS
- e8045db6: refactor(comp:separator): 支持样式类名前缀配置并迁移至 LESS
- 76310c8a: refactor(widget:popover): 支持样式类名前缀配置并优化样式文件结构
- 6863a281: refactor(comp:nav-menu): 支持样式类名前缀配置并迁移至 LESS
- f426eecf: refactor(comp:upload): 支持样式类名前缀配置并迁移至 LESS
- da424e83: refactor(comp:input): 支持样式类名前缀配置并迁移至 LESS
- 788b8a24: refactor(comp:tree): 支持样式类名前缀配置并迁移至 LESS
- fea0efd5: refactor(comp:trigger): 支持样式类名前缀配置并迁移至 LESS
- adb05f2a: feat(comp:editor): 支持样式类名前缀配置并优化样式实现
- acada65c: refactor(comp:carousel): 支持样式类名前缀配置并优化样式文件结构
- a5444f1d: refactor(comp:list): 支持样式类名前缀配置并优化样式文件结构

### Patch Changes

- 10e412d9: refactor(comp:\*): 修改样式前缀方案，直接在已有类名前面加前缀，默认前缀为空
- f9d5dff4: refactor(comp:badge): 修改组件样式前缀变量的获取方式，还原 css 变量
- 04e568da: refactor(comp:empty): empty 组件样式前缀配置保留原有类名
- 13dc7794: refactor(comp:\*): 调整组件样式类名前缀方案，改为保留原有类名基础上额外添加带前缀的类名
- da55c293: refactor: 所有 postCSS 语法定义的 mixin 修改为 less 语法，color-mod 替换为 fade
- 459d783f: refactor(comp:tag): tag 组件样式前缀配置保留原有类名
- 9ba0df70: refactor(comp:alert): alert 组件样式前缀配置保留原有类名
- b36cd956: fix(comp:\*): 修复 fade 函数透明度参数错误

## 1.21.0-scp-6112-patch.3 (2025-03-04)

### Patch Changes

- 4e3f0db9: fix(comp:grid): 自定义列插件的单元格 rowspan 与最后一列的 rowspan 保持一致

## 1.21.0-scp-6112-patch.2 (2025-02-20)

### Patch Changes

- 4fcbd803: fix: 修复 checkNoNotify 逻辑容错

## 1.21.0-scp-6112-patch.1 (2025-02-20)

### Patch Changes

- 9cb5d27a: feat(comp:radio): 增加 radio 自定义 tip 内容功能
- 202cc597: fix: 修复高版本控制台报错问题

## 1.21.1 (2025-03-04)

### Patch Changes

- a9ed76bd: 支持隐藏秒显示的功能
- 30792309: fix(comp:select): 修复 Select 组件 placeholder 无法动态修改的问题
- 5dec038c: fix(comp:alert): 修复 Alert 组件中 link button 样式覆盖问题

## 1.21.0 (2025-02-13)

### Minor Changes

- 14788914: chore: 更新主线包发布版本号

### Patch Changes

- dbd0f03e: feat: release/scc-devops 分支合入主线更新版本号
- 7ae5628c: fix(comp:select): 修复下拉组件 tag 偏上问题
- bdce4b99: feat(widget:grid): 补充配置, useTableAutoRefresh hooks 支持修改轮询时间

## 1.20.0 (2024-12-19)

### Minor Changes

- f755b276: feat: 添加 select 组件选中是否展示前缀图片配置

### Patch Changes

- f63bf3c0: fix(comp:form): 修复 formItem 多余 tip 提示问题
- ad8295a9: feat(comp:tree-select): 更新文档中关于 value 格式的说明
- f41befee: fix(comp:popover): 修复有悬浮提示时某些情况下点击页面控制台报错
- b27b7676: fix(comp:step): 修复点击上/下一步没有过滤掉隐藏的节点的 bug

## 1.19.1 (2024-11-26)

### Patch Changes

- 6bc705ea: fix(comp:popover,tooltip): 修复有悬浮提示时某些情况下点击页面控制台报错

## 1.19.0-aipaas-patch.4 (2024-11-27)

### Patch Changes

- 817ff39b: fix(comp:input): 修复 input 在中文输入法下触发连续 input 事件

## 1.19.0-aipaas-patch.3 (2024-11-20)

### Minor Changes

- 889f4dde: feat: 添加下拉框前缀类型属性配置

### Patch Changes

- c94be367: 修复页面步骤和步骤条边距
- e56741ec: fix(comp:select): 调整 Select 下拉框, 满足 x6 节点放大缩小的场景

## 1.19.0-aipaas-patch.2 (2024-11-18)

### Minor Changes

- e1deaab8: feat: select 组件添加选项图片配置，更新选中样式
- ed5d287b: feat(comp:tag): tag 组件更新关闭样式规范

### Patch Changes

- 477bc3b9: fix(comp:input): 修复 Input 组件配置 Limit 后, 初始化时当前输入字符计算错误的问题

## 1.19.0-aipaas-patch.1 (2024-11-08)

### Minor Changes

- 16cadcf9: feat(comp:grid): 支持表格头部右侧自定义内容
- dae07ad0: feat: 添加 form-item 组件的 labelTip 配置
- f18b71c7: feat(comp:upload) 上传组件 file-list 增加置灰提示

### Patch Changes

- 33a92027: fix(comp:switch): 调整 switch 组件在表单中的样式
- 03c11001: fix(comp: select): 修复 select 默认被挂载在 body 下的问题

## 1.19.0-scc-devops-patch.10 (2024-12-31)

### Patch Changes

- 86b32bea: feat(widget:grid): 补充 ts 声明和 API 文档说明

## 1.19.0-scc-devops-patch.9 (2024-12-10)

### Patch Changes

- f44c032b: fix(comp:tag): 优化 tag-group 的换行效果
- d78bac75: fix(pro:cascade-nav-menu): 修复 SingleNavMenu 组件在初始化时进行折叠时，无法展开激活项
- 65abd9e8: fix(comp:grid): 修复嵌套表格冻结列以后，会遮挡滚动条

## 1.19.0-scc-devops-patch.8 (2024-12-03)

### Patch Changes

- fe1b7e41: fix(comp:grid): 修复嵌套表格内子表缺少横线的 bug

## 1.19.0-scc-devops-patch.7 (2024-11-30)

### Minor Changes

- 1c00dd5e: feat(comp:tag): tagGroup 添加单标签悬浮规范
- dd48a306: feat(comp:tag): tag-group 添加滑入提示气泡功能

### Patch Changes

- b665fb0d: fix(comp:tag): 优化 tag-group, 调整 demo
- 5c460dc3: fix(comp:grid-form): 修复表单数据在滚动时被清空的 bug

## 1.19.0-scc-devops-patch.6 (2024-11-28)

### Patch Changes

- bcaed9bd: fix(comp:tag): 修复 tag-group 悬浮气泡不显示的问题

## 1.19.0-scc-devops-patch.5 (2024-11-27)

### Minor Changes

- 50bda092: feat(comp:tag): tag 添加省略效果, tagGroup 添加多行气泡效果

## 1.19.0-scc-devops-patch.4 (2024-11-22)

### Patch Changes

- 7b335066: fix(comp:tag): 修复业务环境 tag-group 无法使用的问题

## 1.19.0-scc-devops-patch.3 (2024-11-21)

### Minor Changes

- d72ddda7: 新增 tag-group 组件

## 1.19.0-scc-devops-patch.2 (2024-11-20)

### Patch Changes

- 3a9de2d5: feat(pro:cascade-nav-menu): 单层菜单逻辑和级联菜单拆分解耦

## 1.19.0-scc-devops-patch.1 (2024-11-18)

### Minor Changes

- 7bd1ca98: feat(comp:nav-menu): 增加单层导航菜单组件并优化样式

## 1.19.0 (2024-10-28)

### Minor Changes

- 6634213b: feat(comp:tabs):tabs 组件新增 animation 属性
- 189c2d3b: feat(comp:treeTable):treeTable 组件新增 tree-item-hover 事件

### Patch Changes

- 45353fe4: fix(comp:tree): tree-table 组件支持自定义 tree-header 的 options
- e2970d97: fix(layer:popper): 修复在某些情况下销毁 popper 时的控制台错误
- 7214fda3: refactor(comp:cascader): 搜索框更换位置且去掉关键词高亮，并调整下拉的宽度让其符合新规范
- aadc4668: feat(widget:notify): 限制消息堆叠高度并添加滚动条
- 355d96c8: fix(comp:select): select 组件文档出现样式污染问题
- ce163b3d: fix(menu): 修复菜单图标间距问题
- da6c1ff2: fix(comp:checkbox): Checkbox 组件 content 插槽在绑定 v-model 值为数字或者字符串时。无法显示。
- 70c48878: fix(pro:transfer-select): 支持非法数据触发 select 回显至右侧已选表格
- 1ad82eee: fix(comp:tree): tree 组件 expand 传入左树不存在的 id，补充异常场景处理

## 1.18.0-scp-6111-patch.39 (2025-01-13)

### Patch Changes

- 3fef394b: button 组件冒泡事件，由父节点进行事件传播

## 1.18.0-scp-6111-patch.38 (2025-01-13)

### Patch Changes

- e476168b: feat(comp:date-picker): 2025011210088 支持业自定义置最大时间: defineMaxTime

## 1.18.0-scp-6111-patch.37 (2025-01-10)

### Patch Changes

- b4d476d0: 规避掉 safari18.1 浏览器会阻止非点击元素的点击事件冒泡问题

## 1.18.0-scp-6111-patch.36 (2025-01-10)

### Minor Changes

- ea22f764: feat(pro:operation): 支持自定义菜单锚点位置并优化表格场景对齐逻辑

## 1.18.0-scp-6111-patch.35 (2025-01-09)

### Patch Changes

- 5292816f: 修改 button 组件，适配 safari18.1 版本浏览器第一次点击无效的问题

## 1.18.0-scp-6111-patch.34 (2025-01-07)

### Minor Changes

- 40287701: fix(comp:tree-select): 修复 tree 插件计算错误的问题

## 1.18.0-scp-6111-patch.33 (2025-01-05)

### Patch Changes

- 0b5a1213: fix(grid): 修复表格数据刷新会导致更多菜单消失或者显示错误菜单内容

## 1.18.0-scp-6111-patch.32 (2025-01-04)

### Patch Changes

- 8fa9b943: feat(comp:window): 支持过滤 '[er-no-notify]' 前缀

## 1.18.0-scp-6111-patch.31 (2025-01-02)

### Patch Changes

- 26472e3f: fix(comp:grid): 修复表格横向滚动条宽度计算问题

## 1.18.0-scp-6111-patch.30 (2024-12-31)

### Patch Changes

- d7a6c364: fix(comp:window): 修复 messageBox 内容超出不换行问题

## 1.18.0-scp-6111-patch.29 (2024-12-30)

### Minor Changes

- b44ee702: fix(comp): 统一整改内存泄露问题

### Patch Changes

- aa85ca25: feat(comp:grid): 新增方法 支持修改自定义列的顺序

## 1.18.0-scp-6111-patch.28 (2024-12-28)

### Minor Changes

- 4a92bf2f: fix(component: layout-height): 添加事件消除，避免内存泄漏

## 1.18.0-scp-6111-patch.27 (2024-12-27)

### Patch Changes

- f62bd261: fix(comp:window): 修复 MessageBox 组件 content 传数组时组件报错
- d9e7c01c: fix(comp:date-picker): 修复 date-picker 组件快捷方式文本显示问题

## 1.18.0-scp-6111-patch.26 (2024-12-26)

### Patch Changes

- 09e32ad3: fix(comp:window): 修复 MessageBox 没有对 subtitle 和 content 处理换行符，导致无法正确渲染换行效果
- a7c3817a: fix(comp:alert): 修复 alert 在存在切换按钮时，长文本下内容显示异常的 bug

## 1.18.0-scp-6111-patch.25 (2024-12-26)

### Patch Changes

- 3a0e7afe: fix(comp:combo): 修复 ComboGrid 组件内置的悬浮提示出爆红的问题
- f6f54b99: fix(comp:editor): editor 组件居中效果靠 flex 布局实现，移除设置 line-height 为 height 的逻辑
- c71899f6: fix(comp:grid): 暴露 renderSlotLimit 类型定义
- 03dccd5a: fix(comp:alert): 修复 alert 在 id 不变时，text 发生变化横幅未更新渲染
- 002c0b83: fix(comp:layer): 修复 layer 在 body 存在滚动时的偏移计算问题

## 1.18.0-scp-6111-patch.24 (2024-12-25)

### Minor Changes

- ce148144: feat: page-tabs 增加 defaultExpandAll 属性以支持默认展开所有标签页

### Patch Changes

- b61c9a0f: fix(comp:layout-height): 修复 SfLayoutHeight 组件在抽屉内使用时的高度计算问题
- 855080e4: feat(comp:alert): alertList 增加 idProperty 属性用于标记告警条的唯一性
- e9f0b3bc: fix(comp:tabs): 修复懒加载模式下自定义 label 不生效的问题

## 1.18.0-scp-6111-patch.23 (2024-12-24)

### Minor Changes

- 1ea568d7: feat(widget:notify): 增加关闭操作回调功能 & 优化 er-no-notify 逻辑

### Patch Changes

- 15893815: feat(comp:alert): 增加 keepStateWhileUpdate 属性在数据更新时保持告警条索引
- 5cff7245: fix(comp:alert): 修复配置了 type="enbedded"和配置了 opration 插槽，鼠标悬浮上去会往上移问题
- 63247565: feat(comp:select): 补充 Select 组件的 renderer 配置自定义场景, 用于展示超长溢出的场景
- 1db0e25d: fix(comp:combo): 修复 comboGrid 组件内自带的溢出省略提示会显示成错误状态的问题

## 1.18.0-scp-6111-patch.22 (2024-12-21)

### Minor Changes

- 29504756: feat(notify): 扩展通知功能，支持自定义徽标和静默通知

### Patch Changes

- 01dac823: fix(comp:\*): sf-tabs 和 sf-tree-table 的 icon 颜色改为 graphite-black-l30

## 1.18.0-scp-6111-patch.21 (2024-12-21)

### Minor Changes

- 739d45fd: feat(comp:\*): 调整 sf-tab 和 sf-tree-table 的 icon 颜色为 l30

### Patch Changes

- 7d038cb6: fix(comp:notify): 修复 notify 容器滚动条在火狐浏览器常显的问题
- 04f02bea: fix(comp:grid): 修复 SfGridOptions 接口中 alwaysRenderView 属性的可选性

## 1.18.0-scp-6111-patch.20 (2024-12-19)

### Patch Changes

- cbd002ae: fix(comp:grid): 修复表格只剩下固定列的场景下的拖动问题

## 1.18.0-scp-6111-patch.19 (2024-12-18)

### Patch Changes

- e89bf382: feat(comp:alert): 调整 AlertList, 补充配置项
- f48a4abb: fix(comp:trigger): SfMoreTrigger 组件补充悬浮提示效果

## 1.18.0-scp-6111-patch.18 (2024-12-17)

### Patch Changes

- 63ed4764: fix(comp:pagination): 页码输入框输入过程实时校验

## 1.18.0-scp-6111-patch.17 (2024-12-16)

### Patch Changes

- 5404e8fa: feat(comp:alert): alertList 支持自定义插槽功能

## 1.18.0-scp-6111-patch.16 (2024-12-14)

### Patch Changes

- 8288b3c3: fix(comp:alert): 剔除@er/hook 中的 useIntervalTask 函数，改用 utils 中的函数，避免循环引用

## 1.18.0-scp-6111-patch.15 (2024-12-13)

### Patch Changes

- 15e27ec5: fix(comp:grid): 修复 tip slot 显示逻辑
- db1a1187: fix(comp:grid): 修复英文版操作列展示不全问题

## 1.18.0-scp-6111-patch.14 (2024-12-11)

### Minor Changes

- 7defac61: feat(comp:date-picker): 支持启用本地最大时间默认设置

### Patch Changes

- 7fba9975: feat(comp:editor): 更改编辑图标

## 1.18.0-scp-6111-patch.13 (2024-12-10)

### Minor Changes

- 94e8634f: feat(component:window): 添加 xss 处理的 content 和 subtitle

## 1.18.0-scp-6111-patch.12 (2024-12-07)

### Minor Changes

- 1b31c3f6: feat(comp:gridForm): 添加表格表单组件本地搜索功能

### Patch Changes

- 1d112fb8: fix(comp:alert): 1.修复 alertList 无法从头开始轮播 2.修复配置项更新 alertList 没有触发更新

## 1.18.0-scp-6111-patch.11 (2024-12-04)

### Minor Changes

- e21baeb3: feat(comp:tabs): tab 组件暴露 hover 事件

### Patch Changes

- a6fee48c: fix(comp:grid): 修复 grid 组件设置右侧固定列时存在 1px 空隙问题

## 1.18.0-scp-6111-patch.10 (2024-12-02)

### Patch Changes

- b47a7255: fix(comp:search): 调整 Filter 筛选组件的数据重置逻辑

## 1.18.0-scp-6111-patch.9 (2024-11-30)

### Patch Changes

- 77db37b6: fix(comp:grid): 修复表格固定列的背景色不统一问题
- 7a6cab45: feat(widget:notify): 限制消息堆叠高度并添加滚动条
- 3c4ef53c: fix: 异常报错处理
- f5f5084d: fix(comp:menu): 修复 menu 组件滚动时边框消失
- 8959aba9: fix(comp:filter): 修复 Filter 筛选框, 首次进入切换选项 并点击取消后, 筛选数据不会重置的问题

## 1.18.0-scp-6111-patch.8 (2024-11-28)

### Patch Changes

- 84a8fd1c: fix: 补充表格展开异常处理&自定义项销毁异常处理

## 1.18.0-scp-6111-patch.7 (2024-11-22)

### Patch Changes

- 9e99f836: feat(comp:tree): 增加节点滚动和加载子节点功能

  - 增加 scrollToNode 方法，支持滚动到指定节点并根据选项展开或激活节点。
  - 增加 shouldLoadNodeChildren 配置项，用于判断是否需要加载节点的子项。

## 1.18.0-scp-6111-patch.6 (2024-11-20)

### Minor Changes

- 68f69e9f: feat(comp:select): 调整下拉框选项文本超长时的显示效果 改为溢出省略+悬浮提示
- 05bdad0b: combo 添加搜索规范

### Patch Changes

- 09cf5e4b: fix(comp:grid): 修复操作列宽度未配置时的默认宽度问题
- 406f2136: 调整菜单层级的指针样式, 处理点击隐藏问题
- 6b5174b7: feat(comp:grid): 优化自定义列操作面板样式
- 9692db94: feat(comp:card): 更新卡片边框颜色

## 1.18.0-scp-6111-patch.5 (2024-11-16)

### Patch Changes

- 13e3aaa7: fix(comp:tree): 修复 treeTable 组件节点滚动到视图内时, 滚动条和展开收起按钮异常的问题
- 5ecbd51e: fix(comp:tree): 修复树表格菜单样式和菜单图标定位问题

## 1.18.0-scp-6111-patch.4 (2024-11-13)

### Minor Changes

- c14689bf: scp-6111 树表格添加非异步加载搜索事件
- 25732f78: tab 组件添加悬浮气泡提示
- 541430cb: feat(grid:custom-column): 支持自定义列操作面板

## 1.18.0-scp-6111-patch.3 (2024-11-08)

### Patch Changes

- 4bad1618: fix(comp:tabs): 修复 beforeHandler 参数传递错误

## 1.18.0-scp-6111-patch.2 (2024-11-08)

### Minor Changes

- c092c1f2: feat(comp:tabs): 支持隐藏时销毁选项卡
- ce44b955: feat(pro:page-tabs): 支持 tab 切换拦截功能

### Patch Changes

- 6a8a3a12: fix(comp:tabs): 修复 beforeHandler 测试用例错误
- 70cfc77f: fix(comp:menu): 动态触发菜单更新时异常修复

## 1.18.0-scp-6111-patch.1 (2024-10-31)

### Minor Changes

- d3e962d0: feat(comp:menu): 支持隐藏分组菜单图标
- 6634213b: feat(comp:tabs):tabs 组件新增 animation 属性
- 70390b01: feat(pro:page-tabs): 添加 page-tabs content 类型
- 189c2d3b: feat(comp:treeTable):treeTable 组件新增 tree-item-hover 事件

### Patch Changes

- 45353fe4: fix(comp:tree): tree-table 组件支持自定义 tree-header 的 options
- e2970d97: fix(layer:popper): 修复在某些情况下销毁 popper 时的控制台错误
- ce163b3d: fix(menu): 修复菜单图标间距问题
- da6c1ff2: fix(comp:checkbox): Checkbox 组件 content 插槽在绑定 v-model 值为数字或者字符串时。无法显示。
- 70c48878: fix(pro:transfer-select): 支持非法数据触发 select 回显至右侧已选表格
- 1ad82eee: fix(comp:tree): tree 组件 expand 传入左树不存在的 id，补充异常场景处理

## 1.18.0 (2024-10-18)

### Minor Changes

- b367a4a9: feat(comp:pro): sf-icon-text 增加 ellipsis 样式类，在一定宽度下，超长文案显示...效果
- 35c874f8: feat: 添加 tabs 懒加载功能

### Patch Changes

- 1466d79d: fix(comp:upload): 修复 failNotify 配置项支持函数类型

## 1.17.0 (2024-09-29)

### Minor Changes

- 3a4766cd: SfTimeRangePicker 补充配置: 支持不显示秒 和 隐藏次日文案

### Patch Changes

- e8cab017: feat(hooks): 下拉表格支持排序

## 1.16.0

### Minor Changes

- 005dd247: 增加了 failNotify 配置项，用于控制是否显示右下角的错误提示。默认值为 true。此更改使用户可以根据需要选择是否显示错误提示，从而提高了组件的灵活性和用户体验。

## 1.15.1 (2024-09-11)

### Minor Changes

- d205320d: revert(comp:grid): 表格字段溢出时，若没配置 tip，显示不全且没提示

## 1.15.0 (2024-09-10)

### Minor Changes

- b34c2f59: file-list 添加 disabled 属性

### Patch Changes

- 1c5d628f: fix(comp:grid): 表格字段溢出时，若没配置 tip，显示不全且没提示
- Updated dependencies [8ab40be1]
- Updated dependencies [743c1f2e]
  - @sxf/er-config@1.2.2
  - @sxf/er-widget@1.6.2
  - @sxf/er-lib@1.0.1
  - @sxf/er-utils@1.0.5
  - @sxf/er-validator@1.1.1

## 1.14.1 (2024-09-05)

### Patch Changes

- 3d7c6461: fix(comp:\_utils): 适配 monitor 被取消后，没有返回后台定义的 description 场景

## 1.14.0 (2024-09-04)

### Minor Changes

- 090cb248: feat: 添加时间组件的 change 事件

### Patch Changes

- e5a7e1d7: fix: 修复 editor 组件配置了 auto-reset 之后值被清空
- 94e84c7d: 修复日期选择组件配置必填项时不会抛错的问题
- 9ed37653: fix(comp:date-picker): v-model 为字符串时，数据回显问题
- 3bf09af6: fix(comp:input) 多行文本输入框，limitNumber 场景下，修改值时候，字符计算不正确(#488)

## 1.13.0 (2024-09-02)

### Minor Changes

- f6c85e6b: fix(comp:date-picker): 支持 v-model 字符串格式和 valueFormat 配置 (#485)

## 1.12.1 (2024-08-29)

### Patch Changes

- 33d141b0: fix(comp:grid): 异常空文本还原展示为网络异常，可通过全局组件配置进行覆盖
- 96b4d610: fix(comp:input): 调整 limit 判断逻辑，适配 limit 为 0 的场景
- 78b88c1d: fix(comp:input): 修复动态赋值输入框，动态赋值的内容小于 limit 限制的场景

## 1.12.0 (2024-08-28)

### Minor Changes

- 3bac21f7: feat(comp:input): 增加 trimSpace 属性，支持失焦后自动去掉前后空白

### Patch Changes

- 5ceba54e: fix(comp:grid): 移除不符合规范的分页组件文案 "加载中..."
- 36ff01d8: fix(comp:input): 输入框回显超出 limit 限制的文本，limit 未触发计算的问题
- 5b705bf3: fix(comp:radio): 修复 radio desc 插槽内容溢出时，hover tip 不显示的问题
- 9f459fb3: fix(comp:cascader): 回退 popper 改动防止改动引发，重新修改级联组件 layer 定位异常
- 27909b27: fix(comp:radio): 修复 radio-button beforeChange 拒绝时无法再次触发 change 事件的问题
- Updated dependencies [5ceba54e]
- Updated dependencies [f1ae0605]
- Updated dependencies [e05dad89]
  - @sxf/er-config@1.1.2
  - @sxf/er-utils@1.0.3
  - @sxf/er-widget@1.6.1
  - @sxf/er-lib@1.0.1
  - @sxf/er-validator@1.1.1

## 1.11.0 (2024-08-26)

### Minor Changes

- 7eb91fe4: feat(widget:tree): 在 widget 中增加树节点彩色图标的支持， 在 component 中增加 Symbol 彩色图标的样式

### Patch Changes

- be9d199f: fix(comp:date-picker): DatePicker 手动删除日期，控制台报错
- acc93697: fix(comp:radio): 纵向布局时，radio 的描述内容换行显示，不截断
- Updated dependencies [7eb91fe4]
- Updated dependencies [974a756e]
  - @sxf/er-widget@1.6.0
  - @sxf/er-validator@2.0.0

## 1.10.1 (2024-08-23)

### Patch Changes

- 42c4975f: fix(comp:grid): 修复多选分组表格中分组行不可选时样式有误
- Updated dependencies [42c4975f]
  - @sxf/er-widget@1.5.2
  - @sxf/er-validator@1.1.1

## 1.10.0 (2024-08-22)

### Minor Changes

- d10ab6cf: feat(comp:popover): 新增 appendToBody 配置，配置 false 时 tip 被创建到当前的父级
- 7431c4a9: feat(comp:grid): 增加表格分页插件 listeners 对象 change 事件配置
- 35cc6212: feat(comp:input): 增加 width 属性配置

### Patch Changes

- 3f6b4272: perf(comp:grid-form): 关闭不必要的 autolabelWidth 计算，提升初始渲染性能
- 649fabff: fix(comp:radio): 将 utid 绑定到 radio-group 层级上，而非容器层级
- a8f442cf: fix(comp:grid): SfGridColumn 组件 prop groupIconCls 类型补充 boolean
- a381787a: fix(comp:radio): 单选组校验写死了错误信息
- a8f442cf: fix(comp:grid): 调整树形表格样式，修复分组行缩进问题 #459
- Updated dependencies [d10ab6cf]
- Updated dependencies [06ee7795]
- Updated dependencies [fcbb1c2a]
- Updated dependencies [a381787a]
- Updated dependencies [a8f442cf]
  - @sxf/er-widget@1.5.0
  - @sxf/er-config@1.1.1

## 1.9.2 (2024-08-16)

### Patch Changes

- 715a68ca: fix(comp:radio): radio lable 插槽中 存在 label 标签时出现换行
- d18f11fc: fix(comp:grid): 网络请求失败时默认展示`暂无数据`
- 91336d21: fix(comp:grid): 修复单选表格表头中的 radio 列被错误隐藏

## 1.9.1 (2024-08-15)

### Patch Changes

- 4f6677d3: fix(comp:grid): 修复 tree 和 RadioSelection 插件中 hideRadio 配置只隐藏表格 body 的 radio 列，未隐藏 header 的问题
- 1ac2c589: fix(comp:combo): 修复树形 combo 不可选的分组行样式有误
- 587bf030: fix(comp:radio): radio 在多行文本下的样式问题

## 1.9.0 (2024-08-14)

### Minor Changes

- bedf37ef: feat(pro:quick-date-picker): 新增选择开始时间和结束时间的回调

## 1.8.1 (2024-08-12)

### Patch Changes

- 3df2b96c: fix(comp:input): 修复存在前后缀时输入框前后间距计算错误
- 2886d8ab: tree-table 支持动态修改输入框的 placeholder：updateSearchPlaceholder

## 1.8.0 (2024-08-09)

### Minor Changes

- a673440d: feat(comp:cascader): 添加 beforeSelect 配置
- 3e3b5946: feat(pro:page-tabs): 新增侧栏展开收起功能，依赖 @sxf/vtv-icon@1.0.181 及 @uedc/sf-layout@1.6.0
- f94eb295: feat(comp:upload): 上传组件增加 removeFile 方法

### Patch Changes

- f28fa4c0: 修复配置了 stepLoad 而没配置 loadChildren 报错问题
- d8cc038d: fix(comp:select): 修复 number 类型 0 值，select 非空校验报错
- Updated dependencies [3e3b5946]
- Updated dependencies [e1db866c]
- Updated dependencies [1b16bd52]
  - @sxf/er-widget@1.3.0

## 1.7.0 (2024-08-05)

### Minor Changes

- 34efacf9: feat(widget:grid): checkSelection/radioSelection 插件添加 beforeSelect 配置

### Patch Changes

- Updated dependencies [34efacf9]
  - @sxf/er-widget@1.2.0

## 1.6.1 (2024-08-01)

### Patch Changes

- 5cc48c7d: fix(comp:checkbox): 修复 checkbox 在 content 插槽内容使用 v-if 时造成高度坍塌
- 5cc48c7d: fix(comp:checkbox): 修复 checkbox 在 checkbox-group 中 content 插槽内容会常显
- 8c5f2bf7: fix(comp:pagination): 修复分页器样式高度错误

## 1.6.0 (2024-08-01)

### Minor Changes

- c15ae678: feat: 修复 input 框长度限制出错

### Patch Changes

- b812d96a: fix(comp:select): 修复多选标签取消选择的问题, issue429
- fe7e3406: fix(comp:select): 修复远程加载时全选显示异常
- Updated dependencies [c15ae678]
- Updated dependencies [fe7e3406]
  - @sxf/er-validator@1.1.0
  - @sxf/er-widget@1.1.1

## 1.5.0 (2024-07-29)

### Minor Changes

- 6073c06b: feat(comp:tree-table): 新增事件，事件名和 tree 保持一致

  - hand-toggle-group 点击节点按钮展开/收起触发
  - hand-toggle-all-group 点击全部展开/全部收起按钮触发
  - fn-toggle-group 调用展开/收起方法触发
  - fn-toggle-all-group 调用全部展开/全部收起方法触发

- d212a496: feat(comp:tree-table): 新增 clear-search 事件，在清除搜索框内容时触发；搜索框内容清除会触发搜索

### Patch Changes

- 4b36027a: fix(comp:form): form-item 必填星号改为仅取决于 required 配置，不与子组件是否必填绑定
- 9f26c261: fix(comp:pagination): 提高分页器选择器权重，避免因样式引入顺序导致的样式覆盖
- Updated dependencies [6073c06b]
- Updated dependencies [abc32178]
  - @sxf/er-widget@1.1.0
  - @sxf/er-utils@1.0.2

## 1.4.0 (2024-07-19)

### Minor Changes

- b3ad8355: feat(comp:popover): popover 对外暴露方法 getBindTarget
- b3ad8355: feat(comp:grid): 新增 hideHeaderFilter 方法，grid 和 grid-column 均提供
- 900e6508: feat(comp:progress): 进度条添加条纹动画

### Patch Changes

- 900e6508: fix(comp:progress): 进度条修复条纹样式
- Updated dependencies [c8eef378]
- Updated dependencies [b3ad8355]
  - @sxf/er-widget@1.0.7

## 1.3.0 (2024-07-16)

### Minor Changes

- 23559d49: feat(comp:cascader): 级联组件新增空状态

### Patch Changes

- a50d9c08: fix(comp:window): SfWindowButton 使用 medium 尺寸的 SfButton，不再直接覆盖按钮样式
- a50d9c08: fix: 更新 peer 中声明的图标库版本到 1.0.175
- Updated dependencies [a50d9c08]
  - @sxf/er-style@1.0.4

## 1.2.3 (2024-07-10)

### Patch Changes

- f49aebbd: fix:【兼容性问题】文件列表上传组件在 浏览器 Chrome 80 版本下报错

## 1.2.2 (2024-07-02)

### Patch Changes

- 1e201955: fix(comp:cascader): 修改多选 tag 不触发 change 的问题
- eedb2fa0: fix(comp:mask): 按照规范调整 mask 显示字重为 500
- ea5c25ad: fix(comp:window): 修复弹窗 no-close 配置不支持响应式
- dda03955: fix(comp:grid): 修复表格插件初始化问题，issue#406
- 7a3738b2: fix(comp:tabs): 修复 tabs 组件卸载时没有注销在父组件监听的事件导致运行报错
- Updated dependencies [ea5c25ad]
- Updated dependencies [ea5c25ad]
- Updated dependencies [eedb2fa0]
  - @sxf/er-widget@1.0.5
  - @sxf/er-style@1.0.3

## 1.2.1 (2024-06-27)

### Patch Changes

- c88edcfa: fix(comp:alert): 根据规范，align 默认值调整为 left
- 51ee5563: fix(comp:date-picker): 输入显示问题
- b27235c1: fix(comp:cascader): 修复级联选择器在最初不可见时计算 tag 长度异常, 同时统一使用多选宽度计算 mixin

## 1.2.0 (2024-06-20)

### Minor Changes

- ec5b2be1: feat(comp:drawer): 抽屉组件配置 mask 为 false 时，仍然渲染遮罩，但遮罩背景色变为透明

### Patch Changes

- f2707ce9: fix(comp:alert): 更新 danger 对应图标

## 1.1.2 (2024-06-07)

### Patch Changes

- 9b948788: fix(comp:grid): 修复多级表头中排序 icon 没有垂直居中
- Updated dependencies [8f85e285]
  - @sxf/er-widget@1.0.4

## 1.1.1 (2024-06-06)

### Patch Changes

- f461c011: perf(comp:\*): 优化 multipleSelect mixin 计算逻辑，降低大数据量下的计算开销
- 7500c328: fix(comp:drawer): 修复选择器等组件在抽屉内使用时，点击选项会关闭抽屉
- e7a44b5a: fix(comp:window): 修复 messageBox before-submit 钩子传入 Promise 无效
- Updated dependencies [e39f5f05]
  - @sxf/er-widget@1.0.3

## 1.1.0 (2024-06-01)

### Minor Changes

- 6d544601: feat(comp:select): 新增配置 maxTagWidth 用于自定义标签最大宽度
  feat(comp:combo): 新增配置 maxTagWidth 用于自定义标签最大宽度

### Patch Changes

- f1c4f46b: fix(comp:alert): 按照规范调整边框 alert 的样式，normal 样式与 waring 样式保持一致
- 70c8952c: fix(comp:search)：修复搜索框 Search 组件会受父级元素 line-height 样式影响
- f1c4f46b: fix: 升级主题库版本到 0.2.5
- d8957b61: fix(comp:cascader): 子项面板宽度调整，规则为：在输入框宽度 / 子菜单深度 和 160 之间取最大值
- 1b3298f0: fix(comp:grid): 修复分页器在表格数据为空时 start 变为负数，issue386
- 8b9487c0: fix(comp:select): 修复 options 为空数组时展开列表异常
- Updated dependencies [8b9487c0]
- Updated dependencies [f1c4f46b]
- Updated dependencies [c1f14608]
- Updated dependencies [52243bfb]
- Updated dependencies [8b9487c0]
  - @sxf/er-widget@1.0.2
  - @sxf/er-style@1.0.2
  - @sxf/er-config@1.1.0

## 1.0.3 (2024-05-28)

### Patch Changes

- 4d6fa893: fix(comp:cascader): 修复级联选择器展开收起 icon 与其他选择器组件不一致
- 589a55bf: fix(comp:pagination): 修复分页器页码跳转输入框 placeholder 显示错误
- 0abeff3f: fix(comp:drawer): 修复不显示 mask 时点击抽屉外区域无法关闭
- 4d6fa893: fix(comp:select): 修复选择器尺寸不受表单控制
- 2edd83d6: fix(comp:upload): 修复打包产物中没有 viewerjs 样式导致图片预览样式异常
- 7c685b88: fix(comp:checkbox): 修复表单场景下 checkbox 使用 content 插槽高度异常，issue#375
- Updated dependencies [4d6fa893]
- Updated dependencies [70010a95]
  - @sxf/er-style@1.0.1
  - @sxf/er-config@1.0.1

## 1.0.2 (2024-05-24)

### Patch Changes

- 220859d4: fix(comp:drawer): 修复 drawer 组件配置 size 宽度异常，issue#374
- 85b91ba8: fix(comp:upload): 修复 fileListUpload 超出文件最大数量时文案异常
- 85b91ba8: fix(comp:button): 链接按钮允许文字选中复制

## 1.0.1 (2024-05-16)

### Patch Changes

- d9c79693: fix(comp:editor): 默认图标及样式调整
- d9c79693: fix(comp:search): 修复 type-search 在工具栏中使用时不对齐
- 91824af6: fix(comp:grid): 修复 tree-table tree-table-select 样式异常
- 5895fff6: fix(comp:cascader): 修复级联组件 placeholder 显示异常
- Updated dependencies [91824af6]
  - @sxf/er-widget@1.0.1

## 1.0.0 (2024-05-13)

### Major Changes

- 7875a24a: feat: eresh1.0 正式版发布

### Minor Changes

- a967b9ce: feat(comp:\*): 更新 @sxf/sf-theme 版本
- 595377b6: feat(comp:select): 多选选择器增加"全部"选项方式
- 06aee79f: feat(comp:search): 搜索框将清除功能作为默认配置
- 8197c813: feat(comp:upload): 增加 upload 组件
- 5e5600be: feat(comp:alert): 更新 info 状态的提示条样式，由灰色改为蓝色
- 974a4171: feat(comp:tree-select): treeTableSelect 树选择组件新增多选处理
- 12207b72: feat(comp:checkbox): checkbox 添加非空校验
- 0542a073: feat(comp:progess): 增加进度条右侧图标配置
- 83b4dd02: feat(comp): radio 添加非空校验
- e0667d4d: feat(comp:button): button 按钮添加 medium 尺寸
- 63c38f68: fix(comp:search): SfSearch Props 增加 width 属性，默认值 = 200
- cfe372da: feat(comp:grid): 表格新增类型 SfGridStoreApiParams
- 9099a218: feat(comp:select): select 校验信息绑定元素调整
  feat(comp:combo): combo 校验信息绑定元素调整
- 340fbf0a: feat(comp:select): SfSelect 支持多选结果以标签显示
- 9d5470a1: feat(comp:progress): progress 新增分段进度条组件
- ccb9d0b1: feat(comp:select): 选择器搜索框新增图标，样式调整
- ab8d5223: fix(comp:grid):给 grid 头部支持筛选过滤
- b95a5826: feat(comp:alert) 告警组件尺寸调整，删除 size 字段
- ae30095c: feat(comp:select): 新增 on-change 事件，用于解决 change 事件触发不准的问题
- 2068d4e7: feat(comp:grid): 表格 Pagingbar 插件使用 SfPagination 组件
- afc6eefe: feat(comp:grid): 表格分页器插件由从 components 包对外导出

  - **Breaking:** Pagingbar 插件无法从 `@sxf/er-widget/grid` 中获取，升级时需要业务同步替换原来的引用路径为 `import { PagingBar } from '@sxf/er-components/grid'`

- b9af929b: feat(comp:select): 选择器下拉框添加“新增”按钮,调整选择器分组的分割线样式
- b049d503: feat(comp:timepicker): 添加 timePicker 时间选择器
- 3eadde82: feat(comp:list): 新增列表(List)组件
- 1ed2e938: feat(comp:search):增加搜索框校验失败样式
- 4fc7947f: feat(comp:pane): 增加 pane 组件父子节点标识，服务于 page-tabs
- 1a9e6fc5: feat(comp:input-number): 计数器需要支持切换按钮右侧展示
- 99e5e591: feat(comp:popover): 新增 hiddenFooterSeparator 字段用于隐藏 footer 和 content 之间的分隔线
- 4f596393: feat(comp:input): 输入框组件新增配置 additionalEvent
- aa70e5f7: feat(comp:input-number): input-number 新增计数器组件
- 0dbbb2d6: feat(comp:grid): 添加表格 header 行最后一列的自定义列按钮显示
- 9099a218: feat(comp:grid): grid 对外暴露插件 ID
- 412e46fe: feat(comp:collapse): 折叠面板规范问题修改

  - 更新样式
  - SfCollapseItem 支持头部完全自定义
  - 移除 theme 配置，无黑色背景
  - 新增 `size` 配置，默认 `'normal'`，可配置为 `'large'`
  - 新增 `bordered` 配置，控制折叠面板样式风格在描边和阴影之间切换

- e1667ea9: feat(comp:anchor): 新增锚点(anchor)组件
- 6507f6d4: feat(comp:tag):tag tpye 字段补充 multiple-select 字段兼容 select 中 tag 样式问题
- da993d25: feat(comp:grid-form): 添加描述文本配置项和调整描述文本颜色和对齐，文档置灰提示优化
- 90a1aeb4: feat(comp:\*): 更新 @sxf/sf-theme 到 "^0.2.4" 版本
- 9099a218: feat(comp:combo): combo 支持多选标签显示模式
- b9cc91bf: feat(comp:cascader): 新增多选功能
- 821bdd26: fix(comp:search): SfSearch Props 移除 width 属性
- 2068d4e7: feat(comp:pagination): 新增分页器组件
- d2607c2b: feat(comp:grid): 分组表格展开收起按钮单独占用一列
- 9c7acbf5: feat(comp:anchor): anchor 组件新增自定义锚点功能以及 demo 和测试用例
- a3ae5ee0: feat(comp:combo): combo 支持配置新增按钮
- 6533c596: feat(comp:datepicker): 按照规范重构 date-picker 日期选择器
- 26976f37: 文本域右下角添加计数
- f53b15b0: feat(comp:tabs): 标签页新增投影卡片类型

  - `type` 新增 `projection-card` 类型，为无边框的投影卡片标签页

- 2327d438: steps 步骤条组件新增错误样式
- 38deba9c: feat(comp: formCollapse): 折叠表单补充描述文本字段

### Patch Changes

- 7b2e95ae: fix(comp:pagination): 分页器样式调整

  - 默认高度 40px
  - simple 模式下高度为 32px

- d97114b4: fix(comp:select): 选择器部分规范问题修改

  - 组件名称由“选择框”重命名为“选择器”，相关示例文案均修改
  - 选项浮层中的选项颜色改为#333
  - 选项浮层搜索框正常状态下边框改为 blue gray L20(#e1e5eb)，hover 改为 blue gray 主色(#ccd2d9)
  - 下拉加载文案改为“加载中...”并左对齐

- 050d3e1c: fix(input): 修复多行文本计数时存在初始值计数不准确
- ac9baa6a: fix(comp:date-picker): 修复 timer-ranger-picker 中 sf-space 未注册问题
- 77daf089: fix(comp:combo): 修复多选模式以 tag 显示时，若元素初始不可见导致 tag 宽度溢出的问题
- 7a1568b5: fix(comp:drawer): 修改抽屉关闭按钮颜色
- 15c4ff8a: fix(comp:drawer): 抽屉样式验收调整
- c88b6e8c: fix(comp:grid-form): 调整下方描述文本和按钮间距处理，不再写成 4px 和默认间距，直接处理为 8px
- b491f375: fix(comp:block): 根据设计规范调整卡片样式问题
- 27619a2f: fix(comp:select):修改 select 新增按钮样式使其居中，对 select 增加 size 的动态响应
- b244ce06: fix(comp:input): 更换删除按钮图标并修改该图标的大小和颜色
- 2ce08330: fix(comp:steps): 修复步骤条图标错误和调整样式
- 5fe005ce: fix(comp:alert): 告警提示 success 状态颜色调整，status 与 icon 绑定
- f28ab2e9: fix(comp:tree): 修改树的全展全收和搜索图标颜色，修复树表格全展全收未居中问题
- 49f096f4: 分隔线色值调整为#EBEDF0
- 6a861809: fix(comp:collapse): 优化描边样式，修复折叠面板展开收起时内容抖动
- 6260bb87: fix(comp:select): 根据交互规范修复 select 样式，文案
- 9ba2738b: feat(comp:mask): mask 支持水平展示
- 6260bb87: fix(comp:menu): 根据交互规范修复 menu 样式
- d0d28ec2: fix(comp:form): 按设计稿修复部分表单显示细节问题

  - 修改表单 FormItem 的 prompt 文本颜色为#666
  - 修改 CheckboxGroup 内部默认间距：15px -> 24px
  - 修改 FormCollapse：size 为 normal 时的字重改为 600；并在文档添加 szie 为 small 的效果展示
  - 修改 Form，当 size 为 small 时，调整外部 padding 为 8px，同样受 padding、tippadding、formitem 的 tip 参数的影响
  - 修改 Form 的 mode 为 detail 时的样式：调整此时的内容文本颜色#000 -> #333；调整上下间距，当 size 为 small 时为 4px，否则为 8px
  - mode 为 detail 新增不同 size 的文档展示

- 06f9fe6e: fix(comp:progress): 修复进度条灰度和默认文本颜色不对问题，并添加部分文档
- ba60dc70: fix(comp:pagination): 修复 SfPagination change 事件不触发的问题
- d355c2c2: fix(comp:tag): 修复 Tag 组件 effect 为 light 时标签背景颜色不正确的问题
- e9d877e0: fix(comp:\_pro): 修改图标文本样式
- 2ff9157c: fix(comp:grid): 表头高度问题
- 9ae0232d: fix(comp:checkbox): label 色值统一使用 @sxf/er-style 提供的表单元素 label 变量
- 4bbb490d: fix(comp:select): 修复下拉框颜色显示问题
- 77daf089: fix(comp:combo): 修复多选标签模式下，标签文本没有绑定 data-tip
- 77daf089: fix(comp:select): 修复多选模式以 tag 显示时，若元素初始不可见导致 tag 宽度溢出的问题
- 9b919361: fix(comp:tabs): 按规范调整标签页的样式
- 6523c32b: fix(comp:select): 调整带前缀图标的选择器样式
- 59132d96: fix(comp:radio): 修复表单中多行样式出错
- 59e243b3: fix(comp:upload): 修复英文字母截断问题
- 9bdbbf31: fix(comp:tag): 取消内投影，可关闭 icon 的左边距设置为 2px
- 056064e4: fix(comp:button): 调整链接按钮的字体颜色
- 5e202c22: fix(comp:grid): 表格头部文案与排序图标间距问题,修复表格标题过长且出现排序图标时，表格标题与排序图标之间距离应该为 8px
- 9fb29e74: fix(comp:anchor): 修复锚点组件 Anchor 验收问题

  - 未选中的和选中的锚点字重没有区别，需要修改

  - 鼠标 hover 锚点时，字体颜色值应该为#000000

- 0c514b9b: feat(comp:tree-select): 下拉 tree-select 表格的默认高度改为 32
- a9ca20a8: fix(comp:cascader): 调整级联选择框选项的默认字体颜色
- c99513d4: fix(comp:grid): 分组表头样式居中显示
- bf8b67fb: 调整抽屉默认展示宽度以及按钮样式
- 9ae0232d: fix(comp:radio): label 色值统一使用 @sxf/er-style 提供的表单元素 label 变量
- 787fef32: fix(comp:carousel): 修改轮播指示器、箭头样式
- 70b2b208: fix(comp:step): 修复步骤组件弹窗下的布局问题和样式问题
- faf1aa08: fix(comp:collapse): 修复折叠面板头部边缘区域点击无效的问题
- 68464269: fix(comp:button): 调整 button 的边框样式实现
- 047bbfd1: fix(comp:cover-window): 调整全局弹窗底部按钮背景色
- f5e4410c: fix(comp:select): 修复 select 组件为为 tag 模式不居中问题
- 63c38f68: fix(comp:search): typeSearch 类型搜索样式调整：增加圆角，修改搜索框宽度
- b049d503: feat(comp:switch): 调整 disabled 状态下的 style
- 3a208bda: fix(comp:window): 修改对话框样式
- c61f0679: fix(comp:select): 修改选择器分组样式
- aa85c894: fix(comp:time-picker): 修复 time-picker 样式异常
- ac80db67: fix(comp:input): 修改后置图标的间距并修复删除图标没有居中对齐问题
- 9099a218: fix(comp:combo): 调整 combo 小尺寸样式
- 31afaa3f: fix(comp:anchor): 修复锚点组件点击和选中时的字体颜色和气泡填充色

  - 点击和选中时，字体颜色和气泡填充色修改为 Poseidon Blue/D10 #156AD9

- de59fd72: fix(comp:date-picker): 修复混合日期切换类型时选中错误问题
- 0238b816: fix(comp:grid): 修复表格多选禁用选中项样式错误
- 7ec75bf1: fix(comp:upload):修复文件类型校验问题
- 87222de0: fix(comp:date-picker): 修复日期范围组件样式出错问题
- 22245ee4: fix(comp: separator): 分隔线颜色调整
- 83c98cf2: fix:(comp:date-picker): 修复日期选择器初始值为空数组时报错
- f376605e: fix(comp:tag): 修复部分场景存在 tag 文本不居中的问题
- 60efd4b3: fix(comp:radio): 修改 radio-group 样式查找最后一个 el-radio-button 元素通过 last-of-type 查找
- 7dfade43: fix(comp:select): select 组件为 tag 模式时 tag 尺寸和 select 尺寸保持一致
- 3a3a6942: fix(comp:grid): 修复嵌套表格样式被父级的分页表格影响
- 998619f8: fix(comp:grid): 嵌套表格收起展开按钮新增 active 状态
- cc4d2bf2: fix(comp:grid): 树形表格同样显示斑马纹
- 0187afba: fix(comp:radio): 修改 radio-group 按钮置灰时的边框颜色值为 40%的#ccc
- 2ce0aebe: fix(comp:cover-window): 全局弹窗底部按改用 large 尺寸按钮
- 83e0f7e9: fix(comp:select): 按照交互规范修复 select 样式
- b41babc8: fix(comp: tag): 标签样式调整
- 9cbfc6b4: fix(comp:grid): 导出表格 storeModel 类型、修正表格的 listener 的 store 类型错误
- ba60dc70: fix(comp:pagination): 修复页码输入框校验报错
- ee8e2f84: fix(comp:empty): 根据规范更新空状态元素之间的间距
- 32c4f15c: fix(comp:pagination): 分页器上一页、下一页按钮图标替换
- 1c5c403a: fix(style): 修改校验失败字体颜色
- c65c34ec: fix(comp:\_pro): 修改图标文本样式
- f3d6c817: fix(comp:tree): 修复 tree-table 异步加载 loading 样式异常
- 55cfb0f5: fix(comp:trigger): 调整文件上传的图标
- db487f77: fix(comp:drawer): 修改抽屉关闭按钮样式
- 5ac40f38: fix(comp:cascader): 修复级联选择器多选时，input 无效触发的问题
- 66fffe40: fix(comp:timepicker): 修改时间选择器样式
- 0da29eb1: fix(comp:grid): 修改分页器高 40px 而不是 39px，normal 尺寸下同理
- 05ee71aa: fix(comp:radio): 修改 radio-group，添加按钮鼠标点击时候的 focus 效果，修改 hover 效果
- 4b99576b: 告警提示组件插槽容器添加 flex 属性
- 204e82af: fix(comp:select): 修改 select 的 small 尺寸下的新增按钮样式, 新增对应示例
- 78c6bb1e: fix(comp:grid): 分组表格的分组行白色填充，树形表格最后一行显示分割线
- 4b78d4ed: fix(comp:grid): 修复按需加载场景下表格分页加载 pagination 组件报错
- 366c1a9c: fix(comp:step): 修复步骤组件最后一步的样式问题
- de0df5c5: fix(comp:card): 卡片 paddingTop 仅在无标题时加并去掉不符规范示例
- bd1ab325: fix(comp:path): 修改面包屑路径行高
- f3a7d3a8: fix(comp:tree-select): fix the bug that the position is wrong while the height is changed
- fe844dc5: fix(comp:progress): 调整微型进度条高度为 3px，添加微型进度条文档
- dd87a5ca: fix(comp:cover-window): 调整底部按钮之间的间距
- 99e0477b: fix(comp:drawer): 修改抽屉关闭按钮样式
- 77719cfb: feat(comp:mask): 修改 mask 的动画效果
- f1b494db: fix(comp:radio): 按照规范调整单选框 label 色值
- f402f16e: fix(comp:search): 类型搜索分隔线左右边距改为 0px
- ba95de09: fix(comp:pagination): 精简型分页器文字样式调整
- 972049ee: refactor(comp:grid): 自定义列插件初始化时机控制，防止初始化时对应的 icon 不存在
- 4b356c60: fix(comp:select): 支持 mutiple 非布尔的形式进行设置
- 7b5f01ee: fix(comp:select) 选项浮层上下边距应为 4
- ef9736f7: fix(comp:alert): 修复告警提示组件 icon 和文本无对齐
- 08da8811: fix(comp:radio): 单选组 RadioGroup 新增主题文档，并修复 dark 主题下 border 显示问题
- 90a1aeb4: fix(comp:tag): 修复标签组件的样式问题, 增加缺失颜色, 调整 doc 示例
- 83e0f7e9: fix(comp:menu): 按照交互规范修复 menu 样式
- 6ee618c0: fix(comp:tabs): 修改样式来满足 page-tabs 的显示效果
- ac3ff8bb: fix(comp:tabs): 调整标签页不同状态的文本颜色以及 active 标识的颜色
- 6a861809: fix(comp:collapse): 修复折叠面板箭头方向错误
- 7b3964d2: fix(comp:button): 修改 icon 按钮的 active 颜色和 link 按钮 hover 颜色
- d122194c: fix(comp:notify): notify 样式修复
- 7ead5069: fix(comp:path): 修改面包屑行高
- 7b2e95ae: fix(comp:grid): 表格分页器 simple 模式下高度为 32px
- b4ec9995: fix(comp:form): 表单上下排版样式，间距不对
- 108c4331: fix(comp:tag): 修改 tag 标签组件中 drak-alarm 标签的字体颜色
- f1b494db: fix(comp:checkbox): 按照规范调整复选框 label 色值
  .
- 209a1248: fix(comp:tabs): 调整下划线标签页标题栏高度
- a28eb4b6: 修改链接按钮禁用颜色和 icon 按钮 active 颜色
- 4dcd108d: fix(comp:notify):样式修改
- 18b51bc4: fix(comp:form): 添加必填星号样式和文档，并调整为已配置 required 并且是必填内容才展示
- 998619f8: fix(comp:grid): 分组表格展开收起按钮新增 active 状态，且不显示斑马线，分组行白色填充，数据行灰色填充
- c12e9bce: fix(comp:drawer): 补充查看类抽屉的示例，修复操作和查看场景下 drawer 内容区域的边距
- 998619f8: fix(comp:grid): 树形表格叶子行同样显示分割线；调整 group 行样式以显示被遮挡的连接线；展开收起按钮新增 active 状态
- 33927303: fix(comp:grid): 基础表格 small 尺寸取消单元格竖向分割线，调整表头文本颜色，斑马线背景颜色
- f21152b7: fix(comp:form): 调整示例中框中表单的尺寸，调整表单中分割线的间距
- 67d284ff: fix(comp:tree-select): 调整树选择组件多选效果，使只有多选框有变化，文本颜色和字重不变
- a8ee5de0: fix(comp:steps): 修复 Steps 组件验收问题（调整标题颜色）

  - 已完成的标题颜色和正在进行中的标题颜色保持一致，为#000000。

- 77daf089: fix(comp:select): 修复配置 displayField 后 tag 标签显示异常
- d2607c2b: fix(comp:grid): 修复树形表格点击分组行也会触发 item-select 事件
- cde547be: fix(comp:window): 修改对话框关闭按钮颜色
- 0472a0a6: fix(comp:checkbox): 修改 checkbox 组件样式问题
- d13bc207: fix(comp:grid): 修复嵌套表格样式异常
- 11bdcbd2: fix(comp:cascader): 修复级联组件库定位异常问题
- 518d5c0b: fix(comp:tabs): 按规范调整垂直标签页的样式
- 6507f6d4: feat(comp:select): tag-size 默认值设置为 normal
- db191806: fix(comp:grid): 自定义列悬浮层样式调整
- aad3f4c2: fix(comp:cascader): 修改 size 为 small 时级联选项高，更正 size 字段的文档描述
- b7e80f5f: fix(comp:trigger): 调整激活状态下的删除按钮颜色和间距
- 15b4a6c5: fix(comp:select): 下选择器新增按钮底部出现 4px 的留白
- 84d06225: fix(comp:button): 修改按钮 shadow 效果为 inset
- ad6d44a4: fix(comp:path): 修改面包屑路径样式
- 9ddfa979: fix(comp:title): 修改带有副标题的标题栏样式
- e5d7354a: fix(comp:window): 修改对话框关闭按钮样式
- 7d885378: fix(style): 修复小 i 未居中问题
- 3dfb5438: fix(comp:step): 修复 Step 组件以下验收问题:

  1. 最后一步的文案区域右边去掉多余边距;
  2. 描述的文案较少时, 需要适配单行显示;
  3. 描述文本字重使用常规 normal;
  4. 已完成的 icon 内的对号替换饱满型(comp-ok-border);

- e5deb83a: fix(comp:radio): 修改 radio-group 按钮置灰时的边框颜色值-调整变量
- 4f470494: fix(comp:tree-select): 树选择样式调整，包括 tree-select 和 tree-table-select
- 682e957d: fix(comp:select): 修复多选存在可关闭 tag 时没有居中问题
- 6d4f5255: fix(comp:radio): 修复表单内 radio 和 checkbox 的默认高度为 32px
- cb7bc047: fix(comp:select): 修复多选模式下不使用 v-model 时选中回显值顺序错乱
- 3ca1b2a6: fix(comp:type-search): 修复 type-search 在表单中使用时校验报错
- 304971fc: fix(comp:tabs): 标签页投影样式调整
- faf1aa08: fix(comp:collapse): 折叠面板边框样式调整，收起时使用内阴影，避免影响尺寸
- 31aeef0d: fix(comp:empty): 根据规范更新空状态的尺寸间距
- b7e80f5f: fix(comp:input): 调整 input 输入框删除按钮颜色
- Updated dependencies [9ab15bd4]
- Updated dependencies [2af59f99]
- Updated dependencies [2a3e4504]
- Updated dependencies [ba95de09]
- Updated dependencies [27619a2f]
- Updated dependencies [8197c813]
- Updated dependencies [42a5301a]
- Updated dependencies [db191806]
- Updated dependencies [9ba2738b]
- Updated dependencies [77719cfb]
- Updated dependencies [2ce08330]
- Updated dependencies [4dcd108d]
- Updated dependencies [6e39bddc]
- Updated dependencies [db72cf0e]
- Updated dependencies [6260bb87]
- Updated dependencies [a967b9ce]
- Updated dependencies [9b919361]
- Updated dependencies [59e243b3]
- Updated dependencies [4953065a]
- Updated dependencies [412e46fe]
- Updated dependencies [340fbf0a]
- Updated dependencies [ba60dc70]
- Updated dependencies [d97114b4]
- Updated dependencies [c1256828]
- Updated dependencies [b049d503]
- Updated dependencies [ccb9d0b1]
- Updated dependencies [64b604c2]
- Updated dependencies [ab8d5223]
- Updated dependencies [2068d4e7]
- Updated dependencies [e0667d4d]
- Updated dependencies [afc6eefe]
- Updated dependencies [cc4d2bf2]
- Updated dependencies [6ee618c0]
- Updated dependencies [a3ae5ee0]
- Updated dependencies [b9af929b]
- Updated dependencies [1c5c403a]
- Updated dependencies [f1b494db]
- Updated dependencies [e86f9574]
- Updated dependencies [6533c596]
- Updated dependencies [4fc7947f]
- Updated dependencies [63818025]
- Updated dependencies [0238b816]
- Updated dependencies [eb88cdca]
- Updated dependencies [4b78d4ed]
- Updated dependencies [95ed3396]
- Updated dependencies [974a4171]
- Updated dependencies [72650ffa]
- Updated dependencies [cc37b1aa]
- Updated dependencies [99e5e591]
- Updated dependencies [ba60dc70]
- Updated dependencies [7b2e95ae]
- Updated dependencies [d97114b4]
- Updated dependencies [7875a24a]
- Updated dependencies [c99513d4]
- Updated dependencies [0a66303a]
- Updated dependencies [9099a218]
- Updated dependencies [d2607c2b]
- Updated dependencies [178e5a4b]
- Updated dependencies [33927303]
- Updated dependencies [40e1e10f]
- Updated dependencies [90a1aeb4]
- Updated dependencies [386ea7fa]
- Updated dependencies [b5ad2304]
- Updated dependencies [d2607c2b]
- Updated dependencies [9ae0232d]
- Updated dependencies [d2607c2b]
- Updated dependencies [e692c2cc]
- Updated dependencies [77719cfb]
- Updated dependencies [387fc9b5]
- Updated dependencies [5d247376]
- Updated dependencies [9f3d0c43]
- Updated dependencies [4145c62f]
- Updated dependencies [e19e9265]
- Updated dependencies [fc78b913]
- Updated dependencies [1f45755a]
- Updated dependencies [7d885378]
- Updated dependencies [f53b15b0]
- Updated dependencies [4f470494]
- Updated dependencies [2327d438]
- Updated dependencies [cb7bc047]
- Updated dependencies [fc78b913]
- Updated dependencies [5b6ecb52]
  - @sxf/er-widget@1.0.0
  - @sxf/er-config@1.0.0
  - @sxf/er-style@1.0.0
  - @sxf/er-lib@1.0.0
  - @sxf/er-utils@1.0.0
  - @sxf/er-validator@1.0.0

## 1.0.0-beta.30 (2024-05-13)

### Patch Changes

- 81260b00: fix(comp:time-picker): 修复 time-picker 样式异常
- Updated dependencies [0745dfba]
  - @sxf/er-widget@1.0.0-beta.23

## 1.0.0-beta.29 (2024-05-10)

### Patch Changes

- 2a330f10: fix(input): 修复多行文本计数时存在初始值计数不准确
- c689dd18: fix(comp:radio): 修复表单中多行样式出错
- 11ea98b0: fix:(comp:date-picker): 修复日期选择器初始值为空数组时报错

## 1.0.0-beta.28 (2024-05-08)

### Minor Changes

- f429aced: feat(comp:select): 新增 on-change 事件，用于解决 change 事件触发不准的问题

### Patch Changes

- d5507d98: fix(comp:grid): 分组表头样式居中显示
- Updated dependencies [d5507d98]
- Updated dependencies [b97805ee]
  - @sxf/er-widget@1.0.0-beta.22

## 1.0.0-beta.27 (2024-04-30)

### Patch Changes

- f60330db: fix(comp:select): 修复多选模式下不使用 v-model 时选中回显值顺序错乱
- Updated dependencies [f60330db]
  - @sxf/er-widget@1.0.0-beta.21

## 1.0.0-beta.26 (2024-04-26)

### Patch Changes

- 2a8356ae: fix(comp:combo): 修复多选模式以 tag 显示时，若元素初始不可见导致 tag 宽度溢出的问题
- 2a8356ae: fix(comp:combo): 修复多选标签模式下，标签文本没有绑定 data-tip
- 2a8356ae: fix(comp:select): 修复多选模式以 tag 显示时，若元素初始不可见导致 tag 宽度溢出的问题
- d4faa587: fix(comp:grid): 修复嵌套表格样式被父级的分页表格影响
- 2a8356ae: fix(comp:select): 修复配置 displayField 后 tag 标签显示异常
- Updated dependencies [9f9249ef]
- Updated dependencies [f75d6eba]
- Updated dependencies [9f9249ef]
  - @sxf/er-widget@1.0.0-beta.20

## 1.0.0-beta.25 (2024-04-24)

### Patch Changes

- 64e9078d: fix(comp:date-picker): 修复 timer-ranger-picker 中 sf-space 未注册问题
- a045c058: fix(comp:type-search): 修复 type-search 在表单中使用时校验报错

## 1.0.0-beta.24 (2024-04-21)

### Minor Changes

- 68bda2e9: feat(comp:alert): 更新 info 状态的提示条样式，由灰色改为蓝色
- da632a39: feat(comp:select): 选择器搜索框新增图标，样式调整

### Patch Changes

- eb4c587f: fix(comp:trigger): 调整文件上传的图标
- Updated dependencies [1a5d3dd1]
- Updated dependencies [da632a39]
  - @sxf/er-widget@1.0.0-beta.19

## 1.0.0-beta.23 (2024-04-17)

### Minor Changes

- d01213a3: feat(comp:datepicker): 按照规范重构 date-picker 日期选择器

### Patch Changes

- 9c244892: fix(comp:date-picker): 修复混合日期切换类型时选中错误问题
- Updated dependencies [d01213a3]
- Updated dependencies [33cefc44]
- Updated dependencies [c8273926]
  - @sxf/er-config@1.0.0-beta.10
  - @sxf/er-widget@1.0.0-beta.18

## 1.0.0-beta.22 (2024-04-12)

### Patch Changes

- aaf549a1: fix(comp:grid): 修复表格多选禁用选中项样式错误
- Updated dependencies [21aac2fa]
- Updated dependencies [aaf549a1]
- Updated dependencies [a64cebe9]
- Updated dependencies [18b5fa93]
  - @sxf/er-widget@1.0.0-beta.17
  - @sxf/er-config@1.0.0-beta.9

## 1.0.0-beta.21 (2024-04-11)

### Patch Changes

- 6201ed2c: fix(comp:upload):修复文件类型校验问题

## 1.0.0-beta.20 (2024-04-09)

### Minor Changes

- 10479df0: feat(comp:grid): 表格分页器插件由从 components 包对外导出

  - **Breaking:** Pagingbar 插件无法从 `@sxf/er-widget/grid` 中获取，升级时需要业务同步替换原来的引用路径为 `import { PagingBar } from '@sxf/er-components/grid'`

### Patch Changes

- add69a4d: fix(comp:pagination): 分页器样式调整

  - 默认高度 40px
  - simple 模式下高度为 32px

- 18c20ed7: fix(comp:grid): 修复按需加载场景下表格分页加载 pagination 组件报错
- eb4613c4: refactor(comp:grid): 自定义列插件初始化时机控制，防止初始化时对应的 icon 不存在
- add69a4d: fix(comp:grid): 表格分页器 simple 模式下高度为 32px
- 3e64fa3e: fix(comp:grid): 自定义列悬浮层样式调整
- Updated dependencies [3e64fa3e]
- Updated dependencies [10479df0]
- Updated dependencies [18c20ed7]
- Updated dependencies [add69a4d]
- Updated dependencies [d4237b07]
  - @sxf/er-config@1.0.0-beta.8
  - @sxf/er-widget@1.0.0-beta.16

## 1.0.0-beta.19 (2024-04-03)

### Minor Changes

- 59aa7425: feat(comp:select): select 校验信息绑定元素调整
  feat(comp:combo): combo 校验信息绑定元素调整
- 59aa7425: feat(comp:grid): grid 对外暴露插件 ID
- ed9797e3: feat(comp:tag):tag tpye 字段补充 multiple-select 字段兼容 select 中 tag 样式问题
- 59aa7425: feat(comp:combo): combo 支持多选标签显示模式
- 022cdffd: feat(comp:combo): combo 支持配置新增按钮

### Patch Changes

- e47e98a6: fix(comp:collapse): 优化描边样式，修复折叠面板展开收起时内容抖动
- 4291a921: fix(comp:select): 修复下拉框颜色显示问题
- bd237034: fix(comp:select): 修改选择器分组样式
- 59aa7425: fix(comp:combo): 调整 combo 小尺寸样式
- c6b89a36: fix(comp:tag): 修复部分场景存在 tag 文本不居中的问题
- e47e98a6: fix(comp:collapse): 修复折叠面板箭头方向错误
- ed9797e3: feat(comp:select): tag-size 默认值设置为 normal
- Updated dependencies [022cdffd]
- Updated dependencies [1e25c394]
- Updated dependencies [59aa7425]
  - @sxf/er-config@1.0.0-beta.7
  - @sxf/er-widget@1.0.0-beta.15

## 1.0.0-beta.18 (2024-03-29)

### Patch Changes

- 50d8aabd: fix(comp:input): 修改后置图标的间距并修复删除图标没有居中对齐问题
- 17604aa1: fix(comp:tree): 修复 tree-table 异步加载 loading 样式异常
- a6ae8a21: fix(comp:grid): 分组表格的分组行白色填充，树形表格最后一行显示分割线
- 4c725846: fix(comp:select): 支持 mutiple 非布尔的形式进行设置
- Updated dependencies [932d447c]
  - @sxf/er-style@1.0.0-beta.7

## 1.0.0-beta.17 (2024-03-28)

### Patch Changes

- 328ab6dc: fix(comp:select): 修改 select 的 small 尺寸下的新增按钮样式, 新增对应示例
- 9943c23d: fix(comp:path): 修改面包屑行高
- 88cfd314: fix(comp:grid): 修复嵌套表格样式异常
- Updated dependencies [c613d67e]
  - @sxf/er-config@1.0.0-beta.6

## 1.0.0-beta.16 (2024-03-27)

### Patch Changes

- 7a3560fd: fix(comp:select): 修复 select 组件为为 tag 模式不居中问题
- 70050c7e: fix(comp:select): 按照交互规范修复 select 样式
- 70050c7e: fix(comp:menu): 按照交互规范修复 menu 样式

## 1.0.0-beta.15 (2024-03-27)

### Patch Changes

- 0426315a: fix(comp:select): select 组件为 tag 模式时 tag 尺寸和 select 尺寸保持一致
- 73d9af7d: fix(comp:grid): 嵌套表格收起展开按钮新增 active 状态
- ce665cc5: fix(comp:empty): 根据规范更新空状态元素之间的间距
- 66b5cd79: fix(comp:card): 卡片 paddingTop 仅在无标题时加并去掉不符规范示例
- 73d9af7d: fix(comp:grid): 分组表格展开收起按钮新增 active 状态，且不显示斑马线，分组行白色填充，数据行灰色填充
- 73d9af7d: fix(comp:grid): 树形表格叶子行同样显示分割线；调整 group 行样式以显示被遮挡的连接线；展开收起按钮新增 active 状态

## 1.0.0-beta.14 (2024-03-26)

### Minor Changes

- 99d05ae6: feat(comp:button): button 按钮添加 medium 尺寸
- db1033cd: fix(comp:grid):给 grid 头部支持筛选过滤
- d9c180c3: feat(comp:timepicker): 添加 timePicker 时间选择器
- 7287d0e7: feat(comp:popover): 新增 hiddenFooterSeparator 字段用于隐藏 footer 和 content 之间的分隔线
- 6c2f4143: feat(comp:grid): 添加表格 header 行最后一列的自定义列按钮显示
- c078f73c: feat(comp:grid): 分组表格展开收起按钮单独占用一列
- dca7692b: feat(comp: formCollapse): 折叠表单补充描述文本字段

### Patch Changes

- 29f9b54e: fix(comp:grid-form): 调整下方描述文本和按钮间距处理，不再写成 4px 和默认间距，直接处理为 8px
- 25030f68: fix(comp:select):修改 select 新增按钮样式使其居中，对 select 增加 size 的动态响应
- 0f94b940: fix(comp:input): 更换删除按钮图标并修改该图标的大小和颜色
- ad4e5664: fix(comp:select): 根据交互规范修复 select 样式，文案
- 2867bd2e: feat(comp:mask): mask 支持水平展示
- ad4e5664: fix(comp:menu): 根据交互规范修复 menu 样式
- 927590b5: feat(comp:tree-select): 下拉 tree-select 表格的默认高度改为 32
- d9c180c3: feat(comp:switch): 调整 disabled 状态下的 style
- 188904da: fix(comp:grid): 树形表格同样显示斑马纹
- 3cee043b: fix(comp:radio): 修改 radio-group 按钮置灰时的边框颜色值为 40%的#ccc
- 29f88439: fix(comp:cascader): 修复级联选择器多选时，input 无效触发的问题
- 6c5037f9: fix(comp:timepicker): 修改时间选择器样式
- 21e97acd: fix(comp:grid): 修改分页器高 40px 而不是 39px，normal 尺寸下同理
- abb1c0b4: fix(comp:tree-select): fix the bug that the position is wrong while the height is changed
- 4910cb12: fix(comp:cover-window): 调整底部按钮之间的间距
- e65d886b: feat(comp:mask): 修改 mask 的动画效果
- 0b776906: fix(comp:button): 修改 icon 按钮的 active 颜色和 link 按钮 hover 颜色
- 1f9bc00a: fix(comp:notify): notify 样式修复
- 26c66ab3: fix(comp:form): 表单上下排版样式，间距不对
- 53581415: fix(comp:notify):样式修改
- c078f73c: fix(comp:grid): 修复树形表格点击分组行也会触发 item-select 事件
- 2bb899d8: fix(comp:cascader): 修改 size 为 small 时级联选项高，更正 size 字段的文档描述
- fcbe6aab: fix(comp:select): 下选择器新增按钮底部出现 4px 的留白
- a226cf88: fix(comp:radio): 修改 radio-group 按钮置灰时的边框颜色值-调整变量
- a4fe4f5e: fix(comp:select): 修复多选存在可关闭 tag 时没有居中问题
- 2b5e0c57: fix(comp:tabs): 标签页投影样式调整
- Updated dependencies [1738ab6c]
- Updated dependencies [25030f68]
- Updated dependencies [2867bd2e]
- Updated dependencies [e65d886b]
- Updated dependencies [53581415]
- Updated dependencies [ad4e5664]
- Updated dependencies [d9c180c3]
- Updated dependencies [db1033cd]
- Updated dependencies [99d05ae6]
- Updated dependencies [188904da]
- Updated dependencies [7287d0e7]
- Updated dependencies [93687b6f]
- Updated dependencies [c078f73c]
- Updated dependencies [c078f73c]
- Updated dependencies [c078f73c]
- Updated dependencies [e65d886b]
- Updated dependencies [99f1c815]
- Updated dependencies [81af775c]
  - @sxf/er-widget@1.0.0-beta.14
  - @sxf/er-config@1.0.0-beta.5
  - @sxf/er-style@1.0.0-beta.6

## 1.0.0-beta.13 (2024-03-21)

### Minor Changes

- 2a6215ed: feat(comp:cascader): 新增多选功能
- c7929055: fix(comp:search): SfSearch Props 移除 width 属性

### Patch Changes

- 98e33923: fix(comp:block): 根据设计规范调整卡片样式问题
- a3f7ac88: fix(comp:grid): 表格头部文案与排序图标间距问题,修复表格标题过长且出现排序图标时，表格标题与排序图标之间距离应该为 8px
- 277efac8: feat(comp:grid): store 增加 selectAble 的导出
- 7d047d18: fix(comp:steps): 修复 Steps 组件验收问题（调整标题颜色）

  - 已完成的标题颜色和正在进行中的标题颜色保持一致，为#000000。

- Updated dependencies [84158357]
  - @sxf/er-widget@1.0.0-beta.13

## 1.0.0-beta.12 (2024-03-19)

### Minor Changes

- dee33d80: fix(comp:search): SfSearch Props 增加 width 属性，默认值 = 200
- 4a58309b: feat(comp:input-number): 计数器需要支持切换按钮右侧展示

### Patch Changes

- 5b1b04c9: fix(comp:drawer): 修改抽屉关闭按钮颜色
- dee33d80: fix(comp:search): typeSearch 类型搜索样式调整：增加圆角，修改搜索框宽度
- 83899914: fix(comp:radio): 修改 radio-group 样式查找最后一个 el-radio-button 元素通过 last-of-type 查找
- e6c48c08: fix(comp:cover-window): 全局弹窗底部按改用 large 尺寸按钮
- d9deced9: fix(comp:radio): 修改 radio-group，添加按钮鼠标点击时候的 focus 效果，修改 hover 效果
- 6617153d: fix(comp:path): 修改面包屑路径行高
- a25ac244: fix(comp:tree-select): 调整树选择组件多选效果，使只有多选框有变化，文本颜色和字重不变
- ea65322a: fix(comp:window): 修改对话框关闭按钮颜色
- 403f7a5f: fix(comp:trigger): 调整激活状态下的删除按钮颜色和间距
- 79497e4d: fix(comp:title): 修改带有副标题的标题栏样式
- 403f7a5f: fix(comp:input): 调整 input 输入框删除按钮颜色

## 1.0.0-beta.11 (2024-03-18)

### Minor Changes

- 3496b223: feat(comp:select): 选择器下拉框添加“新增”按钮,调整选择器分组的分割线样式
- 258d553b: feat(comp:search):增加搜索框校验失败样式

### Patch Changes

- 65f6145d: fix(comp:drawer): 抽屉样式验收调整
- 2a72af10: fix(comp:tabs): 按规范调整标签页的样式
- 5d2f06d5: fix(comp: tag): 标签样式调整
- 2948ade0: fix(comp:grid): 导出表格 storeModel 类型、修正表格的 listener 的 store 类型错误
- d327d7ca: fix(style): 修改校验失败字体颜色
- aec1f8b0: fix(comp:\_pro): 修改图标文本样式
- c2ce9cbb: fix(comp:select) 选项浮层上下边距应为 4
- 9a8a0f04: fix(comp:button): 修改按钮 shadow 效果为 inset
- 3349d851: fix(style): 修复小 i 未居中问题
- 853e8e91: fix(comp:tree-select): 树选择样式调整，包括 tree-select 和 tree-table-select
- a8cba2a2: fix(comp:radio): 修复表单内 radio 和 checkbox 的默认高度为 32px
- Updated dependencies [2a72af10]
- Updated dependencies [3496b223]
- Updated dependencies [d327d7ca]
- Updated dependencies [064e2ef1]
- Updated dependencies [3349d851]
- Updated dependencies [853e8e91]
  - @sxf/er-widget@1.0.0-beta.12
  - @sxf/er-style@1.0.0-beta.5
  - @sxf/er-config@1.0.0-beta.4

## 1.0.0-beta.10 (2024-03-15)

### Minor Changes

- 57bd62d3: feat(comp:checkbox): checkbox 添加非空校验
- b18bf6d5: 文本域右下角添加计数

### Patch Changes

- 4db30f00: fix(comp:steps): 修复步骤条图标错误和调整样式
- a2c294fa: fix(comp:tree): 修改树的全展全收和搜索图标颜色，修复树表格全展全收未居中问题
- 0b2e185f: fix(comp:grid): 表头高度问题
- 3dfc9ded: fix(comp:select): 调整带前缀图标的选择器样式
- 58c0075a: fix(comp:cascader): 调整级联选择框选项的默认字体颜色
- 6177cad7: fix(comp:collapse): 修复折叠面板头部边缘区域点击无效的问题
- fe594e9c: fix(comp:button): 调整 button 的边框样式实现
- 6177cad7: fix(comp:collapse): 折叠面板边框样式调整，收起时使用内阴影，避免影响尺寸
- Updated dependencies [4db30f00]
  - @sxf/er-widget@1.0.0-beta.11
  - @sxf/er-validator@1.0.0-beta.1

## 1.0.0-beta.9 (2024-03-13)

### Minor Changes

- 385f76fc: feat(comp): radio 添加非空校验
- 94b8bb46: feat(comp:grid): 表格新增类型 SfGridStoreApiParams
- a436abe1: feat(comp:alert) 告警组件尺寸调整，删除 size 字段
- 96d1de98: feat(comp:list): 新增列表(List)组件

### Patch Changes

- 007b9b5c: fix(comp:\_pro): 修改图标文本样式
- 06a9031e: fix(comp:tag): 取消内投影，可关闭 icon 的左边距设置为 2px
- 5d3a17e7: fix(comp:anchor): 修复锚点组件点击和选中时的字体颜色和气泡填充色

  - 点击和选中时，字体颜色和气泡填充色修改为 Poseidon Blue/D10 #156AD9

- 2ab71c55: fix(comp: separator): 分隔线颜色调整
- c9ac453f: fix(comp:cascader): 修复级联组件库定位异常问题

## 1.0.0-beta.8 (2024-03-11)

### Minor Changes

- d7487a70: feat(comp:progess): 增加进度条右侧图标配置
- 0a3b13b5: feat(comp:grid-form): 添加描述文本配置项和调整描述文本颜色和对齐，文档置灰提示优化

### Patch Changes

- 3ce96289: fix(comp:select): 选择器部分规范问题修改

  - 组件名称由“选择框”重命名为“选择器”，相关示例文案均修改
  - 选项浮层中的选项颜色改为#333
  - 选项浮层搜索框正常状态下边框改为 blue gray L20(#e1e5eb)，hover 改为 blue gray 主色(#ccd2d9)
  - 下拉加载文案改为“加载中...”并左对齐

- 8c297196: fix(comp:alert): 告警提示 success 状态颜色调整，status 与 icon 绑定
- e9c9cd0b: 分隔线色值调整为#EBEDF0
- f4bc459f: fix(comp:upload): 修复英文字母截断问题
- 039d3df0: fix(comp:anchor): 修复锚点组件 Anchor 验收问题

  - 未选中的和选中的锚点字重没有区别，需要修改

  - 鼠标 hover 锚点时，字体颜色值应该为#000000

- 9e11759f: 调整抽屉默认展示宽度以及按钮样式
- e5dfa4ef: fix(comp:carousel): 修改轮播指示器、箭头样式
- 80702653: 告警提示组件插槽容器添加 flex 属性
- 1d759be2: fix(comp:search): 类型搜索分隔线左右边距改为 0px
- 619d2253: fix(comp:alert): 修复告警提示组件 icon 和文本无对齐
- f249357c: fix(comp:tabs): 修改样式来满足 page-tabs 的显示效果
- b296792e: fix(comp:tabs): 调整下划线标签页标题栏高度
- 72e91dbe: fix(comp:tabs): 按规范调整垂直标签页的样式
- 5a6cdb2e: fix(comp:path): 修改面包屑路径样式
- bcc3225a: fix(comp:empty): 根据规范更新空状态的尺寸间距
- Updated dependencies [f4bc459f]
- Updated dependencies [3ce96289]
- Updated dependencies [f249357c]
- Updated dependencies [3ce96289]
- Updated dependencies [68c5d043]
  - @sxf/er-config@1.0.0-beta.3
  - @sxf/er-style@1.0.0-beta.4
  - @sxf/er-widget@1.0.0-beta.10

## 1.0.0-beta.7 (2024-03-07)

### Minor Changes

- c57a6391: feat(comp:tree-select): treeTableSelect 树选择组件新增多选处理
- d95ae0ed: feat(comp:pane): 增加 pane 组件父子节点标识，服务于 page-tabs
- 5d0420d3: steps 步骤条组件新增错误样式

### Patch Changes

- Updated dependencies [d95ae0ed]
- Updated dependencies [c57a6391]
- Updated dependencies [5d0420d3]
  - @sxf/er-widget@1.0.0-beta.9
  - @sxf/er-validator@1.0.0-beta.1

## 1.0.0-beta.6 (2024-03-06)

### Minor Changes

- e1bef167: feat(comp:upload): 增加 upload 组件
- 6ded0919: feat(comp:collapse): 折叠面板规范问题修改

  - 更新样式
  - SfCollapseItem 支持头部完全自定义
  - 移除 theme 配置，无黑色背景
  - 新增 `size` 配置，默认 `'normal'`，可配置为 `'large'`
  - 新增 `bordered` 配置，控制折叠面板样式风格在描边和阴影之间切换

- d47f00d7: feat(comp:anchor): 新增锚点(anchor)组件
- 6746a024: feat(comp:anchor): anchor 组件新增自定义锚点功能以及 demo 和测试用例
- 63974d03: feat(comp:tabs): 标签页新增投影卡片类型

  - `type` 新增 `projection-card` 类型，为无边框的投影卡片标签页

### Patch Changes

- 42213ff4: fix(comp:button): 调整链接按钮的字体颜色
- d4bcb30c: fix(comp:cover-window): 调整全局弹窗底部按钮背景色
- a0f19463: fix(comp:window): 修改对话框样式
- 9441a872: fix(comp:drawer): 修改抽屉关闭按钮样式
- 182517e7: fix(comp:drawer): 修改抽屉关闭按钮样式
- 0481fee7: fix(comp:tabs): 调整标签页不同状态的文本颜色以及 active 标识的颜色
- 76c12277: 修改链接按钮禁用颜色和 icon 按钮 active 颜色
- 07e3045a: fix(comp:grid): 基础表格 small 尺寸取消单元格竖向分割线，调整表头文本颜色，斑马线背景颜色
- 1847c4bf: fix(comp:form): 调整示例中框中表单的尺寸，调整表单中分割线的间距
- 0edfc8c5: fix(comp:checkbox): 修改 checkbox 组件样式问题
- 4c204b1f: fix(comp:window): 修改对话框关闭按钮样式
- Updated dependencies [e1bef167]
- Updated dependencies [a0572afe]
- Updated dependencies [6ded0919]
- Updated dependencies [07e3045a]
- Updated dependencies [63974d03]
  - @sxf/er-config@1.0.0-beta.2
  - @sxf/er-style@1.0.0-beta.3
  - @sxf/er-widget@1.0.0-beta.8
  - @sxf/er-lib@1.0.0-beta.1
  - @sxf/er-utils@1.0.0-beta.1
  - @sxf/er-validator@1.0.0-beta.1

## 1.0.0-beta.5 (2024-03-01)

### Patch Changes

- ad827e75: fix(comp:tag): 修复 Tag 组件 effect 为 light 时标签背景颜色不正确的问题
- bddb57f9: fix(comp:pagination): 分页器上一页、下一页按钮图标替换
- d7bb078d: fix(comp:pagination): 精简型分页器文字样式调整
- 927ae380: fix(comp:step): 修复 Step 组件以下验收问题:

  1. 最后一步的文案区域右边去掉多余边距;
  2. 描述的文案较少时, 需要适配单行显示;
  3. 描述文本字重使用常规 normal;
  4. 已完成的 icon 内的对号替换饱满型(comp-ok-border);

- Updated dependencies [d7bb078d]
- Updated dependencies [38763c7f]
- Updated dependencies [f09b46ad]
  - @sxf/er-config@1.0.0-beta.1
  - @sxf/er-widget@1.0.0-beta.7

## 1.0.0-beta.4 (2024-02-28)

### Minor Changes

- d5accfde: feat(comp:select): 多选选择器增加"全部"选项方式
- 7a6b8ebe: feat(comp:progress): progress 新增分段进度条组件
- c3876755: feat(comp:input-number): input-number 新增计数器组件

### Patch Changes

- e071c5ae: fix(comp:form): 按设计稿修复部分表单显示细节问题

  - 修改表单 FormItem 的 prompt 文本颜色为#666
  - 修改 CheckboxGroup 内部默认间距：15px -> 24px
  - 修改 FormCollapse：size 为 normal 时的字重改为 600；并在文档添加 szie 为 small 的效果展示
  - 修改 Form，当 size 为 small 时，调整外部 padding 为 8px，同样受 padding、tippadding、formitem 的 tip 参数的影响
  - 修改 Form 的 mode 为 detail 时的样式：调整此时的内容文本颜色#000 -> #333；调整上下间距，当 size 为 small 时为 4px，否则为 8px
  - mode 为 detail 新增不同 size 的文档展示

- ecb9d373: fix(comp:tag): 修改 tag 标签组件中 drak-alarm 标签的字体颜色
- 15db2e90: fix(comp:form): 添加必填星号样式和文档，并调整为已配置 required 并且是必填内容才展示

## 1.0.0-beta.3 (2024-01-31)

### Minor Changes

- cafe7732: feat(comp:\*): 更新 @sxf/sf-theme 版本
- 9a55f82d: feat(comp:search): 搜索框将清除功能作为默认配置
- 882f1449: feat(comp:\*): 更新 @sxf/sf-theme 到 "^0.2.4" 版本

### Patch Changes

- 81e988b6: fix(comp:progress): 修复进度条灰度和默认文本颜色不对问题，并添加部分文档
- 46367a05: fix(comp:step): 修复步骤组件弹窗下的布局问题和样式问题
- 943c28fb: fix(comp:step): 修复步骤组件最后一步的样式问题
- 53350bea: fix(comp:progress): 调整微型进度条高度为 3px，添加微型进度条文档
- 8de35749: fix(comp:radio): 单选组 RadioGroup 新增主题文档，并修复 dark 主题下 border 显示问题
- 882f1449: fix(comp:tag): 修复标签组件的样式问题, 增加缺失颜色, 调整 doc 示例
- 1aa7deae: fix(comp:drawer): 补充查看类抽屉的示例，修复操作和查看场景下 drawer 内容区域的边距
- Updated dependencies [cafe7732]
- Updated dependencies [96d997ae]
- Updated dependencies [882f1449]
  - @sxf/er-style@1.0.0-beta.2
  - @sxf/er-widget@1.0.0-beta.6
  - @sxf/er-validator@1.0.0-beta.1

## 1.0.0-beta.2 (2024-01-22)

### Minor Changes

- 3a3977ba: feat(comp:select): SfSelect 支持多选结果以标签显示

### Patch Changes

- ef71407e: fix(comp:checkbox): label 色值统一使用 @sxf/er-style 提供的表单元素 label 变量
- ef71407e: fix(comp:radio): label 色值统一使用 @sxf/er-style 提供的表单元素 label 变量
- ff9bb78c: fix(comp:radio): 按照规范调整单选框 label 色值
- ff9bb78c: fix(comp:checkbox): 按照规范调整复选框 label 色值
  .
- Updated dependencies [3a3977ba]
- Updated dependencies [ff9bb78c]
- Updated dependencies [c088354e]
- Updated dependencies [ef71407e]
  - @sxf/er-widget@1.0.0-beta.5
  - @sxf/er-style@1.0.0-beta.1
  - @sxf/er-validator@1.0.0-beta.1

## 1.0.0-beta.1 (2024-01-18)

### Patch Changes

- 5d0adcae: fix(comp:pagination): 修复 SfPagination change 事件不触发的问题
- 5d0adcae: fix(comp:pagination): 修复页码输入框校验报错
- Updated dependencies [5d0adcae]
- Updated dependencies [5d0adcae]
  - @sxf/er-widget@1.0.0-beta.2
  - @sxf/er-validator@1.0.0-beta.1

## 1.0.0-beta.0 (2024-01-17)

### Major Changes

- 0b0e74eb: chore: init beta version release

### Minor Changes

- 0b0e74eb: feat(comp:grid): 表格 Pagingbar 插件使用 SfPagination 组件
- 65fe3016: feat(comp:input): 输入框组件新增配置 additionalEvent
- 0b0e74eb: feat(comp:pagination): 新增分页器组件

### Patch Changes

- Updated dependencies [0b0e74eb]
- Updated dependencies [0b0e74eb]
  - @sxf/er-widget@1.0.0-beta.0
  - @sxf/er-config@1.0.0-beta.0
  - @sxf/er-lib@1.0.0-beta.0
  - @sxf/er-style@1.0.0-beta.0
  - @sxf/er-utils@1.0.0-beta.0
  - @sxf/er-validator@1.0.0-beta.0

## 0.16.0-scp-6105-patch.2

### Patch Changes

- e467b325: fix(comp:radio): 修复 radio-button beforeChange 拒绝时无法再次触发 change 事件的问题

## 0.16.0-scp-6105-patch.1

### Patch Changes

- d6d603e6: fix(comp:\_utils): 适配 monitor 被取消后，没有返回后台定义的 description 场景

## 0.16.0 (2024-04-21)

### Minor Changes

- 5b8205ec: feat(comp:tree): tree-tabel 支持批量插入子节点数据

### Patch Changes

- Updated dependencies [5b8205ec]
  - @sxf/er-widget@0.16.0

## 0.15.0 (2024-03-29)

### Minor Changes

- ebec205b: feat(comp:tree): treeTable 异步加载重构

  - 解决连续展开子节点可能导致数据丢失的问题
  - 修复连续展开子节点时子节点 loading 状态异常

### Patch Changes

- Updated dependencies [ebec205b]
  - @sxf/er-widget@0.14.0

## 0.14.3 (2024-03-21)

### Patch Changes

- 56b015c8: fix(comp:grid): 给分页添加 options 声明

## 0.14.2 (2024-03-19)

### Patch Changes

- 078f5fbd: fix(comp:grid): 修复表格样式问题
- Updated dependencies [7634bbd0]
  - @sxf/er-config@0.5.1

## 0.14.1 (2024-03-18)

### Patch Changes

- 68feb48b: fix(widget:grid): 修复嵌套表格使用自定义列以及样式问题
- Updated dependencies [68feb48b]
  - @sxf/er-widget@0.13.5

## 0.14.0 (2024-02-29)

### Minor Changes

- 0b654f14: feat(comp:cascader): 级联组件支持配置前缀

### Patch Changes

- 0b654f14: fix(comp:cascader): 修复级联组件搜索时输入特殊字符报错
- 0b654f14: fix(comp:cascader): 级联组件搜索结果为空时显示暂无数据
- Updated dependencies [0b654f14]
  - @sxf/er-config@0.5.0

## 0.13.4 (2024-02-28)

### Patch Changes

- 282bdb97: fix(comp:cascader): 修改级联组件搜索状态的样式及图标
- Updated dependencies
  - @sxf/er-widget@0.13.2

## 0.13.3 (2024-02-23)

### Patch Changes

- f6ac1cd3: fix(hooks): 更新表格多选 Hook 的配置参数定义
- Updated dependencies [fb4444e4]
- Updated dependencies [b670da5e]
- Updated dependencies [fb4444e4]
  - @sxf/er-widget@0.13.1
  - @sxf/er-utils@0.5.1

## 0.13.2 (2024-01-29)

### Patch Changes

- 6d8258b0: fix(widget:messageBox): 修复 jQuery messageBox 内容超长滚动异常的问题
- Updated dependencies [6d8258b0]
- Updated dependencies [a3de0353]
  - @sxf/er-widget@0.12.0

## 0.13.1 (2024-01-23)

### Patch Changes

- bc167ffe: fix(comp:grid): 修复表格在数据为空时没有正确销毁单元格内容
- Updated dependencies [bc167ffe]
- Updated dependencies [33f33ab5]
  - @sxf/er-widget@0.11.5
  - @sxf/er-utils@0.5.0

## 0.13.0 (2024-01-12)

### Minor Changes

- 55fdeeeb: feat(comp:\*): 图标库 peer 依赖由 @sxf/cloud-iconfont 变更为 @sxf/vtv-icon

### Patch Changes

- Updated dependencies [55fdeeeb]
  - @sxf/er-style@0.2.0

## 0.12.2 (2024-01-11)

### Patch Changes

- a8e8d902: fix(comp:switch): 修复 Switch 在某些场景下 value 变动导致控制台报错
- 92bfe351: fix(comp:grid): 修复嵌套表格场景子表格闪动的问题
- Updated dependencies [92bfe351]
- Updated dependencies [78c91e53]
  - @sxf/er-widget@0.11.3
  - @sxf/er-config@0.3.0

## 0.12.1 (2024-01-06)

### Patch Changes

- b0190505: fix(comp:grid): 修复表格在隐藏最后一列时的边框样式问题
- Updated dependencies [b0190505]
  - @sxf/er-widget@0.11.2

## 0.12.0 (2023-12-28)

### Minor Changes

- 24485d8b: feat(comp:grid-form): 表格表单新增配置项 formProps，用于控制表单配置

## 0.11.8 (2023-12-26)

### Patch Changes

- 6bb7ef6e: fix(comp:button): 修复按钮使用 v-popover 指令，禁用模式下 hover 无法显示 popover
- Updated dependencies [20c5906b]
  - @sxf/er-utils@0.4.0

## 0.11.7 (2023-12-23)

### Patch Changes

- b3664c74: fix(comp:grid): 修复表格边框异常
- Updated dependencies [b3664c74]
  - @sxf/er-widget@0.11.1

## 0.11.6 (2023-12-22)

### Patch Changes

- d0657919: 修复 Vetur 自动解析失败的组件

## 0.11.5 (2023-12-19)

### Patch Changes

- f47f194f: fix(comp:input): 修复 number 输入框超出精度后无法删除 Infinity

## 0.11.4 (2023-12-14)

### Patch Changes

- 5dc6f641: fix(comp:checkbox): 调整多行模式样式优先级问题

## 0.11.3 (2023-12-14)

### Patch Changes

- 304ab3e2: fix(comp:checkbox): 修复 checkbox 使用 flex 时 tip 提示在表单场景下错位

## 0.11.2 (2023-12-14)

### Patch Changes

- fbeef66f: fix(comp:checkbox): 修复多行模式无效

## 0.11.1 (2023-12-13)

### Patch Changes

- d670499a: fix(comp:grid): 修复表头在显示 header-tip 时 align 失效

## 0.11.0 (2023-12-08)

### Minor Changes

- c9f5e0cf: feat(comp:\*): jquery 和 Eresh 子包之间的依赖全部声明成 peer

### Patch Changes

- Updated dependencies [c9f5e0cf]
- Updated dependencies [c9f5e0cf]
- Updated dependencies [c9f5e0cf]
- Updated dependencies [c9f5e0cf]
  - @sxf/er-widget@0.11.0
  - @sxf/er-validator@0.2.0
  - @sxf/er-utils@0.3.0

## 0.10.7 (2023-12-06)

### Patch Changes

- 79f2cd38: fix(comp:grid): 修复树形表格列宽较小时在 FireFox 下不显示的问题

## 0.10.6 (2023-12-05)

### Patch Changes

- 2604d75a: fix(comp:\_directives): 修复 popover 指令绑定异常

## 0.10.5 (2023-12-05)

### Patch Changes

- 81f2f61d: fix(comp:button): 修复 button 禁用状态下能触发手动添加的事件
- d8c8b456: fix(comp:radio): 修复 radioGroup 在 small 表单中样式异常
- d8c8b456: fix(comp:checkbox): 修复 checkboxGroup 在火狐下因为 line-height 导致的样式问题
- Updated dependencies [25226739]
  - @sxf/er-widget@0.10.5
  - @sxf/er-validator@0.1.3

## 0.10.4 (2023-12-01)

### Patch Changes

- d16395a3: fix(comp:grid): 修复有边框表格在有分页情况下没有底部边框
- Updated dependencies [175a0336]
- Updated dependencies [fc7f2751]
  - @sxf/er-widget@0.10.4
  - @sxf/er-validator@0.1.3

## 0.10.3 (2023-11-24)

### Patch Changes

- e16e9b10: fix(comp:grid): 修复表头小 i 图标与排序图标重复的问题
- Updated dependencies [55af86e7]
- Updated dependencies [c8d6bb26]
- Updated dependencies [4dd80aab]
- Updated dependencies [f0155cb2]
- Updated dependencies [542ae705]
  - @sxf/er-widget@0.10.1
  - @sxf/er-validator@0.1.2
  - @sxf/er-config@0.2.1
  - @sxf/er-lib@0.1.2
  - @sxf/er-utils@0.2.2

## 0.10.2 (2023-11-20)

### Patch Changes

- a4ee4fbc: fix(comp:tree): 优化 loading 图标旋转效果
- 501455ea: fix(comp:grid): 修复表格合并单元格时部分单元格没有边框、表格固定列在选中情况下背景色与非固定列不一致
- 501455ea: fix(comp: grid): 修复表格固定列在火狐浏览器下样式不兼容的问题
- Updated dependencies [501455ea]
- Updated dependencies [8cabfdb5]
  - @sxf/er-widget@0.10.0

## 0.10.1 (2023-11-16)

### Patch Changes

- 3a22f222: fix(comp:tree): 修复 tree-table 在火狐浏览器下由于宽度不够导致文本显示异常
- ef9793f3: fix(comp:grid): 表格固定列阴影效果只在触发固定效果时显示，调整阴影颜色
- 23f9b660: fix(comp:grid): 解决表格行高继承 body 导致 scc 里单元格行高存在的问题
- bf8d8be5: fix(comp:grid): 修复表格 empty 插槽覆盖单元格内容
- 5a3eab0a: fix(comp:alert): 修复 SfAlert 组件 data-tip 内容异常
- Updated dependencies [ef9793f3]
  - @sxf/er-widget@0.9.1

## 0.10.0 (2023-11-14)

### Minor Changes

- 1ff1d67e: feat(comp:search): SfTypeSearch 支持监听类型变更
- 43ab54d4: feat(comp: tree): tree-tabe 支持节点数据异步加载

### Patch Changes

- Updated dependencies [9cadc3af]
- Updated dependencies [43ab54d4]
  - @sxf/er-widget@0.9.0

## 0.9.0 (2023-11-10)

### Minor Changes

- 76761469: ---

  ## '@sxf/er-components': minor

  feat(components): 让表格 header-tip 的小 i 始终保持展示

### Patch Changes

- f0b5a343: fix(comp:radio): 修复 radio 的 tip 属性不支持多行的问题
- Updated dependencies [76761469]
  - @sxf/er-widget@0.8.0
  - @sxf/er-validator@0.1.2

## 0.8.0 (2023-11-08)

### Minor Changes

- 6c8d95e9: feat(comp:date-picker):日期选择器添加日期选择面板的显示隐藏事件 picker-visible-change

### Patch Changes

- e8270639: fix(comp:button): 修复按钮在 link 模式下悬浮出现两条下划线
- dade9cb6: fix(comp:select): 修复 SfSelect 使用前缀图标无法正确显示部分文本、图标和文本不对齐
- Updated dependencies [dade9cb6]
  - @sxf/er-widget@0.7.1

## 0.7.1 (2023-10-30)

### Patch Changes

- fix(comp:button): 修复按钮文字没有居中

## 0.7.0 (2023-10-27)

### Minor Changes

- 0645a54: feat(comp:search): SfSearch、SfFilter、SfTypeSearch 暴露输入框 clear 事件
- 06d2ee7: feat(comp:empty): tip 支持插槽

### Patch Changes

- 46fe00c: fix(comp:grid): 修复表格在销毁后的空指针异常
- 9a0197c: fix(comp:radio): 修复火狐浏览器下 SfRadioGroup 设置 display: inline-block 后高度异常
- a200581: fix(comp:popover)修复 popover 错误调用 Set 的删除函数
- 564c59f: fix(comp:drawer): 移除 drawer 内部没有必要的阻止事件冒泡行为
- 9a0197c: fix(comp:button): 修复按钮文字与图标没有对齐的问题
- e6ce7fd: fix(comp:\*): 修复 SfSelect, SfCombo, SfTreeSelect 组件 loading 动画问题
- Updated dependencies [e6ce7fd]
  - @sxf/er-style@0.1.1

## 0.6.0 (2023-10-20)

### Minor Changes

- a207a0e: feat(components): 表格 detail 插件新增 expand, expandAll, collapse, collapseAll, getExpandList 的类型

### Patch Changes

- Updated dependencies [e7816b8]
- Updated dependencies [1c89619]
- Updated dependencies [700ab67]
- Updated dependencies [a01675b]
  - @sxf/er-widget@0.7.0
  - @sxf/er-config@0.2.0

## 0.5.6 (2023-10-17)

### Patch Changes

- eed07e8: fix(comp:select): 修复 SfSelect clear 事件报错
- 132875b: fix(comp:input): 修复样式类名错误
- Updated dependencies [61e9910]
- Updated dependencies [61e9910]
- Updated dependencies [15c540c]
  - @sxf/er-widget@0.6.0
  - @sxf/er-lib@0.1.1
  - @sxf/er-validator@0.1.2

## 0.5.5 (2023-10-12)

### Patch Changes

- 2694f08: fix(comp:grid): 表格列的 sortable 配置声明成 boolean
- Updated dependencies [729ac15]
  - @sxf/er-widget@0.5.1
  - @sxf/er-validator@0.1.2

## 0.5.4 (2023-10-07)

### Patch Changes

- 035cc84: fix(comp:date-picker): 修复时间选择组件在表单中使用导致校验报错

## 0.5.3 (2023-09-28)

### Patch Changes

- 572e7426: fix(comp:window): 修复底部按钮 props 传递错误
- d9bcb0d7: fix(comp:input): 兼容输入框传入 type 的校验问题
- Updated dependencies [cdca5348]
  - @sxf/er-utils@0.2.1

## 0.5.2 (2023-09-22)

### Patch Changes

- 8fbca5b: fix(comp:\*): props 类型校验移除 undefined
- 8fbca5b: fix(comp:popover): anchorHide props 类型兼容传入 string
- Updated dependencies [48954f5]
- Updated dependencies [6305306]
  - @sxf/er-utils@0.2.0
  - @sxf/er-validator@0.1.2
  - @sxf/er-widget@0.5.1

## 0.5.1 (2023-09-19)

### Patch Changes

- 5584c3a: fix(comp:select): 修复 Select 修改 v-model 校验失败
- b8e08a6: fix(comp:select): 修复 Select 多选模式下校验失败
- 2d6a903: fix(comp:date-picker): 修复时间选择组件在 SfFilter 中无法获取值
- 1bf60af: fix(comp:grid): 修复表格在指定高度情况下，初始化时隐藏高度为 0 导致数据无法渲染

## 0.5.0 (2023-09-11)

### Minor Changes

- 458272b: feat: 表格新增不可选的行内提示

### Patch Changes

- 458272b: fix: 修复 combo 传入多选插件的判断问题
- 4545baa: fix(comp:\*): 修复表单元素调用 onValidate 无效的问题
- 15eafb4: fix(comp:nav-menu): 修复页面跳转时 NavMenu 未激活对应 item 问题
- Updated dependencies [458272b]
  - @sxf/er-widget@0.4.0

## 0.4.5 (2023-09-06)

### Patch Changes

- 5bc8c14: fix(comp:grid): 修复表格自定义列插件在没有必选列时报错；修复非分组模式下列选项鼠标悬浮时高度异常

## 0.4.4 (2023-09-04)

### Patch Changes

- Updated dependencies [d095c5a]
  - @sxf/er-validator@0.1.1

## 0.4.3 (2023-09-01)

### Patch Changes

- 87c9f37: fix(comp:\*): 修复 SfRadioGroup SfCheckBoxGroup 在 SfForm inline 模式下 Firefox 浏览器中样式异常的问题
- 41e5fae: fix(comp:input): 修复输入框在初始值是 undefined 和 null 时错误校验

## 0.4.2 (2023-08-31)

### Patch Changes

- 0c02e4f: fix: 级联组件、日期选择组件中移除 jsx 写法
- fab2524: fix: 表单项从禁用改为不禁用时不触发校验

## 0.4.1 (2023-08-29)

### Patch Changes

- 9ce824f: fix(comp:menu): 修复 menu 没有初始目标对象时使用 setTarget 报错
- eeb9d20: fix(comp:input): 修复 input 配置 can-clear 清除图标显示位置错误
- 7b6815c: fix(comp:search): 修复 type-search border 样式问题
- 7bc8b3e: feat(comp:menu) 新增 appendToBody 属性

## 0.4.0 (2023-08-18)

### Minor Changes

- b597743: build: er-config 和 er-style 改为 peer 依赖

### Patch Changes

- Updated dependencies [b597743]
  - @sxf/er-validator@0.1.0
  - @sxf/er-widget@0.3.0
  - @sxf/er-utils@0.1.0
  - @sxf/er-lib@0.1.0

## 0.3.0 (2023-08-17)

### Minor Changes

- 23eda20: feat(comp:\*): 组件支持前缀注册

### Patch Changes

- 35b823e: fix(comp:combo): 修复 comboGrid 动态修改列 hidden 报错
- Updated dependencies [23eda20]
  - @sxf/er-config@0.1.0

## 0.2.0 (2023-08-09)

### Minor Changes

- 1ceb6fa: feat(comp:path):支持配置面包屑没有最小宽度

### Patch Changes

- ff6a7e0: fix(comp:popover): 修复 popover 需要双击才能打开

## 0.1.1 (2023-07-27)

### Patch Changes

- 12ef3ec: fix(comp:drag): 修复 drag 组件 drop 事件失效的问题

  详细：drag 组件 drop 事件实现依赖于对 Dragula 源码的修改
  且业务中以及组件内部实现上都有用到
  所以恢复内置魔改过的 Dragula，drag 组件恢复 beforeDrop 回调函数

- c8162dd: fix(comp:step): 修复 step 在动态切换显示的场景下不正常的情况

  1. 覆盖两个场景，配置 `hidden` 与 `v-if` 类的情况

  2. 原先 step 变化的时候部分值没有重置，导致有问题

- Updated dependencies [c8162dd]
  - @sxf/er-widget@0.2.5
  - @sxf/er-validator@0.0.19

## 0.1.0 (2023-07-26)

### Minor Changes

- 7110d95: feat(comp:progress):新增进度条边框样式-新增 progress 配置项 borderStyle 边框可设置虚线型等

### Patch Changes

- dbb94fa: feat(comp:window): 新增 getContainer prop
- f8993e3: feat(comp:\*): 补充部分类型定义

  - tree-select
  - steps

- 59df304: feat(comp:window): 新增 autoMask 属性，控制是否显示弹窗遮罩
- 6fd362a: feat(comp:path): path 新增 beforeLeave 钩子，用于控制页面是否跳转
- Updated dependencies [dbb94fa]
- Updated dependencies [e7b0bf4]
- Updated dependencies [a9f8da5]
  - @sxf/er-widget@0.2.4
  - @sxf/er-validator@0.0.18

## 0.0.31 (2023-07-12)

### Patch Changes

- fd66168: fix: pkg 中的依赖补全
- Updated dependencies [fd66168]
  - @sxf/er-validator@0.0.17
  - @sxf/er-widget@0.2.3
  - @sxf/er-lib@0.0.5

## 0.0.30 (2023-07-11)

### Patch Changes

- 5f48871: feat: 修改 workspace 依赖包版本
- Updated dependencies [696bcb1]
- Updated dependencies [5f48871]
  - @sxf/er-widget@0.2.1
  - @sxf/er-validator@0.0.15
  - @sxf/er-utils@0.0.15

## 0.0.29 (2023-07-10)

### Patch Changes

- Updated dependencies [ce56585]
  - @sxf/er-widget@0.2.0

## 0.0.28 (2023-07-06)

### Patch Changes

- 4be47e3: fix: 打包样式保留变量
- Updated dependencies [4be47e3]
  - @sxf/er-style@0.1.0

## 0.0.27 (2023-07-05)

### Patch Changes

- Updated dependencies [2eb4bbd]
  - @sxf/er-widget@0.1.1

## 0.0.26 (2023-06-28)

### Patch Changes

- 9ba3d17: fix: 修改 ajax 的实例判断

  针对子应用非共享包的场景，不能使用 instanceof 的判断

- abf64a7: fix(comp:input): 修复输入框只设置校验状态时报错
- Updated dependencies [9ba3d17]
- Updated dependencies [ee3c4ff]
  - @sxf/er-widget@0.1.0
  - @sxf/er-utils@0.0.14

## 0.0.25 (2023-06-09)

### Patch Changes

- 4701fcb: feat: 添加 module 字段导出
- Updated dependencies [c979fa4]
- Updated dependencies [4701fcb]
  - @sxf/er-widget@0.0.23
  - @sxf/er-validator@0.0.14
  - @sxf/er-config@0.0.9
  - @sxf/er-utils@0.0.13

## 0.0.24 (2023-06-08)

### Patch Changes

- 6195e40: fix(comp:\*): 修复组件问题

  - SfCascader: 禁用项支持配置 tip 显示
  - SfGrid: 修复 CheckSelection 插件在有禁用勾选项时，表头顶部勾选框失效的问题

- Updated dependencies [20e9830]
- Updated dependencies [6195e40]
  - @sxf/er-widget@0.0.21

## 0.0.23 (2023-06-02)

### Patch Changes

- bd9f87d: feat(comp:\*): 表单项组件 getValue,setValue 方法实现

  - SfChecBox
  - SfInput
  - SfRadioGroup SfRadioSwitch
  - SfSelect

- f67c724: refactor(comp:form): 移除一些废弃属性

  1.  error - 没使用到的属性
  2.  validateStatus - 没使用到的属性

- 01f7268: fix(comp:select): select 组件校验改为通过 value 事件触发
- 0b3c1b4: fix(comp:window): 修复 MessageBox 默认校验密码问题
- bbe548e: fix(comp:select): 修复多选模式下 setValue 无法更新 v-model
- Updated dependencies [bd9f87d]
- Updated dependencies [01f7268]
- Updated dependencies [bbe548e]
  - @sxf/er-widget@0.0.20

## 0.0.22 (2023-05-31)

### Patch Changes

- 9552b17: fix(comp:\*): 优化部分样式优先级影响问题

  去掉强依赖外部 css 加载顺序的情况

  1. select 组件配置图标时候的 font-size
  2. cover-window 组件去掉 maintain 配置，已经没用的了

- 44dc306: fix: 修复表头和内容错位的问题
- Updated dependencies [44dc306]
  - @sxf/er-widget@0.0.19

## 0.0.21 (2023-05-25)

### Patch Changes

- 6e981d7: fix: 补齐下拉框的 loading 状态
- 93d6d5b: fix(comp:\*): 修复 jsx 构建时没有 h 的问题
- Updated dependencies [21629e5]
- Updated dependencies [6e981d7]
  - @sxf/er-utils@0.0.12
  - @sxf/er-style@0.0.7

## 0.0.20 (2023-05-25)

### Patch Changes

- d255bc4: fix(comp:form): 在 keep-alive 包裹下，未激活状态不应该校验
- 1fc78de: fix(comp:input): 修复输入框不在表单中使用时输入报错的问题
- Updated dependencies [c54c7c0]
  - @sxf/er-widget@0.0.17

## 0.0.19 (2023-05-17)

### Patch Changes

- 957deb4: fix(comp:form): 修复箭头函数导致的参数问题
- Updated dependencies [0407920]
- Updated dependencies [19a3fd0]
  - @sxf/er-widget@0.0.15

## 0.0.18 (2023-05-17)

### Patch Changes

- 5da549e: fix(comp:trigger): 修改 uploadTrigger 的命名
- Updated dependencies [8f767b9]
  - @sxf/er-widget@0.0.14

## 0.0.17 (2023-05-16)

### Patch Changes

- 800ea0a: fix(comp:form): 修复表单组件动态修改 disable 时校验规则不更新的问题
- Updated dependencies [800ea0a]
- Updated dependencies [62f2915]
  - @sxf/er-validator@0.0.13
  - @sxf/er-utils@0.0.11

## 0.0.16 (2023-05-15)

### Patch Changes

- e4dab5f: refactor(comp:window): 完善组件的测试用例，重构掉 mgr
- 25abf45: refactor(comp:form): 表单校验重构

  - SfForm 取消绑定 vtype，实现脱离 dom 元素校验
  - 各表单组件校验失败的红显逻辑放在组件内部实现

- Updated dependencies [e4dab5f]
- Updated dependencies [57f95f2]
- Updated dependencies [33935a7]
- Updated dependencies [33935a7]
- Updated dependencies [25abf45]
- Updated dependencies [e4dab5f]
  - @sxf/er-widget@0.0.13
  - @sxf/er-validator@0.0.12
  - @sxf/er-utils@0.0.10

## 0.0.15 (2023-05-12)

### Patch Changes

- 0cdf70d: fix(comp:select): 修复样式间距问题
- a119fa7: feat: before 之类的钩子，兼容 Promise 返回值

  - drawer: beforeClose
  - coverWindow: beforeSubmit, beforeCancel, beforeHide
  - window: beforeSubmit, beforeCancel
  - poppover: beforeSubmit,
  - navMenu: before,
  - select: beforeSelect
  - tree: beforeSelect
  - step: before

- 578058d: fix(comp:grid): 修复 type 定义问题
- Updated dependencies [168fc4e]
- Updated dependencies [a119fa7]
- Updated dependencies [73a6082]
- Updated dependencies [3513bd3]
- Updated dependencies [a119fa7]
  - @sxf/er-widget@0.0.12
  - @sxf/er-utils@0.0.9
  - @sxf/er-validator@0.0.11

## 0.0.14 (2023-04-23)

### Patch Changes

- Updated dependencies [1a21a99]
  - @sxf/er-widget@0.0.11

## 0.0.13 (2023-04-23)

### Patch Changes

- 4956304: fix: 修复 tabs 组件初始化报错的问题

## 0.0.12 (2023-04-23)

### Patch Changes

- 7e2d09e: refactor(comp:Steps): Steps 组件配置 widget 修改，显式调用 jQuery 插件 steps
- Updated dependencies [7e2d09e]
- Updated dependencies [7e2d09e]
- Updated dependencies [7e2d09e]
  - @sxf/er-validator@0.0.10
  - @sxf/er-widget@0.0.10
  - @sxf/er-config@0.0.7
  - @sxf/er-utils@0.0.8

## 0.0.11 (2023-04-21)

### Patch Changes

- 65b3ac2: fix(comp:\*): 修复几个样式问题

  1. alert 组件加上 border-box
  2. 表格的 tree 插件由于 tpl 文件改成了模板字符串，额外增加了空白符，添加样式消除空白符的影响

- Updated dependencies [dc8a33f]
  - @sxf/er-validator@0.0.10

## 0.0.10 (2023-04-21)

### Patch Changes

- 87d27cc: fix: 修复依赖 i18n 初始化的问题
- 67de488: fix: 修复一些问题

  - 修复表格 col 元素导致的树表格宽度异常
  - 修复表格 group 由于覆盖 store 的 initDataHash 导致数据重新加载时勾选项丢失的问题
  - widget/grid 新增 isPluginExist 方法用于判断插件列表中是否存在指定插件
  - widget/grid/plugins 中各个插件构造函数上新增 pluginId 属性
  - 同步 vt 组件库嵌套子表格相关更改

- Updated dependencies [87d27cc]
- Updated dependencies [67de488]
  - @sxf/er-validator@0.0.9
  - @sxf/er-widget@0.0.9

## 0.0.9 (2023-04-18)

### Patch Changes

- 731f76c: fix: 修复一些问题

  - 指定 layer props autoScrollbar 默认值为 undefined
  - setInputLimit 增加传参
  - 删除移动到业务的样式文件
  - 补充 SfButton 组件样式

- Updated dependencies [731f76c]
  - @sxf/er-widget@0.0.8

## 0.0.8 (2023-04-18)

### Patch Changes

- dacfcc8: fix(comp:\_utils): 修复 nprogress 的样式问题
- 0d4aa26: refactor(comp:\*): 补充全局类型$isDestroyed
- Updated dependencies [047cc95]
- Updated dependencies [27b7cda]
  - @sxf/er-validator@0.0.8
  - @sxf/er-style@0.0.6

## 0.0.7 (2023-04-17)

### Patch Changes

- 3cd787b: refactor(comp: \*): 补充部分类型定义

  - nav-menu 补充部分类型定义
  - grid 对外暴露插件配置项类型定义
  - 补充 grid 插件 CustomColumn 配置项类型定义

- b1158d4: fix: 修复全局配置的类型定义
- Updated dependencies [b1158d4]
  - @sxf/er-config@0.0.6
  - @sxf/er-utils@0.0.7
  - @sxf/er-validator@0.0.7
  - @sxf/er-widget@0.0.7

## 0.0.6 (2023-04-14)

### Patch Changes

- Updated dependencies [9e25dc7]
- Updated dependencies [64edf2c]
  - @sxf/er-utils@0.0.6
  - @sxf/er-style@0.0.5
  - @sxf/er-validator@0.0.6
  - @sxf/er-widget@0.0.6

## 0.0.5 (2023-04-13)

### Patch Changes

- 80ecd83: fix: 修复构建 external 问题
- Updated dependencies [eefe9b7]
- Updated dependencies [80ecd83]
  - @sxf/er-style@0.0.4
  - @sxf/er-config@0.0.5
  - @sxf/er-utils@0.0.5
  - @sxf/er-validator@0.0.5
  - @sxf/er-widget@0.0.5

## 0.0.4 (2023-04-12)

### Patch Changes

- eab5ae6: refactor: 提供业务的全局配置接口

  1. `globalConfig.search` 参数对组件全覆盖
  2. 业务中使用到了的 `$.searchInputLimit` 放到 `trigger` 组件来注册
  3. 表格 `headerCeilTip`
  4. `validator` 包提供 `extendValidator` 方法扩展 `vtype`

- 9dedad4: feat: 新增部分 types，满足 hooks 包的依赖
- dfce2dc: refactor: 优化部分代码

  1. 去除 VMP.router，在 globalConfig.router 配置
  2. 依赖外层的 #body 容器，改成 globalConfig.rootContainer
  3. props 明确类型定义

- dd9c426: feat(comp:\*): 添加常用的类型提示文件
- 2ca83d3: refactor(comp:\*): 加上 form 的 type 类型
- Updated dependencies [bde581a]
- Updated dependencies [3deb7f3]
- Updated dependencies [9876ea5]
- Updated dependencies [0e57fc4]
- Updated dependencies [eab5ae6]
- Updated dependencies [9dedad4]
- Updated dependencies [dfce2dc]
- Updated dependencies [c769e65]
- Updated dependencies [95ce2b0]
- Updated dependencies [be1fa10]
- Updated dependencies [00e2312]
- Updated dependencies [5596dff]
- Updated dependencies [dfce2dc]
  - @sxf/er-utils@0.0.4
  - @sxf/er-widget@0.0.4
  - @sxf/er-validator@0.0.4
  - @sxf/er-config@0.0.4

## 0.0.3 (2023-04-03)

### Patch Changes

- a40d6d1: fix: 构建的 css 名称错误
- c08a1e1: fix: 修复图片打包问题，移除没有用的样式
- 2065057: fix(comp:\_global): 修复 destroy 中 $props 不存在的问题
- 1daafc1: refactor: 去除所有的全局 VMP 与 install 接口
- 419340c: refactor: 将所有获取国际化词条的配置内容不在初始化执行
- 6759898: fix(comp:button): 修复 btn 的 loading 图片
- 0b96e14: refactor(validator:\*): validator 对外暴露 utils/verify

  - 原 `validator/utils/validate` 重命名为 `validator/utils/verify`
  - `@er/components/_utils/popper` 对外暴露 `PopperJS` 源码

- 6d928ef: fix: 修复配置修改导致的错误
- Updated dependencies [f467d2f]
- Updated dependencies [c08a1e1]
- Updated dependencies [1daafc1]
- Updated dependencies [419340c]
- Updated dependencies [0b96e14]
- Updated dependencies [6d928ef]
  - @sxf/er-validator@0.0.3
  - @sxf/er-config@0.0.3
  - @sxf/er-utils@0.0.3
  - @sxf/er-style@0.0.3
  - @sxf/er-widget@0.0.3

## 0.0.2 (2023-03-29)

### Patch Changes

- release
- Updated dependencies
  - @sxf/er-config@0.0.2
  - @sxf/er-style@0.0.2
  - @sxf/er-utils@0.0.2
  - @sxf/er-validator@0.0.2
  - @sxf/er-widget@0.0.2

## 0.0.1 (2023-03-29)

### Patch Changes

- chore: release
- Updated dependencies
  - @sxf/er-config@0.0.1
  - @sxf/er-style@0.0.1
  - @sxf/er-utils@0.0.1
  - @sxf/er-validator@0.0.1
  - @sxf/er-widget@0.0.1
