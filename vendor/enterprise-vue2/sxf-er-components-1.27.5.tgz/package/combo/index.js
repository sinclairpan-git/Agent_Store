import $ from 'jquery';
import { componentName } from '@sxf/er-components/_const';
import { vOnShow } from '@sxf/er-components/_directives';
import { MultipleSelectMixin } from '@sxf/er-components/_mixins';
import { isPropEnabled } from '@sxf/er-components/_utils/vue-utils';
import { SfButton } from '@sxf/er-components/button';
import { FormFieldMixin, FormSizeMixin } from '@sxf/er-components/form';
import { SfGrid, gridPluginId, SfGridColumn } from '@sxf/er-components/grid';
import { SfSpace } from '@sxf/er-components/space';
import { SfTag } from '@sxf/er-components/tag';
import { $i } from '@sxf/er-config';
import { getPrefixedClassName } from '@sxf/er-feature';
import ComboGrid from '@sxf/er-widget/comboGrid';
const methods = Object.keys(ComboGrid.prototype).reduce(function(map, name) {
  if (typeof ComboGrid.prototype[name] === "function" && name !== "constructor") {
    map[name] = function() {
      return this.combo && this.combo[name].apply(this.combo, arguments);
    };
  }
  return map;
}, {});
var Combo = {
  name: componentName.combo,
  componentName: componentName.combo,
  mixins: [FormFieldMixin, FormSizeMixin, MultipleSelectMixin],
  extends: SfGrid,
  props: {
    displayField: true,
    autoLoad: {
      default: true
    },
    autoSelectFirst: {
      default: true
    },
    autoClear: {
      default: true
    },
    disabled: true,
    listParent: true,
    value: true,
    placeholder: true,
    searchPlaceholder: {
      type: String,
      default: () => $i("scp.vt_component.common.widget.ComboGrid.search_input_placeholder")
    },
    processData: Function,
    size: String,
    notHideTargets: {
      type: Array,
      default: () => []
    },
    defaultOptions: {
      default: () => ({
        minHeight: 120
      })
    },
    showAddBtn: {
      type: Boolean,
      default: false
    },
    clearable: {
      type: Boolean,
      default: false
    }
  },
  directives: {
    "on-show": vOnShow
  },
  computed: {
    isDisabled() {
      return isPropEnabled(this.disabled);
    },
    isClearable() {
      return isPropEnabled(this.clearable);
    },
    disabledStatus() {
      return this.isDisabled;
    },
    multiple() {
      var _a;
      return (_a = this.options.plugins) == null ? void 0 : _a.find((item) => {
        if (typeof item === "string") {
          return item === gridPluginId.checkSelection;
        }
        return item.pluginID === gridPluginId.checkSelection;
      });
    },
    invisibleTagsCount() {
      var _a, _b;
      if (!((_a = this.currentValue) == null ? void 0 : _a.length)) {
        return 0;
      }
      return ((_b = this.currentValue) == null ? void 0 : _b.length) - this.safeTagNumber;
    },
    tagContainerRefName() {
      return "tagContainer";
    },
    tagNumberCeil() {
      var _a, _b;
      return (_b = (_a = this.currentValue) == null ? void 0 : _a.length) != null ? _b : 0;
    }
  },
  watch: {
    isDisabled: function(value) {
      if (value) {
        this.disable();
        this.clearValidateState();
      } else {
        this.enable();
        this.updateValidate();
        this.clearValidateState();
      }
    },
    isClearable: function(value) {
      this.toggleClearable(!!value);
    },
    value() {
      this.combo.setValue(this.value);
      this.combo.updateData(this.value);
    },
    options() {
      this.combo.destroy();
      this.grid.destroy();
      this.__init();
    },
    placeholder(v) {
      this.combo.setPlaceholder(v);
    },
    notHideTargets(v) {
      this.combo.options.notHideTargets = v;
    },
    currentValue() {
      this.updateView();
      if (this.shouldTagBeResponsive) {
        this.safeTagNumber = 0;
        this.$nextTick(() => this.calcMaxSafeTagNumber());
      }
    }
  },
  data() {
    return {
      currentValue: []
    };
  },
  methods: $.extend({}, methods, {
    getFullUtid(utidBase) {
      return this.$attrs.utid ? `${this.$attrs.utid}-${utidBase}` : utidBase;
    },
    __init() {
      var _a;
      const vm = this;
      const plugins = ((_a = this.options) == null ? void 0 : _a.plugins) || [];
      plugins.forEach((item) => {
        var _a2;
        if ((item == null ? void 0 : item.pluginID) === gridPluginId.group) {
          item.isHideGroupColumnWhenNoGroup = (_a2 = item.isHideGroupColumnWhenNoGroup) != null ? _a2 : true;
        }
      });
      let $listParent = this.listParent;
      if (!$listParent || $listParent.size()) {
        const $container = $(this.$el).closest(".sf-layer-locate-container");
        if ($container.size()) {
          $listParent = $container;
        }
      }
      vm.combo = new ComboGrid({
        width: "100%",
        disabled: vm.isDisabled,
        autoClear: vm.autoClear,
        autoSelectFirst: vm.autoSelectFirst,
        displayField: vm.displayField,
        autoLoad: vm.autoLoad,
        listParent: $listParent,
        gridConfig: vm._createGridOptions(),
        selectID: this.fieldSelectorID,
        searchPlaceholder: this.searchPlaceholder,
        data: this.value,
        placeholder: this.placeholder,
        processData: this.processData,
        size: this.currentSize,
        notHideTargets: this.notHideTargets,
        clearable: this.clearable,
        utid: this.$attrs.utid
      });
      vm.grid = vm.combo.grid;
      vm._bindGridEvent();
      [
        "load",
        "select",
        "unselect",
        "change",
        "selectall",
        "unselectall",
        "value",
        "input",
        "collapse",
        "expand",
        "clear"
      ].forEach(function(eventName) {
        vm.combo.on(eventName, function() {
          const args = $.makeArray(arguments);
          vm.$emit.apply(vm, [eventName, ...args]);
          if (eventName === "change") {
            vm.validate();
          }
          if (eventName === "value") {
            const [{ data }] = args;
            vm.currentValue = data;
          }
        });
      });
      vm.combo.render(vm.$refs.grid);
    },
    __getColumnChildren: function() {
      return this.$children.filter((child) => {
        return child.$options.componentName === componentName.comboColumn;
      });
    },
    getData() {
      return methods.getValue.apply(this, arguments);
    },
    setData() {
      return methods.setValue.apply(this, arguments);
    },
    getValue() {
      return this.getData().map((item) => {
        return item[this.getIdProperty()];
      });
    },
    setValue() {
      this.setData.apply(this, arguments);
    },
    reset(force) {
      methods.abort.apply(this, arguments);
      if (!force && this.autoSelectFirst) {
        this.selectFirst();
        return;
      }
      this.setValue([]);
      this.clearValidateState();
    },
    onValidate(ret) {
      this.setValidateState(ret);
    },
    processRule(rule) {
      const self = this;
      rule.getFieldValue = function() {
        return String(self.getValue());
      };
      return rule;
    },
    bindInvalidCls(invalidCls, toggle) {
      const target = this.combo.getComboEl().children(".sfis-combogrid-input");
      if (toggle) {
        target.addClass(invalidCls);
      } else {
        target.removeClass(invalidCls);
      }
    },
    bindValidateHintOptions(hintOptions) {
      const target = this.combo.getComboEl();
      target.attr(hintOptions);
    },
    clearValidateState() {
      this.setValidateState(true);
    },
    checkValidateEnabled(enable) {
      return !this.isDisabled && enable;
    },
    enable() {
      methods.enable.apply(this, arguments);
      SfGrid.methods.enable.apply(this, arguments);
    },
    disable() {
      methods.disable.apply(this, arguments);
      SfGrid.methods.disable.apply(this, arguments);
    },
    toggleClearable() {
      methods.toggleClearable.apply(this, arguments);
    },
    checkIsDisabled() {
      return this.isDisabled;
    },
    renderTags(createElem) {
      const records = this.getSelectedRecords() || [];
      const displayField = this.displayField;
      const tags = records.slice(0, this.safeTagNumber).map((item) => {
        return this.renderTag(createElem, {
          data: item.data,
          label: item.data[displayField],
          closeable: !item.disabled
        });
      });
      const moreTag = this.renderMoreTag(createElem);
      return createElem(
        "div",
        {
          class: [getPrefixedClassName("sfis-combogrid-tag-container")],
          on: {
            click: () => {
              if (!this.isDisabled) {
                this.toggle.call(this.combo);
              }
            }
          },
          ref: this.tagContainerRefName
        },
        [
          createElem(
            SfSpace,
            {
              props: {
                size: 2,
                inline: true,
                align: "center"
              },
              style: {
                height: "100%"
              }
            },
            [...tags, ...moreTag]
          )
        ]
      );
    },
    renderMoreTag(createElem) {
      if (this.invisibleTagsCount > 0) {
        return [this.renderTag(createElem, { closeable: false, label: `+${this.invisibleTagsCount}...` })];
      }
      return [];
    },
    renderTag(createElem, options) {
      const { closeable, data, label } = options;
      return createElem(
        SfTag,
        {
          props: {
            closeable,
            size: this.tagSize,
            type: this.tagType
          },
          on: {
            close: () => this.unSelect(data)
          }
        },
        [this.renderTagLabel(createElem, label)]
      );
    },
    renderTagLabel(createElem, label) {
      return createElem(
        "span",
        {
          style: this.tagLabelStyle,
          class: ["ellipsis"],
          attrs: {
            "data-tip": label
          }
        },
        [label]
      );
    },
    updateView() {
      if (this.isTagMode) {
        this.updateInputEl();
      }
    },
    updateInputEl() {
      this.$nextTick(() => {
        if (this.currentValue.length) {
          this.combo.setInputElValue("");
          this.combo.setPlaceholder("");
        } else {
          this.combo.setPlaceholder(this.placeholder);
        }
      });
    },
    renderComboFooter(createElem) {
      if (this.showAddBtn) {
        return this.renderAddBtn(createElem);
      }
      return null;
    },
    renderAddBtn(createElem) {
      return createElem(
        "div",
        {
          class: {
            [getPrefixedClassName("sfis-combogrid-add-btn-container")]: true,
            [getPrefixedClassName("sfis-combogrid-add-btn-container--small")]: this.size === "small"
          }
        },
        [
          createElem(
            SfButton,
            {
              props: {
                icon: "add",
                size: "small"
              },
              on: {
                click: () => this.$emit("on-add")
              },
              attrs: {
                utid: this.getFullUtid("sf-combo-add-item-btn")
              }
            },
            [$i("scp.vt_component.common.widget.ComboGrid.add_option_item_btn")]
          )
        ]
      );
    }
  }),
  render(createElem) {
    const grid = SfGrid.render.call(this, createElem);
    if (this.isTagMode) {
      const tags = this.renderTags(createElem);
      return createElem(
        "div",
        {
          class: [getPrefixedClassName("sfis-combogrid-wrapper")],
          directives: [
            {
              name: "on-show",
              value: this.tagController
            }
          ]
        },
        [grid, tags]
      );
    }
    return grid;
  },
  mounted() {
    var _a;
    if (this.isTagMode) {
      (_a = this.combo.getComboEl()) == null ? void 0 : _a.append(this.$refs[this.tagContainerRefName]);
    }
  },
  beforeDestroy: function() {
    var _a, _b;
    if ((_a = this.combo) == null ? void 0 : _a.destroy) {
      this.combo.destroy();
    }
    if ((_b = this.grid) == null ? void 0 : _b.destroy) {
      this.grid.destroy();
    }
    this.combo = null;
    this.grid = null;
  }
};
var ComboColumn = {
  name: componentName.comboColumn,
  componentName: componentName.comboColumn,
  extends: SfGridColumn,
  computed: {
    grid() {
      let parent = this.$parent;
      while (parent && parent.$options.componentName !== componentName.combo) {
        parent = parent.$parent;
      }
      return parent;
    }
  }
};
export { Combo as SfCombo, ComboColumn as SfComboColumn };
