import type { SfGridColumn, SfGridMethods } from '@sxf/er-components/grid/types';

export interface SfComboProps {
  /**
   * 设置需要显示的数据域
   */
  displayField: string;

  /**
   * 是否自动加载数据
   *
   * @default true
   */
  autoLoad: boolean;

  /**
   * 在ajax的情况下，加载后，如果没有值则自动选择第一项
   *
   * @default true
   */
  autoSelectFirst: boolean;

  /**
   * 在ajax的情况下，自动清除不合法的数据
   *
   * @default true
   */
  autoClear: boolean;

  /**
   * 是否禁用下拉框
   */
  disabled: boolean;
}

export interface SfComboEvents<T = any> {
  /**
   * 组件选中项发生变化时触发
   *
   * @param selectedData 选中的数据项
   */
  $emit(eventName: 'change', selectedData: T[]): this;
}

export interface SfComboMethods<T = any> extends SfGridMethods<T> {
  /**
   * 获取组件选中的数据项，返回一个对象数组：[{}, {}, {}...]
   */
  getData(): T[];

  /**
   * 获取组件选中的idProperty对应的值
   */
  getValue(): string[];

  /**
   * 设置当前选中项，设置之后显示在input框上面，设置为空数组可以清空当前的选中，形式支持：
   * 1、{id: 'id', name: 'name'}
   * 2、[{id: 'id', name: 'name'}, {id: 'id', name: 'name'}, ...]
   * 3、['id1', 'id2'...]
   * 4、'id'
   */
  setData(newData: T[] | T | string[] | string): void;

  /**
   * 同 `setData`
   */
  setValue(newData: T[] | T | string[] | string): void;

  /**
   * 设置值为组件初始值，没有默认选择第一个，则是清空选择
   */
  reset(force?: boolean): boolean;
}

export declare type SfCombo<T = any> = Readonly<SfComboProps & SfComboEvents<T> & SfComboMethods<T> & Vue>;

export declare type SfComboGridColumn = SfGridColumn;
