import { componentName } from '@sxf/er-components/_const';
import { isPropEnabled, getVueParent } from '@sxf/er-components/_utils/vue-utils';
import { featureConfig, getPrefixedClassName } from '@sxf/er-feature';
import logger from '@sxf/er-utils/logger';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
import $ from 'jquery';
import { addResizeListener, removeResizeListener } from '@sxf/er-components/_utils/resize-event';
import { Tab, tabs } from '@sxf/er-widget/tab';
import { SfFlex, SfFlexItem } from '@sxf/er-components/flex';
var _a, _b, _c;
const paneLogger = logger(componentName.pane);
var script$2 = {
  name: componentName.pane,
  componentName: componentName.pane,
  props: {
    label: true,
    active: true,
    name: true,
    hidden: true,
    disabled: true,
    tabTip: {
      type: String,
      default: ""
    },
    tabTipOffsetX: {
      type: Number,
      default: 0
    },
    tabTipOffsetY: {
      type: Number,
      default: 0
    },
    icon: {
      type: String
    },
    tabs: {
      type: String
    },
    hasPadding: {
      type: Boolean,
      default: false
    },
    hasBorder: {
      type: Boolean,
      default: false
    },
    hasShadow: {
      type: Boolean,
      default: false
    },
    childrenKeys: {
      type: Array,
      default: () => []
    },
    parentKey: {
      type: String,
      default: ""
    },
    lazy: {
      type: Boolean,
      default: (_c = (_b = (_a = featureConfig.componentConfig) == null ? void 0 : _a.tabs) == null ? void 0 : _b.lazy) != null ? _c : false
    },
    destroyOnHide: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      currentName: this.name,
      canShow: true,
      loaded: false,
      isActive: false
    };
  },
  computed: {
    isHidden() {
      return isPropEnabled(this.hidden);
    },
    isDisabled() {
      return isPropEnabled(this.disabled);
    },
    getTabTip() {
      return this.tabTip;
    },
    tabsComponent() {
      if (this.$parent && this.$parent.$options.componentName === componentName.tabs) {
        return this.$parent;
      }
      if (typeof this.tabs === "string") {
        return this.$vnode.context.$refs[this.tabs];
      }
      const msg = `${componentName.pane} \u7EC4\u4EF6\u5FC5\u987B\u4F5C\u4E3A ${componentName.tabs} \u7684\u5B50\u7EC4\u4EF6\uFF0C\u6216\u8005\u9700\u8981\u5728 props \u4E2D\u58F0\u660E tabs\uFF0C\u4E14\u503C\u5E94\u5F53\u662F ${componentName.tabs} \u7684 ref \u7684\u503C`;
      paneLogger.error(msg);
      return void 0;
    },
    isRender() {
      if (this.destroyOnHide) {
        return this.isActive;
      }
      return !this.lazy || this.loaded || this.active;
    }
  },
  watch: {
    canShow(value) {
      this.tabsComponent[value ? "show" : "hide"](this.currentName);
    },
    isHidden(value) {
      if (!this.canShow) {
        return;
      }
      this.tabsComponent.$emit("updateBar");
      this.tabsComponent[value ? "hide" : "show"](this.currentName);
    },
    isDisabled(value) {
      this.tabsComponent[value ? "disable" : "enable"](this.currentName);
    }
  },
  created() {
    this.tabsComponent.__registerChild(this);
    this.currentName = this.currentName || this.tabsComponent.children.length - 1;
    this.tabsComponent.$on("input", (name) => {
      if (name === this.currentName) {
        this.$emit("show");
        this.loaded = true;
        this.isActive = true;
      } else {
        this.$emit("hide");
        this.isActive = false;
      }
    });
  },
  mounted() {
    this.$emit("mounted");
  },
  methods: {
    getPrefixedClassName,
    getConfig() {
      return {
        icon: this.icon,
        content: this.label,
        tabTip: this.getTabTip,
        active: this.active,
        href: this.currentName,
        hidden: this.isHidden,
        disabled: this.isDisabled,
        hasPadding: this.hasPadding,
        hasBorder: this.hasBorder,
        hasShadow: this.hasShadow,
        childrenKeys: this.childrenKeys,
        parentKey: this.parentKey,
        tabTipOffsetX: this.tabTipOffsetX,
        tabTipOffsetY: this.tabTipOffsetY
      };
    },
    setHideAll(hide) {
      this.canShow = typeof hide === "undefined" ? false : !hide;
    }
  }
};
const __vue_script__$2 = script$2;
var __vue_render__$2 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c2 = _vm._self._c || _h;
  return _vm.canShow ? _c2(
    "div",
    {
      class: [
        _vm.getPrefixedClassName("tab-page"),
        _vm.getPrefixedClassName("tab-page-content")
      ],
      attrs: { "data-id": _vm.currentName }
    },
    [
      _vm.isRender ? [_vm._t("default")] : _vm._e(),
      _vm._v(" "),
      _c2(
        "div",
        { class: _vm.getPrefixedClassName("tab-pane_hidden-wrap") },
        [_c2("div", { ref: "label" }, [_vm._t("label")], 2)]
      )
    ],
    2
  ) : _vm._e();
};
var __vue_staticRenderFns__$2 = [];
__vue_render__$2._withStripped = true;
const __vue_inject_styles__$2 = void 0;
const __vue_scope_id__$2 = void 0;
const __vue_module_identifier__$2 = void 0;
const __vue_is_functional_template__$2 = false;
const __vue_component__$2 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$2, staticRenderFns: __vue_staticRenderFns__$2 },
  __vue_inject_styles__$2,
  __vue_script__$2,
  __vue_scope_id__$2,
  __vue_is_functional_template__$2,
  __vue_module_identifier__$2,
  false,
  void 0,
  void 0,
  void 0
);
const methods = Object.keys(Tab.prototype).reduce(function(map, name) {
  if (typeof Tab.prototype[name] === "function" && name !== "constructor") {
    map[name] = function() {
      return this.tabs[name].apply(this.tabs, arguments);
    };
  }
  return map;
}, {});
var script$1 = {
  name: componentName.tabs,
  componentName: componentName.tabs,
  props: {
    value: true,
    before: {
      type: Function,
      default: () => true
    },
    pathName: true,
    cls: {
      type: String
    },
    hasMargin: {
      type: Boolean,
      default: true
    },
    aligns: {
      type: String,
      default: "horizontal",
      validate(v) {
        return ["vertical", "horizontal"].includes(v);
      }
    },
    type: {
      type: String,
      default: "page",
      validate(v) {
        return ["card", "page", "projection-card"].indexOf(v);
      }
    },
    border: {
      type: Boolean,
      default: false
    },
    emitEvent: {
      type: Boolean,
      default: false
    },
    animation: {
      type: Boolean,
      default: true
    },
    collapseIcon: {
      type: String,
      default: "vtv-icon-comp-arrow-down-big"
    },
    noIcon: {
      type: Boolean,
      default: false
    },
    mouseEnterTab: {
      type: Function,
      default: () => {
      }
    },
    defaultExpandAll: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      currentValue: this.value
    };
  },
  watch: {
    value(value) {
      this.active(value);
    }
  },
  created() {
    this.$on("updateBar", () => {
      this.$nextTick(() => {
        this.realignActiveBar(this.currentValue);
      });
    });
    const parent = getVueParent(this, [componentName.navMenuPanel, componentName.pane]);
    if (parent) {
      parent.$on("show", this.__realignActiveBar);
      this.effectParent = parent;
    }
  },
  mounted() {
    this.__init();
    this.$nextTick(() => {
      addResizeListener(this.$el, this.__realignActiveBar);
    });
  },
  beforeDestroy: function() {
    var _a2;
    if (this.$el) {
      removeResizeListener(this.$el, this.__realignActiveBar);
    }
    if (this.effectParent) {
      this.effectParent.$off("show", this.__realignActiveBar);
      this.effectParent = null;
    }
    this.$off("updateBar");
    if ((_a2 = this.children) == null ? void 0 : _a2.length) {
      this.children.forEach((child) => {
        child.$off("mounted");
      });
      this.children = null;
      this.panelConfig = null;
    }
    if (this.tabs) {
      this.tabs.destroy();
    }
    if (this.$refs.tabs) {
      $(this.$refs.tabs).off("after.sf.tabs");
    }
    this.tabs = null;
    if (this.__routerAfterEachDestroy) {
      this.__routerAfterEachDestroy();
      this.__routerAfterEachDestroy = null;
    }
  },
  methods: $.extend(methods, {
    getPrefixedClassName,
    __init() {
      const vm = this;
      if (!vm.$el || !vm.children || vm.mountedChildCount !== vm.children.length || vm.__hasBeenInit) {
        return;
      }
      vm.__hasBeenInit = true;
      const $tabs = $(vm.$refs.tabs);
      let activeTab = vm.value;
      const tabNames = {};
      let queryTabName;
      if (this.pathName && this.APP_ROOT && this.APP_ROOT.$route && this.APP_ROOT.$route.query[this.pathName]) {
        queryTabName = this.APP_ROOT.$route.query[this.pathName];
      }
      const paneConfig = this.children.reduce(function(list, child) {
        const config = child.getConfig();
        tabNames[config.href] = 1;
        if (config.active) {
          activeTab = config.href;
        }
        if (child.$slots.label) {
          config.contentElem = child.$refs.label;
        }
        list.push(config);
        return list;
      }, []);
      vm.panelConfig = paneConfig;
      vm.tabNames = tabNames;
      if (queryTabName && tabNames[queryTabName]) {
        activeTab = queryTabName;
      }
      if (!activeTab && activeTab !== 0 && paneConfig.length) {
        const noHiddenTabs = paneConfig.filter(function(item) {
          return !item.hidden;
        });
        activeTab = noHiddenTabs[0].href;
      }
      $tabs.on("after.sf.tabs", function(e, newTab, oldTab, newData, oldData) {
        vm.currentValue = newData.href;
        vm.$emit("input", newData.href);
        vm.$emit("after", {
          newTab,
          oldTab,
          newData,
          oldData
        });
        if (vm.emitEvent) {
          vm.autoEmitEvent({
            newTab,
            oldTab,
            newData,
            oldData
          });
        }
        let query;
        if (vm.pathName && vm.APP_ROOT && vm.APP_ROOT.$router && vm.APP_ROOT.$route.query[vm.pathName] !== newData.href) {
          query = Object.assign({}, vm.APP_ROOT.$route.query);
          query[vm.pathName] = newData.href;
          vm.APP_ROOT.$router.push({
            query
          });
        }
      });
      vm.tabs = tabs.call($tabs, {
        data: paneConfig,
        activeTab,
        pages: vm.children.map(function(child) {
          return child.$el;
        }),
        autoActivatePage: true,
        cls: this.cls,
        hasMargin: this.hasMargin,
        aligns: this.aligns,
        type: this.type,
        border: this.border,
        change: null,
        before: this.before,
        animation: this.animation,
        collapseIcon: this.collapseIcon,
        noIcon: this.noIcon,
        mouseEnterTab: this.mouseEnterTab,
        defaultExpandAll: this.defaultExpandAll,
        utidPrefix: this.$attrs.utid ? `${this.$attrs.utid}-` : ""
      }).data("tabs");
      if (vm.pathName && vm.APP_ROOT && vm.APP_ROOT.$router) {
        vm.__routerAfterEachDestroy = vm.APP_ROOT.$router.afterEach(function(to) {
          let queryTabName2 = to.query[vm.pathName];
          if (!vm.tabNames[queryTabName2]) {
            queryTabName2 = null;
          }
          if (vm.value !== queryTabName2) {
            vm.active(queryTabName2);
          }
        });
      }
    },
    __registerChild(child) {
      if (!this.children) {
        this.children = [];
        this.mountedChildCount = 0;
      }
      this.children.push(child);
      child.$on("mounted", () => {
        this.mountedChildCount += 1;
        this.__init();
      });
    },
    __realignActiveBar() {
      var _a2;
      if (this.currentValue) {
        (_a2 = this.tabs) == null ? void 0 : _a2.realignActiveBar(this.currentValue);
      }
    },
    autoEmitEvent(tabsInfo) {
      const newData = tabsInfo.newData;
      const oldData = tabsInfo.oldData;
      const ctx = this.$vnode.context;
      if (!ctx) {
        return;
      }
      if (newData.href) {
        const comp = $.makeArray(ctx.$refs[newData.href])[0];
        if (comp && comp.$emit) {
          comp.$emit("show");
        }
      }
      if (oldData.href) {
        const comp = $.makeArray(ctx.$refs[oldData.href])[0];
        if (comp && comp.$emit) {
          comp.$emit("hide");
        }
      }
    },
    collapseTab() {
      this.tabs.collapse();
    },
    expandTab() {
      this.tabs.expand();
    }
  })
};
const __vue_script__$1 = script$1;
var __vue_render__$1 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c2 = _vm._self._c || _h;
  return _c2(
    "div",
    [
      _c2("div", {
        ref: "tabs",
        class: _vm.getPrefixedClassName("vmp-tabs-header-wrap")
      }),
      _vm._v(" "),
      _vm._t("default")
    ],
    2
  );
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
var script = {
  name: componentName.tabsWrap,
  componentName: componentName.tabsWrap,
  components: { SfFlex, SfFlexItem },
  methods: { getPrefixedClassName }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c2 = _vm._self._c || _h;
  return _c2(
    "sf-flex",
    {
      class: _vm.getPrefixedClassName("sf-tabs-wrap"),
      attrs: { "flex-direction": "column" }
    },
    [
      _c2("sf-flex-item", { attrs: { flex: "none" } }, [_vm._t("header")], 2),
      _vm._v(" "),
      _c2(
        "sf-flex-item",
        {
          class: _vm.getPrefixedClassName("sf-tabs-wrap-content"),
          attrs: { flex: "1" }
        },
        [_vm._t("default")],
        2
      ),
      _vm._v(" "),
      _vm.$slots.footer ? _c2("sf-flex-item", { attrs: { flex: "none" } }, [_vm._t("footer")], 2) : _vm._e()
    ],
    1
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__$2 as SfPane, __vue_component__$1 as SfTabs, __vue_component__ as SfTabsWrap };
