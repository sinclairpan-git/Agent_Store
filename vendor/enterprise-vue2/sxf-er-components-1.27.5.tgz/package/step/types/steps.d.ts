import { VNode } from 'vue';

export interface SfStepsProps {
  /**
   * 设置当前步骤栏显示的名称
   *
   * @default ''
   */
  label?: string;

  /**
   * 设置当前步骤栏是否需要激活
   */
  active?: boolean;

  /**
   * 设置当前步骤栏的名字
   *
   * @default ''
   */
  name?: string;

  /**
   * 设置当前步骤栏的显示/隐藏
   *
   * @default false
   */
  hidden?: boolean;

  /**
   * 设置当前步骤栏的启用/禁用
   *
   * @default false
   */
  disabled?: boolean;

  /**
   * 设置对应sf-steps的ref
   */
  steps?: string;

  /**
   * 设置当前激活的步骤栏
   *
   * @default ''
   */
  value?: string;

  /**
   * 设置顶部标签
   *
   * @default ''
   */
  topLabel?: string;

  /**
   * 切换步骤栏前的回调，初始会触发一次
   */
  before?: Function;

  /**
   * 向后切换步骤栏前的回调
   */
  beforeNext?: Function;

  /**
   * 向前切换步骤栏前的回调
   */
  beforePrev?: Function;
}

export interface SfStepsEvents {
  /**
   * 切换步骤栏后的回调，初始会触发一次
   *
   * @param eventName
   */
  $emit(eventName: 'after'): this;
}

export interface SfStepsMethods {
  /**
   * 向前切换
   */
  prev(): void;

  /**
   * 向后切换
   */
  next(): void;
}

export interface SfStepsSlots {
  $slots: {
    default: VNode[];
    label: VNode[];
    desc: VNode[];
  };
}

export declare type SfSteps = Readonly<SfStepsProps & SfStepsEvents & SfStepsMethods & SfStepsSlots> & Vue;
