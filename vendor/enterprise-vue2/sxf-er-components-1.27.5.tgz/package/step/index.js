import { componentName } from '@sxf/er-components/_const';
import { isPropEnabled } from '@sxf/er-components/_utils/vue-utils';
import { getPrefixedClassName } from '@sxf/er-feature';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
import $ from 'jquery';
import { Steps, steps } from '@sxf/er-widget/step';
var script$1 = {
  name: componentName.step,
  componentName: componentName.step,
  props: {
    label: true,
    desc: true,
    topLabel: true,
    active: true,
    isError: true,
    name: true,
    hidden: true,
    disabled: true,
    steps: {
      type: String
    },
    lazy: {
      type: Boolean,
      default: false
    },
    delay: {
      type: Number,
      default: 0,
      validator: (value) => value >= 0
    }
  },
  data() {
    return {
      currentName: this.name,
      shouldShowSlot: this.delay === 0
    };
  },
  computed: {
    isHidden() {
      return isPropEnabled(this.hidden);
    },
    isDisabled() {
      return isPropEnabled(this.disabled);
    },
    stepsComponent() {
      if (this.$parent && this.$parent.$options.componentName === componentName.steps) {
        return this.$parent;
      }
      if (typeof this.steps === "string") {
        return this.$vnode.context.$refs[this.steps];
      }
      return null;
    }
  },
  watch: {
    isHidden(value) {
      this.stepsComponent[value ? "hide" : "show"](this.currentName);
    },
    isDisabled(value) {
      this.stepsComponent[value ? "disable" : "enable"](this.currentName);
    },
    label() {
      this.stepsComponent.$emit("step-change");
    },
    topContent() {
      this.stepsComponent.$emit("step-change");
    },
    isError() {
      this.stepsComponent.$emit("step-change");
    }
  },
  created() {
    this.stepsComponent.__registerChild(this);
    this.currentName = this.currentName || this.stepsComponent.children.length - 1;
  },
  mounted() {
    if (this.delay > 0) {
      setTimeout(() => {
        this.shouldShowSlot = true;
      }, this.delay);
    }
  },
  beforeDestroy() {
    this.stepsComponent.__unregisterChild(this);
  },
  methods: {
    getConfig() {
      return {
        content: this.label,
        contentDesc: this.desc,
        topContent: this.topLabel,
        active: this.active,
        href: this.currentName,
        hidden: this.isHidden,
        disabled: this.isDisabled,
        isError: this.isError
      };
    },
    getPrefixedClassName
  }
};
const __vue_script__$1 = script$1;
var __vue_render__$1 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      class: _vm.getPrefixedClassName("tab-page"),
      attrs: { "data-id": _vm.currentName }
    },
    [
      _vm.lazy ? _c(
        "keep-alive",
        [_vm.active && _vm.shouldShowSlot ? _vm._t("default") : _vm._e()],
        2
      ) : _vm.shouldShowSlot ? _vm._t("default") : _vm._e(),
      _vm._v(" "),
      _c("div", { class: _vm.getPrefixedClassName("steps_hidden-wrap") }, [
        _c("div", { ref: "label" }, [_vm._t("label")], 2),
        _vm._v(" "),
        _vm.$slots.desc ? _c("div", { ref: "desc" }, [_vm._t("desc")], 2) : _vm._e()
      ])
    ],
    2
  );
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
const methods = Object.getOwnPropertyNames(Steps.prototype).reduce(function(map, name) {
  if (typeof Steps.prototype[name] === "function" && name !== "constructor") {
    map[name] = function(...args) {
      const steps2 = this.steps || $(this.$refs.steps).data("sf.steps");
      return steps2[name](...args);
    };
  }
  return map;
}, {});
var script = {
  name: componentName.steps,
  componentName: componentName.steps,
  props: {
    value: true,
    before: {
      type: Function,
      default: $.noop
    },
    beforePrev: {
      type: Function,
      default: $.noop
    },
    beforeNext: {
      type: Function,
      default: $.noop
    },
    theme: {
      type: String,
      default: "default"
    },
    mode: {
      type: String,
      default: "page",
      validator(v) {
        return ["page", "dialog"].includes(v);
      }
    },
    direction: {
      type: String,
      default: "horizontal",
      validator(v) {
        return ["vertical", "horizontal"].includes(v);
      }
    }
  },
  computed: {
    hasBg() {
      if (this.mode === "dialog") {
        return false;
      }
      return !this.theme || this.theme === "default";
    }
  },
  watch: {
    value(value) {
      var _a;
      const values = Object.keys(this.steps.dataMap).map(Number);
      const minValue = Math.min(...values);
      const maxValue = Math.max(...values);
      while (value < maxValue && value > minValue && ((_a = this.steps.dataMap[value]) == null ? void 0 : _a.hidden)) {
        const stepFlag = value > this.steps.stepIndex ? 1 : -1;
        value += stepFlag;
      }
      this.active(value);
      const actualHref = this.getData(this.steps.stepIndex).href;
      if (actualHref !== value) {
        this.$emit("input", actualHref);
      }
    }
  },
  mounted() {
    this.__init();
    this.$on("step-change", () => this.__init());
  },
  beforeDestroy() {
    this.steps.destroy();
    this.steps = null;
  },
  methods: {
    ...methods,
    __init() {
      if (this._isDestroyed) {
        return;
      }
      if (!this.$el || this.mountedChildCount !== this.children.length) {
        return;
      }
      const $steps = $(this.$refs.steps);
      let activeTab = this.value;
      this.children.sort((childA, childB) => {
        const $childA = $(childA.$el);
        const $childB = $(childB.$el);
        const $parent = $childA.parent();
        if ($parent.is($childB.parent())) {
          return $childA.index() - $childB.index();
        }
        return 0;
      });
      const paneConfig = this.children.reduce((list, child) => {
        const config = child.getConfig();
        if (config.active) {
          activeTab = config.href;
        }
        if (child.$slots.label) {
          config.contentElem = child.$refs.label;
        }
        if (child.$slots.desc) {
          config.contentDescElem = child.$refs.desc;
        }
        list.push(config);
        return list;
      }, []);
      if (this.steps) {
        this.steps.setData(paneConfig);
        this.steps.setPages(this.__getPages());
        this.steps.redraw();
        return;
      }
      if (!activeTab && activeTab !== 0 && paneConfig.length) {
        activeTab = paneConfig[0].href;
      }
      $steps.on("after.sf.steps", (e, newTab, oldTab, newData, oldData) => {
        this.$emit("input", newData.href);
        this.$emit("after", {
          newData,
          oldData,
          newTab,
          oldTab
        });
      });
      $steps.on("before.sf.steps prev.sf.steps next.sf.steps", (e, newTab, oldTab, newData, oldData) => {
        let propName = e.type;
        if (propName !== "before") {
          propName = "before" + propName.replace(/^(.)/, function(m, $1) {
            return $1.toUpperCase();
          });
        }
        return this[propName]({
          newTab,
          oldTab,
          newData,
          oldData
        });
      });
      this.steps = steps.call($steps, {
        data: paneConfig,
        activeTab,
        pages: this.__getPages(),
        theme: this.theme,
        mode: this.mode,
        direction: this.direction
      }).data("sf.steps");
    },
    __getPages() {
      return this.children.map((child) => {
        return child.$el;
      });
    },
    __registerChild(child) {
      if (!this.children) {
        this.children = [];
        this.mountedChildCount = 0;
      }
      this.children.push(child);
      child.$on("hook:mounted", () => {
        this.mountedChildCount += 1;
        this.__init();
      });
    },
    __unregisterChild(child) {
      const index = this.children.indexOf(child);
      if (index >= 0) {
        this.children.splice(index, 1);
        child.$on("hook:destroyed", () => {
          this.mountedChildCount -= 1;
          this.__init();
        });
      }
    },
    getPrefixedClassName
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _obj;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      class: [
        _vm.getPrefixedClassName("sf-steps-container"),
        (_obj = {}, _obj[_vm.getPrefixedClassName("sf-steps-container--fill")] = _vm.hasBg, _obj)
      ]
    },
    [
      _c("div", {
        ref: "steps",
        class: _vm.getPrefixedClassName("sf-steps-container--wrapper")
      }),
      _vm._v(" "),
      _vm._t("default")
    ],
    2
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__$1 as SfStep, __vue_component__ as SfSteps };
