import { componentName } from '@sxf/er-components/_const';
import { SfAlert } from '@sxf/er-components/alert';
import { SfButton } from '@sxf/er-components/button';
import { $i } from '@sxf/er-config';
import { getPrefixedClassName } from '@sxf/er-feature';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
const SEARCH_STATUS = {
  searching: "searching",
  success: "success",
  fail: "fail"
};
const eventName = "opr-callback";
var script = {
  name: componentName.searchTip,
  componentName: componentName.searchTip,
  components: { SfAlert, SfButton },
  data() {
    return {
      isShow: false,
      status: SEARCH_STATUS.searching,
      count: 0
    };
  },
  computed: {
    isSearching() {
      return this.status === SEARCH_STATUS.searching;
    },
    isSuccess() {
      return this.status === SEARCH_STATUS.success;
    },
    isFail() {
      return this.status === SEARCH_STATUS.fail;
    },
    searchingText() {
      return $i("scp.vt_component.sf_widget.packages.search_tip.searching_text");
    },
    searchFailText() {
      return $i("scp.vt_component.sf_widget.packages.search_tip.search_fail_text");
    },
    endSearchBtnText() {
      return $i("scp.vt_component.sf_widget.packages.search_tip.end_search_btn");
    },
    successText() {
      return $i("scp.vt_component.sf_widget.packages.search_tip.success_text", { 0: this.count });
    }
  },
  methods: {
    getPrefixedClassName,
    getFullUtid(utidBase) {
      return this.$attrs.utid ? `${this.$attrs.utid}-${utidBase}` : utidBase;
    },
    show() {
      this.isShow = true;
    },
    hide() {
      this.isShow = false;
    },
    reset() {
      this.count = 0;
      this.status = SEARCH_STATUS.searching;
    },
    onFail() {
      if (!this.isShow) {
        return;
      }
      this.status = SEARCH_STATUS.fail;
    },
    onSuccess(count) {
      if (!this.isShow) {
        return;
      }
      this.count = count;
      this.status = SEARCH_STATUS.success;
    },
    __endSearch() {
      this.hide();
      this.reset();
      this.$emit(eventName);
    }
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "sf-alert",
    {
      directives: [
        {
          name: "show",
          rawName: "v-show",
          value: _vm.isShow,
          expression: "isShow"
        }
      ],
      class: _vm.getPrefixedClassName("search-tip-bar"),
      attrs: { align: "left", size: "small", border: "" }
    },
    [
      _c(
        "span",
        {
          directives: [
            {
              name: "show",
              rawName: "v-show",
              value: _vm.isSearching,
              expression: "isSearching"
            }
          ]
        },
        [_c("span", [_vm._v(_vm._s(_vm.searchingText))])]
      ),
      _vm._v(" "),
      _c(
        "span",
        {
          directives: [
            {
              name: "show",
              rawName: "v-show",
              value: _vm.isFail,
              expression: "isFail"
            }
          ]
        },
        [_c("span", [_vm._v(_vm._s(_vm.searchFailText))])]
      ),
      _vm._v(" "),
      _c(
        "span",
        {
          directives: [
            {
              name: "show",
              rawName: "v-show",
              value: _vm.isSuccess,
              expression: "isSuccess"
            }
          ]
        },
        [
          _vm._v("\n    " + _vm._s(_vm.successText) + "\n    "),
          _c(
            "sf-button",
            {
              attrs: { type: "link", utid: _vm.getFullUtid("end-search") },
              on: { click: _vm.__endSearch }
            },
            [_c("span", [_vm._v(_vm._s(_vm.endSearchBtnText))])]
          )
        ],
        1
      )
    ]
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__ as SfSearchTip };
