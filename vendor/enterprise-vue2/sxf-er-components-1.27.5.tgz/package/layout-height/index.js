import $ from 'jquery';
import { componentName } from '@sxf/er-components/_const';
import { vOnShow } from '@sxf/er-components/_directives';
import { EmitterMixin, AddComponentMixinEventName } from '@sxf/er-components/_mixins';
import { getVueParent } from '@sxf/er-components/_utils/vue-utils';
import { debounce } from '@sxf/er-utils/delay';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
const defaultValue = {
  dispatchAddedEvent: false,
  bottomDistance: 0
};
function getSums(el, targetEl) {
  let parent = el;
  let pbSum = 0;
  let sTSum = 0;
  while (parent && parent !== targetEl && parent.parentElement) {
    parent = parent.parentElement;
    const pb = parseInt(getComputedStyle(parent).paddingBottom, 10);
    pbSum += pb;
    sTSum += parent.scrollTop || 0;
  }
  return {
    pbSum,
    sTSum
  };
}
function getComputeHeight(el, { targetEl = document.documentElement, distance = defaultValue.bottomDistance } = {}) {
  const elRect = el.getBoundingClientRect() || {};
  const targetElRect = targetEl.getBoundingClientRect() || {};
  const { pbSum, sTSum } = getSums(el, targetEl);
  const height = targetElRect.height - (elRect.top - targetElRect.top) - distance - pbSum - sTSum;
  return Math.floor(height);
}
function getNumericalDistance(distance) {
  if (typeof distance === "string") {
    const numStr = distance.replace(/px$/, "");
    const num = Number(numStr);
    if (Number.isNaN(num)) {
      return defaultValue.bottomDistance;
    }
    return num;
  }
  if (typeof distance === "number" && !Number.isNaN(distance)) {
    return distance;
  }
  return defaultValue.bottomDistance;
}
const DELAY_TIME = 200;
var script = {
  name: componentName.layoutHeight,
  componentName: componentName.layoutHeight,
  directives: { "on-show": vOnShow },
  mixins: [EmitterMixin],
  props: {
    distance: {
      type: [Number, String],
      default: defaultValue.bottomDistance
    },
    fill: {
      type: Boolean,
      default: true
    },
    gridOffset: {
      type: Number,
      default: 0
    },
    fixHeight: {
      type: Boolean,
      default: true
    },
    fixGridHeight: {
      type: Boolean,
      default: true
    },
    gridMinHeight: {
      type: Number,
      default: 0
    },
    ignoreGrid: {
      type: Boolean,
      default: false
    },
    ignoreTree: {
      type: Boolean,
      default: false
    },
    dispatchAddedEvent: {
      type: Boolean,
      default: defaultValue.dispatchAddedEvent
    },
    watchWidthResize: {
      type: Boolean,
      default: true
    }
  },
  data() {
    const numericalDistance = getNumericalDistance(this.distance);
    return {
      height: 0,
      gridOffsetValue: this.gridOffset,
      computedDistance: numericalDistance,
      gridComponents: [],
      treeComponents: [],
      curParent: null
    };
  },
  computed: {
    styles() {
      if (this.height) {
        const heightType = this.fixHeight ? "height" : "minHeight";
        const heightVal = this.height + "px";
        return { [heightType]: heightVal };
      }
      return {};
    }
  },
  created() {
    var _a;
    this.gridComponents = [];
    this.treeComponents = [];
    this.curParent = null;
    this.$on(AddComponentMixinEventName, (comp) => {
      if (comp.$options.componentName === componentName.grid) {
        this.gridComponents.push(comp);
      }
      if (comp.$options.componentName === componentName.tree) {
        this.treeComponents.push(comp);
      }
    });
    this.curParent = getVueParent(this, [componentName.navMenuPanel, componentName.pane]);
    this.curParent && this.curParent.$on("show", this.onShowManual);
    this._inDrawer = (_a = this._inDrawer) != null ? _a : !!getVueParent(this, [componentName.drawer]);
  },
  mounted() {
    let lastWindowHeight = $(window).height();
    let lastDocumentHeight = $(document).height();
    this.layoutContainerEl = this.getContainerEl();
    this.computedDistance = this.computedDistance + (this.layoutContainerEl ? 1 : 0);
    this.__resizeFn = debounce(() => {
      const isHidden = $(this.$el).is(":hidden");
      if (isHidden) {
        this._isShown = false;
        return;
      }
      const windowHeight = $(window).height();
      const documentHeight = $(document).height();
      if (lastWindowHeight === windowHeight && lastDocumentHeight === documentHeight && !this.watchWidthResize) {
        return;
      }
      lastWindowHeight = windowHeight;
      lastDocumentHeight = documentHeight;
      this.changeHeight();
    }, DELAY_TIME);
    $(window).on("resize", this.__resizeFn);
    if (this.dispatchAddedEvent) {
      this.dispatch(
        (comp) => {
          if (comp === this.APP_ROOT) {
            return {
              continue: false,
              valid: true
            };
          }
        },
        AddComponentMixinEventName,
        this
      );
    }
  },
  beforeDestroy() {
    if (this.__resizeFn) {
      $(window).off("resize", this.__resizeFn);
      this.__resizeFn = null;
    }
    if (this.curParent) {
      this.curParent.$off("show", this.onShowManual);
      this.curParent = null;
    }
    this.gridComponents = [];
    this.treeComponents = [];
    this.layoutContainerEl = null;
    this._inDrawer = null;
    this._isShown = null;
  },
  methods: {
    onShowManual() {
      this.onShow(true);
    },
    onShow(isManual) {
      if (this._isShown || !this.$el) {
        return;
      }
      if (!isManual) {
        this._isShown = true;
      }
      this.changeHeight();
    },
    setGridOffsetValue(gridOffset) {
      this.gridOffsetValue = gridOffset;
    },
    addComponent(component, type = "grid") {
      if (!component) {
        return;
      }
      const components = [].concat(component);
      const currComponents = type === "grid" ? this.gridComponents : this.treeComponents;
      components.forEach((item) => {
        const isNewComponent = currComponents.every((curr) => curr !== item);
        if (isNewComponent) {
          currComponents.push(item);
        }
      });
      this.setGridHeight();
    },
    changeHeight() {
      const targetEl = this.layoutContainerEl ? this.layoutContainerEl : void 0;
      const height = getComputeHeight(this.$el, {
        distance: this.computedDistance,
        targetEl
      });
      if (this.fill) {
        this.height = height;
      }
      this.$nextTick(() => {
        if (!this.ignoreGrid) {
          this.setGridHeight();
        }
        if (!this.ignoreTree) {
          this.setTreeHeight();
        }
      });
      this.$emit("change-height", height);
    },
    getRootEl() {
      return this.$root.$el;
    },
    getChildTargetEl() {
      if (this.fill) {
        return this.$el;
      }
      if (this.layoutContainerEl) {
        return this.layoutContainerEl;
      }
      return document.documentElement;
    },
    setGridHeight() {
      this.gridComponents.forEach((gridComp) => {
        const gridEl = gridComp.getGridEl();
        if (!gridEl || !this.isRootContained(gridEl)) {
          return;
        }
        if ($(gridEl).is(":hidden")) {
          this._isShown = false;
          return;
        }
        let gridHeight = getComputeHeight(gridEl, {
          distance: this.computedDistance,
          targetEl: this.getChildTargetEl()
        });
        const minHeight = gridComp.getBodyElSize(gridHeight);
        gridHeight = Math.max(gridHeight, this.gridMinHeight);
        this.fixGridHeight ? gridComp.setHeight(gridHeight + this.gridOffsetValue) : gridComp.setMinHeight(minHeight + this.gridOffsetValue);
      });
    },
    setTreeHeight() {
      this.treeComponents.forEach((treeComp) => {
        const treeHeight = getComputeHeight(treeComp.getTreeEl(), {
          distance: this.computedDistance,
          targetEl: this.getChildTargetEl()
        });
        treeComp.setTreeHeight(treeHeight);
      });
    },
    isRootContained(element) {
      const rootEl = this.getRootEl();
      return this._inDrawer || rootEl.contains(element);
    },
    getContainerEl() {
      if (this._inDrawer) {
        return $(this.$el).parents(".sf-drawer__body").get(0);
      }
      return $(this.$el).parents('[class*="sf-layout"]').get(0);
    }
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      directives: [
        {
          name: "on-show",
          rawName: "v-on-show",
          value: _vm.onShow,
          expression: "onShow"
        }
      ],
      style: _vm.styles
    },
    [_vm._t("default")],
    2
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__ as SfLayoutHeight };
