import { VNode } from 'vue';

export interface SfWindowProps {
  width?: number | 'auto';
  height?: number | 'auto';
  maxHeight?: number | 'auto';
  minHeight?: number | 'auto';
  autoHeight?: boolean;
  title?: string;
  overtop?: HTMLElement;
  cls?: string;
  showHelp?: string;
  noHeader?: boolean;
  noFooter?: boolean;
  noClose?: boolean;
  noCancel?: boolean;
  noSubmit?: boolean;
  cancelDisabled?: boolean;
  submitDisabled?: boolean;
  buttonAlign?: string;
  submitText?: string;
  cancelText?: string;
  noPrev?: boolean;
  steps?: string;
  path?: Array<string>;
  beforeSubmit?: Function | boolean;
  beforeCancel?: Function | boolean;
  beforeClose?: Function | boolean;
  beforeHide?: Function | boolean;
}

export interface SfWindowSlots {
  $slots: {
    default?: VNode[];
    top?: VNode[];
    header?: VNode[];
    'header-inner'?: VNode[];
    bodyInner?: VNode[];
  };
  $scopedSlots: {
    footer?: (props: SfWindowFooterProps) => VNode[];
  };
}

export interface SfWindowFooterProps {
  submit: () => void;
  cancel: () => void;
  submitText: string;
  cancelText: string;
  align: string;
  noSubmit: boolean;
  noCancel: boolean;
  nextDisabled: boolean;
  preDisabled: boolean;
  submitDisabled: boolean;
  cancelDisabled: boolean;
}

export interface SfWindowEvents {
  $emit(eventName: 'show'): this;
  $emit(eventName: 'hide'): this;
  $emit(eventName: 'resize'): this;
  $emit(eventName: 'submit'): this;
  $emit(eventName: 'cancel'): this;
}

export interface SfWindowMethods {
  prev: () => void;
  next: () => void;
  setTitle: (title: string) => void;
  setWidth: (width: string | number) => void;
  setHeight: (height: string | number) => void;
  getWidth: () => number;
  getHeight: () => number;
  show: () => void;
  hide: () => void;
  toFront: () => void;
  hideHeader: () => void;
  showHeader: () => void;
  hideMask: () => void;
  showMask: () => void;
  getBodySel: () => JQuery<HTMLElement>;
}

export declare type SfWindow = Readonly<SfWindowProps & SfWindowSlots & SfWindowEvents & SfWindowMethods> & Vue;
