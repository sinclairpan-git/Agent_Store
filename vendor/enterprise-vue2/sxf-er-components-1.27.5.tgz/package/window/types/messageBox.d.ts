import type { SfWindow, SfWindowProps } from './window';
import type { VNode } from 'vue';

/**
 * 弹窗类型
 */
export type SfMessageBoxType = 'confirm' | 'info' | 'warn' | 'success' | 'danger' | 'error' | 'delete';

/**
 * 弹窗组件的 props
 */
export type SfMessageBoxProps = SfWindowProps & {
  /**
   * 弹窗标题
   *
   * @default 提示
   */
  title?: string;

  /**
   * 子标题
   */
  subtitle?: string | string[];

  /**
   * 消息内容
   */
  content?: string | string[];

  /**
   * 输入OK确认弹窗
   */
  withOk?: boolean;

  /**
   * 输入密码确认弹窗
   */
  withPassword?: boolean;

  /**
   * 内容块是否使用html
   */
  contentUseHtml?: boolean;

  /**
   * 图标
   */
  icon?: boolean;
};

export interface SfMessageBoxSlots {
  $slots: {
    default: VNode[];
    icon?: VNode[];
    subtitle?: VNode[];
    footer?: VNode[];
    'sub-footer'?: VNode[];
  };
}

/**
 * 弹窗组件的类型定义
 */
export type SfMessageBox = Readonly<SfMessageBoxProps & SfMessageBoxSlots> & SfWindow & Vue;

export type SfConfirmWindow = SfMessageBox;
export type SfWarnWindow = SfMessageBox;
export type SfInfoWindow = SfMessageBox;
export type SfSuccessWindow = SfMessageBox;
export type SfDangerWindow = SfMessageBox;
export type SfErrorWindow = SfMessageBox;
export type SfDeleteWindow = SfMessageBox;
