import type { SfWindow } from './window';

import Vue, { ComponentOptions } from 'vue';

interface WindowConfig extends ComponentOptions<Vue> {
  create: <T = Vue>(
    config?: Record<string, any>,
    winConfig?: { noDeepcopy?: boolean },
  ) => T & {
    __win: SfWindow;
    show(): void;
    hide(): void;
    silentHide(): void;
  };
}

declare function vueWindowCreator(vueConfig: ComponentOptions<Vue>): WindowConfig;

export { vueWindowCreator };
