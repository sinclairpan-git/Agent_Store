import $ from 'jquery';
import { componentName } from '@sxf/er-components/_const';
import { isPropEnabled, hasDefinedProp } from '@sxf/er-components/_utils/vue-utils';
import { SfAlert } from '@sxf/er-components/alert';
import { SfFlex, SfFlexItem } from '@sxf/er-components/flex';
import { $i, globalConfig } from '@sxf/er-config';
import { getPrefixedClassName } from '@sxf/er-feature';
import { when } from '@sxf/er-utils/when';
import LoadMask from '@sxf/er-widget/mask';
import WindowWidget from '@sxf/er-widget/window';
import '@sxf/er-components/_global/mask';
import { SfButton } from '@sxf/er-components/button';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
import { SfForm, SfFormItem } from '@sxf/er-components/form';
import { SfInput } from '@sxf/er-components/input';
import { checkNoNotify, filterNoNotifyPrefix } from '@sxf/er-utils/ajax';
import format from '@sxf/er-utils/format';
import { xssFilter, whiteList } from '@sxf/er-utils/xss';
import { getVerifyPasswordApi } from '@sxf/er-widget/messageBox';
import notify from '@sxf/er-widget/notify';
var SfWindowButton = {
  name: componentName.windowButton,
  componentName: componentName.windowButton,
  components: {
    SfButton
  },
  extends: SfButton,
  render(createElement) {
    return createElement(
      SfButton,
      {
        class: getPrefixedClassName("sf-window-button"),
        props: $.extend(
          {
            size: "medium"
          },
          this.$props
        ),
        attrs: this.$attrs,
        on: this.$listeners
      },
      [this.$slots.default]
    );
  }
};
const methods$1 = Object.keys(WindowWidget.prototype).reduce(function(map, name) {
  if (typeof WindowWidget.prototype[name] === "function" && name !== "constructor") {
    map[name] = function(...args) {
      return this.win[name](args);
    };
  }
  return map;
}, {});
var script$1 = {
  name: componentName.window,
  componentName: componentName.window,
  components: {
    SfAlert,
    SfWindowButton,
    SfFlex,
    SfFlexItem
  },
  props: {
    size: true,
    width: true,
    height: true,
    autoHeight: true,
    maxHeight: true,
    minHeight: true,
    title: {
      type: String,
      default: ""
    },
    overtop: true,
    cls: true,
    showHelp: true,
    noHeader: true,
    noBody: {
      type: Boolean,
      default: false
    },
    noFooter: true,
    noClose: true,
    noSubmit: true,
    noCancel: true,
    nextDisabled: true,
    preDisabled: true,
    submitDisabled: true,
    cancelDisabled: true,
    buttonAlign: {
      type: String,
      default: "right"
    },
    submitText: {
      type: String,
      default: () => $i("scp.vt_component.sf_widget.packages.window.submit_btn")
    },
    cancelText: {
      type: String,
      default: () => $i("scp.vt_component.sf_widget.packages.window.cancel_btn")
    },
    beforeSubmit: {
      type: [Function, Boolean],
      default: true
    },
    beforeCancel: {
      type: [Function, Boolean],
      default: true
    },
    beforeClose: {
      type: [Function, Boolean],
      default: true
    },
    beforeHide: {
      type: [Function, Boolean],
      default: true
    },
    steps: {},
    renderOnShown: {},
    utid: {},
    isIllustration: {
      type: Boolean,
      default: false
    },
    verticalAlign: {
      type: String,
      default: "",
      validator: (val) => ["", "center"].includes(val)
    },
    alert: {
      type: String,
      default: ""
    },
    btnCloseTheme: {
      type: String,
      default: "gray",
      validator: (val) => ["gray", "white"].includes(val)
    },
    getContainer: {
      type: Function
    },
    autoMask: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      hasSteps: typeof this.steps !== "undefined",
      inFirst: true,
      inEnd: true,
      isShown: false,
      prevUtid: "",
      nextUtid: ""
    };
  },
  computed: {
    isNoHeader() {
      return isPropEnabled(this.noHeader);
    },
    isNoBody() {
      return isPropEnabled(this.noBody);
    },
    isNoFooter() {
      return isPropEnabled(this.noFooter);
    },
    isNoClose() {
      return isPropEnabled(this.noClose);
    },
    isNoSubmit() {
      return isPropEnabled(this.noSubmit) || this.hasSteps && !this.inEnd;
    },
    isNoCancel() {
      return isPropEnabled(this.noCancel);
    },
    isPreDisabled() {
      return isPropEnabled(this.preDisabled);
    },
    isNextDisabled() {
      return isPropEnabled(this.nextDisabled);
    },
    isSubmitDisabled() {
      return isPropEnabled(this.submitDisabled);
    },
    isCancelDisabled() {
      return isPropEnabled(this.cancelDisabled);
    },
    buttonFlexAlign() {
      if (this.hasSteps) {
        return "space-between";
      }
      return {
        left: "flex-start",
        right: "flex-end"
      }[this.buttonAlign] || this.buttonAlign;
    },
    hasHeight() {
      const height = parseInt(this.height, 10);
      return !isNaN(height);
    },
    bodyFlex() {
      return `1 1 ${this.autoHeight || this.hasHeight ? "100%" : "auto"}`;
    },
    bodyCls() {
      return {
        [getPrefixedClassName("sf-window_body")]: true,
        [getPrefixedClassName("sf-window_body--center")]: this.verticalAlign === "center"
      };
    },
    prevText() {
      return $i("scp.vt_component.sf_widget.packages.window.prev_btn");
    },
    nextText() {
      return $i("scp.vt_component.sf_widget.packages.window.next_btn");
    }
  },
  watch: {
    title: function() {
      this.renderHeader(this.$refs.top);
    },
    isNoHeader: function(value) {
      this.win[value ? "hideHeader" : "showHeader"]();
    },
    isNoBody: function(value) {
      this.win[value ? "hideBody" : "showBody"]();
    },
    isNoFooter: function(value) {
      this.win[value ? "hideFooter" : "showFooter"]();
    },
    isNoClose: function(value) {
      this.win[value ? "hideHeaderClose" : "showHeaderClose"]();
    }
  },
  mounted() {
    const vm = this;
    let loadMask;
    let bodyLoadMask;
    const cls = vm.cls;
    function _getContainer() {
      if (vm.getContainer) {
        const container = vm.getContainer();
        if (container === false) {
          return vm.$parent.$el;
        }
        return container;
      }
      return document.body;
    }
    vm.win = new WindowWidget({
      size: vm.size,
      width: vm.width,
      height: vm.height,
      autoHeight: vm.autoHeight,
      minHeight: vm.minHeight,
      maxHeight: vm.maxHeight,
      title: vm.title,
      titleTip: false,
      header: !vm.isNoHeader,
      body: !vm.isNoBody,
      footer: !vm.isNoFooter,
      closeable: !vm.isNoClose,
      cls,
      overtop: vm.overtop,
      showHelp: vm.showHelp,
      utid: vm.utid,
      btnCloseTheme: vm.btnCloseTheme,
      verticalAlign: this.verticalAlign,
      container: _getContainer(),
      autoclose: true,
      listeners: {},
      buttons: null,
      autoDestroy: false,
      buttonAlign: "left",
      autoMask: vm.autoMask,
      beforeClose: function() {
        return vm._fixBefore(vm.beforeClose);
      },
      beforeHide: function() {
        return vm._fixBefore(vm.beforeHide);
      },
      beforeShow: function() {
        const me = this;
        if (me.__hasInitFooter && me.__hasInitHeader) {
          return;
        }
        const defer = $.Deferred();
        vm.$nextTick(() => {
          if (vm.$refs.footer) {
            vm.renderFooter(vm.$refs.footer);
            me.__hasInitFooter = true;
          }
          if (vm.$refs.top) {
            vm.renderHeader(vm.$refs.top);
            me.__hasInitHeader = true;
          }
          defer.resolve();
        });
        return defer;
      }
    });
    vm.win.on("show", () => {
      const me = this;
      const isFirstTimeShown = !me.isShown;
      me.isShown = true;
      vm.$nextTick(() => {
        if (isFirstTimeShown && me.renderOnShown) {
          me.__initSteps();
        }
        vm.$emit("show");
      });
    });
    vm.win.on("hide", function() {
      vm.$nextTick(function() {
        vm.$emit("hide");
      });
    });
    vm.win.on("resize", function() {
      vm.$emit("resize");
    });
    vm.win.render();
    vm.win.renderBody(vm.$el);
    vm.$watch(
      function() {
        return {
          width: vm.width,
          height: vm.height,
          minHeight: vm.minHeight,
          maxHeight: vm.maxHeight
        };
      },
      function(value) {
        $.extend(vm.win.options, value);
        vm.win.updateWinSize();
      },
      {
        deep: true
      }
    );
    Object.defineProperty(this, "$loadMask", {
      get: function() {
        if (loadMask) {
          return loadMask;
        }
        vm.__loadMaskInited = true;
        const { target, option } = vm.__getLoadMaskConfig();
        loadMask = new LoadMask(target, option);
        return loadMask;
      }
    });
    Object.defineProperty(this, "$windowLoadMask", {
      get: function() {
        return vm.$loadMask;
      }
    });
    Object.defineProperty(this, "$bodyLoadMask", {
      get: function() {
        if (bodyLoadMask) {
          return bodyLoadMask;
        }
        vm.__BodyLoadMaskInited = true;
        bodyLoadMask = new LoadMask(vm.win.bodyEl);
        return bodyLoadMask;
      }
    });
    if (!this.renderOnShown) {
      this.__initSteps();
    }
  },
  beforeDestroy: function() {
    if (this.__loadMaskInited) {
      this.$loadMask.destroy();
    }
    if (this.__BodyLoadMaskInited) {
      this.$bodyLoadMask.destroy();
    }
  },
  destroyed() {
    this.win.destroy();
  },
  methods: $.extend({}, methods$1, {
    submit: function() {
      const vm = this;
      when(vm._fixBefore(vm.beforeSubmit)).then(function(result) {
        if (result === false) {
          return;
        }
        vm.$emit("submit");
        vm.win.hide();
      });
    },
    cancel: function() {
      const vm = this;
      when(vm._fixBefore(vm.beforeCancel)).then(function(result) {
        if (result === false) {
          return;
        }
        vm.$emit("cancel");
        vm.win.hide();
      });
    },
    prev: function() {
      this.stepsComponent.prev();
    },
    next: function() {
      this.stepsComponent.next();
    },
    _fixBefore: function(value) {
      return typeof value === "boolean" ? value : value();
    },
    __initSteps() {
      if (!this.steps) {
        return;
      }
      this.stepsComponent = this.$vnode.context.$refs[this.steps];
      if (!this.stepsComponent || this.stepsComponent.$options.componentName !== componentName.steps) {
        const errMsg = `Expect definition of "${componentName.steps}" component inner "${componentName.window}" component.`;
        throw new Error(errMsg);
      }
      this.stepsComponent.$on("after", () => {
        this.updateUtid();
        this.inFirst = this.stepsComponent.inFirst();
        this.inEnd = this.stepsComponent.inEnd();
      });
      this.inFirst = this.stepsComponent.inFirst();
      this.inEnd = this.stepsComponent.inEnd();
      this.updateUtid();
    },
    getPrefixedClassName,
    getFullUtid(utidBase) {
      return this.utid ? `${this.utid}-${utidBase}` : utidBase;
    },
    updateUtid() {
      var _a, _b;
      const step = (_b = (_a = this.stepsComponent) == null ? void 0 : _a.steps) == null ? void 0 : _b.href;
      this.prevUtid = [this.utid, step, "prev"].filter((char) => char).join("-");
      this.nextUtid = [this.utid, step, "next"].filter((char) => char).join("-");
    },
    __getLoadMaskConfig() {
      const vm = this;
      return {
        target: vm.win.winEl,
        option: {
          cls: getPrefixedClassName("sfis-window_load-mask")
        }
      };
    }
  })
};
const __vue_script__$1 = script$1;
var __vue_render__$1 = function() {
  var _obj;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    { class: _vm.getPrefixedClassName("sf-window") },
    [
      _c(
        "div",
        {
          ref: "top",
          class: (_obj = {}, _obj[_vm.getPrefixedClassName("sf-window-illustration")] = _vm.isIllustration, _obj)
        },
        [
          _vm._t("top", [
            _c(
              "div",
              {
                class: [
                  _vm.getPrefixedClassName("sf-window__title"),
                  "ellipsis"
                ],
                attrs: { "data-tip": _vm.title }
              },
              [_vm._v("\n        " + _vm._s(_vm.title) + "\n      ")]
            )
          ])
        ],
        2
      ),
      _vm._v(" "),
      (_vm.renderOnShown ? _vm.isShown : true) ? _c(
        "sf-flex",
        {
          class: _vm.getPrefixedClassName("sf-window_inner"),
          attrs: { "flex-direction": "column" }
        },
        [
          _vm.$slots.header || _vm.$slots["header-inner"] ? _c(
            "sf-flex-item",
            {
              class: _vm.getPrefixedClassName("sf-window_header"),
              attrs: { flex: "0 0 auto" }
            },
            [
              _vm._t("header", [
                _c(
                  "div",
                  {
                    class: _vm.getPrefixedClassName(
                      "sf-window_header-inner"
                    )
                  },
                  [_vm._t("header-inner")],
                  2
                )
              ])
            ],
            2
          ) : _vm._e(),
          _vm._v(" "),
          _vm.alert || _vm.$slots.alert ? _c(
            "sf-flex-item",
            { attrs: { flex: "0 0 auto" } },
            [
              _c(
                "sf-alert",
                {
                  class: _vm.getPrefixedClassName("sf-window__alert"),
                  attrs: {
                    size: "small",
                    border: "",
                    type: "enbedded",
                    align: "left"
                  }
                },
                [
                  _vm._t("alert", [
                    _vm._v(
                      "\n          " + _vm._s(_vm.alert) + "\n        "
                    )
                  ])
                ],
                2
              )
            ],
            1
          ) : _vm._e(),
          _vm._v(" "),
          _c(
            "sf-flex-item",
            { class: _vm.bodyCls, attrs: { flex: _vm.bodyFlex } },
            [
              _vm._t("default", [
                _c(
                  "div",
                  {
                    class: _vm.getPrefixedClassName("sf-window_body-inner")
                  },
                  [_vm._t("body-inner")],
                  2
                )
              ])
            ],
            2
          )
        ],
        1
      ) : _vm._e(),
      _vm._v(" "),
      _c(
        "div",
        { ref: "footer", class: _vm.getPrefixedClassName("sf-window_footer") },
        [
          _vm._t(
            "footer",
            [
              _c(
                "sf-flex",
                {
                  class: _vm.getPrefixedClassName("sf-window_footer-content"),
                  attrs: {
                    "align-items": "center",
                    "justify-content": _vm.buttonFlexAlign
                  }
                },
                [
                  _vm.hasSteps ? _c(
                    "sf-flex-item",
                    { attrs: { flex: "none" } },
                    [
                      !_vm.inFirst ? _c(
                        "sf-window-button",
                        {
                          class: _vm.getPrefixedClassName(
                            "sf-window-button--prev"
                          ),
                          attrs: {
                            type: "cancel",
                            disabled: _vm.isPreDisabled,
                            utid: _vm.prevUtid
                          },
                          on: {
                            click: function($event) {
                              return _vm.prev();
                            }
                          }
                        },
                        [
                          _vm._v(
                            "\n            " + _vm._s(_vm.prevText) + "\n          "
                          )
                        ]
                      ) : _vm._e()
                    ],
                    1
                  ) : _vm._e(),
                  _vm._v(" "),
                  _c(
                    "sf-flex-item",
                    { attrs: { flex: "none" } },
                    [
                      _vm.hasSteps && !_vm.inEnd ? _c(
                        "sf-window-button",
                        {
                          class: _vm.getPrefixedClassName(
                            "sf-window-button--next"
                          ),
                          attrs: {
                            type: "primary",
                            disabled: _vm.isNextDisabled,
                            utid: _vm.nextUtid
                          },
                          on: {
                            click: function($event) {
                              return _vm.next();
                            }
                          }
                        },
                        [
                          _vm._v(
                            "\n            " + _vm._s(_vm.nextText) + "\n          "
                          )
                        ]
                      ) : _vm._e(),
                      _vm._v(" "),
                      !_vm.isNoSubmit ? _c(
                        "sf-window-button",
                        {
                          class: _vm.getPrefixedClassName(
                            "sf-window-button--submit"
                          ),
                          attrs: {
                            type: "primary",
                            disabled: _vm.isSubmitDisabled,
                            utid: _vm.getFullUtid("submit")
                          },
                          on: {
                            click: function($event) {
                              return _vm.submit();
                            }
                          }
                        },
                        [
                          _vm._v(
                            "\n            " + _vm._s(_vm.submitText) + "\n          "
                          )
                        ]
                      ) : _vm._e(),
                      _vm._v(" "),
                      !_vm.isNoCancel ? _c(
                        "sf-window-button",
                        {
                          class: _vm.getPrefixedClassName(
                            "sf-window-button--cancel"
                          ),
                          attrs: {
                            type: "cancel",
                            disabled: _vm.isCancelDisabled,
                            utid: _vm.getFullUtid("cancel")
                          },
                          on: {
                            click: function($event) {
                              return _vm.cancel();
                            }
                          }
                        },
                        [
                          _vm._v(
                            "\n            " + _vm._s(_vm.cancelText) + "\n          "
                          )
                        ]
                      ) : _vm._e()
                    ],
                    1
                  )
                ],
                1
              )
            ],
            {
              submit: _vm.submit,
              cancel: _vm.cancel,
              submitText: _vm.submitText,
              cancelText: _vm.cancelText,
              align: _vm.buttonAlign,
              noSubmit: _vm.isNoSubmit,
              noCancel: _vm.isNoCancel,
              nextDisabled: _vm.isNextDisabled,
              preDisabled: _vm.isPreDisabled,
              submitDisabled: _vm.isSubmitDisabled,
              cancelDisabled: _vm.isCancelDisabled
            }
          )
        ],
        2
      )
    ],
    1
  );
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
function reserveEventsAfterDestroy(vueInstance) {
  let events;
  let isDestroyed;
  vueInstance.$on("hook:beforeDestroy", () => {
    events = vueInstance._events;
    isDestroyed = true;
  });
  const originEmit = vueInstance.$emit;
  vueInstance.$emit = function() {
    if (isDestroyed && vueInstance._events !== events) {
      vueInstance._events = events;
    }
    originEmit.apply(vueInstance, arguments);
  };
}
const BASE_CONFIG = {
  props: {
    autoDestroy: {
      default: true
    }
  },
  mounted() {
    this.__win = this.$refs.win;
    if (!this.__win) {
      this.__win = this.$children.filter((child) => child.$options.name.match(/window$/i))[0];
    }
    if (!this.__win) {
      throw new Error('Definition of "window" is expected.');
    }
    Object.defineProperty(this, "$loadMask", {
      configurable: true,
      get: function() {
        return this.__win.$loadMask;
      }
    });
    Object.defineProperty(this, "$windowLoadMask", {
      configurable: true,
      get: function() {
        return this.__win.$loadMask;
      }
    });
    this.__win.$on("show", () => {
      this.__silentHide = false;
    });
    this.__win.$on("hide", () => {
      if (this.__silentHide) {
        return;
      }
      this.$emit("hide");
      if (this.autoDestroy) {
        this.$destroy();
        this.__win = null;
      }
    });
  },
  methods: {
    show() {
      this.__win.show();
    },
    hide() {
      this.__win.hide();
    },
    silentHide() {
      this.__silentHide = true;
      this.hide();
    },
    __getLoadMaskConfig() {
      var _a, _b;
      return (_b = (_a = this.__win).__getLoadMaskConfig) == null ? void 0 : _b.call(_a);
    }
  }
};
function vueWindowCreator(vueConfig) {
  vueConfig = $.extend(
    {
      mixins: []
    },
    vueConfig
  );
  vueConfig.mixins.push(BASE_CONFIG);
  const WindowConfig = vueConfig;
  WindowConfig.create = function(config = {}, winConfig = {}) {
    const { noDeepcopy = false } = winConfig;
    const WindowModule = globalConfig.VueConstructor.extend(WindowConfig);
    const autoWin = new WindowModule({
      propsData: noDeepcopy ? config : $.extend(true, {}, config)
    });
    reserveEventsAfterDestroy(autoWin);
    autoWin.$mount();
    return autoWin;
  };
  return WindowConfig;
}
const methods = Object.keys(__vue_component__$1.methods).reduce(function(map, name) {
  if (typeof __vue_component__$1.methods[name] === "function" && name !== "constructor") {
    map[name] = function(...args) {
      return this.$refs.win[name](...args);
    };
  }
  return map;
}, {});
var script = {
  components: {
    SfWindow: __vue_component__$1,
    SfWindowButton,
    SfForm,
    SfFormItem,
    SfInput
  },
  props: $.extend({}, __vue_component__$1.props, {
    subtitle: {},
    content: {},
    type: {},
    withOk: Boolean,
    withPassword: Boolean,
    contentUseHtml: Boolean,
    subTitleUseHtml: Boolean,
    title: $.extend({}, __vue_component__$1.props.title, {
      default: () => $i("scp.vt_component.sf_widget.packages.message_box.base.window_default_title")
    }),
    minHeight: $.extend({}, __vue_component__$1.props.minHeight, {
      default: 212
    }),
    maxHeight: $.extend({}, __vue_component__$1.props.maxHeight, {
      default: 600
    }),
    verifyPasswordApi: {
      type: Function
    },
    size: {
      type: String,
      default: "normal"
    }
  }),
  data() {
    const username = globalConfig.username || "";
    const userNameTip = $i("scp.vt_component.sf_widget.packages.message_box.base.username_tip", {
      0: username === "admin@vtp" ? "admin" : username
    });
    return {
      okValid: false,
      password: "",
      inputOkMsg: $i("scp.vt_component.sf_widget.packages.message_box.base.confirm_text"),
      userNameTip,
      psdPlaceholder: $i("scp.vt_component.sf_widget.packages.message_box.base.password_input_placeholder"),
      okPlaceholder: $i("scp.vt_component.sf_widget.packages.message_box.base.text_input_placeholder")
    };
  },
  computed: {
    subtitleList() {
      return $.makeArray(this.subtitle);
    },
    contentList() {
      return $.makeArray(this.content);
    },
    isWithOk() {
      return isPropEnabled(this.withOk);
    },
    isWithPassword() {
      return isPropEnabled(this.withPassword);
    },
    isContentUseHtml() {
      return isPropEnabled(this.contentUseHtml);
    },
    isSubTitleUseHtml() {
      return isPropEnabled(this.subTitleUseHtml);
    },
    isConfirmLikeType() {
      return this.type === "danger" || this.type === "confirm" || this.type === "delete";
    },
    isNoSubmit() {
      if (!this.isConfirmLikeType && !hasDefinedProp(this, "noSubmit")) {
        return true;
      }
      return this.noSubmit;
    },
    currentCancelText() {
      if (!hasDefinedProp(this, "cancelText")) {
        if (this.isNoSubmit) {
          return $i("scp.vt_component.sf_widget.packages.message_box.base.default_cancel_text");
        }
        return this.cancelText;
      }
      return this.cancelText;
    },
    currentTitle() {
      if (!hasDefinedProp(this, "title")) {
        if (this.type === "error") {
          return $i("scp.vt_component.sf_widget.packages.message_box.base.error_title");
        }
        if (this.type === "danger") {
          return $i("scp.vt_component.sf_widget.packages.message_box.base.danger_title");
        }
        if (this.type === "info") {
          return $i("scp.vt_component.sf_widget.packages.message_box.base.info_title");
        }
      }
      return this.title;
    },
    currentBtnAlign() {
      if (this.isConfirmLikeType && !hasDefinedProp(this, "buttonAlign")) {
        return "right";
      }
      return this.buttonAlign;
    },
    isSubmitDisabled() {
      if (!hasDefinedProp(this, "submitDisabled") && this.isWithOk && !this.okValid) {
        return true;
      }
      return this.submitDisabled;
    },
    currentProps() {
      const messageCls = ` ${getPrefixedClassName(`sf-message-box--${this.size}`)} ${getPrefixedClassName(
        "sf-message-box"
      )}`;
      const props = $.extend({}, this.$props, {
        cls: (this.cls || "") + messageCls,
        title: this.currentTitle,
        noSubmit: this.isNoSubmit,
        cancelText: this.currentCancelText,
        buttonAlign: this.currentBtnAlign,
        submitDisabled: this.isSubmitDisabled,
        beforeSubmit: (...args) => {
          return $.when(this.isWithPassword ? this.__checkPassword() : true).then((result) => {
            if (result === false) {
              return false;
            }
            result = this.$props.beforeSubmit;
            if ($.isFunction(result)) {
              result = result(...args);
            }
            return when(result);
          });
        }
      });
      delete props.verifyPasswordApi;
      return props;
    },
    iconfont() {
      const iconMap = {
        confirm: "win-tip",
        info: "win-info",
        warn: "win-tip",
        success: "done",
        danger: "win-tip",
        error: "win-fail",
        delete: "win-tip"
      };
      return ["iconfont", "vtv-icon-" + iconMap[this.type], getPrefixedClassName("sf-message-box_icon-" + this.type)];
    },
    listeners() {
      return ["show", "hide", "submit", "cancel"].reduce((map, eventName) => {
        map[eventName] = (...args) => {
          this.$emit.apply(this, [eventName].concat(args));
        };
        return map;
      }, {});
    }
  },
  mounted() {
    this.$refs.win.$on("show", () => {
      if (this.$refs.okField) {
        this.$refs.okField.focus();
      }
      if (this.$refs.passwordField) {
        this.$refs.passwordField.focus();
      }
    });
    Object.defineProperty(this, "$loadMask", {
      get() {
        return this.$refs.win && this.$refs.win.$loadMask;
      }
    });
    Object.defineProperty(this, "$windowLoadMask", {
      configurable: true,
      get: function() {
        return this.$loadMask;
      }
    });
    Object.defineProperty(this, "$bodyLoadMask", {
      get() {
        return this.$refs.win && this.$refs.win.$bodyLoadMask;
      }
    });
  },
  methods: $.extend({}, methods, {
    getFullUtid(utidBase) {
      return this.utid ? `${this.utid}-${utidBase}` : utidBase;
    },
    __validateOk(value) {
      this.okValid = String(value).toLowerCase() === "ok";
      return this.okValid ? true : $i("scp.vt_component.sf_widget.packages.message_box.base.text_input_tip");
    },
    __checkPassword() {
      const api = this.verifyPasswordApi || getVerifyPasswordApi();
      if (!api) {
        notify.fail($i("scp.vt_component.sf_widget.packages.message_box.base.check_password_api_fail_tip"));
        return false;
      }
      const defer = $.Deferred();
      const password = $.trim(this.password);
      const loadMask = this.$loadMask;
      if (!password) {
        notify.fail($i("scp.vt_component.sf_widget.packages.message_box.base.check_password_input_password_tip"));
        return false;
      }
      loadMask.show({
        text: $i("scp.vt_component.sf_widget.packages.message_box.base.check_password_load_text")
      });
      api({
        password
      }).always((success, json) => {
        loadMask.hide();
        if (!success) {
          notify.fail(
            json && json.message || $i("scp.vt_component.sf_widget.packages.message_box.base.check_password_api_error_tip")
          );
          defer.reject();
          return;
        }
        defer.resolve();
      });
      return defer.promise();
    },
    formatText(text) {
      if (typeof text !== "string") {
        return text;
      }
      const formattedText = format.nl2br(text);
      const hasWhite = this.getIsUseHtml(formattedText);
      if (hasWhite) {
        return xssFilter(formattedText);
      }
      return formattedText;
    },
    getIsUseHtml(text) {
      if (typeof text !== "string") {
        return false;
      }
      const formattedText = format.nl2br(text);
      const hasWhite = whiteList.some((item) => item.test(formattedText));
      return hasWhite;
    },
    filterNoNotify(textContent) {
      if (typeof checkNoNotify === "function" && checkNoNotify(textContent)) {
        return filterNoNotifyPrefix(textContent);
      }
      return textContent;
    },
    getPrefixedClassName
  })
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "sf-window",
    _vm._g(
      _vm._b(
        {
          ref: "win",
          scopedSlots: _vm._u(
            [
              {
                key: "footer",
                fn: function(props) {
                  return [
                    _vm._t(
                      "footer",
                      [
                        _c(
                          "div",
                          { style: { "text-align": props.align } },
                          [
                            !props.noSubmit ? _c(
                              "sf-window-button",
                              {
                                attrs: {
                                  utid: _vm.getFullUtid(
                                    "message-box-submit-btn"
                                  ),
                                  type: "primary",
                                  disabled: props.submitDisabled
                                },
                                on: {
                                  click: function($event) {
                                    return props.submit();
                                  }
                                }
                              },
                              [
                                _vm._v(
                                  "\n          " + _vm._s(props.submitText) + "\n        "
                                )
                              ]
                            ) : _vm._e(),
                            _vm._v(" "),
                            !props.noCancel ? _c(
                              "sf-window-button",
                              {
                                attrs: {
                                  type: "cancel",
                                  utid: _vm.getFullUtid(
                                    "message-box-cancel-btn"
                                  ),
                                  disabled: props.cancelDisabled
                                },
                                on: {
                                  click: function($event) {
                                    return props.cancel();
                                  }
                                }
                              },
                              [
                                _vm._v(
                                  "\n          " + _vm._s(props.cancelText) + "\n        "
                                )
                              ]
                            ) : _vm._e()
                          ],
                          1
                        )
                      ],
                      null,
                      props
                    )
                  ];
                }
              }
            ],
            null,
            true
          )
        },
        "sf-window",
        _vm.currentProps,
        false
      ),
      _vm.listeners
    ),
    [
      _c(
        "div",
        {
          staticClass: "pull-left",
          class: _vm.getPrefixedClassName("sf-message-box_tip")
        },
        [
          _vm._t("icon", [
            _vm.iconfont ? _c("i", {
              class: [
                _vm.iconfont,
                _vm.getPrefixedClassName("sf-message-box_icon")
              ]
            }) : _c("div", {
              class: [
                _vm.getPrefixedClassName("sf-message-box_icon"),
                _vm.getPrefixedClassName("is-" + _vm.type)
              ]
            })
          ])
        ],
        2
      ),
      _vm._v(" "),
      _c("div", { class: _vm.getPrefixedClassName("sf-message-box_inner") }, [
        _vm.$slots.subtitle || _vm.subtitle ? _c(
          "div",
          { class: _vm.getPrefixedClassName("sf-message-box_subtitle") },
          [
            _vm._t(
              "subtitle",
              _vm._l(_vm.subtitleList, function(subtitle, i) {
                return _c(
                  "div",
                  { key: i },
                  [
                    _vm.isSubTitleUseHtml || _vm.getIsUseHtml(subtitle) ? _c("div", {
                      domProps: {
                        innerHTML: _vm._s(_vm.formatText(subtitle))
                      }
                    }) : [
                      _vm._v(
                        "\n            " + _vm._s(_vm.filterNoNotify(subtitle)) + "\n          "
                      )
                    ]
                  ],
                  2
                );
              })
            )
          ],
          2
        ) : _vm._e(),
        _vm._v(" "),
        _vm.$slots.default || _vm.content ? _c(
          "div",
          { class: _vm.getPrefixedClassName("sf-message-box_content") },
          [
            _vm._t("default", [
              _vm.isContentUseHtml || _vm.getIsUseHtml(_vm.content) ? _c("div", {
                domProps: {
                  innerHTML: _vm._s(_vm.formatText(_vm.content))
                }
              }) : _vm._l(_vm.contentList, function(content, i) {
                return _c("div", { key: i }, [
                  _vm._v(
                    "\n            " + _vm._s(_vm.filterNoNotify(content)) + "\n          "
                  )
                ]);
              })
            ])
          ],
          2
        ) : _vm._e(),
        _vm._v(" "),
        _vm.$slots["sub-footer"] ? _c(
          "div",
          { class: _vm.getPrefixedClassName("sf-message-box_confirm") },
          [_vm._t("sub-footer")],
          2
        ) : _vm.isWithOk ? _c(
          "div",
          { class: _vm.getPrefixedClassName("sf-message-box_confirm") },
          [
            _c("div", {
              class: _vm.getPrefixedClassName(
                "sf-message-box_confirm-text"
              ),
              domProps: { innerHTML: _vm._s(_vm.inputOkMsg) }
            }),
            _vm._v(" "),
            _c(
              "sf-form",
              {
                attrs: { padding: false },
                nativeOn: {
                  submit: function($event) {
                    $event.preventDefault();
                  }
                }
              },
              [
                _c(
                  "sf-form-item",
                  [
                    _c("sf-input", {
                      ref: "okField",
                      attrs: {
                        type: "text",
                        size: "small",
                        placeholder: _vm.okPlaceholder,
                        validator: _vm.__validateOk
                      },
                      on: { input: _vm.__validateOk }
                    })
                  ],
                  1
                )
              ],
              1
            )
          ],
          1
        ) : _vm.isWithPassword ? _c(
          "div",
          { class: _vm.getPrefixedClassName("sf-message-box_confirm") },
          [
            _c(
              "div",
              {
                class: _vm.getPrefixedClassName(
                  "sf-message-box_confirm-text"
                )
              },
              [_vm._v("\n        " + _vm._s(_vm.userNameTip) + "\n      ")]
            ),
            _vm._v(" "),
            _c("sf-input", {
              ref: "passwordField",
              attrs: {
                utid: _vm.getFullUtid("box-password"),
                type: "password",
                size: "small",
                placeholder: _vm.psdPlaceholder
              },
              model: {
                value: _vm.password,
                callback: function($$v) {
                  _vm.password = $$v;
                },
                expression: "password"
              }
            })
          ],
          1
        ) : _vm._e()
      ])
    ]
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
const factory = (type, componentName2) => {
  return {
    name: componentName2,
    componentName: componentName2,
    extends: __vue_component__,
    props: {
      type: {
        default: type,
        validator: function(value) {
          if (value !== type) {
            throw new Error('Avoid overwriting prop "type" the value of which must be "' + type + '"');
          }
          return true;
        }
      },
      utid: {
        type: String,
        default: `${type}-window`
      }
    }
  };
};
const openCreator = function(component) {
  return function(propsData) {
    const win = new (globalConfig.VueConstructor.extend(component))({
      propsData
    });
    win.$mount();
    win.show();
    if (typeof propsData.autoDestroy === "undefined" || propsData.autoDestroy) {
      win.$on("hide", () => win.$destroy());
    }
    reserveEventsAfterDestroy(win);
    return win;
  };
};
const SfConfirmWindow = factory("confirm", componentName.confirmWindow);
const SfInfoWindow = factory("info", componentName.infoWindow);
const SfWarnWindow = factory("warn", componentName.warnWindow);
const SfSuccessWindow = factory("success", componentName.successWindow);
const SfDangerWindow = factory("danger", componentName.dangerWindow);
const SfErrorWindow = factory("error", componentName.errorWindow);
const SfDeleteWindow = factory("delete", componentName.deleteWindow);
const messageBoxCreators = {
  $confirmWindow: openCreator(SfConfirmWindow),
  $infoWindow: openCreator(SfInfoWindow),
  $warnWindow: openCreator(SfWarnWindow),
  $successWindow: openCreator(SfSuccessWindow),
  $dangerWindow: openCreator(SfDangerWindow),
  $errorWindow: openCreator(SfErrorWindow),
  $deleteWindow: openCreator(SfDeleteWindow)
};
export { SfConfirmWindow, SfDangerWindow, SfDeleteWindow, SfErrorWindow, SfInfoWindow, SfSuccessWindow, SfWarnWindow, __vue_component__$1 as SfWindow, SfWindowButton, messageBoxCreators, vueWindowCreator };
