import { componentName } from '@sxf/er-components/_const';
import { getPrefixedClassName } from '@sxf/er-feature';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
const LIST_SIZE = ["small", "normal", "large"];
const LIST_TOKEN = Symbol("listToken");
var script$1 = {
  name: componentName.list,
  componentName: componentName.list,
  provide() {
    return {
      [LIST_TOKEN]: {
        getSize: () => this.size,
        getSplit: () => this.split,
        getSectionMaxWidth: () => this.sectionMaxWidth
      }
    };
  },
  props: {
    size: {
      type: String,
      default: "normal",
      validator: (val) => LIST_SIZE.includes(val)
    },
    split: {
      type: Boolean,
      default: true
    },
    bordered: {
      type: Boolean,
      default: false
    },
    sectionMaxWidth: {
      type: Number,
      validator: (val) => val > 0 && val <= 100
    }
  },
  data() {
    return {};
  },
  computed: {
    listWrapperClass() {
      return [getPrefixedClassName("sf-list"), { [getPrefixedClassName("sf-list-bordered")]: this.bordered }];
    }
  }
};
const __vue_script__$1 = script$1;
var __vue_render__$1 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    { class: _vm.listWrapperClass, attrs: { utid: "list-area" } },
    [_vm._t("default")],
    2
  );
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
var script = {
  name: componentName.listItem,
  componentName: componentName.listItem,
  inject: { list: LIST_TOKEN },
  props: {
    title: String,
    description: String,
    utid: String | Number,
    onTitleClick: Function
  },
  data() {
    return {};
  },
  computed: {
    listSize() {
      return this.list.getSize();
    },
    showDescription() {
      return this.listSize === "small" ? false : this.description || this.$slots.desc;
    },
    wrapperClass() {
      const split = this.list.getSplit();
      return [
        getPrefixedClassName("sf-list-item"),
        getPrefixedClassName(`sf-list-item--${this.listSize}`),
        { [getPrefixedClassName("sf-list-item--split")]: split }
      ];
    },
    sectionStyle() {
      const sectionMaxWidth = this.list.getSectionMaxWidth();
      return sectionMaxWidth ? { maxWidth: `${sectionMaxWidth}%` } : {};
    }
  },
  methods: {
    getPrefixedClassName,
    handleClickTitle(event) {
      var _a, _b;
      (_b = this.onTitleClick) == null ? void 0 : _b.call(this, event, { title: (_a = this.title) != null ? _a : "" });
    },
    getUtid(type) {
      return this.$attrs.utid ? `${this.$attrs.utid}-${type}` : type;
    }
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    { class: _vm.wrapperClass, attrs: { utid: _vm.getUtid("item-area") } },
    [
      _c(
        "div",
        {
          class: _vm.getPrefixedClassName("sf-list-item__section"),
          style: _vm.sectionStyle
        },
        [
          _vm.$slots.icon ? _c(
            "div",
            {
              class: _vm.getPrefixedClassName("sf-list-item__icon"),
              attrs: { utid: _vm.getUtid("icon-area") }
            },
            [_vm._t("icon")],
            2
          ) : _vm._e(),
          _vm._v(" "),
          _vm.$slots.info ? [_vm._t("info")] : _c(
            "div",
            { class: _vm.getPrefixedClassName("sf-list-item__info") },
            [
              _c(
                "div",
                {
                  class: _vm.getPrefixedClassName(
                    "sf-list-item__info-title"
                  )
                },
                [
                  _c(
                    "span",
                    {
                      class: _vm.getPrefixedClassName(
                        "sf-list-item__info-span"
                      ),
                      attrs: {
                        utid: _vm.getUtid("title-area"),
                        "data-tip": _vm.title
                      },
                      on: {
                        click: function($event) {
                          $event.preventDefault();
                          return _vm.handleClickTitle($event);
                        }
                      }
                    },
                    [_vm._t("title", [_vm._v(_vm._s(_vm.title || ""))])],
                    2
                  )
                ]
              ),
              _vm._v(" "),
              _vm.showDescription ? _c(
                "div",
                {
                  class: _vm.getPrefixedClassName(
                    "sf-list-item__info-desc"
                  )
                },
                [
                  _c(
                    "span",
                    {
                      class: _vm.getPrefixedClassName(
                        "sf-list-item__info-span"
                      ),
                      attrs: {
                        utid: _vm.getUtid("desc-area"),
                        "data-tip": _vm.description
                      }
                    },
                    [_vm._t("desc", [_vm._v(_vm._s(_vm.description))])],
                    2
                  )
                ]
              ) : _vm._e()
            ]
          )
        ],
        2
      ),
      _vm._v(" "),
      _vm.$slots.details ? _c(
        "div",
        {
          class: _vm.getPrefixedClassName("sf-list-item__details"),
          attrs: { utid: _vm.getUtid("details-area") }
        },
        [_vm._t("details")],
        2
      ) : _vm._e(),
      _vm._v(" "),
      _vm.$slots.operating ? _c(
        "div",
        {
          class: _vm.getPrefixedClassName("sf-list-item__operating"),
          attrs: { utid: _vm.getUtid("operating-area") }
        },
        [_vm._t("operating")],
        2
      ) : _vm._e()
    ]
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__$1 as SfList, __vue_component__ as SfListItem };
