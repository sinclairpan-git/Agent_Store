import { componentName } from '@sxf/er-components/_const';
import { SfButton } from '@sxf/er-components/button';
import { SfInput } from '@sxf/er-components/input';
import { SfSelect } from '@sxf/er-components/select';
import { $i } from '@sxf/er-config';
import { getPrefixedClassName } from '@sxf/er-feature';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
const generatePage = function(start, end) {
  const pageList = [];
  for (let index = start; index <= end; index++) {
    pageList.push({ index, type: "page", key: `page-${index}` });
  }
  return pageList;
};
const generateRangeItem = (pageIndex, lastIndex) => {
  let listOfRange = [];
  const prevItem = { type: "prev", key: `page-prev` };
  const nextItem = { type: "next", key: `page-next` };
  if (pageIndex < 6) {
    listOfRange = [...generatePage(2, 7), nextItem];
  } else if (pageIndex < lastIndex - 4) {
    listOfRange = [prevItem, ...generatePage(pageIndex - 2, pageIndex + 2), nextItem];
  } else {
    listOfRange = [prevItem, ...generatePage(lastIndex - 6, lastIndex - 1)];
  }
  const firstPageItem = generatePage(1, 1);
  const lastPageItem = generatePage(lastIndex, lastIndex);
  return [...firstPageItem, ...listOfRange, ...lastPageItem];
};
var script = {
  name: componentName.pagination,
  componentName: componentName.pagination,
  components: {
    SfButton,
    SfInput,
    SfSelect
  },
  model: {
    prop: "pageIndex",
    event: "input.page-index"
  },
  props: {
    pageSizeList: {
      type: Array,
      default: () => [20, 50]
    },
    size: {
      validator: function(value) {
        return ["small", "normal"].includes(value);
      },
      default: "small"
    },
    total: {
      type: Number,
      default: 0
    },
    pageIndex: {
      type: Number,
      default: 1
    },
    pageSize: {
      type: Number,
      default: 20
    },
    simple: {
      type: Boolean,
      default: false
    },
    showTotal: {
      type: Boolean,
      default: true
    },
    showSizeChanger: {
      type: Boolean,
      default: true
    },
    showQuickJumper: {
      type: Boolean,
      default: true
    },
    showMore: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      currentPageIndex: this.pageIndex,
      currentPageSize: this.pageSize,
      jumpPageIndex: this.pageIndex
    };
  },
  computed: {
    totalText() {
      return $i("scp.vt_component.common.widget.Grid.plugins.PagingBar.update_page_bar_total", {
        0: this.total
      });
    },
    prevBtnTitle() {
      return $i("scp.vt_component.common.widget.Grid.plugins.PagingBar.prev_btn");
    },
    nextBtnTitle() {
      return $i("scp.vt_component.common.widget.Grid.plugins.PagingBar.next_btn");
    },
    perPageText() {
      return $i("scp.vt_component.common.widget.Grid.plugins.PagingBar.entries_per_page");
    },
    goToText() {
      return $i("scp.vt_component.common.widget.Grid.plugins.PagingBar.label_goto");
    },
    dataUnit() {
      return $i("scp.vt_component.common.widget.Grid.plugins.PagingBar.label_unit");
    },
    pageUnit() {
      return $i("scp.vt_component.common.widget.Grid.plugins.PagingBar.label_unit_page");
    },
    pageSizeOptions() {
      return this.pageSizeList.map((size) => {
        return { id: size, text: size };
      });
    },
    paginationCls() {
      if (this.simple) {
        return getPrefixedClassName(`sf-pagination--simple`);
      }
      return getPrefixedClassName(`sf-pagination--${this.size}`);
    },
    totalPage() {
      return Math.ceil(this.total / this.currentPageSize);
    },
    pages() {
      if (this.totalPage < 10) {
        return generatePage(1, this.totalPage);
      }
      return generateRangeItem(this.currentPageIndex, this.totalPage);
    },
    prevBtnDisabled() {
      return this.currentPageIndex <= 1;
    },
    nextBtnDisabled() {
      return this.currentPageIndex >= this.totalPage;
    },
    additionalEvent() {
      return {
        keyup: this.handlePageIndexKeyup
      };
    },
    validatePageIndexResult() {
      return this.pageIndexValidator(this.jumpPageIndex);
    },
    pageIndexIsValid() {
      return this.validatePageIndexResult === true;
    },
    isShowMoreInfo() {
      if (this.simple) {
        return false;
      }
      return this.showMore;
    },
    jumpPageIndexDisabled() {
      return !(this.total > 0);
    },
    showBtnNav() {
      return this.total > 0;
    },
    jumpPageIndexPlaceholder() {
      return { text: "" };
    }
  },
  watch: {
    pageIndex(val) {
      this.currentPageIndex = val;
    },
    pageSize(val) {
      this.currentPageSize = val;
    },
    currentPageIndex(val) {
      this.emitChange();
      this.jumpPageIndex = val;
    },
    currentPageSize(val) {
      this.$emit("page-size-change", val);
      if (this.currentPageIndex !== 1) {
        this.setPageIndex(1);
      } else {
        this.emitChange();
      }
    },
    validatePageIndexResult(validateResult) {
      if (validateResult !== true) {
        validateResult = [validateResult];
      }
      this.setPageIndexValidateState(validateResult);
    }
  },
  methods: {
    getPrefixedClassName,
    getFullUtid(utidBase) {
      return this.$attrs.utid ? `${this.$attrs.utid}-${utidBase}` : utidBase;
    },
    setPageIndex(val) {
      const numberVal = Number(val);
      this.currentPageIndex = numberVal;
      this.$emit("input.page-index", numberVal);
    },
    clickPageItem(item) {
      if (item.index) {
        this.setPageIndex(item.index);
      }
    },
    goNext() {
      if (!this.nextBtnDisabled) {
        this.setPageIndex(this.currentPageIndex + 1);
      }
    },
    goPrev() {
      if (!this.prevBtnDisabled) {
        this.setPageIndex(this.currentPageIndex - 1);
      }
    },
    handlePageIndexKeyup(event) {
      if (this.pageIndexIsValid && event.keyCode === 13) {
        this.setPageIndex(this.jumpPageIndex);
      }
    },
    pageIndexValidator(val) {
      if (!/^-?[0-9]+$/.test(val)) {
        return $i("scp.vt_component.common.widget.Grid.plugins.PagingBar.valid_integer");
      }
      const value = parseInt(val, 10);
      if (value < 1) {
        return $i("scp.vt_component.common.widget.Grid.plugins.PagingBar.min_data", {
          0: 1
        });
      }
      if (value > this.totalPage) {
        return $i("scp.vt_component.common.widget.Grid.plugins.PagingBar.max_data", {
          0: this.totalPage
        });
      }
      return true;
    },
    setPageIndexValidateState(validateResult) {
      var _a;
      (_a = this.$refs.pageIndexInput) == null ? void 0 : _a.onValidate(validateResult);
    },
    emitChange() {
      this.$emit("change", this.currentPageIndex, this.currentPageSize);
    }
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    { class: [_vm.getPrefixedClassName("sf-pagination"), _vm.paginationCls] },
    [
      _vm.showTotal ? _c(
        "span",
        {
          class: [
            _vm.getPrefixedClassName("sf-pagination-total"),
            _vm.getPrefixedClassName("page-tip")
          ]
        },
        [_vm._v(_vm._s(_vm.totalText))]
      ) : _vm._e(),
      _vm._v(" "),
      _c(
        "div",
        {
          class: [
            _vm.getPrefixedClassName("sf-pagination-nav-btn-list"),
            _vm.getPrefixedClassName("nav-btn-list")
          ]
        },
        [
          _c("sf-button", {
            directives: [
              {
                name: "show",
                rawName: "v-show",
                value: _vm.showBtnNav,
                expression: "showBtnNav"
              }
            ],
            class: [
              _vm.getPrefixedClassName("sf-pagination-btn-nav"),
              _vm.getPrefixedClassName("btn-nav"),
              _vm.getPrefixedClassName("btn-prev")
            ],
            attrs: {
              type: "icon",
              icon: "prev-month",
              title: _vm.prevBtnTitle,
              disabled: _vm.prevBtnDisabled,
              utid: _vm.getFullUtid("pagingbar-btn-prev")
            },
            on: { click: _vm.goPrev }
          }),
          _vm._v(" "),
          _c(
            "ul",
            {
              class: [
                _vm.getPrefixedClassName("sf-pagination-page-number-wrap"),
                _vm.getPrefixedClassName("page-number-wrap")
              ]
            },
            [
              _vm.simple ? [
                _c(
                  "li",
                  [
                    _c("sf-input", {
                      ref: "pageIndexInput",
                      class: [
                        _vm.getPrefixedClassName(
                          "sf-pagination-page-index"
                        ),
                        _vm.getPrefixedClassName("page-index"),
                        _vm.getPrefixedClassName(
                          "sf-pagination-page-index-jumper"
                        )
                      ],
                      attrs: {
                        disabled: _vm.jumpPageIndexDisabled,
                        "additional-event": _vm.additionalEvent,
                        utid: _vm.getFullUtid("pagingbar-input-page-index"),
                        size: _vm.size
                      },
                      model: {
                        value: _vm.jumpPageIndex,
                        callback: function($$v) {
                          _vm.jumpPageIndex = $$v;
                        },
                        expression: "jumpPageIndex"
                      }
                    }),
                    _vm._v(" "),
                    _c(
                      "span",
                      {
                        class: [
                          _vm.getPrefixedClassName(
                            "sf-pagination-page-current-label"
                          ),
                          _vm.getPrefixedClassName("page-current-label")
                        ]
                      },
                      [_vm._v("/")]
                    ),
                    _vm._v(" "),
                    _c(
                      "span",
                      {
                        class: [
                          _vm.getPrefixedClassName(
                            "sf-pagination-page-total-label"
                          ),
                          _vm.getPrefixedClassName("page-total-label")
                        ]
                      },
                      [_vm._v(_vm._s(_vm.totalPage))]
                    )
                  ],
                  1
                )
              ] : _vm._l(_vm.pages, function(item) {
                return _c(
                  "li",
                  {
                    key: item.key,
                    class: [
                      _vm.getPrefixedClassName("sf-pagination-page-number"),
                      _vm.getPrefixedClassName("page-number"),
                      item.index === _vm.currentPageIndex ? _vm.getPrefixedClassName("active") : ""
                    ],
                    attrs: { utid: _vm.getFullUtid(item.key) },
                    on: {
                      click: function($event) {
                        return _vm.clickPageItem(item);
                      }
                    }
                  },
                  [
                    item.index ? [_vm._v(_vm._s(item.index))] : [
                      _c("i", {
                        class: [
                          _vm.getPrefixedClassName("iconfont"),
                          _vm.getPrefixedClassName("vtv-icon-more")
                        ]
                      })
                    ]
                  ],
                  2
                );
              })
            ],
            2
          ),
          _vm._v(" "),
          _c("sf-button", {
            directives: [
              {
                name: "show",
                rawName: "v-show",
                value: _vm.showBtnNav,
                expression: "showBtnNav"
              }
            ],
            class: [
              _vm.getPrefixedClassName("sf-pagination-btn-nav"),
              _vm.getPrefixedClassName("btn-nav"),
              _vm.getPrefixedClassName("btn-next")
            ],
            attrs: {
              type: "icon",
              icon: "next-month",
              title: _vm.nextBtnTitle,
              disabled: _vm.nextBtnDisabled,
              utid: _vm.getFullUtid("pagingbar-btn-next")
            },
            on: { click: _vm.goNext }
          }),
          _vm._v(" "),
          _vm.isShowMoreInfo ? _c(
            "span",
            { class: [_vm.getPrefixedClassName("pagination-more-info")] },
            [
              _vm.showSizeChanger ? [
                _c(
                  "label",
                  {
                    class: [
                      _vm.getPrefixedClassName("sf-pagination-label"),
                      _vm.getPrefixedClassName(
                        "sf-pagination-label-every"
                      ),
                      _vm.getPrefixedClassName("label"),
                      _vm.getPrefixedClassName("label-every")
                    ]
                  },
                  [
                    _vm._v(
                      "\n          " + _vm._s(_vm.perPageText) + "\n        "
                    )
                  ]
                ),
                _vm._v(" "),
                _c("sf-select", {
                  class: [
                    _vm.getPrefixedClassName("sf-pagination-page-size"),
                    _vm.getPrefixedClassName("page-limit")
                  ],
                  attrs: {
                    size: _vm.size,
                    options: _vm.pageSizeOptions,
                    width: "60px",
                    utid: _vm.getFullUtid(
                      "pagingbar-select-page-index"
                    )
                  },
                  model: {
                    value: _vm.currentPageSize,
                    callback: function($$v) {
                      _vm.currentPageSize = $$v;
                    },
                    expression: "currentPageSize"
                  }
                }),
                _vm._v(" "),
                _c(
                  "span",
                  {
                    class: [
                      _vm.getPrefixedClassName("sf-pagination-label"),
                      _vm.getPrefixedClassName(
                        "sf-pagination-label-unit"
                      ),
                      _vm.getPrefixedClassName("label"),
                      _vm.getPrefixedClassName("label-unit")
                    ]
                  },
                  [_vm._v(_vm._s(_vm.dataUnit))]
                )
              ] : _vm._e(),
              _vm._v(" "),
              _vm.showQuickJumper ? [
                _c(
                  "span",
                  {
                    class: [
                      _vm.getPrefixedClassName("sf-pagination-label"),
                      _vm.getPrefixedClassName(
                        "sf-pagination-label-to"
                      ),
                      _vm.getPrefixedClassName("label"),
                      _vm.getPrefixedClassName("label-to")
                    ]
                  },
                  [_vm._v(_vm._s(_vm.goToText))]
                ),
                _vm._v(" "),
                _c("sf-input", {
                  ref: "pageIndexInput",
                  class: [
                    _vm.getPrefixedClassName(
                      "sf-pagination-page-index"
                    ),
                    _vm.getPrefixedClassName("page-index"),
                    _vm.getPrefixedClassName(
                      "sf-pagination-page-index-jumper"
                    )
                  ],
                  attrs: {
                    placeholder: _vm.jumpPageIndexPlaceholder,
                    disabled: _vm.jumpPageIndexDisabled,
                    "additional-event": _vm.additionalEvent,
                    utid: _vm.getFullUtid("pagingbar-input-page-index"),
                    size: _vm.size
                  },
                  model: {
                    value: _vm.jumpPageIndex,
                    callback: function($$v) {
                      _vm.jumpPageIndex = $$v;
                    },
                    expression: "jumpPageIndex"
                  }
                }),
                _vm._v(" "),
                _c(
                  "span",
                  {
                    class: [
                      _vm.getPrefixedClassName("sf-pagination-label"),
                      _vm.getPrefixedClassName("label")
                    ]
                  },
                  [
                    _vm._v(
                      "\n          " + _vm._s(_vm.pageUnit) + "\n        "
                    )
                  ]
                )
              ] : _vm._e()
            ],
            2
          ) : _vm._e()
        ],
        1
      )
    ]
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__ as SfPagination };
