var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));

// packages/components/index.js
import { vOnShow, vPopover } from "@sxf/er-components/_directives";
import DestroyPlugin from "@sxf/er-components/_global/destroy";
import FactoryPlugin from "@sxf/er-components/_global/factory";
import KeycodePlugin from "@sxf/er-components/_global/keycode";
import LoadPlugin from "@sxf/er-components/_global/load";
import LoggerPlugin from "@sxf/er-components/_global/logger";
import LoadMaskPlugin from "@sxf/er-components/_global/mask";
import ModalPlugin from "@sxf/er-components/_global/modal";
import NotifyPlugin from "@sxf/er-components/_global/notify";
import OverridesPlugin from "@sxf/er-components/_global/overrides";
import AppRootPlugin from "@sxf/er-components/_global/root";
import SimpleRequestPlugin from "@sxf/er-components/_global/simple-request";
import UtilsPlugin from "@sxf/er-components/_global/utils";
import { globalConfig } from "@sxf/er-config";

// packages/components/_const/name.js
var others = {
  enableStatus: "SfEnableStatus",
  iconText: "SfIconText",
  odometer: "SfOdometer",
  page: "SfPage",
  reproduce: "SfReproduce",
  scrollFix: "SfScrollFix"
};
var componentName = {
  alert: "SfAlert",
  alertList: "SfAlertList",
  anchor: "SfAnchor",
  anchorLink: "SfAnchorLink",
  button: "SfButton",
  checkbox: "SfCheckbox",
  checkboxButton: "SfCheckboxButton",
  checkboxGroup: "SfCheckboxGroup",
  col: "SfCol",
  coverWindow: "SfCoverWindow",
  row: "SfRow",
  drag: "SfDrag",
  datePicker: "SfDatePicker",
  editor: "SfEditor",
  timePicker: "SfTimePicker",
  timeRangePicker: "SfTimeRangePicker",
  timeSelect: "SfTimeSelect",
  fieldset: "SfFieldset",
  flex: "SfFlex",
  flexItem: "SfFlexItem",
  form: "SfForm",
  formItem: "SfFormItem",
  formCollapse: "SfFormCollapse",
  input: "SfInput",
  ipInput: "SfIpInput",
  inputNumber: "SfInputNumber",
  layer: "SfLayer",
  layoutHeight: "SfLayoutHeight",
  list: "SfList",
  listItem: "SfListItem",
  menu: "SfMenu",
  menuItem: "SfMenuItem",
  navMenu: "SfNavMenu",
  navWrap: "SfNavWrap",
  navMenuItem: "SfNavMenuItem",
  navMenuPanel: "SfNavMenuPanel",
  navSubMenu: "SfNavSubMenu",
  navMenuPanelWrap: "SfNavMenuPanelWrap",
  pageNavWrap: "SfPageNavWrap",
  radio: "SfRadio",
  radioGroup: "SfRadioGroup",
  radioButton: "SfRadioButton",
  radioSelect: "SfRadioSelect",
  radioSwitch: "SfRadioSwitch",
  radioSwitchContent: "SfRadioSwitchContent",
  select: "SfSelect",
  menuSelect: "SfMenuSelect",
  separator: "SfSeparator",
  step: "SfStep",
  steps: "SfSteps",
  tag: "SfTag",
  tagGroup: "SfTagGroup",
  toolbar: "SfToolbar",
  toolbarWrap: "SfToolbarWrap",
  tabs: "SfTabs",
  tabsWrap: "SfTabsWrap",
  pane: "SfPane",
  space: "SfSpace",
  switch: "SfSwitch",
  scrollbar: "SfScrollbar",
  cascader: "SfCascader",
  empty: "SfEmpty",
  emptyWrap: "SfEmptyWrap",
  numberBadge: "SfNumberBadge",
  badge: "SfBadge",
  title: "SfTitle",
  popover: "SfPopover",
  popoverForm: "SfPopoverForm",
  card: "SfCard",
  block: "SfBlock",
  gridForm: "SfGridForm",
  gridFormColumn: "SfGridFormColumn",
  grid: "SfGrid",
  gridColumn: "SfGridColumn",
  combo: "SfCombo",
  comboColumn: "SfComboColumn",
  carousel: "SfCarousel",
  carouselInline: "SfCarouselInline",
  carouselItem: "SfCarouselItem",
  tree: "SfTree",
  treeTable: "SfTreeTable",
  treeHeader: "SfTreeHeader",
  treeSelect: "SfTreeSelect",
  treeTableSelect: "SfTreeTableSelect",
  path: "SfPath",
  progress: "SfProgress",
  circleProgress: "SfCircleProgress",
  stepProgress: "SfStepProgress",
  collapse: "SfCollapse",
  collapseItem: "SfCollapseItem",
  collapseTransition: "SfCollapseTransition",
  drawer: "SfDrawer",
  search: "SfSearch",
  searchTip: "SfSearchTip",
  gridSearchTip: "SfGridSearchTip",
  filter: "SfFilter",
  typeSearch: "SfTypeSearch",
  trigger: "SfTrigger",
  browserTrigger: "SfBrowserTrigger",
  searchTrigger: "SfSearchTrigger",
  dateTrigger: "SfDateTrigger",
  moreTrigger: "SfMoreTrigger",
  timeTrigger: "SfTimeTrigger",
  uploadTrigger: "SfUploadTrigger",
  window: "SfWindow",
  confirmWindow: "SfConfirmWindow",
  infoWindow: "SfInfoWindow",
  warnWindow: "SfWarnWindow",
  successWindow: "SfSuccessWindow",
  dangerWindow: "SfDangerWindow",
  errorWindow: "SfErrorWindow",
  deleteWindow: "SfDeleteWindow",
  windowButton: "SfWindowButton",
  pagination: "SfPagination",
  upload: "SfUpload",
  imageUpload: "SfImageUpload",
  fileListUpload: "SfFileListUpload",
  dragUpload: "SfDragUpload",
  ...others
};
var defaultPrefix = "Sf";

// packages/components/component.js
var component_exports = {};
__reExport(component_exports, alert_star);
__reExport(component_exports, anchor_star);
__reExport(component_exports, badge_star);
__reExport(component_exports, button_star);
__reExport(component_exports, card_star);
__reExport(component_exports, carousel_star);
__reExport(component_exports, cascader_star);
__reExport(component_exports, checkbox_star);
__reExport(component_exports, collapse_star);
__reExport(component_exports, combo_star);
__reExport(component_exports, cover_window_star);
__reExport(component_exports, date_picker_star);
__reExport(component_exports, drag_star);
__reExport(component_exports, drawer_star);
__reExport(component_exports, editor_star);
__reExport(component_exports, empty_star);
__reExport(component_exports, fieldset_star);
__reExport(component_exports, flex_star);
__reExport(component_exports, form_star);
__reExport(component_exports, grid_star);
__reExport(component_exports, grid_form_star);
__reExport(component_exports, input_star);
__reExport(component_exports, input_number_star);
__reExport(component_exports, layer_star);
__reExport(component_exports, layout_star);
__reExport(component_exports, layout_height_star);
__reExport(component_exports, list_star);
__reExport(component_exports, menu_star);
__reExport(component_exports, nav_menu_star);
__reExport(component_exports, path_star);
__reExport(component_exports, popover_star);
__reExport(component_exports, progress_star);
__reExport(component_exports, radio_star);
__reExport(component_exports, scrollbar_star);
__reExport(component_exports, search_star);
__reExport(component_exports, search_tip_star);
__reExport(component_exports, select_star);
__reExport(component_exports, separator_star);
__reExport(component_exports, space_star);
__reExport(component_exports, step_star);
__reExport(component_exports, switch_star);
__reExport(component_exports, tabs_star);
__reExport(component_exports, tag_star);
__reExport(component_exports, title_star);
__reExport(component_exports, toolbar_star);
__reExport(component_exports, tree_star);
__reExport(component_exports, tree_select_star);
__reExport(component_exports, trigger_star);
__reExport(component_exports, window_star);
__reExport(component_exports, pagination_star);
__reExport(component_exports, upload_star);
__reExport(component_exports, enable_status_star);
__reExport(component_exports, icon_text_star);
__reExport(component_exports, odometer_star);
__reExport(component_exports, page_star);
__reExport(component_exports, reproduce_star);
__reExport(component_exports, scroll_fix_star);
import * as alert_star from "@sxf/er-components/alert";
import * as anchor_star from "@sxf/er-components/anchor";
import * as badge_star from "@sxf/er-components/badge";
import * as button_star from "@sxf/er-components/button";
import * as card_star from "@sxf/er-components/card";
import * as carousel_star from "@sxf/er-components/carousel";
import * as cascader_star from "@sxf/er-components/cascader";
import * as checkbox_star from "@sxf/er-components/checkbox";
import * as collapse_star from "@sxf/er-components/collapse";
import * as combo_star from "@sxf/er-components/combo";
import * as cover_window_star from "@sxf/er-components/cover-window";
import * as date_picker_star from "@sxf/er-components/date-picker";
import * as drag_star from "@sxf/er-components/drag";
import * as drawer_star from "@sxf/er-components/drawer";
import * as editor_star from "@sxf/er-components/editor";
import * as empty_star from "@sxf/er-components/empty";
import * as fieldset_star from "@sxf/er-components/fieldset";
import * as flex_star from "@sxf/er-components/flex";
import * as form_star from "@sxf/er-components/form";
import * as grid_star from "@sxf/er-components/grid";
import * as grid_form_star from "@sxf/er-components/grid-form";
import * as input_star from "@sxf/er-components/input";
import * as input_number_star from "@sxf/er-components/input-number";
import * as layer_star from "@sxf/er-components/layer";
import * as layout_star from "@sxf/er-components/layout";
import * as layout_height_star from "@sxf/er-components/layout-height";
import * as list_star from "@sxf/er-components/list";
import * as menu_star from "@sxf/er-components/menu";
import * as nav_menu_star from "@sxf/er-components/nav-menu";
import * as path_star from "@sxf/er-components/path";
import * as popover_star from "@sxf/er-components/popover";
import * as progress_star from "@sxf/er-components/progress";
import * as radio_star from "@sxf/er-components/radio";
import * as scrollbar_star from "@sxf/er-components/scrollbar";
import * as search_star from "@sxf/er-components/search";
import * as search_tip_star from "@sxf/er-components/search-tip";
import * as select_star from "@sxf/er-components/select";
import * as separator_star from "@sxf/er-components/separator";
import * as space_star from "@sxf/er-components/space";
import * as step_star from "@sxf/er-components/step";
import * as switch_star from "@sxf/er-components/switch";
import * as tabs_star from "@sxf/er-components/tabs";
import * as tag_star from "@sxf/er-components/tag";
import * as title_star from "@sxf/er-components/title";
import * as toolbar_star from "@sxf/er-components/toolbar";
import * as tree_star from "@sxf/er-components/tree";
import * as tree_select_star from "@sxf/er-components/tree-select";
import * as trigger_star from "@sxf/er-components/trigger";
import * as window_star from "@sxf/er-components/window";
import * as pagination_star from "@sxf/er-components/pagination";
import * as upload_star from "@sxf/er-components/upload";
import * as enable_status_star from "@sxf/er-components/_pro/enable-status";
import * as icon_text_star from "@sxf/er-components/_pro/icon-text";
import * as odometer_star from "@sxf/er-components/_pro/odometer";
import * as page_star from "@sxf/er-components/_pro/page";
import * as reproduce_star from "@sxf/er-components/_pro/reproduce";
import * as scroll_fix_star from "@sxf/er-components/_pro/scroll-fix";

// packages/components/index.js
var installComponents = (Vue) => {
  const { prefixComp } = globalConfig;
  const components = Object.values(component_exports).filter((maybeComp) => {
    var _a;
    return (_a = maybeComp.name) == null ? void 0 : _a.startsWith(defaultPrefix);
  });
  if (prefixComp) {
    components.forEach((component) => {
      const compName = component.name.replace(defaultPrefix, prefixComp);
      component.name = compName;
    });
  }
  components.forEach((component) => {
    Vue.component(component.name, component);
  });
};
var installGlobalDirectives = (Vue) => {
  Vue.directive("on-show", vOnShow);
  Vue.directive("popover", vPopover);
};
var install = (Vue) => {
  Vue.config.devTools = false;
  Vue.config.productionTip = false;
  installGlobalDirectives(Vue);
  Vue.use(AppRootPlugin);
  Vue.use(OverridesPlugin);
  Vue.use(DestroyPlugin);
  Vue.use(LoadMaskPlugin);
  Vue.use(NotifyPlugin);
  Vue.use(LoggerPlugin);
  Vue.use(SimpleRequestPlugin);
  Vue.use(FactoryPlugin);
  Vue.use(KeycodePlugin);
  Vue.use(ModalPlugin);
  Vue.use(UtilsPlugin);
  Vue.use(LoadPlugin);
  installComponents(Vue);
};
var components_default = {
  install
};
export {
  components_default as default,
  install
};
