import { componentName } from '@sxf/er-components/_const';
import { FormTipMixin, EmitterMixin } from '@sxf/er-components/_mixins';
import { FormFieldMixin } from '@sxf/er-components/form';
import { getPrefixedClassName } from '@sxf/er-feature';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
import { $i } from '@sxf/er-config';
var script$2 = {
  name: componentName.checkbox,
  componentName: componentName.checkbox,
  mixins: [FormFieldMixin, FormTipMixin],
  props: {
    value: {},
    label: {},
    desc: String,
    indeterminate: Boolean,
    disabled: Boolean,
    readonly: Boolean,
    checked: Boolean,
    name: String,
    trueLabel: [String, Number],
    falseLabel: [String, Number],
    theme: String,
    flex: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      selfModel: false,
      focus: false,
      initValue: this.value
    };
  },
  computed: {
    model: {
      get() {
        return this.isGroup ? this.store : typeof this.value !== "undefined" ? this.value : this.selfModel;
      },
      set(val) {
        if (this.isGroup) {
          let isLimitExceeded = false;
          typeof this._checkboxGroup.min !== "undefined" && val.length < this._checkboxGroup.min && (isLimitExceeded = true);
          typeof this._checkboxGroup.max !== "undefined" && val.length > this._checkboxGroup.max && (isLimitExceeded = true);
          isLimitExceeded === false && this.dispatch(componentName.checkboxGroup, "input", [val]);
        } else {
          this.$emit("input", val);
          this.selfModel = val;
        }
      }
    },
    isChecked() {
      if (typeof this.trueLabel === "undefined" && (typeof this.model === "string" || typeof this.model === "number")) {
        return this.model;
      } else if (typeof this.model === "boolean") {
        return this.model;
      } else if (Array.isArray(this.model)) {
        return this.model.indexOf(this.label) > -1;
      } else if (this.model !== null && typeof this.model !== "undefined") {
        return this.model === this.trueLabel;
      }
      return false;
    },
    isGroup() {
      let parent = this.$parent;
      while (parent) {
        if (parent.$options.componentName !== componentName.checkboxGroup) {
          parent = parent.$parent;
        } else {
          this._checkboxGroup = parent;
          return true;
        }
      }
      return false;
    },
    store() {
      return this._checkboxGroup ? this._checkboxGroup.value : this.value;
    },
    disabledStatus() {
      return this.disabled;
    },
    hasContent() {
      if (this.isChecked) {
        return !!this.$slots.content;
      }
      return false;
    },
    rootCls() {
      return {
        [getPrefixedClassName("el-checkbox")]: true,
        [getPrefixedClassName("el-checkbox--flex")]: this.flex,
        [getPrefixedClassName("el-checkbox--with-content")]: this.hasContent
      };
    }
  },
  created() {
    this.checked && this.addToStore();
  },
  methods: {
    shouldAddToForm() {
      return !this._checkboxGroup;
    },
    onClick(e) {
      if (this.readonly) {
        e.preventDefault();
      }
      if (!this.disabled) {
        this.$emit("click", e);
      }
    },
    addToStore() {
      if (Array.isArray(this.model) && this.model.indexOf(this.label) === -1) {
        this.model.push(this.label);
      } else {
        this.model = this.trueLabel || true;
      }
    },
    handleChange(ev) {
      this.$emit("change", ev);
      if (this.isGroup) {
        this.$nextTick((_) => {
          this.dispatch(componentName.checkboxGroup, "change", [this._checkboxGroup.value]);
        });
      }
    },
    reset() {
      if (typeof this.initValue !== "undefined") {
        this.model = this.initValue;
      }
    },
    getData() {
      return this.model;
    },
    getValue() {
      return this.getData();
    },
    setData(val) {
      this.model = val;
    },
    processRule(rule) {
      rule.getFieldValue = () => {
        return String(this.getValue());
      };
      return rule;
    },
    getPrefixedClassName
  }
};
const __vue_script__$2 = script$2;
var __vue_render__$2 = function() {
  var _obj;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c("span", { class: _vm.rootCls }, [
    _c("label", [
      _c(
        "span",
        {
          class: (_obj = {}, _obj[_vm.getPrefixedClassName("el-checkbox__input")] = true, _obj[_vm.getPrefixedClassName("is-disabled")] = _vm.disabled, _obj[_vm.getPrefixedClassName("is-checked")] = _vm.isChecked, _obj[_vm.getPrefixedClassName("is-indeterminate")] = _vm.indeterminate, _obj[_vm.getPrefixedClassName("is-focus")] = _vm.focus, _obj)
        },
        [
          _vm.trueLabel || _vm.falseLabel ? _c("input", {
            directives: [
              {
                name: "model",
                rawName: "v-model",
                value: _vm.model,
                expression: "model"
              }
            ],
            class: [
              _vm.getPrefixedClassName("el-checkbox__original"),
              "hidden"
            ],
            attrs: {
              id: _vm.fieldSelectorID,
              type: "checkbox",
              "style-key": "checkbox",
              name: _vm.name,
              disabled: _vm.disabled,
              "true-value": _vm.trueLabel,
              "false-value": _vm.falseLabel
            },
            domProps: {
              checked: Array.isArray(_vm.model) ? _vm._i(_vm.model, null) > -1 : _vm._q(_vm.model, _vm.trueLabel)
            },
            on: {
              click: _vm.onClick,
              change: [
                function($event) {
                  var $$a = _vm.model, $$el = $event.target, $$c = $$el.checked ? _vm.trueLabel : _vm.falseLabel;
                  if (Array.isArray($$a)) {
                    var $$v = null, $$i = _vm._i($$a, $$v);
                    if ($$el.checked) {
                      $$i < 0 && (_vm.model = $$a.concat([$$v]));
                    } else {
                      $$i > -1 && (_vm.model = $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
                    }
                  } else {
                    _vm.model = $$c;
                  }
                },
                _vm.handleChange
              ],
              focus: function($event) {
                _vm.focus = true;
              },
              blur: function($event) {
                _vm.focus = false;
              }
            }
          }) : _c("input", {
            directives: [
              {
                name: "model",
                rawName: "v-model",
                value: _vm.model,
                expression: "model"
              }
            ],
            class: [
              _vm.getPrefixedClassName("el-checkbox__original"),
              "hidden"
            ],
            attrs: {
              id: _vm.fieldSelectorID,
              type: "checkbox",
              "style-key": "checkbox",
              disabled: _vm.disabled,
              name: _vm.name
            },
            domProps: {
              value: _vm.label,
              checked: Array.isArray(_vm.model) ? _vm._i(_vm.model, _vm.label) > -1 : _vm.model
            },
            on: {
              click: _vm.onClick,
              change: [
                function($event) {
                  var $$a = _vm.model, $$el = $event.target, $$c = $$el.checked ? true : false;
                  if (Array.isArray($$a)) {
                    var $$v = _vm.label, $$i = _vm._i($$a, $$v);
                    if ($$el.checked) {
                      $$i < 0 && (_vm.model = $$a.concat([$$v]));
                    } else {
                      $$i > -1 && (_vm.model = $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
                    }
                  } else {
                    _vm.model = $$c;
                  }
                },
                _vm.handleChange
              ],
              focus: function($event) {
                _vm.focus = true;
              },
              blur: function($event) {
                _vm.focus = false;
              }
            }
          }),
          _vm._v(" "),
          _c("span", {
            class: [
              _vm.getPrefixedClassName("el-checkbox__inner"),
              _vm.getPrefixedClassName(
                _vm.theme ? "checkbox-" + _vm.theme + "-wrap" : "checkbox-wrap"
              )
            ]
          })
        ]
      ),
      _vm._v(" "),
      _vm.$slots.default || _vm.label ? _c(
        "span",
        { class: _vm.getPrefixedClassName("el-checkbox__label") },
        [_vm._t("default", [_vm._v(_vm._s(_vm.label))])],
        2
      ) : _vm._e()
    ]),
    _vm._v(" "),
    _vm.tip ? _c("i", {
      class: [_vm.getPrefixedClassName("el-checkbox__tip"), "icon-tip"],
      attrs: { "data-hint": _vm.contentTip }
    }) : _vm._e(),
    _vm._v(" "),
    _vm.$slots.desc || _vm.desc ? _c(
      "div",
      { class: _vm.getPrefixedClassName("el-checkbox__desc") },
      [
        _vm._t("desc"),
        _vm._v(" "),
        !_vm.$slots.desc ? [_vm._v(_vm._s(_vm.desc))] : _vm._e()
      ],
      2
    ) : _vm._e(),
    _vm._v(" "),
    _vm.$slots.content ? _c(
      "div",
      {
        directives: [
          {
            name: "show",
            rawName: "v-show",
            value: _vm.isChecked,
            expression: "isChecked"
          }
        ],
        class: _vm.getPrefixedClassName("el-checkbox__content-wrap")
      },
      [
        _c("span", {
          class: _vm.getPrefixedClassName("el-checkbox__item-triangle")
        }),
        _vm._v(" "),
        _c(
          "div",
          { class: _vm.getPrefixedClassName("el-checkbox__content") },
          [_vm._t("content")],
          2
        )
      ]
    ) : _vm._e()
  ]);
};
var __vue_staticRenderFns__$2 = [];
__vue_render__$2._withStripped = true;
const __vue_inject_styles__$2 = void 0;
const __vue_scope_id__$2 = void 0;
const __vue_module_identifier__$2 = void 0;
const __vue_is_functional_template__$2 = false;
const __vue_component__$2 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$2, staticRenderFns: __vue_staticRenderFns__$2 },
  __vue_inject_styles__$2,
  __vue_script__$2,
  __vue_scope_id__$2,
  __vue_is_functional_template__$2,
  __vue_module_identifier__$2,
  false,
  void 0,
  void 0,
  void 0
);
var script$1 = {
  name: componentName.checkboxButton,
  componentName: componentName.checkboxButton,
  mixins: [EmitterMixin],
  props: {
    value: {},
    label: {},
    disabled: Boolean,
    checked: Boolean,
    name: String,
    trueLabel: [String, Number],
    falseLabel: [String, Number],
    needBtnIcon: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      selfModel: false,
      focus: false
    };
  },
  computed: {
    model: {
      get() {
        return this._checkboxGroup ? this.store : this.value !== void 0 ? this.value : this.selfModel;
      },
      set(val) {
        if (this._checkboxGroup) {
          let isLimitExceeded = false;
          this._checkboxGroup.min !== void 0 && val.length < this._checkboxGroup.min && (isLimitExceeded = true);
          this._checkboxGroup.max !== void 0 && val.length > this._checkboxGroup.max && (isLimitExceeded = true);
          isLimitExceeded === false && this.dispatch(componentName.checkboxGroup, "input", [val]);
        } else if (this.value !== void 0) {
          this.$emit("input", val);
        } else {
          this.selfModel = val;
        }
      }
    },
    isChecked() {
      if (typeof this.model === "boolean") {
        return this.model;
      } else if (Array.isArray(this.model)) {
        return this.model.indexOf(this.label) > -1;
      } else if (this.model !== null && this.model !== void 0) {
        return this.model === this.trueLabel;
      }
      return false;
    },
    _checkboxGroup() {
      let parent = this.$parent;
      while (parent) {
        if (parent.$options.componentName !== componentName.checkboxGroup) {
          parent = parent.$parent;
        } else {
          return parent;
        }
      }
      return false;
    },
    store() {
      return this._checkboxGroup ? this._checkboxGroup.value : this.value;
    },
    activeStyle() {
      return {
        backgroundColor: this._checkboxGroup.fill || "",
        borderColor: this._checkboxGroup.fill || "",
        color: this._checkboxGroup.textColor || "",
        "box-shadow": "-1px 0 0 0 " + this._checkboxGroup.fill
      };
    },
    size() {
      return this._checkboxGroup.size;
    }
  },
  created() {
    this.checked && this.addToStore();
  },
  methods: {
    addToStore() {
      if (Array.isArray(this.model) && this.model.indexOf(this.label) === -1) {
        this.model.push(this.label);
      } else {
        this.model = this.trueLabel || true;
      }
    },
    handleChange(ev) {
      this.$emit("change", ev);
      if (this._checkboxGroup) {
        this.$nextTick((_) => {
          this.dispatch(componentName.checkboxGroup, "change", [this._checkboxGroup.value]);
        });
      }
    },
    getPrefixedClassName
  },
  template: ""
};
const __vue_script__$1 = script$1;
var __vue_render__$1 = function() {
  var _obj, _obj$1, _obj$2;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "label",
    {
      class: [
        _vm.getPrefixedClassName("el-checkbox-button"),
        _vm.size ? _vm.getPrefixedClassName("el-checkbox-button--" + _vm.size) : "",
        (_obj = {}, _obj[_vm.getPrefixedClassName("is-disabled")] = _vm.disabled, _obj),
        (_obj$1 = {}, _obj$1[_vm.getPrefixedClassName("is-checked")] = _vm.isChecked, _obj$1),
        (_obj$2 = {}, _obj$2[_vm.getPrefixedClassName("is-focus")] = _vm.focus, _obj$2)
      ]
    },
    [
      _vm.trueLabel || _vm.falseLabel ? _c("input", {
        directives: [
          {
            name: "model",
            rawName: "v-model",
            value: _vm.model,
            expression: "model"
          }
        ],
        class: _vm.getPrefixedClassName("el-checkbox-button__original"),
        attrs: {
          type: "checkbox",
          name: _vm.name,
          disabled: _vm.disabled,
          "true-value": _vm.trueLabel,
          "false-value": _vm.falseLabel
        },
        domProps: {
          checked: Array.isArray(_vm.model) ? _vm._i(_vm.model, null) > -1 : _vm._q(_vm.model, _vm.trueLabel)
        },
        on: {
          change: [
            function($event) {
              var $$a = _vm.model, $$el = $event.target, $$c = $$el.checked ? _vm.trueLabel : _vm.falseLabel;
              if (Array.isArray($$a)) {
                var $$v = null, $$i = _vm._i($$a, $$v);
                if ($$el.checked) {
                  $$i < 0 && (_vm.model = $$a.concat([$$v]));
                } else {
                  $$i > -1 && (_vm.model = $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
                }
              } else {
                _vm.model = $$c;
              }
            },
            _vm.handleChange
          ],
          focus: function($event) {
            _vm.focus = true;
          },
          blur: function($event) {
            _vm.focus = false;
          }
        }
      }) : _c("input", {
        directives: [
          {
            name: "model",
            rawName: "v-model",
            value: _vm.model,
            expression: "model"
          }
        ],
        class: _vm.getPrefixedClassName("el-checkbox-button__original"),
        attrs: { type: "checkbox", name: _vm.name, disabled: _vm.disabled },
        domProps: {
          value: _vm.label,
          checked: Array.isArray(_vm.model) ? _vm._i(_vm.model, _vm.label) > -1 : _vm.model
        },
        on: {
          change: [
            function($event) {
              var $$a = _vm.model, $$el = $event.target, $$c = $$el.checked ? true : false;
              if (Array.isArray($$a)) {
                var $$v = _vm.label, $$i = _vm._i($$a, $$v);
                if ($$el.checked) {
                  $$i < 0 && (_vm.model = $$a.concat([$$v]));
                } else {
                  $$i > -1 && (_vm.model = $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
                }
              } else {
                _vm.model = $$c;
              }
            },
            _vm.handleChange
          ],
          focus: function($event) {
            _vm.focus = true;
          },
          blur: function($event) {
            _vm.focus = false;
          }
        }
      }),
      _vm._v(" "),
      _vm.$slots.default || _vm.label ? _c(
        "span",
        {
          class: _vm.getPrefixedClassName("el-checkbox-button__inner"),
          style: _vm.isChecked ? _vm.activeStyle : null
        },
        [
          _vm.needBtnIcon ? _c("i", {
            class: [
              "iconfont",
              _vm.getPrefixedClassName("el-checkbox-button_icon"),
              _vm.isChecked ? "vtv-icon-comp-ok-circle" : "vtv-icon-comp-ok-border"
            ]
          }) : _vm._e(),
          _vm._v(" "),
          _vm._t("default", [_vm._v(_vm._s(_vm.label))])
        ],
        2
      ) : _vm._e()
    ]
  );
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
var script = {
  name: componentName.checkboxGroup,
  componentName: componentName.checkboxGroup,
  mixins: [FormFieldMixin],
  props: {
    value: {},
    min: Number,
    max: Number,
    size: String,
    fill: String,
    textColor: String,
    multiline: Boolean
  },
  data: () => {
    return {
      errorText: $i("scp.vt_component.sf_widget.packages.radio.radio_group.select_least_one")
    };
  },
  computed: {
    groupCls() {
      return [
        this.getPrefixedClassName("el-checkbox-group"),
        this.multiline ? this.getPrefixedClassName("el-checkbox-group--multiline") : "",
        this.invalidCls
      ];
    }
  },
  watch: {
    value() {
      this.validate();
    }
  },
  methods: {
    getData() {
      return this.value;
    },
    getValue() {
      return this.getData();
    },
    processRule(rule) {
      rule.getFieldValue = () => {
        return String(this.getValue());
      };
      return rule;
    },
    setData(vals) {
      this.$emit("input", vals);
    },
    getPrefixedClassName
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    { class: _vm.groupCls, attrs: { id: _vm.fieldSelectorID } },
    [
      _vm._t("default"),
      _vm._v(" "),
      _c(
        "p",
        { class: _vm.getPrefixedClassName("el-checkbox-group--required-tip") },
        [_vm._v("\n    " + _vm._s(_vm.errorText) + "\n  ")]
      )
    ],
    2
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__$2 as SfCheckbox, __vue_component__$1 as SfCheckboxButton, __vue_component__ as SfCheckboxGroup };
