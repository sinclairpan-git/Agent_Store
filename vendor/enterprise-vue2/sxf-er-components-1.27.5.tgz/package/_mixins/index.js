import { componentName } from '@sxf/er-components/_const';
import logger from '@sxf/er-utils/logger';
import uuid from '@sxf/er-utils/uuid';
import { cascadeComponent } from '@sxf/er-utils/walk';
import format from '@sxf/er-utils/format';
import langUtil from '@sxf/er-utils/lang';
function broadcast(componentName2, eventName2, params) {
  this.$children.forEach((child) => {
    const name = child.$options.componentName;
    if (name === componentName2) {
      child.$emit.call(child, eventName2, ...params);
    } else {
      broadcast.apply(child, [componentName2, eventName2].concat([params]));
    }
  });
}
const EmitterMixin = {
  methods: {
    dispatch(componentName2, eventName2, params) {
      let parent = this.$parent || this.$root;
      let name = parent && parent.$options.componentName;
      const args = [eventName2].concat(params);
      const names = {};
      let emitCount = 1;
      let checkFn;
      if (typeof componentName2 === "function") {
        checkFn = componentName2;
      }
      if (!checkFn) {
        if (typeof componentName2 === "string") {
          componentName2 = [componentName2];
        }
        componentName2.forEach(function(item) {
          names[item] = 1;
        });
        emitCount = componentName2.length;
      }
      while (parent && (checkFn || emitCount)) {
        if (checkFn) {
          const ret = checkFn.apply(parent, [parent].concat(args));
          if (ret === true || ret && ret.valid === true) {
            parent.$emit(...args);
          }
          parent = parent.$parent;
          if (ret === false || ret && ret.continue === false) {
            break;
          }
          continue;
        }
        name = parent.$options.componentName;
        if (!names[name]) {
          parent = parent.$parent;
          continue;
        }
        emitCount--;
        names[name] = 0;
        parent.$emit(...args);
        parent = parent.$parent;
      }
    },
    broadcast(componentName2, eventName2, params) {
      broadcast.call(this, componentName2, eventName2, params);
    }
  }
};
const targetComponents = ["SfLayoutHeight"];
const eventName = "sf-component-added";
const AddComponentMixin = {
  mixins: [EmitterMixin],
  props: {
    dispatchAddedEvent: {
      type: Boolean,
      default: true
    }
  },
  mounted() {
    if (!this.dispatchAddedEvent) {
      return;
    }
    this.dispatch(
      (comp) => {
        const name = comp.$options.componentName;
        if ([componentName.form, componentName.formItem].includes(name)) {
          return {
            continue: true,
            valid: true
          };
        }
        if (targetComponents.includes(name)) {
          return {
            continue: false,
            valid: true
          };
        }
      },
      eventName,
      this
    );
  }
};
const AddComponentMixinEventName = eventName;
const mixinComponentLogger = logger("mixin-component");
const ComponentMixin = {
  mounted() {
    this.$isMounted = true;
  },
  data() {
    return {
      id: uuid(),
      width: this.defaultWidth,
      height: this.defaultHeight,
      disabled: this.defaultDisabled,
      hidden: this.defaultHidden
    };
  },
  props: {
    cls: {},
    defaultHidden: {
      type: Boolean,
      default: false
    },
    defaultDisabled: Boolean,
    defaultWidth: [Number, String],
    defaultHeight: Number
  },
  computed: {},
  methods: {
    getId() {
      return this.id;
    },
    disable(silent = false) {
      if (this.disabled) {
        return;
      }
      this.disabled = true;
      if (!silent) {
        this.$emit("disable", this);
      }
    },
    enable(silent = false) {
      if (!this.disabled) {
        return;
      }
      this.disabled = false;
      if (!silent) {
        this.$emit("enable", this);
      }
    },
    show(silent) {
      this.hidden = false;
      mixinComponentLogger.log("show component...");
      if (!silent) {
        this.$emit("show", this);
      }
    },
    hide(silent) {
      this.hidden = true;
      mixinComponentLogger.log("hide component...");
      if (!silent) {
        this.$emit("hide", this);
      }
    },
    isVisibility() {
      let visibility = true;
      let p = this;
      while (p) {
        if (p.hidden) {
          visibility = false;
          break;
        }
        p = p.$parent;
      }
      return visibility;
    }
  },
  watch: {
    hidden() {
      const me = this;
      this.$nextTick(function() {
        cascadeComponent(me, (child) => {
          return child.$emit("parentvisibilitychange", me);
        });
      });
    },
    defaultHidden(value) {
      this.hidden = value;
    },
    defaultDisabled(value) {
      this.disabled = value;
    },
    defaultWidth(value) {
      this.width = value;
    },
    defaultHeight(value) {
      this.height = value;
    }
  }
};
const FormTipMixin = {
  props: {
    tip: [String, Array]
  },
  computed: {
    contentTip() {
      return format.getContentTip(this.tip);
    }
  }
};
const MenuTargetMixin = {
  props: {
    menuRef: {
      type: String,
      default: ""
    }
  },
  data() {
    return {
      menuShow: false
    };
  },
  mounted() {
    if (this.menuRef) {
      this.__setMenu();
    }
  },
  methods: {
    __setMenu() {
      const refName = this.menuRef;
      if (!refName || !this.$vnode) {
        return;
      }
      const refs = this.$vnode.context.$refs[refName];
      const menu = Array.isArray(refs) ? refs[0] : refs;
      const Vue = this.constructor.super;
      if (!(menu instanceof Vue)) {
        return;
      }
      menu.$on("before-show", () => {
        this.menuShow = true;
      });
      menu.$on("before-hide", () => {
        this.menuShow = false;
      });
      this._menuComponent = menu;
    }
  }
};
const ADD_EVENT_NAME = "sf.mgr.add";
const ID_ATTR = "sfId";
const MgrClientMixin = {
  mixins: [EmitterMixin],
  props: {
    sfId: true,
    sfMgrEvent: {
      default: "click"
    },
    sfMgrStateEnabled: {
      default: true
    }
  },
  created() {
    if (!this[ID_ATTR]) {
      return;
    }
    this.dispatch(
      function(component) {
        const match = !!component.sfMgr;
        return {
          valid: match,
          continue: !match
        };
      },
      ADD_EVENT_NAME,
      [this]
    );
  },
  methods: {
    onToggleState() {
    }
  }
};
const MgrServerMixin = {
  props: {
    eventHandler: Function
  },
  computed: {
    sfMgr() {
      return "server";
    }
  },
  data() {
    return {
      disabledState: {}
    };
  },
  created() {
    this.$on(ADD_EVENT_NAME, (component, params) => {
      const id = component[ID_ATTR];
      params = Object.assign(
        {
          initStateValue: 0
        },
        params
      );
      if (!id) {
        return;
      }
      if (component.sfMgrStateEnabled !== false) {
        this.$set(this.disabledState, id, params.initStateValue);
        this.$watch(`disabledState.${id}`, (value) => {
          if (component.onToggleState) {
            component.onToggleState(!value);
          }
        });
      }
      const mgr = this;
      let events = component.sfMgrEvent;
      if (this.eventHandler && events) {
        if (typeof events === "string") {
          events = [events];
        }
        events.forEach((event) => {
          component.$on(event, function() {
            const args = [this[ID_ATTR], event].concat([].slice.call(arguments));
            mgr.handleSfMgrEvent(...args);
          });
        });
      }
    });
  },
  methods: {
    updateDisabledState(id, disabled) {
      if (arguments.length === 2) {
        this.disabledState[id] = disabled;
        return;
      }
      if (typeof id === "object") {
        Object.assign(this.disabledState, id);
      }
      if (id === true || id === false) {
        Object.keys(this.disabledState).forEach((key) => {
          this.disabledState[key] = id;
        });
      }
    },
    getDisabledState(id) {
      return this.disabledState[id];
    },
    handleSfMgrEvent(...args) {
      this.eventHandler(...args);
    }
  }
};
const PathnameMixin = {
  props: {
    pathName: String
  },
  methods: {
    getPathName() {
      if (this.pathName && this.APP_ROOT && this.APP_ROOT.$route && this.APP_ROOT.$route.query[this.pathName]) {
        return this.APP_ROOT.$route.query[this.pathName];
      }
    },
    setPathName(value) {
      if (this.pathName && this.APP_ROOT && this.APP_ROOT.$route && this.APP_ROOT.$route.query[this.pathName] !== value) {
        const query = Object.assign({}, this.APP_ROOT.$route.query);
        query[this.pathName] = value;
        this.APP_ROOT.$router.replace({
          query
        });
      }
    },
    watchPathNameRouter(callback) {
      if (this.pathName && this.APP_ROOT && this.APP_ROOT.$router) {
        this.__routerAfterEachDestroy = this.APP_ROOT.$router.afterEach((to) => {
          const queryName = to.query[this.pathName];
          if (callback) {
            callback({
              to,
              value: queryName
            });
          }
        });
      }
    }
  },
  beforeDestroy() {
    if (this.__routerAfterEachDestroy) {
      this.__routerAfterEachDestroy();
    }
  }
};
const { isNumber } = langUtil;
const multipleSelectMixinLogger = logger("multipleSelectMixin");
const MultipleSelectMixin = {
  props: {
    multipleDisplayType: {
      validator(val) {
        return ["tag", "text"].includes(val);
      },
      default: "text"
    },
    maxTag: {
      validator(val) {
        return typeof val === "number" || val === "responsive";
      },
      default: "responsive"
    },
    maxTagWidth: {
      type: [Number, String]
    }
  },
  computed: {
    tagSize() {
      return this.currentSize || "normal";
    },
    tagType() {
      return "multiple-select";
    },
    isTagMode() {
      return this.multiple && this.multipleDisplayType === "tag";
    },
    shouldTagBeResponsive() {
      return this.isTagMode && this.maxTag === "responsive";
    },
    tagController() {
      return {
        enable: this.isTagMode,
        callback: this.initTag
      };
    },
    maxTagLabelWidth() {
      const maxTagWidth = Number(this.maxTagWidth);
      return isNaN(maxTagWidth) ? 0 : Math.max(0, maxTagWidth - 26);
    }
  },
  data() {
    return {
      safeTagNumber: typeof this.maxTag === "number" ? this.maxTag : 0,
      tagLabelStyle: {}
    };
  },
  methods: {
    initTag() {
      if (this.tagInitialized) {
        return;
      }
      this.tagInitialized = true;
      const tagContainerRefName = this.tagContainerRefName;
      this.$nextTick(() => {
        if (this.$refs[tagContainerRefName]) {
          const containerWidth = this.$refs[tagContainerRefName].clientWidth;
          const reservedWidth = 80;
          const safeMaxWidth = containerWidth - reservedWidth;
          const maxWidth = this.maxTagLabelWidth ? Math.min(safeMaxWidth, this.maxTagLabelWidth) : safeMaxWidth;
          this.tagLabelStyle = { maxWidth: `${maxWidth}px` };
          if (this.shouldTagBeResponsive) {
            this.$nextTick(() => {
              this.tagLabelMaxWidthSettled = true;
              this.calcMaxSafeTagNumber();
            });
          }
        } else {
          multipleSelectMixinLogger.error(`bad tagContainerRefName, mixin won't work`);
        }
      });
    },
    isTagOverflow() {
      var _a, _b;
      const tagContainerRefName = this.tagContainerRefName;
      const containerClientWidth = this.$refs[tagContainerRefName].clientWidth;
      const needWidth = ((_a = this.$refs[tagContainerRefName].children[0]) == null ? void 0 : _a.clientWidth) || 0;
      const containerElement = this.$refs[tagContainerRefName];
      const computedStyle = window.getComputedStyle(containerElement);
      const paddingLeft = parseFloat(computedStyle.paddingLeft) || 0;
      const paddingRight = parseFloat(computedStyle.paddingRight) || 0;
      const containerPaddingWidth = paddingLeft + paddingRight;
      const isWidthOver = needWidth > containerClientWidth - containerPaddingWidth;
      const containerHeight = this.$refs[tagContainerRefName].clientHeight;
      const realHeight = ((_b = this.$refs[tagContainerRefName].children[0]) == null ? void 0 : _b.clientHeight) || 0;
      const isHeightOver = realHeight > containerHeight;
      return isWidthOver || isHeightOver;
    },
    calcMaxSafeTagNumber() {
      if (!this.shouldTagBeResponsive || !this.tagLabelMaxWidthSettled) {
        return;
      }
      if (!isNumber(this.tagNumberCeil)) {
        multipleSelectMixinLogger.error(`bad tagNumberCeil, mixin won't work`);
        return;
      }
      const isDanger = this.isTagOverflow();
      if (isDanger) {
        this.safeTagNumber = Math.max(this.safeTagNumber - 1, 0);
      } else {
        const newTagNumber = this.safeTagNumber + 1;
        if (newTagNumber <= this.tagNumberCeil) {
          this.safeTagNumber = newTagNumber;
          this.$nextTick(() => {
            this.calcMaxSafeTagNumber();
          });
        }
      }
    }
  }
};
export { AddComponentMixin, AddComponentMixinEventName, ComponentMixin, EmitterMixin, FormTipMixin, MenuTargetMixin, MgrClientMixin, MgrServerMixin, MultipleSelectMixin, PathnameMixin };
