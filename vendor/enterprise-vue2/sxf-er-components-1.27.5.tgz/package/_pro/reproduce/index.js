import $ from 'jquery';
import { componentName } from '@sxf/er-components/_const';
import { isPropEnabled } from '@sxf/er-components/_utils/vue-utils';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
const HOLDER = Math.random();
var script = {
  name: componentName.reproduce,
  componentName: componentName.reproduce,
  props: {
    reserve: {
      type: [Number, String],
      default: 0
    },
    initial: {
      type: Number,
      default: 0
    },
    noIcon: {},
    data: {
      type: Array
    },
    outside: {},
    idField: {},
    beforeRemove: {
      type: Function
    }
  },
  data() {
    const data = {};
    data.ID = 0;
    data.list = createReproduceList(this.data, Math.max(this.initial, this.reserve, 0), data, this.idField);
    return data;
  },
  computed: {
    currentReserve() {
      return Math.max(Number(this.reserve) || 0, 0);
    },
    isNoIcon() {
      return isPropEnabled(this.noIcon);
    },
    isOutside() {
      return isPropEnabled(this.outside);
    },
    total() {
      return this.list.length;
    }
  },
  watch: {
    data(arr, oldArr) {
      if (arr !== oldArr) {
        this.list = createReproduceList(this.data, 0, this, this.idField);
      } else {
        const list = [];
        const valueList = this.list.map((item) => item.value);
        arr.forEach((value, index) => {
          const valueIndex = valueList.indexOf(value);
          if (valueIndex < 0) {
            list[index] = createReproduceList([value], 0, this, this.idField)[0];
          } else {
            list[index] = this.list[valueIndex];
          }
        });
        this.list = list;
      }
    }
  },
  methods: {
    add(num = 1, startIndex = this.total) {
      const newList = createReproduceList(num, num, this, this.idField);
      if (!newList.length) {
        return;
      }
      startIndex = startIndex < 0 ? startIndex + this.total : startIndex;
      this.list.splice.apply(this.list, [startIndex, 0].concat(newList));
      if (this.data) {
        this.data.splice.apply(this.data, [startIndex, 0].concat(newList.map((item) => item.value)));
      }
      this.$emit(
        "add",
        newList.map((item, index) => {
          return {
            id: item.id,
            value: item.value,
            index: startIndex + index
          };
        })
      );
      this.$emit("change");
    },
    remove(num = 1, startIndex) {
      const closableNum = this.total - this.currentReserve;
      num = Number(num) || 0;
      if (typeof startIndex === "undefined") {
        startIndex = this.total - num;
      }
      if (num >= closableNum) {
        num = closableNum;
        startIndex = this.total - num;
      }
      if (num <= 0) {
        return;
      }
      const eventData = this.list.slice(startIndex, startIndex + num).map((item, index) => {
        return {
          id: item.id,
          value: item.value,
          index: startIndex + index
        };
      });
      $.when(this.beforeRemove && this.beforeRemove(eventData)).then((result) => {
        if (result === false) {
          return;
        }
        this.list.splice(startIndex, num);
        if (this.data) {
          this.data.splice(startIndex, num);
        }
        this.$emit("remove", eventData);
        this.$emit("change");
      });
    },
    clear() {
      this.remove(this.total, 0);
    },
    removeByID(ids) {
      ids = $.makeArray(ids);
      if (ids.length <= 0 || ids.length > this.total - this.currentReserve) {
        return;
      }
      const arr = [];
      this.list = this.list.filter((item, index) => {
        const notMatch = ids.indexOf(item.id) < 0;
        if (!notMatch) {
          arr.push({
            id: item.id,
            value: item.value,
            index
          });
        }
        return notMatch;
      });
      if (this.data) {
        for (let i = arr.length - 1; i >= 0; i--) {
          this.data.splice(arr[i].index, 1);
        }
      }
      if (arr.length) {
        this.$emit("remove", arr);
        this.$emit("change");
      }
    },
    up(index, step = -1) {
      this.move(1, index, step);
    },
    down(index, step = 1) {
      this.move(1, index, step);
    },
    move(num = 1, startIndex, step = 1) {
      let targetIndex = step > 0 ? startIndex + num + step : startIndex + step;
      targetIndex = Math.max(Math.min(targetIndex, this.data.length), 0);
      for (const list of [this.data, this.list]) {
        const arr = list.splice(startIndex, num, ...createArray(num).map(() => HOLDER));
        if (!arr.length) {
          return;
        }
        list.splice(targetIndex, 0, ...arr);
        removeFromArr(list, HOLDER);
      }
      this.$emit("move", {
        num,
        startIndex,
        step
      });
      this.$emit("change");
    },
    getID(index) {
      const item = this.list[index];
      return item && item.id;
    },
    getIndex(id) {
      let result;
      this.list.forEach((item, index) => {
        if (item.id === id) {
          result = index;
        }
      });
      return result;
    }
  },
  render(createElem) {
    return createElem(
      "div",
      { class: "sf-reproduce" },
      this.list.map((item, index) => {
        const remove = () => {
          this.remove(1, index);
        };
        const isReserve = this.total <= this.currentReserve;
        const slotData = {
          id: item.id,
          index,
          total: this.total,
          remove,
          isReserve
        };
        Object.defineProperty(slotData, "value", {
          configurable: true,
          enumerable: true,
          get: () => {
            return this.data[index];
          },
          set: (value) => {
            this.$set(this.data, index, value);
          }
        });
        const slotElem = parseSlot(this, "default", slotData);
        if (this.isNoIcon) {
          return createElem(
            "div",
            {
              key: item.id
            },
            [slotElem]
          );
        }
        const closeElement = createElem("i", {
          class: "iconfont vtv-icon-tab-close sf-reproduce_close-icon",
          key: item.id,
          on: {
            click: remove
          }
        });
        return createElem(
          "div",
          {
            class: {
              "sf-reproduce_item": true,
              "is-outside": this.isOutside
            }
          },
          [slotElem, isReserve ? null : closeElement]
        );
      })
    );
  }
};
function parseSlot(vm, slotName, data) {
  return vm.$slots[slotName] || vm.$scopedSlots[slotName](data);
}
function createArray(num) {
  return Array.apply(null, Array(Number(num) || 0));
}
function createReproduceList(list, initial, data, idField) {
  const newList = $.isArray(list) ? list : createArray(initial);
  return newList.map((item) => {
    return {
      value: item,
      id: idField && item.hasOwnProperty(idField) ? item[idField] : data.ID++
    };
  });
}
function removeFromArr(arr, value) {
  let index = arr.indexOf(value);
  while (index >= 0) {
    arr.splice(index, 1);
    index = arr.indexOf(value);
  }
  return arr;
}
const __vue_script__ = script;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = "data-v-4aa3890e";
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = void 0;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  {},
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__ as SfReproduce };
