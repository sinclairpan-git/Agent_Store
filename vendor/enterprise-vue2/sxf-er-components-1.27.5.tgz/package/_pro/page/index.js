import { componentName } from '@sxf/er-components/_const';
import { isPropEnabled } from '@sxf/er-components/_utils/vue-utils';
import { SfCard } from '@sxf/er-components/card';
import { SfPath } from '@sxf/er-components/path';
import { getPrefixedClassName } from '@sxf/er-feature';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
var script = {
  name: componentName.page,
  componentName: componentName.page,
  components: {
    SfCard,
    SfPath
  },
  props: {
    pathData: {},
    tip: {
      type: String,
      default: ""
    },
    card: {
      type: Boolean,
      default: false
    },
    noPaddingY: {}
  },
  computed: {
    pathCls() {
      return {
        [this.getPrefixedClassName("vmp-page-tabs-container")]: this.$slots.path,
        [this.getPrefixedClassName("vmp-page-tabs-container--with-path")]: this.pathData && this.$slots.path
      };
    },
    pageCls() {
      return {
        [this.getPrefixedClassName("no-padding-y")]: isPropEnabled(this.noPaddingY),
        [this.getPrefixedClassName("sf-page--with-path")]: this.pathData
      };
    }
  },
  methods: {
    getPrefixedClassName
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    { class: [_vm.getPrefixedClassName("sf-page"), _vm.pageCls] },
    [
      _c(
        "sf-path",
        {
          ref: "path",
          class: _vm.pathCls,
          attrs: { "path-data": _vm.pathData, tip: _vm.tip }
        },
        [
          _vm._t("path"),
          _vm._v(" "),
          _vm.$slots.right ? _c("template", { slot: "right" }, [_vm._t("right")], 2) : _vm._e()
        ],
        2
      ),
      _vm._v(" "),
      _vm.card ? [
        _c(
          "sf-card",
          { class: _vm.getPrefixedClassName("sf-page__content") },
          [_vm._t("default")],
          2
        )
      ] : [
        _c(
          "div",
          { class: _vm.getPrefixedClassName("sf-page__content") },
          [_vm._t("default")],
          2
        )
      ]
    ],
    2
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__ as SfPage };
