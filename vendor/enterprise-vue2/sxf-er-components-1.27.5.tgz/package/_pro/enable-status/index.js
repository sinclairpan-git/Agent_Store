import { componentName } from '@sxf/er-components/_const';
import { $i } from '@sxf/er-config';
import { getPrefixedClassName } from '@sxf/er-feature';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
const STATUS_ICON = {
  enable: "vtv-icon-enable",
  disable: "vtv-icon-disable"
};
var script = {
  name: componentName.enableStatus,
  componentName: componentName.enableStatus,
  props: {
    status: {
      type: String,
      default: "enable"
    },
    hint: "",
    disabled: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    isDisabled() {
      return this.disabled;
    },
    tip() {
      if (typeof this.hint !== "undefined") {
        return this.hint;
      }
      if (this.isDisabled) {
        return this.status === "enable" ? $i("scp.vt_component.sf_widget.packages.enable_status.enabled_tip") : $i("scp.vt_component.sf_widget.packages.enable_status.disabled_tip");
      }
      return this.status === "enable" ? $i("scp.vt_component.sf_widget.packages.enable_status.click_on_the_disable_tip") : $i("scp.vt_component.sf_widget.packages.enable_status.click_on_the_enable_tip");
    },
    statusCls() {
      return STATUS_ICON[this.status] || "";
    }
  },
  methods: {
    handleClick: function(evt) {
      if (!this.isDisabled) {
        this.$emit("click", evt, this.status);
      }
    },
    getPrefixedClassName
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c("i", {
    class: [
      _vm.getPrefixedClassName("sf-icon-enable-status"),
      "iconfont",
      _vm.statusCls
    ],
    attrs: {
      action: _vm.status,
      "data-hint": _vm.tip,
      disabled: _vm.isDisabled
    },
    on: { click: _vm.handleClick }
  });
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__ as SfEnableStatus };
