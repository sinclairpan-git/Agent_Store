import { componentName } from '@sxf/er-components/_const';
import { getPrefixedClassName } from '@sxf/er-feature';
import format from '@sxf/er-utils/format';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
const ICON_COLOR_TYPE = ["success", "warning", "danger", "info"];
var script = {
  name: componentName.iconText,
  componentName: componentName.iconText,
  props: {
    icon: {
      type: String,
      default: ""
    },
    text: {
      type: String,
      default: ""
    },
    type: {
      type: String,
      default: "",
      validator(type) {
        if (!type) {
          return true;
        }
        return ICON_COLOR_TYPE.includes(type);
      }
    },
    color: {
      type: String,
      default: ""
    },
    animation: {
      type: Boolean,
      default: false
    },
    tip: {
      type: [Array, String],
      default: ""
    }
  },
  computed: {
    curIconStyle() {
      const style = {};
      this.color && (style.color = this.color);
      return style;
    },
    curIconCls() {
      return [
        getPrefixedClassName("sf-icon-text__icon"),
        this.type && getPrefixedClassName(`sf-icon-text__icon--${this.type}`),
        "iconfont",
        this.icon && "vtv-icon-" + this.icon,
        this.animation && getPrefixedClassName("sf-icon-text--animation")
      ];
    }
  },
  methods: {
    getTip() {
      return format.getContentTip(this.tip);
    },
    getPrefixedClassName
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "span",
    { class: _vm.getPrefixedClassName("sf-icon-text") },
    [
      _vm.icon ? _c("i", {
        class: _vm.curIconCls,
        style: _vm.curIconStyle,
        attrs: { "data-hint": _vm.getTip() }
      }) : _vm._e(),
      _vm._v(" "),
      _vm.text ? _c(
        "span",
        {
          class: _vm.getPrefixedClassName("sf-icon-text__text") + " ellipsis"
        },
        [_vm._v(_vm._s(_vm.text))]
      ) : _vm._e(),
      _vm._v(" "),
      _vm._t("default")
    ],
    2
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__ as SfIconText };
