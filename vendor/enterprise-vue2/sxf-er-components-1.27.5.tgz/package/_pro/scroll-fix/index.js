import $ from 'jquery';
import { componentName } from '@sxf/er-components/_const';
import { throttle } from '@sxf/er-utils/delay';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
let hasFixedCnt = 0;
const SCROLL_WIDTH = 17;
var script = {
  name: componentName.scrollFix,
  componentName: componentName.scrollFix,
  props: {
    top: {
      type: [String, Number],
      default: "top"
    },
    dir: {
      type: String,
      default: "top"
    },
    noPlaceHolder: {
      type: Boolean,
      default: false
    },
    holderHeight: {
      type: Number,
      default: 0
    },
    offsetTop: {
      type: Number,
      default: 0
    }
  },
  data() {
    return {
      isFixed: false,
      holderElHeight: 0
    };
  },
  computed: {
    height() {
      if (this.top === "top") {
        return 0;
      }
      if (this.top === "bottom") {
        return document.documentElement.clientHeight - this.scrollHeight;
      }
      if (Number(this.top) < 0) {
        return document.documentElement.clientHeight - this.scrollHeight + Number(this.top);
      }
      return Number(this.top);
    },
    direct() {
      return this.dir === "top" ? 1 : -1;
    }
  },
  mounted() {
    this.$scrollFix = $(this.$refs.scrollFix);
    this.originHeight = false;
    this.scrollHeight = (this.$scrollFix.offset().top || this.offsetTop) - this.height;
    this.resizeFn = throttle(() => {
      const scrollLeft = this.getScrollLeft();
      if (this.isFixed) {
        this.$scrollFix.css({
          left: scrollLeft <= SCROLL_WIDTH ? "auto" : this.originLeft - scrollLeft
        });
        if (scrollLeft <= SCROLL_WIDTH) {
          this.originLeft = this.$scrollFix.offset().left;
        }
      }
    });
    $(window).on("scroll", this.scrollFn);
    $(window).on("resize", this.resizeFn);
    this.holderElHeight = this.$el.clientHeight || this.holderHeight;
  },
  beforeDestroy() {
    $(window).off("scroll", this.scrollFn);
    $(window).off("resize", this.resizeFn);
    this.$scrollFix = null;
  },
  methods: {
    getScrollTop() {
      return document.documentElement.scrollTop || document.body.scrollTop;
    },
    getScrollLeft() {
      return document.documentElement.scrollLeft || document.body.scrollLeft;
    },
    getScrollHeight() {
      if (!this.isFixed && !hasFixedCnt) {
        this.scrollHeight = (this.$scrollFix.offset().top || this.offsetTop) - this.height;
      }
      return this.scrollHeight;
    },
    scrollFn() {
      const scrollTop = this.getScrollTop(), scrollHeight = this.getScrollHeight(), height = scrollTop - scrollHeight;
      if (typeof this.originLeft === "undefined" || !this.isFixed) {
        this.originLeft = this.$scrollFix.offset().left;
      }
      if (!this.$scrollFix.is(":visible")) {
        return;
      }
      if (this.originHeight === false) {
        if (height >= 0 && this.direct > 0 || height <= 0 && this.direct < 0) {
          this.originHeight = scrollHeight;
          this.$scrollFix.css({
            position: "fixed",
            top: this.height,
            left: this.originLeft
          });
          this.isFixed = true;
          hasFixedCnt++;
        }
      } else {
        if (this.direct > 0 && scrollTop < this.originHeight || this.direct < 0 && scrollTop > this.originHeight) {
          this.$scrollFix.css({ position: "static" });
          this.originHeight = false;
          this.isFixed = false;
          hasFixedCnt--;
        }
      }
      if (this.isFixed) {
        this.$scrollFix.css({
          left: this.originLeft - this.getScrollLeft()
        });
      }
      this.$emit("scroll", this.isFixed, scrollTop, scrollHeight);
    }
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c("div", { staticClass: "sf-scroll-fix-box" }, [
    _c(
      "div",
      { ref: "scrollFix", staticStyle: { "z-index": "11" } },
      [_vm._t("default")],
      2
    ),
    _vm._v(" "),
    !_vm.noPlaceHolder && _vm.isFixed ? _c("div", {
      staticClass: "scroll-place-holder",
      style: { height: _vm.holderElHeight + "px" }
    }) : _vm._e()
  ]);
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__ as SfScrollFix };
