import { VNode } from 'vue';

export declare type SfInputType = 'text' | 'textarea';

export interface SfInputProps<T = string | number> {
  value: T;
  type: SfInputType;
  placeholder: string;
  size: string;
  resize: string;
  readonly: boolean;
  autofocus: boolean;
  icon: string;
  disabled: boolean;
  name: string;
  rows: number;
  autosize: boolean | { minRows?: string; maxRows?: string };
  autoComplete: string;
  limit: number;
  useUTF8Len: boolean;
  onIconClick: () => void;
  trimPreZero: boolean;
  showPassword: boolean;
  canClear: boolean;
}

export interface SfInputSlots {
  $slots: {
    prepend?: VNode[];
    append?: VNode[];
    prefix?: VNode[];
    suffix?: VNode[];
    icon?: VNode[];
  };
}

export interface SfInputEvents<T = string | number> {
  $emit(eventName: 'focus', event: FocusEvent): this;
  $emit(eventName: 'blur', event: UIEvent): this;
  $emit(eventName: 'input', value: T): this;
  $emit(eventName: 'change', value: T): this;
  $emit(eventName: 'click', event: MouseEvent): this;
  $emit(eventName: 'clear', event: MouseEvent): this;
  $emit(eventName: 'invalid', eventData: boolean | string | Array<string>): this;
  $emit(eventName: 'valid', eventData: true): this;
  $emit(eventName: 'hide', inputValue: T): this;
  $emit(eventName: 'show'): this;
}

export interface SfInputMethods {
  focus: () => void;
  blur: () => void;
  clearValidateState: () => void;
}

export declare type SfInput<T = string | number> = Readonly<SfInputProps<T> & SfInputSlots & SfInputMethods> & Vue;
