import { isUndefined } from 'lodash-es';
import $ from 'jquery';
import { componentName } from '@sxf/er-components/_const';
import { vOnShow } from '@sxf/er-components/_directives';
import { EmitterMixin } from '@sxf/er-components/_mixins';
import { isPropEnabled } from '@sxf/er-components/_utils/vue-utils';
import { FormFieldMixin, FormSizeMixin } from '@sxf/er-components/form';
import { $i } from '@sxf/er-config';
import { getPrefixedClassName } from '@sxf/er-feature';
import { debounce } from '@sxf/er-utils/delay';
import { getStyleComputedProperty } from '@sxf/er-utils/dom';
import format from '@sxf/er-utils/format';
import lang from '@sxf/er-utils/lang';
import ua from '@sxf/er-utils/ua';
import { VALIDATE_TIME, maskTest, typeVerify } from '@sxf/er-validator';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
let hiddenTextarea;
const HIDDEN_STYLE = `
  height:0 !important;
  visibility:hidden !important;
  overflow:hidden !important;
  position:absolute !important;
  z-index:-1000 !important;
  top:0 !important;
  right:0 !important
`;
const CONTEXT_STYLE = [
  "letter-spacing",
  "line-height",
  "padding-top",
  "padding-bottom",
  "font-family",
  "font-weight",
  "font-size",
  "text-rendering",
  "text-transform",
  "width",
  "text-indent",
  "padding-left",
  "padding-right",
  "border-width",
  "box-sizing"
];
function calculateNodeStyling(node) {
  const style = window.getComputedStyle(node);
  const boxSizing = style.getPropertyValue("box-sizing");
  const paddingSize = parseFloat(style.getPropertyValue("padding-bottom")) + parseFloat(style.getPropertyValue("padding-top"));
  const borderSize = parseFloat(style.getPropertyValue("border-bottom-width")) + parseFloat(style.getPropertyValue("border-top-width"));
  const contextStyle = CONTEXT_STYLE.map((name) => `${name}:${style.getPropertyValue(name)}`).join(";");
  return { contextStyle, paddingSize, borderSize, boxSizing };
}
function calcTextareaHeight(targetNode, minRows = null, maxRows = null) {
  if (!hiddenTextarea) {
    hiddenTextarea = document.createElement("textarea");
    document.body.appendChild(hiddenTextarea);
  }
  const { paddingSize, borderSize, boxSizing, contextStyle } = calculateNodeStyling(targetNode);
  hiddenTextarea.setAttribute("style", `${contextStyle};${HIDDEN_STYLE}`);
  hiddenTextarea.value = targetNode.value || targetNode.placeholder || "";
  let height = hiddenTextarea.scrollHeight;
  if (boxSizing === "border-box") {
    height = height + borderSize;
  } else if (boxSizing === "content-box") {
    height = height - paddingSize;
  }
  hiddenTextarea.value = "";
  const singleRowHeight = hiddenTextarea.scrollHeight - paddingSize;
  if (minRows !== null) {
    let minHeight = singleRowHeight * minRows;
    if (boxSizing === "border-box") {
      minHeight = minHeight + paddingSize + borderSize;
    }
    height = Math.max(minHeight, height);
  }
  if (maxRows !== null) {
    let maxHeight = singleRowHeight * maxRows;
    if (boxSizing === "border-box") {
      maxHeight = maxHeight + paddingSize + borderSize;
    }
    height = Math.min(maxHeight, height);
  }
  return { height: height + "px" };
}
function normalizeWidth(width) {
  const defaultWidth = "100%";
  if (typeof width === "number") {
    return `${width}px`;
  }
  if (typeof width === "string") {
    if (/^\d+$/.test(width)) {
      return `${width}px`;
    }
    if (/^\d+px$/.test(width) || /^\d+%$/.test(width)) {
      return width;
    }
    return defaultWidth;
  }
  return defaultWidth;
}
var script$1 = {
  name: componentName.input,
  componentName: componentName.input,
  directives: {
    "on-show": vOnShow
  },
  mixins: [EmitterMixin, FormFieldMixin, FormSizeMixin],
  props: {
    value: [String, Number],
    placeholder: [String, Object],
    size: String,
    width: [Number, String],
    resize: String,
    readonly: {
      type: Boolean,
      default: false
    },
    autofocus: Boolean,
    icon: String,
    disabled: {
      type: Boolean,
      default: false
    },
    type: {
      type: String,
      default: "text"
    },
    name: String,
    autosize: {
      type: [Boolean, Object],
      default: false
    },
    isAutoFitSuffix: {
      type: Boolean,
      default: false
    },
    rows: {
      type: Number,
      default: 3
    },
    autoComplete: {
      type: String,
      default: "off"
    },
    limit: Number,
    limitNumber: Number,
    onIconClick: Function,
    trimPreZero: {
      type: Boolean,
      default: false
    },
    showPassword: Boolean,
    canClear: {
      type: Boolean,
      default: false
    },
    additionalEvent: {
      type: Object,
      default: () => ({})
    },
    trimSpace: {
      type: Boolean,
      default: false
    }
  },
  data() {
    const value = this.value || this.value === 0 ? this.value : "";
    const textLength = this.calcCharLength(String(this.value || ""));
    return {
      currentValue: value,
      textareaCalcStyle: {},
      initValue: value,
      prefixOffset: null,
      suffixOffset: null,
      passwordVisible: false,
      focusing: false,
      textLength,
      resizeObserver: null,
      isResize: false
    };
  },
  computed: {
    inputWrapStyle() {
      const base = {};
      if (this.isResize) {
        return Object.assign(base, { width: "auto" });
      }
      return isUndefined(this.width) ? base : Object.assign(base, { width: normalizeWidth(this.width) });
    },
    isEmpty() {
      return this.currentValue === "";
    },
    textareaStyle() {
      return Object.assign({}, this.textareaCalcStyle, { resize: this.resize });
    },
    isDisabled() {
      return isPropEnabled(this.disabled);
    },
    isReadonly() {
      return isPropEnabled(this.readonly);
    },
    field() {
      return this.type === "textarea" ? this.$refs.textarea : this.$refs.input;
    },
    showPwdVisible() {
      return this.showPassword && !this.isDisabled && !this.isReadonly;
    },
    fieldOptions() {
      const options = {};
      ["size", "resize", "readonly", "autofocus", "disabled", "name", "rows"].forEach((prop) => {
        options[prop] = this.$props[prop];
      });
      options.placeholder = this.getPlaceholder();
      return options;
    },
    bindOptions() {
      return { ...this.fieldOptions, ...this.validateHintOptions };
    },
    inputInnerStyle() {
      const styles = {};
      const OFFSET_GUTTER = 12;
      if (this.prefixOffset) {
        styles.paddingLeft = `${this.prefixOffset + OFFSET_GUTTER}px`;
      }
      if (this.isAutoFitSuffix && this.suffixOffset) {
        styles.paddingRight = this.suffixOffset + "px";
      }
      return styles;
    },
    disabledStatus() {
      return this.isDisabled;
    },
    isShowTextAreaCount() {
      return typeof this.limit === "number" || typeof this.limitNumber === "number";
    },
    outOfWordLimit() {
      if (!this.isShowTextAreaCount || !this.currentLimit) {
        return false;
      }
      return this.textLength > this.currentLimit;
    },
    currentLimit() {
      var _a;
      return (_a = this.limit) != null ? _a : this.limitNumber;
    }
  },
  watch: {
    value(val) {
      this.setCurrentValue(val);
    },
    isDisabled(val) {
      if (val) {
        this.clearValidateState();
      }
    }
  },
  created() {
    this.$on("inputSelect", this.inputSelect);
    this.debounceValidate = debounce(this.safeValidate, VALIDATE_TIME);
  },
  beforeDestroy() {
    this.destroyResizeObserver();
  },
  mounted() {
    this.resizeTextarea();
    this.calcSlotFix();
    this.initResizeObserver();
  },
  methods: {
    handleBlur(event) {
      if (this.trimPreZero || this.trimSpace) {
        this._trimCharacters();
      }
      this.validate();
      this.$emit("blur", event);
      this.focusing = false;
    },
    inputSelect() {
      this.$refs.input.select();
    },
    resizeTextarea() {
      const { autosize, type } = this;
      if (!autosize || type !== "textarea") {
        return;
      }
      const minRows = autosize.minRows;
      const maxRows = autosize.maxRows;
      this.textareaCalcStyle = calcTextareaHeight(this.$refs.textarea, minRows, maxRows);
    },
    handleFocus(event) {
      this.toggleValidError(this.field);
      this.$emit("focus", event);
      this.focusing = true;
    },
    calcCharLength(value) {
      return this.useUTF8Len ? format.utf8Length(value) : value.length;
    },
    updateTextLen(value = this.field.value) {
      this.updateFieldValue(value);
      this.textLength = this.calcCharLength(this.field.value);
    },
    updateFieldValue(value) {
      if (!this.limit || this.calcCharLength(value) < this.limit) {
        this.field.value = value;
        return;
      }
      this.field.value = format.limitString(value, this.limit, this.useUTF8Len);
    },
    handleCompositionEnd(compositionEvent) {
      this.handleInput(compositionEvent);
    },
    handleInput(event) {
      var _a;
      if (event.isComposing) {
        return;
      }
      const newInputKey = (_a = Array.from(event.target.value).pop()) != null ? _a : "";
      const isDelete = /^delete/i.test(event.inputType);
      const allowInput = isDelete || this.maskInput(newInputKey);
      if (allowInput !== true) {
        event.target.value = this.currentValue;
        return;
      }
      this.updateTextLen();
      const value = event.target.value;
      this.$emit("input", value);
      this.setCurrentValue(value);
    },
    handleIconClick(event) {
      if (this.onIconClick) {
        this.onIconClick(event);
      }
      this.$emit("click", event);
    },
    handleClear(event) {
      const value = "";
      this.$emit("clear", event);
      this.$emit("input", value);
      this.setCurrentValue(value);
    },
    setCurrentValue(value) {
      if (value === this.currentValue) {
        return;
      }
      this.__hasValue = this.__hasValue || Boolean(value);
      this.$nextTick((_) => {
        this.resizeTextarea();
        this.debounceValidate();
      });
      if (this.currentLimit) {
        this.updateTextLen(value);
        this.currentValue = this.field.value === value ? value : this.field.value;
      } else {
        this.currentValue = value;
      }
      this.$emit("change", this.currentValue);
    },
    onValidate(ret) {
      this.setValidateState(ret);
      this.$emit(ret === true ? "valid" : "invalid", ret);
      this.$nextTick(() => {
        if (this.focusing) {
          this.toggleValidError(this.field);
        }
      });
    },
    clearValidateState() {
      this.setValidateState(true);
    },
    focus: function() {
      const el = this.$refs.input ? this.$refs.input : this.$refs.textarea;
      const value = el.value;
      if (!ua.isIE) {
        el.focus();
        return;
      }
      el.value = "";
      el.focus();
      el.value = value;
    },
    blur: function() {
      if (this.$refs.input) {
        this.$refs.input.blur();
      }
      if (this.$refs.textarea) {
        this.$refs.textarea.blur();
      }
    },
    getData() {
      return this.currentValue;
    },
    getValue() {
      return this.currentValue;
    },
    setData(value) {
      this.$emit("input", value);
      this.setCurrentValue(value);
    },
    setValue(...args) {
      this.setData(...args);
    },
    reset() {
      this.setValue(this.initValue);
    },
    calcSlotFix(force) {
      if ($(this.$el).is(":hidden")) {
        return;
      }
      if (!force && this._calcSlot) {
        return;
      }
      if (this.$slots.prefix) {
        this.prefixOffset = this.calcIconOffset("pre");
      }
      if (this.$slots.suffix) {
        this.suffixOffset = this.calcIconOffset("suf");
      }
      this.$emit("after-calc-slot-fix", this.inputInnerStyle);
      this._calcSlot = true;
    },
    calcIconOffset(place) {
      const pendantMap = {
        suf: "suffix",
        pre: "prefix"
      };
      const pendant = pendantMap[place];
      if (this.$slots[pendant]) {
        let width = this.$el.querySelector(`.el-input__${pendant}`).offsetWidth || 0;
        if (this.$refs.input) {
          if (place === "suf") {
            const rightSpace = getStyleComputedProperty(this.$refs.suffix, "right");
            width += 2 * parseInt(rightSpace, 10);
          }
        }
        return width;
      }
    },
    _trimCharacters() {
      let value = String(this.value);
      if (this.trimSpace) {
        value = value.trim();
      }
      if (this.trimPreZero) {
        value = value.replace(/^0+/, "");
      }
      if (typeof this.value === "number") {
        value = Number(value);
      }
      this.$emit("input", value);
      this.setCurrentValue(value);
    },
    getPlaceholder() {
      var _a;
      if (lang.isObject(this.placeholder)) {
        return (_a = this.placeholder.text) != null ? _a : "";
      }
      if (this.placeholder) {
        return this.placeholder;
      }
      if (this.allowBlank) {
        return $i("scp.vt_component.sf_widget.packages.input.src.input.default_placeholder");
      }
      if (this.validateType || $.isFunction(this.validator)) {
        return "";
      }
      if (typeof this.allowBlank === "undefined") {
        return $i("scp.vt_component.sf_widget.packages.input.src.input.error_argument_placeholder");
      }
      return "";
    },
    getValidateType() {
      return this.validateType || this.type;
    },
    maskInput(newInputKey) {
      if (!this.validateEnabled) {
        return true;
      }
      const cfg = this.getFieldRule();
      if (!cfg || !cfg.mask && !cfg.type) {
        return true;
      }
      if (newInputKey !== "") {
        if (cfg.mask && !maskTest(cfg.mask, newInputKey, cfg)) {
          return false;
        }
        if (cfg.type && !(cfg.type instanceof RegExp)) {
          return typeVerify(newInputKey, cfg);
        }
      }
      return true;
    },
    processRule(rule) {
      rule.getFieldValue = () => {
        return lang.isEmpty(this.currentValue) ? this.currentValue : String(this.currentValue);
      };
      return rule;
    },
    safeValidate() {
      if (!this._isDestroyed) {
        this.validate();
      }
    },
    checkIsDisabled() {
      return this.isDisabled;
    },
    getPrefixedClassName,
    initResizeObserver() {
      if (!window.ResizeObserver || this.type !== "textarea") {
        return;
      }
      if (!this.isShowTextAreaCount || !["both", "horizontal"].includes(this.resize)) {
        return;
      }
      let isFirstResize = true;
      this.resizeObserver = new ResizeObserver(() => {
        if (isFirstResize) {
          isFirstResize = false;
          return;
        }
        this.isResize = true;
        this.destroyResizeObserver();
      });
      if (this.$refs.textarea) {
        this.resizeObserver.observe(this.$refs.textarea);
      }
    },
    destroyResizeObserver() {
      if (this.resizeObserver) {
        this.resizeObserver.disconnect();
        this.resizeObserver = null;
      }
    }
  }
};
const __vue_script__$1 = script$1;
var __vue_render__$1 = function() {
  var _obj;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      directives: [
        {
          name: "on-show",
          rawName: "v-on-show.once",
          value: {
            callback: _vm.calcSlotFix,
            enable: !!_vm.$slots.prefix || _vm.isAutoFitSuffix
          },
          expression: "{ callback: calcSlotFix, enable: !!$slots.prefix || isAutoFitSuffix }",
          modifiers: { once: true }
        }
      ],
      class: [
        _vm.type === "textarea" ? _vm.getPrefixedClassName("el-textarea") : _vm.getPrefixedClassName("el-input"),
        _vm.currentSize ? _vm.getPrefixedClassName("el-input--" + _vm.currentSize) : "",
        (_obj = {}, _obj[_vm.getPrefixedClassName("is-disabled")] = _vm.isDisabled, _obj[_vm.getPrefixedClassName("el-input-group")] = _vm.$slots.prepend || _vm.$slots.append, _obj[_vm.getPrefixedClassName("el-input-group--append")] = _vm.$slots.append, _obj[_vm.getPrefixedClassName("el-input-group--prepend")] = _vm.$slots.prepend, _obj[_vm.getPrefixedClassName("el-input--prefix")] = _vm.$slots.prefix, _obj[_vm.getPrefixedClassName("el-input--suffix")] = _vm.$slots.suffix || _vm.showPassword, _obj[_vm.getPrefixedClassName("el-input--clear")] = _vm.canClear && !_vm.isEmpty, _obj)
      ],
      style: _vm.inputWrapStyle
    },
    [
      _vm.type !== "textarea" ? [
        _vm.$slots.prepend ? _c(
          "div",
          {
            class: _vm.getPrefixedClassName("el-input-group__prepend")
          },
          [_vm._t("prepend")],
          2
        ) : _vm._e(),
        _vm._v(" "),
        _vm.$slots.prefix ? _c(
          "span",
          { class: _vm.getPrefixedClassName("el-input__prefix") },
          [_vm._t("prefix")],
          2
        ) : _vm._e(),
        _vm._v(" "),
        _vm.canClear && !_vm.isEmpty ? _c(
          "span",
          { class: _vm.getPrefixedClassName("el-input__clear") },
          [
            _c(
              "span",
              {
                class: _vm.getPrefixedClassName(
                  "el-input__clear-inner"
                )
              },
              [
                _c("i", {
                  staticClass: "iconfont vtv-icon-comp-tip-close",
                  on: {
                    click: function($event) {
                      $event.stopPropagation();
                      return _vm.handleClear($event);
                    }
                  }
                })
              ]
            )
          ]
        ) : _vm._e(),
        _vm._v(" "),
        _vm.$slots.suffix || _vm.showPassword ? _c(
          "span",
          {
            ref: "suffix",
            class: _vm.getPrefixedClassName("el-input__suffix")
          },
          [
            _c(
              "span",
              {
                class: _vm.getPrefixedClassName(
                  "el-input__suffix-inner"
                )
              },
              [
                _vm._t("suffix"),
                _vm._v(" "),
                _c("i", {
                  directives: [
                    {
                      name: "show",
                      rawName: "v-show",
                      value: _vm.showPwdVisible,
                      expression: "showPwdVisible"
                    }
                  ],
                  staticClass: "color-gray iconfont",
                  class: [
                    _vm.passwordVisible ? "vtv-icon-show-group" : "vtv-icon-hide-password",
                    _vm.isDisabled ? "" : "cursor-pointer"
                  ],
                  on: {
                    click: function($event) {
                      _vm.passwordVisible = !_vm.passwordVisible;
                    }
                  }
                })
              ],
              2
            )
          ]
        ) : _vm._e(),
        _vm._v(" "),
        _vm._t("icon", [
          _vm.icon ? _c("i", {
            class: [
              _vm.getPrefixedClassName("el-input__icon"),
              _vm.getPrefixedClassName("el-icon-" + _vm.icon),
              _vm.onIconClick ? _vm.getPrefixedClassName("is-clickable") : ""
            ],
            on: { click: _vm.handleIconClick }
          }) : _vm._e()
        ]),
        _vm._v(" "),
        _vm.type === "password" ? _c("input", {
          staticStyle: { display: "none" },
          attrs: { type: "text" }
        }) : _vm._e(),
        _vm._v(" "),
        _vm.type === "password" ? _c("input", {
          staticStyle: { display: "none" },
          attrs: { type: "password" }
        }) : _vm._e(),
        _vm._v(" "),
        _vm.type !== "textarea" ? _c(
          "input",
          _vm._g(
            _vm._b(
              {
                ref: "input",
                class: [
                  _vm.getPrefixedClassName("el-input__inner"),
                  _vm.invalidCls
                ],
                style: _vm.inputInnerStyle,
                attrs: {
                  id: _vm.fieldSelectorID,
                  "style-key": "input",
                  type: _vm.showPassword ? _vm.passwordVisible ? "text" : "password" : _vm.type,
                  autocomplete: _vm.autoComplete
                },
                domProps: { value: _vm.currentValue },
                on: {
                  input: _vm.handleInput,
                  compositionend: _vm.handleCompositionEnd,
                  focus: _vm.handleFocus,
                  blur: _vm.handleBlur
                }
              },
              "input",
              _vm.bindOptions,
              false
            ),
            _vm.additionalEvent
          )
        ) : _vm._e(),
        _vm._v(" "),
        _vm.$slots.append ? _c(
          "div",
          { class: _vm.getPrefixedClassName("el-input-group__append") },
          [_vm._t("append")],
          2
        ) : _vm._e()
      ] : [
        _c(
          "textarea",
          _vm._g(
            _vm._b(
              {
                ref: "textarea",
                class: [
                  _vm.getPrefixedClassName("el-textarea__inner"),
                  _vm.invalidCls
                ],
                style: _vm.textareaStyle,
                attrs: { id: _vm.fieldSelectorID, "style-key": "textarea" },
                domProps: { value: _vm.currentValue },
                on: {
                  input: _vm.handleInput,
                  compositionend: _vm.handleCompositionEnd,
                  focus: _vm.handleFocus,
                  blur: _vm.handleBlur
                }
              },
              "textarea",
              _vm.bindOptions,
              false
            ),
            _vm.additionalEvent
          )
        ),
        _vm._v(" "),
        _vm.isShowTextAreaCount ? _c(
          "div",
          {
            class: _vm.getPrefixedClassName(
              "el-textarea__inner__count"
            )
          },
          [
            _c(
              "span",
              {
                class: _vm.outOfWordLimit ? _vm.getPrefixedClassName(
                  "el-textarea__inner__count--error"
                ) : ""
              },
              [
                _vm._v(
                  "\n        " + _vm._s(_vm.textLength) + "\n      "
                )
              ]
            ),
            _vm._v("\n      /" + _vm._s(_vm.currentLimit) + "\n    ")
          ]
        ) : _vm._e()
      ]
    ],
    2
  );
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
const getIpConfig = () => {
  return {
    ipv4: {
      text: "IPv4",
      subnetText: $i("scp.vt_component.sf_widget.packages.ip_input.src.hint.subnet_text"),
      example: "192.168.1.1",
      rangeExample: "192.168.1.1-192.168.1.10",
      subnetExample: "192.168.1.1/24"
    },
    ipv6: {
      text: "IPv6",
      subnetText: $i("scp.vt_component.sf_widget.packages.ip_input.src.hint.prefix"),
      example: "2001::abc",
      rangeExample: "2001::1000-2001::f000",
      subnetExample: "2001:ffff:ffff:ffff::/64"
    }
  };
};
function getText(type, wrapText, opt) {
  const IP = getIpConfig();
  wrapText = wrapText || "<br>";
  let result = [
    $i("scp.vt_component.sf_widget.packages.ip_input.src.hint.ip_address", {
      0: IP[type].example
    }),
    wrapText,
    $i("scp.vt_component.sf_widget.packages.ip_input.src.hint.ip_range", {
      0: IP[type].rangeExample
    })
  ];
  if (opt.type === "all") {
    result.unshift(
      $i("scp.vt_component.sf_widget.packages.ip_input.src.hint.all_option_format", {
        0: IP[type].text
      }),
      wrapText
    );
  }
  if (opt.subnet) {
    result = result.concat([
      wrapText,
      $i("scp.vt_component.sf_widget.packages.ip_input.src.hint.subnet_result_text", {
        0: IP[type].subnetText,
        1: IP[type].subnetExample
      })
    ]);
  }
  return result;
}
function getResult(isPlaceholder, opt) {
  const IP = getIpConfig();
  const wrapText = isPlaceholder ? "\n" : "<br>";
  const prefix = isPlaceholder ? $i("scp.vt_component.sf_widget.packages.ip_input.src.hint.prefix_enter") : $i("scp.vt_component.sf_widget.packages.ip_input.src.hint.prefix_supported");
  let typeText = "", result = [];
  switch (opt.type) {
    case "ipv4":
    case "ipv6":
      typeText = IP[opt.type].text;
      result = getText(opt.type, wrapText, opt);
      break;
    case "all":
      typeText = `${IP.ipv4.text}/${IP.ipv6.text}`;
      result = [...getText("ipv4", wrapText, opt), wrapText, wrapText, ...getText("ipv6", wrapText, opt)];
      break;
    default: {
      throw new Error("Unsupported types");
    }
  }
  const title = opt.multi ? $i("scp.vt_component.sf_widget.packages.ip_input.src.hint.multi_address", {
    0: prefix,
    1: typeText
  }) : $i("scp.vt_component.sf_widget.packages.ip_input.src.hint.single_address", {
    0: prefix,
    1: typeText
  });
  return [title, wrapText, ...result].join("");
}
function getHint(opt) {
  const IP = getIpConfig();
  opt = {
    range: false,
    type: "ipv4",
    subnet: false,
    multi: false,
    ...opt
  };
  if (!opt.range) {
    let info = {};
    switch (opt.type) {
      case "ipv4":
      case "ipv6":
        info = {
          hint: $i("scp.vt_component.sf_widget.packages.ip_input.src.hint.hint_support_address", {
            0: IP[opt.type].text,
            1: IP[opt.type].example
          }),
          placeholder: $i("scp.vt_component.sf_widget.packages.ip_input.src.hint.hint_placeholder_address_format", {
            0: IP[opt.type].text,
            1: IP[opt.type].example
          })
        };
        break;
      case "all":
        info = {
          hint: $i("scp.vt_component.sf_widget.packages.ip_input.src.hint.all_hint_support_address", {
            0: IP.ipv4.text,
            1: IP.ipv6.text,
            2: IP.ipv4.example,
            3: IP.ipv6.example
          }),
          placeholder: $i("scp.vt_component.sf_widget.packages.ip_input.src.hint.all_placeholder_address_format", {
            0: IP.ipv4.text,
            1: IP.ipv6.text
          })
        };
        break;
      default: {
        throw new Error("Unsupported types");
      }
    }
    return info;
  }
  const hint = getResult(false, opt);
  const placeholder = opt.multi ? getResult(true, opt) : $i("scp.vt_component.sf_widget.packages.ip_input.src.hint.default_placeholder");
  return {
    hint,
    placeholder
  };
}
var script = {
  name: componentName.ipInput,
  componentName: componentName.ipInput,
  components: {
    SfInput: __vue_component__$1
  },
  extends: __vue_component__$1,
  props: {
    tipRange: {
      type: Boolean,
      default: false
    },
    tipType: {
      type: String,
      default: "ipv4",
      validator: (v) => ["ipv4", "ipv6", "all"].includes(v)
    }
  },
  computed: {
    isTextarea() {
      return this.type === "textarea";
    },
    tipContent() {
      return getHint({
        range: this.tipRange,
        type: this.tipType,
        subnet: this.withSubnet,
        multi: this.isTextarea
      });
    },
    inputProps() {
      const props = {};
      for (const key of Object.keys(this.$props)) {
        if (!["tipRange", "tipType"].includes(key)) {
          props[key] = this.$props[key];
        }
      }
      const textareaRows = 10;
      return {
        ...props,
        placeholder: props.placeholder || this.tipContent.placeholder,
        rows: props.type === "textarea" ? Math.max(props.rows, textareaRows) : props.rows
      };
    }
  },
  methods: {
    shouldAddToForm() {
      return false;
    },
    getPrefixedClassName
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _obj;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      class: (_obj = {}, _obj[_vm.getPrefixedClassName("sf-ip-input")] = _vm.isTextarea, _obj)
    },
    [
      !_vm.isTextarea ? [
        _c(
          "sf-input",
          _vm._g(
            _vm._b({ ref: "input" }, "sf-input", _vm.inputProps, false),
            _vm.$listeners
          ),
          [
            _c("i", {
              class: [
                "iconfont",
                "vtv-icon-tip-info",
                _vm.getPrefixedClassName("sf-ip-input__append-tip")
              ],
              attrs: { slot: "append", "data-hint": _vm.tipContent.hint },
              slot: "append"
            })
          ]
        )
      ] : [
        _c(
          "sf-input",
          _vm._g(
            _vm._b(
              {
                ref: "input",
                class: _vm.getPrefixedClassName("sf-ip-input__inner")
              },
              "sf-input",
              _vm.inputProps,
              false
            ),
            _vm.$listeners
          )
        ),
        _vm._v(" "),
        _c("i", {
          class: [
            "iconfont",
            "vtv-icon-tip-info",
            _vm.getPrefixedClassName("sf-ip-input__tip")
          ],
          attrs: { "data-hint": _vm.tipContent.hint }
        })
      ]
    ],
    2
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__$1 as SfInput, __vue_component__ as SfIpInput };
