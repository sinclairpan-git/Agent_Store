import $ from 'jquery';
import { componentName } from '@sxf/er-components/_const';
import { isPropEnabled } from '@sxf/er-components/_utils/vue-utils';
import { getPrefixedClassName } from '@sxf/er-feature';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
import { SfFlex, SfFlexItem } from '@sxf/er-components/flex';
import clone from '@sxf/er-utils/clone';
var Color = { "--color-belarus-green-l70": "#edfcf2", "--color-belarus-green-l60": "#daf2e2", "--color-belarus-green-l50": "#c2f2d2", "--color-belarus-green-l40": "#8debac", "--color-belarus-green-l30": "#7ee5a1", "--color-belarus-green-l20": "#6cd990", "--color-belarus-green-l10": "#6c8", "--color-belarus-green": "#50b371", "--color-belarus-green-d10": "#3d995c", "--color-belarus-green-d20": "#2d8048", "--color-graphite-black-l70": "#637a99", "--color-graphite-black-l60": "#596a80", "--color-graphite-black-l50": "#505f73", "--color-graphite-black-l40": "#475466", "--color-graphite-black-l30": "#3e4a59", "--color-graphite-black-l20": "#36404d", "--color-graphite-black-l10": "#2d3540", "--color-graphite-black": "#242a33", "--color-graphite-black-d10": "#1b2026", "--color-graphite-black-d20": "#12161a", "--color-poseidon-blue-l70": "#f5f9ff", "--color-poseidon-blue-l60": "#e6f1ff", "--color-poseidon-blue-l50": "#c2d7f2", "--color-poseidon-blue-l40": "#91bbf2", "--color-poseidon-blue-l30": "#61a0f2", "--color-poseidon-blue-l20": "#197dff", "--color-poseidon-blue-l10": "#1876f2", "--color-poseidon-blue": "#1770e6", "--color-poseidon-blue-d10": "#156ad9", "--color-poseidon-blue-d20": "#1464cc", "--color-poseidon-blue-d30": "#1258b2", "--color-poseidon-blue-d40": "#0f458c", "--color-poseidon-blue-d50": "#0e458c", "--color-poseidon-blue-d60": "#0d3e80", "--color-sky-blue-l70": "#f5f9ff", "--color-sky-blue-l60": "#e6f1ff", "--color-sky-blue-l50": "#c2d7f2", "--color-sky-blue-l40": "#91bbf2", "--color-sky-blue-l30": "#61a0f2", "--color-sky-blue-l20": "#197dff", "--color-sky-blue-l10": "#1876f2", "--color-sky-blue": "#1770e6", "--color-sky-blue-d10": "#156ad9", "--color-sky-blue-d20": "#1464cc", "--color-sky-blue-d30": "#1258b2", "--color-sky-blue-d40": "#0f458c", "--color-sky-blue-d50": "#0e458c", "--color-sky-blue-d60": "#0d3e80", "--color-grass-green-l70": "#edfcf2", "--color-grass-green-l60": "#daf2e2", "--color-grass-green-l50": "#b8e6c7", "--color-grass-green-l40": "#8ae6a8", "--color-grass-green-l30": "#82d99f", "--color-grass-green-l20": "#73e699", "--color-grass-green-l10": "#6c8", "--color-grass-green": "#50b371", "--color-grass-green-d10": "#3d995c", "--color-grass-green-d20": "#2d8048", "--color-gray-l60": "#fff", "--color-gray-l50": "#f9f9f9", "--color-gray-l40": "#f6f6f6", "--color-gray-l30": "#f3f3f3", "--color-gray-l20": "#eee", "--color-gray-l10": "#ddd", "--color-gray": "#ccc", "--color-gray-d10": "#bbb", "--color-gray-d20": "#aaa", "--color-gray-d30": "#999", "--color-gray-d40": "#666", "--color-gray-d50": "#333", "--color-gray-d60": "#000", "--color-golden-yellow-l70": "#fff5e6", "--color-golden-yellow-l60": "#ffdfb3", "--color-golden-yellow-l50": "#ffca80", "--color-golden-yellow-l40": "#ffbf66", "--color-golden-yellow-l30": "#ffb54d", "--color-golden-yellow-l20": "#fa3", "--color-golden-yellow-l10": "#ffa019", "--color-golden-yellow": "#ff9500", "--color-golden-yellow-d10": "#e0870b", "--color-golden-yellow-d20": "#c70", "--color-lemon-yellow-l70": "#fffce6", "--color-lemon-yellow-l60": "#fff5b3", "--color-lemon-yellow-l50": "#ffee80", "--color-lemon-yellow-l40": "#ffeb66", "--color-lemon-yellow-l30": "#fae458", "--color-lemon-yellow-l20": "#ffe433", "--color-lemon-yellow-l10": "#fd0", "--color-lemon-yellow": "#ffd500", "--color-lemon-yellow-d10": "#e6c000", "--color-lemon-yellow-d20": "#bf9f00", "--color-lemon-yellow-d30": "#998000", "--color-lemon-yellow-d40": "#806a00", "--color-lemon-yellow-d50": "#650", "--color-classical-red-l70": "#fff2f2", "--color-classical-red-l60": "#fae1e1", "--color-classical-red-l50": "#fabbbb", "--color-classical-red-l40": "#f59393", "--color-classical-red-l30": "#f07878", "--color-classical-red-l20": "#eb5e5e", "--color-classical-red-l15": "#f59393", "--color-classical-red-l10": "#eb5252", "--color-classical-red": "#e64545", "--color-classical-red-d10": "#d92121", "--color-classical-red-d20": "#cc1414", "--color-classical-red-d30": "#b21212", "--color-classical-red-d40": "#800d0d", "--color-classical-red-d50": "#660a0a", "--color-blue-gray-l80": "#fcfcfd", "--color-blue-gray-l70": "#fafbfc", "--color-blue-gray-l60": "#f7f8fa", "--color-blue-gray-l50": "#f5f7fa", "--color-blue-gray-l40": "#f0f2f5", "--color-blue-gray-l30": "#ebedf0", "--color-blue-gray-l20": "#e1e5eb", "--color-blue-gray-l10": "#dce0e6", "--color-blue-gray": "#ccd2d9", "--color-blue-gray-d10": "#c0c5cc", "--color-blue-gray-d20": "#b4b9bf", "--color-blue-gray-d30": "#a8adb3", "--color-blue-gray-d40": "#9ca0a6", "--color-blue-gray-d50": "#909499", "--color-blue-gray-d60": "#84878c", "--color-blue-gray-d70": "#6c6f73", "--color-blue-70": "#204ed9", "--color-gold-10": "#fff7e6", "--color-gold-70": "#e0720b", "--color-yellow-80": "#ad6800", "--color-yellow-90": "#884c00", "--color-brand-red-l50": "#faf0f0", "--color-brand-red-l40": "#fad6d6", "--color-brand-red-l30": "#fab7b7", "--color-brand-red-l20": "#fa8e8e", "--color-brand-red-l10": "#f55151", "--color-brand-red": "#de1b1b", "--color-brand-red-d10": "#ba0d0d", "--color-brand-red-d20": "#900e0e", "--color-brand-red-d30": "#661414", "--color-brand-red-d40": "#451717", "--color-brand-lime-l50": "#f5f7fa", "--color-brand-lime-l40": "#ebeff5", "--color-brand-lime-l30": "#dee3ed", "--color-brand-lime-l20": "#c8d0e0", "--color-brand-lime-l10": "#aeb9cb", "--color-brand-lime": "#8d98aa", "--color-brand-lime-d10": "#707a89", "--color-brand-lime-d20": "#59616e", "--color-brand-lime-d30": "#444b55", "--color-brand-lime-d40": "#343a41", "--color-yellow-l50": "#fffbe6", "--color-yellow-l40": "#fef1b7", "--color-yellow-l30": "#ffe48f", "--color-yellow-l20": "#ffd665", "--color-yellow-l10": "#ffc53d", "--color-yellow0": "#ffb019", "--color-yellow-d10": "#e09106", "--color-yellow-d20": "#ad6800", "--color-yellow-d30": "#884c00", "--color-yellow-d40": "#603400", "--color-canary-l50": "#fcfbf0", "--color-canary-l40": "#fcf7d7", "--color-canary-l30": "#fcf1a4", "--color-canary-l20": "#fcea72", "--color-canary-l10": "#fcdd3f", "--color-canary": "#fcd200", "--color-canary-d10": "#d9ad00", "--color-canary-d20": "#a68503", "--color-canary-d30": "#806703", "--color-canary-d40": "#594802", "--color-canary-d50": "#332901", "--color-primary-l70": "#f5f9ff", "--color-primary-l60": "#e6f1ff", "--color-primary-l50": "#c2d7f2", "--color-primary-l40": "#91bbf2", "--color-primary-l30": "#61a0f2", "--color-primary-l20": "#197dff", "--color-primary-l10": "#1876f2", "--color-primary": "#1770e6", "--color-primary-d10": "#156ad9", "--color-primary-d20": "#1464cc", "--color-primary-table-hover": "#f5f9ff", "--color-primary-checkbox": "#1770e6", "--color-success": "#50b371", "--color-warning-l40": "#ffbf66", "--color-warning-l30": "#ffb54d", "--color-warning-l20": "#fa3", "--color-warning-l10": "#ffa019", "--color-warning": "#ff9500", "--color-warning-d10": "#e0870b", "--color-warning-border": "#f2dfc3", "--color-danger-bg": "#faf0f0", "--color-danger-l50": "#faf0f0", "--color-danger-l40": "#f59393", "--color-danger-l30": "#f07878", "--color-danger-l20": "#eb5e5e", "--color-danger-l10": "#eb5252", "--color-danger": "#e64545", "--color-danger-d10": "#d92121", "--color-danger-d20": "#900e0e", "--color-danger-d30": "#661414", "--color-danger-d40": "#451717", "--color-gray-lighter": "#f3f3f3", "--color-gray-deeper": "#aaa", "--color-gray-light": "#eee", "--color-link-l10": "#204ed9", "--color-link": "#204ed9", "--color-link-d10": "undefined", "--color-info-l20": "#f5f8fd", "--color-info-l10": "#edf3fb", "--color-info": "#596a80", "--color-info-d10": "#7a8896", "--color-info-d20": "#4e6484", "--color-white": "#fff", "--color-transparent": "transparent", "--color-black-ligher": "rgba(0,0,0,0.8)", "--color-black": "#14161a", "--color-leak-blue-lighter": "#acebff", "--color-leak-blue-light": "#59d6ff", "--color-leak-blue-dark": "#1e3459", "--font-family": '"Microsoft Yahei","PingFangSC","Source Sans Pro","SimSun","sans-serif"', "--font-family-en": '"Helvetica","Helvetica Neue","sans-serif","Verdana","Tahoma","Arial","serif"', "--font-size-8xl": "64px", "--font-size-7xl": "56px", "--font-size-6xl": "48px", "--font-size-5xl": "40px", "--font-size-4xl": "32px", "--font-size-3xl": "28px", "--font-size-2xl": "24px", "--font-size-xl": "20px", "--font-size-l": "16px", "--font-size-m": "14px", "--font-size-s": "12px", "--font-size-base": "12px", "--font-weight-normal": "400", "--font-weight-bold": "500", "--font-weight-bolder": "600" };
const PANE_COLOR = Color["--color-blue-gray-l30"];
const BORDER_COLOR = Color["--color-blue-gray-l30"];
const STROKE_COLOR = Color["--color-primary"];
const STROKE_COLOR_TYPE = {
  error: Color["--color-danger"],
  warn: Color["--color-warning"],
  success: Color["--color-success"],
  info: Color["--color-graphite-black-l70"]
};
const TEXT_COLOR_TYPE = {
  normal: Color["--color-gray-d50"],
  error: Color["--color-danger"]
};
const SIZE_MAP = {
  normal: 8,
  small: 6,
  mini: 3
};
const STEP_STATES = {
  finish: "finish",
  failed: "failed",
  doing: "doing",
  waiting: "waiting"
};
const STEP_PANE_COLOR = Color["--color-blue-gray-l20"];
function pixelValue(value) {
  return isNaN(Number(value)) ? value : Number(value) + "px";
}
function parseColorLevel(color, currentValue, defaultValue, colorTypes) {
  const COLOR_TYPES = colorTypes || STROKE_COLOR_TYPE;
  if (typeof color === "string") {
    return COLOR_TYPES[color] || color;
  }
  if ($.isEmptyObject(color)) {
    return defaultValue;
  }
  const key = Object.keys(color).map((value) => Number(value) || 0).sort((a, b) => b - a).filter((value) => currentValue >= value)[0];
  const curColor = COLOR_TYPES[color[key]] || color[key];
  return typeof key !== "undefined" ? curColor : defaultValue;
}
var script$2 = {
  name: componentName.progress,
  componentName: componentName.progress,
  props: {
    percentage: {
      type: [Number, String],
      default: 0
    },
    strokeWidth: {
      type: [Number, String],
      default: 8
    },
    borderRadius: {
      type: [Number, String],
      default: 0
    },
    innerBorderRadius: {
      type: [Number, String],
      default: 0
    },
    strokeColor: {
      type: [String, Object],
      default: STROKE_COLOR
    },
    paneColor: {
      type: [String, Object],
      default: PANE_COLOR
    },
    borderColor: {
      type: [String, Object],
      default: BORDER_COLOR
    },
    borderStyle: {
      type: String,
      default: "solid"
    },
    textInside: {
      default: false
    },
    textColor: {
      type: [String, Object],
      default: TEXT_COLOR_TYPE.normal
    },
    noText: {},
    autoFontSize: {
      default: false
    },
    textWidth: {
      type: [Number, String],
      default: 40
    },
    showStripe: {
      type: Boolean,
      default: false
    },
    size: {},
    iconName: {
      type: String,
      default: ""
    },
    animation: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    isAutoFontSize() {
      return isPropEnabled(this.autoFontSize);
    },
    isTextInside() {
      return isPropEnabled(this.textInside);
    },
    isNoText() {
      return isPropEnabled(this.noText);
    },
    currentPercentage() {
      let value = Math.max(Number(this.percentage) || 0, 0);
      value = Math.min(value, 100);
      return Math.ceil(value);
    },
    currentBorderRadius() {
      return pixelValue(this.borderRadius);
    },
    currentInnerBorderRadius() {
      return pixelValue(this.innerBorderRadius);
    },
    currentStrokeWidth() {
      if (typeof this.size !== "undefined") {
        return SIZE_MAP[this.size] || 8;
      }
      return Number(this.strokeWidth) || 8;
    },
    currentStrokeColor() {
      return parseColorLevel(this.strokeColor, this.currentPercentage, STROKE_COLOR_TYPE.success);
    },
    currentPaneColor() {
      return parseColorLevel(this.paneColor, this.currentPercentage, PANE_COLOR);
    },
    currentBorderColor() {
      return parseColorLevel(this.borderColor, this.currentPercentage, BORDER_COLOR);
    },
    cls() {
      return {
        [getPrefixedClassName("sf-progress--without-text")]: this.isNoText,
        [getPrefixedClassName("sf-progress--text-inside")]: this.isTextInside
      };
    },
    outerStyle() {
      return {
        height: this.currentStrokeWidth + "px",
        background: this.currentPaneColor,
        "border-radius": this.currentBorderRadius
      };
    },
    barStyle() {
      return {
        width: this.currentPercentage + "%",
        background: this.currentStrokeColor,
        "border-radius": this.currentInnerBorderRadius
      };
    },
    bgStyle() {
      const res = { width: `calc(100% - ${this.currentPercentage}%)` };
      if (this.currentPercentage !== 100) {
        res.border = `1px ${this.borderStyle} ${this.currentBorderColor}`;
        res["border-left"] = "none";
      }
      return res;
    },
    progressTextSize() {
      return this.type === "line" ? 12 + this.currentStrokeWidth * 0.4 : this.width * 0.111111 + 2;
    },
    textStyle() {
      const style = {};
      style["color"] = parseColorLevel(this.textColor, this.currentPercentage, TEXT_COLOR_TYPE.normal, TEXT_COLOR_TYPE);
      if (this.isAutoFontSize) {
        style["font-size"] = this.progressTextSize;
      }
      return style;
    },
    iconStyle() {
      return {
        color: this.currentStrokeColor
      };
    }
  },
  methods: {
    getPrefixedClassName
  }
};
const __vue_script__$2 = script$2;
var __vue_render__$2 = function() {
  var _obj;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    { class: [_vm.getPrefixedClassName("sf-progress"), _vm.cls] },
    [
      _c("div", { class: _vm.getPrefixedClassName("sf-progress-bar") }, [
        _c(
          "div",
          {
            class: _vm.getPrefixedClassName("sf-progress-bar__outer"),
            style: _vm.outerStyle
          },
          [
            !_vm.isNoText && _vm.isTextInside ? _c(
              "div",
              {
                class: _vm.getPrefixedClassName(
                  "sf-progress-bar__outer-text"
                ),
                style: { color: _vm.currentStrokeColor }
              },
              [
                _vm._t(
                  "default",
                  [
                    _vm._v(
                      "\n          " + _vm._s(_vm.currentPercentage) + "%\n        "
                    )
                  ],
                  {
                    text: _vm.currentPercentage + "%",
                    percentage: _vm.percentage,
                    value: _vm.currentPercentage,
                    autoFontSize: _vm.progressTextSize,
                    strokeColor: _vm.currentStrokeColor,
                    paneColor: _vm.currentPaneColor
                  }
                )
              ],
              2
            ) : _vm._e(),
            _vm._v(" "),
            _c(
              "div",
              {
                class: (_obj = {}, _obj[_vm.getPrefixedClassName("sf-progress-bar__inner")] = true, _obj[_vm.getPrefixedClassName("sf-progress-bar__stripe")] = _vm.showStripe, _obj[_vm.getPrefixedClassName("moving")] = _vm.animation, _obj),
                style: _vm.barStyle
              },
              [
                !_vm.isNoText && _vm.isTextInside ? _c(
                  "div",
                  {
                    class: _vm.getPrefixedClassName(
                      "sf-progress-bar__inner-text"
                    )
                  },
                  [
                    _vm._t(
                      "default",
                      [
                        _vm._v(
                          "\n            " + _vm._s(_vm.currentPercentage) + "%\n          "
                        )
                      ],
                      {
                        text: _vm.currentPercentage + "%",
                        percentage: _vm.percentage,
                        value: _vm.currentPercentage,
                        autoFontSize: _vm.progressTextSize,
                        strokeColor: _vm.currentStrokeColor,
                        paneColor: _vm.currentPaneColor
                      }
                    )
                  ],
                  2
                ) : _vm._e()
              ]
            ),
            _vm._v(" "),
            _c("div", {
              class: _vm.getPrefixedClassName("sf-progress-bar__bg-end"),
              style: _vm.bgStyle
            })
          ]
        )
      ]),
      _vm._v(" "),
      !_vm.isNoText && !_vm.isTextInside ? _c(
        "div",
        { class: _vm.getPrefixedClassName("sf-progress__text-box") },
        [
          _c(
            "div",
            {
              class: [
                _vm.getPrefixedClassName("sf-progress__text"),
                "ellipsis"
              ],
              style: { width: _vm.textWidth + "px" }
            },
            [
              _vm._t(
                "default",
                [
                  _c(
                    "div",
                    {
                      staticClass: "ellipsis",
                      style: _vm.textStyle,
                      attrs: { title: _vm.currentPercentage + "%" }
                    },
                    [_vm._v(" " + _vm._s(_vm.currentPercentage) + "% ")]
                  )
                ],
                {
                  text: _vm.currentPercentage + "%",
                  percentage: _vm.percentage,
                  value: _vm.currentPercentage,
                  autoFontSize: _vm.progressTextSize,
                  strokeColor: _vm.currentStrokeColor,
                  paneColor: _vm.currentPaneColor
                }
              )
            ],
            2
          )
        ]
      ) : _vm._e(),
      _vm._v(" "),
      _vm.iconName ? _c("div", { class: _vm.getPrefixedClassName("sf-progress__icon") }, [
        _c("i", {
          class: "iconfont vtv-icon-" + _vm.iconName,
          style: _vm.iconStyle
        })
      ]) : _vm._e()
    ]
  );
};
var __vue_staticRenderFns__$2 = [];
__vue_render__$2._withStripped = true;
const __vue_inject_styles__$2 = void 0;
const __vue_scope_id__$2 = void 0;
const __vue_module_identifier__$2 = void 0;
const __vue_is_functional_template__$2 = false;
const __vue_component__$2 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$2, staticRenderFns: __vue_staticRenderFns__$2 },
  __vue_inject_styles__$2,
  __vue_script__$2,
  __vue_scope_id__$2,
  __vue_is_functional_template__$2,
  __vue_module_identifier__$2,
  false,
  void 0,
  void 0,
  void 0
);
var k = {}, max = Math.max, min = Math.min;
k.c = {};
k.c.d = $(document);
k.c.t = function(e) {
  return e.originalEvent.touches.length - 1;
};
k.o = function() {
  var s = this;
  this.o = null;
  this.$ = null;
  this.i = null;
  this.g = null;
  this.v = null;
  this.cv = null;
  this.x = 0;
  this.y = 0;
  this.w = 0;
  this.h = 0;
  this.$c = null;
  this.c = null;
  this.t = 0;
  this.isInit = false;
  this.fgColor = null;
  this.pColor = null;
  this.dH = null;
  this.cH = null;
  this.eH = null;
  this.rH = null;
  this.scale = 1;
  this.relative = false;
  this.relativeWidth = false;
  this.relativeHeight = false;
  this.$div = null;
  this.run = function() {
    var cf = function(e, conf) {
      var k2;
      for (k2 in conf) {
        s.o[k2] = conf[k2];
      }
      s._carve().init();
      s._configure()._draw();
    };
    if (this.$.data("kontroled"))
      return;
    this.$.data("kontroled", true);
    this.extend();
    this.o = $.extend(
      {
        min: this.$.data("min") !== void 0 ? this.$.data("min") : 0,
        max: this.$.data("max") !== void 0 ? this.$.data("max") : 100,
        stopper: true,
        readOnly: this.$.data("readonly") || this.$.attr("readonly") === "readonly",
        cursor: this.$.data("cursor") === true && 30 || this.$.data("cursor") || 0,
        thickness: this.$.data("thickness") && Math.max(Math.min(this.$.data("thickness"), 1), 0.01) || 0.35,
        lineCap: this.$.data("linecap") || "butt",
        width: this.$.data("width") || 200,
        height: this.$.data("height") || 200,
        displayInput: this.$.data("displayinput") == null || this.$.data("displayinput"),
        displayPrevious: this.$.data("displayprevious"),
        fgColor: this.$.data("fgcolor") || "#87CEEB",
        inputColor: this.$.data("inputcolor"),
        font: this.$.data("font") || "TG-TYPE, Arial",
        fontWeight: this.$.data("font-weight") || "bold",
        inline: false,
        step: this.$.data("step") || 1,
        rotation: this.$.data("rotation"),
        draw: null,
        change: null,
        cancel: null,
        release: null,
        format: function(v) {
          return v;
        },
        parse: function(v) {
          return parseFloat(v);
        }
      },
      this.o
    );
    this.o.flip = this.o.rotation === "anticlockwise" || this.o.rotation === "acw";
    if (!this.o.inputColor) {
      this.o.inputColor = this.o.fgColor;
    }
    if (this.$.is("fieldset")) {
      this.v = {};
      this.i = this.$.find("input");
      this.i.each(function(k2) {
        var $this = $(this);
        s.i[k2] = $this;
        s.v[k2] = s.o.parse($this.val());
        $this.bind("change blur", function() {
          var val = {};
          val[k2] = $this.val();
          s.val(val);
        });
      });
      this.$.find("legend").remove();
    } else {
      this.i = this.$;
      this.v = this.o.parse(this.$.val());
      this.v === "" && (this.v = this.o.min);
      this.$.bind("change blur", function() {
        s.val(s._validate(s.o.parse(s.$.val())));
      });
    }
    !this.o.displayInput && this.$.hide();
    this.$c = $(document.createElement("canvas")).attr({
      width: this.o.width,
      height: this.o.height
    });
    this.$div = $(
      "<div  " + (this.o.wrapperClass ? 'class="' + this.o.wrapperClass : "") + '" style="' + (this.o.inline ? "display:inline;" : "") + "width:" + this.o.width + "px;height:" + this.o.height + 'px;"></div>'
    );
    this.$.wrap(this.$div).before(this.$c);
    this.$div = this.$.parent();
    if (typeof G_vmlCanvasManager !== "undefined") {
      G_vmlCanvasManager.initElement(this.$c[0]);
    }
    this.c = this.$c[0].getContext ? this.$c[0].getContext("2d") : null;
    if (!this.c) {
      throw {
        name: "CanvasNotSupportedException",
        message: "Canvas not supported. Please use excanvas on IE8.0.",
        toString: function() {
          return this.name + ": " + this.message;
        }
      };
    }
    this.scale = (window.devicePixelRatio || 1) / (this.c.webkitBackingStorePixelRatio || this.c.mozBackingStorePixelRatio || this.c.msBackingStorePixelRatio || this.c.oBackingStorePixelRatio || this.c.backingStorePixelRatio || 1);
    this.relativeWidth = this.o.width % 1 !== 0 && this.o.width.indexOf("%");
    this.relativeHeight = this.o.height % 1 !== 0 && this.o.height.indexOf("%");
    this.relative = this.relativeWidth || this.relativeHeight;
    this._carve();
    if (this.v instanceof Object) {
      this.cv = {};
      this.copy(this.v, this.cv);
    } else {
      this.cv = this.v;
    }
    this.$.bind("configure", cf).parent().bind("configure", cf);
    this._listen()._configure()._xy().init();
    this.isInit = true;
    this.$.val(this.o.format(this.v));
    this._draw();
    return this;
  };
  this._carve = function() {
    if (this.relative) {
      var w = this.relativeWidth ? this.$div.parent().width() * parseInt(this.o.width) / 100 : this.$div.parent().width(), h = this.relativeHeight ? this.$div.parent().height() * parseInt(this.o.height) / 100 : this.$div.parent().height();
      this.w = this.h = Math.min(w, h);
    } else {
      this.w = this.o.width;
      this.h = this.o.height;
    }
    this.$div.css({
      width: this.w + "px",
      height: this.h + "px"
    });
    this.$c.attr({
      width: this.w,
      height: this.h
    });
    if (this.scale !== 1) {
      this.$c[0].width = this.$c[0].width * this.scale;
      this.$c[0].height = this.$c[0].height * this.scale;
      this.$c.width(this.w);
      this.$c.height(this.h);
    }
    return this;
  };
  this._draw = function() {
    var d = true;
    s.g = s.c;
    s.clear();
    s.dH && (d = s.dH());
    d !== false && s.draw();
  };
  this._touch = function(e) {
    var touchMove = function(e2) {
      var v = s.xy2val(e2.originalEvent.touches[s.t].pageX, e2.originalEvent.touches[s.t].pageY);
      if (v == s.cv)
        return;
      if (s.cH && s.cH(v) === false)
        return;
      s.change(s._validate(v));
      s._draw();
    };
    this.t = k.c.t(e);
    touchMove(e);
    k.c.d.bind("touchmove.k", touchMove).bind("touchend.k", function() {
      k.c.d.unbind("touchmove.k touchend.k");
      s.val(s.cv);
    });
    return this;
  };
  this._mouse = function(e) {
    var mouseMove = function(e2) {
      var v = s.xy2val(e2.pageX, e2.pageY);
      if (v == s.cv)
        return;
      if (s.cH && s.cH(v) === false)
        return;
      s.change(s._validate(v));
      s._draw();
    };
    mouseMove(e);
    k.c.d.bind("mousemove.k", mouseMove).bind(
      "keyup.k",
      function(e2) {
        if (e2.keyCode === 27) {
          k.c.d.unbind("mouseup.k mousemove.k keyup.k");
          if (s.eH && s.eH() === false)
            return;
          s.cancel();
        }
      }
    ).bind("mouseup.k", function(e2) {
      k.c.d.unbind("mousemove.k mouseup.k keyup.k");
      s.val(s.cv);
    });
    return this;
  };
  this._xy = function() {
    var o = this.$c.offset();
    this.x = o.left;
    this.y = o.top;
    return this;
  };
  this._listen = function() {
    if (!this.o.readOnly) {
      this.$c.bind("mousedown", function(e) {
        e.preventDefault();
        s._xy()._mouse(e);
      }).bind("touchstart", function(e) {
        e.preventDefault();
        s._xy()._touch(e);
      });
      this.listen();
    } else {
      this.$.attr("readonly", "readonly");
    }
    if (this.relative) {
      $(window).resize(function() {
        s._carve().init();
        s._draw();
      });
    }
    return this;
  };
  this._configure = function() {
    if (this.o.draw)
      this.dH = this.o.draw;
    if (this.o.change)
      this.cH = this.o.change;
    if (this.o.cancel)
      this.eH = this.o.cancel;
    if (this.o.release)
      this.rH = this.o.release;
    if (this.o.displayPrevious) {
      this.pColor = this.h2rgba(this.o.fgColor, "0.4");
      this.fgColor = this.h2rgba(this.o.fgColor, "0.6");
    } else {
      this.fgColor = this.o.fgColor;
    }
    return this;
  };
  this._clear = function() {
    this.$c[0].width = this.$c[0].width;
  };
  this._validate = function(v) {
    return ~~((v < 0 ? -0.5 : 0.5) + v / this.o.step) * this.o.step;
  };
  this.listen = function() {
  };
  this.extend = function() {
  };
  this.init = function() {
  };
  this.change = function(v) {
  };
  this.val = function(v) {
  };
  this.xy2val = function(x, y) {
  };
  this.draw = function() {
  };
  this.clear = function() {
    this._clear();
  };
  this.h2rgba = function(h, a) {
    var rgb;
    h = h.substring(1, 7);
    rgb = [parseInt(h.substring(0, 2), 16), parseInt(h.substring(2, 4), 16), parseInt(h.substring(4, 6), 16)];
    return "rgba(" + rgb[0] + "," + rgb[1] + "," + rgb[2] + "," + a + ")";
  };
  this.copy = function(f, t) {
    for (var i in f) {
      t[i] = f[i];
    }
  };
};
k.Dial = function() {
  k.o.call(this);
  this.startAngle = null;
  this.xy = null;
  this.radius = null;
  this.lineWidth = null;
  this.cursorExt = null;
  this.w2 = null;
  this.PI2 = 2 * Math.PI;
  this.extend = function() {
    this.o = $.extend(
      {
        bgColor: this.$.data("bgcolor") || "#EEEEEE",
        angleOffset: this.$.data("angleoffset") || 0,
        angleArc: this.$.data("anglearc") || 360,
        inline: true,
        wrapperClass: this.$.data("wrapperclass") || null
      },
      this.o
    );
  };
  this.val = function(v, triggerRelease) {
    if (null != v) {
      v = this.o.parse(v);
      if (triggerRelease !== false && v != this.v && this.rH && this.rH(v) === false) {
        return;
      }
      this.cv = this.o.stopper ? max(min(v, this.o.max), this.o.min) : v;
      this.v = this.cv;
      this.$.val(this.o.format(this.v));
      this._draw();
    } else {
      return this.v;
    }
  };
  this.xy2val = function(x, y) {
    var a, ret;
    a = Math.atan2(x - (this.x + this.w2), -(y - this.y - this.w2)) - this.angleOffset;
    if (this.o.flip) {
      a = this.angleArc - a - this.PI2;
    }
    if (this.angleArc != this.PI2 && a < 0 && a > -0.5) {
      a = 0;
    } else if (a < 0) {
      a += this.PI2;
    }
    ret = ~~(0.5 + a * (this.o.max - this.o.min) / this.angleArc) + this.o.min;
    this.o.stopper && (ret = max(min(ret, this.o.max), this.o.min));
    return ret;
  };
  this.listen = function() {
    var s = this, mwTimerStop, mwTimerRelease, mw = function(e) {
      e.preventDefault();
      var ori = e.originalEvent, deltaX = ori.detail || ori.wheelDeltaX, deltaY = ori.detail || ori.wheelDeltaY, v = s._validate(s.o.parse(s.$.val())) + (deltaX > 0 || deltaY > 0 ? s.o.step : deltaX < 0 || deltaY < 0 ? -s.o.step : 0);
      v = max(min(v, s.o.max), s.o.min);
      s.val(v, false);
      if (s.rH) {
        clearTimeout(mwTimerStop);
        mwTimerStop = setTimeout(function() {
          s.rH(v);
          mwTimerStop = null;
        }, 100);
        if (!mwTimerRelease) {
          mwTimerRelease = setTimeout(function() {
            if (mwTimerStop)
              s.rH(v);
            mwTimerRelease = null;
          }, 200);
        }
      }
    }, kval, to, m = 1, kv = {
      37: -s.o.step,
      38: s.o.step,
      39: s.o.step,
      40: -s.o.step
    };
    this.$.bind("keydown", function(e) {
      var kc = e.keyCode;
      if (kc >= 96 && kc <= 105) {
        kc = e.keyCode = kc - 48;
      }
      kval = parseInt(String.fromCharCode(kc));
      if (isNaN(kval)) {
        kc !== 13 && kc !== 8 && kc !== 9 && kc !== 189 && (kc !== 190 || s.$.val().match(/\./)) && e.preventDefault();
        if ($.inArray(kc, [37, 38, 39, 40]) > -1) {
          e.preventDefault();
          var v = s.o.parse(s.$.val()) + kv[kc] * m;
          s.o.stopper && (v = max(min(v, s.o.max), s.o.min));
          s.change(v);
          s._draw();
          to = window.setTimeout(function() {
            m *= 2;
          }, 30);
        }
      }
    }).bind("keyup", function(e) {
      if (isNaN(kval)) {
        if (to) {
          window.clearTimeout(to);
          to = null;
          m = 1;
          s.val(s.$.val());
        }
      } else {
        s.$.val() > s.o.max && s.$.val(s.o.max) || s.$.val() < s.o.min && s.$.val(s.o.min);
      }
    });
    this.$c.bind("mousewheel DOMMouseScroll", mw);
    this.$.bind("mousewheel DOMMouseScroll", mw);
  };
  this.init = function() {
    if (this.v < this.o.min || this.v > this.o.max) {
      this.v = this.o.min;
    }
    this.$.val(this.v);
    this.w2 = this.w / 2;
    this.cursorExt = this.o.cursor / 100;
    this.xy = this.w2 * this.scale;
    this.lineWidth = this.xy * this.o.thickness;
    this.lineCap = this.o.lineCap;
    this.radius = this.xy - this.lineWidth / 2;
    this.o.angleOffset && (this.o.angleOffset = isNaN(this.o.angleOffset) ? 0 : this.o.angleOffset);
    this.o.angleArc && (this.o.angleArc = isNaN(this.o.angleArc) ? this.PI2 : this.o.angleArc);
    this.angleOffset = this.o.angleOffset * Math.PI / 180;
    this.angleArc = this.o.angleArc * Math.PI / 180;
    this.startAngle = 1.5 * Math.PI + this.angleOffset;
    this.endAngle = 1.5 * Math.PI + this.angleOffset + this.angleArc;
    max(String(Math.abs(this.o.max)).length, String(Math.abs(this.o.min)).length, 2) + 2;
    this.o.displayInput && this.i.css({
      width: (this.w / 2 + 10 >> 0) + "px",
      height: (this.w / 3 >> 0) + "px",
      position: "absolute",
      "vertical-align": "middle",
      "margin-top": 44 + "px",
      "margin-left": "-" + (this.w * 3 / 4 + 8 >> 0) + "px",
      border: 0,
      background: "none",
      font: this.o.fontWeight + " " + 38 + "px " + this.o.font,
      "text-align": "center",
      color: this.o.inputColor || this.o.fgColor,
      padding: "0px",
      "-webkit-appearance": "none"
    }) || this.i.css({
      width: "0px",
      visibility: "hidden"
    });
  };
  this.change = function(v) {
    this.cv = v;
    this.$.val(this.o.format(v));
  };
  this.angle = function(v) {
    return (v - this.o.min) * this.angleArc / (this.o.max - this.o.min);
  };
  this.arc = function(v) {
    var sa, ea;
    v = this.angle(v);
    if (this.o.flip) {
      sa = this.endAngle + 1e-5;
      ea = sa - v - 1e-5;
    } else {
      sa = this.startAngle - 1e-5;
      ea = sa + v + 1e-5;
    }
    this.o.cursor && (sa = ea - this.cursorExt) && (ea = ea + this.cursorExt);
    return {
      s: sa,
      e: ea,
      d: this.o.flip && !this.o.cursor
    };
  };
  this.draw = function() {
    var c = this.g, a = this.arc(this.cv), pa, r = 1;
    c.lineWidth = this.lineWidth;
    c.lineCap = this.lineCap;
    if (this.o.bgColor !== "none") {
      c.beginPath();
      c.strokeStyle = this.o.bgColor;
      c.arc(this.xy, this.xy, this.radius, this.endAngle - 1e-5, this.startAngle + 1e-5, true);
      c.stroke();
    }
    if (this.o.displayPrevious) {
      pa = this.arc(this.v);
      c.beginPath();
      c.strokeStyle = this.pColor;
      c.arc(this.xy, this.xy, this.radius, pa.s, pa.e, pa.d);
      c.stroke();
      r = this.cv == this.v;
    }
    c.beginPath();
    c.strokeStyle = r ? this.o.fgColor : this.fgColor;
    c.arc(this.xy, this.xy, this.radius, a.s, a.e, a.d);
    c.stroke();
  };
  this.cancel = function() {
    this.val(this.v);
  };
};
$.fn.dial = $.fn.knob = function(o) {
  return this.each(function() {
    var d = new k.Dial();
    d.o = o;
    d.$ = $(this);
    d.run();
  }).parent();
};
const DEFAULT_WIDTH = 126;
const STROKE_WIDTH$1 = 8;
var script$1 = {
  name: componentName.circleProgress,
  componentName: componentName.circleProgress,
  extends: __vue_component__$2,
  props: {
    width: {
      type: [Number, String],
      default: DEFAULT_WIDTH
    },
    noBorderRadius: Boolean,
    borderRadius: {
      validator() {
        throw new Error('props "borderRadius" is not allowed on "sf-circle-progress"');
      }
    },
    textInside: {
      validator() {
        throw new Error('props "textInside" is not allowed on "sf-circle-progress"');
      }
    },
    thickness: {
      type: Number,
      default: 0,
      validator: (v) => v <= 1
    }
  },
  computed: {
    currentWidth() {
      const width = Number(this.width);
      return isNaN(width) ? DEFAULT_WIDTH : width;
    },
    relativeStrokeWidth() {
      return (this.currentStrokeWidth / this.width * 2).toFixed(2);
    },
    strokeLinecap() {
      return isPropEnabled(this.noBorderRadius) ? "butt" : "round";
    }
  },
  watch: {
    currentPercentage(v) {
      this.updateVal(v);
    },
    currentStrokeColor(v) {
      this.updateKnob({
        fgColor: v
      });
    },
    strokeLinecap(v) {
      this.updateKnob({
        lineCap: v
      });
    },
    currentPaneColor(v) {
      this.updateKnob({
        bgColor: v
      });
    }
  },
  mounted() {
    this.$knob = $(this.$refs.circle);
    const currentThickness = this.thicknessFormat();
    this.$knob.knob({
      fgColor: this.currentStrokeColor,
      bgColor: this.currentPaneColor,
      lineCap: this.strokeLinecap,
      thickness: currentThickness
    });
    this.updateVal(this.currentPercentage);
  },
  methods: {
    getPrefixedClassName,
    updateKnob(options) {
      this.$knob.trigger("configure", options);
    },
    updateVal(v) {
      this.$knob.val(v).trigger("change");
    },
    thicknessFormat() {
      if (this.thickness) {
        return this.thickness;
      }
      const halfWidth = this.width / 2, currentThickness = Number(STROKE_WIDTH$1 / halfWidth).toFixed(10);
      if (currentThickness <= 1) {
        return currentThickness;
      }
      return 0.1;
    }
  }
};
const __vue_script__$1 = script$1;
var __vue_render__$1 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c("div", { class: _vm.getPrefixedClassName("sf-circle-progress") }, [
    _c(
      "div",
      {
        style: {
          height: _vm.currentWidth + "px",
          width: _vm.currentWidth + "px"
        }
      },
      [
        _c("input", {
          ref: "circle",
          attrs: {
            type: "text",
            readOnly: "",
            "data-displayInput": "false",
            "data-thickness": _vm.relativeStrokeWidth,
            "data-width": "100%"
          }
        })
      ]
    ),
    _vm._v(" "),
    !_vm.isNoText && !_vm.isTextInside ? _c(
      "div",
      { class: _vm.getPrefixedClassName("sf-circle-progress_text") },
      [
        _vm._t(
          "default",
          [
            _c(
              "div",
              {
                style: _vm.textStyle,
                attrs: { title: _vm.currentPercentage + "%" }
              },
              [_vm._v(" " + _vm._s(_vm.currentPercentage) + "% ")]
            )
          ],
          {
            text: _vm.currentPercentage + "%",
            percentage: _vm.percentage,
            value: _vm.currentPercentage,
            autoFontSize: _vm.progressTextSize,
            strokeColor: _vm.currentStrokeColor,
            paneColor: _vm.currentPaneColor
          }
        )
      ],
      2
    ) : _vm._e()
  ]);
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
const STROKE_WIDTH = 2;
var script = {
  name: componentName.stepProgress,
  componentName: componentName.stepProgress,
  components: { SfFlex, SfFlexItem },
  extends: __vue_component__$2,
  props: {
    strokeWidth: {
      type: [Number, String],
      default: STROKE_WIDTH
    },
    strokeColor: {
      type: String,
      default: STROKE_COLOR
    },
    paneColor: {
      type: String,
      default: STEP_PANE_COLOR
    },
    stepList: {
      type: Array,
      default: () => []
    },
    borderRadius: {
      validator() {
        throw new Error('props "borderRadius" is not allowed on "sf-step-progress"');
      }
    },
    textInside: {
      validator() {
        throw new Error('props "textInside" is not allowed on "sf-step-progress"');
      }
    }
  },
  data() {
    return {
      steps: []
    };
  },
  computed: {
    statusColorMap() {
      return {
        normal: this.strokeColor,
        error: STROKE_COLOR_TYPE.error,
        warn: STROKE_COLOR_TYPE.warn
      };
    },
    currentStep() {
      return this.steps.find((item) => item.state === STEP_STATES.doing) || this.steps[0] || {};
    },
    baseWidth() {
      return typeof this.strokeWidth === "number" ? this.strokeWidth : parseInt(this.strokeWidth) || STROKE_WIDTH;
    },
    dotWidth() {
      return this.baseWidth * 4;
    },
    dotFlex() {
      return `0 0 ${this.dotWidth}px`;
    },
    stepFlex() {
      return `1 1 ${this.dotWidth}px`;
    },
    lastStep() {
      return this.steps[this.steps.length - 1] || {};
    },
    lineStyle() {
      return {
        top: `${this.baseWidth * 3 / 2}px`,
        paddingLeft: `${this.baseWidth * 4}px`
      };
    },
    lineStartStyle() {
      return {
        height: `${this.baseWidth}px`
      };
    },
    lineEndStyle() {
      return {
        backgroundColor: this.paneColor,
        height: `${this.baseWidth}px`
      };
    },
    dotStyle() {
      return {
        width: `${this.dotWidth}px`,
        height: `${this.dotWidth}px`,
        borderStyle: "solid",
        borderWidth: `${this.baseWidth}px`
      };
    },
    lastDotStyle() {
      return {
        width: `${this.dotWidth}px`,
        height: `${this.dotWidth}px`,
        borderStyle: "solid",
        borderWidth: `${this.baseWidth}px`,
        borderColor: this.lastStep.isFinish ? this.lastStep.backgroundColor : this.paneColor,
        backgroundColor: this.lastStep.isFinish ? this.lastStep.backgroundColor : "unset"
      };
    }
  },
  watch: {
    stepList: {
      deep: true,
      immediate: true,
      handler: function(val) {
        const newArray = clone(val);
        this.steps = newArray.map((item) => {
          let backgroundColor = this.paneColor;
          switch (item.state) {
            case STEP_STATES.waiting:
              backgroundColor = this.paneColor;
              item.percentage = 0;
              break;
            case STEP_STATES.doing:
              backgroundColor = this.statusColorMap[item.status] || this.strokeColor;
              break;
            case STEP_STATES.finish:
              backgroundColor = this.strokeColor;
              item.percentage = 100;
              break;
            case STEP_STATES.failed:
              backgroundColor = this.statusColorMap.error;
              item.percentage = 100;
              break;
            default:
              backgroundColor = this.paneColor;
          }
          return {
            ...item,
            isFinish: item.state !== STEP_STATES.doing && item.state !== STEP_STATES.waiting,
            percent: `0 0 ${item.percentage}%`,
            backgroundColor
          };
        });
      }
    }
  },
  methods: {
    getPrefixedClassName
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    { class: _vm.getPrefixedClassName("sf-step-progress") },
    [
      _vm.steps.length ? _c(
        "sf-flex",
        [
          _vm._l(_vm.steps, function(item) {
            return _c(
              "sf-flex-item",
              {
                key: item.id,
                class: _vm.getPrefixedClassName("step-progress__item"),
                attrs: { flex: _vm.stepFlex }
              },
              [
                _c("div", {
                  class: _vm.getPrefixedClassName(
                    "step-progress__item-dot"
                  ),
                  style: {
                    width: _vm.dotStyle.width,
                    height: _vm.dotStyle.height,
                    borderStyle: _vm.dotStyle.borderStyle,
                    borderWidth: _vm.dotStyle.borderWidth,
                    borderColor: item.percentage ? item.backgroundColor : _vm.paneColor,
                    backgroundColor: item.isFinish ? item.backgroundColor : "unset"
                  }
                }),
                _vm._v(" "),
                _c(
                  "div",
                  {
                    class: _vm.getPrefixedClassName(
                      "step-progress__item-line"
                    ),
                    style: _vm.lineStyle
                  },
                  [
                    _c(
                      "sf-flex",
                      [
                        item.percentage ? _c("sf-flex-item", {
                          style: {
                            height: _vm.lineStartStyle.height,
                            backgroundColor: item.backgroundColor
                          },
                          attrs: {
                            flex: item.isFinish ? "0 0 100%" : item.percent
                          }
                        }) : _vm._e(),
                        _vm._v(" "),
                        _c("sf-flex-item", {
                          style: _vm.lineEndStyle,
                          attrs: { flex: "auto" }
                        })
                      ],
                      1
                    )
                  ],
                  1
                )
              ]
            );
          }),
          _vm._v(" "),
          _c("sf-flex-item", { attrs: { flex: _vm.dotFlex } }, [
            _c("div", {
              class: _vm.getPrefixedClassName("step-progress__dot"),
              style: _vm.lastDotStyle
            })
          ])
        ],
        2
      ) : _vm._e(),
      _vm._v(" "),
      !_vm.isNoText ? _c(
        "div",
        { class: _vm.getPrefixedClassName("step-progress__text") },
        [
          _vm._t(
            "default",
            [
              _vm.currentStep.desc ? _c(
                "div",
                {
                  staticClass: "ellipsis",
                  attrs: { title: _vm.currentStep.desc }
                },
                [_vm._v(" " + _vm._s(_vm.currentStep.desc) + " ")]
              ) : _vm._e()
            ],
            {
              strokeWidth: _vm.baseWidth,
              currentStep: _vm.currentStep,
              steps: _vm.steps
            }
          )
        ],
        2
      ) : _vm._e()
    ],
    1
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
const stepState = STEP_STATES;
const stepStatus = {
  normal: "normal",
  error: "error",
  warn: "warn"
};
export { __vue_component__$1 as SfCircleProgress, __vue_component__$2 as SfProgress, __vue_component__ as SfStepProgress, stepState, stepStatus };
