import type { SfProgress, SfProgressProps } from './progress';

export type SfCircleProgressProps = Omit<SfProgressProps, 'borderRadius' | 'textInside' | 'noBorderRadius'> & {
  /**
   * 环形进度条宽度,也就是外圆的直径
   */
  width?: number;

  /**
   * 环形图的粗细配置， 取值范围（0, 1], 默认未配置；
   * 1、未配置该参数时，默认宽度以STROKE_WIDTH为准， 默认值是8,
   * 2、而当环形进度条的宽度 this.width< STROKE_WIDTH*2 时，默认取0.1
   */
  thickness?: number;
};

export type SfCircleProgress = SfProgress & SfCircleProgressProps;
