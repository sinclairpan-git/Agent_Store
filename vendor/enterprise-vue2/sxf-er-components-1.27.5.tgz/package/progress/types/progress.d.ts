import { VNode } from 'vue';

export declare type SfProgressColor =
  | string
  | {
      [k: number]: string;
    };

export interface SfProgressProps {
  /**
   * 百分比
   *
   * @default 0
   */
  readonly percentage: string | number;

  /**
   * 进度条线条宽度
   *
   * @default 8
   */
  readonly strokeWidth: number | string;

  /**
   * 进度条圆角
   *
   * @default 0
   */
  borderRadius: number | string;

  /**
   * 圆角
   *
   * @default 0
   */
  innerBorderRadius: number | string;

  /**
   * 线条颜色，支持配置字符串和对象
   * “默认绿色，>=50%显示黄色，>=80%显示红色”可传入：
   * {
   *   0: 'green',
   *   50: 'yellow',
   *   80: 'red'
   * }
   *
   * @default '#1ac575'
   */
  strokeColor: SfProgressColor;

  /**
   * 底槽颜色，支持配置字符串和对象
   * “默认绿色，>=50%显示黄色，>=80%显示红色”可传入：
   * {
   *   0: 'green',
   *   50: 'yellow',
   *   80: 'red'
   * }
   *
   * @default '#eee'
   */
  paneColor: SfProgressColor;

  /**
   * 底槽颜色，支持配置字符串和对象
   * “默认绿色，>=50%显示黄色，>=80%显示红色”可传入：
   * {
   *   0: 'green',
   *   50: 'yellow',
   *   80: 'red'
   * }
   *
   * @default '#eee'
   */
  borderColor: SfProgressColor;

  /**
   * 文本是否显示在进度条内部
   *
   * @default false
   */
  textInside: boolean;

  /**
   * 文本的颜色
   * 提供传入normal 或 error 两种颜色，只有严重告警才是红色
   */
  textColor: SfProgressColor;

  /**
   * 是否显示文本
   *
   * @default false
   */
  noText: boolean;

  /**
   * 是否根据宽度、线条宽度控制字体大小
   *
   * @default false
   */
  autoFontSize: boolean;

  /**
   * 文本的宽度
   *
   * @default 40
   */
  textWidth: number | string;

  /**
   * 是否要显示条纹
   *
   * @default false
   */
  showStripe: boolean;
}

export interface SfProgressSlots {
  $slots: {
    default?: VNode[];
  };
}

export declare type SfProgress = Readonly<SfProgressProps & SfProgressSlots> & Vue;
