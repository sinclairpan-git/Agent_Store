import type { SfProgress, SfProgressProps } from './progress';

export interface IStepProgressInfo {
  id: string;
  state: 'finish' | 'failed' | 'doing' | 'waiting';
  status: 'normal' | 'error' | 'warn';
  percentage: number;
  desc: string;
}

export type IStepProgressInfoList = IStepProgressInfo[];

export type SfStepProgressProps = Omit<
  SfProgressProps,
  'borderRadius' | 'textInside' | 'noBorderRadius' | 'percentage'
> & {
  /**
   * 进度条分段数据，示例：[{
   *    id: '5',
   *    state: 'doing',
   *    status: 'warn',
   *    percentage: 66,
   *    desc: '增量迁移中，当前延迟2秒',
   *  }]
   * 1、通过此数组长度来确定展示的分段数量
   * 2、每个分段数据要有：阶段完成状态state、当前阶段执行状态status、进度percentage、描述desc
   * 3、state取值：finish、failed、doing、waiting
   * 4、status取值：normal、error、warn
   * 5、正确的数据只会有一个为doing的state或没有，它之前的是finish或者failed，它之后的是waiting，需要按正确顺序传入数据
   * 6、status、percentage、desc只会在state为doing的进度条中起到展示当前阶段的作用
   */
  stepList: IStepProgressInfoList;
};

export type SfStepProgress = SfProgress & SfStepProgressProps;
