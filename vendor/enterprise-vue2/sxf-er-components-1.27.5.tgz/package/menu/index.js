import $ from 'jquery';
import { componentName } from '@sxf/er-components/_const';
import { ComponentMixin, MgrClientMixin, MgrServerMixin } from '@sxf/er-components/_mixins';
import { SfLayer } from '@sxf/er-components/layer';
import { SfScrollbar } from '@sxf/er-components/scrollbar';
import { getPrefixedClassName } from '@sxf/er-feature';
import { on, off } from '@sxf/er-utils/dom';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
var script = {
  name: componentName.menuItem,
  componentName: componentName.menuItem,
  mixins: [ComponentMixin, MgrClientMixin],
  props: {
    data: Object,
    icon: String,
    type: String,
    actionName: String,
    title: String,
    hideParent: {
      type: Boolean,
      default: true
    },
    hideGroupIcon: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      isHover: false,
      isGroup: false,
      isSeparator: this.type === "separator",
      subMenu: null,
      titleText: this.title
    };
  },
  watch: {
    title() {
      this.titleText = this.title;
    }
  },
  mounted() {
    this.initSubMenu();
  },
  methods: {
    updateHoverStatus({ hover }) {
      this.isHover = hover;
    },
    initSubMenu() {
      const scrollBar = this.$parent;
      const rootMenu = scrollBar.$vnode.data.attrs.rootMenu;
      if (!this.$slots.default) {
        return;
      }
      this.$slots.default.forEach((vnode) => {
        if (vnode.componentInstance && vnode.componentInstance.$options.componentName === componentName.menu) {
          this.isGroup = true;
          this.subMenu = vnode.child;
          this.subMenu.setRootMenu(rootMenu);
          rootMenu.insertSubMenu(this.subMenu);
          this.subMenu.alignTo(this.$el);
        }
      });
    },
    onClick(e) {
      if (this.isSeparator || this.disabled) {
        return;
      }
      this.$emit("click", e, this);
      this.$parent.$emit("click-item", e, this);
      if (this.actionName) {
        this.$emit("action", e, this);
      }
    },
    onEnter() {
      this.$parent.$emit("hover-submenu", this.subMenu, this);
    },
    updateTitle(title) {
      this.titleText = title;
    },
    getPrefixedClassName
  }
};
const __vue_script__$1 = script;
var __vue_render__$1 = function() {
  var _obj;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "li",
    {
      directives: [
        {
          name: "show",
          rawName: "v-show",
          value: !_vm.hidden,
          expression: "!hidden"
        }
      ],
      class: (_obj = {}, _obj[_vm.getPrefixedClassName("sf-menu-list__separator")] = _vm.isSeparator, _obj[_vm.getPrefixedClassName("sf-menu-list-item")] = !_vm.isSeparator, _obj[_vm.getPrefixedClassName("sf-menu-list-item-group")] = _vm.isGroup, _obj[_vm.getPrefixedClassName("sf-menu-list-item--hover")] = _vm.isHover, _obj),
      attrs: { disabled: _vm.disabled, title: _vm.titleText },
      on: { click: _vm.onClick, mouseenter: _vm.onEnter }
    },
    [
      _c("i", {
        directives: [
          {
            name: "show",
            rawName: "v-show",
            value: !_vm.hideGroupIcon && (_vm.isGroup || _vm.icon),
            expression: "!hideGroupIcon && (isGroup || icon)"
          }
        ],
        class: [
          _vm.icon ? "iconfont vtv-icon-" + _vm.icon : "",
          _vm.isGroup && !_vm.icon ? "iconfont vtv-icon-menu-more" : "",
          _vm.getPrefixedClassName("sf-menu-list-item__icon-before")
        ]
      }),
      _vm._v(" "),
      _vm._t("default"),
      _vm._v(" "),
      _c("i", {
        directives: [
          {
            name: "show",
            rawName: "v-show",
            value: _vm.isGroup,
            expression: "isGroup"
          }
        ],
        class: [
          _vm.getPrefixedClassName("sf-menu-list-item__icon-after"),
          "iconfont",
          "vtv-icon-arrow-right"
        ]
      })
    ],
    2
  );
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
const MIN_WIDTH = 144;
const MAX_HEIGHT = 400;
const EVENT_NAME_MAP = {
  click: "click",
  hover: "mouseenter"
};
const SfMenu = {
  name: componentName.menu,
  componentName: componentName.menu,
  mixins: [ComponentMixin, MgrServerMixin],
  props: {
    options: {
      type: Array,
      default: () => []
    },
    defaultTarget: {},
    notHideTargets: {
      type: Array,
      default: () => []
    },
    renderer: {},
    clickHide: {
      type: Boolean,
      default: true
    },
    anchor: {
      type: String,
      default: "right-start"
    },
    trigger: {
      type: String,
      default: "click"
    },
    size: {
      type: String,
      default: "normal",
      validator: (v) => ["normal", "small"].includes(v)
    },
    layerOptions: {
      type: Object,
      default: () => ({})
    },
    appendToBody: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      target: this.defaultTarget,
      optionsList: this.options,
      subMenuList: []
    };
  },
  computed: {
    layerOpt() {
      return $.extend(
        true,
        {},
        {
          removeOnDestroy: true,
          gpuAcceleration: false,
          modifiers: {
            preventOverflow: {
              padding: 0
            }
          }
        },
        this.layerOptions
      );
    }
  },
  watch: {
    options() {
      if (this.hidden) {
        this.loadNewOptions();
      }
    }
  },
  mounted() {
    this.hidden = true;
    this.menuLayer = this.$refs.menuLayer;
    this.menuScroll = this.$refs.menuScroll;
    this.menuList = this.$refs.menuList;
    this._initMenu();
    this._bindEvent();
  },
  beforeDestroy() {
    this.destroy();
  },
  methods: {
    _initMenu() {
      this.optionsList = this.options;
      if (this.defaultTarget) {
        const targetEl = this._getTarget();
        this.alignTo(targetEl);
        on(targetEl, EVENT_NAME_MAP[this.trigger], this.toggle);
      }
    },
    _bindEvent() {
      this.menuScroll.$on("hover-submenu", (subMenu, curItem) => {
        this.menuScroll.$children.forEach((item) => {
          if (typeof item.updateHoverStatus === "function") {
            item.updateHoverStatus({
              hover: false
            });
          }
        });
        if (this.subMenu) {
          this.subMenu.hide();
        }
        if (subMenu) {
          subMenu.show();
          curItem.updateHoverStatus({
            hover: true
          });
        }
        this.subMenu = subMenu;
      });
      this.menuScroll.$on("click-item", (e, menuItem) => {
        this.$emit("click-item", e, menuItem);
        if (this.clickHide && menuItem.hideParent && !menuItem.isGroup) {
          this.hideAllMenu();
        }
      });
      on(document, "click", this._documentHide);
    },
    _unbindEvent() {
      off(document, "click", this._documentHide);
      Object.values(EVENT_NAME_MAP).forEach((eventName) => {
        off(this.target, eventName, this.toggle);
      });
    },
    _getMenuWidth() {
      return Math.max(MIN_WIDTH, this.width || this.menuList.offsetWidth);
    },
    _getMenuHeight() {
      return Math.min(MAX_HEIGHT, this.height || this.menuList.offsetHeight);
    },
    _getRendererFn() {
      if (typeof this.renderer === "function") {
        return this.renderer;
      } else if (typeof this.renderer === "string") {
        return this.$vnode.context[this.renderer];
      }
      return (v) => v;
    },
    _renderText(data) {
      const renderFn = this._getRendererFn();
      return renderFn(data.label, data);
    },
    _documentHide(e) {
      const target = this.target;
      const isClickNotHideTargets = this.notHideTargets.some((notHideTarget) => notHideTarget.contains(e.target));
      if (target && target.contains(e.target) || this.menuLayer.$el.contains(e.target) || isClickNotHideTargets) {
        return;
      }
      this.hide();
    },
    _getTarget() {
      let target = this.target;
      if (typeof target === "string" && this.$vnode) {
        target = $.makeArray(this.$vnode.context.$refs[target])[0];
      }
      const Vue = this.constructor.super;
      if (target instanceof Vue) {
        target = target.$el;
      }
      return target instanceof window.Element ? target : null;
    },
    loadNewOptions() {
      this.destroy();
      this._initMenu();
      this._bindEvent();
    },
    setRootMenu(menu) {
      this.rootMenu = menu;
    },
    insertSubMenu(menu) {
      this.subMenuList.push(menu);
    },
    calClientRect() {
      this.menuLayer.width = this._getMenuWidth();
      this.menuLayer.height = this._getMenuHeight();
      this.$nextTick(() => {
        this.menuScroll.update();
      });
    },
    onClickFn(e, menuItem) {
      e.stopPropagation();
      e.preventDefault();
      const data = menuItem.data;
      if (data.disabled) {
        return;
      }
      if (typeof data.click === "function") {
        data.click(e, menuItem, data);
      }
    },
    hideAllMenu() {
      let menu = this;
      while (menu) {
        menu.hide();
        menu = menu.rootMenu;
      }
    },
    _getMountedTarget(left, top) {
      const el = document.body;
      const elPos = el.getBoundingClientRect();
      left = left - elPos.left;
      top = top - elPos.top;
      if (this._mountedTarget) {
        this._mountedTarget.style.left = `${left}px`;
        this._mountedTarget.style.top = `${top}px`;
        return this._mountedTarget;
      }
      this._mountedTarget = document.createElement("div");
      this._mountedTarget.className = "layer-target-node";
      this._mountedTarget.style.position = "absolute";
      this._mountedTarget.style.width = 0;
      this._mountedTarget.style.height = 0;
      this._mountedTarget.style.left = `${left}px`;
      this._mountedTarget.style.top = `${top}px`;
      el.appendChild(this._mountedTarget);
      return this._mountedTarget;
    },
    showAt(x, y) {
      if (arguments.length === 1) {
        if (Array.isArray(x)) {
          y = x[1];
          x = x[0];
        } else if (typeof x === "object") {
          y = x.y;
          x = x.x;
        } else {
          return;
        }
      }
      const target = this._getMountedTarget(x, y);
      this.showTo(target, true);
    },
    showTo(target, forceUpdate = false) {
      if (!forceUpdate && this.target === target) {
        return;
      }
      const showToTarget = () => {
        this.setTarget(target);
        this.show();
      };
      if (this.hidden) {
        showToTarget();
      } else {
        this.hide(() => {
          showToTarget();
        });
      }
    },
    alignTo(target) {
      this.target = target;
      this.menuLayer.alignTo(target);
    },
    setTarget(target) {
      if (this.target) {
        off(this.target, "click", this.toggle);
      }
      this.alignTo(target);
      on(this.target, "click", this.toggle);
    },
    toggle() {
      const target = this._getTarget();
      const isDisabledButton = target.classList.contains("el-button") && target.classList.contains("is-disabled");
      if (isDisabledButton) {
        return;
      }
      if (this.hidden) {
        this.show();
      } else {
        this.hide();
      }
    },
    setTargetActive(isActive) {
      if (!this.target) {
        return;
      }
      $(this.target).toggleClass("is-active", !!isActive);
    },
    show(callback) {
      const beforeShow = () => {
        this.setTargetActive(true);
        this.menuLayer.$off("before-show", beforeShow);
      };
      this.$emit("before-show", this.target);
      this.menuLayer.$on("before-show", beforeShow);
      this.hidden = false;
      this.menuLayer.hidden = false;
      const afterShow = () => {
        this.$emit("after-show");
        this.menuLayer.$off("after-show", afterShow);
        if (typeof callback === "function") {
          callback();
        }
      };
      this.menuLayer.$on("after-show", afterShow);
      this.$nextTick(() => {
        this.calClientRect();
      });
      return this;
    },
    hide(callback) {
      if (this.hidden && this.menuLayer.hidden) {
        return;
      }
      const beforeHide = () => {
        this.$emit("before-hide");
        this.setTargetActive(false);
        this.menuLayer.$off("before-hide", beforeHide);
      };
      this.menuLayer.$on("before-hide", beforeHide);
      this.hidden = true;
      this.menuLayer.hidden = true;
      const afterHide = () => {
        this.$emit("after-hide");
        this.menuLayer.$off("after-hide", afterHide);
        if (typeof callback === "function") {
          callback();
        }
      };
      this.menuLayer.$on("after-hide", afterHide);
      if (this.subMenu) {
        this.subMenu.hide();
      }
      return this;
    },
    getMenuItem: function(needSubMenu) {
      const currentItem = this.$children[0].$children[0].$children || [];
      let subMenuItem = [];
      if (this.subMenuList.length && needSubMenu !== false) {
        this.subMenuList.forEach(function(subMenu) {
          subMenuItem = subMenuItem.concat(subMenu.getMenuItem(needSubMenu));
        });
        return currentItem.concat(subMenuItem);
      }
      return currentItem;
    },
    destroy() {
      this._unbindEvent();
      this.subMenu = null;
      this.subMenuList.forEach((subMenu) => {
        subMenu.destroy();
      });
      this.subMenuList.length = 0;
    },
    getPrefixedClassName
  }
};
SfMenu.components = {
  SfScrollbar,
  SfLayer,
  SfMenuItem: __vue_component__$1,
  SfMenu
};
const __vue_script__ = SfMenu;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "sf-layer",
    {
      ref: "menuLayer",
      class: [
        _vm.getPrefixedClassName("sf-menu-layer"),
        _vm.getPrefixedClassName("sf-menu-wrapper"),
        _vm.size === "small" ? _vm.getPrefixedClassName("sf-menu-layer--small") : ""
      ],
      attrs: {
        options: _vm.layerOpt,
        anchor: _vm.anchor,
        "append-to-body": _vm.appendToBody,
        "auto-scrollbar": false
      }
    },
    [
      _c(
        "sf-scrollbar",
        {
          ref: "menuScroll",
          class: _vm.getPrefixedClassName("sf-menu-scroll"),
          attrs: { rootMenu: _vm._self, "auto-width": true }
        },
        [
          _vm.optionsList.length ? _c(
            "ul",
            {
              ref: "menuList",
              class: _vm.getPrefixedClassName("sf-menu-list")
            },
            _vm._l(_vm.optionsList, function(item, index) {
              return _c(
                "sf-menu-item",
                {
                  key: index,
                  attrs: {
                    type: item.type,
                    icon: item.icon,
                    "default-disabled": item.disabled,
                    "default-hidden": item.hidden,
                    "hide-group-icon": item.hideGroupIcon,
                    data: item
                  },
                  on: { click: _vm.onClickFn }
                },
                [
                  _c("span", {
                    domProps: { innerHTML: _vm._s(_vm._renderText(item)) }
                  }),
                  _vm._v(" "),
                  item.children && item.children.length ? _c(
                    "sf-menu",
                    _vm._g(
                      {
                        attrs: {
                          anchor: "right-start",
                          "default-width": _vm.width,
                          options: item.children,
                          renderer: _vm._getRendererFn()
                        }
                      },
                      _vm.$listeners
                    )
                  ) : _vm._e()
                ],
                1
              );
            }),
            1
          ) : _c(
            "ul",
            {
              ref: "menuList",
              class: _vm.getPrefixedClassName("sf-menu-list")
            },
            [_vm._t("default")],
            2
          )
        ]
      )
    ],
    1
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__ as SfMenu, __vue_component__$1 as SfMenuItem };
