import type { SfMenuOptions } from './menu';
import type { VNode } from 'vue';

export interface SfMenuItemProps {
  /**
   * 子菜单项的配置
   */
  data: SfMenuOptions;
  /**
   * 设置当前子菜单项的图标class
   */
  icon: string;
  /**
   * 若值设置为separator，则显示为分割符
   */
  type: '' | 'separator';
  /**
   * 点击当前菜单项时，想要触发的父类的事件
   */
  actionName: string;
  /**
   * 显示标题
   */
  title: string;
  /**
   * 点击此子项，是否隐藏整个菜单
   *
   * @default true
   */
  hideParent: boolean;
}

export interface SfMenuItemSlots {
  $slots: {
    default?: VNode[];
  };
}

export interface SfMenuItemEvents {
  /**
   * 点击菜单项触发的事件
   *
   * @param e 事件对象
   * @param menuItem 菜单项
   */
  $emit(eventName: 'click', e: MouseEvent, menuItem: SfMenuItem): this;
  /**
   * 点击菜单项触发的事件
   *
   * @param e 事件对象
   * @param menuItem 菜单项
   */
  $emit(eventName: 'action', e: MouseEvent, menuItem: SfMenuItem): this;
}

export interface SfMenuItemMethods {
  /**
   * 使用props配置title时，不要使用此方法更新title！
   *
   * @param title
   */
  updateTitle(title: string): void;
}

export type SfMenuItem = Readonly<SfMenuItemProps & SfMenuItemSlots & SfMenuItemEvents & SfMenuItemMethods> & Vue;
