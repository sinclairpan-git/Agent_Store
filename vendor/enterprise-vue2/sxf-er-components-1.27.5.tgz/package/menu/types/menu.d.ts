import type { SfMenuItem } from './menuItem';
import type { VNode } from 'vue';

export interface SfMenuOptions {
  icon?: string;
  type?: string;
  label?: string;
  disabled?: boolean;
  hidden?: false;
  children?: SfMenuOptions;
  click?: Function;
}

export type SfMenuAnchor =
  | 'top'
  | 'bottom'
  | 'left'
  | 'right'
  | 'top-start'
  | 'top-end'
  | 'bottom-start'
  | 'bottom-end'
  | 'left-start'
  | 'left-end'
  | 'right-start'
  | 'right-end';

export interface SfMenuProps {
  options: SfMenuOptions[];
  defaultTarget: string | Element;
  notHideTargets: Element[];
  renderer: string | { (label: string, data: SfMenuItem): string };
  clickHide: boolean;
  anchor: SfMenuAnchor;
  trigger: 'click' | 'hover';
}

export interface SfMenuSlots {
  $slots: {
    default?: VNode[];
  };
}

export interface SfMenuEvents {
  $emit(eventName: 'click-item', event: MouseEvent, menuItem: SfMenuItem): this;
  $emit(eventName: 'before-show', event: MouseEvent): this;
  $emit(eventName: 'after-show'): this;
  $emit(eventName: 'before-hide'): this;
  $emit(eventName: 'after-hide'): this;
}

export interface SfMenuMethods {
  loadNewOptions: () => void;
  setRootMenu: () => void;
  insertSubMenu: (menu: SfMenuItem) => void;
  calClientRect: () => void;
  hideAllMenu: () => void;
  showAt: (x: number | string, y: number | string) => void;
  showTo: (target: Element, forceUpdate?: boolean) => void;
  alignTo: (target: Element) => void;
  setTarget: (target: Element) => void;
  toggle: () => void;
  show: (callback?: Function) => void;
  hide: (callback?: Function) => void;
  getMenuItem: (needSubMenu?: boolean) => SfMenuItem[];
  destroy: () => void;
}

export type SfMenu = Readonly<SfMenuProps & SfMenuSlots & SfMenuEvents & SfMenuMethods> & Vue;
