import $ from 'jquery';
import { SfTreeHeader } from '@sxf/er-components/tree';
import { componentName } from '@sxf/er-components/_const';
import { isPropEnabled } from '@sxf/er-components/_utils/vue-utils';
import { FormFieldMixin, FormSizeMixin } from '@sxf/er-components/form';
import { $i } from '@sxf/er-config';
import logger from '@sxf/er-utils/logger';
import { fixtreeselect, listeners } from '@sxf/er-widget/treeSelect';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
import { SfCombo, SfComboColumn } from '@sxf/er-components/combo';
import { getPrefixedClassName } from '@sxf/er-feature';
import { getTreeDefaultConfig } from '@sxf/er-widget/tree';
const treeSelectLogger = logger("treeSelect");
const toSafeEventName = function(name) {
  return String(name || "").replace(/^\.+|\.+$/g, "").replace(/\.+/g, "-");
};
var script$1 = {
  name: componentName.treeSelect,
  componentName: componentName.treeSelect,
  mixins: [FormFieldMixin, FormSizeMixin],
  props: {
    name: true,
    options: true,
    defaultTreeCfg: {
      type: Object,
      default: () => ({
        treeBgTheme: "bright-theme"
      })
    },
    value: true,
    disabled: true,
    placeholder: true,
    size: String
  },
  computed: {
    disabledStatus() {
      return isPropEnabled(this.disabled);
    }
  },
  watch: {
    value(value) {
      this._triggerAction("value", [value]);
    },
    disabledStatus(disabled) {
      this._triggerAction(disabled ? "disable" : "enable");
      if (disabled) {
        this.setValidateState(true);
      }
    },
    options() {
      this.redraw();
    }
  },
  mounted() {
    this.$select = $(this.$refs.select);
    this.__init();
    if (this.disabledStatus) {
      this._triggerAction("disable");
    }
  },
  beforeDestroy() {
    this.invokeSelect("destroy");
  },
  methods: {
    invokeSelect(...args) {
      return fixtreeselect.call(this.$select, ...args);
    },
    redraw() {
      this.invokeSelect("destroy");
      this.__init();
    },
    getOption() {
      return this._triggerAction("option", arguments);
    },
    getData() {
      return [].map.call(this._triggerAction("value"), (node) => {
        return node;
      });
    },
    setData(data) {
      if (!data || !data.length || data.length < 1) {
        treeSelectLogger.error($i("scp.vt_component.sf_widget.packages.tree_select.tree_select.cannot_clear_err_msg"));
        return;
      }
      this._triggerAction("value", arguments);
    },
    getValue() {
      const tree = this.getOption()[0].tree;
      return this.getData().map((node) => {
        return tree && tree.getNodeId(node);
      });
    },
    setValue(value) {
      this.setData(value);
    },
    load() {
      return this._triggerAction("load", arguments);
    },
    reset(force) {
      this._triggerAction("abort");
      if (!force && this.options && this.options.autoSelect) {
        this.selectfirst();
        return;
      }
      this._triggerAction("value", "");
      this.setValidateState(true);
    },
    selectfirst() {
      return this._triggerAction("selectfirst", arguments);
    },
    triggerAction(...args) {
      const action = args[0];
      if (["enable", "disable"].indexOf(action) >= 0) {
        throw new Error('Use "disabled" props instead.');
      }
      return this.invokeSelect(...args);
    },
    __init() {
      const options = $.extend(true, {}, { treeCfg: this.defaultTreeCfg }, this.options);
      options.resizeWidth = true;
      options.wrap = this.$el;
      options.size = this.currentSize;
      if (options.listeners) {
        throw new Error(`"options.listeners" is not allowed, use Vue's event binding instead.`);
      }
      if (options.value) {
        throw new Error('use "v-model" instead.');
      }
      options.value = this.value;
      options.listeners = this._initListeners();
      if (!options.listParent && options.listParent !== false) {
        options.listParent = function(wrap) {
          const $parent = wrap.closest(".sf-popover-vtip");
          if ($parent.size()) {
            return $parent;
          }
          return $("body");
        };
      }
      this.invokeSelect(options);
    },
    _triggerAction(actionName, args) {
      return this.invokeSelect(...[actionName, ...$.makeArray(args)]);
    },
    _initListeners() {
      const vm = this;
      return Object.keys(listeners).reduce((map, name) => {
        const safeName = toSafeEventName(name);
        map[name] = function() {
          const args = $.makeArray(arguments).slice(1);
          vm.$emit(safeName, ...args);
          if (safeName === "change") {
            const tree = vm.getOption()[0].tree;
            vm.$emit("input", args[0].data && tree.getNodeId(args[0].data));
            vm.validate();
          }
        };
        return map;
      }, {});
    },
    processRule(rule) {
      rule.getFieldValue = () => {
        return String(this.getValue());
      };
      return rule;
    },
    bindInvalidCls(invalidCls, toggle) {
      if (toggle) {
        this.$select.addClass(invalidCls);
      } else {
        this.$select.removeClass(invalidCls);
      }
    },
    bindValidateHintOptions(hintOptions) {
      this.$select.attr(hintOptions);
    },
    handleBlur() {
      this.validate();
    },
    checkIsDisabled() {
      return this.disabledStatus;
    },
    onValidate(ret) {
      this.setValidateState(ret);
    }
  }
};
const __vue_script__$1 = script$1;
var __vue_render__$1 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c("div", [
    _c("input", {
      ref: "select",
      attrs: {
        id: _vm.fieldSelectorID,
        "style-key": "input",
        name: _vm.name,
        placeholder: _vm.placeholder
      },
      on: { blur: _vm.handleBlur }
    })
  ]);
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
const TREE_SELECT_METHODS = Object.keys(__vue_component__$1.methods);
var script = {
  name: componentName.treeTableSelect,
  componentName: componentName.treeTableSelect,
  components: {
    SfTreeHeader,
    SfCombo,
    SfComboColumn
  },
  props: {
    value: {
      type: String
    },
    options: {
      type: Object,
      default: () => ({})
    },
    disabled: {
      type: Boolean,
      default: false
    },
    placeholder: {
      type: String,
      default: ""
    },
    defaultTreeCfg: {
      type: Object,
      default: () => ({})
    },
    allowBlank: {
      type: Boolean,
      default: true
    },
    dataKey: {
      type: String,
      default: ""
    },
    size: {
      type: String,
      default: "normal"
    },
    multiSelect: {
      type: Boolean,
      default: false
    },
    multiTipFn: {
      type: Function,
      default: () => ""
    }
  },
  data() {
    return {
      treeSelectOptions: this.transformTreeSelectOptions()
    };
  },
  computed: {
    treeOptions() {
      return this.treeSelectOptions.treeCfg || {};
    },
    autoSelect() {
      return !!this.treeSelectOptions.autoSelect;
    },
    autoExpandAll() {
      return this.treeOptions.autoExpandAll;
    },
    displayField() {
      return this.treeSelectOptions.displayField;
    },
    needHeader() {
      return this.treeOptions.needHeader;
    },
    searchString() {
      return this.treeOptions.searchString;
    },
    treeSelectField() {
      return this.treeOptions.treeField || this.treeOptions.nameField;
    },
    comboStyle() {
      return {
        width: typeof this.treeSelectOptions.width === "number" ? this.treeSelectOptions.width + "px" : this.treeSelectOptions.width
      };
    },
    multiCls() {
      return this.multiSelect ? getPrefixedClassName("sf-tree-table-select__multi") : "";
    },
    selectionPlugin() {
      if (this.multiSelect) {
        return {
          pluginID: "CheckSelection",
          checkboxInTreeField: true,
          tipFn: (record) => {
            if (!this.multiTipFn) {
              return "";
            }
            return this.multiTipFn(record);
          }
        };
      }
      return {
        pluginID: "RadioSelection",
        hideRadio: true,
        silentSelect: true
      };
    },
    comboOptions() {
      return {
        noColumnHeader: true,
        rowHeight: 32,
        colBorder: false,
        minRows: 1,
        maxRows: 10,
        store: {
          idProperty: "path",
          ...this.treeSelectOptions.ajax ? { ajax: this.treeSelectOptions.ajax } : {}
        },
        ...this.treeSelectOptions,
        cls: [
          getPrefixedClassName("sf-tree-table-select__list"),
          getPrefixedClassName("sf-tree-table"),
          this.treeSelectOptions.cls,
          this.multiCls
        ].join(" "),
        width: this.treeSelectOptions.listWidth,
        height: this.parseHeight(this.treeOptions.treeHeight),
        minHeight: this.parseHeight(this.treeOptions.treeMinHeight),
        maxHeight: this.parseHeight(this.treeOptions.treeMaxHeight),
        plugins: [
          this.selectionPlugin,
          {
            pluginID: "Tree",
            needRoot: this.treeOptions.showRoot,
            rootText: this.treeOptions.rootInfo.name,
            multiRoot: true,
            radioCanSelectGroup: true,
            hiddenIcon: true,
            autoScrollX: true,
            hideCheckbox: this.multiSelect,
            search: {
              includeGroup: true
            },
            selectAbleFn: (record) => {
              const disabled = typeof this.treeOptions.disableCheckFn === "function" ? this.treeOptions.disableCheckFn(record.data) : false;
              const unselectable = typeof this.treeOptions.unselectableCheckFn === "function" ? this.treeOptions.unselectableCheckFn(record.data) : false;
              return !disabled && !unselectable;
            },
            ...this.treeOptions
          }
        ]
      };
    }
  },
  watch: {
    value(val) {
      this.getCombo().setValue(val);
    }
  },
  mounted() {
    if (this.needHeader) {
      this.setTreeTarget();
    }
  },
  methods: {
    handleValue(selectData) {
      if (this.multiSelect) {
        this.$emit("change", selectData.data);
        return;
      }
      this.$emit("change", { data: selectData.data[0] });
    },
    handleExpand() {
      this.$emit("list-show");
    },
    handleCollapse() {
      this.$emit("list-hide");
    },
    getCombo() {
      return this.$refs.combo;
    },
    getTree() {
      return this.getCombo().getPlugin("Tree");
    },
    setTreeTarget() {
      const tree = this.getTree();
      this.$refs.treeHeader.setTarget(tree);
    },
    transformTreeSelectOptions() {
      const options = {
        displayField: "__namePath",
        ...this.options,
        treeCfg: {
          ...getTreeDefaultConfig(),
          ...this.defaultTreeCfg,
          ...this.options.treeCfg || {}
        }
      };
      if (typeof options.treeCfg.renNameFn !== "undefined") {
        options.treeCfg.renderer = function(name, record) {
          return options.treeCfg.renNameFn.call(this, name, record.data);
        };
      }
      if (typeof options.treeCfg.renNameFn !== "undefined") {
        options.treeCfg.renderer = function(name, record) {
          return options.treeCfg.renNameFn.call(this, name, record.data);
        };
      }
      return options;
    },
    processData({ data }) {
      return this.treeSelectOptions.processData(data);
    },
    groupIconCls(record) {
      return typeof this.treeOptions.groupIconCls === "function" ? this.treeOptions.groupIconCls(record == null ? void 0 : record.data) : this.treeOptions.groupIconCls;
    },
    nodeIconCls(record) {
      return typeof this.treeOptions.nodeIconCls === "function" ? this.treeOptions.nodeIconCls(record == null ? void 0 : record.data) : this.treeOptions.nodeIconCls;
    },
    parseHeight(height) {
      return typeof height === "string" && /^\d+px$/.test(height) ? parseInt(height, 10) : height;
    },
    ...TREE_SELECT_METHODS.reduce((methods, fnName) => {
      methods[fnName] = function() {
        const combo = this.getCombo();
        return combo[fnName].apply(combo, arguments);
      };
      return methods;
    }, {}),
    scrollToNode(nodeId) {
      this.getTree().expandAll();
      const start = this.getTree().grid.store.dataList.findIndex((id) => id === nodeId);
      this.getTree().grid.renderView(start);
    },
    handleViewReady() {
      var _a;
      (_a = this.getCombo()) == null ? void 0 : _a.updateListElPosition();
    },
    getPrefixedClassName
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "sf-combo",
    {
      ref: "combo",
      class: _vm.getPrefixedClassName("sf-tree-table-select"),
      style: _vm.comboStyle,
      attrs: {
        options: _vm.comboOptions,
        "auto-select-first": _vm.autoSelect,
        disabled: _vm.disabled,
        "process-data": _vm.treeSelectOptions.processData && _vm.processData,
        placeholder: _vm.placeholder,
        "allow-blank": _vm.allowBlank,
        "data-key": _vm.dataKey,
        "display-field": _vm.displayField,
        size: _vm.size
      },
      on: {
        value: _vm.handleValue,
        expand: _vm.handleExpand,
        collapse: _vm.handleCollapse,
        viewready: _vm.handleViewReady
      }
    },
    [
      _vm.needHeader ? _c("sf-tree-header", {
        ref: "treeHeader",
        attrs: {
          slot: "header",
          "lazy-search": true,
          placeholder: _vm.searchString,
          "auto-expand-all": _vm.autoExpandAll
        },
        slot: "header"
      }) : _vm._e(),
      _vm._v(" "),
      _c("sf-combo-column", {
        attrs: {
          field: _vm.treeSelectField,
          tip: "auto",
          "group-icon-cls": _vm.groupIconCls,
          "icon-cls": _vm.nodeIconCls,
          width: "100%",
          "is-auto-fit-width": true
        }
      })
    ],
    1
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__$1 as SfTreeSelect, __vue_component__ as SfTreeTableSelect };
