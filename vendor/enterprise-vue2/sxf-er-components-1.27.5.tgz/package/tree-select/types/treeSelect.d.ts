import type { SfFormFieldMixin } from '@sxf/er-components/form/types';
import type { SfSelectOptions } from '@sxf/er-components/select/types';

interface DefaultTreeCfg {
  treeDottedStyle?: boolean;
}

export interface SfTreeSelectProps {
  name: string;
  options: SfSelectOptions;
  defaultTreeCfg: DefaultTreeCfg;
  value: string;
  disabled: boolean;
  placeholder: string;
}

export interface SfTreeSelectMethods {
  redraw: () => void;
  getOption: () => JQuery;
  getData: () => any[];
  setData: (data?: string) => void;
  getValue: () => string[];
  setValue: (value: string) => void;
  load: () => void;
  reset: () => void;
  selectfirst: () => void;
  triggerAction: (action: string) => this;
}

export declare type SfTreeSelect = Readonly<SfTreeSelectProps & SfTreeSelectMethods & SfFormFieldMixin> & Vue;
