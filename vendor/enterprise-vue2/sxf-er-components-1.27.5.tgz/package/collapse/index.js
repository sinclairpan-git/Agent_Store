import { componentName } from '@sxf/er-components/_const';
import { getPrefixedClassName } from '@sxf/er-feature';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
import { EmitterMixin } from '@sxf/er-components/_mixins';
import uuid from '@sxf/er-utils/uuid';
import { addClass, removeClass } from '@sxf/er-utils/dom';
var script$1 = {
  name: componentName.collapse,
  componentName: componentName.collapse,
  provide() {
    return {
      collapse: this
    };
  },
  props: {
    accordion: Boolean,
    value: {
      type: [Array, String, Number],
      default() {
        return [];
      }
    },
    size: {
      default: "normal",
      validator(value) {
        return ["normal", "large"].includes(value);
      }
    },
    bordered: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      activeNames: [].concat(this.value)
    };
  },
  computed: {
    collapseSizeCls() {
      return getPrefixedClassName(`el-collapse--${this.size}`);
    },
    collapseBorderCls() {
      return this.bordered ? `${getPrefixedClassName("el-collapse--bordered")}` : "";
    },
    collapseCls() {
      return [getPrefixedClassName("el-collapse"), this.collapseSizeCls, this.collapseBorderCls];
    }
  },
  watch: {
    value(value) {
      this.activeNames = [].concat(value);
    }
  },
  created() {
    this.$on("item-click", this.handleItemClick);
  },
  methods: {
    setActiveNames(activeNames) {
      activeNames = [].concat(activeNames);
      const value = this.accordion ? activeNames[0] : activeNames;
      this.activeNames = activeNames;
      this.$emit("input", value);
      this.$emit("change", value);
    },
    handleItemClick(item) {
      if (this.accordion) {
        const isActived = this.activeNames[0] === item.name;
        this.setActiveNames(isActived ? "" : item.name);
      } else {
        const activeNames = this.activeNames.slice(0);
        const index = activeNames.indexOf(item.name);
        if (index > -1) {
          activeNames.splice(index, 1);
        } else {
          activeNames.push(item.name);
        }
        this.setActiveNames(activeNames);
      }
    }
  }
};
const __vue_script__$1 = script$1;
var __vue_render__$1 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      class: _vm.collapseCls,
      attrs: { role: "tablist", "aria-multiselectable": "true" }
    },
    [_vm._t("default")],
    2
  );
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
class Transition {
  constructor() {
    this.beforeEnter = this.beforeEnter.bind(this);
    this.enter = this.enter.bind(this);
    this.afterEnter = this.afterEnter.bind(this);
    this.beforeLeave = this.beforeLeave.bind(this);
    this.leave = this.leave.bind(this);
    this.afterLeave = this.afterLeave.bind(this);
  }
  beforeEnter(el) {
    addClass(el, "collapse-transition");
    if (!el.dataset) {
      el.dataset = {};
    }
    el.dataset.oldPaddingTop = el.style.paddingTop;
    el.dataset.oldPaddingBottom = el.style.paddingBottom;
    el.style.height = "0";
    el.style.paddingTop = 0;
    el.style.paddingBottom = 0;
  }
  enter(el) {
    el.dataset.oldOverflow = el.style.overflow;
    if (el.scrollHeight !== 0) {
      el.style.height = el.scrollHeight + "px";
      el.style.paddingTop = el.dataset.oldPaddingTop;
      el.style.paddingBottom = el.dataset.oldPaddingBottom;
    } else {
      el.style.height = "";
      el.style.paddingTop = el.dataset.oldPaddingTop;
      el.style.paddingBottom = el.dataset.oldPaddingBottom;
    }
    el.style.overflow = "hidden";
  }
  afterEnter(el) {
    removeClass(el, "collapse-transition");
    el.style.height = "";
    el.style.overflow = el.dataset.oldOverflow;
  }
  beforeLeave(el) {
    if (!el.dataset) {
      el.dataset = {};
    }
    el.dataset.oldPaddingTop = el.style.paddingTop;
    el.dataset.oldPaddingBottom = el.style.paddingBottom;
    el.dataset.oldOverflow = el.style.overflow;
    el.style.height = el.scrollHeight + "px";
    el.style.overflow = "hidden";
  }
  leave(el) {
    if (el.scrollHeight !== 0) {
      addClass(el, "collapse-transition");
      el.style.height = 0;
      el.style.paddingTop = 0;
      el.style.paddingBottom = 0;
    }
  }
  afterLeave(el) {
    removeClass(el, "collapse-transition");
    el.style.height = "";
    el.style.overflow = el.dataset.oldOverflow;
    el.style.paddingTop = el.dataset.oldPaddingTop;
    el.style.paddingBottom = el.dataset.oldPaddingBottom;
  }
}
var SfCollapseTransition = {
  name: componentName.collapseTransition,
  componentName: componentName.collapseTransition,
  functional: true,
  render(h, { children }) {
    const data = {
      on: new Transition()
    };
    return h("transition", data, children);
  }
};
var script = {
  name: componentName.collapseItem,
  componentName: componentName.collapseItem,
  components: { SfCollapseTransition },
  mixins: [EmitterMixin],
  inject: ["collapse"],
  props: {
    title: String,
    name: {
      type: [String, Number],
      default() {
        return this._uid;
      }
    }
  },
  data() {
    return {
      contentWrapStyle: {
        height: "auto",
        display: "block"
      },
      contentHeight: 0,
      focusing: false,
      isClick: false
    };
  },
  computed: {
    isActive() {
      return this.collapse.activeNames.indexOf(this.name) > -1;
    },
    id() {
      return uuid();
    },
    headerId() {
      return `el-collapse-head-${this.id}`;
    },
    contentId() {
      return `el-collapse-content-${this.id}`;
    }
  },
  methods: {
    handleHeaderClick() {
      this.dispatch(componentName.collapse, "item-click", this);
      this.focusing = false;
      this.isClick = true;
    },
    getPrefixedClassName
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _obj, _obj$1, _obj$2;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      class: [
        _vm.getPrefixedClassName("el-collapse-item"),
        (_obj = {}, _obj[_vm.getPrefixedClassName("is-active")] = _vm.isActive, _obj)
      ]
    },
    [
      _c(
        "div",
        {
          class: _vm.getPrefixedClassName("el-collapse-item__header-wrapper"),
          attrs: {
            role: "tab",
            "aria-expanded": _vm.isActive,
            "aria-controls": _vm.contentId,
            "aria-describedby": _vm.contentId
          },
          on: { click: _vm.handleHeaderClick }
        },
        [
          _vm._t(
            "header",
            [
              _c(
                "div",
                {
                  class: [
                    _vm.getPrefixedClassName("el-collapse-item__header"),
                    (_obj$1 = {}, _obj$1[_vm.getPrefixedClassName("focusing")] = _vm.focusing, _obj$1[_vm.getPrefixedClassName("is-active")] = _vm.isActive, _obj$1)
                  ],
                  attrs: { id: _vm.headerId, role: "button", tabindex: "0" }
                },
                [
                  _c(
                    "div",
                    {
                      class: _vm.getPrefixedClassName(
                        "el-collapse-item__header-title"
                      )
                    },
                    [_vm._t("title", [_vm._v(_vm._s(_vm.title))])],
                    2
                  ),
                  _vm._v(" "),
                  _c("i", {
                    class: [
                      _vm.getPrefixedClassName("el-collapse-item__arrow"),
                      "iconfont vtv-icon-next-month",
                      (_obj$2 = {}, _obj$2[_vm.getPrefixedClassName("is-active")] = _vm.isActive, _obj$2)
                    ]
                  })
                ]
              )
            ],
            { expanded: _vm.isActive }
          )
        ],
        2
      ),
      _vm._v(" "),
      _c("sf-collapse-transition", [
        _c(
          "div",
          {
            directives: [
              {
                name: "show",
                rawName: "v-show",
                value: _vm.isActive,
                expression: "isActive"
              }
            ],
            class: _vm.getPrefixedClassName("el-collapse-item__wrap"),
            attrs: {
              id: _vm.contentId,
              role: "tabpanel",
              "aria-hidden": !_vm.isActive,
              "aria-labelledby": _vm.headerId
            }
          },
          [
            _c(
              "div",
              { class: _vm.getPrefixedClassName("el-collapse-item__content") },
              [_vm._t("default")],
              2
            )
          ]
        )
      ])
    ],
    1
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__$1 as SfCollapse, __vue_component__ as SfCollapseItem, SfCollapseTransition };
