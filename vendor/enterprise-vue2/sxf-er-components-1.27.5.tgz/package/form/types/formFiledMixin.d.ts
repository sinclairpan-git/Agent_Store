interface FormRule {
  selector: string;
  rule: {
    label: string;
    type: string;
    noValidate: boolean;
    validator: Function;
    cb: Function;
  };
}

export interface SfFormFieldMixinProps {
  /**
   * id标识，在form组件中可通过该标识验证组件，获取数据时以该id作为返回值的key
   * 未配置则自动生成
   *
   * @default uuid()
   */
  id?: string;

  /**
   * getData返回数据的key值，默认是id标识，如果是false则不获取数据
   */
  dataKey?: string;

  /**
   * vtype验证规则
   */
  validateType?: string;

  allowBlank?: boolean;

  allDecimals?: boolean;

  maxline?: number;

  visitor?: Object;

  mask?: RegExp;

  errText?: string;

  maxLength?: number;

  minLength?: number;

  minCharType?: Object;

  minCharTypeCount?: number;

  maxValue?: number;

  maxValueText?: string;

  minValue?: number;

  minValueText?: string;

  event?: string;

  validator?: Function;

  blankText?: string;

  label?: string;

  cb?: Function;

  check?: string | Object;

  withSubnet?: boolean;

  netmask?: string;

  netprefix?: number;

  isDecimal?: boolean;

  autoTrim?: boolean;

  /**
   * 校验输入长度的时候不校验中文
   */
  withoutZh?: boolean;

  /**
   * 屏蔽所有验证（可以动态设置
   */
  noValidate?: boolean;

  /**
   * 当vtype的配置项被修改时是否自动重新验证
   *
   * @default true
   */
  validateOnVtypeConfigChange?: boolean;

  /**
   * 自定义的验证处理函数，设置错误显示效果，返回false则不设置默认的错误效果
   *
   * @default true
   */
  validateCallback?: () => boolean;

  /**
   * 重置text输入框的maxLength限制
   * 详见 packages/validator/validation-functions/text.js
   *
   * @default { maxLength: 255, useUTF8Len: true }
   */
  textOptions?: { maxLength: number; useUTF8Len: boolean };
}

export interface SfFormFieldMixinMethods {
  updateValidate(): void;

  checkValidateEnabled(enabled: boolean): boolean;

  /**
   * 获取vtype验证规则
   */
  getRule(): FormRule;

  processRule(rule: FormRule): FormRule;

  /**
   * 验证表单项是否有效
   *
   * @param {boolean} silent - 是否触发回调
   * @return {true | string[]} - 验证成功返回true，否则返回错误信息数组
   */
  validate(silent?: boolean): true | string[];

  /**
   * vtype验证回调，处理验证状态显示等，在表单实例中处理
   *
   * @param {boolean} ret
   * @param {object} options
   */
  onValidate(ret?: boolean, options?: Object): boolean;

  /**
   * 获取数据，一般是完整数据项
   */
  getData(): any;

  /**
   * 设置数据，一般是完整的数据项
   */
  setData(): void;

  /**
   * 获取组件的值，一般是idField对应的值
   */
  getValue(): any;

  /**
   * 根据组件的值，一般是idField对应的值
   */
  setValue(value: any): void;

  /**
   * 重置组件的值为初始值，用在表单项每次需要复位的情况
   */
  reset(): void;
}

export declare type SfFormFieldMixin = Readonly<SfFormFieldMixinProps & SfFormFieldMixinMethods> & Vue;
