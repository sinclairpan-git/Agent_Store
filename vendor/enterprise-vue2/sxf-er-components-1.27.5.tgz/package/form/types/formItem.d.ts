import { VNode } from 'vue';

export interface SfFormItemProps {
  size: string;
  /**
   * 标签文本
   *
   * @default ''
   */
  label: string;

  /**
   * 标签文本宽度
   */
  labelWidth: string;

  /**
   * 是否显示标签
   */
  showLabel: boolean | undefined;

  /**
   * 表单标签的flex布局align-items对齐方式
   */
  labelAlignItems: 'flex-start' | 'flex-end' | 'stretch' | 'center' | 'baseline';

  /**
   * 表单域内容的位置
   */
  contentPosition: 'right' | 'left' | 'top';

  /**
   * 是否存在表单域内容的间距
   */
  noItemContentPadding: boolean | undefined;

  /**
   * 是否必填，
   * 如不设置，则会根据校验规则自动生成
   */
  required: boolean;
}

export interface SfFormItemSlots {
  $slots: {
    label?: VNode[];
  };
}

export interface SfFormItemMethods {
  validate(): true | string[];
}

export declare type SfFormItem = Readonly<SfFormItemProps & SfFormItemSlots & SfFormItemMethods> & Vue;
