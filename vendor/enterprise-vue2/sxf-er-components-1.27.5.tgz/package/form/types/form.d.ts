import type { SfFormFieldMixin } from './formFiledMixin';

import { VNode } from 'vue';

export interface SfFormProps {
  size: string;
  /**
   * 表单数据对象
   */
  model: Record<string, any>;

  /**
   * 表单域标签的位置
   *
   * @default 'left'
   */
  labelPosition: 'left' | 'top';

  /**
   * 表单标签的flex布局align-items对齐方式
   */
  labelAlignItems: 'flex-start' | 'flex-end' | 'stretch' | 'center' | 'baseline';

  /**
   * 行内表单模式
   *
   * @default false
   */
  inline: boolean;

  /**
   * 表单域内容的位置
   */
  contentPosition: 'right' | 'left' | 'top';

  /**
   * 是否显示表单域的标签
   *
   * @default true
   */
  showLabel: boolean;

  /**
   * 表单域标签的宽度
   *
   * @default '76px'
   */
  labelWidth: string;

  /**
   * 表单域标签的后缀
   *
   * @default ''
   */
  labelSuffix: string;

  /**
   * 是否存在表单域标签的间距
   */
  noLabelPadding: boolean;

  /**
   * 是否存在表单域内容的间距
   *
   * @default true
   */
  noItemContentPadding: boolean;

  /**
   * 是否异步绑定vtype
   *
   * @default false
   */
  isAsyncBindVtype: boolean;

  /**
   * 是否阻止表单的enter键自动提交
   *
   * @default true
   */
  preventAutoSubmit: boolean;
}

export interface SfFormEvents {
  $emit: {
    focus: () => void;
  };
}

export interface SfFormMethods {
  /**
   * 验证表单是否正确
   *
   * @param {Boolean} silent - 是否触发回调
   * @return {true | string[]} - 验证成功返回true，否则返回错误信息数组
   */
  validate(silent?: boolean): true | string[];

  /**
   * 验证一个表单项是否正确
   *
   * @param {String | FormField} field
   * @param {Boolean} silent - 是否触发回调
   * @return {true | string[]} - 验证成功返回true，否则返回错误信息数组
   */
  validateField(field?: string | SfFormFieldMixin, silent?: boolean): true | string[];

  /**
   * 验证一行表单项是否正确
   *
   * @param {String | FormItem | String[] | FormItem[]} row
   * @param {Boolean} silent
   * @return {true | string[]}
   */
  validateRow(row?: string | string[], silent?: boolean): true | string[];

  /**
   * 获取表单完整数据，调用组件的getData方法获取数据
   *
   * @returns {object} ret
   */
  getData(): Record<string, any>;

  /**
   * 获取表单的数据，调用组件的getValue方法设置数据，一般是idField的集合
   *
   * @returns {object} ret
   */
  getValue(): Record<string, any>;

  /**
   * 设置表单的数据，调用组件的setValue方法设置数据
   *
   * @param {object} data 表单数据
   *
   * @returns {object} ret
   */
  setData(data?: Record<string, any>): Record<string, any>;

  getFieldData(fieldID?: string | number): Record<string, any>;

  /**
   * 重置表单项，设置为初始数据
   */
  reset(): void;

  /**
   * 通过ID获取表单项
   */
  getFieldByFieldID(fieldID: string): SfFormFieldMixin;

  /**
   * 通过ID获取表单值
   */
  getFieldValue(fieldID: string): Record<string, any>;
}

export interface SfFormSlots {
  $slots: {
    default: VNode[];
  };
}

export declare type SfForm = Readonly<SfFormProps & SfFormEvents & SfFormMethods & SfFormSlots> & Vue;
