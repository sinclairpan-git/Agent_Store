import $ from 'jquery';
import { componentName } from '@sxf/er-components/_const';
import { getVueParent } from '@sxf/er-components/_utils/vue-utils';
import { getPrefixedClassName } from '@sxf/er-feature';
import logger from '@sxf/er-utils/logger';
import textMetrics from '@sxf/er-utils/textMetrics';
import uuid from '@sxf/er-utils/uuid';
import { cascadeComponent } from '@sxf/er-utils/walk';
import { pureValidate } from '@sxf/er-validator';
import { AddComponentMixinEventName, FormTipMixin, EmitterMixin } from '@sxf/er-components/_mixins';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
import { $i } from '@sxf/er-config';
import { SfFlex, SfFlexItem } from '@sxf/er-components/flex';
import format from '@sxf/er-utils/format';
import { toggleTip } from '@sxf/er-widget/tooltip';
const formEvent = {
  addRow: "sf.form.addRow",
  removeRow: "sf.form.removeRow",
  addField: "sf.form.addField",
  removeField: "sf.form.removeField",
  updateValidate: "sf.form.updateValidate"
};
const formComponentName = {
  form: componentName.form,
  formItem: componentName.formItem,
  formCollapse: componentName.formCollapse
};
var formContainerMixin = {
  props: {
    limit: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      hasGridChildren: false
    };
  },
  computed: {
    isLimit() {
      return this.limit && !this.hasGridChildren;
    }
  },
  created() {
    this.$on(AddComponentMixinEventName, (comp) => {
      if (comp && comp.$options.componentName === "SfGrid") {
        this.hasGridChildren = true;
      }
    });
  }
};
const LABEL_SPACE = 4;
const formLogger$1 = logger(formComponentName.form);
var script$2 = {
  name: formComponentName.form,
  componentName: formComponentName.form,
  mixins: [formContainerMixin],
  props: {
    model: Object,
    labelPosition: {
      type: String,
      default: "left"
    },
    mode: {
      type: String,
      default: ""
    },
    labelAlignItems: String,
    contentPosition: String,
    labelWidth: String,
    labelSuffix: {
      type: String,
      default: ""
    },
    inline: Boolean,
    noLabelPadding: Boolean,
    showLabel: {
      type: Boolean,
      default: true
    },
    noItemContentPadding: {
      type: Boolean,
      default: true
    },
    preventAutoSubmit: {
      type: Boolean,
      default: true
    },
    padding: {
      type: Boolean,
      default: true
    },
    tipPadding: {
      type: Boolean,
      default: true
    },
    size: {
      type: String,
      default: ""
    },
    autoLabelWidth: {
      type: [Boolean, Object],
      default: () => ({
        includeNestedForm: false,
        group: false
      })
    },
    scene: {
      type: String,
      default: ""
    }
  },
  data() {
    return {
      validateEnabled: false,
      rules: {},
      fields: [],
      fieldMaps: {},
      rows: [],
      rowMaps: {},
      calcLabelWidth: 0,
      isFirstCalcWidth: true,
      inForm: false,
      parentForm: null,
      groupName: ""
    };
  },
  computed: {
    formCls() {
      const cls = {
        [getPrefixedClassName("el-form")]: true,
        [getPrefixedClassName("el-form--inline")]: this.inline,
        [getPrefixedClassName("el-form--limit")]: this.isLimit,
        [getPrefixedClassName("el-form--no-label-padding")]: this.noLabelPadding,
        [getPrefixedClassName("sfc-form-padding")]: this.padding && !this.inForm,
        [getPrefixedClassName("sfc-form-padding--small")]: this.padding && !this.inForm && this.size === "small",
        [getPrefixedClassName("el-form--inner-form")]: this.inForm,
        [getPrefixedClassName("el-form--has-tip")]: this.tipPadding && this.rows.some((item) => item.tip),
        [getPrefixedClassName("sfc-detail-form")]: this.mode === "detail"
      };
      if (this.labelPosition) {
        cls[getPrefixedClassName(`el-form--label-${this.labelPosition}`)] = true;
      }
      if (this.scene) {
        cls[getPrefixedClassName(`sfc-is-in-${this.scene}`)] = true;
      }
      return cls;
    },
    isLimit() {
      let limit = this.limit;
      if (this.parentForm) {
        const parentLimit = this.parentForm.isLimit;
        limit = parentLimit && this.limit;
      }
      return limit && !this.hasGridChildren;
    }
  },
  created() {
    this.$on(formEvent.addField, (field, row) => {
      if (!field) {
        return;
      }
      const rule = field.getRule();
      if (rule) {
        this.rules[rule.selector] = rule.rule;
        this.validateEnabled = true;
      }
      this.fields.push(field);
      this.fieldMaps[field.fieldID] = field;
      if (!row) {
        return;
      }
      if (!this.rowMaps[row.id]) {
        this.rowMaps[row.id] = row;
        row.fields = [];
      }
      this.rows.push(row);
      row.fields.push(field);
      if (!this.isFirstCalcWidth) {
        this.updateLabelWidth();
      }
    });
    this.$on(formEvent.removeField, (field, row) => {
      let index;
      delete this.rules[field.fieldSelector];
      delete this.fieldMaps[field.fieldID];
      index = this.fields.indexOf(field);
      if (index !== -1) {
        this.fields.splice(index, 1);
      }
      if (!row) {
        return;
      }
      index = row.fields.indexOf(field);
      if (index !== -1) {
        row.fields.splice(index, 1);
      }
      if (!row.fields.length) {
        delete this.rowMaps[row.id];
        index = this.rows.indexOf(row);
        if (index !== -1) {
          this.rows.splice(index, 1);
        }
      }
      if (!this.isFirstCalcWidth) {
        this.updateLabelWidth();
      }
    });
    this.$on(formEvent.updateValidate, (field, notValidate) => {
      const rule = field.getRule();
      this.rules[rule.selector] = rule.rule;
      if (field.validateOnVtypeConfigChange) {
        if (field.clearValidateState) {
          field.clearValidateState();
        } else {
          formLogger$1.error(`can not find method clearValidateState of ${field.$options.name}`);
        }
        if (!notValidate) {
          this.validateField(field);
        }
      }
    });
    const parent = getVueParent(this, [formComponentName.form, componentName.popover]);
    if (parent && parent.$options.componentName === formComponentName.form) {
      this.parentForm = parent;
      this.inForm = true;
    }
  },
  mounted() {
    if (this.preventAutoSubmit) {
      $(this.$refs.form).on("submit.prevent-auto-submit", (e) => {
        e.preventDefault();
      });
    }
    this.updateLabelWidth();
    this.isFirstCalcWidth = false;
  },
  beforeDestroy() {
    const $form = $(this.$refs.form);
    $form.off("submit.prevent-auto-submit");
  },
  destroyed() {
    this.rows = null;
    this.fields = null;
    this.rowMaps = null;
    this.fieldMaps = null;
    this.rules = null;
  },
  methods: {
    updateLabelWidth() {
      if (!this.autoLabelWidth) {
        return;
      }
      this.$nextTick(() => {
        this.resetLabelWidth();
      });
    },
    focus() {
      const field = this.fields.filter((child) => {
        return child.$options.componentName === componentName.input && !child.isDisabled && !child.isReadonly;
      })[0];
      if (field) {
        field.focus();
      }
    },
    validate(silent) {
      return pureValidate.validateAll(this.rules, silent);
    },
    validateField(field, silent) {
      if (field.constructor !== Array) {
        field = [field];
      }
      const validateCfg = field.reduce((config, item) => {
        if (typeof item === "string") {
          item = this.getFieldByFieldID(item);
        }
        const fieldSelector = item.fieldSelector;
        const rule = this.rules[fieldSelector];
        config[fieldSelector] = rule;
        return config;
      }, {});
      return pureValidate.validateAll(validateCfg, silent);
    },
    validateRow(row, silent) {
      let ret = [];
      if (row.constructor !== Array) {
        row = [row];
      }
      row = row.map((item) => {
        if (typeof item === "string") {
          return this.getRowByRowID(item);
        }
        return item;
      });
      row.forEach((item) => {
        const isValid = this.validateField(item.fields, silent);
        if (isValid !== true) {
          ret = ret.concat(isValid);
        }
      });
      return ret.length ? ret : true;
    },
    getRowByRowID(rowID) {
      return this.rowMaps[rowID];
    },
    getFieldByFieldID(fieldID) {
      return this.fieldMaps[fieldID];
    },
    getData() {
      const ret = {};
      this.fields.forEach((field) => {
        if (field.getData && field.dataKey !== false) {
          const value = field.getData();
          const id = field.dataKey || field.fieldID;
          ret[id] = value;
        }
      });
      return ret;
    },
    setData(data) {
      const ret = {};
      this.fields.forEach((field) => {
        if (field.setData && field.dataKey !== false) {
          const id = field.dataKey || field.fieldID;
          const value = data[id];
          if (typeof value !== "undefined") {
            field.setData(value);
          }
        }
      });
      return ret;
    },
    getValue() {
      const ret = {};
      this.fields.forEach((field) => {
        if (field.getValue && field.dataKey !== false) {
          const value = field.getValue();
          const id = field.dataKey || field.fieldID;
          ret[id] = value;
        }
      });
      return ret;
    },
    setValue(data) {
      const ret = {};
      this.fields.forEach((field) => {
        if (field.setValue) {
          const id = field.dataKey || field.fieldID;
          const value = data[id];
          if (typeof value !== "undefined") {
            field.setValue(value);
          }
        }
      });
      return ret;
    },
    getFieldData(fieldID) {
      const field = this.getFieldByFieldID(fieldID);
      if (field) {
        return field.getData();
      }
    },
    getFieldValue(fieldID) {
      const field = this.getFieldByFieldID(fieldID);
      if (field) {
        return field.getValue();
      }
    },
    reset() {
      this.fields.forEach((field) => {
        if (field.reset) {
          field.reset();
        }
      });
    },
    getSubmitData() {
      return this.getValue();
    },
    getRootForm(component) {
      function getOuterForm(comp) {
        var _a;
        if (((_a = comp.autoLabelWidth) == null ? void 0 : _a.group) || !(comp == null ? void 0 : comp.parentForm)) {
          return comp;
        }
        return getOuterForm(comp.parentForm);
      }
      return getOuterForm(component);
    },
    resetLabelWidth() {
      this.calcLabelWidth = 0;
      const dom = this.$el.querySelector(".el-form-item__label");
      const subForm = [];
      const rootForm = this.getRootForm(this);
      const includeNestedForm = typeof rootForm.autoLabelWidth === "object" ? !!rootForm.autoLabelWidth.includeNestedForm : false;
      if (rootForm.autoLabelWidth.group && !rootForm.groupName) {
        rootForm.groupName = uuid("group-");
      }
      this.$nextTick(() => {
        cascadeComponent(rootForm, (comp) => {
          var _a;
          const componentName2 = comp.$options.componentName;
          if ([formComponentName.form, formComponentName.formItem].includes(componentName2) && comp.groupName && comp.groupName !== rootForm.groupName) {
            return;
          }
          if ([formComponentName.form, formComponentName.formItem].includes(componentName2) && !comp.groupName && rootForm.groupName) {
            comp.groupName = rootForm.groupName;
          }
          if (componentName2 === formComponentName.form && includeNestedForm) {
            subForm.push(comp);
            return;
          }
          const isNeedCalc = includeNestedForm || comp.form === this;
          if (!(componentName2 === formComponentName.formItem && isNeedCalc && !comp.labelWidth)) {
            return;
          }
          if (comp.isShowLabel) {
            comp.cascadeWithoutChildren = true;
          }
          let text = comp.defaultLabelContent;
          const labelSlot = comp.$slots.label;
          if (labelSlot && labelSlot[0]) {
            const elm = labelSlot[0].elm;
            text = ((_a = elm == null ? void 0 : elm.innerHTML) == null ? void 0 : _a.trim()) || "";
          }
          const textsize = textMetrics.measure(dom, text);
          const width = textsize.width;
          if (this.calcLabelWidth < width) {
            this.calcLabelWidth = width + LABEL_SPACE;
          }
        });
        subForm.forEach((formComp) => {
          formComp.calcLabelWidth = this.calcLabelWidth;
        });
      });
    },
    getFieldRule(fieldSelector) {
      return this.rules[fieldSelector];
    }
  }
};
const __vue_script__$2 = script$2;
var __vue_render__$2 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c("form", { ref: "form", class: _vm.formCls }, [_vm._t("default")], 2);
};
var __vue_staticRenderFns__$2 = [];
__vue_render__$2._withStripped = true;
const __vue_inject_styles__$2 = void 0;
const __vue_scope_id__$2 = void 0;
const __vue_module_identifier__$2 = void 0;
const __vue_is_functional_template__$2 = false;
const __vue_component__$2 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$2, staticRenderFns: __vue_staticRenderFns__$2 },
  __vue_inject_styles__$2,
  __vue_script__$2,
  __vue_scope_id__$2,
  __vue_is_functional_template__$2,
  __vue_module_identifier__$2,
  false,
  void 0,
  void 0,
  void 0
);
var script$1 = {
  name: formComponentName.formCollapse,
  componentName: formComponentName.formCollapse,
  mixins: [FormTipMixin],
  props: {
    value: {
      type: Boolean,
      default: false
    },
    text: {
      type: String,
      default: () => $i("scp.vt_component.sf_widget.packages.form.src.form_collapse.advanced_text")
    },
    size: {
      type: String,
      default: "normal",
      validator(val) {
        return ["normal", "small"].includes(val);
      }
    },
    descText: {
      type: String
    }
  },
  data() {
    return {
      currentValue: this.value
    };
  },
  computed: {
    cls() {
      return [getPrefixedClassName("sf-form-collapse"), getPrefixedClassName(`sf-form-collapse--${this.size}`)];
    },
    iconCls() {
      return {
        iconfont: true,
        [getPrefixedClassName("sf-form-collapse__icon")]: true,
        "vtv-icon-arrow-up": this.currentValue,
        "vtv-icon-arrow-down": !this.currentValue
      };
    }
  },
  watch: {
    currentValue(val) {
      this.$emit("input", val);
    },
    value(val) {
      this.currentValue = val;
    }
  },
  methods: {
    getPrefixedClassName,
    toggle() {
      this.currentValue = !this.currentValue;
    }
  }
};
const __vue_script__$1 = script$1;
var __vue_render__$1 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c("div", { class: _vm.cls }, [
    _c(
      "div",
      {
        class: _vm.getPrefixedClassName("sf-form-collapse__divider"),
        on: {
          click: function($event) {
            return _vm.toggle();
          }
        }
      },
      [
        _c(
          "span",
          { class: _vm.getPrefixedClassName("sf-form-collapse__inner-text") },
          [_vm._v("\n      " + _vm._s(_vm.text) + "\n    ")]
        ),
        _vm._v(" "),
        _vm.tip ? _c("i", {
          class: [
            "icon-info",
            _vm.getPrefixedClassName("sf-form-collapse__tip")
          ],
          attrs: { "data-hint": _vm.contentTip }
        }) : _vm._e(),
        _vm._v(" "),
        _c("i", { class: _vm.iconCls })
      ]
    ),
    _vm._v(" "),
    _vm.descText ? _c(
      "div",
      { class: _vm.getPrefixedClassName("sf-form-collapse__des-text") },
      [_vm._v(_vm._s(_vm.descText))]
    ) : _vm._e(),
    _vm._v(" "),
    _vm.$slots.default ? _c(
      "div",
      {
        directives: [
          {
            name: "show",
            rawName: "v-show",
            value: _vm.currentValue,
            expression: "currentValue"
          }
        ]
      },
      [_vm._t("default")],
      2
    ) : _vm._e()
  ]);
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
const formLogger = logger(formComponentName.form);
function getPropByPath(obj, path) {
  let tempObj = obj;
  path = path.replace(/\[(\w+)\]/g, ".$1");
  path = path.replace(/^\./, "");
  const keyArr = path.split(".");
  let i = 0;
  for (let len = keyArr.length; i < len - 1; ++i) {
    const key = keyArr[i];
    if (key in tempObj) {
      tempObj = tempObj[key];
    } else {
      throw new Error("please transfer a valid prop path to form item!");
    }
  }
  return {
    o: tempObj,
    k: keyArr[i],
    v: tempObj[keyArr[i]]
  };
}
var script = {
  name: formComponentName.formItem,
  componentName: formComponentName.formItem,
  components: {
    SfFlex,
    SfFlexItem
  },
  mixins: [EmitterMixin, FormTipMixin, formContainerMixin],
  provide() {
    return {
      formItemSize: this.currentSize
    };
  },
  props: {
    label: String,
    labelWidth: String,
    labelAlignItems: String,
    contentPosition: String,
    prop: String,
    required: Boolean,
    noItemContentPadding: {},
    showLabel: {},
    id: {
      type: String,
      default() {
        return uuid();
      }
    },
    size: {
      type: String,
      default: ""
    },
    prompt: String,
    mode: String,
    labelTip: {
      type: [String, Array],
      default: ""
    }
  },
  data() {
    return {
      groupName: ""
    };
  },
  computed: {
    selectorID() {
      return this.id + "_" + uuid("form-item-");
    },
    selector() {
      return "#" + this.selectorID;
    },
    defaultLabelContent() {
      return this.label ? this.label + this.form.labelSuffix : "";
    },
    labelStyle() {
      const ret = {};
      if (this.form.labelPosition === "top") {
        return ret;
      }
      const autoLabelWidth = !!this.form.autoLabelWidth;
      const defaultLabelWidth = this.labelWidth || this.form.labelWidth;
      let width = "";
      if (defaultLabelWidth) {
        width = defaultLabelWidth;
      } else {
        width = autoLabelWidth ? this.form.calcLabelWidth + "px" : "";
      }
      if (width) {
        ret.width = width;
      }
      return ret;
    },
    contentFlexStyle() {
      const ret = {};
      if (!this.isShowLabel) {
        return ret;
      }
      const labelWidth = this.labelStyle.width;
      if (labelWidth) {
        ret.maxWidth = "calc(100% - " + labelWidth + ")";
      }
      return ret;
    },
    contentStyle() {
      const ret = {};
      if (this.form.labelPosition === "top" || this.form.inline) {
        return ret;
      }
      const contentPosition = this.contentPosition || this.form.contentPosition;
      if (contentPosition) {
        ret.textAlign = contentPosition;
      }
      return ret;
    },
    form() {
      let parent = this.$parent;
      while (parent.$options.componentName !== formComponentName.form) {
        parent = parent.$parent;
      }
      return parent;
    },
    fieldValue: {
      cache: false,
      get() {
        const model = this.form.model;
        if (!model || !this.prop) {
          return;
        }
        let path = this.prop;
        if (path.indexOf(":") !== -1) {
          path = path.replace(/:/, ".");
        }
        return getPropByPath(model, path).v;
      }
    },
    isNoItemContentPadding() {
      if (typeof this.noItemContentPadding !== "undefined") {
        return this.noItemContentPadding;
      }
      return this.form.noItemContentPadding;
    },
    isShowLabel() {
      const isShow = typeof this.showLabel === "undefined" ? this.form.showLabel : this.showLabel;
      return isShow && (this.label || this.$slots.label);
    },
    currentSize() {
      return this.size || this.form.size;
    },
    isInline() {
      return this.form.inline;
    },
    isLimit() {
      const limit = this.form.isLimit && this.limit;
      return limit && !this.hasGridChildren;
    },
    contentLabelTip() {
      return format.getContentTip(this.labelTip);
    }
  },
  mounted() {
    if (this.prop) {
      this.dispatch(formComponentName.form, formEvent.addRow, [this]);
      let initialValue = this.fieldValue;
      if (Array.isArray(initialValue)) {
        initialValue = [].concat(initialValue);
      }
      Object.defineProperty(this, "initialValue", {
        value: initialValue
      });
    }
  },
  beforeDestroy() {
    this.dispatch(formComponentName.form, formEvent.removeRow, [this]);
  },
  methods: {
    getPrefixedClassName,
    validate() {
      return this.form.validateRow(this);
    },
    setRequiredMark() {
      formLogger.warn("Use required prop instead");
    }
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _obj, _obj$1;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      class: (_obj = {}, _obj[_vm.getPrefixedClassName("el-form-item")] = true, _obj[_vm.getPrefixedClassName("is-required")] = _vm.required, _obj[_vm.getPrefixedClassName("el-form--item-content-padding")] = !_vm.isNoItemContentPadding, _obj[_vm.getPrefixedClassName("el-form-item--small")] = _vm.currentSize === "small", _obj[_vm.getPrefixedClassName("el-form-item--detail")] = _vm.mode === "detail", _obj[_vm.getPrefixedClassName("el-form-item--limit")] = _vm.isLimit, _obj),
      attrs: { id: _vm.selectorID }
    },
    [
      _c(
        "sf-flex",
        {
          attrs: {
            "flex-direction": _vm.form.labelPosition === "top" ? "column" : "row",
            "align-items": _vm.labelAlignItems || _vm.form.labelAlignItems || (_vm.isInline ? "center" : void 0)
          }
        },
        [
          _c("sf-flex-item", { attrs: { flex: "none" } }, [
            _vm.isShowLabel ? _c(
              "label",
              {
                class: [
                  _vm.getPrefixedClassName("el-form-item__label"),
                  "ellipsis"
                ],
                style: _vm.labelStyle,
                attrs: {
                  for: _vm.prop,
                  "data-tip": _vm.defaultLabelContent
                }
              },
              [
                _vm._t("label", [
                  _vm._v("\n          " + _vm._s(_vm.label)),
                  _vm.labelTip ? _c("i", {
                    staticClass: "icon-tip",
                    attrs: { "data-hint": _vm.contentLabelTip }
                  }) : _vm._e(),
                  _vm._v(_vm._s(_vm.form.labelSuffix) + "\n        ")
                ])
              ],
              2
            ) : _vm._e()
          ]),
          _vm._v(" "),
          _c(
            "sf-flex-item",
            {
              style: _vm.contentFlexStyle,
              attrs: {
                flex: _vm.form.labelPosition === "top" || _vm.isInline ? "auto" : "1"
              }
            },
            [
              _c(
                "div",
                {
                  class: (_obj$1 = {}, _obj$1[_vm.getPrefixedClassName("el-form-item__content")] = true, _obj$1[_vm.getPrefixedClassName("el-form-item__content--flex")] = _vm.$slots.append, _obj$1),
                  style: _vm.contentStyle
                },
                [
                  _vm._t("default"),
                  _vm._v(" "),
                  _vm._t("append"),
                  _vm._v(" "),
                  _vm.tip ? _c("i", {
                    class: [
                      "icon-tip",
                      _vm.getPrefixedClassName("el-form-item__content-tip")
                    ],
                    attrs: { "data-hint": _vm.contentTip }
                  }) : _vm._e()
                ],
                2
              ),
              _vm._v(" "),
              _vm.prompt || _vm.$slots.prompt ? _c(
                "div",
                { class: _vm.getPrefixedClassName("el-form-item__prompt") },
                [
                  _vm._t("prompt", [
                    _vm._v(
                      "\n          " + _vm._s(_vm.prompt) + "\n        "
                    )
                  ])
                ],
                2
              ) : _vm._e()
            ]
          )
        ],
        1
      )
    ],
    1
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
const INVALID_CLASS_NAME = "invalid";
var formFieldMixin = {
  mixins: [EmitterMixin],
  props: {
    id: {
      type: String,
      default() {
        return uuid();
      }
    },
    dataKey: {
      default: ""
    },
    validateType: {
      default: void 0
    },
    allowBlank: {
      default: void 0
    },
    allDecimals: {
      default: void 0
    },
    maxline: Number,
    visitor: Object,
    combineErr: Boolean,
    mask: RegExp,
    errText: String,
    maxLength: Number,
    minLength: Number,
    minCharType: Object,
    minCharTypeCount: Number,
    maxValue: Number,
    maxValueText: String,
    minValue: Number,
    minValueText: String,
    event: String,
    validator: Function,
    blankText: String,
    label: String,
    cb: Function,
    check: [String, Object],
    withSubnet: Boolean,
    netmask: String,
    netprefix: Number,
    isDecimal: Boolean,
    autoTrim: {
      default: void 0
    },
    useUTF8Len: {
      type: Boolean,
      default: true
    },
    withoutZh: Boolean,
    noValidate: {
      type: Boolean,
      default: false
    },
    validateOnVtypeConfigChange: {
      default: true
    },
    validateCallback: {
      default: function() {
        return function() {
          return true;
        };
      }
    },
    textOptions: {
      type: Object,
      default: () => ({ maxLength: 255, useUTF8Len: true })
    },
    addToForm: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      validateTip: "",
      dataHintStyle: "error",
      invalidCls: "",
      isDeactivated: false
    };
  },
  watch: {
    validateTip() {
      this.bindValidateHintOptions(this.validateHintOptions);
    },
    invalidCls(val) {
      const toggle = val === "" ? false : true;
      this.bindInvalidCls(INVALID_CLASS_NAME, toggle);
    },
    isDeactivated() {
      this.updateValidate();
    },
    disabledStatus(val) {
      this.updateValidate(!val);
    }
  },
  mounted() {
    if (this.shouldAddToForm() !== false) {
      this.dispatch(formComponentName.form, formEvent.addField, [this, this.formItem]);
      this.vtypeOptionKeys.forEach((key) => {
        this.$watch(key, () => {
          this.updateValidate();
        });
      });
    }
  },
  activated() {
    this.isDeactivated = false;
  },
  deactivated() {
    this.isDeactivated = true;
  },
  beforeDestroy() {
    if (this.shouldAddToForm() !== false) {
      this.dispatch(formComponentName.form, formEvent.removeField, [this, this.formItem]);
    }
  },
  computed: {
    fieldID() {
      return this.id;
    },
    fieldSelectorID() {
      return this.fieldID + "_" + uuid("form-field-");
    },
    fieldSelector() {
      return "#" + this.fieldSelectorID;
    },
    form() {
      let parent = this.$parent;
      while (parent && parent.$options.componentName !== formComponentName.form) {
        parent = parent.$parent;
      }
      return parent;
    },
    formItem() {
      let parent = this.$parent;
      while (parent && parent.$options.componentName !== formComponentName.formItem) {
        parent = parent.$parent;
      }
      return parent;
    },
    validateEnabled() {
      return this.checkValidateEnabled(
        !!(this.validateType || this.validator || typeof this.allowBlank !== "undefined" || this.maxLength || this.minLength || this.mask || this.autoTrim)
      );
    },
    fieldLabel() {
      return this.removeColon(this.label) || this.formItem && this.removeColon(this.formItem.label);
    },
    vtypeOptionKeys() {
      return [
        "validateType",
        "allowBlank",
        "allDecimals",
        "mask",
        "errText",
        "maxLength",
        "minLength",
        "minCharType",
        "minCharTypeCount",
        "maxValue",
        "maxValueText",
        "minValue",
        "minValueText",
        "event",
        "validator",
        "blankText",
        "fieldLabel",
        "cb",
        "autoTrim",
        "noValidate",
        "check",
        "maxline",
        "visitor",
        "combineErr",
        "withSubnet",
        "withoutZh",
        "netmask",
        "netprefix",
        "textOptions",
        "useUTF8Len"
      ];
    },
    validateHintOptions() {
      return { "data-hint": this.validateTip, "data-hint-style": this.dataHintStyle, "data-hint-pos": "b" };
    }
  },
  methods: {
    shouldAddToForm() {
      return this.addToForm;
    },
    updateValidate(notValidate = false) {
      if (this.shouldAddToForm()) {
        this.dispatch(formComponentName.form, formEvent.updateValidate, [this, notValidate]);
      }
    },
    checkValidateEnabled(enabled) {
      return enabled;
    },
    removeColon(v) {
      return String(v || "").replace(/(:|：)\s*$/, "");
    },
    getRule() {
      var _a;
      let rule = {};
      this.vtypeOptionKeys.forEach((key) => {
        if (typeof this[key] !== "undefined") {
          rule[key] = this[key];
        }
      });
      if (this.fieldLabel) {
        rule.label = this.fieldLabel;
      }
      const validateType = ((_a = this.getValidateType) == null ? void 0 : _a.call(this)) || this.validateType;
      if (validateType) {
        rule.type = validateType;
      }
      if (rule.validator) {
        rule._validator = rule.validator;
        rule.validator = (value) => {
          return rule._validator(value, this);
        };
      }
      rule.cb = (ret, options) => {
        let isContinue;
        if (this.validateCallback) {
          isContinue = this.validateCallback(ret, options);
        }
        if (isContinue === false) {
          return;
        }
        this.setValidateState(ret);
        this.onValidate(ret, options, this);
      };
      rule = this.processRule(rule);
      rule.noValidate = this.forceSkipValidate() || !this.validateEnabled;
      return {
        selector: this.fieldSelector,
        rule
      };
    },
    processRule(rule) {
      return rule;
    },
    validate(silent) {
      return this.form ? this.form.validateField(this, silent) : true;
    },
    onValidate() {
      return true;
    },
    getData() {
    },
    setData() {
    },
    getValue() {
      return this.getData();
    },
    setValue() {
      return this.setData.apply(this, arguments);
    },
    reset() {
    },
    getFieldRule() {
      var _a;
      return (_a = this.form) == null ? void 0 : _a.getFieldRule(this.fieldSelector);
    },
    toggleValidError(fieldEl) {
      toggleTip(fieldEl);
    },
    setValidateState(validateResult, hideHint) {
      if (validateResult === true) {
        this.validateTip = "";
        this.invalidCls = "";
        this.dataHintStyle = "";
        return;
      }
      if (hideHint) {
        this.validateTip = "";
        this.dataHintStyle = "";
      } else {
        const hintMsgConnector = $i("scp.vt_component.sf_widget.src.utils.validate_util.hint_msg_connector");
        if (Array.isArray(validateResult)) {
          this.validateTip = validateResult.join(hintMsgConnector);
          this.dataHintStyle = "error";
        } else {
          this.validateTip = "";
          this.dataHintStyle = "";
        }
      }
      this.invalidCls = INVALID_CLASS_NAME;
    },
    bindInvalidCls() {
    },
    bindValidateHintOptions() {
    },
    checkIsDisabled() {
      return this.disabled;
    },
    forceSkipValidate() {
      return this.noValidate || this.checkIsDisabled() || !!this.isDeactivated;
    }
  }
};
var formSizeMixin = {
  inject: {
    formItemSize: {
      default: ""
    }
  },
  computed: {
    currentSize() {
      return this.size || this.formItemSize;
    }
  }
};
export { formFieldMixin as FormFieldMixin, formSizeMixin as FormSizeMixin, __vue_component__$2 as SfForm, __vue_component__$1 as SfFormCollapse, __vue_component__ as SfFormItem };
