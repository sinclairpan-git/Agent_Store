import { componentName } from '@sxf/er-components/_const';
import { SfButton } from '@sxf/er-components/button';
import { SfSeparator } from '@sxf/er-components/separator';
import { $i } from '@sxf/er-config';
import { getPrefixedClassName } from '@sxf/er-feature';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
const PRE_INDEX = 2;
var script = {
  name: componentName.path,
  componentName: componentName.path,
  components: {
    SfButton,
    SfSeparator
  },
  props: {
    separator: {
      type: String,
      default: ">"
    },
    pathData: {
      required: true,
      type: Array,
      default() {
        return [];
      }
    },
    tip: {
      type: String,
      default: ""
    },
    goBack: {
      type: Boolean,
      default: true
    },
    isBtnBack: {
      type: Boolean,
      default: true
    },
    beforeLeave: {
      type: Function,
      default: () => true
    },
    hasMinWidth: {
      type: Boolean,
      default: true
    }
  },
  computed: {
    pagePathClass() {
      return {
        [getPrefixedClassName("page-path--has-min-width")]: this.hasMinWidth,
        [getPrefixedClassName("page-path--has-back-btn")]: this.hasBackBtn
      };
    },
    path() {
      return this.pathData.map((item) => {
        if (typeof item === "object") {
          return item;
        }
        return { text: item };
      });
    },
    goBackText() {
      return $i("scp.vt_component.sf_widget.packages.path.src.path.back_btn");
    },
    needGoBack() {
      return this.goBack && this.path.some((item, index) => {
        return index < this.path.length - 1 && item.url;
      });
    },
    pagePathWrapperClass() {
      return {
        [getPrefixedClassName("page-path-wrapper")]: true,
        [getPrefixedClassName("page-path-wrapper--has-back-btn")]: this.hasBackBtn
      };
    },
    hasBackBtn() {
      return this.needGoBack && this.isBtnBack;
    }
  },
  methods: {
    __goBack() {
      for (let i = this.path.length - PRE_INDEX; i >= 0; i--) {
        const url = this.path[i] && this.path[i].url;
        if (url) {
          this.__toPage(url, true);
          break;
        }
      }
    },
    async __toPage(url, isBack = false) {
      const leave = await this.beforeLeave({ isBack });
      if (url && leave) {
        window.location.href = url;
      }
    },
    getPrefixedClassName
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c("div", { class: _vm.pagePathWrapperClass }, [
    _c(
      "div",
      { class: _vm.getPrefixedClassName("page-path-container") },
      [
        _vm.path.length ? _c(
          "div",
          {
            class: [
              _vm.getPrefixedClassName("page-path"),
              "ellipsis",
              _vm.pagePathClass
            ]
          },
          [
            _vm.needGoBack && !_vm.isBtnBack ? _c(
              "span",
              { class: _vm.getPrefixedClassName("page-path__item") },
              [
                _c("i", {
                  staticClass: "iconfont vtv-icon-return",
                  class: _vm.getPrefixedClassName(
                    "page-path__back-icon"
                  )
                }),
                _vm._v(" "),
                _c(
                  "sf-button",
                  {
                    class: _vm.getPrefixedClassName("page-path__inner"),
                    attrs: { type: "link" },
                    on: {
                      click: function($event) {
                        return _vm.__goBack();
                      }
                    }
                  },
                  [
                    _vm._v(
                      "\n          " + _vm._s(_vm.goBackText) + "\n        "
                    )
                  ]
                ),
                _vm._v(" "),
                _c("sf-separator", { attrs: { color: "#cccccc" } })
              ],
              1
            ) : _vm._e(),
            _vm._v(" "),
            _vm.needGoBack && _vm.isBtnBack ? _c("sf-button", {
              attrs: { type: "text", icon: "back", size: "small" },
              on: {
                click: function($event) {
                  return _vm.__goBack();
                }
              }
            }) : _vm._e(),
            _vm._v(" "),
            _vm._l(_vm.path, function(item, index) {
              return _c(
                "span",
                {
                  key: index,
                  class: _vm.getPrefixedClassName("page-path__item")
                },
                [
                  item.url ? _c(
                    "sf-button",
                    {
                      class: _vm.getPrefixedClassName("page-path__inner"),
                      attrs: { type: "link", tip: item.text },
                      on: {
                        click: function($event) {
                          return _vm.__toPage(item.url);
                        }
                      }
                    },
                    [
                      _vm._v(
                        "\n          " + _vm._s(item.text) + "\n        "
                      )
                    ]
                  ) : _c(
                    "span",
                    {
                      class: _vm.getPrefixedClassName("page-path__inner"),
                      attrs: { "data-tip": item.text }
                    },
                    [
                      _vm._v(
                        "\n          " + _vm._s(item.text) + "\n        "
                      )
                    ]
                  ),
                  _vm._v(" "),
                  _c(
                    "span",
                    {
                      class: _vm.getPrefixedClassName(
                        "page-path__separator"
                      )
                    },
                    [
                      _vm._v(
                        "\n          " + _vm._s(_vm.separator) + "\n        "
                      )
                    ]
                  )
                ],
                1
              );
            })
          ],
          2
        ) : _vm._e(),
        _vm._v(" "),
        _vm._t("default"),
        _vm._v(" "),
        _c(
          "div",
          { class: _vm.getPrefixedClassName("page-path-right") },
          [
            _vm._t("right", [
              _vm.tip ? _c("i", {
                staticClass: "iconfont vtv-icon-help",
                class: _vm.getPrefixedClassName("page-path-right__help"),
                attrs: { "data-tip": _vm.tip }
              }) : _vm._e()
            ])
          ],
          2
        )
      ],
      2
    )
  ]);
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__ as SfPath };
