import { componentName } from '@sxf/er-components/_const';
import { vClickoutside } from '@sxf/er-components/_directives';
import { EmitterMixin, ComponentMixin } from '@sxf/er-components/_mixins';
import { VuePopper } from '@sxf/er-components/_utils/popper';
import { FormFieldMixin } from '@sxf/er-components/form';
import { SfInput } from '@sxf/er-components/input';
import { getPrefixedClassName } from '@sxf/er-feature';
import { $i, globalConfig } from '@sxf/er-config';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
import { SfButton } from '@sxf/er-components/button';
import { hasClass, off as off$1, on as on$1, getScrollBarWidth, scrollIntoView } from '@sxf/er-utils/dom';
import 'jquery';
import '@sxf/er-utils/apply';
import '@sxf/er-utils/delay';
import Format from '@sxf/er-utils/format';
import { $i as $i$1 } from '@sxf/er-config/';
import { addResizeListener, removeResizeListener } from '@sxf/er-components/_utils/resize-event';
import { SfSpace } from '@sxf/er-components/space';
var fecha = {};
var token = /d{1,4}|M{1,4}|yy(?:yy)?|S{1,3}|Do|ZZ|([HhMsDm])\1?|[aA]|"[^"]*"|'[^']*'/g;
var twoDigits = /\d\d?/;
var threeDigits = /\d{3}/;
var fourDigits = /\d{4}/;
var word = /[0-9]*['a-z\u00A0-\u05FF\u0700-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+|[\u0600-\u06FF\/]+(\s*?[\u0600-\u06FF]+){1,2}/i;
var noop = function() {
};
function shorten(arr, sLen) {
  var newArr = [];
  for (var i = 0, len = arr.length; i < len; i++) {
    newArr.push(arr[i].substr(0, sLen));
  }
  return newArr;
}
function monthUpdate(arrName) {
  return function(d, v, i18n) {
    var index = i18n[arrName].indexOf(v.charAt(0).toUpperCase() + v.substr(1).toLowerCase());
    if (~index) {
      d.month = index;
    }
  };
}
function pad(val, len) {
  val = String(val);
  len = len || 2;
  while (val.length < len) {
    val = "0" + val;
  }
  return val;
}
var dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
var monthNames = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December"
];
var monthNamesShort = shorten(monthNames, 3);
var dayNamesShort = shorten(dayNames, 3);
fecha.i18n = {
  dayNamesShort,
  dayNames,
  monthNamesShort,
  monthNames,
  amPm: ["am", "pm"],
  DoFn: function DoFn(D) {
    return D + ["th", "st", "nd", "rd"][D % 10 > 3 ? 0 : (D - D % 10 !== 10) * D % 10];
  }
};
var formatFlags = {
  D: function(dateObj) {
    return dateObj.getDay();
  },
  DD: function(dateObj) {
    return pad(dateObj.getDay());
  },
  Do: function(dateObj, i18n) {
    return i18n.DoFn(dateObj.getDate());
  },
  d: function(dateObj) {
    return dateObj.getDate();
  },
  dd: function(dateObj) {
    return pad(dateObj.getDate());
  },
  ddd: function(dateObj, i18n) {
    return i18n.dayNamesShort[dateObj.getDay()];
  },
  dddd: function(dateObj, i18n) {
    return i18n.dayNames[dateObj.getDay()];
  },
  M: function(dateObj) {
    return dateObj.getMonth() + 1;
  },
  MM: function(dateObj) {
    return pad(dateObj.getMonth() + 1);
  },
  MMM: function(dateObj, i18n) {
    return i18n.monthNamesShort[dateObj.getMonth()];
  },
  MMMM: function(dateObj, i18n) {
    return i18n.monthNames[dateObj.getMonth()];
  },
  yy: function(dateObj) {
    return String(dateObj.getFullYear()).substr(2);
  },
  yyyy: function(dateObj) {
    return dateObj.getFullYear();
  },
  h: function(dateObj) {
    return dateObj.getHours() % 12 || 12;
  },
  hh: function(dateObj) {
    return pad(dateObj.getHours() % 12 || 12);
  },
  H: function(dateObj) {
    return dateObj.getHours();
  },
  HH: function(dateObj) {
    return pad(dateObj.getHours());
  },
  m: function(dateObj) {
    return dateObj.getMinutes();
  },
  mm: function(dateObj) {
    return pad(dateObj.getMinutes());
  },
  s: function(dateObj) {
    return dateObj.getSeconds();
  },
  ss: function(dateObj) {
    return pad(dateObj.getSeconds());
  },
  S: function(dateObj) {
    return Math.round(dateObj.getMilliseconds() / 100);
  },
  SS: function(dateObj) {
    return pad(Math.round(dateObj.getMilliseconds() / 10), 2);
  },
  SSS: function(dateObj) {
    return pad(dateObj.getMilliseconds(), 3);
  },
  a: function(dateObj, i18n) {
    return dateObj.getHours() < 12 ? i18n.amPm[0] : i18n.amPm[1];
  },
  A: function(dateObj, i18n) {
    return dateObj.getHours() < 12 ? i18n.amPm[0].toUpperCase() : i18n.amPm[1].toUpperCase();
  },
  ZZ: function(dateObj) {
    var o = dateObj.getTimezoneOffset();
    return (o > 0 ? "-" : "+") + pad(Math.floor(Math.abs(o) / 60) * 100 + Math.abs(o) % 60, 4);
  }
};
var parseFlags = {
  d: [
    twoDigits,
    function(d, v) {
      d.day = v;
    }
  ],
  M: [
    twoDigits,
    function(d, v) {
      d.month = v - 1;
    }
  ],
  yy: [
    twoDigits,
    function(d, v) {
      var da = new Date(), cent = +("" + da.getFullYear()).substr(0, 2);
      d.year = "" + (v > 68 ? cent - 1 : cent) + v;
    }
  ],
  h: [
    twoDigits,
    function(d, v) {
      d.hour = v;
    }
  ],
  m: [
    twoDigits,
    function(d, v) {
      d.minute = v;
    }
  ],
  s: [
    twoDigits,
    function(d, v) {
      d.second = v;
    }
  ],
  yyyy: [
    fourDigits,
    function(d, v) {
      d.year = v;
    }
  ],
  S: [
    /\d/,
    function(d, v) {
      d.millisecond = v * 100;
    }
  ],
  SS: [
    /\d{2}/,
    function(d, v) {
      d.millisecond = v * 10;
    }
  ],
  SSS: [
    threeDigits,
    function(d, v) {
      d.millisecond = v;
    }
  ],
  D: [twoDigits, noop],
  ddd: [word, noop],
  MMM: [word, monthUpdate("monthNamesShort")],
  MMMM: [word, monthUpdate("monthNames")],
  a: [
    word,
    function(d, v, i18n) {
      var val = v.toLowerCase();
      if (val === i18n.amPm[0]) {
        d.isPm = false;
      } else if (val === i18n.amPm[1]) {
        d.isPm = true;
      }
    }
  ],
  ZZ: [
    /[\+\-]\d\d:?\d\d/,
    function(d, v) {
      var parts = (v + "").match(/([\+\-]|\d\d)/gi), minutes;
      if (parts) {
        minutes = +(parts[1] * 60) + parseInt(parts[2], 10);
        d.timezoneOffset = parts[0] === "+" ? minutes : -minutes;
      }
    }
  ]
};
parseFlags.DD = parseFlags.D;
parseFlags.dddd = parseFlags.ddd;
parseFlags.Do = parseFlags.dd = parseFlags.d;
parseFlags.mm = parseFlags.m;
parseFlags.hh = parseFlags.H = parseFlags.HH = parseFlags.h;
parseFlags.MM = parseFlags.M;
parseFlags.ss = parseFlags.s;
parseFlags.A = parseFlags.a;
fecha.masks = {
  default: "ddd MMM dd yyyy HH:mm:ss",
  shortDate: "M/D/yy",
  mediumDate: "MMM d, yyyy",
  longDate: "MMMM d, yyyy",
  fullDate: "dddd, MMMM d, yyyy",
  shortTime: "HH:mm",
  mediumTime: "HH:mm:ss",
  longTime: "HH:mm:ss.SSS"
};
fecha.format = function(dateObj, mask, i18nSettings) {
  var i18n = i18nSettings || fecha.i18n;
  if (typeof dateObj === "number") {
    dateObj = new Date(dateObj);
  }
  if (Object.prototype.toString.call(dateObj) !== "[object Date]" || isNaN(dateObj.getTime())) {
    throw new Error("Invalid Date in fecha.format");
  }
  mask = fecha.masks[mask] || mask || fecha.masks["default"];
  return mask.replace(token, function($0) {
    return $0 in formatFlags ? formatFlags[$0](dateObj, i18n) : $0.slice(1, $0.length - 1);
  });
};
fecha.parse = function(dateStr, format, i18nSettings) {
  var i18n = i18nSettings || fecha.i18n;
  if (typeof format !== "string") {
    throw new Error("Invalid format in fecha.parse");
  }
  format = fecha.masks[format] || format;
  if (dateStr.length > 1e3) {
    return false;
  }
  var isValid = true;
  var dateInfo = {};
  format.replace(token, function($0) {
    if (parseFlags[$0]) {
      var info = parseFlags[$0];
      var index = dateStr.search(info[0]);
      if (!~index) {
        isValid = false;
      } else {
        dateStr.replace(info[0], function(result) {
          info[1](dateInfo, result, i18n);
          dateStr = dateStr.substr(index + result.length);
          return result;
        });
      }
    }
    return parseFlags[$0] ? "" : $0.slice(1, $0.length - 1);
  });
  if (!isValid) {
    return false;
  }
  var today = new Date();
  if (dateInfo.isPm === true && dateInfo.hour != null && +dateInfo.hour !== 12) {
    dateInfo.hour = +dateInfo.hour + 12;
  } else if (dateInfo.isPm === false && +dateInfo.hour === 12) {
    dateInfo.hour = 0;
  }
  var date;
  if (dateInfo.timezoneOffset != null) {
    dateInfo.minute = +(dateInfo.minute || 0) - +dateInfo.timezoneOffset;
    date = new Date(
      Date.UTC(
        dateInfo.year || today.getFullYear(),
        dateInfo.month || 0,
        dateInfo.day || 1,
        dateInfo.hour || 0,
        dateInfo.minute || 0,
        dateInfo.second || 0,
        dateInfo.millisecond || 0
      )
    );
  } else {
    date = new Date(
      dateInfo.year || today.getFullYear(),
      dateInfo.month || 0,
      dateInfo.day || 1,
      dateInfo.hour || 0,
      dateInfo.minute || 0,
      dateInfo.second || 0,
      dateInfo.millisecond || 0
    );
  }
  return date;
};
const lang = function($i2) {
  return {
    el: {
      datepicker: {
        now: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_now"),
        today: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_today"),
        cancel: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_cancel"),
        clear: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_clear"),
        confirm: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_confirm"),
        selectDate: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_select_day"),
        selectTime: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_select_time"),
        startDate: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_start_date"),
        startTime: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_start_time"),
        endDate: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_end_date"),
        endTime: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_end_time"),
        prevYear: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_perv_year"),
        nextYear: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_next_year"),
        prevMonth: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_prev_month"),
        nextMonth: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_next_month"),
        year: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_year"),
        month1: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_january"),
        month2: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_february"),
        month3: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_march"),
        month4: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_april"),
        month5: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_may"),
        month6: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_june"),
        month7: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_july"),
        month8: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_august"),
        month9: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_september"),
        month10: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_october"),
        month11: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_november"),
        month12: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_december"),
        weeks: {
          sun: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_sunday"),
          mon: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_monday"),
          tue: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_tuesday"),
          wed: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_wednesday"),
          thu: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_thursday"),
          fri: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_friday"),
          sat: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_saturday")
        },
        months: {
          jan: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_months_january"),
          feb: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_months_february"),
          mar: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_months_march"),
          apr: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_months_april"),
          may: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_months_may"),
          jun: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_months_june"),
          jul: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_months_july"),
          aug: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_months_august"),
          sep: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_months_september"),
          oct: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_months_october"),
          nov: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_months_november"),
          dec: $i2("scp.vt_component.sf_widget.packages.date_picker.src.locale.datepicker_months_december")
        }
      }
    }
  };
};
const t$1 = function($i2, path) {
  const array = path.split(".");
  let current = lang($i2);
  for (let i = 0, j = array.length; i < j; i++) {
    const property = array[i];
    const value = current[property];
    if (i === j - 1) {
      return value;
    }
    if (!value) {
      return "";
    }
    current = value;
  }
  return "";
};
const arrayFindIndex = function(arr, pred) {
  for (let i = 0; i !== arr.length; ++i) {
    if (pred(arr[i])) {
      return i;
    }
  }
  return -1;
};
const arrayFind = function(arr, pred) {
  const idx = arrayFindIndex(arr, pred);
  return idx !== -1 ? arr[idx] : void 0;
};
const coerceTruthyValueToArray = function(val) {
  if (Array.isArray(val)) {
    return val;
  } else if (val) {
    return [val];
  } else {
    return [];
  }
};
const t = (...args) => t$1($i, ...args);
const weeks = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
const months = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
const getI18nSettings = () => {
  return {
    dayNamesShort: weeks.map((week) => t(`el.datepicker.weeks.${week}`)),
    dayNames: weeks.map((week) => t(`el.datepicker.weeks.${week}`)),
    monthNamesShort: months.map((month) => t(`el.datepicker.months.${month}`)),
    monthNames: months.map((month, index) => t(`el.datepicker.month${index + 1}`)),
    amPm: ["am", "pm"]
  };
};
const toDate = function(date) {
  return isDate(date) ? new Date(date) : null;
};
const isDate = function(date) {
  if (date === null || date === void 0) {
    return false;
  }
  if (isNaN(new Date(date).getTime())) {
    return false;
  }
  if (Array.isArray(date)) {
    return false;
  }
  return true;
};
const isDateObject = function(val) {
  return val instanceof Date;
};
const formatDate = function(date, format) {
  date = toDate(date);
  if (!date) {
    return "";
  }
  return fecha.format(date, format || "yyyy-MM-dd", getI18nSettings());
};
const parseDate = function(string, format) {
  return fecha.parse(string, format || "yyyy-MM-dd", getI18nSettings());
};
const getDayCountOfMonth = function(year, month) {
  if (month === 3 || month === 5 || month === 8 || month === 10) {
    return 30;
  }
  if (month === 1) {
    if (year % 4 === 0 && year % 100 !== 0 || year % 400 === 0) {
      return 29;
    } else {
      return 28;
    }
  }
  return 31;
};
const getDayCountOfYear = function(year) {
  const isLeapYear = year % 400 === 0 || year % 100 !== 0 && year % 4 === 0;
  return isLeapYear ? 366 : 365;
};
const getFirstDayOfMonth = function(date) {
  const temp = new Date(date.getTime());
  temp.setDate(1);
  return temp.getDay();
};
const prevDate = function(date, amount = 1) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() - amount);
};
const nextDate = function(date, amount = 1) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() + amount);
};
const getStartDateOfMonth = function(year, month) {
  const result = new Date(year, month, 1);
  const day = result.getDay();
  if (day === 0) {
    return prevDate(result, 7);
  } else {
    return prevDate(result, day);
  }
};
const getWeekNumber = function(src) {
  if (!isDate(src)) {
    return null;
  }
  const date = new Date(src.getTime());
  date.setHours(0, 0, 0, 0);
  date.setDate(date.getDate() + 3 - (date.getDay() + 6) % 7);
  const week1 = new Date(date.getFullYear(), 0, 4);
  return 1 + Math.round(((date.getTime() - week1.getTime()) / 864e5 - 3 + (week1.getDay() + 6) % 7) / 7);
};
const range = function(n) {
  return Array.from({
    length: n
  }).map((_, n2) => n2);
};
const modifyDate = function(date, y, m, d) {
  return new Date(y, m, d, date.getHours(), date.getMinutes(), date.getSeconds(), date.getMilliseconds());
};
const modifyTime = function(date, h, m, s) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate(), h, m, s, date.getMilliseconds());
};
const modifyWithTimeString = (date, time) => {
  if (date == null || !time) {
    return date;
  }
  time = parseDate(time, "HH:mm:ss");
  return modifyTime(date, time.getHours(), time.getMinutes(), time.getSeconds());
};
const clearTime = function(date) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
};
const clearMilliseconds = function(date) {
  return new Date(
    date.getFullYear(),
    date.getMonth(),
    date.getDate(),
    date.getHours(),
    date.getMinutes(),
    date.getSeconds(),
    0
  );
};
const changeYearMonthAndClampDate = function(date, year, month) {
  const monthDate = Math.min(date.getDate(), getDayCountOfMonth(year, month));
  return modifyDate(date, year, month, monthDate);
};
const prevMonth = function(date) {
  const year = date.getFullYear();
  const month = date.getMonth();
  return month === 0 ? changeYearMonthAndClampDate(date, year - 1, 11) : changeYearMonthAndClampDate(date, year, month - 1);
};
const nextMonth = function(date) {
  const year = date.getFullYear();
  const month = date.getMonth();
  return month === 11 ? changeYearMonthAndClampDate(date, year + 1, 0) : changeYearMonthAndClampDate(date, year, month + 1);
};
const prevYear = function(date, amount = 1) {
  const year = date.getFullYear();
  const month = date.getMonth();
  return changeYearMonthAndClampDate(date, year - amount, month);
};
const nextYear = function(date, amount = 1) {
  const year = date.getFullYear();
  const month = date.getMonth();
  return changeYearMonthAndClampDate(date, year + amount, month);
};
const extractDateFormat = function(format) {
  return format.replace(/\W?m{1,2}|\W?ZZ/g, "").replace(/\W?h{1,2}|\W?s{1,3}|\W?a/gi, "").trim();
};
const extractTimeFormat = function(format) {
  return format.replace(/\W?D{1,2}|\W?Do|\W?d{1,4}|\W?M{1,4}|\W?y{2,4}/g, "").trim();
};
const getWeekStartAndEnd = function(date) {
  const currentDay = date.getDay();
  const startDate = new Date(date.getTime());
  if (currentDay === 0) {
    return [startDate, new Date(startDate.getTime() + 6 * 24 * 60 * 60 * 1e3)];
  }
  const diff = startDate.getDate() - currentDay;
  const weekStart = new Date(startDate.setDate(diff));
  const weekEnd = new Date(weekStart.getTime() + 6 * 24 * 60 * 60 * 1e3);
  return [weekStart, weekEnd];
};
const formatTimeToString = function(value, format = "HH:mm:ss") {
  return format.replace("HH", String(value.hour).padStart(2, "0")).replace("mm", String(value.minute).padStart(2, "0")).replace("ss", value.second !== void 0 ? String(value.second).padStart(2, "0") : "");
};
const NewPopper = {
  props: {
    appendToBody: VuePopper.props.appendToBody,
    offset: VuePopper.props.offset,
    boundariesPadding: VuePopper.props.boundariesPadding,
    arrowOffset: VuePopper.props.arrowOffset
  },
  methods: VuePopper.methods,
  data() {
    return Object.assign({ visibleArrow: false }, VuePopper.data);
  },
  beforeDestroy: VuePopper.beforeDestroy
};
const DEFAULT_FORMATS = {
  date: "yyyy-MM-dd",
  month: "yyyy-MM",
  datetime: "yyyy-MM-dd HH:mm:ss",
  time: "HH:mm:ss",
  week: "yyyywWW",
  timerange: "HH:mm:ss",
  daterange: "yyyy-MM-dd",
  datetimerange: "yyyy-MM-dd HH:mm:ss",
  year: "yyyy"
};
const HAVE_TRIGGER_TYPES = [
  "date",
  "datetime",
  "time",
  "time-select",
  "week",
  "month",
  "year",
  "daterange",
  "timerange",
  "datetimerange",
  "dates"
];
const DATE_FORMATTER = function(value, format) {
  if (format === "timestamp") {
    return value.getTime();
  }
  return formatDate(value, format);
};
const DATE_PARSER = function(text, format) {
  if (format === "timestamp") {
    return new Date(Number(text));
  }
  return parseDate(text, format);
};
const RANGE_FORMATTER = function(value, format) {
  if (Array.isArray(value) && value.length === 2) {
    const start = value[0];
    const end = value[1];
    if (start && end) {
      return [DATE_FORMATTER(start, format), DATE_FORMATTER(end, format)];
    }
  }
  return "";
};
const RANGE_PARSER = function(array, format, separator) {
  if (!Array.isArray(array)) {
    array = array.split(separator);
  }
  if (array.length === 2) {
    const range1 = array[0];
    const range2 = array[1];
    return [DATE_PARSER(range1, format), DATE_PARSER(range2, format)];
  }
  return [];
};
const TYPE_VALUE_RESOLVER_MAP = {
  default: {
    formatter(value) {
      if (!value) {
        return "";
      }
      return "" + value;
    },
    parser(text) {
      if (text === void 0 || text === "") {
        return null;
      }
      return text;
    }
  },
  week: {
    formatter(value, format) {
      const week = getWeekNumber(value);
      const month = value.getMonth();
      const trueDate = new Date(value);
      if (week === 1 && month === 11) {
        trueDate.setHours(0, 0, 0, 0);
        trueDate.setDate(trueDate.getDate() + 3 - (trueDate.getDay() + 6) % 7);
      }
      let date = formatDate(trueDate, format);
      date = /WW/.test(date) ? date.replace(/WW/, week < 10 ? "0" + week : week) : date.replace(/W/, week);
      return date;
    },
    parser(text) {
      const array = (text || "").split("w");
      if (array.length === 2) {
        const year = Number(array[0]);
        const month = Number(array[1]);
        if (!isNaN(year) && !isNaN(month) && month < 54) {
          return text;
        }
      }
      return null;
    }
  },
  date: {
    formatter: DATE_FORMATTER,
    parser: DATE_PARSER
  },
  datetime: {
    formatter: DATE_FORMATTER,
    parser: DATE_PARSER
  },
  daterange: {
    formatter: RANGE_FORMATTER,
    parser: RANGE_PARSER
  },
  datetimerange: {
    formatter: RANGE_FORMATTER,
    parser: RANGE_PARSER
  },
  timerange: {
    formatter: RANGE_FORMATTER,
    parser: RANGE_PARSER
  },
  time: {
    formatter: DATE_FORMATTER,
    parser: DATE_PARSER
  },
  month: {
    formatter: DATE_FORMATTER,
    parser: DATE_PARSER
  },
  year: {
    formatter: DATE_FORMATTER,
    parser: DATE_PARSER
  },
  number: {
    formatter(value) {
      if (!value) {
        return "";
      }
      return "" + value;
    },
    parser(text) {
      const result = Number(text);
      if (!isNaN(text)) {
        return result;
      } else {
        return null;
      }
    }
  },
  dates: {
    formatter(value, format) {
      return value.map((date) => DATE_FORMATTER(date, format));
    },
    parser(value, format) {
      return (typeof value === "string" ? value.split(", ") : value).map(
        (date) => date instanceof Date ? date : DATE_PARSER(date, format)
      );
    }
  }
};
const PLACEMENT_MAP = {
  left: "bottom-start",
  center: "bottom",
  right: "bottom-end"
};
const parseAsFormatAndType = (value, customFormat, type, rangeSeparator = "-") => {
  if (!value) {
    return null;
  }
  const parser = (TYPE_VALUE_RESOLVER_MAP[type] || TYPE_VALUE_RESOLVER_MAP["default"]).parser;
  const format = customFormat || DEFAULT_FORMATS[type];
  return parser(value, format, rangeSeparator);
};
const formatAsFormatAndType = (value, customFormat, type) => {
  if (!value) {
    return null;
  }
  const formatter = (TYPE_VALUE_RESOLVER_MAP[type] || TYPE_VALUE_RESOLVER_MAP["default"]).formatter;
  const format = customFormat || DEFAULT_FORMATS[type];
  return formatter(value, format);
};
const valueEquals = function(a, b) {
  const dateEquals = function(a2, b2) {
    const aIsDate = a2 instanceof Date;
    const bIsDate = b2 instanceof Date;
    if (aIsDate && bIsDate) {
      return a2.getTime() === b2.getTime();
    }
    if (!aIsDate && !bIsDate) {
      return a2 === b2;
    }
    return false;
  };
  const aIsArray = a instanceof Array;
  const bIsArray = b instanceof Array;
  if (aIsArray && bIsArray) {
    if (a.length !== b.length) {
      return false;
    }
    return a.every((item, index) => dateEquals(item, b[index]));
  }
  if (!aIsArray && !bIsArray) {
    return dateEquals(a, b);
  }
  return false;
};
const isString = function(val) {
  return typeof val === "string" || val instanceof String;
};
const validator = function(val) {
  return val === null || val === void 0 || isString(val) || Array.isArray(val) && val.length === 2 && val.every(isString);
};
const defaultDisabledDate = (date) => {
  return date.getFullYear() < 1970 || date.getFullYear() >= 1e4;
};
var script$9 = {
  name: "PickerMixin",
  components: {
    SfInput
  },
  directives: { clickoutside: vClickoutside },
  mixins: [EmitterMixin, NewPopper, FormFieldMixin],
  props: {
    size: String,
    format: String,
    valueFormat: String,
    readonly: Boolean,
    placeholder: String,
    startPlaceholder: String,
    endPlaceholder: String,
    prefixIcon: String,
    clearIcon: {
      type: String,
      default: "el-icon-circle-close"
    },
    name: {
      default: "",
      validator
    },
    disabled: Boolean,
    clearable: {
      type: Boolean,
      default: false
    },
    id: {
      default: "",
      validator
    },
    popperClass: String,
    editable: {
      type: Boolean,
      default: true
    },
    align: {
      type: String,
      default: "left"
    },
    value: {},
    defaultValue: {},
    defaultTime: {},
    rangeSeparator: {
      type: String,
      default: "-"
    },
    pickerOptions: {},
    unlinkPanels: {
      type: Boolean,
      default: true
    },
    displayValueFormat: {
      type: Function
    },
    useLocalMaxtime: {
      type: Boolean,
      default: false
    },
    showSecond: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      pickerVisible: false,
      showClose: false,
      userInput: null,
      valueOnOpen: null,
      unwatchPickerOptions: null,
      currentValue: this.value
    };
  },
  computed: {
    ranged() {
      return this.mixSelect || this.type.indexOf("range") > -1;
    },
    reference() {
      const reference = this.$refs.reference;
      return reference.$el || reference;
    },
    refInput() {
      if (this.reference) {
        return [].slice.call(this.reference.querySelectorAll("input"));
      }
      return [];
    },
    valueIsEmpty() {
      const val = this.value;
      if (Array.isArray(val)) {
        for (let i = 0, len = val.length; i < len; i++) {
          if (val[i]) {
            return false;
          }
        }
      } else {
        if (val) {
          return false;
        }
      }
      return true;
    },
    triggerClass() {
      let prefixIcon = "calendar";
      if (this.type === "time-select") {
        prefixIcon = "triangle-unfold";
      }
      if (this.prefixIcon) {
        prefixIcon = this.prefixIcon;
      }
      if (this.showClose) {
        prefixIcon = "comp-tip-close";
      }
      return ["vtv-icon-" + prefixIcon, "iconfont"].join(" ");
    },
    selectionMode() {
      if (this.type === "week") {
        return "week";
      } else if (this.type === "month") {
        return "month";
      } else if (this.type === "year") {
        return "year";
      } else if (this.type === "dates") {
        return "dates";
      }
      return "day";
    },
    haveTrigger() {
      if (typeof this.showTrigger !== "undefined") {
        return this.showTrigger;
      }
      return HAVE_TRIGGER_TYPES.indexOf(this.type) !== -1;
    },
    displayValue() {
      const formattedValue = formatAsFormatAndType(this.parsedValue, this.format, this.type, this.rangeSeparator);
      if (this.displayValueFormat) {
        return this.displayValueFormat(formattedValue, this.userInput);
      }
      if (Array.isArray(this.userInput)) {
        return [
          this.userInput[0] || formattedValue && formattedValue[0] || "",
          this.userInput[1] || formattedValue && formattedValue[1] || ""
        ];
      } else if (this.userInput !== null) {
        return this.userInput;
      } else if (formattedValue) {
        return this.type === "dates" ? formattedValue.join(", ") : formattedValue;
      } else {
        return formattedValue;
      }
    },
    parsedValue() {
      if (!this.value) {
        return this.value;
      }
      if (this.type === "time-select") {
        return this.value;
      }
      const valueIsDateObject = isDateObject(this.value) || Array.isArray(this.value) && this.value.every(isDateObject);
      if (valueIsDateObject) {
        return this.value;
      }
      if (this.valueFormat) {
        return parseAsFormatAndType(this.value, this.valueFormat, this.type, this.rangeSeparator) || this.value;
      }
      return Array.isArray(this.value) ? this.value.map((val) => new Date(val)) : new Date(this.value);
    },
    pickerSize() {
      return this.size;
    },
    pickerDisabled() {
      return this.disabled;
    },
    firstInputId() {
      const obj = {};
      let id;
      if (this.ranged) {
        id = this.id && this.id[0];
      } else {
        id = this.id;
      }
      if (id) {
        obj.id = id;
      }
      return obj;
    },
    secondInputId() {
      const obj = {};
      let id;
      if (this.ranged) {
        id = this.id && this.id[1];
      }
      if (id) {
        obj.id = id;
      }
      return obj;
    }
  },
  watch: {
    pickerVisible(val) {
      if (this.readonly || this.pickerDisabled) {
        return;
      }
      this.$emit("picker-visible-change", val);
      if (val) {
        this.showPicker();
        this.valueOnOpen = Array.isArray(this.value) ? [...this.value] : this.value;
      } else {
        this.hidePicker();
        this.emitChange(this.value);
        this.userInput = null;
        this.dispatch("SfFormItem", "sf.form.blur");
        this.$emit("blur", this);
        this.blur();
      }
    },
    parsedValue: {
      immediate: true,
      handler(val) {
        if (this.picker) {
          this.picker.value = val;
        }
      }
    },
    defaultValue(val) {
      if (this.picker) {
        this.picker.defaultValue = val;
      }
    },
    value(val, oldVal) {
      if (!valueEquals(val, oldVal) && !this.pickerVisible) {
        this.dispatch("SfFormItem", "sf.form.change", val);
      }
      this.currentValue = val;
    }
  },
  created() {
    this.popperOptions = {
      boundariesPadding: 0,
      gpuAcceleration: false
    };
    this.placement = PLACEMENT_MAP[this.align] || PLACEMENT_MAP.left;
  },
  methods: {
    getPrefixedClassName,
    getFullUtid(utidBase) {
      return this.$attrs.utid ? `${this.$attrs.utid}-${utidBase}` : utidBase;
    },
    focus() {
      if (!this.ranged) {
        this.$refs.reference.focus();
      } else {
        this.handleFocus();
      }
    },
    blur() {
      this.refInput.forEach((input) => input.blur());
    },
    parseValue(value) {
      const isParsed = isDateObject(value) || Array.isArray(value) && value.every(isDateObject);
      if (this.valueFormat && !isParsed) {
        return parseAsFormatAndType(value, this.valueFormat, this.type, this.rangeSeparator) || value;
      } else {
        return value;
      }
    },
    formatToValue(date) {
      const isFormattable = isDateObject(date) || Array.isArray(date) && date.every(isDateObject);
      if (this.valueFormat && isFormattable) {
        return formatAsFormatAndType(date, this.valueFormat, this.type, this.rangeSeparator);
      } else {
        return date;
      }
    },
    parseString(value) {
      const type = Array.isArray(value) ? this.type : this.type.replace("range", "");
      return parseAsFormatAndType(value, this.format, type);
    },
    formatToString(value) {
      const type = Array.isArray(value) ? this.type : this.type.replace("range", "");
      return formatAsFormatAndType(value, this.format, type);
    },
    handleMouseEnter() {
      if (this.readonly || this.pickerDisabled) {
        return;
      }
      if (!this.valueIsEmpty && this.clearable) {
        this.showClose = true;
      }
    },
    dateTextTrimStartWithZero(text) {
      try {
        const list = text.split("-");
        return list.map((item) => {
          if (item[0] === "0") {
            const trimItem = item.slice(1, item.length);
            return trimItem;
          } else {
            return item;
          }
        }).join("-");
      } catch (error) {
        return text;
      }
    },
    handleChange() {
      if (this.userInput) {
        const value = this.parseString(this.dateTextTrimStartWithZero(this.displayValue));
        if (value) {
          this.picker.value = value;
          if (this.isValidValue(value)) {
            this.emitInput(value);
            this.userInput = null;
          }
        }
      }
      if (this.userInput === "") {
        this.emitInput(null);
        this.emitChange(null);
        this.userInput = null;
      }
    },
    handleStartInput(event) {
      if (this.userInput) {
        this.userInput = [event.target.value, this.userInput[1]];
      } else {
        this.userInput = [event.target.value, null];
      }
    },
    handleEndInput(event) {
      if (this.userInput) {
        this.userInput = [this.userInput[0], event.target.value];
      } else {
        this.userInput = [null, event.target.value];
      }
    },
    handleStartChange() {
      const value = this.parseString(this.userInput && this.userInput[0]);
      if (value) {
        this.userInput = [this.formatToString(value), this.displayValue[1]];
        const newValue = [value, this.picker.value && this.picker.value[1]];
        this.picker.value = newValue;
        if (this.isValidValue(newValue)) {
          this.emitInput(newValue);
          this.userInput = null;
        }
      }
    },
    handleEndChange() {
      const value = this.parseString(this.userInput && this.userInput[1]);
      if (value) {
        this.userInput = [this.displayValue[0], this.formatToString(value)];
        const newValue = [this.picker.value && this.picker.value[0], value];
        this.picker.value = newValue;
        if (this.isValidValue(newValue)) {
          this.emitInput(newValue);
          this.userInput = null;
        }
      }
    },
    handleClickIcon(event) {
      if (this.readonly || this.pickerDisabled) {
        return;
      }
      if (this.showClose) {
        this.valueOnOpen = this.value;
        event.stopPropagation();
        this.emitInput(null);
        this.emitChange(null);
        this.showClose = false;
        if (this.picker && typeof this.picker.handleClear === "function") {
          this.picker.handleClear();
        }
      } else {
        this.pickerVisible = !this.pickerVisible;
      }
    },
    handleClose() {
      if (!this.pickerVisible) {
        return;
      }
      this.pickerVisible = false;
      if (this.type === "dates") {
        const oldValue = parseAsFormatAndType(this.valueOnOpen, this.valueFormat, this.type, this.rangeSeparator) || this.valueOnOpen;
        this.emitInput(oldValue);
      }
    },
    handleFieldReset(initialValue) {
      this.userInput = initialValue === "" ? null : initialValue;
    },
    handleFocus() {
      const type = this.type;
      if (HAVE_TRIGGER_TYPES.indexOf(type) !== -1 && !this.pickerVisible) {
        this.pickerVisible = true;
      }
      this.$emit("focus", this);
    },
    handleKeydown(event) {
      const keyCode = event.keyCode;
      if (keyCode === 27) {
        this.pickerVisible = false;
        event.stopPropagation();
        return;
      }
      if (keyCode === 9) {
        if (!this.ranged) {
          this.handleChange();
          this.pickerVisible = this.picker.visible = false;
          this.blur();
          event.stopPropagation();
        } else {
          setTimeout(() => {
            if (this.refInput.indexOf(document.activeElement) === -1) {
              this.pickerVisible = false;
              this.blur();
              event.stopPropagation();
            }
          }, 0);
        }
        return;
      }
      if (keyCode === 13) {
        if (this.userInput === "" || this.isValidValue(this.parseString(this.displayValue))) {
          this.handleChange();
          this.pickerVisible = this.picker.visible = false;
          this.blur();
        }
        event.stopPropagation();
        return;
      }
      if (this.userInput) {
        event.stopPropagation();
        return;
      }
      if (this.picker && this.picker.handleKeydown) {
        this.picker.handleKeydown(event);
      }
    },
    handleRangeClick() {
      const type = this.type;
      if (HAVE_TRIGGER_TYPES.indexOf(type) !== -1 && !this.pickerVisible) {
        this.pickerVisible = true;
      }
      this.$emit("focus", this);
    },
    hidePicker() {
      if (this.picker) {
        this.picker.resetView && this.picker.resetView();
        this.pickerVisible = this.picker.visible = false;
        this.destroyPopper();
      }
    },
    showPicker() {
      if (this.$isServer) {
        return;
      }
      if (!this.picker) {
        this.mountPicker();
      }
      this.pickerVisible = this.picker.visible = true;
      this.updatePopper();
      this.picker.value = this.parsedValue;
      this.picker.resetView && this.picker.resetView();
      this.$nextTick(() => {
        this.picker.adjustSpinners && this.picker.adjustSpinners();
      });
    },
    mountPicker() {
      const Vue = this.constructor.super;
      this.picker = new Vue(this.panel).$mount();
      this.picker.defaultValue = this.defaultValue;
      this.picker.defaultTime = this.defaultTime;
      this.picker.popperClass = this.popperClass;
      this.popperElm = this.picker.$el;
      this.picker.width = this.reference.getBoundingClientRect().width;
      this.picker.showTime = this.type === "datetime" || this.type === "datetimerange";
      this.picker.selectionMode = this.selectionMode;
      this.picker.unlinkPanels = this.unlinkPanels;
      this.picker.arrowControl = this.arrowControl || this.timeArrowControl || false;
      this.picker.useLocalMaxtime = this.useLocalMaxtime;
      this.$watch("format", (format) => {
        this.picker.format = format;
      });
      this.picker.showSecond = this.showSecond;
      const updateOptions = () => {
        const options = Object.assign(
          {
            disabledDate: defaultDisabledDate
          },
          this.pickerOptions
        );
        if (options && options.selectableRange) {
          let ranges = options.selectableRange;
          const parser = TYPE_VALUE_RESOLVER_MAP.datetimerange.parser;
          const format = DEFAULT_FORMATS.timerange;
          ranges = Array.isArray(ranges) ? ranges : [ranges];
          this.picker.selectableRange = ranges.map((range2) => parser(range2, format, this.rangeSeparator));
        }
        for (const option in options) {
          if (options.hasOwnProperty(option) && option !== "selectableRange") {
            this.picker[option] = options[option];
          }
        }
        if (this.format) {
          this.picker.format = this.format;
        }
      };
      updateOptions();
      this.unwatchPickerOptions = this.$watch("pickerOptions", () => updateOptions(), { deep: true });
      this.$el.appendChild(this.picker.$el);
      this.picker.resetView && this.picker.resetView();
      this.picker.$on("dodestroy", this.doDestroy);
      this.picker.$on("pick", this.pick);
      this.picker.$on("close", this.handleClose);
      this.picker.$on("select-range", (start, end, pos) => {
        if (this.refInput.length === 0) {
          return;
        }
        if (!pos || pos === "min") {
          this.refInput[0].setSelectionRange(start, end);
          this.refInput[0].focus();
        } else if (pos === "max") {
          this.refInput[1].setSelectionRange(start, end);
          this.refInput[1].focus();
        }
      });
      this.picker.$on("select-start", (val) => {
        this.$emit("select-start", val);
      });
      this.picker.$on("select-end", (val) => {
        this.$emit("select-end", val);
      });
    },
    unmountPicker() {
      if (this.picker) {
        this.picker.$destroy();
        this.picker.$off();
        if (typeof this.unwatchPickerOptions === "function") {
          this.unwatchPickerOptions();
        }
        this.picker.$el.parentNode.removeChild(this.picker.$el);
      }
    },
    emitChange(val) {
      if (!valueEquals(val, this.valueOnOpen)) {
        this.$emit("change", val);
        this.valueOnOpen = val;
      }
    },
    emitInput(val) {
      const formatted = this.formatToValue(val);
      if (!valueEquals(this.value, formatted)) {
        this.$emit("input", formatted);
      }
    },
    isValidValue(value) {
      if (!this.picker) {
        this.mountPicker();
      }
      if (this.picker.isValidValue) {
        return value && this.picker.isValidValue(value);
      } else {
        return true;
      }
    },
    getData() {
      return this.currentValue;
    },
    pick(date = "", visible = false) {
      if (!this.picker) {
        this.mountPicker();
      }
      this.userInput = null;
      this.pickerVisible = this.picker.visible = visible;
      this.emitInput(date);
      this.picker.resetView && this.picker.resetView();
    },
    reset() {
      if (this.defaultValue) {
        this.pick(this.defaultValue);
        this.currentValue = this.defaultValue;
        return;
      }
      this.currentValue = null;
      if (this.picker && typeof this.picker.handleClear === "function") {
        this.picker.handleClear();
      }
    },
    processRule(rule) {
      rule.getFieldValue = () => {
        return this.getData();
      };
      return rule;
    }
  }
};
const __vue_script__$9 = script$9;
var __vue_render__$9 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return !_vm.ranged ? _c(
    "sf-input",
    _vm._b(
      {
        directives: [
          {
            name: "clickoutside",
            rawName: "v-clickoutside",
            value: _vm.handleClose,
            expression: "handleClose"
          }
        ],
        ref: "reference",
        class: [
          _vm.getPrefixedClassName("el-date-editor"),
          _vm.getPrefixedClassName("el-date-editor--" + _vm.type),
          _vm.pickerVisible ? _vm.getPrefixedClassName("is-active") : ""
        ],
        attrs: {
          readonly: !_vm.editable || _vm.readonly || _vm.type === "dates",
          disabled: _vm.pickerDisabled,
          "allow-blank": _vm.allowBlank,
          size: _vm.pickerSize,
          name: _vm.name,
          placeholder: _vm.placeholder,
          value: _vm.displayValue,
          validateEvent: false,
          utid: _vm.getFullUtid("date-input")
        },
        on: {
          focus: _vm.handleFocus,
          input: function(value) {
            return _vm.userInput = value;
          },
          change: _vm.handleChange
        },
        nativeOn: {
          keydown: function($event) {
            return _vm.handleKeydown($event);
          },
          mouseenter: function($event) {
            return _vm.handleMouseEnter($event);
          },
          mouseleave: function($event) {
            _vm.showClose = false;
          }
        }
      },
      "sf-input",
      _vm.firstInputId,
      false
    ),
    [
      _c("i", {
        class: [
          _vm.getPrefixedClassName("el-input__icon"),
          _vm.triggerClass
        ],
        attrs: { slot: "suffix" },
        on: { click: _vm.handleClickIcon },
        slot: "suffix"
      })
    ]
  ) : _c(
    "div",
    {
      directives: [
        {
          name: "clickoutside",
          rawName: "v-clickoutside",
          value: _vm.handleClose,
          expression: "handleClose"
        }
      ],
      ref: "reference",
      class: [
        _vm.getPrefixedClassName("el-date-editor"),
        _vm.getPrefixedClassName("el-range-editor"),
        _vm.getPrefixedClassName("el-input__inner"),
        _vm.getPrefixedClassName("el-date-editor--" + _vm.type),
        _vm.pickerSize ? _vm.getPrefixedClassName("el-range-editor--" + _vm.pickerSize) : "",
        _vm.pickerDisabled ? _vm.getPrefixedClassName("is-disabled") : "",
        _vm.pickerVisible ? _vm.getPrefixedClassName("is-active") : ""
      ],
      on: {
        click: _vm.handleRangeClick,
        mouseenter: _vm.handleMouseEnter,
        mouseleave: function($event) {
          _vm.showClose = false;
        },
        keydown: _vm.handleKeydown
      }
    },
    [
      !_vm.value || !_vm.value.length ? _c(
        "div",
        {
          class: _vm.getPrefixedClassName(
            "el-range-editor__placeholder"
          )
        },
        [_vm._v(_vm._s(_vm.placeholder || _vm.startPlaceholder))]
      ) : [
        _c(
          "input",
          _vm._b(
            {
              class: _vm.getPrefixedClassName("el-range-input"),
              attrs: {
                autocomplete: "off",
                placeholder: _vm.startPlaceholder,
                disabled: _vm.pickerDisabled,
                readonly: !_vm.editable || _vm.readonly,
                name: _vm.name && _vm.name[0],
                "style-key": "input"
              },
              domProps: {
                value: _vm.displayValue && _vm.displayValue[0]
              },
              on: {
                input: _vm.handleStartInput,
                change: _vm.handleStartChange,
                focus: _vm.handleFocus
              }
            },
            "input",
            _vm.firstInputId,
            false
          )
        ),
        _vm._v(" "),
        _c(
          "span",
          { class: _vm.getPrefixedClassName("el-range-separator") },
          [_vm._v(_vm._s(_vm.displayValue ? _vm.rangeSeparator : ""))]
        ),
        _vm._v(" "),
        _c(
          "input",
          _vm._b(
            {
              class: _vm.getPrefixedClassName("el-range-input"),
              attrs: {
                autocomplete: "off",
                placeholder: _vm.endPlaceholder,
                disabled: _vm.pickerDisabled,
                readonly: !_vm.editable || _vm.readonly,
                name: _vm.name && _vm.name[1],
                "style-key": "input"
              },
              domProps: {
                value: _vm.displayValue && _vm.displayValue[1]
              },
              on: {
                input: _vm.handleEndInput,
                change: _vm.handleEndChange,
                focus: _vm.handleFocus
              }
            },
            "input",
            _vm.secondInputId,
            false
          )
        )
      ],
      _vm._v(" "),
      _c("i", {
        class: [
          _vm.getPrefixedClassName("el-input__icon"),
          _vm.getPrefixedClassName("el-range__icon"),
          _vm.triggerClass
        ],
        on: { click: _vm.handleClickIcon }
      })
    ],
    2
  );
};
var __vue_staticRenderFns__$9 = [];
__vue_render__$9._withStripped = true;
const __vue_inject_styles__$9 = void 0;
const __vue_scope_id__$9 = void 0;
const __vue_module_identifier__$9 = void 0;
const __vue_is_functional_template__$9 = false;
const __vue_component__$9 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$9, staticRenderFns: __vue_staticRenderFns__$9 },
  __vue_inject_styles__$9,
  __vue_script__$9,
  __vue_scope_id__$9,
  __vue_is_functional_template__$9,
  __vue_module_identifier__$9,
  false,
  void 0,
  void 0,
  void 0
);
var Locale = {
  methods: {
    t(...args) {
      return t$1.apply(this, [$i, ...args]);
    }
  }
};
const WEEKS = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
const clearHours = function(time) {
  const cloneDate = new Date(time);
  cloneDate.setHours(0, 0, 0, 0);
  return cloneDate.getTime();
};
const removeFromArray = function(arr, pred) {
  const idx = typeof pred === "function" ? arrayFindIndex(arr, pred) : arr.indexOf(pred);
  return idx >= 0 ? [...arr.slice(0, idx), ...arr.slice(idx + 1)] : arr;
};
var script$8 = {
  mixins: [Locale],
  props: {
    firstDayOfWeek: {
      default: 7,
      type: Number,
      validator: (val) => val >= 1 && val <= 7
    },
    value: {},
    defaultValue: {
      validator(val) {
        return val === null || isDate(val) || Array.isArray(val) && val.every(isDate);
      }
    },
    date: {},
    selectionMode: {
      default: "day"
    },
    mixSelect: {
      type: Boolean,
      default: false
    },
    showWeekNumber: {
      type: Boolean,
      default: false
    },
    disabledDate: {},
    minDate: {},
    maxDate: {},
    rangeState: {
      default() {
        return {
          endDate: null,
          selecting: false,
          row: null,
          column: null
        };
      }
    }
  },
  data() {
    return {
      tableRows: [[], [], [], [], [], []]
    };
  },
  computed: {
    offsetDay() {
      const week = this.firstDayOfWeek;
      return week > 3 ? 7 - week : -week;
    },
    WEEKS() {
      const week = this.firstDayOfWeek;
      return WEEKS.concat(WEEKS).slice(week, week + 7);
    },
    year() {
      var _a;
      return ((_a = this.value) == null ? void 0 : _a[0]) ? this.value[0].getFullYear() : this.date.getFullYear();
    },
    month() {
      var _a;
      return ((_a = this.value) == null ? void 0 : _a[0]) ? this.value[0].getMonth() : this.date.getMonth();
    },
    startDate() {
      return getStartDateOfMonth(this.year, this.month);
    },
    rows() {
      const date = new Date(this.year, this.month, 1);
      let day = getFirstDayOfMonth(date);
      const dateCountOfMonth = getDayCountOfMonth(date.getFullYear(), date.getMonth());
      const dateCountOfLastMonth = getDayCountOfMonth(
        date.getFullYear(),
        date.getMonth() === 0 ? 11 : date.getMonth() - 1
      );
      day = day === 0 ? 7 : day;
      const offset = this.offsetDay;
      const rows = this.tableRows;
      let count = 1;
      let firstDayPosition;
      const startDate = this.startDate;
      const disabledDate = this.disabledDate;
      const selectedDate = this.selectionMode === "dates" ? coerceTruthyValueToArray(this.value) : [];
      const now = clearHours(new Date());
      for (let i = 0; i < 6; i++) {
        const row = rows[i];
        if (this.showWeekNumber) {
          if (!row[0]) {
            row[0] = { type: "week", text: getWeekNumber(nextDate(startDate, i * 7 + 1)) };
          }
        }
        for (let j = 0; j < 7; j++) {
          let cell = row[this.showWeekNumber ? j + 1 : j];
          if (!cell) {
            cell = { row: i, column: j, type: "normal", inRange: false, start: false, end: false };
          }
          cell.type = "normal";
          const index = i * 7 + j;
          const time = nextDate(startDate, index - offset).getTime();
          cell.inRange = time >= clearHours(this.minDate) && time <= clearHours(this.maxDate);
          cell.start = this.minDate && time === clearHours(this.minDate);
          cell.end = this.maxDate && time === clearHours(this.maxDate);
          const isToday = time === now;
          if (isToday) {
            cell.type = "today";
          }
          if (i >= 0 && i <= 1) {
            if (j + i * 7 >= day + offset) {
              cell.text = count++;
              if (count === 2) {
                firstDayPosition = i * 7 + j;
              }
            } else {
              cell.text = dateCountOfLastMonth - (day + offset - j % 7) + 1 + i * 7;
              cell.type = "prev-month";
            }
          } else {
            if (count <= dateCountOfMonth) {
              cell.text = count++;
              if (count === 2) {
                firstDayPosition = i * 7 + j;
              }
            } else {
              cell.text = count++ - dateCountOfMonth;
              cell.type = "next-month";
            }
          }
          const cellDate = new Date(time);
          cell.disabled = typeof disabledDate === "function" && disabledDate(cellDate);
          cell.selected = arrayFind(selectedDate, (date2) => date2.getTime() === cellDate.getTime());
          this.$set(row, this.showWeekNumber ? j + 1 : j, cell);
        }
        if (this.selectionMode === "week") {
          const start = this.showWeekNumber ? 1 : 0;
          const end = this.showWeekNumber ? 7 : 6;
          const isWeekActive = this.mixSelect ? this.isWeekActive(row[start]) : this.isWeekActive(row[start + 1]);
          row[start].inRange = isWeekActive;
          row[start].start = isWeekActive;
          row[end].inRange = isWeekActive;
          row[end].end = isWeekActive;
        }
      }
      rows.firstDayPosition = firstDayPosition;
      return rows;
    }
  },
  watch: {
    "rangeState.endDate"(newVal) {
      this.markRange(newVal);
    },
    minDate(newVal, oldVal) {
      if (newVal && !oldVal) {
        this.rangeState.selecting = true;
        this.markRange(newVal);
      } else if (!newVal) {
        this.rangeState.selecting = false;
        this.markRange(newVal);
      } else {
        this.markRange();
      }
    },
    maxDate(newVal, oldVal) {
      if (newVal && !oldVal) {
        this.rangeState.selecting = false;
        this.markRange(newVal);
      }
    }
  },
  methods: {
    getPrefixedClassName,
    cellMatchesDate(cell, date) {
      const value = new Date(date);
      return this.year === value.getFullYear() && this.month === value.getMonth() && Number(cell.text) === value.getDate();
    },
    getCellClasses(cell) {
      const selectionMode = this.selectionMode;
      const defaultValue = this.defaultValue ? Array.isArray(this.defaultValue) ? this.defaultValue : [this.defaultValue] : [];
      const classes = [];
      if ((cell.type === "normal" || cell.type === "today") && !cell.disabled) {
        classes.push(getPrefixedClassName("available"));
        if (cell.type === "today") {
          classes.push(getPrefixedClassName("today"));
        }
      } else {
        classes.push(getPrefixedClassName(cell.type));
      }
      if (cell.type === "normal" && defaultValue.some((date) => this.cellMatchesDate(cell, date))) {
        classes.push(getPrefixedClassName("default"));
      }
      if (selectionMode === "day" && (cell.type === "normal" || cell.type === "today") && this.cellMatchesDate(cell, this.mixSelect ? this.value[0] : this.value)) {
        classes.push(getPrefixedClassName("current"));
      }
      if (cell.inRange && (cell.type === "normal" || cell.type === "today" || this.selectionMode === "week")) {
        classes.push(getPrefixedClassName("in-range"));
        if (cell.start) {
          classes.push(getPrefixedClassName("start-date"));
        }
        if (cell.end) {
          classes.push(getPrefixedClassName("end-date"));
        }
      }
      if (cell.disabled) {
        classes.push(getPrefixedClassName("disabled"));
      }
      if (cell.selected) {
        classes.push(getPrefixedClassName("selected"));
      }
      return classes.join(" ");
    },
    getDateOfCell(row, column) {
      const offsetFromStart = row * 7 + (column - (this.showWeekNumber ? 1 : 0)) - this.offsetDay;
      return nextDate(this.startDate, offsetFromStart);
    },
    isWeekActive(cell) {
      var _a, _b;
      if (this.selectionMode !== "week") {
        return false;
      }
      const newDate = new Date(this.year, this.month, 1);
      const year = newDate.getFullYear();
      const month = newDate.getMonth();
      if (cell.type === "prev-month") {
        newDate.setMonth(month === 0 ? 11 : month - 1);
        newDate.setFullYear(month === 0 ? year - 1 : year);
      }
      if (cell.type === "next-month") {
        newDate.setMonth(month === 11 ? 0 : month + 1);
        newDate.setFullYear(month === 11 ? year + 1 : year);
      }
      newDate.setDate(parseInt(cell.text, 10));
      if (this.mixSelect) {
        const valueYear2 = ((_b = (_a = this.value) == null ? void 0 : _a[0]) == null ? void 0 : _b.getFullYear()) || null;
        return year === valueYear2 && newDate.getTime() === this.value[0].getTime();
      }
      const valueYear = isDate(this.value) ? this.value.getFullYear() : null;
      return year === valueYear && getWeekNumber(newDate) === getWeekNumber(this.value);
    },
    markRange(maxDate) {
      const startDate = this.startDate;
      if (!maxDate) {
        maxDate = this.maxDate;
      }
      const rows = this.rows;
      const minDate = this.minDate;
      for (let i = 0, k = rows.length; i < k; i++) {
        const row = rows[i];
        for (let j = 0, l = row.length; j < l; j++) {
          if (this.showWeekNumber && j === 0) {
            continue;
          }
          const cell = row[j];
          const index = i * 7 + j + (this.showWeekNumber ? -1 : 0);
          const time = nextDate(startDate, index - this.offsetDay).getTime();
          if (maxDate && maxDate < minDate) {
            cell.inRange = minDate && time >= clearHours(maxDate) && time <= clearHours(minDate);
            cell.start = maxDate && time === clearHours(maxDate.getTime());
            cell.end = minDate && time === clearHours(minDate.getTime());
          } else {
            cell.inRange = minDate && time >= clearHours(minDate) && time <= clearHours(maxDate);
            cell.start = minDate && time === clearHours(minDate.getTime());
            cell.end = maxDate && time === clearHours(maxDate.getTime());
          }
        }
      }
    },
    handleMouseMove(event) {
      if (!this.rangeState.selecting) {
        return;
      }
      this.$emit("changerange", {
        minDate: this.minDate,
        maxDate: this.maxDate,
        rangeState: this.rangeState
      });
      let target = event.target;
      if (target.tagName === "SPAN") {
        target = target.parentNode.parentNode;
      }
      if (target.tagName === "DIV") {
        target = target.parentNode;
      }
      if (target.tagName !== "TD") {
        return;
      }
      const column = target.cellIndex;
      const row = target.parentNode.rowIndex - 1;
      const { row: oldRow, column: oldColumn } = this.rangeState;
      if (oldRow !== row || oldColumn !== column) {
        this.rangeState.row = row;
        this.rangeState.column = column;
        this.rangeState.endDate = this.getDateOfCell(row, column);
      }
    },
    handleClick(event) {
      let target = event.target;
      if (target.tagName === "SPAN") {
        target = target.parentNode.parentNode;
      }
      if (target.tagName === "DIV") {
        target = target.parentNode;
      }
      if (target.tagName !== "TD") {
        return;
      }
      if (hasClass(target, "disabled") || hasClass(target, "week")) {
        return;
      }
      const selectionMode = this.selectionMode;
      if (selectionMode === "week") {
        target = target.parentNode.cells[1];
      }
      let year = Number(this.year);
      let month = Number(this.month);
      const cellIndex = target.cellIndex;
      const rowIndex = target.parentNode.rowIndex;
      const cell = this.rows[rowIndex - 1][cellIndex];
      const text = cell.text;
      const className = target.className;
      const newDate = new Date(year, month, 1);
      if (className.indexOf("prev") !== -1) {
        if (month === 0) {
          year = year - 1;
          month = 11;
        } else {
          month = month - 1;
        }
        newDate.setFullYear(year);
        newDate.setMonth(month);
      } else if (className.indexOf("next") !== -1) {
        if (month === 11) {
          year = year + 1;
          month = 0;
        } else {
          month = month + 1;
        }
        newDate.setFullYear(year);
        newDate.setMonth(month);
      }
      newDate.setDate(parseInt(text, 10));
      if (this.selectionMode === "range") {
        if (this.minDate && this.maxDate) {
          const minDate = new Date(newDate.getTime());
          const maxDate = null;
          this.$emit("pick", { minDate, maxDate }, false);
          this.rangeState.selecting = true;
          this.markRange(this.minDate);
          this.$nextTick(() => {
            this.handleMouseMove(event);
          });
        } else if (this.minDate && !this.maxDate) {
          if (newDate >= this.minDate) {
            const maxDate = new Date(newDate.getTime());
            this.rangeState.selecting = false;
            this.$emit("pick", {
              minDate: this.minDate,
              maxDate
            });
          } else {
            const minDate = new Date(newDate.getTime());
            this.rangeState.selecting = false;
            this.$emit("pick", { minDate, maxDate: this.minDate });
          }
        } else if (!this.minDate) {
          const minDate = new Date(newDate.getTime());
          this.$emit("pick", { minDate, maxDate: this.maxDate }, false);
          this.rangeState.selecting = true;
          this.markRange(this.minDate);
        }
      } else if (selectionMode === "day") {
        if (this.mixSelect) {
          const minDate = modifyTime(newDate, 0, 0, 0);
          const maxDate = modifyTime(newDate, 23, 59, 59);
          this.$emit("pick", { minDate, maxDate });
          return;
        }
        this.$emit("pick", newDate);
      } else if (selectionMode === "week") {
        if (this.mixSelect) {
          const [minDate, maxDate] = getWeekStartAndEnd(newDate);
          this.$emit("pick", { minDate, maxDate });
          return;
        }
        const weekNumber = getWeekNumber(newDate);
        const value = newDate.getFullYear() + "w" + weekNumber;
        this.$emit("pick", {
          year: newDate.getFullYear(),
          week: weekNumber,
          value,
          date: newDate
        });
      } else if (selectionMode === "dates") {
        const value = this.value || [];
        const newValue = cell.selected ? removeFromArray(value, (date) => date.getTime() === newDate.getTime()) : [...value, newDate];
        this.$emit("pick", newValue);
      }
    }
  }
};
const __vue_script__$8 = script$8;
var __vue_render__$8 = function() {
  var _obj;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "table",
    {
      class: [
        _vm.getPrefixedClassName("el-date-table"),
        (_obj = {}, _obj[_vm.getPrefixedClassName("is-week-mode")] = _vm.selectionMode === "week", _obj)
      ],
      attrs: { cellspacing: "0", cellpadding: "0" },
      on: { click: _vm.handleClick, mousemove: _vm.handleMouseMove }
    },
    [
      _c(
        "tbody",
        [
          _c(
            "tr",
            { class: _vm.getPrefixedClassName("el-date-table__week-row") },
            [
              _vm.showWeekNumber ? _c("th", [_vm._v(_vm._s(_vm.t("el.datepicker.week")))]) : _vm._e(),
              _vm._v(" "),
              _vm._l(_vm.WEEKS, function(week, key) {
                return _c("th", { key }, [
                  _vm._v(_vm._s(_vm.t("el.datepicker.weeks." + week)))
                ]);
              })
            ],
            2
          ),
          _vm._v(" "),
          _vm._l(_vm.rows, function(row, key) {
            return _c(
              "tr",
              {
                key,
                class: [
                  _vm.getPrefixedClassName("el-date-table__row"),
                  _vm.isWeekActive(_vm.mixSelect ? row[0] : row[1]) ? _vm.getPrefixedClassName("current") : ""
                ]
              },
              _vm._l(row, function(cell, cellKey) {
                return _c(
                  "td",
                  { key: cellKey, class: _vm.getCellClasses(cell) },
                  [
                    _c("div", [
                      _c("span", [
                        _vm._v(
                          "\n            " + _vm._s(cell.text) + "\n          "
                        )
                      ])
                    ])
                  ]
                );
              }),
              0
            );
          })
        ],
        2
      )
    ]
  );
};
var __vue_staticRenderFns__$8 = [];
__vue_render__$8._withStripped = true;
const __vue_inject_styles__$8 = void 0;
const __vue_scope_id__$8 = void 0;
const __vue_module_identifier__$8 = void 0;
const __vue_is_functional_template__$8 = false;
const __vue_component__$8 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$8, staticRenderFns: __vue_staticRenderFns__$8 },
  __vue_inject_styles__$8,
  __vue_script__$8,
  __vue_scope_id__$8,
  __vue_is_functional_template__$8,
  __vue_module_identifier__$8,
  false,
  void 0,
  void 0,
  void 0
);
const datesInMonth = (year, month) => {
  const numOfDays = getDayCountOfMonth(year, month);
  const firstDay = new Date(year, month, 1);
  return range(numOfDays).map((n) => nextDate(firstDay, n));
};
var script$7 = {
  mixins: [Locale],
  props: {
    disabledDate: {},
    value: {},
    defaultValue: {
      validator(val) {
        return val === null || val instanceof Date && isDate(val);
      }
    },
    date: {}
  },
  data() {
    return {
      scheme: [3, 4],
      monthList: Object.values(lang($i).el.datepicker.months)
    };
  },
  methods: {
    getPrefixedClassName,
    getCellStyle(month) {
      var _a, _b, _c;
      const style = {};
      const year = (_c = (_b = (_a = this.value) == null ? void 0 : _a[0]) == null ? void 0 : _b.getFullYear()) != null ? _c : this.date.getFullYear();
      const today = new Date();
      style[getPrefixedClassName("disabled")] = typeof this.disabledDate === "function" ? datesInMonth(year, month).every(this.disabledDate) : false;
      style[getPrefixedClassName("current")] = arrayFindIndex(
        coerceTruthyValueToArray(this.value),
        (date) => date.getFullYear() === year && date.getMonth() === month
      ) >= 0;
      style[getPrefixedClassName("today")] = today.getFullYear() === year && today.getMonth() === month;
      style[getPrefixedClassName("default")] = this.defaultValue && this.defaultValue.getFullYear() === year && this.defaultValue.getMonth() === month;
      return style;
    },
    handleMonthTableClick(event) {
      const target = event.target;
      if (target.tagName !== "A") {
        return;
      }
      if (hasClass(target.parentNode, "disabled")) {
        return;
      }
      const column = target.parentNode.cellIndex;
      const row = target.parentNode.parentNode.rowIndex;
      const month = row * this.scheme[0] + column;
      this.$emit("pick", month);
    }
  }
};
const __vue_script__$7 = script$7;
var __vue_render__$7 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "table",
    {
      class: _vm.getPrefixedClassName("el-month-table"),
      on: { click: _vm.handleMonthTableClick }
    },
    [
      _c(
        "tbody",
        _vm._l(_vm.scheme[1], function(i) {
          return _c(
            "tr",
            { key: i },
            _vm._l(_vm.scheme[0], function(j) {
              return _c(
                "td",
                {
                  directives: [
                    {
                      name: "show",
                      rawName: "v-show",
                      value: (i - 1) * _vm.scheme[0] + j - 1 < _vm.monthList.length,
                      expression: "(i - 1) * scheme[0] + j - 1 < monthList.length"
                    }
                  ],
                  key: j,
                  class: [
                    _vm.getPrefixedClassName("available"),
                    _vm.getCellStyle((i - 1) * _vm.scheme[0] + j - 1)
                  ]
                },
                [
                  _c("a", { class: _vm.getPrefixedClassName("cell") }, [
                    _vm._v(
                      _vm._s(_vm.monthList[(i - 1) * _vm.scheme[0] + j - 1])
                    )
                  ])
                ]
              );
            }),
            0
          );
        }),
        0
      )
    ]
  );
};
var __vue_staticRenderFns__$7 = [];
__vue_render__$7._withStripped = true;
const __vue_inject_styles__$7 = void 0;
const __vue_scope_id__$7 = void 0;
const __vue_module_identifier__$7 = void 0;
const __vue_is_functional_template__$7 = false;
const __vue_component__$7 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$7, staticRenderFns: __vue_staticRenderFns__$7 },
  __vue_inject_styles__$7,
  __vue_script__$7,
  __vue_scope_id__$7,
  __vue_is_functional_template__$7,
  __vue_module_identifier__$7,
  false,
  void 0,
  void 0,
  void 0
);
const datesInYear = (year) => {
  const numOfDays = getDayCountOfYear(year);
  const firstDay = new Date(year, 0, 1);
  return range(numOfDays).map((n) => nextDate(firstDay, n));
};
var script$6 = {
  props: {
    disabledDate: {},
    value: {},
    defaultValue: {
      validator(val) {
        return val === null || val instanceof Date && isDate(val);
      }
    },
    date: {}
  },
  data() {
    return {
      scheme: [3, 4]
    };
  },
  computed: {
    startYear() {
      return Math.floor(this.date.getFullYear() / 10) * 10;
    }
  },
  methods: {
    getPrefixedClassName,
    getCellStyle(year) {
      const style = {};
      const today = new Date();
      style[getPrefixedClassName("disabled")] = typeof this.disabledDate === "function" ? datesInYear(year).every(this.disabledDate) : false;
      style[getPrefixedClassName("current")] = arrayFindIndex(coerceTruthyValueToArray(this.value), (date) => date.getFullYear() === year) >= 0;
      style[getPrefixedClassName("today")] = today.getFullYear() === year;
      style[getPrefixedClassName("default")] = this.defaultValue && this.defaultValue.getFullYear() === year;
      return style;
    },
    handleYearTableClick(event) {
      const target = event.target;
      if (target.tagName === "A") {
        if (hasClass(target.parentNode, "disabled")) {
          return;
        }
        const year = target.textContent || target.innerText;
        this.$emit("pick", Number(year));
      }
    }
  }
};
const __vue_script__$6 = script$6;
var __vue_render__$6 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "table",
    {
      class: _vm.getPrefixedClassName("el-year-table"),
      on: { click: _vm.handleYearTableClick }
    },
    [
      _c(
        "tbody",
        _vm._l(_vm.scheme[1], function(i) {
          return _c(
            "tr",
            { key: i },
            _vm._l(_vm.scheme[0], function(j) {
              return _c(
                "td",
                {
                  directives: [
                    {
                      name: "show",
                      rawName: "v-show",
                      value: (i - 1) * _vm.scheme[0] + j - 1 < 10,
                      expression: "(i - 1) * scheme[0] + j - 1 < 10"
                    }
                  ],
                  key: j,
                  class: [
                    _vm.getPrefixedClassName("available"),
                    _vm.getCellStyle(
                      _vm.startYear + (i - 1) * _vm.scheme[0] + j - 1
                    )
                  ]
                },
                [
                  _c("a", { class: _vm.getPrefixedClassName("cell") }, [
                    _vm._v(
                      _vm._s(_vm.startYear + (i - 1) * _vm.scheme[0] + j - 1)
                    )
                  ])
                ]
              );
            }),
            0
          );
        }),
        0
      )
    ]
  );
};
var __vue_staticRenderFns__$6 = [];
__vue_render__$6._withStripped = true;
const __vue_inject_styles__$6 = void 0;
const __vue_scope_id__$6 = void 0;
const __vue_module_identifier__$6 = void 0;
const __vue_is_functional_template__$6 = false;
const __vue_component__$6 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$6, staticRenderFns: __vue_staticRenderFns__$6 },
  __vue_inject_styles__$6,
  __vue_script__$6,
  __vue_scope_id__$6,
  __vue_is_functional_template__$6,
  __vue_module_identifier__$6,
  false,
  void 0,
  void 0,
  void 0
);
featureDetect();
function featureDetect() {
  let needsPoly2 = false;
  const overrideStyles = [
    {
      name: "float",
      value: "left"
    },
    {
      name: "paddingLeft",
      value: "0px"
    },
    {
      name: "paddingRight",
      value: "0px"
    },
    {
      name: "position",
      value: "absolute"
    },
    {
      name: "width",
      value: "0px"
    },
    {
      name: "borderRightWidth",
      value: "0px"
    },
    {
      name: "borderLeftWidth",
      value: "0px"
    },
    {
      name: "visibility",
      value: "hidden"
    }
  ];
  const ghostMeasureInput = createGhostElement("input", null, overrideStyles, "Test", true);
  if (ghostMeasureInput.scrollWidth == 0) {
    needsPoly2 = true;
  }
  return needsPoly2;
}
function createGhostElement(elType, computedStyles, overrideStyles, content, callScrollWidth) {
  elType = elType.toLowerCase();
  const id = "swMeasure-" + Date.now();
  let el = document.createElement(elType);
  el.id = id;
  const initStyle = el.style;
  if (computedStyles !== null) {
    const csKeys = Object.keys(computedStyles.__proto__);
    csKeys.forEach(function(prop) {
      initStyle[prop] = computedStyles[prop];
    });
    el.style = initStyle;
  }
  overrideStyles.forEach(function(overrideStyle) {
    el.style[overrideStyle.name] = overrideStyle.value;
  });
  if (elType == "input" || elType == "textarea") {
    el.value = content;
  } else {
    el.textContent = content;
  }
  document.getElementsByTagName("body")[0].appendChild(el);
  el = document.getElementById(id);
  const ghostMeasure = {
    scrollWidth: callScrollWidth ? el.scrollWidth : 0,
    clientWidth: parseInt(el.clientWidth, 10)
  };
  el.outerHTML = "";
  el = null;
  return ghostMeasure;
}
const on = function() {
  return function(element, event, handler) {
    if (element && event && handler) {
      element.addEventListener(event, handler, false);
    }
  };
}();
const off = function() {
  return function(element, event, handler) {
    if (element && event) {
      element.removeEventListener(event, handler, false);
    }
  };
}();
const { leftPad } = Format;
const KEY_CODE_MAP = {
  96: 0,
  97: 1,
  98: 2,
  99: 3,
  100: 4,
  101: 5,
  102: 6,
  103: 7,
  104: 8,
  105: 9,
  48: 0,
  49: 1,
  50: 2,
  51: 3,
  52: 4,
  53: 5,
  54: 6,
  55: 7,
  56: 8,
  57: 9
};
const DELAY = 130;
const TIME_LIMIT = {
  hour: "24",
  minute: "60",
  second: "60"
};
var script$5 = {
  name: componentName.timePicker,
  mixins: [ComponentMixin],
  componentName: componentName.timePicker,
  props: {
    showSecond: {
      type: Boolean,
      default: true
    },
    value: {
      type: [Object, String],
      default: function() {
        return {
          hour: 0,
          minute: 0,
          second: 0
        };
      }
    },
    valueFormat: {
      type: String
    }
  },
  data: function() {
    const defaultValue = this.value || this.$options.props.value.default();
    return {
      curItem: this.showSecond ? "second" : "minute",
      activeInput: false,
      hour: this.zeroLeftPad(defaultValue.hour || 0),
      minute: this.zeroLeftPad(defaultValue.minute || 0),
      second: this.zeroLeftPad(defaultValue.second || 0),
      isFirst: true
    };
  },
  computed: {
    calcClass() {
      const cls = [];
      if (this.activeInput) {
        cls.push(getPrefixedClassName("active"));
      }
      if (this.disabled) {
        cls.push(getPrefixedClassName("input-disable"));
      }
      if (this.invalidClass) {
        cls.push(getPrefixedClassName(this.invalidClass));
      }
      return cls;
    },
    valueTypeIsString() {
      return typeof this.value === "string";
    },
    currentValue() {
      var _a, _b, _c;
      return {
        hour: (_a = Number(this.hour)) != null ? _a : 0,
        minute: (_b = Number(this.minute)) != null ? _b : 0,
        ...this.showSecond ? { second: (_c = Number(this.second)) != null ? _c : 0 } : {}
      };
    }
  },
  watch: {
    value: {
      deep: true,
      immediate: true,
      handler(value) {
        if (this.valueTypeIsString) {
          const timeParts = value.split(":");
          this.hour = this.zeroLeftPad(this._safeParseInt(timeParts[0]));
          this.minute = this.zeroLeftPad(this._safeParseInt(timeParts[1]));
          if (this.showSecond) {
            this.second = this.zeroLeftPad(this._safeParseInt(timeParts[2]));
          }
        } else {
          this.hour = this.zeroLeftPad(value == null ? void 0 : value.hour);
          this.minute = this.zeroLeftPad(value == null ? void 0 : value.minute);
          this.second = this.zeroLeftPad(value == null ? void 0 : value.second);
        }
        if (this.isFirst) {
          this.isFirst = false;
          return;
        }
        this.$emit("change", this._formatValue(this.currentValue));
      }
    }
  },
  created: function() {
    this.isEntering = false;
    this.isArwEntering = false;
  },
  mounted: function() {
    on(document, "click", this._shouldFocus);
  },
  destroyed() {
    off(document, "click", this._shouldFocus);
  },
  methods: {
    getPrefixedClassName,
    getFullUtid(utidBase) {
      return this.$attrs.utid ? `${this.$attrs.utid}-${utidBase}` : utidBase;
    },
    _safeParseInt(value) {
      const defaultValue = 0;
      const parsedValue = parseInt(value || defaultValue, 10);
      return isNaN(parsedValue) ? defaultValue : parsedValue;
    },
    _shouldFocus(e) {
      if (this.disabled) {
        return;
      }
      const timeFieldDIV = this.$refs.timefield;
      if (timeFieldDIV.contains(e.target)) {
        return;
      }
      this.activeInput = false;
      this.curItem = this.showSecond ? "second" : "minute";
    },
    onAddMouseDown() {
      if (this.disabled) {
        return;
      }
      this.isArwEntering = true;
      this._addTime(true);
      this.moveInterval = window.setInterval(() => {
        this._addTime(true);
      }, DELAY);
    },
    onReduceMouseDown() {
      if (this.disabled) {
        return;
      }
      this.isArwEntering = true;
      this._addTime(false);
      this.moveInterval = window.setInterval(() => {
        this._addTime(false);
      }, DELAY);
    },
    onMouseUp() {
      if (this.disabled) {
        return;
      }
      this.$refs[this.curItem].focus();
      this.isArwEntering = false;
      window.clearInterval(this.moveInterval);
    },
    onMouseOut() {
      if (this.disabled) {
        return;
      }
      if (this.isArwEntering) {
        this.$refs[this.curItem].focus();
      }
      window.clearInterval(this.moveInterval);
    },
    zeroLeftPad(value = 0) {
      return leftPad(value, 2, "0");
    },
    _changeNum: function(e) {
      const keyCode = e.keyCode, curItem = this.curItem, enterValue = KEY_CODE_MAP[keyCode];
      e.preventDefault();
      if (keyCode === 8) {
        this[curItem] = "00";
        return;
      }
      if (keyCode >= 48 && keyCode <= 57 || keyCode >= 96 && keyCode <= 105) {
        if (this.isEntering) {
          const time = this[curItem][1] + enterValue;
          this[curItem] = time >= TIME_LIMIT[curItem] ? String(TIME_LIMIT[curItem] - 1) : time;
        } else {
          this.isEntering = true;
          this[curItem] = this.zeroLeftPad(enterValue);
        }
        return;
      }
      switch (keyCode) {
        case 37:
          if (this.curItem === "minute") {
            this.$refs.hour.focus();
          } else if (this.curItem === "second" && this.showSecond) {
            this.$refs.minute.focus();
          }
          break;
        case 39:
        case 9:
          if (this.curItem === "hour") {
            this.$refs.minute.focus();
          } else if (this.curItem === "minute" && this.showSecond) {
            this.$refs.second.focus();
          }
          break;
        case 38:
          this.isEntering = false;
          this._fixTime(1, true);
          break;
        case 40:
          this.isEntering = false;
          this._fixTime(-1, true);
          break;
      }
    },
    _fixTime: function(diffNum, fix2Min) {
      diffNum = diffNum || 0;
      const curItem = this.curItem, maxNum = curItem === "hour" ? 23 : 59;
      this[curItem] = +this[curItem] + diffNum;
      if (this[curItem] < 0) {
        this[curItem] = this.zeroLeftPad(maxNum);
        this._autoTime(curItem, fix2Min, false);
      } else if (this[curItem] > maxNum) {
        this[curItem] = fix2Min ? "00" : this.zeroLeftPad(maxNum);
        this._autoTime(curItem, fix2Min, true);
      } else {
        this[curItem] = this.zeroLeftPad(this[curItem]);
      }
    },
    _autoTime(curItem, flag, isAdd) {
      if (flag) {
        switch (curItem) {
          case "second":
            this._autoSecond(isAdd);
            break;
          case "minute":
            this._autoMinute(isAdd);
            break;
        }
      }
    },
    _autoSecond(isAdd) {
      const lastMin = isAdd ? "59" : "00";
      const nextMin = isAdd ? "00" : "59";
      const lastHour = isAdd ? "23" : "00";
      const nextHour = isAdd ? "00" : "23";
      if (this.minute === lastMin) {
        this.minute = nextMin;
        if (this.hour === lastHour) {
          this.hour = nextHour;
          return;
        }
        this.hour = this.zeroLeftPad(isAdd ? Number(this.hour) + 1 : Number(this.hour) - 1);
        return;
      }
      this.minute = this.zeroLeftPad(isAdd ? Number(this.minute) + 1 : Number(this.minute) - 1);
    },
    _autoMinute(isAdd) {
      const lastHour = isAdd ? "23" : "00";
      const nextHour = isAdd ? "00" : "23";
      if (this.hour === lastHour) {
        this.hour = nextHour;
        return;
      }
      this.hour = this.zeroLeftPad(isAdd ? Number(this.hour) + 1 : Number(this.hour) - 1);
    },
    _emitInput: function() {
      this.$emit("input", this._formatValue(this.currentValue));
    },
    _formatValue: function(value) {
      let formattedValue = value;
      if (this.valueFormat || this.valueTypeIsString) {
        formattedValue = formatTimeToString(value, this.valueFormat);
      }
      return formattedValue;
    },
    _focusInput: function(key) {
      this.$emit("closeFocus");
      this.curItem = key;
      this.isEntering = false;
      this.activeInput = true;
    },
    _blurInput: function() {
      this._fixTime(0);
      this._emitInput();
      this.isEntering = false;
    },
    _addTime: function(isAdd) {
      this._fixTime(isAdd !== false ? 1 : -1, true);
      this.activeInput = true;
    }
  }
};
const __vue_script__$5 = script$5;
var __vue_render__$5 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      directives: [
        {
          name: "show",
          rawName: "v-show",
          value: !_vm.hidden,
          expression: "!hidden"
        }
      ],
      ref: "timefield",
      class: [_vm.getPrefixedClassName("el-time-picker")].concat(_vm.calcClass),
      style: {
        width: typeof _vm.width === "number" ? _vm.width + "px" : _vm.width,
        height: _vm.height + "px"
      },
      attrs: { disabled: _vm.disabled }
    },
    [
      _c("input", {
        directives: [
          {
            name: "model",
            rawName: "v-model",
            value: _vm.hour,
            expression: "hour"
          }
        ],
        ref: "hour",
        class: _vm.getPrefixedClassName("el-time-picker_item"),
        attrs: {
          disabled: _vm.disabled,
          type: "text",
          utid: _vm.getFullUtid("time-picker-hour")
        },
        domProps: { value: _vm.hour },
        on: {
          keydown: _vm._changeNum,
          focus: function($event) {
            return _vm._focusInput("hour");
          },
          blur: function($event) {
            return _vm._blurInput("hour");
          },
          input: function($event) {
            if ($event.target.composing) {
              return;
            }
            _vm.hour = $event.target.value;
          }
        }
      }),
      _vm._v(" "),
      _c(
        "span",
        { class: _vm.getPrefixedClassName("el-time-picker_separator") },
        [_vm._v(":")]
      ),
      _vm._v(" "),
      _c("input", {
        directives: [
          {
            name: "model",
            rawName: "v-model",
            value: _vm.minute,
            expression: "minute"
          }
        ],
        ref: "minute",
        class: _vm.getPrefixedClassName("el-time-picker_item"),
        attrs: {
          disabled: _vm.disabled,
          type: "text",
          utid: _vm.getFullUtid("time-picker-minute")
        },
        domProps: { value: _vm.minute },
        on: {
          keydown: _vm._changeNum,
          focus: function($event) {
            return _vm._focusInput("minute");
          },
          blur: function($event) {
            return _vm._blurInput("minute");
          },
          input: function($event) {
            if ($event.target.composing) {
              return;
            }
            _vm.minute = $event.target.value;
          }
        }
      }),
      _vm._v(" "),
      _vm.showSecond ? [
        _c(
          "span",
          { class: _vm.getPrefixedClassName("el-time-picker_separator") },
          [_vm._v(":")]
        ),
        _vm._v(" "),
        _c("input", {
          directives: [
            {
              name: "model",
              rawName: "v-model",
              value: _vm.second,
              expression: "second"
            }
          ],
          ref: "second",
          class: _vm.getPrefixedClassName("el-time-picker_item"),
          attrs: {
            disabled: _vm.disabled,
            type: "text",
            utid: _vm.getFullUtid("time-picker-second")
          },
          domProps: { value: _vm.second },
          on: {
            keydown: _vm._changeNum,
            focus: function($event) {
              return _vm._focusInput("second");
            },
            blur: function($event) {
              return _vm._blurInput("second");
            },
            input: function($event) {
              if ($event.target.composing) {
                return;
              }
              _vm.second = $event.target.value;
            }
          }
        })
      ] : _vm._e(),
      _vm._v(" "),
      _c("div", { class: _vm.getPrefixedClassName("handle-btns") }, [
        _c(
          "div",
          {
            class: [
              _vm.getPrefixedClassName("handle-btn-box"),
              _vm.getPrefixedClassName("handle-btn-box-bottom")
            ],
            attrs: { utid: _vm.getFullUtid("time-picker-down-btn") },
            on: {
              mousedown: _vm.onReduceMouseDown,
              mouseup: _vm.onMouseUp,
              mouseout: _vm.onMouseOut
            }
          },
          [
            _c("span", {
              class: _vm.getPrefixedClassName("handle-btn-box__cover")
            }),
            _vm._v(" "),
            _c("i", {
              class: [
                "iconfont",
                "vtv-icon-comp-angle-down",
                _vm.getPrefixedClassName("btn-arw"),
                _vm.getPrefixedClassName("btn-arw-down")
              ],
              style: { lineHeight: _vm.height / 2 + "px" }
            })
          ]
        ),
        _vm._v(" "),
        _c(
          "div",
          {
            class: [
              _vm.getPrefixedClassName("handle-btn-box"),
              _vm.getPrefixedClassName("handle-btn-box-top")
            ],
            attrs: { utid: _vm.getFullUtid("time-picker-up-btn") },
            on: {
              mousedown: _vm.onAddMouseDown,
              mouseup: _vm.onMouseUp,
              mouseout: _vm.onMouseOut
            }
          },
          [
            _c("span", {
              class: _vm.getPrefixedClassName("handle-btn-box__cover")
            }),
            _vm._v(" "),
            _c("i", {
              class: [
                "iconfont",
                "vtv-icon-comp-angle-up",
                _vm.getPrefixedClassName("btn-arw"),
                _vm.getPrefixedClassName("btn-arw-up")
              ],
              style: { lineHeight: _vm.height / 2 + "px" }
            })
          ]
        )
      ])
    ],
    2
  );
};
var __vue_staticRenderFns__$5 = [];
__vue_render__$5._withStripped = true;
const __vue_inject_styles__$5 = void 0;
const __vue_scope_id__$5 = void 0;
const __vue_module_identifier__$5 = void 0;
const __vue_is_functional_template__$5 = false;
const __vue_component__$5 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$5, staticRenderFns: __vue_staticRenderFns__$5 },
  __vue_inject_styles__$5,
  __vue_script__$5,
  __vue_scope_id__$5,
  __vue_is_functional_template__$5,
  __vue_module_identifier__$5,
  false,
  void 0,
  void 0,
  void 0
);
var script$4 = {
  directives: { clickoutside: vClickoutside },
  components: {
    TimePicker: __vue_component__$5,
    YearTable: __vue_component__$6,
    MonthTable: __vue_component__$7,
    DateTable: __vue_component__$8,
    SfButton
  },
  mixins: [Locale],
  data() {
    return {
      popperClass: "",
      date: new Date(),
      value: "",
      defaultValue: null,
      defaultTime: null,
      showTime: false,
      selectionMode: "day",
      shortcuts: "",
      visible: false,
      currentView: "date",
      disabledDate: "",
      firstDayOfWeek: 7,
      showWeekNumber: false,
      format: "",
      arrowControl: false,
      userInputDate: null,
      isInternational: globalConfig.isInternational,
      showSecond: true
    };
  },
  computed: {
    year() {
      return this.date.getFullYear();
    },
    month() {
      return this.date.getMonth();
    },
    week() {
      return getWeekNumber(this.date);
    },
    monthDate() {
      return this.date.getDate();
    },
    footerVisible() {
      return this.showTime || this.selectionMode === "dates";
    },
    visibleTime() {
      let time;
      if (this.value) {
        time = new Date(this.value);
      } else if (this.defaultValue) {
        time = new Date(this.defaultValue);
      } else {
        time = new Date();
      }
      if (isNaN(time.getTime())) {
        time = new Date();
      }
      return {
        hour: time.getHours(),
        minute: time.getMinutes(),
        second: time.getSeconds()
      };
    },
    visibleDate() {
      if (this.userInputDate !== null) {
        return this.userInputDate;
      } else {
        return formatDate(this.value || this.defaultValue, this.dateFormat);
      }
    },
    yearLabel() {
      const yearTranslation = this.t("el.datepicker.year");
      if (this.currentView === "year") {
        const startYear = Math.floor(this.year / 10) * 10;
        if (yearTranslation) {
          return startYear + " " + yearTranslation + " - " + (startYear + 9) + " " + yearTranslation;
        }
        return startYear + " - " + (startYear + 9);
      }
      return $i("scp.vt_component.sf_widget.packages.date_picker.panel.date.year_label", {
        cnLabel: this.year + " " + yearTranslation,
        enLabel: yearTranslation + " " + this.year
      });
    },
    timeFormat() {
      if (this.format) {
        return extractTimeFormat(this.format);
      } else {
        return "HH:mm:ss";
      }
    },
    dateFormat() {
      if (this.format) {
        return extractDateFormat(this.format);
      } else {
        return "yyyy-MM-dd";
      }
    }
  },
  watch: {
    value(val) {
      if (this.selectionMode === "dates" && this.value) {
        return;
      }
      if (isDate(val)) {
        this.date = new Date(val);
      } else {
        this.date = this.getDefaultValue();
      }
    },
    defaultValue(val) {
      if (!isDate(this.value)) {
        this.date = val ? new Date(val) : new Date();
      }
    },
    selectionMode(newVal) {
      if (newVal === "month") {
        if (this.currentView !== "year" || this.currentView !== "month") {
          this.currentView = "month";
        }
      } else if (newVal === "dates") {
        this.currentView = "date";
      }
    }
  },
  methods: {
    getPrefixedClassName,
    handleClear() {
      this.date = this.getDefaultValue();
      this.$emit("pick", null);
    },
    emit(value, ...args) {
      if (!value) {
        this.$emit("pick", value, ...args);
      } else if (Array.isArray(value)) {
        const dates = value.map((date) => this.showTime ? clearMilliseconds(date) : clearTime(date));
        this.$emit("pick", dates, ...args);
      } else {
        this.$emit("pick", this.showTime ? clearMilliseconds(value) : clearTime(value), ...args);
      }
      this.userInputDate = null;
    },
    showMonthPicker() {
      this.currentView = "month";
    },
    showYearPicker() {
      this.currentView = "year";
    },
    prevMonth() {
      this.date = prevMonth(this.date);
    },
    nextMonth() {
      this.date = nextMonth(this.date);
    },
    prevYear() {
      if (this.currentView === "year") {
        this.date = prevYear(this.date, 10);
      } else {
        this.date = prevYear(this.date);
      }
    },
    nextYear() {
      if (this.currentView === "year") {
        this.date = nextYear(this.date, 10);
      } else {
        this.date = nextYear(this.date);
      }
    },
    handleShortcutClick(shortcut) {
      if (shortcut.onClick) {
        shortcut.onClick(this);
      }
    },
    handleMonthPick(month) {
      if (this.selectionMode === "month") {
        this.date = modifyDate(this.date, this.year, month, 1);
        this.emit(this.date);
      } else {
        this.date = changeYearMonthAndClampDate(this.date, this.year, month);
        this.currentView = "date";
      }
    },
    handleDatePick(value) {
      if (this.selectionMode === "day") {
        this.date = this.value ? modifyDate(this.value, value.getFullYear(), value.getMonth(), value.getDate()) : modifyWithTimeString(value, this.defaultTime);
        this.emit(this.date, this.showTime);
      } else if (this.selectionMode === "week") {
        this.emit(value.date);
      } else if (this.selectionMode === "dates") {
        this.emit(value, true);
      }
    },
    handleYearPick(year) {
      if (this.selectionMode === "year") {
        this.date = modifyDate(this.date, year, 0, 1);
        this.emit(this.date);
      } else {
        this.date = changeYearMonthAndClampDate(this.date, year, this.month);
        this.currentView = "month";
      }
    },
    changeToNow() {
      if (!this.disabledDate || !this.disabledDate(new Date())) {
        this.date = new Date();
        this.emit(this.date);
      }
    },
    confirm() {
      if (this.selectionMode === "dates") {
        this.emit(this.value);
      } else {
        const value = this.value ? this.value : modifyWithTimeString(this.getDefaultValue(), this.defaultTime);
        this.date = new Date(value);
        this.emit(value);
      }
    },
    resetView() {
      if (this.selectionMode === "month") {
        this.currentView = "month";
      } else if (this.selectionMode === "year") {
        this.currentView = "year";
      } else {
        this.currentView = "date";
      }
    },
    handleKeyControl(keyCode) {
      const mapping = {
        year: {
          38: -4,
          40: 4,
          37: -1,
          39: 1,
          offset: (date, step) => date.setFullYear(date.getFullYear() + step)
        },
        month: {
          38: -4,
          40: 4,
          37: -1,
          39: 1,
          offset: (date, step) => date.setMonth(date.getMonth() + step)
        },
        week: {
          38: -1,
          40: 1,
          37: -1,
          39: 1,
          offset: (date, step) => date.setDate(date.getDate() + step * 7)
        },
        day: {
          38: -7,
          40: 7,
          37: -1,
          39: 1,
          offset: (date, step) => date.setDate(date.getDate() + step)
        }
      };
      const mode = this.selectionMode;
      const year = 31536e6;
      const now = this.date.getTime();
      const newDate = new Date(this.date.getTime());
      while (Math.abs(now - newDate.getTime()) <= year) {
        const map = mapping[mode];
        map.offset(newDate, map[keyCode]);
        if (typeof this.disabledDate === "function" && this.disabledDate(newDate)) {
          continue;
        }
        this.date = newDate;
        this.$emit("pick", newDate, true);
        break;
      }
    },
    handleVisibleTimeChange(value) {
      const { hour, minute, second } = value;
      this.date = new Date(this.year, this.month, this.monthDate, hour, minute, second != null ? second : 0);
      this.emit(this.date, true);
    },
    handleVisibleDateChange(value) {
      const date = parseDate(value, this.dateFormat);
      if (date) {
        if (typeof this.disabledDate === "function" && this.disabledDate(date)) {
          return;
        }
        this.date = modifyTime(date, this.date.getHours(), this.date.getMinutes(), this.date.getSeconds());
        this.userInputDate = null;
        this.resetView();
        this.emit(this.date, true);
      }
    },
    isValidValue(value) {
      return value && !isNaN(value) && (typeof this.disabledDate === "function" ? !this.disabledDate(value) : true);
    },
    getDefaultValue() {
      return this.defaultValue ? new Date(this.defaultValue) : new Date();
    }
  }
};
const __vue_script__$4 = script$4;
var __vue_render__$4 = function() {
  var _obj, _obj$1, _obj$2, _obj$3, _obj$4;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c("transition", { attrs: { name: "el-zoom-in-top" } }, [
    _c(
      "div",
      {
        directives: [
          {
            name: "show",
            rawName: "v-show",
            value: _vm.visible,
            expression: "visible"
          }
        ],
        class: [
          _vm.getPrefixedClassName("el-picker-panel"),
          _vm.getPrefixedClassName("el-date-picker"),
          _vm.getPrefixedClassName("el-popper"),
          (_obj = {}, _obj[_vm.getPrefixedClassName("has-sidebar")] = _vm.$slots.sidebar || _vm.shortcuts, _obj[_vm.getPrefixedClassName("has-time")] = _vm.showTime, _obj),
          _vm.popperClass
        ]
      },
      [
        _c(
          "div",
          { class: _vm.getPrefixedClassName("el-picker-panel__body-wrapper") },
          [
            _vm._t("sidebar"),
            _vm._v(" "),
            _vm.shortcuts ? _c(
              "div",
              {
                class: _vm.getPrefixedClassName("el-picker-panel__sidebar")
              },
              _vm._l(_vm.shortcuts, function(shortcut, key) {
                return _c(
                  "button",
                  {
                    key,
                    class: _vm.getPrefixedClassName(
                      "el-picker-panel__shortcut"
                    ),
                    attrs: { type: "button" },
                    on: {
                      click: function($event) {
                        return _vm.handleShortcutClick(shortcut);
                      }
                    }
                  },
                  [
                    _c(
                      "span",
                      {
                        staticClass: "ellipsis",
                        attrs: { "data-tip": shortcut.text }
                      },
                      [
                        _vm._v(
                          "\n            " + _vm._s(shortcut.text) + "\n          "
                        )
                      ]
                    )
                  ]
                );
              }),
              0
            ) : _vm._e(),
            _vm._v(" "),
            _c(
              "div",
              {
                class: [
                  _vm.getPrefixedClassName("el-picker-panel__body"),
                  (_obj$1 = {}, _obj$1[_vm.getPrefixedClassName("el-picker-panel__body--time")] = _vm.showTime, _obj$1)
                ]
              },
              [
                _c(
                  "div",
                  {
                    directives: [
                      {
                        name: "show",
                        rawName: "v-show",
                        value: _vm.currentView !== "time",
                        expression: "currentView !== 'time'"
                      }
                    ],
                    class: [
                      _vm.getPrefixedClassName("el-date-picker__header"),
                      (_obj$2 = {}, _obj$2[_vm.getPrefixedClassName(
                        "el-date-picker__header--bordered"
                      )] = _vm.currentView === "year" || _vm.currentView === "month", _obj$2)
                    ]
                  },
                  [
                    _c("button", {
                      class: [
                        _vm.getPrefixedClassName("el-picker-panel__icon-btn"),
                        _vm.getPrefixedClassName("el-date-picker__prev-btn"),
                        "vtv-icon-prev-year",
                        "iconfont"
                      ],
                      attrs: {
                        type: "button",
                        "aria-label": _vm.t("el.datepicker.prevYear")
                      },
                      on: { click: _vm.prevYear }
                    }),
                    _vm._v(" "),
                    _c("button", {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: _vm.currentView === "date",
                          expression: "currentView === 'date'"
                        }
                      ],
                      class: [
                        _vm.getPrefixedClassName("el-picker-panel__icon-btn"),
                        _vm.getPrefixedClassName("el-date-picker__prev-btn"),
                        "vtv-icon-prev-month",
                        "iconfont"
                      ],
                      attrs: {
                        type: "button",
                        "aria-label": _vm.t("el.datepicker.prevMonth")
                      },
                      on: { click: _vm.prevMonth }
                    }),
                    _vm._v(" "),
                    _c(
                      "span",
                      {
                        directives: [
                          {
                            name: "show",
                            rawName: "v-show",
                            value: _vm.currentView === "date" && _vm.isInternational,
                            expression: "currentView === 'date' && isInternational"
                          }
                        ],
                        class: [
                          _vm.getPrefixedClassName(
                            "el-date-picker__header-label"
                          ),
                          (_obj$3 = {}, _obj$3[_vm.getPrefixedClassName("active")] = _vm.currentView === "month", _obj$3)
                        ],
                        attrs: { role: "button" },
                        on: { click: _vm.showMonthPicker }
                      },
                      [
                        _vm._v(
                          _vm._s(_vm.t("el.datepicker.month" + (_vm.month + 1)))
                        )
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "span",
                      {
                        class: _vm.getPrefixedClassName(
                          "el-date-picker__header-label"
                        ),
                        attrs: { role: "button" },
                        on: { click: _vm.showYearPicker }
                      },
                      [_vm._v(_vm._s(_vm.yearLabel))]
                    ),
                    _vm._v(" "),
                    _c(
                      "span",
                      {
                        directives: [
                          {
                            name: "show",
                            rawName: "v-show",
                            value: _vm.currentView === "date" && !_vm.isInternational,
                            expression: "currentView === 'date' && !isInternational"
                          }
                        ],
                        class: [
                          _vm.getPrefixedClassName(
                            "el-date-picker__header-label"
                          ),
                          (_obj$4 = {}, _obj$4[_vm.getPrefixedClassName("active")] = _vm.currentView === "month", _obj$4)
                        ],
                        attrs: { role: "button" },
                        on: { click: _vm.showMonthPicker }
                      },
                      [
                        _vm._v(
                          _vm._s(_vm.t("el.datepicker.month" + (_vm.month + 1)))
                        )
                      ]
                    ),
                    _vm._v(" "),
                    _c("button", {
                      class: [
                        _vm.getPrefixedClassName("el-picker-panel__icon-btn"),
                        _vm.getPrefixedClassName("el-date-picker__next-btn"),
                        "vtv-icon-next-year",
                        "iconfont"
                      ],
                      attrs: {
                        type: "button",
                        "aria-label": _vm.t("el.datepicker.nextYear")
                      },
                      on: { click: _vm.nextYear }
                    }),
                    _vm._v(" "),
                    _c("button", {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: _vm.currentView === "date",
                          expression: "currentView === 'date'"
                        }
                      ],
                      class: [
                        _vm.getPrefixedClassName("el-picker-panel__icon-btn"),
                        _vm.getPrefixedClassName("el-date-picker__next-btn"),
                        "vtv-icon-next-month",
                        "iconfont"
                      ],
                      attrs: {
                        type: "button",
                        "aria-label": _vm.t("el.datepicker.nextMonth")
                      },
                      on: { click: _vm.nextMonth }
                    })
                  ]
                ),
                _vm._v(" "),
                _c(
                  "div",
                  {
                    class: _vm.getPrefixedClassName("el-picker-panel__content")
                  },
                  [
                    _c("date-table", {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: _vm.currentView === "date",
                          expression: "currentView === 'date'"
                        }
                      ],
                      attrs: {
                        "selection-mode": _vm.selectionMode,
                        "first-day-of-week": _vm.firstDayOfWeek,
                        value: _vm.value,
                        "default-value": _vm.defaultValue ? new Date(_vm.defaultValue) : null,
                        date: _vm.date,
                        "disabled-date": _vm.disabledDate
                      },
                      on: { pick: _vm.handleDatePick }
                    }),
                    _vm._v(" "),
                    _c("year-table", {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: _vm.currentView === "year",
                          expression: "currentView === 'year'"
                        }
                      ],
                      attrs: {
                        value: _vm.value,
                        "default-value": _vm.defaultValue ? new Date(_vm.defaultValue) : null,
                        date: _vm.date,
                        "disabled-date": _vm.disabledDate
                      },
                      on: { pick: _vm.handleYearPick }
                    }),
                    _vm._v(" "),
                    _c("month-table", {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: _vm.currentView === "month",
                          expression: "currentView === 'month'"
                        }
                      ],
                      attrs: {
                        value: _vm.value,
                        "default-value": _vm.defaultValue ? new Date(_vm.defaultValue) : null,
                        date: _vm.date,
                        "disabled-date": _vm.disabledDate
                      },
                      on: { pick: _vm.handleMonthPick }
                    })
                  ],
                  1
                ),
                _vm._v(" "),
                _vm.showTime ? _c(
                  "div",
                  {
                    class: _vm.getPrefixedClassName(
                      "el-date-picker__time-header"
                    )
                  },
                  [
                    _c(
                      "span",
                      {
                        class: _vm.getPrefixedClassName(
                          "el-date-picker__editor-wrap"
                        )
                      },
                      [
                        _vm._v(
                          "\n            " + _vm._s(_vm.visibleDate) + "\n          "
                        )
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "span",
                      {
                        class: _vm.getPrefixedClassName(
                          "el-date-picker__editor-wrap"
                        )
                      },
                      [
                        _c("time-picker", {
                          ref: "timepicker",
                          attrs: {
                            "show-second": _vm.showSecond,
                            value: _vm.visibleTime
                          },
                          on: { input: _vm.handleVisibleTimeChange }
                        })
                      ],
                      1
                    )
                  ]
                ) : _vm._e()
              ]
            )
          ],
          2
        ),
        _vm._v(" "),
        _c(
          "div",
          {
            directives: [
              {
                name: "show",
                rawName: "v-show",
                value: _vm.footerVisible && _vm.currentView === "date",
                expression: "footerVisible && currentView === 'date'"
              }
            ],
            class: _vm.getPrefixedClassName("el-picker-panel__footer")
          },
          [
            _c(
              "sf-button",
              {
                directives: [
                  {
                    name: "show",
                    rawName: "v-show",
                    value: _vm.selectionMode !== "dates",
                    expression: "selectionMode !== 'dates'"
                  }
                ],
                class: _vm.getPrefixedClassName("el-picker-panel__link-btn"),
                attrs: { type: "cancel", size: "small" },
                on: { click: _vm.changeToNow }
              },
              [
                _vm._v(
                  "\n        " + _vm._s(_vm.t("el.datepicker.now")) + "\n      "
                )
              ]
            ),
            _vm._v(" "),
            _c(
              "sf-button",
              {
                class: _vm.getPrefixedClassName("el-picker-panel__link-btn"),
                attrs: { type: "primary", size: "small" },
                on: { click: _vm.confirm }
              },
              [
                _vm._v(
                  "\n        " + _vm._s(_vm.t("el.datepicker.confirm")) + "\n      "
                )
              ]
            )
          ],
          1
        )
      ]
    )
  ]);
};
var __vue_staticRenderFns__$4 = [];
__vue_render__$4._withStripped = true;
const __vue_inject_styles__$4 = void 0;
const __vue_scope_id__$4 = void 0;
const __vue_module_identifier__$4 = void 0;
const __vue_is_functional_template__$4 = false;
const __vue_component__$4 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$4, staticRenderFns: __vue_staticRenderFns__$4 },
  __vue_inject_styles__$4,
  __vue_script__$4,
  __vue_scope_id__$4,
  __vue_is_functional_template__$4,
  __vue_module_identifier__$4,
  false,
  void 0,
  void 0,
  void 0
);
const DEFAULT_TIME$1 = ["00:00:00", "23:59:59"];
const advanceDate$1 = (date, amount) => {
  return new Date(new Date(date).getTime() + amount);
};
const calcDefaultValue$1 = (defaultValue) => {
  if (Array.isArray(defaultValue)) {
    return [new Date(defaultValue[0]), new Date(defaultValue[1])];
  } else if (defaultValue) {
    return [new Date(defaultValue), advanceDate$1(defaultValue, 24 * 60 * 60 * 1e3)];
  } else {
    return [new Date(), advanceDate$1(Date.now(), 24 * 60 * 60 * 1e3)];
  }
};
var script$3 = {
  directives: { clickoutside: vClickoutside },
  components: {
    TimePicker: __vue_component__$5,
    DateTable: __vue_component__$8,
    SfButton
  },
  mixins: [Locale],
  data() {
    return {
      popperClass: "",
      value: [],
      defaultValue: null,
      defaultTime: null,
      minDate: "",
      maxDate: "",
      leftDate: new Date(),
      rightDate: nextMonth(new Date()),
      rangeState: {
        endDate: null,
        selecting: false,
        row: null,
        column: null
      },
      showTime: false,
      shortcuts: "",
      visible: "",
      disabledDate: "",
      firstDayOfWeek: 7,
      minTimePickerVisible: false,
      maxTimePickerVisible: false,
      format: "",
      unlinkPanels: false,
      useLocalMaxtime: false,
      showSecond: true
    };
  },
  computed: {
    btnDisabled() {
      return !(this.minDate && this.maxDate && !this.selecting && this.isValidValue([this.minDate, this.maxDate]));
    },
    leftLabel() {
      const monthDate = [
        this.leftDate.getFullYear(),
        this.t("el.datepicker.year"),
        this.t(`el.datepicker.month${this.leftDate.getMonth() + 1}`)
      ];
      return $i("scp.vt_component.sf_widget.packages.date_picker.panel.date_range.left_label", {
        cnLabel: monthDate.join(" "),
        enLabel: monthDate.reverse().join(" ")
      });
    },
    rightLabel() {
      const monthDate = [
        this.rightDate.getFullYear(),
        this.t("el.datepicker.year"),
        this.t(`el.datepicker.month${this.rightDate.getMonth() + 1}`)
      ];
      return $i("scp.vt_component.sf_widget.packages.date_picker.panel.date_range.right_label", {
        cnLabel: monthDate.join(" "),
        enLabel: monthDate.reverse().join(" ")
      });
    },
    leftYear() {
      return this.leftDate.getFullYear();
    },
    leftMonth() {
      return this.leftDate.getMonth();
    },
    leftMonthDate() {
      return this.leftDate.getDate();
    },
    rightYear() {
      return this.rightDate.getFullYear();
    },
    rightMonth() {
      return this.rightDate.getMonth();
    },
    rightMonthDate() {
      return this.rightDate.getDate();
    },
    minVisibleDate() {
      return this.minDate ? formatDate(this.minDate, this.dateFormat) : "";
    },
    maxVisibleDate() {
      return this.maxDate || this.minDate ? formatDate(this.maxDate || this.minDate, this.dateFormat) : "";
    },
    minVisibleTime() {
      var _a, _b, _c, _d, _e, _f;
      return {
        hour: (_b = (_a = this.minDate) == null ? void 0 : _a.getHours()) != null ? _b : 0,
        minute: (_d = (_c = this.minDate) == null ? void 0 : _c.getMinutes()) != null ? _d : 0,
        second: (_f = (_e = this.minDate) == null ? void 0 : _e.getSeconds()) != null ? _f : 0
      };
    },
    maxVisibleTime() {
      var _a, _b, _c;
      const time = this.maxDate || this.minDate;
      return {
        hour: (_a = time == null ? void 0 : time.getHours()) != null ? _a : 23,
        minute: (_b = time == null ? void 0 : time.getMinutes()) != null ? _b : 59,
        second: (_c = time == null ? void 0 : time.getSeconds()) != null ? _c : 59
      };
    },
    timeFormat() {
      if (this.format) {
        return extractTimeFormat(this.format);
      } else {
        return "HH:mm:ss";
      }
    },
    dateFormat() {
      if (this.format) {
        return extractDateFormat(this.format);
      } else {
        return "yyyy-MM-dd";
      }
    },
    enableMonthArrow() {
      const nextMonth2 = (this.leftMonth + 1) % 12;
      const yearOffset = this.leftMonth + 1 >= 12 ? 1 : 0;
      return this.unlinkPanels && new Date(this.leftYear + yearOffset, nextMonth2) < new Date(this.rightYear, this.rightMonth);
    },
    enableYearArrow() {
      return this.unlinkPanels && this.rightYear * 12 + this.rightMonth - (this.leftYear * 12 + this.leftMonth + 1) >= 12;
    }
  },
  watch: {
    value(newVal) {
      if (!newVal) {
        this.minDate = null;
        this.maxDate = null;
      } else if (Array.isArray(newVal)) {
        this.minDate = isDate(newVal[0]) ? new Date(newVal[0]) : null;
        this.maxDate = isDate(newVal[1]) ? new Date(newVal[1]) : null;
        if (this.minDate) {
          this.leftDate = this.minDate;
          if (this.unlinkPanels && this.maxDate) {
            const minDateYear = this.minDate.getFullYear();
            const minDateMonth = this.minDate.getMonth();
            const maxDateYear = this.maxDate.getFullYear();
            const maxDateMonth = this.maxDate.getMonth();
            this.rightDate = minDateYear === maxDateYear && minDateMonth === maxDateMonth ? nextMonth(this.maxDate) : this.maxDate;
          } else {
            this.rightDate = nextMonth(this.leftDate);
          }
        } else {
          this.leftDate = calcDefaultValue$1(this.defaultValue)[0];
          this.rightDate = nextMonth(this.leftDate);
        }
      }
    },
    defaultValue(val) {
      if (!Array.isArray(this.value)) {
        const [left, right] = calcDefaultValue$1(val);
        this.leftDate = left;
        this.rightDate = val && val[1] && this.unlinkPanels ? right : nextMonth(this.leftDate);
      }
    }
  },
  methods: {
    getPrefixedClassName,
    handleClose() {
      this.$emit("close");
    },
    handleClear() {
      this.minDate = null;
      this.maxDate = null;
      this.leftDate = calcDefaultValue$1(this.defaultValue)[0];
      this.rightDate = nextMonth(this.leftDate);
      this.$emit("pick", null);
    },
    handleChangeRange(val) {
      this.minDate = val.minDate;
      this.maxDate = val.maxDate;
      this.rangeState = val.rangeState;
    },
    handleTimeChange(value, type) {
      if (!this.minDate || !this.maxDate) {
        return;
      }
      const { hour, minute, second } = value;
      if (type === "min") {
        this.minDate = modifyTime(this.minDate, hour, minute, second != null ? second : 0);
        if (this.minDate > this.maxDate) {
          this.maxDate = this.minDate;
        }
      } else {
        this.maxDate = modifyTime(this.maxDate, hour, minute, second != null ? second : 0);
        if (this.maxDate < this.minDate) {
          this.minDate = this.maxDate;
        }
      }
    },
    getLocalTime() {
      const now = new Date();
      const hours = now.getHours();
      const minutes = now.getMinutes();
      const seconds = now.getSeconds();
      return `${hours}:${minutes}:${seconds}`;
    },
    isToday(date) {
      const today = new Date();
      const targetDate = new Date(date);
      return today.getFullYear() === targetDate.getFullYear() && today.getMonth() === targetDate.getMonth() && today.getDate() === targetDate.getDate();
    },
    handleRangePick(val, close = true) {
      const defaultTime = this.defaultTime || DEFAULT_TIME$1;
      const minTime = defaultTime[0];
      let maxTime = this.useLocalMaxtime && this.isToday(val.maxDate) ? this.getLocalTime() : defaultTime[1];
      if (close && typeof this.defineMaxTime === "function") {
        maxTime = this.defineMaxTime({ val, close, maxTime }) || maxTime;
      }
      const minDate = modifyWithTimeString(val.minDate, minTime);
      const maxDate = modifyWithTimeString(val.maxDate, maxTime);
      if (this.maxDate === maxDate && this.minDate === minDate) {
        return;
      }
      this.onPick && this.onPick(val);
      this.maxDate = maxDate;
      this.minDate = minDate;
      if (!close) {
        this.$emit("select-start", minDate);
      } else {
        this.$emit("select-end", maxDate);
      }
      setTimeout(() => {
        this.maxDate = maxDate;
        this.minDate = minDate;
      }, 10);
      if (!close || this.showTime) {
        return;
      }
      this.handleConfirm();
    },
    handleShortcutClick(shortcut) {
      if (shortcut.onClick) {
        shortcut.onClick(this);
      }
    },
    leftPrevYear() {
      this.leftDate = prevYear(this.leftDate);
      if (!this.unlinkPanels) {
        this.rightDate = nextMonth(this.leftDate);
      }
    },
    leftPrevMonth() {
      this.leftDate = prevMonth(this.leftDate);
      if (!this.unlinkPanels) {
        this.rightDate = nextMonth(this.leftDate);
      }
    },
    rightNextYear() {
      if (!this.unlinkPanels) {
        this.leftDate = nextYear(this.leftDate);
        this.rightDate = nextMonth(this.leftDate);
      } else {
        this.rightDate = nextYear(this.rightDate);
      }
    },
    rightNextMonth() {
      if (!this.unlinkPanels) {
        this.leftDate = nextMonth(this.leftDate);
        this.rightDate = nextMonth(this.leftDate);
      } else {
        this.rightDate = nextMonth(this.rightDate);
      }
    },
    leftNextYear() {
      this.leftDate = nextYear(this.leftDate);
    },
    leftNextMonth() {
      this.leftDate = nextMonth(this.leftDate);
    },
    rightPrevYear() {
      this.rightDate = prevYear(this.rightDate);
    },
    rightPrevMonth() {
      this.rightDate = prevMonth(this.rightDate);
    },
    handleConfirm(visible = false) {
      if (this.isValidValue([this.minDate, this.maxDate])) {
        this.$emit("pick", [this.minDate, this.maxDate], visible);
      }
    },
    isValidValue(value) {
      return Array.isArray(value) && value && value[0] && value[1] && isDate(value[0]) && isDate(value[1]) && value[0].getTime() <= value[1].getTime() && typeof this.disabledDate === "function" ? !this.disabledDate(value[0]) && !this.disabledDate(value[1]) : true;
    },
    resetView() {
      this.minDate = this.value && isDate(this.value[0]) ? new Date(this.value[0]) : null;
      this.maxDate = this.value && isDate(this.value[0]) ? new Date(this.value[1]) : null;
    }
  }
};
const __vue_script__$3 = script$3;
var __vue_render__$3 = function() {
  var _obj, _obj$1, _obj$2, _obj$3, _obj$4, _obj$5;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "transition",
    {
      attrs: { name: "el-zoom-in-top" },
      on: {
        "after-leave": function($event) {
          return _vm.$emit("dodestroy");
        }
      }
    },
    [
      _c(
        "div",
        {
          directives: [
            {
              name: "show",
              rawName: "v-show",
              value: _vm.visible,
              expression: "visible"
            }
          ],
          class: [
            _vm.getPrefixedClassName("el-picker-panel"),
            _vm.getPrefixedClassName("el-date-range-picker"),
            _vm.getPrefixedClassName("el-popper"),
            (_obj = {}, _obj[_vm.getPrefixedClassName("has-sidebar")] = _vm.$slots.sidebar || _vm.shortcuts, _obj[_vm.getPrefixedClassName("has-time")] = _vm.showTime, _obj),
            _vm.popperClass
          ]
        },
        [
          _c(
            "div",
            {
              class: _vm.getPrefixedClassName("el-picker-panel__body-wrapper")
            },
            [
              _vm._t("sidebar"),
              _vm._v(" "),
              _vm.shortcuts ? _c(
                "div",
                {
                  class: _vm.getPrefixedClassName(
                    "el-picker-panel__sidebar"
                  )
                },
                _vm._l(_vm.shortcuts, function(shortcut, key) {
                  return _c(
                    "button",
                    {
                      key,
                      class: _vm.getPrefixedClassName(
                        "el-picker-panel__shortcut"
                      ),
                      attrs: { type: "button" },
                      on: {
                        click: function($event) {
                          return _vm.handleShortcutClick(shortcut);
                        }
                      }
                    },
                    [
                      _c(
                        "span",
                        {
                          staticClass: "ellipsis",
                          attrs: { "data-tip": shortcut.text }
                        },
                        [
                          _vm._v(
                            "\n            " + _vm._s(shortcut.text) + "\n          "
                          )
                        ]
                      )
                    ]
                  );
                }),
                0
              ) : _vm._e(),
              _vm._v(" "),
              _c(
                "div",
                {
                  class: [
                    _vm.getPrefixedClassName("el-picker-panel__body"),
                    (_obj$1 = {}, _obj$1[_vm.getPrefixedClassName("el-picker-panel__body--time")] = _vm.showTime, _obj$1)
                  ]
                },
                [
                  _c(
                    "div",
                    {
                      class: [
                        _vm.getPrefixedClassName("el-picker-panel__content"),
                        _vm.getPrefixedClassName(
                          "el-date-range-picker__content"
                        ),
                        _vm.getPrefixedClassName("is-left")
                      ]
                    },
                    [
                      _c(
                        "div",
                        {
                          class: _vm.getPrefixedClassName(
                            "el-date-range-picker__header"
                          )
                        },
                        [
                          _c("button", {
                            class: [
                              _vm.getPrefixedClassName(
                                "el-picker-panel__icon-btn"
                              ),
                              "vtv-icon-prev-year",
                              "iconfont"
                            ],
                            attrs: { type: "button" },
                            on: { click: _vm.leftPrevYear }
                          }),
                          _vm._v(" "),
                          _c("button", {
                            class: [
                              _vm.getPrefixedClassName(
                                "el-picker-panel__icon-btn"
                              ),
                              "vtv-icon-prev-month",
                              "iconfont"
                            ],
                            attrs: { type: "button" },
                            on: { click: _vm.leftPrevMonth }
                          }),
                          _vm._v(" "),
                          _vm.unlinkPanels ? _c("button", {
                            class: [
                              _vm.getPrefixedClassName(
                                "el-picker-panel__icon-btn"
                              ),
                              "vtv-icon-next-year",
                              "iconfont",
                              (_obj$2 = {}, _obj$2[_vm.getPrefixedClassName("is-disabled")] = !_vm.enableYearArrow, _obj$2)
                            ],
                            attrs: {
                              type: "button",
                              disabled: !_vm.enableYearArrow
                            },
                            on: { click: _vm.leftNextYear }
                          }) : _vm._e(),
                          _vm._v(" "),
                          _vm.unlinkPanels ? _c("button", {
                            class: [
                              _vm.getPrefixedClassName(
                                "el-picker-panel__icon-btn"
                              ),
                              "vtv-icon-next-month",
                              "iconfont",
                              (_obj$3 = {}, _obj$3[_vm.getPrefixedClassName("is-disabled")] = !_vm.enableMonthArrow, _obj$3)
                            ],
                            attrs: {
                              type: "button",
                              disabled: !_vm.enableMonthArrow
                            },
                            on: { click: _vm.leftNextMonth }
                          }) : _vm._e(),
                          _vm._v(" "),
                          _c("div", [_vm._v(_vm._s(_vm.leftLabel))])
                        ]
                      ),
                      _vm._v(" "),
                      _c("date-table", {
                        attrs: {
                          "selection-mode": "range",
                          date: _vm.leftDate,
                          "default-value": _vm.defaultValue,
                          "min-date": _vm.minDate,
                          "max-date": _vm.maxDate,
                          "range-state": _vm.rangeState,
                          "disabled-date": _vm.disabledDate,
                          "first-day-of-week": _vm.firstDayOfWeek
                        },
                        on: {
                          changerange: _vm.handleChangeRange,
                          pick: _vm.handleRangePick
                        }
                      })
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      class: [
                        _vm.getPrefixedClassName("el-picker-panel__content"),
                        _vm.getPrefixedClassName(
                          "el-date-range-picker__content"
                        ),
                        _vm.getPrefixedClassName("is-right")
                      ]
                    },
                    [
                      _c(
                        "div",
                        {
                          class: _vm.getPrefixedClassName(
                            "el-date-range-picker__header"
                          )
                        },
                        [
                          _vm.unlinkPanels ? _c("button", {
                            class: [
                              _vm.getPrefixedClassName(
                                "el-picker-panel__icon-btn"
                              ),
                              "vtv-icon-prev-year",
                              "iconfont",
                              (_obj$4 = {}, _obj$4[_vm.getPrefixedClassName("is-disabled")] = !_vm.enableYearArrow, _obj$4)
                            ],
                            attrs: {
                              type: "button",
                              disabled: !_vm.enableYearArrow
                            },
                            on: { click: _vm.rightPrevYear }
                          }) : _vm._e(),
                          _vm._v(" "),
                          _vm.unlinkPanels ? _c("button", {
                            class: [
                              _vm.getPrefixedClassName(
                                "el-picker-panel__icon-btn"
                              ),
                              "vtv-icon-prev-month",
                              "iconfont",
                              (_obj$5 = {}, _obj$5[_vm.getPrefixedClassName("is-disabled")] = !_vm.enableMonthArrow, _obj$5)
                            ],
                            attrs: {
                              type: "button",
                              disabled: !_vm.enableMonthArrow
                            },
                            on: { click: _vm.rightPrevMonth }
                          }) : _vm._e(),
                          _vm._v(" "),
                          _c("button", {
                            class: [
                              _vm.getPrefixedClassName(
                                "el-picker-panel__icon-btn"
                              ),
                              "vtv-icon-next-year",
                              "iconfont"
                            ],
                            attrs: { type: "button" },
                            on: { click: _vm.rightNextYear }
                          }),
                          _vm._v(" "),
                          _c("button", {
                            class: [
                              _vm.getPrefixedClassName(
                                "el-picker-panel__icon-btn"
                              ),
                              "vtv-icon-next-month",
                              "iconfont"
                            ],
                            attrs: { type: "button" },
                            on: { click: _vm.rightNextMonth }
                          }),
                          _vm._v(" "),
                          _c("div", [_vm._v(_vm._s(_vm.rightLabel))])
                        ]
                      ),
                      _vm._v(" "),
                      _c("date-table", {
                        attrs: {
                          "selection-mode": "range",
                          date: _vm.rightDate,
                          "default-value": _vm.defaultValue,
                          "min-date": _vm.minDate,
                          "max-date": _vm.maxDate,
                          "range-state": _vm.rangeState,
                          "disabled-date": _vm.disabledDate,
                          "first-day-of-week": _vm.firstDayOfWeek
                        },
                        on: {
                          changerange: _vm.handleChangeRange,
                          pick: _vm.handleRangePick
                        }
                      })
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _vm.showTime ? _c(
                    "div",
                    {
                      class: _vm.getPrefixedClassName(
                        "el-date-range-picker__time-header"
                      )
                    },
                    [
                      _c(
                        "span",
                        {
                          class: _vm.getPrefixedClassName(
                            "el-date-range-picker__editors-wrap"
                          )
                        },
                        [
                          _c(
                            "span",
                            {
                              class: _vm.getPrefixedClassName(
                                "el-date-range-picker__time-picker-wrap"
                              )
                            },
                            [
                              _vm._v(
                                "\n              " + _vm._s(_vm.minVisibleDate) + "\n            "
                              )
                            ]
                          ),
                          _vm._v(" "),
                          _c(
                            "span",
                            {
                              class: _vm.getPrefixedClassName(
                                "el-date-range-picker__time-picker-wrap"
                              )
                            },
                            [
                              _c("time-picker", {
                                ref: "minTimePicker",
                                attrs: {
                                  value: _vm.minVisibleTime,
                                  "show-second": _vm.showSecond
                                },
                                on: {
                                  input: function(value) {
                                    return _vm.handleTimeChange(
                                      value,
                                      "min"
                                    );
                                  }
                                }
                              })
                            ],
                            1
                          )
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          class: _vm.getPrefixedClassName(
                            "el-date-range-picker__time-header-arrow-right"
                          )
                        },
                        [
                          _c("i", {
                            staticClass: "iconfont vtv-icon-ele-time-arrow"
                          })
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          class: [
                            _vm.getPrefixedClassName(
                              "el-date-range-picker__editors-wrap"
                            ),
                            _vm.getPrefixedClassName("is-right")
                          ]
                        },
                        [
                          _c(
                            "span",
                            {
                              class: _vm.getPrefixedClassName(
                                "el-date-range-picker__time-picker-wrap"
                              )
                            },
                            [
                              _vm._v(
                                "\n              " + _vm._s(_vm.maxVisibleDate) + "\n            "
                              )
                            ]
                          ),
                          _vm._v(" "),
                          _c(
                            "span",
                            {
                              class: _vm.getPrefixedClassName(
                                "el-date-range-picker__time-picker-wrap"
                              )
                            },
                            [
                              _c("time-picker", {
                                ref: "maxTimePicker",
                                attrs: {
                                  value: _vm.maxVisibleTime,
                                  "show-second": _vm.showSecond
                                },
                                on: {
                                  input: function(value) {
                                    return _vm.handleTimeChange(
                                      value,
                                      "max"
                                    );
                                  }
                                }
                              })
                            ],
                            1
                          )
                        ]
                      )
                    ]
                  ) : _vm._e()
                ]
              )
            ],
            2
          ),
          _vm._v(" "),
          _vm.showTime ? _c(
            "div",
            { class: _vm.getPrefixedClassName("el-picker-panel__footer") },
            [
              _c(
                "sf-button",
                {
                  class: _vm.getPrefixedClassName(
                    "el-picker-panel__link-btn"
                  ),
                  attrs: {
                    type: "primary",
                    size: "small",
                    disabled: _vm.btnDisabled
                  },
                  on: {
                    click: function($event) {
                      return _vm.handleConfirm(false);
                    }
                  }
                },
                [
                  _vm._v(
                    "\n        " + _vm._s(_vm.t("el.datepicker.confirm")) + "\n      "
                  )
                ]
              ),
              _vm._v(" "),
              _c(
                "sf-button",
                {
                  class: _vm.getPrefixedClassName(
                    "el-picker-panel__link-btn"
                  ),
                  attrs: { type: "cancel", size: "small" },
                  on: { click: _vm.handleClose }
                },
                [
                  _vm._v(
                    "\n        " + _vm._s(_vm.t("el.datepicker.cancel")) + "\n      "
                  )
                ]
              )
            ],
            1
          ) : _vm._e()
        ]
      )
    ]
  );
};
var __vue_staticRenderFns__$3 = [];
__vue_render__$3._withStripped = true;
const __vue_inject_styles__$3 = void 0;
const __vue_scope_id__$3 = void 0;
const __vue_module_identifier__$3 = void 0;
const __vue_is_functional_template__$3 = false;
const __vue_component__$3 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$3, staticRenderFns: __vue_staticRenderFns__$3 },
  __vue_inject_styles__$3,
  __vue_script__$3,
  __vue_scope_id__$3,
  __vue_is_functional_template__$3,
  __vue_module_identifier__$3,
  false,
  void 0,
  void 0,
  void 0
);
const mixDateType = {
  byDate: "byDate",
  byWeek: "byWeek",
  byMonth: "byMonth",
  bySelf: "bySelf"
};
const mixDateList = [
  {
    text: () => $i$1("scp.vt_component.sf_widget.packages.date_picker.date_picker.by_date"),
    key: mixDateType.byDate
  },
  {
    text: () => $i$1("scp.vt_component.sf_widget.packages.date_picker.date_picker.by_week"),
    key: mixDateType.byWeek
  },
  {
    text: () => $i$1("scp.vt_component.sf_widget.packages.date_picker.date_picker.by_month"),
    key: mixDateType.byMonth
  },
  {
    text: () => $i$1("scp.vt_component.sf_widget.packages.date_picker.date_picker.by_self"),
    key: mixDateType.bySelf
  }
];
const DEFAULT_TIME = ["00:00:00", "23:59:59"];
const advanceDate = (date, amount) => {
  return new Date(new Date(date).getTime() + amount);
};
const calcDefaultValue = (defaultValue) => {
  if (Array.isArray(defaultValue)) {
    return [new Date(defaultValue[0]), new Date(defaultValue[1])];
  } else if (defaultValue) {
    return [new Date(defaultValue), advanceDate(defaultValue, 24 * 60 * 60 * 1e3)];
  } else {
    return [new Date(), advanceDate(Date.now(), 24 * 60 * 60 * 1e3)];
  }
};
var script$2 = {
  directives: { clickoutside: vClickoutside },
  components: {
    DateTable: __vue_component__$8,
    MonthTable: __vue_component__$7
  },
  mixins: [Locale],
  data() {
    return {
      popperClass: "",
      value: [],
      defaultValue: null,
      defaultTime: null,
      minDate: "",
      maxDate: "",
      leftDate: new Date(),
      rightDate: nextMonth(new Date()),
      rangeState: {
        endDate: null,
        selecting: false,
        row: null,
        column: null
      },
      showTime: false,
      shortcuts: "",
      visible: "",
      disabledDate: "",
      date: new Date(),
      format: "",
      unlinkPanels: false,
      currentType: mixDateType.bySelf,
      mixDateType,
      mixDateList
    };
  },
  computed: {
    isShowSingleDate() {
      return this.currentType !== mixDateType.bySelf;
    },
    btnDisabled() {
      return !(this.minDate && this.maxDate && !this.selecting && this.isValidValue([this.minDate, this.maxDate]));
    },
    yearLabel() {
      return this.leftDate.getFullYear() + this.t("el.datepicker.year");
    },
    monthLablel() {
      return this.t(`el.datepicker.month${this.leftDate.getMonth() + 1}`);
    },
    leftLabel() {
      const monthDate = [
        this.leftDate.getFullYear(),
        this.t("el.datepicker.year"),
        this.t(`el.datepicker.month${this.leftDate.getMonth() + 1}`)
      ];
      return $i("scp.vt_component.sf_widget.packages.date_picker.panel.date_range.left_label", {
        cnLabel: monthDate.join(" "),
        enLabel: monthDate.reverse().join(" ")
      });
    },
    rightLabel() {
      const monthDate = [
        this.rightDate.getFullYear(),
        this.t("el.datepicker.year"),
        this.t(`el.datepicker.month${this.rightDate.getMonth() + 1}`)
      ];
      return $i("scp.vt_component.sf_widget.packages.date_picker.panel.date_range.right_label", {
        cnLabel: monthDate.join(" "),
        enLabel: monthDate.reverse().join(" ")
      });
    },
    leftYear() {
      return this.leftDate.getFullYear();
    },
    leftMonth() {
      return this.leftDate.getMonth();
    },
    leftMonthDate() {
      return this.leftDate.getDate();
    },
    rightYear() {
      return this.rightDate.getFullYear();
    },
    rightMonth() {
      return this.rightDate.getMonth();
    },
    rightMonthDate() {
      return this.rightDate.getDate();
    },
    minVisibleDate() {
      return this.minDate ? formatDate(this.minDate, this.dateFormat) : "";
    },
    maxVisibleDate() {
      return this.maxDate || this.minDate ? formatDate(this.maxDate || this.minDate, this.dateFormat) : "";
    },
    dateFormat() {
      if (this.format) {
        return extractDateFormat(this.format);
      } else {
        return "yyyy-MM-dd";
      }
    },
    enableMonthArrow() {
      const nextMonth2 = (this.leftMonth + 1) % 12;
      const yearOffset = this.leftMonth + 1 >= 12 ? 1 : 0;
      return this.unlinkPanels && new Date(this.leftYear + yearOffset, nextMonth2) < new Date(this.rightYear, this.rightMonth);
    },
    enableYearArrow() {
      return this.unlinkPanels && this.rightYear * 12 + this.rightMonth - (this.leftYear * 12 + this.leftMonth + 1) >= 12;
    }
  },
  watch: {
    value(newVal) {
      if (!newVal) {
        this.minDate = null;
        this.maxDate = null;
      } else if (Array.isArray(newVal)) {
        this.minDate = isDate(newVal[0]) ? new Date(newVal[0]) : null;
        this.maxDate = isDate(newVal[1]) ? new Date(newVal[1]) : null;
        if (this.minDate) {
          this.leftDate = this.minDate;
          if (this.unlinkPanels && this.maxDate) {
            const minDateYear = this.minDate.getFullYear();
            const minDateMonth = this.minDate.getMonth();
            const maxDateYear = this.maxDate.getFullYear();
            const maxDateMonth = this.maxDate.getMonth();
            this.rightDate = minDateYear === maxDateYear && minDateMonth === maxDateMonth ? nextMonth(this.maxDate) : this.maxDate;
          } else {
            this.rightDate = nextMonth(this.leftDate);
          }
        } else {
          this.leftDate = calcDefaultValue(this.defaultValue)[0];
          this.rightDate = nextMonth(this.leftDate);
        }
      }
    },
    defaultValue(val) {
      if (!Array.isArray(this.value)) {
        const [left, right] = calcDefaultValue(val);
        this.leftDate = left;
        this.rightDate = val && val[1] && this.unlinkPanels ? right : nextMonth(this.leftDate);
      }
    }
  },
  methods: {
    getPrefixedClassName,
    handleClose() {
      this.$emit("close");
    },
    handleClear() {
      this.minDate = null;
      this.maxDate = null;
      this.leftDate = calcDefaultValue(this.defaultValue)[0];
      this.rightDate = nextMonth(this.leftDate);
      this.$emit("pick", null);
    },
    handleChangeRange(val) {
      this.minDate = val.minDate;
      this.maxDate = val.maxDate;
      this.rangeState = val.rangeState;
    },
    handleRangePick(val, close = true) {
      const defaultTime = this.defaultTime || DEFAULT_TIME;
      const minDate = modifyWithTimeString(val.minDate, defaultTime[0]);
      const maxDate = modifyWithTimeString(val.maxDate, defaultTime[1]);
      if (this.maxDate === maxDate && this.minDate === minDate) {
        return;
      }
      this.onPick && this.onPick(val);
      this.maxDate = maxDate;
      this.minDate = minDate;
      if (!close) {
        this.$emit("select-start", minDate);
      } else {
        this.$emit("select-end", maxDate);
      }
      setTimeout(() => {
        this.maxDate = maxDate;
        this.minDate = minDate;
      }, 10);
      if (!close || this.showTime) {
        return;
      }
      this.handleConfirm();
    },
    handleMonthPick(month, close = true) {
      const minDate = new Date(this.minDate.getFullYear(), month, 1);
      const maxDate = new Date(this.minDate.getFullYear(), month + 1, 0);
      this.handleRangePick({ minDate, maxDate }, close);
    },
    handleShortcutClick(key) {
      this.currentType = key;
      if (this.currentType === mixDateType.byMonth) {
        this.handleMonthPick(this.minDate.getMonth(), false);
        this.handleConfirm(true);
        return;
      }
      if (this.currentType === mixDateType.byDate) {
        this.handleRangePick(
          {
            minDate: this.minDate,
            maxDate: this.minDate
          },
          false
        );
        this.handleConfirm(true);
        return;
      }
      if (this.currentType === mixDateType.byWeek) {
        const [minDate, maxDate] = getWeekStartAndEnd(this.minDate);
        this.handleRangePick(
          {
            minDate,
            maxDate
          },
          false
        );
        this.handleConfirm(true);
        return;
      }
    },
    leftPrevYear() {
      this.leftDate = prevYear(this.leftDate);
      if (!this.unlinkPanels) {
        this.rightDate = nextMonth(this.leftDate);
      }
    },
    leftPrevMonth() {
      this.leftDate = prevMonth(this.leftDate);
      if (!this.unlinkPanels) {
        this.rightDate = nextMonth(this.leftDate);
      }
    },
    rightNextYear() {
      if (!this.unlinkPanels) {
        this.leftDate = nextYear(this.leftDate);
        this.rightDate = nextMonth(this.leftDate);
      } else {
        this.rightDate = nextYear(this.rightDate);
      }
    },
    rightNextMonth() {
      if (!this.unlinkPanels) {
        this.leftDate = nextMonth(this.leftDate);
        this.rightDate = nextMonth(this.leftDate);
      } else {
        this.rightDate = nextMonth(this.rightDate);
      }
    },
    leftNextYear() {
      this.leftDate = nextYear(this.leftDate);
    },
    leftNextMonth() {
      this.leftDate = nextMonth(this.leftDate);
    },
    rightPrevYear() {
      this.rightDate = prevYear(this.rightDate);
    },
    rightPrevMonth() {
      this.rightDate = prevMonth(this.rightDate);
    },
    handleNextYear() {
      this.leftNextYear();
      this.rightNextYear();
    },
    handleNextMonth() {
      this.leftNextMonth();
      this.rightNextMonth();
    },
    handlePrevYear() {
      this.leftPrevYear();
      this.rightPrevYear();
    },
    handlePrevMonth() {
      this.leftPrevMonth();
      this.rightPrevMonth();
    },
    handleConfirm(visible = false) {
      if (this.isValidValue([this.minDate, this.maxDate])) {
        this.$emit("pick", [this.minDate, this.maxDate], visible);
      }
    },
    isValidValue(value) {
      return Array.isArray(value) && value && value[0] && value[1] && isDate(value[0]) && isDate(value[1]) && value[0].getTime() <= value[1].getTime() && typeof this.disabledDate === "function" ? !this.disabledDate(value[0]) && !this.disabledDate(value[1]) : true;
    },
    resetView() {
      this.minDate = this.value && isDate(this.value[0]) ? new Date(this.value[0]) : null;
      this.maxDate = this.value && isDate(this.value[0]) ? new Date(this.value[1]) : null;
    }
  }
};
const __vue_script__$2 = script$2;
var __vue_render__$2 = function() {
  var _obj, _obj$1, _obj$2, _obj$3;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c("transition", { attrs: { name: "el-zoom-in-top" } }, [
    _c(
      "div",
      {
        directives: [
          {
            name: "show",
            rawName: "v-show",
            value: _vm.visible,
            expression: "visible"
          }
        ],
        class: [
          _vm.getPrefixedClassName("el-picker-panel"),
          _vm.getPrefixedClassName("el-date-picker"),
          _vm.getPrefixedClassName("el-mix-picker-panel"),
          _vm.popperClass,
          _vm.currentType === _vm.mixDateType.bySelf ? _vm.getPrefixedClassName("show-range-picker") : ""
        ]
      },
      [
        _c(
          "div",
          { class: _vm.getPrefixedClassName("el-picker-panel__body-wrapper") },
          [
            _c(
              "div",
              { class: _vm.getPrefixedClassName("el-picker-panel__sidebar") },
              _vm._l(_vm.mixDateList, function(item) {
                return _c(
                  "button",
                  {
                    key: item.key,
                    class: [
                      _vm.getPrefixedClassName("el-picker-panel__shortcut"),
                      _vm.currentType === item.key ? _vm.getPrefixedClassName(
                        "el-picker-panel__shortcut--active"
                      ) : ""
                    ],
                    attrs: { type: "button" },
                    on: {
                      click: function($event) {
                        return _vm.handleShortcutClick(item.key);
                      }
                    }
                  },
                  [
                    _c(
                      "span",
                      {
                        staticClass: "ellipsis",
                        attrs: { "data-tip": item.text() }
                      },
                      [
                        _vm._v(
                          "\n            " + _vm._s(item.text()) + "\n          "
                        )
                      ]
                    ),
                    _vm._v(" "),
                    _c("i", {
                      staticClass: "iconfont vtv-icon-arrow-right",
                      class: _vm.getPrefixedClassName(
                        "el-picker-panel__shortcut__icon"
                      )
                    })
                  ]
                );
              }),
              0
            ),
            _vm._v(" "),
            _c(
              "div",
              { class: _vm.getPrefixedClassName("el-picker-panel__body") },
              [
                _c(
                  "div",
                  {
                    directives: [
                      {
                        name: "show",
                        rawName: "v-show",
                        value: _vm.currentType !== _vm.mixDateType.bySelf,
                        expression: "currentType !== mixDateType.bySelf"
                      }
                    ],
                    class: [
                      _vm.getPrefixedClassName("el-date-picker__header"),
                      _vm.getPrefixedClassName("el-mix-picker-panel__header")
                    ]
                  },
                  [
                    _c("button", {
                      class: [
                        _vm.getPrefixedClassName("el-picker-panel__icon-btn"),
                        _vm.getPrefixedClassName("el-date-picker__prev-btn"),
                        "vtv-icon-prev-year",
                        "iconfont"
                      ],
                      attrs: { type: "button" },
                      on: { click: _vm.handlePrevYear }
                    }),
                    _vm._v(" "),
                    _c("button", {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: _vm.currentType !== _vm.mixDateType.byMonth,
                          expression: "currentType !== mixDateType.byMonth"
                        }
                      ],
                      class: [
                        _vm.getPrefixedClassName("el-picker-panel__icon-btn"),
                        _vm.getPrefixedClassName("el-date-picker__prev-btn"),
                        "vtv-icon-prev-month",
                        "iconfont"
                      ],
                      attrs: { type: "button" },
                      on: { click: _vm.handlePrevMonth }
                    }),
                    _vm._v(" "),
                    _c("span", [_vm._v(_vm._s(_vm.yearLabel))]),
                    _vm._v(" "),
                    _c(
                      "span",
                      {
                        directives: [
                          {
                            name: "show",
                            rawName: "v-show",
                            value: _vm.currentType !== _vm.mixDateType.byMonth,
                            expression: "currentType !== mixDateType.byMonth"
                          }
                        ]
                      },
                      [_vm._v(_vm._s(_vm.monthLablel))]
                    ),
                    _vm._v(" "),
                    _c("button", {
                      class: [
                        _vm.getPrefixedClassName("el-picker-panel__icon-btn"),
                        _vm.getPrefixedClassName("el-date-picker__next-btn"),
                        "vtv-icon-next-year",
                        "iconfont"
                      ],
                      attrs: { type: "button" },
                      on: { click: _vm.handleNextYear }
                    }),
                    _vm._v(" "),
                    _c("button", {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: _vm.currentType !== _vm.mixDateType.byMonth,
                          expression: "currentType !== mixDateType.byMonth"
                        }
                      ],
                      class: [
                        _vm.getPrefixedClassName("el-picker-panel__icon-btn"),
                        _vm.getPrefixedClassName("el-date-picker__next-btn"),
                        "vtv-icon-next-month",
                        "iconfont"
                      ],
                      attrs: { type: "button" },
                      on: { click: _vm.handleNextMonth }
                    })
                  ]
                ),
                _vm._v(" "),
                _c(
                  "div",
                  {
                    directives: [
                      {
                        name: "show",
                        rawName: "v-show",
                        value: _vm.currentType === _vm.mixDateType.byDate,
                        expression: "currentType === mixDateType.byDate"
                      }
                    ]
                  },
                  [
                    _c("date-table", {
                      attrs: {
                        "selection-mode": "day",
                        value: _vm.value,
                        "default-value": _vm.defaultValue ? new Date(_vm.defaultValue) : null,
                        date: _vm.date,
                        mixSelect: true,
                        "disabled-date": _vm.disabledDate
                      },
                      on: { pick: _vm.handleRangePick }
                    })
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "div",
                  {
                    directives: [
                      {
                        name: "show",
                        rawName: "v-show",
                        value: _vm.currentType === _vm.mixDateType.byWeek,
                        expression: "currentType === mixDateType.byWeek"
                      }
                    ]
                  },
                  [
                    _c("date-table", {
                      attrs: {
                        "selection-mode": "week",
                        value: _vm.value,
                        "default-value": _vm.defaultValue ? new Date(_vm.defaultValue) : null,
                        date: _vm.date,
                        mixSelect: true,
                        "disabled-date": _vm.disabledDate
                      },
                      on: { pick: _vm.handleRangePick }
                    })
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "div",
                  {
                    directives: [
                      {
                        name: "show",
                        rawName: "v-show",
                        value: _vm.currentType === _vm.mixDateType.byMonth,
                        expression: "currentType === mixDateType.byMonth"
                      }
                    ]
                  },
                  [
                    _c("month-table", {
                      attrs: {
                        value: _vm.value,
                        "default-value": _vm.defaultValue ? new Date(_vm.defaultValue) : null,
                        date: _vm.date,
                        "disabled-date": _vm.disabledDate
                      },
                      on: { pick: _vm.handleMonthPick }
                    })
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "div",
                  {
                    directives: [
                      {
                        name: "show",
                        rawName: "v-show",
                        value: _vm.currentType === _vm.mixDateType.bySelf,
                        expression: "currentType === mixDateType.bySelf"
                      }
                    ],
                    class: _vm.getPrefixedClassName("el-picker-panel__self")
                  },
                  [
                    _c(
                      "div",
                      {
                        class: [
                          _vm.getPrefixedClassName("el-picker-panel__content"),
                          _vm.getPrefixedClassName(
                            "el-date-range-picker__content"
                          ),
                          _vm.getPrefixedClassName("is-left")
                        ]
                      },
                      [
                        _c(
                          "div",
                          {
                            class: _vm.getPrefixedClassName(
                              "el-date-range-picker__header"
                            )
                          },
                          [
                            _c("button", {
                              class: [
                                _vm.getPrefixedClassName(
                                  "el-picker-panel__icon-btn"
                                ),
                                "vtv-icon-prev-year",
                                "iconfont"
                              ],
                              attrs: { type: "button" },
                              on: { click: _vm.leftPrevYear }
                            }),
                            _vm._v(" "),
                            _c("button", {
                              class: [
                                _vm.getPrefixedClassName(
                                  "el-picker-panel__icon-btn"
                                ),
                                "vtv-icon-prev-month",
                                "iconfont"
                              ],
                              attrs: { type: "button" },
                              on: { click: _vm.leftPrevMonth }
                            }),
                            _vm._v(" "),
                            _vm.unlinkPanels ? _c("button", {
                              class: [
                                _vm.getPrefixedClassName(
                                  "el-picker-panel__icon-btn"
                                ),
                                "vtv-icon-next-year",
                                "iconfont",
                                (_obj = {}, _obj[_vm.getPrefixedClassName("is-disabled")] = !_vm.enableYearArrow, _obj)
                              ],
                              attrs: {
                                type: "button",
                                disabled: !_vm.enableYearArrow
                              },
                              on: { click: _vm.leftNextYear }
                            }) : _vm._e(),
                            _vm._v(" "),
                            _vm.unlinkPanels ? _c("button", {
                              class: [
                                _vm.getPrefixedClassName(
                                  "el-picker-panel__icon-btn"
                                ),
                                "vtv-icon-next-month",
                                "iconfont",
                                (_obj$1 = {}, _obj$1[_vm.getPrefixedClassName("is-disabled")] = !_vm.enableMonthArrow, _obj$1)
                              ],
                              attrs: {
                                type: "button",
                                disabled: !_vm.enableMonthArrow
                              },
                              on: { click: _vm.leftNextMonth }
                            }) : _vm._e(),
                            _vm._v(" "),
                            _c("div", [_vm._v(_vm._s(_vm.leftLabel))])
                          ]
                        ),
                        _vm._v(" "),
                        _c("date-table", {
                          attrs: {
                            "selection-mode": "range",
                            date: _vm.leftDate,
                            "default-value": _vm.defaultValue,
                            "min-date": _vm.minDate,
                            "max-date": _vm.maxDate,
                            "range-state": _vm.rangeState,
                            "disabled-date": _vm.disabledDate
                          },
                          on: {
                            changerange: _vm.handleChangeRange,
                            pick: _vm.handleRangePick
                          }
                        })
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      {
                        class: [
                          _vm.getPrefixedClassName("el-picker-panel__content"),
                          _vm.getPrefixedClassName(
                            "el-date-range-picker__content"
                          ),
                          _vm.getPrefixedClassName("is-right")
                        ]
                      },
                      [
                        _c(
                          "div",
                          {
                            class: _vm.getPrefixedClassName(
                              "el-date-range-picker__header"
                            )
                          },
                          [
                            _vm.unlinkPanels ? _c("button", {
                              class: [
                                _vm.getPrefixedClassName(
                                  "el-picker-panel__icon-btn"
                                ),
                                "vtv-icon-prev-year",
                                "iconfont",
                                (_obj$2 = {}, _obj$2[_vm.getPrefixedClassName("is-disabled")] = !_vm.enableYearArrow, _obj$2)
                              ],
                              attrs: {
                                type: "button",
                                disabled: !_vm.enableYearArrow
                              },
                              on: { click: _vm.rightPrevYear }
                            }) : _vm._e(),
                            _vm._v(" "),
                            _vm.unlinkPanels ? _c("button", {
                              class: [
                                _vm.getPrefixedClassName(
                                  "el-picker-panel__icon-btn"
                                ),
                                "vtv-icon-prev-month",
                                "iconfont",
                                (_obj$3 = {}, _obj$3[_vm.getPrefixedClassName("is-disabled")] = !_vm.enableMonthArrow, _obj$3)
                              ],
                              attrs: {
                                type: "button",
                                disabled: !_vm.enableMonthArrow
                              },
                              on: { click: _vm.rightPrevMonth }
                            }) : _vm._e(),
                            _vm._v(" "),
                            _c("button", {
                              class: [
                                _vm.getPrefixedClassName(
                                  "el-picker-panel__icon-btn"
                                ),
                                "vtv-icon-next-year",
                                "iconfont"
                              ],
                              attrs: { type: "button" },
                              on: { click: _vm.rightNextYear }
                            }),
                            _vm._v(" "),
                            _c("button", {
                              class: [
                                _vm.getPrefixedClassName(
                                  "el-picker-panel__icon-btn"
                                ),
                                "vtv-icon-next-month",
                                "iconfont"
                              ],
                              attrs: { type: "button" },
                              on: { click: _vm.rightNextMonth }
                            }),
                            _vm._v(" "),
                            _c("div", [_vm._v(_vm._s(_vm.rightLabel))])
                          ]
                        ),
                        _vm._v(" "),
                        _c("date-table", {
                          attrs: {
                            "selection-mode": "range",
                            date: _vm.rightDate,
                            "default-value": _vm.defaultValue,
                            "min-date": _vm.minDate,
                            "max-date": _vm.maxDate,
                            "range-state": _vm.rangeState,
                            "disabled-date": _vm.disabledDate
                          },
                          on: {
                            changerange: _vm.handleChangeRange,
                            pick: _vm.handleRangePick
                          }
                        })
                      ],
                      1
                    )
                  ]
                )
              ]
            )
          ]
        )
      ]
    )
  ]);
};
var __vue_staticRenderFns__$2 = [];
__vue_render__$2._withStripped = true;
const __vue_inject_styles__$2 = void 0;
const __vue_scope_id__$2 = void 0;
const __vue_module_identifier__$2 = void 0;
const __vue_is_functional_template__$2 = false;
const __vue_component__$2 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$2, staticRenderFns: __vue_staticRenderFns__$2 },
  __vue_inject_styles__$2,
  __vue_script__$2,
  __vue_scope_id__$2,
  __vue_is_functional_template__$2,
  __vue_module_identifier__$2,
  false,
  void 0,
  void 0,
  void 0
);
const getPanel = function(type) {
  if (type === "daterange" || type === "datetimerange") {
    return __vue_component__$3;
  }
  return __vue_component__$4;
};
var DatePicker = {
  name: componentName.datePicker,
  componentName: componentName.datePicker,
  mixins: [__vue_component__$9],
  props: {
    type: {
      type: String,
      default: "date"
    },
    mixSelect: {
      type: Boolean,
      default: false
    },
    timeArrowControl: Boolean
  },
  watch: {
    type(type) {
      if (this.picker) {
        this.unmountPicker();
        this.panel = this.mixSelect ? __vue_component__$2 : getPanel(type);
        this.mountPicker();
      } else {
        this.panel = this.mixSelect ? __vue_component__$2 : getPanel(type);
      }
    }
  },
  created() {
    this.panel = this.mixSelect ? __vue_component__$2 : getPanel(this.type);
  }
};
const barMap = {
  vertical: {
    offset: "offsetHeight",
    scroll: "scrollTop",
    scrollSize: "scrollHeight",
    size: "height",
    key: "vertical",
    axis: "Y",
    client: "clientY",
    direction: "top"
  },
  horizontal: {
    offset: "offsetWidth",
    scroll: "scrollLeft",
    scrollSize: "scrollWidth",
    size: "width",
    key: "horizontal",
    axis: "X",
    client: "clientX",
    direction: "left"
  }
};
function renderThumbStyle({ move, size, bar }) {
  const style = {};
  const translate = `translate${bar.axis}(${move}%)`;
  style[bar.size] = size;
  style.transform = translate;
  style.msTransform = translate;
  style.webkitTransform = translate;
  return style;
}
var Bar = {
  name: "Bar",
  props: {
    vertical: Boolean,
    size: String,
    move: Number
  },
  computed: {
    bar() {
      return barMap[this.vertical ? "vertical" : "horizontal"];
    },
    wrap() {
      return this.$parent.wrap;
    }
  },
  destroyed() {
    off$1(document, "mouseup", this.mouseUpDocumentHandler);
  },
  methods: {
    getPrefixedClassName,
    clickThumbHandler(e) {
      this.startDrag(e);
      this[this.bar.axis] = e.currentTarget[this.bar.offset] - (e[this.bar.client] - e.currentTarget.getBoundingClientRect()[this.bar.direction]);
    },
    clickTrackHandler(e) {
      const offset = Math.abs(e.target.getBoundingClientRect()[this.bar.direction] - e[this.bar.client]);
      const thumbHalf = this.$refs.thumb[this.bar.offset] / 2;
      const thumbPositionPercentage = (offset - thumbHalf) * 100 / this.$el[this.bar.offset];
      this.wrap[this.bar.scroll] = thumbPositionPercentage * this.wrap[this.bar.scrollSize] / 100;
    },
    startDrag(e) {
      e.stopImmediatePropagation();
      this.cursorDown = true;
      on$1(document, "mousemove", this.mouseMoveDocumentHandler);
      on$1(document, "mouseup", this.mouseUpDocumentHandler);
      document.onselectstart = () => false;
    },
    mouseMoveDocumentHandler(e) {
      if (this.cursorDown === false) {
        return;
      }
      const prevPage = this[this.bar.axis];
      if (!prevPage) {
        return;
      }
      const offset = (this.$el.getBoundingClientRect()[this.bar.direction] - e[this.bar.client]) * -1;
      const thumbClickPosition = this.$refs.thumb[this.bar.offset] - prevPage;
      const thumbPositionPercentage = (offset - thumbClickPosition) * 100 / this.$el[this.bar.offset];
      this.wrap[this.bar.scroll] = thumbPositionPercentage * this.wrap[this.bar.scrollSize] / 100;
    },
    mouseUpDocumentHandler() {
      this.cursorDown = false;
      this[this.bar.axis] = 0;
      off$1(document, "mousemove", this.mouseMoveDocumentHandler);
      document.onselectstart = null;
    }
  },
  render(h) {
    const { size, move, bar } = this;
    const thumbStyle = renderThumbStyle({ size, move, bar });
    return h(
      "div",
      {
        class: [getPrefixedClassName("el-scrollbar__bar"), getPrefixedClassName(`is-${bar.key}`)],
        on: {
          mousedown: this.clickTrackHandler
        }
      },
      [
        h("div", {
          ref: "thumb",
          class: getPrefixedClassName("el-scrollbar__thumb"),
          on: {
            mousedown: this.clickThumbHandler
          },
          style: thumbStyle
        })
      ]
    );
  }
};
function extend(to, _from) {
  for (const key in _from) {
    if (_from.hasOwnProperty(key)) {
      to[key] = _from[key];
    }
  }
  return to;
}
function toObject(arr) {
  const res = {};
  for (let i = 0; i < arr.length; i++) {
    if (arr[i]) {
      extend(res, arr[i]);
    }
  }
  return res;
}
var Scrollbar = {
  name: "Scrollbar",
  components: { Bar },
  props: {
    native: Boolean,
    wrapStyle: {},
    wrapClass: {},
    viewClass: {},
    viewStyle: {},
    noresize: Boolean,
    tag: {
      type: String,
      default: "div"
    }
  },
  data() {
    return {
      sizeWidth: "0",
      sizeHeight: "0",
      moveX: 0,
      moveY: 0
    };
  },
  computed: {
    wrap() {
      return this.$refs.wrap;
    }
  },
  mounted() {
    if (this.native) {
      return;
    }
    this.$nextTick(this.update);
    !this.noresize && addResizeListener(this.$refs.resize, this.update);
  },
  beforeDestroy() {
    if (this.native) {
      return;
    }
    !this.noresize && removeResizeListener(this.$refs.resize, this.update);
  },
  methods: {
    handleScroll() {
      const wrap = this.wrap;
      this.moveY = wrap.scrollTop * 100 / wrap.clientHeight;
      this.moveX = wrap.scrollLeft * 100 / wrap.clientWidth;
    },
    update() {
      const wrap = this.wrap;
      if (!wrap) {
        return;
      }
      const heightPercentage = wrap.clientHeight * 100 / wrap.scrollHeight;
      const widthPercentage = wrap.clientWidth * 100 / wrap.scrollWidth;
      this.sizeHeight = heightPercentage < 100 ? heightPercentage + "%" : "";
      this.sizeWidth = widthPercentage < 100 ? widthPercentage + "%" : "";
    }
  },
  render(h) {
    const gutter = getScrollBarWidth();
    let style = this.wrapStyle;
    if (gutter) {
      const gutterWith = `-${gutter}px`;
      const gutterStyle = `margin-bottom: ${gutterWith}; margin-right: ${gutterWith};`;
      if (Array.isArray(this.wrapStyle)) {
        style = toObject(this.wrapStyle);
        style.marginRight = style.marginBottom = gutterWith;
      } else if (typeof this.wrapStyle === "string") {
        style += gutterStyle;
      } else {
        style = gutterStyle;
      }
    }
    const view = h(
      this.tag,
      {
        class: [getPrefixedClassName("el-scrollbar__view"), this.viewClass],
        style: this.viewStyle,
        ref: "resize"
      },
      this.$slots.default
    );
    const wrapClass = [
      this.wrapClass,
      getPrefixedClassName("el-scrollbar__wrap"),
      gutter ? "" : getPrefixedClassName("el-scrollbar__wrap--hidden-default")
    ];
    const wrap = h(
      "div",
      {
        ref: "wrap",
        style,
        on: {
          scroll: this.handleScroll
        },
        class: wrapClass
      },
      [view]
    );
    let nodes;
    if (!this.native) {
      nodes = [
        wrap,
        h(Bar, {
          props: {
            move: this.moveX,
            size: this.sizeWidth
          }
        }),
        h(Bar, {
          props: {
            vertical: true,
            move: this.moveY,
            size: this.sizeHeight
          }
        })
      ];
    } else {
      nodes = [
        h(
          "div",
          {
            ref: "wrap",
            class: [this.wrapClass, getPrefixedClassName("el-scrollbar__wrap")],
            style
          },
          [view]
        )
      ];
    }
    return h("div", { class: getPrefixedClassName("el-scrollbar") }, nodes);
  }
};
const parseTime = function(time) {
  const values = (time || "").split(":");
  if (values.length >= 2) {
    const hours = parseInt(values[0], 10);
    const minutes = parseInt(values[1], 10);
    return {
      hours,
      minutes
    };
  }
  return null;
};
const compareTime = function(time1, time2) {
  const value1 = parseTime(time1);
  const value2 = parseTime(time2);
  const minutes1 = value1.minutes + value1.hours * 60;
  const minutes2 = value2.minutes + value2.hours * 60;
  if (minutes1 === minutes2) {
    return 0;
  }
  return minutes1 > minutes2 ? 1 : -1;
};
const formatTime = function(time) {
  return (time.hours < 10 ? "0" + time.hours : time.hours) + ":" + (time.minutes < 10 ? "0" + time.minutes : time.minutes);
};
const nextTime = function(time, step) {
  const timeValue = parseTime(time);
  const stepValue = parseTime(step);
  const next = {
    hours: timeValue.hours,
    minutes: timeValue.minutes
  };
  next.minutes += stepValue.minutes;
  next.hours += stepValue.hours;
  next.hours += Math.floor(next.minutes / 60);
  next.minutes = next.minutes % 60;
  return formatTime(next);
};
var script$1 = {
  components: { Scrollbar },
  data() {
    return {
      popperClass: "",
      start: "09:00",
      end: "18:00",
      step: "00:30",
      value: "",
      defaultValue: "",
      visible: false,
      minTime: "",
      maxTime: "",
      width: 0
    };
  },
  computed: {
    items() {
      const start = this.start;
      const end = this.end;
      const step = this.step;
      const result = [];
      if (start && end && step) {
        let current = start;
        while (compareTime(current, end) <= 0) {
          result.push({
            value: current,
            disabled: compareTime(current, this.minTime || "-1:-1") <= 0 || compareTime(current, this.maxTime || "100:100") >= 0
          });
          current = nextTime(current, step);
        }
      }
      return result;
    }
  },
  watch: {
    value(val) {
      if (!val) {
        return;
      }
      this.$nextTick(() => this.scrollToOption());
    }
  },
  methods: {
    getPrefixedClassName,
    handleClick(item) {
      if (!item.disabled) {
        this.$emit("pick", item.value);
      }
    },
    handleClear() {
      this.$emit("pick", null);
    },
    scrollToOption(selector = ".selected") {
      const menu = this.$refs.popper.querySelector(".el-picker-panel__content");
      scrollIntoView(menu, menu.querySelector(selector));
    },
    handleMenuEnter() {
      const selected = this.items.map((item) => item.value).indexOf(this.value) !== -1;
      const hasDefault = this.items.map((item) => item.value).indexOf(this.defaultValue) !== -1;
      const option = selected && ".selected" || hasDefault && ".default" || ".time-select-item:not(.disabled)";
      this.$nextTick(() => this.scrollToOption(option));
    },
    scrollDown(step) {
      const items = this.items;
      const length = items.length;
      let total = items.length;
      let index = items.map((item) => item.value).indexOf(this.value);
      while (total--) {
        index = (index + step + length) % length;
        if (!items[index].disabled) {
          this.$emit("pick", items[index].value, true);
          return;
        }
      }
    },
    isValidValue(date) {
      return this.items.filter((item) => !item.disabled).map((item) => item.value).indexOf(date) !== -1;
    },
    handleKeydown(event) {
      const keyCode = event.keyCode;
      if (keyCode === 38 || keyCode === 40) {
        const mapping = { 40: 1, 38: -1 };
        const offset = mapping[keyCode.toString()];
        this.scrollDown(offset);
        event.stopPropagation();
        return;
      }
    }
  }
};
const __vue_script__$1 = script$1;
var __vue_render__$1 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "transition",
    {
      attrs: { name: "el-zoom-in-top" },
      on: {
        "before-enter": _vm.handleMenuEnter,
        "after-leave": function($event) {
          return _vm.$emit("dodestroy");
        }
      }
    },
    [
      _c(
        "div",
        {
          directives: [
            {
              name: "show",
              rawName: "v-show",
              value: _vm.visible,
              expression: "visible"
            }
          ],
          ref: "popper",
          class: [
            _vm.popperClass,
            _vm.getPrefixedClassName("el-picker-panel"),
            _vm.getPrefixedClassName("time-select"),
            _vm.getPrefixedClassName("el-popper")
          ],
          style: { width: _vm.width + "px" }
        },
        [
          _c(
            "scrollbar",
            {
              attrs: {
                noresize: "",
                "wrap-class": _vm.getPrefixedClassName(
                  "el-picker-panel__content"
                )
              }
            },
            _vm._l(_vm.items, function(item) {
              var _obj;
              return _c(
                "div",
                {
                  key: item.value,
                  class: [
                    _vm.getPrefixedClassName("time-select-item"),
                    (_obj = {}, _obj[_vm.getPrefixedClassName("selected")] = _vm.value === item.value, _obj[_vm.getPrefixedClassName("disabled")] = item.disabled, _obj[_vm.getPrefixedClassName("default")] = item.value === _vm.defaultValue, _obj)
                  ],
                  attrs: { disabled: item.disabled },
                  on: {
                    click: function($event) {
                      return _vm.handleClick(item);
                    }
                  }
                },
                [_vm._v("\n        " + _vm._s(item.value) + "\n      ")]
              );
            }),
            0
          )
        ],
        1
      )
    ]
  );
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
var TimeSelect = {
  name: componentName.timeSelect,
  componentName: componentName.timeSelect,
  mixins: [__vue_component__$9],
  props: {
    type: {
      type: String,
      default: "time-select"
    }
  },
  beforeCreate() {
    this.panel = __vue_component__$1;
  }
};
var script = {
  name: componentName.timeRangePicker,
  componentName: componentName.timeRangePicker,
  components: {
    TimePicker: __vue_component__$5,
    SfSpace
  },
  props: {
    value: {
      type: Object,
      default: function() {
        return {
          start: {
            hour: 0,
            minute: 0,
            second: 0
          },
          end: {
            hour: 0,
            minute: 0,
            second: 0
          }
        };
      }
    },
    defaultDisabled: {
      type: Boolean,
      default: false
    },
    showSecond: {
      type: Boolean,
      default: true
    },
    showTomorrowLabel: {
      type: Boolean,
      default: true
    }
  },
  data: function() {
    return {
      defaultValue: this.value || this.$options.props.value.default(),
      toLabel: $i("scp.vt_component.sf_widget.packages.date_picker.time_picker.to"),
      tomorrowLabel: $i("scp.vt_component.sf_widget.packages.date_picker.time_picker.tomorrow")
    };
  },
  computed: {
    isShowTomorrwLabel() {
      var _a, _b, _c, _d, _e, _f;
      if (!this.showTomorrowLabel) {
        return false;
      }
      const { start, end } = this.defaultValue;
      const startTime = new Date(2024, 3, 20, (_a = start == null ? void 0 : start.hour) != null ? _a : 0, (_b = start == null ? void 0 : start.minute) != null ? _b : 0, (_c = start == null ? void 0 : start.second) != null ? _c : 0);
      const endTime = new Date(2024, 3, 20, (_d = end == null ? void 0 : end.hour) != null ? _d : 0, (_e = end == null ? void 0 : end.minute) != null ? _e : 0, (_f = end == null ? void 0 : end.second) != null ? _f : 0);
      return startTime > endTime;
    }
  },
  watch: {
    defaultValue: {
      deep: true,
      handler() {
        this._emitInputStart();
      }
    }
  },
  methods: {
    getPrefixedClassName,
    getFullUtid(utidBase) {
      return this.$attrs.utid ? `${this.$attrs.utid}-${utidBase}` : utidBase;
    },
    _emitInputStart: function() {
      this.$emit("input", this.defaultValue);
    }
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    { class: _vm.getPrefixedClassName("el-time-range-pricker") },
    [
      _c(
        "sf-space",
        [
          _c("time-picker", {
            attrs: {
              utid: _vm.getFullUtid("time-start-picker"),
              defaultWidth: "120",
              defaultDisabled: _vm.defaultDisabled,
              "show-second": _vm.showSecond
            },
            model: {
              value: _vm.defaultValue.start,
              callback: function($$v) {
                _vm.$set(_vm.defaultValue, "start", $$v);
              },
              expression: "defaultValue.start"
            }
          }),
          _vm._v(" "),
          _c(
            "span",
            { class: _vm.getPrefixedClassName("el-time-range-pricker__text") },
            [_vm._v("\n      " + _vm._s(_vm.toLabel) + "\n    ")]
          ),
          _vm._v(" "),
          _c("time-picker", {
            attrs: {
              utid: _vm.getFullUtid("time-end-picker"),
              defaultWidth: "120",
              defaultDisabled: _vm.defaultDisabled,
              "show-second": _vm.showSecond
            },
            model: {
              value: _vm.defaultValue.end,
              callback: function($$v) {
                _vm.$set(_vm.defaultValue, "end", $$v);
              },
              expression: "defaultValue.end"
            }
          }),
          _vm._v(" "),
          _c(
            "span",
            {
              directives: [
                {
                  name: "show",
                  rawName: "v-show",
                  value: _vm.isShowTomorrwLabel,
                  expression: "isShowTomorrwLabel"
                }
              ],
              class: _vm.getPrefixedClassName("el-time-range-pricker__text")
            },
            [_vm._v("\n      " + _vm._s(_vm.tomorrowLabel) + "\n    ")]
          )
        ],
        1
      )
    ],
    1
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { DatePicker as SfDatePicker, __vue_component__$5 as SfTimePicker, __vue_component__ as SfTimeRangePicker, TimeSelect as SfTimeSelect };
