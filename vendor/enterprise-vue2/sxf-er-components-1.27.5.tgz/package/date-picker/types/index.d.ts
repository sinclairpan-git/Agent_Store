import { VNode } from 'vue';

export declare type SfDatePickerType =
  | 'date'
  | 'datetime'
  | 'dates'
  | 'daterange'
  | 'datetimerange'
  | 'year'
  | 'month'
  | 'week'
  | 'time'
  | 'time-select'
  | 'timerange';

export interface SfDatePickerProps {
  size: string;
  type: SfDatePickerType;
  /**
   * 显示的格式，yyyy-MM-dd、timestamp等
   */
  format: string;
  /**
   * 值的格式，yyyy-MM-dd、timestamp等
   */
  valueFormat: string;
  /**
   * 是否只读
   *
   * @default false
   */
  readonly: boolean;
  /**
   * 当type不包括xxrange时起效
   */
  placeholder: string;
  /**
   * 当type包括xxrange时起效
   */
  startPlaceholder: string;
  /**
   * 当type包括xxrange时起效
   */
  endPlaceholder: string;
  prefixIcon: string;
  /**
   * @default 'el-icon-circle-close'
   */
  clearIcon: string;
  /**
   * 原生name属性
   */
  name: string;
  /**
   * 是否禁用
   *
   * @default false
   */
  disabled: boolean;
  /**
   * @default true
   */
  clearable: boolean;
  /**
   * @default ''
   */
  id: string;
  popperClass: string;
  /**
   * @default true
   */
  editable: boolean;
  align: 'left' | 'center' | 'right';
  /**
   * @default '-'
   */
  rangeSeparator: string;
  value: any[] | string | number | Date;
  /**
   * 与type取值相关，重置组件时，本配置生效
   */
  defaultValue: any[] | string | number | Date;
  defaultTime: any[] | string | number | Date;
  /**
   * @default true
   */
  unlinkPanels: boolean;
}

export interface SfDatePickerSlots {
  $slots: {
    default?: VNode[];
    suffix?: VNode[];
  };
}

export interface SfDatePickerEvents {
  $emit(eventName: 'blur', eventData: this): this;
  $emit(eventName: 'focus', eventData: this): this;
  $emit(eventName: 'change', eventData: any): this;
  $emit(eventName: 'input', eventData: any): this;
}

export interface SfDatePickerMethods {
  pickerOptions: {
    shortcuts: Array<{
      text: string;
      onClick(picker: any): void;
    }>;
    defineMaxTime?: ({
      val,
      close,
      maxTime,
    }: {
      val: {
        maxDate: any;
        minDate: any;
      };
      close: boolean;
      maxTime: string;
    }) => string;
  };
  focus: () => void;
  blur: () => void;
  hidePicker(): void;
  showPicker(): void;
  /**
   * 获取数据
   */
  getData(): void;
  /**
   * 触发提交事件
   *
   * @param date 默认值''
   * @param visible 默认值false
   */
  pick(date: any, visible: boolean): void;
  reset(): void;
}

export type SfDatePicker = Readonly<SfDatePickerProps & SfDatePickerSlots & SfDatePickerMethods> & Vue;
export type SfTimePicker = SfDatePicker;
export type SfTimeSelect = SfDatePicker;
