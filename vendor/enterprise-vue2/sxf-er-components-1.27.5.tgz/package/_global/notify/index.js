import notify from '@sxf/er-widget/notify';
const getCamelCaseName = (prefix, name) => {
  if (!prefix) {
    return `${name}`;
  }
  const formattedPrefix = prefix.charAt(0).toLowerCase() + prefix.slice(1);
  const formattedName = name.charAt(0).toUpperCase() + name.slice(1);
  return `${formattedPrefix}${formattedName}`;
};
var index = {
  install(Vue, option = {}) {
    const { prefix = "" } = option;
    Vue.prototype[`$${getCamelCaseName(prefix, "notify")}`] = notify;
    Vue.prototype[`$${getCamelCaseName(prefix, "ok")}`] = notify.ok;
    Vue.prototype[`$${getCamelCaseName(prefix, "fail")}`] = notify.fail;
  }
};
export { index as default };
