export interface NotifyOptions {
  /**
   * 类型
   *
   * @default 'ok'
   */
  type?: 'ok' | 'warn' | 'info' | 'fail' | 'email';

  /**
   * 标题
   */
  title?: string;

  /**
   * 内容
   */
  msg: string;

  /**
   * 是否encode
   * 为false的话不调用htmlEncode
   */
  autoEncode?: boolean;

  /**
   * 显示查看详情
   * 为false不显示
   */
  detailMsg?: string;
}

/**
 * 通知提示
 */
export interface Notify {
  /**
   * 提示
   *
   * @param {(string | NotifyOptions)} [opt]
   * @returns {JQuery<HTMLElement>}
   */
  show(opt: string | NotifyOptions): JQuery<HTMLElement>;

  /**
   * 成功提示
   *
   * @param {(string | NotifyOptions)} [opt]
   * @returns {JQuery<HTMLElement>}
   */
  ok(opt: string | NotifyOptions): JQuery<HTMLElement>;

  /**
   * 失败提示
   *
   * @param {string} msg
   * @returns {JQuery<HTMLElement>}
   */
  fail(msg: string): JQuery<HTMLElement>;

  /**
   * 告警提示
   *
   * @param {string} msg
   * @returns {JQuery<HTMLElement>}
   */
  warn(msg: string): JQuery<HTMLElement>;

  /**
   * 信息提示
   *
   * @param {string} msg
   * @returns {JQuery<HTMLElement>}
   */
  info(msg: string): JQuery<HTMLElement>;

  /**
   * 邮件提示
   *
   * @param {(string | NotifyOptions)} msg
   * @param {string} [title]
   * @returns {JQuery<HTMLElement>}
   */
  message(msg: string | NotifyOptions, title?: string): JQuery<HTMLElement>;
}
