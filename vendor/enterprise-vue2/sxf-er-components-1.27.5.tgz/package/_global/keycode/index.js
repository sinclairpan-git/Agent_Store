const NUMBER_0_CODE = 96, NUMBER_9_CODE = 105, NUM_0_CODE = 48, NUM_9_CODE = 57;
function getNumKeyArray() {
  const retArr = [];
  for (let i = NUMBER_0_CODE; i <= NUMBER_9_CODE; i++) {
    retArr.push(i);
  }
  for (let i = NUM_0_CODE; i <= NUM_9_CODE; i++) {
    retArr.push(i);
  }
  return retArr;
}
var index = {
  install(Vue) {
    Vue.config.keyCodes = {
      number: getNumKeyArray(),
      dot: [110, 190]
    };
  }
};
export { index as default };
