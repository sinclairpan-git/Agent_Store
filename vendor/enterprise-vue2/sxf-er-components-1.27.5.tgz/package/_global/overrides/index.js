const OverridesMixin = {
  props: {
    overrides: {
      default: null
    }
  },
  created() {
    if (this.overrides) {
      let supers;
      let overrides;
      if (typeof this.overrides === "object") {
        overrides = this.overrides;
      } else if (typeof this.overrides === "function") {
        overrides = this.overrides();
      }
      if (!overrides) {
        overrides = {};
      }
      Object.keys(overrides).forEach((fnKey) => {
        const fn = overrides[fnKey];
        if (typeof fn === "function") {
          if (this[fnKey]) {
            supers = supers || {};
            supers[fnKey] = this[fnKey];
          }
          this[fnKey] = fn;
        }
      });
      if (supers) {
        this.supers = supers;
      }
    }
  }
};
var index = {
  install(Vue) {
    Vue.mixin(OverridesMixin);
  }
};
export { index as default };
