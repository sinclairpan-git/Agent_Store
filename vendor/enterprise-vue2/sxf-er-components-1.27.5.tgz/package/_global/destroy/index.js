import $ from 'jquery';
var index = {
  install(Vue) {
    const _destroy = Vue.prototype.$destroy;
    const simpleDestroy = function() {
      $(this.$el).remove();
    };
    Vue.prototype.$destroy = function() {
      const ret = _destroy.apply(this, arguments);
      Vue.nextTick(simpleDestroy.bind(this));
      return ret;
    };
  }
};
export { index as default };
