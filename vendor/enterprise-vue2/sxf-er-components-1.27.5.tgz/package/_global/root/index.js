let root;
function getRoot(vm) {
  if (typeof root === "undefined") {
    let elem = document.getElementById("app");
    while (elem && elem !== document.body) {
      const instance = elem.__vue__;
      if (instance) {
        root = elem.__vue__;
      }
      elem = elem.parentElement;
    }
  }
  return root || vm.$root;
}
const AppRootMixin = {
  created() {
    this.APP_ROOT = getRoot(this);
    if (this.APP_ROOT && this !== this.APP_ROOT && this === this.$root) {
      this.APP_ROOT.$children.push(this);
      this.$parent = this.APP_ROOT;
      this.$root = this.APP_ROOT;
    }
  }
};
var index = {
  install(Vue) {
    Vue.mixin(AppRootMixin);
  }
};
export { AppRootMixin, index as default };
