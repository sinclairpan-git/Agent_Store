import { poolFuncs } from '@sxf/er-components/_utils/auto-destroy-utils';
import LoadMask from '@sxf/er-widget/mask';
import $ from 'jquery';
import uuid from '@sxf/er-utils/uuid';
import { messageBoxCreators } from '@sxf/er-components/window';
import messageBox from '@sxf/er-widget/messageBox';
import notify from '@sxf/er-widget/notify';
import { simpleRequest, simpleWhen, simpleMonitor, getMessageConfig } from '@sxf/er-components/_utils/simple-request';
import { ajax, get, post } from '@sxf/er-utils/ajax';
import apply from '@sxf/er-utils/apply';
import format from '@sxf/er-utils/format';
import numberic from '@sxf/er-utils/numberic';
const getCamelCaseName = (prefix, name) => {
  if (!prefix) {
    return `${name}`;
  }
  const formattedPrefix = prefix.charAt(0).toLowerCase() + prefix.slice(1);
  const formattedName = name.charAt(0).toUpperCase() + name.slice(1);
  return `${formattedPrefix}${formattedName}`;
};
const AutoDestroyMixin = {
  beforeDestroy() {
    poolFuncs.$destroyPools.call(this);
  }
};
var FactoryPlugin = {
  install(Vue, option = {}) {
    const { prefix = "" } = option;
    Object.keys(poolFuncs).forEach((name) => {
      const prototypeName = "$" + getCamelCaseName(prefix, name.replace(/^\$/, ""));
      Vue.prototype[prototypeName] = poolFuncs[name];
    });
    Vue.mixin(AutoDestroyMixin);
  }
};
const createLoadMaskMixin = (option = {}) => {
  const { prefix = "" } = option;
  const propName = `$${getCamelCaseName(prefix, "loadMask")}`;
  const initFlagName = `__${getCamelCaseName(prefix, "loadMaskInited")}`;
  return {
    props: {
      loadMask: {
        default: null
      }
    },
    mounted() {
      const loadMaskConfig = this.$options.loadMask || this.loadMask || {};
      let loadMask;
      Object.defineProperty(this, propName, {
        configurable: true,
        get: () => {
          if (loadMask) {
            return loadMask;
          }
          this[initFlagName] = true;
          const target = loadMaskConfig.target || this.$el;
          const config = typeof loadMaskConfig === "object" ? loadMaskConfig : null;
          loadMask = new LoadMask(target, config);
          return loadMask;
        }
      });
    },
    beforeDestroy() {
      if (this[initFlagName]) {
        this[propName].destroy();
      }
    }
  };
};
createLoadMaskMixin();
function mask(el, options) {
  el = el || this.$el;
  const maskKey = uuid("maskKey-"), $el = $(el || this.$el);
  if ($el.data("maskKey")) {
    return;
  }
  $el.data("maskKey", maskKey);
  this._maskMap = this._maskMap || {};
  this._maskMap[maskKey] = new LoadMask($el, options);
  this._maskMap[maskKey].show();
}
function unmask(el) {
  const $el = $(el || this.$el);
  const maskKey = $el.data("maskKey");
  if (!maskKey) {
    return;
  }
  this._maskMap[maskKey].destroy();
  $el.data("maskKey", null);
}
var LoadMaskPlugin = {
  install(Vue, option = {}) {
    const { prefix = "" } = option;
    Vue.mixin(createLoadMaskMixin(option));
    Vue.prototype["$" + getCamelCaseName(prefix, "mask")] = mask;
    Vue.prototype["$" + getCamelCaseName(prefix, "unmask")] = unmask;
  }
};
var ModalPlugin = {
  install(Vue, option = {}) {
    const { prefix = "" } = option;
    Vue.prototype[`$${getCamelCaseName(prefix, "confirmWindow")}`] = messageBoxCreators.$confirmWindow;
    Vue.prototype[`$${getCamelCaseName(prefix, "infoWindow")}`] = messageBoxCreators.$infoWindow;
    Vue.prototype[`$${getCamelCaseName(prefix, "warnWindow")}`] = messageBoxCreators.$warnWindow;
    Vue.prototype[`$${getCamelCaseName(prefix, "successWindow")}`] = messageBoxCreators.$successWindow;
    Vue.prototype[`$${getCamelCaseName(prefix, "dangerWindow")}`] = messageBoxCreators.$dangerWindow;
    Vue.prototype[`$${getCamelCaseName(prefix, "errorWindow")}`] = messageBoxCreators.$errorWindow;
    Vue.prototype[`$${getCamelCaseName(prefix, "deleteWindow")}`] = messageBoxCreators.$deleteWindow;
    Vue.prototype[`$${getCamelCaseName(prefix, "showErr")}`] = messageBox.showErr;
    Vue.prototype[`$${getCamelCaseName(prefix, "showInfo")}`] = messageBox.showInfo;
    Vue.prototype[`$${getCamelCaseName(prefix, "showWarn")}`] = messageBox.showWarn;
    Vue.prototype[`$${getCamelCaseName(prefix, "confirm")}`] = messageBox.confirm;
    Vue.prototype[`$${getCamelCaseName(prefix, "confirmDelete")}`] = messageBox.confirmDelete;
    Vue.prototype[`$${getCamelCaseName(prefix, "confirmDeleteWithOK")}`] = messageBox.confirmDeleteWithOK;
  }
};
var NotifyPlugin = {
  install(Vue, option = {}) {
    const { prefix = "" } = option;
    Vue.prototype[`$${getCamelCaseName(prefix, "notify")}`] = notify;
    Vue.prototype[`$${getCamelCaseName(prefix, "ok")}`] = notify.ok;
    Vue.prototype[`$${getCamelCaseName(prefix, "fail")}`] = notify.fail;
  }
};
var SimpleRequestPlugin = {
  install(Vue, option = {}) {
    const { prefix = "" } = option;
    Vue.prototype[`$${getCamelCaseName(prefix, "simpleRequest")}`] = simpleRequest;
    Vue.prototype[`$${getCamelCaseName(prefix, "simpleWhen")}`] = simpleWhen;
    Vue.prototype[`$${getCamelCaseName(prefix, "simpleMonitor")}`] = simpleMonitor;
    Vue.prototype[`$${getCamelCaseName(prefix, "MESSAGE")}`] = getMessageConfig();
  }
};
var UtilsPlugin = {
  install(Vue, option = {}) {
    const { prefix = "" } = option;
    Vue.prototype[`$${getCamelCaseName(prefix, "formatter")}`] = format;
    Vue.prototype[`$${getCamelCaseName(prefix, "numberic")}`] = numberic;
    Vue.prototype[`$${getCamelCaseName(prefix, "ajax")}`] = ajax;
    Vue.prototype[`$${getCamelCaseName(prefix, "get")}`] = get;
    Vue.prototype[`$${getCamelCaseName(prefix, "post")}`] = post;
    Vue.prototype[`$${getCamelCaseName(prefix, "uuid")}`] = uuid;
    Vue.prototype[`$${getCamelCaseName(prefix, "apply")}`] = apply;
    Vue.prototype[`$${getCamelCaseName(prefix, "isDestroyed")}`] = function() {
      return this._isDestroyed;
    };
  }
};
function installPlugin(Vue, option) {
  Vue.use(FactoryPlugin, option);
  Vue.use(LoadMaskPlugin, option);
  Vue.use(NotifyPlugin, option);
  Vue.use(SimpleRequestPlugin, option);
  Vue.use(ModalPlugin, option);
  Vue.use(UtilsPlugin, option);
}
export { installPlugin };
