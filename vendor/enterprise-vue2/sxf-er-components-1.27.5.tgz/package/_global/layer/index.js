import { Layer } from '@sxf/er-components/layer';
var index = {
  install(Vue) {
    Vue.prototype.$layer = function(vueComponent, options) {
      return new Layer(vueComponent, options, Vue);
    };
  }
};
export { index as default };
