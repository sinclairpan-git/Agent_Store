import type { LoadMask } from '@sxf/er-components/_global/mask/types';

type AjaxReturnType = any;

interface IAsyncOptions {
  /**
   * 支持自定义传入loadMask或者使用组件注入的$loadMask，不传则不使用遮罩；
   */
  mask?: LoadMask | boolean;

  /**
   * 是否立即显示遮罩，用于处理请求之间切换遮罩导致的闪屏；
   */
  maskImmediate?: boolean;

  /**
   * 自定义请求信息，没传就是不提示；自定义请求信息，没传就是不提示；
   */
  notify?: notifyType;

  /**
   * 自定义monitor回调，(success, json) => {}；
   */
  callback?: (success: boolean, json: any) => void;

  /**
   * 操作名称，用于提示信息，如XX操作成功或者失败
   */
  actionText?: string;

  monitorOptions?: any;
}

type notifyType =
  | 'post'
  | 'delete'
  | 'put'
  | 'sync'
  | 'async'
  | 'load'
  | 'get'
  | { okText?: string; failText?: string };

/**
 * 请求函数的封装，集成提示、遮罩和异步任务轮询处理
 */
export interface ISimpleRequestOptions {
  /**
   * 请求接口，传入数组则会调用simpleWhen，传入函数会配合下面参数ajaxParams执行，建议直接传入defer；
   */
  request: AjaxReturnType | ((...args: any) => AjaxReturnType);

  /**
   * 请求参数，历史遗留，当request是函数的时候作为参数使用；
   */
  ajaxParams?: any;

  /**
   * 自定义请求信息，没传就是不提示；
   */
  notify?: notifyType;

  /**
   * 是否使用loadmask，或直接传入mask；
   */
  mask?: LoadMask | boolean;
  /**
   * 自定义 maskText，用于自定义遮罩提示文本，如果 mask 是 LoadMask 实例，则会覆盖 LoadMask 实例初始化的 msg（如有）
   */
  maskText?: string;

  /**
   * 使用abort掉上一个重复请求，一般get的情况下使用；
   */
  abortLast?: boolean;

  /**
   * 操作名称，用于提示信息，如XX操作成功或者失败；
   */
  actionText?: string;

  /**
   * 异步请求monitor配置，回调、提示和遮罩等，传true则使用默认配置；
   */
  withMonitor?: boolean | IAsyncOptions;

  /**
   * 是否立即显示遮罩，用于处理请求之间切换遮罩导致的闪屏；
   */
  maskImmediate?: boolean;
}

interface ISimpleWhenOptions {
  notify?: notifyType;
  mask?: LoadMask | boolean;
  maskImmediate?: boolean;
  request: AjaxReturnType[];
}

export interface SimpleRequestMixin {
  /**
   * 请求函数的封装，集成提示、遮罩和异步任务轮询处理
   */
  $simpleRequest: (options: ISimpleRequestOptions) => AjaxReturnType;

  /**
   * $.when函数的封装，集成提示和遮罩处理
   */
  $simpleWhen: (options: ISimpleWhenOptions) => AjaxReturnType;

  /**
   * monitor函数的封装，集成提示和遮罩处理
   */
  $simpleMonitor: (pid?: string | AjaxReturnType, asyncOptions?: IAsyncOptions) => AjaxReturnType;
}
