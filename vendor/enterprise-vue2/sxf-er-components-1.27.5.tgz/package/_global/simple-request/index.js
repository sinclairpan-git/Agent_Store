import { simpleRequest, simpleWhen, simpleMonitor, getMessageConfig } from '@sxf/er-components/_utils/simple-request';
const getCamelCaseName = (prefix, name) => {
  if (!prefix) {
    return `${name}`;
  }
  const formattedPrefix = prefix.charAt(0).toLowerCase() + prefix.slice(1);
  const formattedName = name.charAt(0).toUpperCase() + name.slice(1);
  return `${formattedPrefix}${formattedName}`;
};
var index = {
  install(Vue, option = {}) {
    const { prefix = "" } = option;
    Vue.prototype[`$${getCamelCaseName(prefix, "simpleRequest")}`] = simpleRequest;
    Vue.prototype[`$${getCamelCaseName(prefix, "simpleWhen")}`] = simpleWhen;
    Vue.prototype[`$${getCamelCaseName(prefix, "simpleMonitor")}`] = simpleMonitor;
    Vue.prototype[`$${getCamelCaseName(prefix, "MESSAGE")}`] = getMessageConfig();
  }
};
export { index as default };
