import LoadMask from '@sxf/er-widget/mask';
import $ from 'jquery';
import uuid from '@sxf/er-utils/uuid';
const getCamelCaseName = (prefix, name) => {
  if (!prefix) {
    return `${name}`;
  }
  const formattedPrefix = prefix.charAt(0).toLowerCase() + prefix.slice(1);
  const formattedName = name.charAt(0).toUpperCase() + name.slice(1);
  return `${formattedPrefix}${formattedName}`;
};
const createLoadMaskMixin = (option = {}) => {
  const { prefix = "" } = option;
  const propName = `$${getCamelCaseName(prefix, "loadMask")}`;
  const initFlagName = `__${getCamelCaseName(prefix, "loadMaskInited")}`;
  return {
    props: {
      loadMask: {
        default: null
      }
    },
    mounted() {
      const loadMaskConfig = this.$options.loadMask || this.loadMask || {};
      let loadMask;
      Object.defineProperty(this, propName, {
        configurable: true,
        get: () => {
          if (loadMask) {
            return loadMask;
          }
          this[initFlagName] = true;
          const target = loadMaskConfig.target || this.$el;
          const config = typeof loadMaskConfig === "object" ? loadMaskConfig : null;
          loadMask = new LoadMask(target, config);
          return loadMask;
        }
      });
    },
    beforeDestroy() {
      if (this[initFlagName]) {
        this[propName].destroy();
      }
    }
  };
};
const LoadMaskMixin = createLoadMaskMixin();
function mask(el, options) {
  el = el || this.$el;
  const maskKey = uuid("maskKey-"), $el = $(el || this.$el);
  if ($el.data("maskKey")) {
    return;
  }
  $el.data("maskKey", maskKey);
  this._maskMap = this._maskMap || {};
  this._maskMap[maskKey] = new LoadMask($el, options);
  this._maskMap[maskKey].show();
}
function unmask(el) {
  const $el = $(el || this.$el);
  const maskKey = $el.data("maskKey");
  if (!maskKey) {
    return;
  }
  this._maskMap[maskKey].destroy();
  $el.data("maskKey", null);
}
var index = {
  install(Vue, option = {}) {
    const { prefix = "" } = option;
    Vue.mixin(createLoadMaskMixin(option));
    Vue.prototype["$" + getCamelCaseName(prefix, "mask")] = mask;
    Vue.prototype["$" + getCamelCaseName(prefix, "unmask")] = unmask;
  }
};
export { LoadMaskMixin, index as default };
