export interface LoadMask {
  init(): void;
  show(force?: boolean): void;
  show(options: { force?: boolean; text?: string }): void;
  hide(): void;
  text(text: string, type?: '' | 'error'): void;
  toggleStatus(type?: '' | 'error'): void;
  html(html?: string): void;
  destroy(): void;
}

export type LoadMaskAlignType = 'horizontal' | 'vertical';

export interface LoadMaskOptions {
  /** 是否延迟显示 */
  defer?: boolean;
  /** 遮罩层显示的文本 */
  msg?: string;
  /** 遮罩层的样式类 */
  cls?: string;
  /** 加载动画的样式类 */
  loadingCls?: string;
  /** 文本的样式类 */
  msgCls?: string;
  /** 排版方式：horizontal|vertical, 默认vertical */
  align?: 'horizontal' | 'vertical';
}
