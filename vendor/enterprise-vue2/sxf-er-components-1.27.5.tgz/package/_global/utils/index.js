import { ajax, get, post } from '@sxf/er-utils/ajax';
import apply from '@sxf/er-utils/apply';
import format from '@sxf/er-utils/format';
import numberic from '@sxf/er-utils/numberic';
import uuid from '@sxf/er-utils/uuid';
const getCamelCaseName = (prefix, name) => {
  if (!prefix) {
    return `${name}`;
  }
  const formattedPrefix = prefix.charAt(0).toLowerCase() + prefix.slice(1);
  const formattedName = name.charAt(0).toUpperCase() + name.slice(1);
  return `${formattedPrefix}${formattedName}`;
};
var index = {
  install(Vue, option = {}) {
    const { prefix = "" } = option;
    Vue.prototype[`$${getCamelCaseName(prefix, "formatter")}`] = format;
    Vue.prototype[`$${getCamelCaseName(prefix, "numberic")}`] = numberic;
    Vue.prototype[`$${getCamelCaseName(prefix, "ajax")}`] = ajax;
    Vue.prototype[`$${getCamelCaseName(prefix, "get")}`] = get;
    Vue.prototype[`$${getCamelCaseName(prefix, "post")}`] = post;
    Vue.prototype[`$${getCamelCaseName(prefix, "uuid")}`] = uuid;
    Vue.prototype[`$${getCamelCaseName(prefix, "apply")}`] = apply;
    Vue.prototype[`$${getCamelCaseName(prefix, "isDestroyed")}`] = function() {
      return this._isDestroyed;
    };
  }
};
export { index as default };
