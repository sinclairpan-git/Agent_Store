import { poolFuncs } from '@sxf/er-components/_utils/auto-destroy-utils';
const getCamelCaseName = (prefix, name) => {
  if (!prefix) {
    return `${name}`;
  }
  const formattedPrefix = prefix.charAt(0).toLowerCase() + prefix.slice(1);
  const formattedName = name.charAt(0).toUpperCase() + name.slice(1);
  return `${formattedPrefix}${formattedName}`;
};
const AutoDestroyMixin = {
  beforeDestroy() {
    poolFuncs.$destroyPools.call(this);
  }
};
var index = {
  install(Vue, option = {}) {
    const { prefix = "" } = option;
    Object.keys(poolFuncs).forEach((name) => {
      const prototypeName = "$" + getCamelCaseName(prefix, name.replace(/^\$/, ""));
      Vue.prototype[prototypeName] = poolFuncs[name];
    });
    Vue.mixin(AutoDestroyMixin);
  }
};
export { index as default };
