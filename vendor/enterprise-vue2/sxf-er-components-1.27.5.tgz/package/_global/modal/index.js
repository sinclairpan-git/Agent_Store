import { messageBoxCreators } from '@sxf/er-components/window';
import messageBox from '@sxf/er-widget/messageBox';
const getCamelCaseName = (prefix, name) => {
  if (!prefix) {
    return `${name}`;
  }
  const formattedPrefix = prefix.charAt(0).toLowerCase() + prefix.slice(1);
  const formattedName = name.charAt(0).toUpperCase() + name.slice(1);
  return `${formattedPrefix}${formattedName}`;
};
var index = {
  install(Vue, option = {}) {
    const { prefix = "" } = option;
    Vue.prototype[`$${getCamelCaseName(prefix, "confirmWindow")}`] = messageBoxCreators.$confirmWindow;
    Vue.prototype[`$${getCamelCaseName(prefix, "infoWindow")}`] = messageBoxCreators.$infoWindow;
    Vue.prototype[`$${getCamelCaseName(prefix, "warnWindow")}`] = messageBoxCreators.$warnWindow;
    Vue.prototype[`$${getCamelCaseName(prefix, "successWindow")}`] = messageBoxCreators.$successWindow;
    Vue.prototype[`$${getCamelCaseName(prefix, "dangerWindow")}`] = messageBoxCreators.$dangerWindow;
    Vue.prototype[`$${getCamelCaseName(prefix, "errorWindow")}`] = messageBoxCreators.$errorWindow;
    Vue.prototype[`$${getCamelCaseName(prefix, "deleteWindow")}`] = messageBoxCreators.$deleteWindow;
    Vue.prototype[`$${getCamelCaseName(prefix, "showErr")}`] = messageBox.showErr;
    Vue.prototype[`$${getCamelCaseName(prefix, "showInfo")}`] = messageBox.showInfo;
    Vue.prototype[`$${getCamelCaseName(prefix, "showWarn")}`] = messageBox.showWarn;
    Vue.prototype[`$${getCamelCaseName(prefix, "confirm")}`] = messageBox.confirm;
    Vue.prototype[`$${getCamelCaseName(prefix, "confirmDelete")}`] = messageBox.confirmDelete;
    Vue.prototype[`$${getCamelCaseName(prefix, "confirmDeleteWithOK")}`] = messageBox.confirmDeleteWithOK;
  }
};
export { index as default };
