import { $i } from '@sxf/er-config';
import { isInstanceofAjax } from '@sxf/er-utils/ajax';
const LoadDataMixin = {
  props: {
    dataUrl: {
      default: ""
    },
    loadErrorMsgType: String,
    autoLoadData: {
      default: false
    },
    submitUrl: {
      default: ""
    }
  },
  created() {
    this.sfMixins = this.sfMixins || {};
    this.sfMixins.commonMixin = LoadDataMixin;
  },
  mounted() {
    if (this.autoLoadData) {
      this.loadData(null, false, "notify");
    }
  },
  methods: {
    loadData(options, showLoadMask, errMsgType) {
      return this.request(options || this.dataUrl, showLoadMask).always((isSuccess, json) => {
        if (isSuccess) {
          this.setData(json.data);
          this.$emit("data.load.success", json.data);
          return;
        }
        errMsgType = errMsgType || this.loadErrorMsgType;
        if (errMsgType === "msgBox") {
          this.$errorWindow({
            subtitle: json && json.message || $i("scp.vt_component.sf_widget.src.mixins.common_mixin.error_win_subtitle")
          });
        } else if (errMsgType === "notify") {
          this.$notify.fail(
            json && json.message || $i("scp.vt_component.sf_widget.src.mixins.common_mixin.error_win_msg")
          );
        }
        this.$emit("data.load.callback", isSuccess, json);
      });
    },
    setData() {
    },
    submit() {
      const errMsg = this.validate && this.validate() || [];
      if (errMsg.length) {
        this.$errorWindow({
          subtitle: errMsg
        });
        return;
      }
      return this.doSubmit();
    },
    doSubmit() {
      const submitData = this.getSubmitData();
      this.$emit("submit.before", submitData);
      return this.request({
        url: this.submitUrl,
        type: "POST",
        data: submitData
      }).always((isSuccess, json) => {
        if (!isSuccess) {
          this.$errorWindow({
            subtitle: json && json.data || $i("scp.vt_component.sf_widget.src.mixins.common_mixin.submit_data_error_msg")
          });
          return;
        }
        this.$notify.ok($i("scp.vt_component.sf_widget.src.mixins.common_mixin.submit_data_success_msg"));
        this.$emit("submit.callback", isSuccess, json, submitData);
      });
    },
    request(info, loadMask) {
      let ajax;
      if (!info) {
        return;
      }
      if (isInstanceofAjax(info)) {
        ajax = info;
      } else {
        ajax = this.$ajax(formatAjaxOptions(info));
      }
      if (this.$loadMask && loadMask !== false) {
        this.$loadMask.show();
      }
      ajax.always(() => {
        if (this.$loadMask && loadMask !== false) {
          this.$loadMask.hide();
        }
      });
      return ajax;
    },
    getData() {
    },
    getAllData(grid) {
      const allData = [];
      Object.keys(grid.store.dataHash).forEach((key) => {
        allData.unshift(grid.store.dataHash[key].data);
      });
      return allData;
    },
    getSubmitData() {
    }
  }
};
function formatAjaxOptions(info) {
  let options;
  if (typeof info === "string") {
    options = {
      url: info,
      type: "GET"
    };
  }
  if (typeof info === "function") {
    options = info.call(this);
  }
  if (typeof info === "object") {
    options = info;
  }
  return options;
}
var index = {
  install(Vue) {
    Vue.mixin(LoadDataMixin);
  }
};
export { index as default };
