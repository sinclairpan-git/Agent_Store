import logger from '@sxf/er-utils/logger';
const LoggerMixin = {
  mounted() {
    let loggerInstance;
    Object.defineProperty(this, "$logger", {
      configurable: true,
      get: function() {
        if (loggerInstance) {
          return loggerInstance;
        }
        this.__loggerInited = true;
        loggerInstance = logger(
          this.loggerName || this.$options.logger || this.$vnode && this.$vnode.componentOptions.tag || this.$options.name || ""
        );
        return loggerInstance;
      }
    });
    this.__destroyLogger = function() {
      loggerInstance = null;
    };
  },
  beforeDestroy() {
    if (this.__loggerInited) {
      this.__loggerInited = null;
      this.__destroyLogger();
    }
  }
};
var index = {
  install(Vue) {
    Vue.mixin(LoggerMixin);
  }
};
export { LoggerMixin, index as default };
