import { LayoutPage } from '@uedc/sf-layout';
import $ from 'jquery';
import { componentName } from '@sxf/er-components/_const';
import { isPropEnabled } from '@sxf/er-components/_utils/vue-utils';
import { SfButton } from '@sxf/er-components/button';
import { SfFlex, SfFlexItem } from '@sxf/er-components/flex';
import { SfPath } from '@sxf/er-components/path';
import { SfSpace } from '@sxf/er-components/space';
import { $i, globalConfig } from '@sxf/er-config';
import { getPrefixedClassName } from '@sxf/er-feature';
import { when } from '@sxf/er-utils/when';
import LoadMask from '@sxf/er-widget/mask';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
var script = {
  name: componentName.coverWindow,
  componentName: componentName.coverWindow,
  components: {
    SfPath,
    SfFlex,
    SfFlexItem,
    SfButton,
    SfSpace,
    SfLayoutPage: LayoutPage
  },
  props: {
    path: {},
    noHeader: true,
    noFooter: true,
    noSubmit: true,
    noCancel: true,
    noPrev: true,
    submitDisabled: true,
    cancelDisabled: true,
    prevDisabled: true,
    buttonAlign: {
      type: String,
      default: "right"
    },
    isButtonLeft: {
      type: Boolean,
      default: true
    },
    submitText: {
      type: String,
      default: () => $i("scp.vt_component.sf_widget.packages.cover_window.cover_window.footer_inner_button_submit")
    },
    cancelText: {
      type: String,
      default: () => $i("scp.vt_component.sf_widget.packages.cover_window.cover_window.footer_inner_button_cancle")
    },
    beforeHide: {
      type: Function,
      default: $.noop
    },
    beforeSubmit: {
      type: Function,
      default: $.noop
    },
    beforeCancel: {
      type: Function,
      default: $.noop
    },
    steps: {},
    addCommonPadding: {
      type: Boolean,
      default: true
    },
    relatedNav: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      isShown: false,
      showPadding: true,
      hasSteps: typeof this.steps !== "undefined",
      inFirst: true,
      inEnd: true,
      prevUtid: "",
      nextUtid: ""
    };
  },
  computed: {
    buttonFlexAlign() {
      if (this.hasSteps) {
        return this.isButtonLeft ? "flex-start" : "space-between";
      }
      return {
        left: "flex-start",
        right: "flex-end"
      }[this.buttonAlign] || this.buttonAlign;
    },
    isNoFooter() {
      return isPropEnabled(this.noFooter);
    },
    isNoHeader() {
      return isPropEnabled(this.noHeader) || !this.$slots.header && !this.$slots["header-inner"];
    },
    isNoSubmit() {
      return isPropEnabled(this.noSubmit) || this.hasSteps && !this.inEnd;
    },
    isNoCancel() {
      return isPropEnabled(this.noCancel);
    },
    isSubmitDisabled() {
      return isPropEnabled(this.submitDisabled);
    },
    isCancelDisabled() {
      return isPropEnabled(this.cancelDisabled);
    },
    prevButtonText() {
      return $i("scp.vt_component.sf_widget.packages.cover_window.cover_window.footer_inner_button_prev");
    },
    nextButtonText() {
      return $i("scp.vt_component.sf_widget.packages.cover_window.cover_window.footer_inner_button_next");
    }
  },
  mounted() {
    const vm = this;
    let bodyLoadMask;
    this.$container = this.getContainer();
    $(this.$el).hide();
    $(this.$el).appendTo(this.$container);
    Object.defineProperty(this, "$bodyLoadMask", {
      get() {
        if (bodyLoadMask) {
          return bodyLoadMask;
        }
        vm.__BodyLoadMaskInited = true;
        bodyLoadMask = new LoadMask(vm.$refs.body.$el);
        return bodyLoadMask;
      }
    });
    if (this.steps) {
      vm.stepsComponent = vm.$vnode.context.$refs[this.steps];
      if (!vm.stepsComponent || vm.stepsComponent.$options.componentName !== componentName.steps) {
        const errMsg = `Expect definition of "${componentName.steps}" component inner "${componentName.coverWindow}" component.`;
        throw new Error(errMsg);
      }
      vm.stepsComponent.$on("after", function() {
        vm.updateUtid();
        vm.inFirst = vm.stepsComponent.inFirst();
        vm.inEnd = vm.stepsComponent.inEnd();
      });
      vm.inFirst = vm.stepsComponent.inFirst();
      vm.inEnd = vm.stepsComponent.inEnd();
    }
    this.updateUtid();
    const $router = globalConfig.router;
    if ($router) {
      const query = Object.assign({}, $router.currentRoute.query);
      query.ts = new Date().getTime();
      $router.push({ query });
      this.__routerAfterEachDestroy = $router.afterEach((to, from) => {
        this.__notAllowShow = true;
        const isRouterPathChanged = to.path !== from.path;
        if (isRouterPathChanged) {
          this.$nextTick(() => {
            this.isShown = false;
          });
        } else {
          this.hide();
        }
        this.$nextTick(() => {
          this.__notAllowShow = false;
        });
      });
    }
  },
  beforeDestroy() {
    if (this.__BodyLoadMaskInited) {
      this.$bodyLoadMask.destroy();
    }
    if (this.__routerAfterEachDestroy) {
      this.__routerAfterEachDestroy();
    }
    this.hide();
    if (this.$el && this.$el.parentNode) {
      $(this.$el).remove();
    }
    $.event.trigger("scroll");
  },
  methods: {
    getPrefixedClassName,
    getFullUtid(utidBase) {
      return this.$attrs.utid ? `${this.$attrs.utid}-${utidBase}` : utidBase;
    },
    updateUtid() {
      var _a, _b;
      const step = (_b = (_a = this.stepsComponent) == null ? void 0 : _a.steps) == null ? void 0 : _b.href;
      this.prevUtid = [this.$attrs.utid || "cover-window", step, "step-btn-prev"].filter((char) => char).join("-");
      this.nextUtid = [this.$attrs.utid || "cover-window", step, "step-btn-next"].filter((char) => char).join("-");
    },
    show() {
      if (this.isShown || this.__notAllowShow) {
        return;
      }
      this.$container.addClass(getPrefixedClassName("cover-window_auto-height"));
      $(this.$el).siblings().addClass(getPrefixedClassName("cover-window_hidden"));
      this.isShown = true;
      this.$emit("show");
    },
    hide() {
      const vm = this;
      if (!vm.isShown) {
        return;
      }
      when(vm.beforeHide()).then(function(result) {
        if (result === false) {
          return;
        }
        vm.$container.removeClass(getPrefixedClassName("cover-window_auto-height"));
        $(vm.$el).siblings().removeClass(getPrefixedClassName("cover-window_hidden"));
        vm.isShown = false;
        vm.$emit("hide");
      });
    },
    getContainer() {
      return $(globalConfig.rootContainer || "#body");
    },
    submit() {
      const vm = this;
      when(vm.beforeSubmit()).then(function(result) {
        if (result === false) {
          return;
        }
        vm.$emit("submit");
        vm.hide();
      });
    },
    cancel() {
      const vm = this;
      when(vm.beforeCancel()).then(function(result) {
        if (result === false) {
          return;
        }
        vm.$emit("cancel");
        vm.hide();
      });
    },
    prev() {
      this.stepsComponent.prev();
    },
    next() {
      this.stepsComponent.next();
    }
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _obj, _obj$1;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "sf-layout-page",
    {
      directives: [
        {
          name: "show",
          rawName: "v-show",
          value: _vm.isShown,
          expression: "isShown"
        }
      ],
      class: (_obj = {}, _obj[_vm.getPrefixedClassName("cover-window")] = true, _obj[_vm.getPrefixedClassName("cover-window_window-padding")] = _vm.showPadding, _obj)
    },
    [
      _vm.path ? _c(
        "template",
        { slot: "title" },
        [_c("sf-path", { attrs: { "path-data": _vm.path } })],
        1
      ) : _vm._e(),
      _vm._v(" "),
      _vm.$slots.toolbar ? _c("template", { slot: "toolbar" }, [_vm._t("toolbar")], 2) : _vm._e(),
      _vm._v(" "),
      _c(
        "div",
        { class: _vm.getPrefixedClassName("cover-window_main-wrap") },
        [
          _c(
            "sf-flex",
            {
              class: _vm.getPrefixedClassName("cover-window_main"),
              attrs: { "flex-direction": "column" }
            },
            [
              _c(
                "sf-flex-item",
                {
                  directives: [
                    {
                      name: "show",
                      rawName: "v-show",
                      value: !_vm.isNoHeader,
                      expression: "!isNoHeader"
                    }
                  ],
                  attrs: { flex: "none" }
                },
                [
                  _c(
                    "div",
                    { class: _vm.getPrefixedClassName("cover-window_header") },
                    [
                      _vm._t("header", [
                        _c(
                          "div",
                          {
                            class: _vm.getPrefixedClassName(
                              "cover-window_header-inner"
                            )
                          },
                          [_vm._t("header-inner")],
                          2
                        )
                      ])
                    ],
                    2
                  )
                ]
              ),
              _vm._v(" "),
              _c(
                "sf-flex-item",
                {
                  ref: "body",
                  class: _vm.getPrefixedClassName("cover-window_body")
                },
                [
                  _vm._t("body", [
                    _c(
                      "div",
                      {
                        class: (_obj$1 = {}, _obj$1[_vm.getPrefixedClassName("cover-window_body-inner")] = true, _obj$1[_vm.getPrefixedClassName("has-common-padding")] = _vm.addCommonPadding, _obj$1)
                      },
                      [_vm._t("default")],
                      2
                    )
                  ])
                ],
                2
              ),
              _vm._v(" "),
              _c(
                "sf-flex-item",
                {
                  directives: [
                    {
                      name: "show",
                      rawName: "v-show",
                      value: !_vm.isNoFooter,
                      expression: "!isNoFooter"
                    }
                  ],
                  class: _vm.getPrefixedClassName("cover-window_footer"),
                  attrs: { flex: "0 0 auto" }
                },
                [
                  _vm._t(
                    "footer",
                    [
                      _c(
                        "sf-flex",
                        {
                          class: _vm.getPrefixedClassName(
                            "cover-window_footer-inner"
                          ),
                          attrs: {
                            "align-items": "center",
                            "justify-content": _vm.buttonFlexAlign
                          }
                        },
                        [
                          _vm.hasSteps ? _c(
                            "sf-flex-item",
                            { attrs: { flex: "none" } },
                            [
                              !_vm.noPrev && !_vm.inFirst ? _c(
                                "sf-button",
                                {
                                  key: "prev",
                                  class: _vm.getPrefixedClassName(
                                    "cover-window_previous-step"
                                  ),
                                  attrs: {
                                    size: "large",
                                    type: "cancel",
                                    disabled: _vm.prevDisabled,
                                    utid: _vm.prevUtid
                                  },
                                  on: {
                                    click: function($event) {
                                      return _vm.prev();
                                    }
                                  }
                                },
                                [
                                  _c("span", [
                                    _vm._v(
                                      " " + _vm._s(_vm.prevButtonText) + " "
                                    )
                                  ])
                                ]
                              ) : _vm._e()
                            ],
                            1
                          ) : _vm._e(),
                          _vm._v(" "),
                          !_vm.isButtonLeft ? _c(
                            "sf-flex-item",
                            {
                              class: _vm.getPrefixedClassName(
                                "cover-window_footer-middle"
                              ),
                              attrs: { flex: "none" }
                            },
                            [_vm._t("footer-middle")],
                            2
                          ) : _vm._e(),
                          _vm._v(" "),
                          _c(
                            "sf-flex-item",
                            { attrs: { flex: "none" } },
                            [
                              _vm._t(
                                "footer-inner",
                                [
                                  _c(
                                    "sf-space",
                                    { attrs: { size: 8 } },
                                    [
                                      _vm.hasSteps && !_vm.inEnd ? _c(
                                        "sf-button",
                                        {
                                          key: "next",
                                          class: _vm.getPrefixedClassName(
                                            "cover-window_next-step"
                                          ),
                                          attrs: {
                                            size: "large",
                                            type: "primary",
                                            disabled: _vm.submitDisabled,
                                            utid: _vm.nextUtid
                                          },
                                          on: {
                                            click: function($event) {
                                              return _vm.next();
                                            }
                                          }
                                        },
                                        [
                                          _c("span", [
                                            _vm._v(
                                              " " + _vm._s(_vm.nextButtonText) + " "
                                            )
                                          ])
                                        ]
                                      ) : _vm._e(),
                                      _vm._v(" "),
                                      !_vm.isNoSubmit ? _c(
                                        "sf-button",
                                        {
                                          key: "submit",
                                          class: _vm.getPrefixedClassName(
                                            "cover-window_submit-button"
                                          ),
                                          attrs: {
                                            size: "large",
                                            utid: _vm.getFullUtid(
                                              "cover-window-submit-btn"
                                            ),
                                            type: "primary",
                                            disabled: _vm.isSubmitDisabled
                                          },
                                          on: {
                                            click: function($event) {
                                              return _vm.submit();
                                            }
                                          }
                                        },
                                        [
                                          _vm._v(
                                            "\n                    " + _vm._s(_vm.submitText) + "\n                  "
                                          )
                                        ]
                                      ) : _vm._e(),
                                      _vm._v(" "),
                                      !_vm.isNoCancel ? _c(
                                        "sf-button",
                                        {
                                          key: "cancel",
                                          class: _vm.getPrefixedClassName(
                                            "cover-window_cancel-button"
                                          ),
                                          attrs: {
                                            size: "large",
                                            utid: _vm.getFullUtid(
                                              "cover-window-cancel-btn"
                                            ),
                                            type: "cancel",
                                            disabled: _vm.isCancelDisabled
                                          },
                                          on: {
                                            click: function($event) {
                                              return _vm.cancel();
                                            }
                                          }
                                        },
                                        [
                                          _vm._v(
                                            "\n                    " + _vm._s(_vm.cancelText) + "\n                  "
                                          )
                                        ]
                                      ) : _vm._e()
                                    ],
                                    1
                                  )
                                ],
                                {
                                  submit: _vm.submit,
                                  cancel: _vm.cancel,
                                  submitText: _vm.submitText,
                                  cancelText: _vm.cancelText,
                                  align: _vm.buttonAlign,
                                  noSubmit: _vm.isNoSubmit,
                                  noCancel: _vm.isNoCancel,
                                  submitDisabled: _vm.isSubmitDisabled,
                                  cancelDisabled: _vm.isCancelDisabled
                                }
                              )
                            ],
                            2
                          ),
                          _vm._v(" "),
                          _vm.isButtonLeft ? _c(
                            "sf-flex-item",
                            {
                              class: _vm.getPrefixedClassName(
                                "cover-window_footer-middle"
                              ),
                              attrs: { flex: "none" }
                            },
                            [_vm._t("footer-middle")],
                            2
                          ) : _vm._e()
                        ],
                        1
                      )
                    ],
                    {
                      submit: _vm.submit,
                      cancel: _vm.cancel,
                      submitText: _vm.submitText,
                      cancelText: _vm.cancelText,
                      align: _vm.buttonAlign,
                      noSubmit: _vm.isNoSubmit,
                      noCancel: _vm.isNoCancel,
                      submitDisabled: _vm.isSubmitDisabled,
                      cancelDisabled: _vm.isCancelDisabled
                    }
                  )
                ],
                2
              )
            ],
            1
          )
        ],
        1
      )
    ],
    2
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__ as SfCoverWindow };
