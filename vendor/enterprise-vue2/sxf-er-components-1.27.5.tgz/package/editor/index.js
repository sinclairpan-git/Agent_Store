import { componentName } from '@sxf/er-components/_const';
import { isPropEnabled } from '@sxf/er-components/_utils/vue-utils';
import { SfButton } from '@sxf/er-components/button';
import { SfInput } from '@sxf/er-components/input';
import { $i } from '@sxf/er-config';
import { getPrefixedClassName } from '@sxf/er-feature';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
const inputMethods = Object.keys(SfInput.methods || {}).reduce((map, name) => {
  map[name] = function(...args) {
    return this.$refs.input[name](...args);
  };
  return map;
}, {});
var script = {
  name: componentName.editor,
  componentName: componentName.editor,
  components: {
    SfInput,
    SfButton
  },
  props: {
    value: String,
    italic: Boolean,
    readonly: Boolean,
    type: {
      type: String,
      default: "input",
      validator: (v) => ["input", "textarea"].includes(v)
    },
    autoReset: {
      type: Boolean,
      default: false
    },
    hoverShowIcon: Boolean,
    triggerType: {
      type: String,
      default: "text",
      validator: (val) => ["icon", "text"].includes(val)
    },
    defaultTip: {
      type: String,
      default: () => $i("scp.vt_component.sf_widget.packages.editor.editor_tip_placeholder")
    },
    autoWidth: Boolean
  },
  data() {
    return {
      isActive: false,
      inputValue: "",
      oldValue: "",
      editorText: $i("scp.vt_component.sf_widget.packages.editor.button_edit")
    };
  },
  computed: {
    isReadonly() {
      return isPropEnabled(this.readonly);
    },
    isHoverShowIcon() {
      return isPropEnabled(this.hoverShowIcon);
    },
    isItalic() {
      return isPropEnabled(this.italic);
    },
    isAutoWidth() {
      return isPropEnabled(this.autoWidth);
    },
    actualValue() {
      return this.inputValue && this.inputValue.trim();
    },
    isTextarea() {
      return this.type === "textarea";
    },
    tipBoxStyle() {
      const style = {};
      if (this.isTextarea) {
        style["padding-top"] = "5px";
      }
      return style;
    },
    inputProps() {
      return {
        ...this.$props,
        ...this.$attrs,
        utid: this.getFullUtid("input")
      };
    }
  },
  watch: {
    value() {
      if (!this.isActive) {
        this.inputValue = this.value;
      }
    },
    readonly(val, oldVal) {
      if (val && val !== oldVal) {
        this.hide({
          autoReset: true
        });
      }
    }
  },
  created() {
    this.$nextTick(() => {
      this.inputValue = this.value;
    });
  },
  methods: {
    ...inputMethods,
    getPrefixedClassName,
    getFullUtid(utidBase) {
      return this.$attrs.utid ? `${this.$attrs.utid}-${utidBase}` : utidBase;
    },
    show() {
      if (this.isReadonly || this.isActive) {
        return;
      }
      this.isActive = true;
      if (this.$refs.input) {
        this.$refs.input.focus();
      }
      this.oldValue = this.inputValue;
      this.$emit("show");
    },
    hide(options) {
      options = options || {};
      if (!this.isActive) {
        return;
      }
      if (this.$refs.input.validate() !== true) {
        if (this.autoReset || options.autoReset) {
          this.isActive = false;
          this.inputValue = this.oldValue;
          this.$emit("hide", this.inputValue);
          this.$emit("input", this.inputValue);
        }
        return;
      }
      this.isActive = false;
      this.$emit("hide", this.inputValue);
      this.$emit("input", this.inputValue);
    },
    setValue(value) {
      if (this.isActive) {
        return;
      }
      this.inputValue = value;
    }
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _obj, _obj$1, _obj$2, _obj$3;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      class: [
        _vm.getPrefixedClassName("sf-editor"),
        (_obj = {}, _obj[_vm.getPrefixedClassName("is-auto-width")] = _vm.isAutoWidth, _obj)
      ]
    },
    [
      _c(
        "div",
        {
          directives: [
            {
              name: "show",
              rawName: "v-show",
              value: !_vm.isActive,
              expression: "!isActive"
            }
          ],
          class: [
            _vm.getPrefixedClassName("sf-editor_tip-box"),
            "clearfix",
            (_obj$1 = {}, _obj$1[_vm.getPrefixedClassName("is-readonly")] = _vm.isReadonly, _obj$1[_vm.getPrefixedClassName("is-hover-show-icon")] = _vm.isHoverShowIcon, _obj$1)
          ],
          style: _vm.tipBoxStyle,
          on: {
            click: function($event) {
              return _vm.show();
            }
          }
        },
        [
          _c(
            "div",
            { class: _vm.getPrefixedClassName("sf-editor_icon-box") },
            [
              _vm._t(
                "icon",
                [
                  _vm.triggerType === "icon" ? _c("sf-button", {
                    directives: [
                      {
                        name: "show",
                        rawName: "v-show",
                        value: !_vm.isReadonly,
                        expression: "!isReadonly"
                      }
                    ],
                    class: _vm.getPrefixedClassName("sf-editor_icon"),
                    attrs: { type: "icon", icon: "edit-light" }
                  }) : _c(
                    "sf-button",
                    {
                      directives: [
                        {
                          name: "show",
                          rawName: "v-show",
                          value: !_vm.isReadonly,
                          expression: "!isReadonly"
                        }
                      ],
                      class: _vm.getPrefixedClassName("sf-editor_text"),
                      attrs: { type: "link" }
                    },
                    [
                      _vm._v(
                        "\n          " + _vm._s(_vm.editorText) + "\n        "
                      )
                    ]
                  )
                ],
                { readonly: _vm.isReadonly }
              )
            ],
            2
          ),
          _vm._v(" "),
          _c(
            "div",
            {
              class: [
                _vm.getPrefixedClassName("sf-editor_tip"),
                (_obj$2 = {}, _obj$2[_vm.getPrefixedClassName("sf-editor_italic")] = _vm.isItalic, _obj$2.ellipsis = !_vm.isTextarea, _obj$2)
              ],
              attrs: { "data-tip": _vm.inputValue }
            },
            [
              _vm.actualValue ? [_vm._v("\n        " + _vm._s(_vm.actualValue) + "\n      ")] : _vm._t("default", [
                !_vm.isReadonly ? _c("span", [_vm._v(_vm._s(_vm.defaultTip))]) : _c("span", [_vm._v("-")])
              ])
            ],
            2
          )
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        {
          class: [
            _vm.getPrefixedClassName("sf-editor_input-box"),
            (_obj$3 = {}, _obj$3[_vm.getPrefixedClassName("is-show")] = _vm.isActive, _obj$3)
          ]
        },
        [
          _c(
            "sf-input",
            _vm._g(
              _vm._b(
                {
                  ref: "input",
                  on: {
                    blur: function($event) {
                      return _vm.hide();
                    }
                  },
                  model: {
                    value: _vm.inputValue,
                    callback: function($$v) {
                      _vm.inputValue = $$v;
                    },
                    expression: "inputValue"
                  }
                },
                "sf-input",
                _vm.inputProps,
                false
              ),
              _vm.$listeners
            )
          )
        ],
        1
      )
    ]
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__ as SfEditor };
