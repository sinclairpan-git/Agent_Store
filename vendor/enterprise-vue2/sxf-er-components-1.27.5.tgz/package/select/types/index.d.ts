import { VNode } from 'vue';

export interface SfSelectOptions {
  id?: string;
  text?: string;
  value?: string;
  json?: any;
  disabled?: boolean;
}

interface IEventOptions {
  target?: JQuery;
  field?: JQuery;
  trigger?: JQuery;
  records?: SfSelectOptions;
}

interface IEventData {
  data?: SfSelectOptions;
  oldData?: SfSelectOptions;
  list?: JQuery; // 下拉框展开的那块
  evtTarget?: JQuery;
  options?: IEventOptions; // 这个是当前下拉框的配置
  records?: SfSelectOptions[];
  json?: {
    success: number; // 默认封了一层
    data: any;
  }; // json数据，不确定的数据
}

interface SfSelectListeners {
  trigger?: (evt: JQuery.Event) => void;
  focus?: (evt: JQuery.Event) => void;
  blur?: (evt: JQuery.Event) => void;
  change?: (evt: JQuery.Event, changeData: IEventData) => void;
  value?: (evt: JQuery.Event, valueData: IEventData) => void;
  clear?: (evt: JQuery.Event) => void;
  'item.select'?: (evt: JQuery.Event, selectData: IEventData) => void;
  'data.beforeload'?: (evt: JQuery.Event) => void;
  'data.load'?: (evt: JQuery.Event, loadData: IEventData) => void;
  'data.clear'?: (evt: JQuery.Event) => void;
  'data.changed'?: (evt: JQuery.Event, loadData: IEventData) => void;
  'list.scroll'?: (evt: JQuery.Event) => void;
  'list.show'?: (evt: JQuery.Event, listData: IEventData) => void;
  'list.hide'?: (evt: JQuery.Event, listData: IEventData) => void;
  'list.click'?: (evt: JQuery.Event, clickData: IEventData) => void;
  'list.destroy'?: (evt: JQuery.Event) => void;
  'item.add'?: () => void;
}

interface SfSelectSearchOptions {
  placeholder: string;
  searchLimit: boolean | number;
  searchUseUTF8Len: boolean | number;
}

type SfSelectValueField = string;

type SfSelectDisplayField = string;

type SfSelectAlign = 'left' | 'center' | 'right';

type SfSelectRenderer = (text: string, data: SfSelectOptions, opt: SfSelectOptions[]) => string;

type SfSelectFilter = (record: SfSelectOptions, index: number, records: SfSelectOptions[]) => SfSelectOptions[];

type SfSelectGroupBy = {
  field: string;
  render: (v: any) => any;
};

type SfSelectProcessData = (data: SfSelectOptions) => SfSelectOptions;

type SfSelectBeforeSelect = JQuery.Promise<any> | boolean;

export interface SfSelectProps {
  displayField: SfSelectDisplayField;
  valueField: SfSelectValueField;
  listWidth: string | number;
  cls: string;
  listWrapCls: string;
  listCls: string;
  listItemCls: string;
  readOnly: boolean;
  editable: boolean;
  commitEditValue: (newValue: string) => boolean | string;
  renderer: SfSelectRenderer;
  filter: SfSelectFilter;
  search: boolean;
  listeners: SfSelectListeners;
  multiple: boolean;
  groupBy: SfSelectGroupBy;
  processData: SfSelectProcessData;
  ajax: { api: any };
  autoLoad: boolean;
  autoSelect: boolean;
  value: string;
  preventPageScrolling: boolean;
  beforelisthide: () => boolean;
  listExtTpl: string;
  displayTextFormatter: (data: SfSelectOptions, oldData: SfSelectOptions, options: IEventOptions) => string;
  align: SfSelectAlign;
  refuseInvalidValue: boolean;
  clearOnRefused: boolean;
  autoSelectOnRefused: boolean;
  width: string | number;
  disabled: boolean | number;
  options: SfSelectOptions[];
  placeholder: string;
  clearable: boolean;
  tip: boolean | string | ((v: string) => string);
  beforeSelect: SfSelectBeforeSelect;
}

export interface SfSelectSlots {
  $slots: {
    options?: VNode[];
  };
}

export interface SfSelectEvents {
  $emit(eventName: 'item-select', data: IEventData, e: JQuery.Event): this;
  $emit(eventName: 'change', info: IEventData, e: JQuery.Event): this;
  $emit(eventName: 'input', info: SfSelectOptions): this;
  $emit(eventName: 'value', info: IEventData, e: JQuery.Event): this;
  $emit(eventName: 'on-add'): this;
}

export interface SfSelectMethods {
  getOptions: () => any;
  getOptionsData: () => SfSelectOptions;
  setValue: (value: string) => void;
  getValue: () => string;
  getData: () => Record<string, any>;
  enable: () => void;
  disable: () => void;
  load: () => void;
  empty: () => void;
  reset: () => void;
  setLoadingStatus: () => void;
  selectFirst: () => void;
  expandList: () => void;
  collapseList: () => void;
}

export declare type SfSelect = Readonly<SfSelectProps & SfSelectSlots & SfSelectMethods> & Vue;
