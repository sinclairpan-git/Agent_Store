import { componentName } from '@sxf/er-components/_const';
import $ from 'jquery';
import { vOnShow } from '@sxf/er-components/_directives';
import { EmitterMixin, PathnameMixin, MultipleSelectMixin } from '@sxf/er-components/_mixins';
import { formatProps } from '@sxf/er-components/_utils/vue-utils';
import { FormFieldMixin, FormSizeMixin } from '@sxf/er-components/form';
import { SfSpace } from '@sxf/er-components/space';
import { SfTag } from '@sxf/er-components/tag';
import { $i } from '@sxf/er-config';
import { getPrefixedClassName } from '@sxf/er-feature';
import format from '@sxf/er-utils/format';
import lang from '@sxf/er-utils/lang';
import { fixselect } from '@sxf/er-widget/select';
import { hint } from '@sxf/er-widget/tooltip';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
var PrefixType = /* @__PURE__ */ ((PrefixType2) => {
  PrefixType2["image"] = "image";
  PrefixType2["icon"] = "icon";
  return PrefixType2;
})(PrefixType || {});
const defaultListParent = function(wrap) {
  const $parent = wrap.closest(".sf-popover-vtip");
  if ($parent.size()) {
    return $parent;
  }
  return $("html > body").first();
};
const SELECT_PROPS = [
  "displayField",
  "valueField",
  "disabledField",
  "listWidth",
  "cls",
  "listWrapCls",
  "listCls",
  "listItemCls",
  "listContentEl",
  "readOnly",
  "editable",
  "commitEditValue",
  "renderer",
  "filter",
  "search",
  "addEmptyItem",
  "processData",
  "listeners",
  "groupBy",
  "ajax",
  "autoLoad",
  "forceReload",
  "autoSelect",
  "keepNotFound",
  "value",
  "beforelisthide",
  "listExtTpl",
  "displayTextFormatter",
  "align",
  "refuseInvalidValue",
  "clearOnRefused",
  "autoSelectOnRefused",
  "searchLoad",
  "searchKey",
  "scrollLoad",
  "scrollNumber",
  "scrollNumberKey",
  "scrollTotalKey",
  "icon",
  "tipField"
];
var script$1 = {
  name: componentName.select,
  componentName: componentName.select,
  components: {
    SfTag,
    SfSpace
  },
  directives: {
    "on-show": vOnShow
  },
  mixins: [EmitterMixin, FormFieldMixin, PathnameMixin, FormSizeMixin, MultipleSelectMixin],
  props: formatProps(SELECT_PROPS, {
    validator: {
      default: null
    },
    laterValid: Boolean,
    width: {
      default: "100%"
    },
    disabled: Boolean,
    options: {
      type: Array
    },
    placeholder: {
      type: String,
      default: () => $i("scp.vt_component.sf_widget.packages.select.src.select.select_placeholder")
    },
    tip: [Boolean, String, Function, Array],
    iconTip: {
      type: [String, Array]
    },
    size: {
      type: String,
      default: "",
      validator: (size) => ["", "normal", "small"].includes(size)
    },
    beforeSelect: {
      type: [Function, Boolean],
      default: true
    },
    clearable: {
      type: Boolean,
      default: false
    },
    selectLimit: {
      type: Number
    },
    selectLimitText: {
      type: String,
      default: () => $i("scp.vt_component.sf_widget.packages.select.src.select.select_limit")
    },
    showCheckAll: {
      type: Boolean,
      default: false
    },
    checkAllLabel: {
      type: String,
      default: () => $i("scp.vt_component.sf_widget.packages.select.src.select.all_option_label")
    },
    showAddBtn: {
      type: Boolean,
      default: false
    },
    multiple: {
      type: Boolean,
      default: false
    },
    destroyOnHide: {
      type: Boolean,
      default: false
    },
    showSelectedPrefix: {
      type: Boolean,
      default: false
    },
    tipOffsetX: {
      type: Number,
      default: 50
    },
    tipOffsetY: {
      type: Number,
      default: 0
    }
  }),
  data() {
    return {
      optionsData: this.options,
      currentValue: this.value,
      currentData: {},
      isDisabled: this.disabled,
      initValue: this.value,
      isCheckedAll: false,
      prefixType: PrefixType
    };
  },
  computed: {
    style() {
      return {
        width: this.width
      };
    },
    isAutoSelect() {
      return !!this.autoSelect;
    },
    currentIconTip() {
      return format.getContentTip(this.iconTip);
    },
    disabledStatus() {
      return this.isDisabled;
    },
    visibleTags() {
      var _a, _b;
      return ((_b = (_a = this.currentData) == null ? void 0 : _a.slice) == null ? void 0 : _b.call(_a, 0, this.safeTagNumber)) || [];
    },
    invisibleTagsCount() {
      var _a, _b;
      if (!((_a = this.currentData) == null ? void 0 : _a.length)) {
        return 0;
      }
      return ((_b = this.currentData) == null ? void 0 : _b.length) - this.safeTagNumber;
    },
    rootCls() {
      return [
        this.currentSize ? getPrefixedClassName("sf-select--" + this.currentSize) : "",
        this.isDisabled ? getPrefixedClassName("sf-select--disabled") : ""
      ];
    },
    tagContainerRefName() {
      return "tagContainer";
    },
    tagNumberCeil() {
      var _a, _b;
      return (_b = (_a = this.currentData) == null ? void 0 : _a.length) != null ? _b : 0;
    }
  },
  watch: {
    disabled(val) {
      if (val) {
        this.disable();
        this.setValidateState(true);
      } else {
        this.enable();
      }
    },
    isDisabled(value) {
      if (value) {
        this.invokeSelect("disable");
      } else {
        this.invokeSelect("enable");
      }
    },
    value(val, oldVal) {
      if ((val == null ? void 0 : val.toString()) === (oldVal == null ? void 0 : oldVal.toString())) {
        return;
      }
      this.currentValue = this.value;
      this.invokeSelect("value", this.value);
    },
    placeholder(value) {
      this.invokeSelect("placeholder", value);
    },
    options() {
      this.optionsData = this.options;
      this.invokeSelect("load", JSON.parse(JSON.stringify(this.optionsData)));
      if (typeof this.currentValue !== "undefined") {
        this.invokeSelect("value", this.currentValue);
      } else if (this.isAutoSelect) {
        this.selectFirst();
      }
    },
    size(size) {
      this.setSize(size);
    },
    currentData(v) {
      if (v && this.$select) {
        const $el = this.$select.parent();
        if (this.tip === true) {
          hint.call($el, v.text);
        } else if (typeof this.tip === "function") {
          hint.call($el, this.tip(v));
        } else if (typeof this.tip === "string") {
          hint.call($el, this.tip);
        }
      }
      if (Array.isArray(v)) {
        if (this.shouldTagBeResponsive) {
          this.safeTagNumber = 0;
          this.$nextTick(() => this.calcMaxSafeTagNumber());
        }
      }
    }
  },
  created() {
    if (!this.pathName) {
      return;
    }
    const name = this.getPathName();
    if (name) {
      this.currentValue = name;
    }
    this.watchPathNameRouter(({ value }) => {
      if (value === this.value) {
        return;
      }
      this.invokeSelect("value", value);
    });
  },
  mounted() {
    this.initSelect();
    if (this.isTagMode) {
      this.$select.parent()[0].append(this.$refs[this.tagContainerRefName]);
    }
  },
  beforeDestroy() {
    if (this.$select) {
      const $el = this.$select.parent();
      if ($el) {
        $el.off("focus", this.handleFocusEvent);
        $el.off("blur", this.handleBlurEvent);
        $el.off("item.select", this.handleItemSelectEvent);
        $el.off("change", this.handleChangeEvent);
        $el.off("item.add", this.handleItemAddEvent);
        $el.off("value", this.handleValueEventWrapper);
        $el.off("clear", this.handleClearEvent);
        $el.off("update-checked-all-status", this.handleUpdateCheckedAllStatusEvent);
      }
      this.invokeSelect("destroy");
      this.$select = null;
    }
    this.currentData = null;
    this.optionsData = null;
  },
  methods: {
    invokeSelect(...args) {
      if (!this.$select) {
        return null;
      }
      return fixselect.call(this.$select, ...args);
    },
    getOptions() {
      const ret = {};
      Object.keys(this.$options.props).forEach((key) => {
        if (typeof this[key] !== "undefined") {
          ret[key] = this[key];
        }
      });
      if (typeof ret.search === "undefined") {
        ret.search = !!this.ajax;
      }
      if (!ret.listParent && ret.listParent !== false) {
        ret.listParent = defaultListParent;
      }
      return ret;
    },
    initSelect() {
      this.$select = $(this.$refs.select);
      this.invokeSelect(this.getOptions());
      this.initSelectEvent();
      if (Array.isArray(this.optionsData)) {
        this.invokeSelect("load", JSON.parse(JSON.stringify(this.optionsData)));
        if (typeof this.currentValue !== "undefined") {
          this.invokeSelect("value", this.currentValue);
        }
      }
    },
    handleFocusEvent() {
      this.$emit("focus");
    },
    handleBlurEvent() {
      this.$emit("blur");
      if (this.validateEnabled) {
        this.validate();
      }
    },
    handleItemSelectEvent(event, data) {
      this.$emit("item-select", data, event);
    },
    handleChangeEvent(event, info) {
      this.$emit("change", info, event);
    },
    handleItemAddEvent() {
      this.$emit("on-add");
    },
    handleValueEvent(info) {
      let data = info == null ? void 0 : info.data;
      let value = data == null ? void 0 : data.value;
      if (this.multiple && data) {
        data = lang.isArray(data) ? data : [data];
        value = data.map((record) => record.value);
      }
      this.$emit("input", value);
      this.currentValue = value;
      this.currentData = JSON.parse(JSON.stringify(data || {}));
      this.setPathName(value);
      if ((info == null ? void 0 : info.changed) && this.validateEnabled) {
        this.validate();
      }
      if (info == null ? void 0 : info.changed) {
        this.$emit("on-change", info);
      }
    },
    handleValueEventWrapper(event, info) {
      this.$emit("value", info, event);
      this.handleValueEvent(info);
    },
    handleClearEvent() {
      this.handleValueEvent();
    },
    handleUpdateCheckedAllStatusEvent(event, info) {
      this.isCheckedAll = info.checkedAll;
    },
    initSelectEvent() {
      const $el = this.$select.parent();
      $el.on("focus", this.handleFocusEvent);
      $el.on("blur", this.handleBlurEvent);
      $el.on("item.select", this.handleItemSelectEvent);
      $el.on("change", this.handleChangeEvent);
      $el.on("item.add", this.handleItemAddEvent);
      $el.on("value", this.handleValueEventWrapper);
      $el.on("clear", this.handleClearEvent);
      $el.on("update-checked-all-status", this.handleUpdateCheckedAllStatusEvent);
    },
    processRule(rule) {
      rule.getFieldValue = () => {
        return String(this.getValue());
      };
      return rule;
    },
    bindInvalidCls(invalidCls, toggle) {
      const target = this.$select.next();
      if (toggle) {
        target.addClass(invalidCls);
      } else {
        target.removeClass(invalidCls);
      }
    },
    bindValidateHintOptions(hintOptions) {
      this.$select.parent().attr(hintOptions);
    },
    onValidate(ret) {
      this.setValidateState(ret);
    },
    getOptionsData() {
      return this.optionsData;
    },
    setValue(value) {
      this.invokeSelect("value", value);
    },
    setSize(size) {
      this.invokeSelect("size", size);
    },
    getValue() {
      const data = this.invokeSelect("value");
      if (this.multiple) {
        const list = Array.from(data).map((item) => item.value);
        return list.length ? list : "";
      }
      const val = data[0] && data[0].value;
      return lang.isEmpty(val) ? "" : val;
    },
    getData() {
      return JSON.parse(JSON.stringify(this.currentData));
    },
    enable() {
      this.isDisabled = false;
    },
    disable() {
      this.isDisabled = true;
    },
    load() {
      this.invokeSelect("load", ...arguments);
    },
    empty() {
      this.invokeSelect("empty");
    },
    reset() {
      if (this.initValue) {
        this.setValue(this.initValue);
        return;
      }
      if (this.isAutoSelect) {
        this.selectFirst();
        return;
      }
      this.setValue("");
      this.setValidateState(true);
    },
    setLoadingStatus() {
      this.invokeSelect("status", ...arguments);
    },
    selectFirst() {
      this.invokeSelect("selectfirst", ...arguments);
    },
    expandList() {
      this.invokeSelect("expandList", ...arguments);
    },
    collapseList() {
      this.invokeSelect("collapseList", ...arguments);
    },
    toggleList() {
      if (this.isDisabled) {
        return;
      }
      this.invokeSelect("toggleList");
      this.invokeSelect("focusField");
    },
    checkIsDisabled() {
      return this.isDisabled;
    },
    cancelSelect(value) {
      const data = this.currentData.filter((item) => item.value !== value).map((item) => item.value);
      this.invokeSelect("value", data);
      this.invokeSelect("focusField");
    },
    getPrefixedClassName
  }
};
const __vue_script__$1 = script$1;
var __vue_render__$1 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      directives: [
        {
          name: "on-show",
          rawName: "v-on-show",
          value: _vm.tagController,
          expression: "tagController"
        }
      ],
      class: [_vm.rootCls, _vm.getPrefixedClassName("sf-select")],
      style: _vm.style
    },
    [
      _c(
        "select",
        {
          ref: "select",
          class: _vm.getPrefixedClassName("sf-select_field"),
          attrs: {
            id: _vm.fieldSelectorID,
            disabled: _vm.isDisabled,
            placeholder: _vm.placeholder,
            "style-key": "select"
          }
        },
        [_vm._t("options")],
        2
      ),
      _vm._v(" "),
      _vm.iconTip ? _c("i", {
        staticClass: "icon-tip",
        class: _vm.getPrefixedClassName("el-select__content-tip"),
        attrs: { "data-hint": _vm.currentIconTip }
      }) : _vm._e(),
      _vm._v(" "),
      _vm.isTagMode ? _c(
        "div",
        {
          ref: "tagContainer",
          class: _vm.getPrefixedClassName("sf-select_tag-container"),
          on: { click: _vm.toggleList }
        },
        [
          _c(
            "sf-space",
            {
              directives: [
                {
                  name: "show",
                  rawName: "v-show",
                  value: !_vm.isCheckedAll,
                  expression: "!isCheckedAll"
                }
              ],
              attrs: { size: 2, inline: "", align: "center" }
            },
            [
              _vm._l(_vm.visibleTags, function(data) {
                return _c(
                  "sf-tag",
                  {
                    key: data.json.id,
                    class: _vm.getPrefixedClassName("sf-select_tag"),
                    attrs: {
                      type: _vm.tagType,
                      size: _vm.tagSize,
                      closeable: !_vm.isDisabled && !data.json[_vm.disabledField]
                    },
                    on: {
                      close: function($event) {
                        return _vm.cancelSelect(data.value);
                      }
                    }
                  },
                  [
                    _vm.showSelectedPrefix && data.json.prefix && data.json.prefixType === _vm.prefixType.image ? _c("img", {
                      class: [
                        _vm.getPrefixedClassName(
                          "sf-select_tag-prefix"
                        ),
                        _vm.getPrefixedClassName("sf-select_tag-img")
                      ],
                      attrs: { src: data.json.prefix }
                    }) : _vm._e(),
                    _vm._v(" "),
                    _vm.showSelectedPrefix && data.json.prefix && data.json.prefixType === _vm.prefixType.icon ? _c("i", {
                      class: [
                        _vm.getPrefixedClassName(
                          "sf-select_tag-prefix"
                        ),
                        _vm.getPrefixedClassName("sf-select_tag-icon"),
                        data.json.prefix
                      ]
                    }) : _vm._e(),
                    _vm._v(" "),
                    _c(
                      "span",
                      {
                        class: [
                          _vm.getPrefixedClassName("sf-select_tag-label"),
                          "ellipsis"
                        ],
                        style: _vm.tagLabelStyle,
                        attrs: { "data-tip": data.text }
                      },
                      [
                        _vm._v(
                          "\n          " + _vm._s(data.text) + "\n        "
                        )
                      ]
                    )
                  ]
                );
              }),
              _vm._v(" "),
              _vm.invisibleTagsCount > 0 ? _c(
                "sf-tag",
                {
                  class: _vm.getPrefixedClassName("sf-select_tag"),
                  attrs: { size: _vm.tagSize, type: _vm.tagType }
                },
                [
                  _c("span", [
                    _vm._v(
                      "+" + _vm._s(_vm.invisibleTagsCount) + "..."
                    )
                  ])
                ]
              ) : _vm._e()
            ],
            2
          )
        ],
        1
      ) : _vm._e()
    ]
  );
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
var script = {
  name: componentName.menuSelect,
  componentName: componentName.menuSelect,
  components: {
    SfSelect: __vue_component__$1
  },
  props: {
    options: {
      type: Object,
      default: () => ({})
    }
  },
  computed: {
    selectProps() {
      const { data, ...attrs } = this.options;
      return {
        ...this.$attrs,
        ...attrs,
        options: data
      };
    }
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "sf-select",
    _vm._g(_vm._b({}, "sf-select", _vm.selectProps, false), _vm.$listeners)
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__ as SfMenuSelect, __vue_component__$1 as SfSelect };
