import $ from 'jquery';
import { componentName } from '@sxf/er-components/_const';
import { SfButton } from '@sxf/er-components/button';
import { getPrefixedClassName } from '@sxf/er-feature';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
import { defineComponent, ref, computed, watch, onMounted, onUnmounted } from '@vue/composition-api';
import { differenceWith } from 'lodash-es';
import Task from '@sxf/er-utils/intervalTask';
const statusIconMap = {
  success: "vtv-icon-comp-ok-border",
  normal: "vtv-icon-notice",
  warning: "vtv-icon-notice",
  danger: "vtv-icon-fail-12",
  info: "vtv-icon-lamp"
};
var script$1 = {
  name: componentName.alert,
  componentName: componentName.alert,
  components: {
    SfButton
  },
  props: {
    type: {
      type: String,
      default: "global",
      validator: (type) => ["global", "enbedded", "text"].includes(type)
    },
    noBackground: {
      type: Boolean,
      default: false
    },
    spaceDistance: {
      type: Array | Number,
      default: () => []
    },
    hasMarginX: {
      type: Boolean,
      default: false
    },
    hasMarginY: {
      type: Boolean,
      default: false
    },
    status: {
      type: String,
      default: "warning",
      validator: (status) => ["success", "normal", "warning", "danger", "info"].includes(status)
    },
    align: {
      type: String,
      default: "left",
      validator: (align) => ["left", "center"].includes(align)
    },
    iconCls: {
      type: String,
      default: void 0
    },
    word: {
      type: String,
      default: ""
    },
    canClose: {
      type: Boolean,
      default: false
    },
    border: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      visible: true
    };
  },
  computed: {
    __alertTip() {
      var _a, _b, _c;
      const defaultSlotText = (_c = (_b = (_a = this.$slots.default) == null ? void 0 : _a.filter((item) => {
        var _a2;
        return (_a2 = item == null ? void 0 : item.text) == null ? void 0 : _a2.trim();
      })) == null ? void 0 : _b[0]) == null ? void 0 : _c.text;
      return this.type === "global" ? defaultSlotText || this.word : "";
    },
    __spaceDistance() {
      if (Array.isArray(this.spaceDistance) && this.spaceDistance.length === 0) {
        return;
      }
      if ($.isNumeric(this.spaceDistance)) {
        return {
          margin: `${this.spaceDistance}px`
        };
      }
      return {
        margin: this.spaceDistance.map((item) => {
          return `${item}px`;
        }).join(" ")
      };
    },
    _iconClsName() {
      return this.iconCls ? this.iconCls : statusIconMap[this.status];
    }
  },
  methods: {
    __close() {
      this.$emit("close");
      this.visible = false;
    },
    getPrefixedClassName
  }
};
const __vue_script__$1 = script$1;
var __vue_render__$1 = function() {
  var _obj;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _vm.visible ? _c(
    "div",
    {
      class: [
        _vm.getPrefixedClassName("sf-alert"),
        _vm.getPrefixedClassName("sf-alert--type-" + _vm.type),
        _vm.getPrefixedClassName("sf-alert--status-" + _vm.status),
        _vm.noBackground ? _vm.getPrefixedClassName("sf-alert--nobackground") : "",
        _vm.hasMarginX ? _vm.getPrefixedClassName("sf-alert--hasMarginX") : "",
        _vm.hasMarginY ? _vm.getPrefixedClassName("sf-alert--hasMarginY") : "",
        _vm.border ? _vm.getPrefixedClassName("sf-alert--border") : ""
      ],
      style: _vm.__spaceDistance
    },
    [
      _vm.$slots.left ? _c(
        "div",
        { class: _vm.getPrefixedClassName("sf-alert__left") },
        [_vm._t("left")],
        2
      ) : _vm._e(),
      _vm._v(" "),
      _c(
        "div",
        {
          class: [
            _vm.getPrefixedClassName("sf-alert__content"),
            _vm.getPrefixedClassName("sf-alert__content--" + _vm.align),
            (_obj = {}, _obj[_vm.getPrefixedClassName("sf-alert__content--with-right")] = _vm.$slots.right, _obj[_vm.getPrefixedClassName("sf-alert__content--with-left")] = _vm.$slots.left, _obj[_vm.getPrefixedClassName("sf-alert__content--with-close")] = _vm.canClose, _obj)
          ]
        },
        [
          _vm.type !== "text" ? _c("i", {
            class: [
              _vm.getPrefixedClassName("sf-alert__content-icon"),
              "iconfont",
              _vm._iconClsName
            ]
          }) : _vm._e(),
          _vm._v(" "),
          _c(
            "div",
            {
              class: _vm.getPrefixedClassName("sf-alert__content-word"),
              attrs: { "data-tip": _vm.__alertTip }
            },
            [_vm._t("default", [_vm._v(_vm._s(_vm.word))])],
            2
          ),
          _vm._v(" "),
          _vm.$slots.opration ? _c(
            "span",
            {
              class: _vm.getPrefixedClassName(
                "sf-alert__content-opration"
              )
            },
            [_vm._t("opration")],
            2
          ) : _vm._e()
        ]
      ),
      _vm._v(" "),
      _vm.$slots.right || _vm.canClose ? _c(
        "div",
        { class: _vm.getPrefixedClassName("sf-alert__right") },
        [
          _vm._t("right", [
            _vm.canClose ? _c("sf-button", {
              class: _vm.getPrefixedClassName("sf-alert__close"),
              attrs: {
                type: "link",
                icon: "comp-tip-close",
                "icon-only": ""
              },
              on: {
                click: function($event) {
                  return _vm.__close();
                }
              }
            }) : _vm._e()
          ])
        ],
        2
      ) : _vm._e()
    ]
  ) : _vm._e();
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
const SHOW_OPERATE_MIN_NUM = 1;
function useTaskInterval(props) {
  let task;
  const init = (callback) => {
    task = new Task({
      interval: props.interval,
      fn: (next) => callback(true, next),
      autoStart: props.autoPlay,
      skipFirst: true
    });
  };
  const resume = () => {
    task == null ? void 0 : task.start(true);
  };
  const stop = () => {
    task == null ? void 0 : task.stop();
  };
  return {
    init,
    resume,
    stop
  };
}
let pendingHandleData = /* @__PURE__ */ new Map();
var script = defineComponent({
  name: componentName.alertList,
  componentName: componentName.alertList,
  components: {
    SfAlert: __vue_component__$1,
    SfButton
  },
  props: {
    autoPlay: {
      type: Boolean,
      default: false
    },
    closable: {
      type: Boolean,
      default: true
    },
    interval: {
      type: Number,
      default: 3e3
    },
    configList: {
      type: Array,
      default: () => []
    },
    height: {
      type: Number,
      default: 32
    },
    idProperty: {
      type: String,
      default: "text"
    },
    keepStateWhileUpdate: {
      type: Boolean,
      default: false
    }
  },
  emits: ["trigger-operate-type", "close"],
  setup(props, { emit, attrs }) {
    const { init, stop, resume } = useTaskInterval(props);
    const getFullUtid = (utidBase) => {
      return attrs.utid ? `${attrs.utid}-${utidBase}` : utidBase;
    };
    const alertListRef = ref();
    const currentIndex = ref(0);
    const isTransitioning = ref(false);
    const isLocked = ref(false);
    const translateY = ref(0);
    const options = ref(props.configList || []);
    const height = computed(() => props.height);
    const displayAlertIndex = computed(() => {
      return `${currentIndex.value + 1}/${options.value.length}`;
    });
    const alertListCls = computed(() => {
      const base = [getPrefixedClassName("sf-alert-list__scroll-container")];
      showSwitchOperation.value && base.push(getPrefixedClassName("sf-alert-list__scroll-container--has-operate"));
      props.closable && base.push(getPrefixedClassName("sf-alert-list__scroll-container--has-close"));
      return base;
    });
    const leftArrowCls = computed(() => {
      const base = ["iconfont", "vtv-icon-prev-month", getPrefixedClassName("alert-prev")];
      if (currentIndex.value === 0) {
        base.push(getPrefixedClassName("alert-prev--disabled"));
      }
      return base;
    });
    const rightArrowCls = computed(() => {
      const base = ["iconfont", "vtv-icon-next-month", getPrefixedClassName("alert-next")];
      if (currentIndex.value === options.value.length - 1) {
        base.push(getPrefixedClassName("alert-next--disabled"));
      }
      return base;
    });
    const showSwitchOperation = computed(() => options.value.length > SHOW_OPERATE_MIN_NUM);
    const getFilterAction = (actionList) => {
      return actionList == null ? void 0 : actionList.filter((item) => !item.hidden);
    };
    const resetAlertState = (value, oldValue = []) => {
      var _a;
      stop();
      if (props.keepStateWhileUpdate) {
        const cacheAlertItem = (_a = oldValue[currentIndex.value]) == null ? void 0 : _a[props.idProperty];
        const cacheAlertIndex = value.findIndex((item) => item[props.idProperty] === cacheAlertItem);
        currentIndex.value = cacheAlertIndex === -1 ? 0 : cacheAlertIndex;
        translateY.value = cacheAlertIndex * height.value;
      } else {
        currentIndex.value = 0;
        translateY.value = 0;
      }
      options.value = value;
      resume();
    };
    const compareListHasChanged = (newVal, oldValue) => {
      if (newVal.length !== (oldValue == null ? void 0 : oldValue.length)) {
        return true;
      }
      const dataDiff = differenceWith(newVal, oldValue, (newItem, oldItem) => {
        const idSame = newItem[props.idProperty] === oldItem[props.idProperty];
        const textSame = newItem.text === oldItem.text;
        return idSame && textSame;
      });
      return !!dataDiff.length;
    };
    const handleDataChange = (value, oldValue) => {
      const isChanged = compareListHasChanged(value, oldValue);
      if (!isChanged) {
        return;
      }
      if (isTransitioning.value) {
        setTimeout(() => {
          resetAlertState(value, oldValue);
        }, 200);
      } else {
        resetAlertState(value, oldValue);
      }
    };
    watch(
      () => props.configList,
      (value, oldValue) => {
        if (isLocked.value && props.autoPlay) {
          pendingHandleData == null ? void 0 : pendingHandleData.set("value", value);
          pendingHandleData == null ? void 0 : pendingHandleData.set("oldValue", value);
          return;
        }
        handleDataChange(value, oldValue || []);
        pendingHandleData == null ? void 0 : pendingHandleData.clear();
      },
      {
        immediate: true,
        deep: true
      }
    );
    const handlePointerMove = () => {
      isLocked.value = true;
      stop();
    };
    const handlePointerLeave = () => {
      isLocked.value = false;
      if (pendingHandleData == null ? void 0 : pendingHandleData.size) {
        handleDataChange(pendingHandleData.get("value"), pendingHandleData.get("oldValue"));
        pendingHandleData == null ? void 0 : pendingHandleData.clear();
      }
      resume();
    };
    onMounted(() => {
      props.autoPlay && start();
      alertListRef.value.addEventListener("pointermove", handlePointerMove);
      alertListRef.value.addEventListener("pointerleave", handlePointerLeave);
    });
    onUnmounted(() => {
      pendingHandleData == null ? void 0 : pendingHandleData.clear();
      pendingHandleData = null;
      stop();
      alertListRef.value.removeEventListener("pointermove", handlePointerMove);
      alertListRef.value.removeEventListener("pointerleave", handlePointerLeave);
    });
    const handleEmitOperate = (btnOption, data) => {
      if (btnOption.disabled) {
        return;
      }
      emit("trigger-operate-type", { type: btnOption.type, data });
    };
    const start = () => {
      stop();
      init(handleNextAlert);
    };
    const toggleOffTransition = () => {
      setTimeout(() => {
        isTransitioning.value = false;
      }, 150);
    };
    const handlePreAlert = () => {
      if (currentIndex.value === 0) {
        return;
      }
      isTransitioning.value = true;
      translateY.value = --currentIndex.value * height.value;
      toggleOffTransition();
    };
    const handleNextAlert = (isAutoPlay, next) => {
      const len = options.value.length;
      if (!isAutoPlay && currentIndex.value === len - 1) {
        return;
      }
      isTransitioning.value = true;
      if (isAutoPlay) {
        currentIndex.value = currentIndex.value + 1 > len - 1 ? 0 : currentIndex.value + 1;
      } else {
        currentIndex.value++;
      }
      translateY.value = currentIndex.value * height.value;
      toggleOffTransition();
      next == null ? void 0 : next();
    };
    const normalizeAlertProps = (props2) => {
      return {
        ...props2,
        canClose: false,
        border: true
      };
    };
    const handleCloseAlert = () => {
      resetAlertState([]);
      emit("close");
    };
    const defineAlertKey = (item, index) => {
      return `${item[props.idProperty]}-${item.text}-${index}`;
    };
    return {
      options,
      translateY,
      currentIndex,
      displayAlertIndex,
      alertListRef,
      isTransitioning,
      leftArrowCls,
      rightArrowCls,
      showSwitchOperation,
      getFilterAction,
      handleNextAlert,
      handlePreAlert,
      handleCloseAlert,
      handleEmitOperate,
      normalizeAlertProps,
      defineAlertKey,
      alertListCls,
      getPrefixedClassName,
      getFullUtid
    };
  }
});
const __vue_script__ = script;
var __vue_render__ = function() {
  var _obj;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      directives: [
        {
          name: "show",
          rawName: "v-show",
          value: _vm.options.length,
          expression: "options.length"
        }
      ],
      class: _vm.alertListCls,
      attrs: { utid: "alert-list" }
    },
    [
      _c(
        "div",
        {
          ref: "alertListRef",
          class: (_obj = {}, _obj[_vm.getPrefixedClassName("alert-list")] = true, _obj[_vm.getPrefixedClassName("disabled-transition")] = !_vm.isTransitioning, _obj),
          style: { transform: "translateY(-" + _vm.translateY + "px)" }
        },
        [
          _vm._l(_vm.options, function(item, i) {
            return [
              _c(
                "sf-alert",
                _vm._b(
                  {
                    key: _vm.defineAlertKey(item, i),
                    class: [
                      i === _vm.currentIndex && _vm.getPrefixedClassName("sf-alert--active")
                    ],
                    attrs: { word: item.text }
                  },
                  "sf-alert",
                  _vm.normalizeAlertProps(item.alertProps),
                  false
                ),
                [
                  _c(
                    "template",
                    { slot: "opration" },
                    [
                      _vm._t(item.actionSlotName, null, {
                        record: item,
                        index: i
                      }),
                      _vm._v(" "),
                      _vm._l(
                        _vm.getFilterAction(item.actionBtnList),
                        function(btn, btnIndex) {
                          return _c(
                            "sf-button",
                            {
                              key: btnIndex,
                              attrs: {
                                utid: btn.utid || _vm.getFullUtid("btn-" + btnIndex),
                                disabled: btn.disabled,
                                tip: btn.tip,
                                type: "link"
                              },
                              on: {
                                click: function($event) {
                                  return _vm.handleEmitOperate(btn, item);
                                }
                              }
                            },
                            [
                              _vm._v(
                                "\n            " + _vm._s(btn.text) + "\n          "
                              )
                            ]
                          );
                        }
                      )
                    ],
                    2
                  ),
                  _vm._v(" "),
                  _vm._t(item.slotName, null, { record: item, index: i })
                ],
                2
              )
            ];
          })
        ],
        2
      ),
      _vm._v(" "),
      _c(
        "div",
        { class: _vm.getPrefixedClassName("operate-container") },
        [
          _vm.showSwitchOperation ? [
            _c("span", {
              class: _vm.leftArrowCls,
              attrs: { utid: _vm.getFullUtid("pre-btn") },
              on: { click: _vm.handlePreAlert }
            }),
            _vm._v(" "),
            _c("span", { class: _vm.getPrefixedClassName("alert-index") }, [
              _vm._v(_vm._s(_vm.displayAlertIndex))
            ]),
            _vm._v(" "),
            _c("span", {
              class: _vm.rightArrowCls,
              attrs: { utid: _vm.getFullUtid("next-btn") },
              on: {
                click: function($event) {
                  return _vm.handleNextAlert();
                }
              }
            })
          ] : _vm._e(),
          _vm._v(" "),
          _vm.closable ? _c("i", {
            class: [
              "iconfont",
              "vtv-icon-comp-tip-close",
              _vm.getPrefixedClassName("sf-alert__close-icon")
            ],
            attrs: { utid: _vm.getFullUtid("close-btn") },
            on: { click: _vm.handleCloseAlert }
          }) : _vm._e()
        ],
        2
      )
    ]
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__$1 as SfAlert, __vue_component__ as SfAlertList };
