import Vue, { VNode } from 'vue';

export declare type SfDrawerDirection = 'rtl' | 'ltr' | 'ttb' | 'btt';

export interface SfDrawerProps {
  title: string;
  direction: SfDrawerDirection;
  mask: boolean;
  wrapperClosable: boolean;
  showClose: boolean;
  size: 'small' | 'normal' | 'large' | string | number;
  closeOnPressEscape: boolean;
  top: number;
  useScrollbar: boolean;
  appendToBody: boolean;
  beforeClose: () => JQuery.Promise<any> | boolean;
  customClass: string;
  zIndex: number;
  destroyOnClose: boolean;
  lockScroll: boolean;
}

export interface SfDrawerSlots {
  $slots: {
    title: VNode[];
    default: VNode[];
    footer: VNode[];
  };
}

export interface SfDrawerEvents {
  $emit: {
    opened: () => void;
  };
}

export interface SfDrawerMethods {
  show: () => void;
  hide: (cancel?: boolean) => void;
  showDrawerMask: () => void;
  hideDrawerMask: () => void;
  closeDrawer: () => void;
  setZIndex: (zIndex?: number) => void;
}

export declare type SfDrawer = Readonly<SfDrawerProps & SfDrawerSlots & SfDrawerMethods> & Vue;
