import $ from 'jquery';
import { componentName } from '@sxf/er-components/_const';
import { SfScrollbar } from '@sxf/er-components/scrollbar';
import { getPrefixedClassName } from '@sxf/er-feature';
import { debounce } from '@sxf/er-utils/delay';
import { off, on } from '@sxf/er-utils/dom';
import Lang from '@sxf/er-utils/lang';
import { when } from '@sxf/er-utils/when';
import getZIndex from '@sxf/er-utils/zindex';
import LoadMask from '@sxf/er-widget/mask';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
const DRAWER_SIZE = {
  small: 480,
  normal: 640,
  large: 800
};
const { isNumber } = Lang;
var script = {
  name: componentName.drawer,
  componentName: componentName.drawer,
  components: { SfScrollbar },
  props: {
    appendToBody: {
      type: Boolean,
      default: true
    },
    beforeClose: {
      type: Function
    },
    customClass: {
      type: String,
      default: ""
    },
    destroyOnClose: {
      type: Boolean,
      default: false
    },
    mask: {
      type: Boolean,
      default: true
    },
    direction: {
      type: String,
      default: "rtl",
      validator(val) {
        return ["ltr", "rtl", "ttb", "btt"].indexOf(val) !== -1;
      }
    },
    showClose: {
      type: Boolean,
      default: true
    },
    size: {
      type: [String, Number],
      default: DRAWER_SIZE.normal
    },
    title: {
      type: String,
      default: ""
    },
    wrapperClosable: {
      type: Boolean,
      default: true
    },
    zIndex: {
      type: Number,
      default: () => getZIndex()
    },
    lockScroll: {
      type: Boolean,
      default: true
    },
    closeOnPressEscape: {
      type: Boolean,
      default: true
    },
    top: {
      type: Number,
      default: 0
    },
    useScrollbar: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      rendered: true,
      showHeader: true,
      showFooter: true,
      contentHeight: 0,
      zIndexValue: this.zIndex,
      hasMouseDown: false,
      isOpened: false,
      drawerMask: null
    };
  },
  computed: {
    isHorizontal() {
      return this.direction === "rtl" || this.direction === "ltr";
    },
    bodyStyle() {
      return {
        height: this.contentHeight + "px"
      };
    },
    wrapperStyle() {
      const wrapperTop = this.top !== 0 ? `${this.top}px` : 0;
      const directionStyle = {
        ltr: { top: wrapperTop, bottom: 0, height: `calc(100% - ${wrapperTop})` },
        rtl: { top: wrapperTop, bottom: 0, height: `calc(100% - ${wrapperTop})` },
        ttb: { left: 0, right: 0 },
        btt: { left: 0, right: 0 }
      };
      return {
        zIndex: this.zIndexValue,
        ...directionStyle[this.direction],
        [this.isHorizontal ? "width" : "height"]: this.sizeCalc
      };
    },
    sizeCalc() {
      const size = this.size;
      if (DRAWER_SIZE.hasOwnProperty(size)) {
        return `${DRAWER_SIZE[size]}px`;
      }
      return isNumber(size) ? `${size}px` : size;
    },
    drawerMaskCls() {
      return { [getPrefixedClassName("sf-drawer__mask-wrap--transparent")]: !this.mask };
    }
  },
  watch: {
    title: {
      immediate: true,
      handler: function() {
        this.showHeader = !(this.$slots.title === void 0 && !this.title);
      }
    },
    showHeader() {
      this.$nextTick(() => {
        this._calcContentBodyHeight();
      });
    }
  },
  mounted() {
    this.showFooter = !(this.$slots.footer === void 0);
    this.closeOnPressEscape && this._bindEscKeyDown();
    const DELAY = 80;
    const _resetContentHeight = debounce(this._calcContentBodyHeight, DELAY);
    window.addEventListener("resize", _resetContentHeight);
    this.$once("hook:beforeDestroy", () => {
      window.removeEventListener("resize", _resetContentHeight);
    });
  },
  destroyed() {
    if (this.appendToBody && this.$el && this.$el.parentNode) {
      this.$el.parentNode.removeChild(this.$el);
    }
    this.closeOnPressEscape && off(document, "keydown", this.keyDown);
    if (this.drawerMask) {
      this.drawerMask.destroy();
      this.drawerMask = null;
    }
  },
  methods: {
    getFullUtid(utidBase) {
      return this.$attrs.utid ? `${this.$attrs.utid}-${utidBase}` : utidBase;
    },
    afterEnter() {
      this.$emit("opened");
    },
    afterLeave() {
      this.$emit("closed");
    },
    hide(cancel) {
      if (cancel !== false) {
        this.$emit("close");
        this.isOpened = false;
        if (this.destroyOnClose) {
          this.rendered = false;
        }
      }
    },
    show() {
      this.$emit("open");
      this.isOpened = true;
      if (this.appendToBody) {
        document.body.appendChild(this.$el);
        this.lockScroll && this._lockScrollBar();
      }
      if (!this.rendered) {
        this.rendered = true;
      }
      this.$nextTick(() => {
        this._calcContentBodyHeight();
      });
    },
    handleWrapperClick(e) {
      if (this.wrapperClosable && this.hasMouseDown) {
        const target = e.target;
        const drawer = this.$refs.drawer;
        const outter = this.$refs.outter;
        let parent = target.parentNode;
        if (target === drawer) {
          return;
        }
        while (parent && parent !== drawer && parent !== outter) {
          parent = parent.parentNode;
        }
        if (parent !== drawer) {
          this.closeDrawer();
        }
      }
      this.hasMouseDown = false;
    },
    closeDrawer() {
      if (this.duringBeforeClose) {
        return;
      }
      if (typeof this.beforeClose === "function") {
        this.duringBeforeClose = true;
        when(this.beforeClose()).then(
          (res) => {
            if (res !== false) {
              this.hide();
            }
            this.duringBeforeClose = false;
          },
          () => {
            this.duringBeforeClose = false;
          }
        );
        return;
      }
      this.hide();
    },
    showDrawerMask() {
      if (!this.drawerMask) {
        this.drawerMask = new LoadMask(this.$refs.drawer, {
          cls: getPrefixedClassName("sf-drawer__loadmask")
        });
      }
      this.drawerMask.show();
    },
    hideDrawerMask() {
      this.drawerMask && this.drawerMask.hide();
    },
    setZIndex(zIndex) {
      this.zIndexValue = zIndex || getZIndex();
    },
    _bindEscKeyDown() {
      const CODE_ESC = 27;
      this.keyDown = (event) => {
        if (event.keyCode === CODE_ESC) {
          this.isOpened && this.closeDrawer();
        }
      };
      on(document, "keydown", this.keyDown);
    },
    _lockScrollBar() {
      $(document.body).addClass(getPrefixedClassName("sf-drawer__body--hidden"));
    },
    _resetScrollBar() {
      $(document.body).removeClass(getPrefixedClassName("sf-drawer__body--hidden"));
    },
    _calcContentBodyHeight() {
      const headerHeight = this.showHeader && this.$refs.header && this.$refs.header.offsetHeight || 0;
      const footerHeight = this.showFooter && this.$refs.footer && this.$refs.footer.offsetHeight || 0;
      this.contentHeight = this.$refs.drawer && this.$refs.drawer.offsetHeight - headerHeight - footerHeight;
    },
    getPrefixedClassName
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _obj, _obj$1;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      ref: "outter",
      on: {
        mousedown: function($event) {
          _vm.hasMouseDown = true;
        },
        mouseup: _vm.handleWrapperClick
      }
    },
    [
      _c("transition", { attrs: { name: "fade" } }, [
        _vm.isOpened ? _c("div", {
          class: [
            _vm.getPrefixedClassName("sf-drawer__mask-wrap"),
            _vm.drawerMaskCls
          ],
          style: { zIndex: _vm.zIndexValue }
        }) : _vm._e()
      ]),
      _vm._v(" "),
      _c(
        "transition",
        {
          attrs: { name: _vm.getPrefixedClassName("sf-drawer-fade") },
          on: { "after-enter": _vm.afterEnter, "after-leave": _vm.afterLeave }
        },
        [
          _c(
            "div",
            {
              directives: [
                {
                  name: "show",
                  rawName: "v-show",
                  value: _vm.isOpened,
                  expression: "isOpened"
                }
              ],
              class: [
                _vm.getPrefixedClassName("sf-drawer__wrapper"),
                _vm.getPrefixedClassName(_vm.direction),
                _vm.isOpened ? _vm.getPrefixedClassName("sf-drawer__open") : ""
              ],
              style: _vm.wrapperStyle
            },
            [
              _c(
                "div",
                { class: _vm.getPrefixedClassName("sf-drawer__container") },
                [
                  _c(
                    "div",
                    {
                      ref: "drawer",
                      class: [
                        _vm.getPrefixedClassName("sf-drawer"),
                        _vm.customClass
                      ],
                      attrs: {
                        "aria-modal": "true",
                        "aria-labelledby": "sf-drawer__title"
                      }
                    },
                    [
                      _vm.showHeader ? _c(
                        "header",
                        {
                          ref: "header",
                          class: _vm.getPrefixedClassName("sf-drawer__header")
                        },
                        [
                          _vm._t("title", [
                            _c("span", [_vm._v(_vm._s(_vm.title))])
                          ]),
                          _vm._v(" "),
                          _vm.showClose ? _c("i", {
                            class: [
                              "pull-right",
                              _vm.getPrefixedClassName(
                                "sf-drawer_close"
                              ),
                              "iconfont",
                              "vtv-icon-win-close"
                            ],
                            attrs: {
                              utid: _vm.getFullUtid("close-drawer")
                            },
                            on: { click: _vm.closeDrawer }
                          }) : _vm._e()
                        ],
                        2
                      ) : _vm._e(),
                      _vm._v(" "),
                      _c(
                        "div",
                        { ref: "content" },
                        [
                          _vm.useScrollbar && _vm.rendered ? _c(
                            "sf-scrollbar",
                            {
                              ref: "scrollbar",
                              attrs: {
                                "auto-scrollbar": false,
                                "default-height": _vm.contentHeight
                              }
                            },
                            [
                              _c(
                                "section",
                                {
                                  class: [
                                    _vm.getPrefixedClassName(
                                      "sf-drawer__body"
                                    ),
                                    (_obj = {}, _obj[_vm.getPrefixedClassName(
                                      "sf-drawer__body--padding-bottom"
                                    )] = !_vm.showFooter, _obj)
                                  ]
                                },
                                [_vm._t("default")],
                                2
                              )
                            ]
                          ) : _vm._e(),
                          _vm._v(" "),
                          !_vm.useScrollbar && _vm.rendered ? [
                            _c(
                              "section",
                              {
                                class: [
                                  _vm.getPrefixedClassName(
                                    "sf-drawer__body"
                                  ),
                                  (_obj$1 = {}, _obj$1[_vm.getPrefixedClassName(
                                    "sf-drawer__body--padding-bottom"
                                  )] = !_vm.showFooter, _obj$1)
                                ],
                                style: _vm.bodyStyle
                              },
                              [_vm._t("default")],
                              2
                            )
                          ] : _vm._e(),
                          _vm._v(" "),
                          _vm.showFooter ? _c(
                            "footer",
                            {
                              ref: "footer",
                              class: _vm.getPrefixedClassName(
                                "sf-drawer__footer"
                              )
                            },
                            [_vm._t("footer")],
                            2
                          ) : _vm._e()
                        ],
                        2
                      )
                    ]
                  )
                ]
              )
            ]
          )
        ]
      )
    ],
    1
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__ as SfDrawer };
