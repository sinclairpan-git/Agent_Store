import { componentName } from '@sxf/er-components/_const';
import { addResizeListener, removeResizeListener } from '@sxf/er-components/_utils/resize-event';
import { getPrefixedClassName } from '@sxf/er-feature';
import { throttle } from '@sxf/er-utils/delay';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
var script$2 = {
  name: componentName.carousel,
  componentName: componentName.carousel,
  props: {
    initialIndex: {
      type: Number,
      default: 0
    },
    height: String,
    trigger: {
      type: String,
      default: "hover"
    },
    autoplay: {
      type: Boolean,
      default: true
    },
    interval: {
      type: Number,
      default: 3e3
    },
    indicatorType: {
      type: String,
      default: "circle",
      validator(val) {
        return ["circle", "line"].indexOf(val) !== -1;
      }
    },
    indicatorPosition: {
      type: String
    },
    indicator: {
      type: Boolean,
      default: true
    },
    arrow: {
      type: String,
      default: "hover"
    },
    type: {
      type: String
    },
    loop: {
      type: Boolean,
      default: true
    },
    direction: {
      type: String,
      default: "horizontal",
      validator(val) {
        return ["horizontal", "vertical"].indexOf(val) !== -1;
      }
    },
    inline: {
      type: Number,
      default: 1,
      validator(val) {
        return val !== 0;
      }
    }
  },
  data() {
    return {
      items: [],
      activeIndex: -1,
      containerWidth: 0,
      timer: null,
      hover: false
    };
  },
  computed: {
    arrowDisplay() {
      return this.arrow !== "never" && this.direction !== "vertical";
    },
    hasLabel() {
      return this.items.some((item) => item.label.toString().length > 0);
    },
    carouselClasses() {
      const classes = [
        this.getPrefixedClassName("el-carousel"),
        this.getPrefixedClassName("el-carousel--" + this.direction)
      ];
      if (this.type === "card") {
        classes.push(this.getPrefixedClassName("el-carousel--card"));
      }
      return classes;
    },
    indicatorsClasses() {
      const classes = [
        this.getPrefixedClassName("el-carousel__indicators"),
        this.getPrefixedClassName("el-carousel__indicators--" + this.direction)
      ];
      if (this.hasLabel) {
        classes.push(this.getPrefixedClassName("el-carousel__indicators--labels"));
      }
      classes.push(this.getPrefixedClassName("el-carousel__indicators--" + this.indicatorType));
      if (this.indicatorPosition === "outside" || this.type === "card") {
        classes.push(this.getPrefixedClassName("el-carousel__indicators--outside"));
      }
      return classes;
    }
  },
  watch: {
    items(val) {
      if (val.length > 0) {
        this.setActiveItem(this.initialIndex);
      }
    },
    activeIndex(val, oldVal) {
      this.resetItemPosition(oldVal);
      if (oldVal > -1) {
        this.$emit("change", val, oldVal);
      }
    },
    autoplay(val) {
      val ? this.startTimer() : this.pauseTimer();
    },
    loop() {
      this.setActiveItem(this.activeIndex);
    }
  },
  created() {
    this.throttledArrowClick = throttle(
      (index) => {
        this.setActiveItem(index);
      },
      300,
      {
        trailing: true
      }
    );
    this.throttledIndicatorHover = throttle((index) => {
      this.handleIndicatorHover(index);
    }, 300);
  },
  mounted() {
    this.updateItems();
    this.$nextTick(() => {
      addResizeListener(this.$el, this.resetItemPosition);
      if (this.initialIndex < this.items.length && this.initialIndex >= 0) {
        this.activeIndex = this.initialIndex;
      }
      this.startTimer();
    });
  },
  beforeDestroy() {
    if (this.$el) {
      removeResizeListener(this.$el, this.resetItemPosition);
    }
    this.pauseTimer();
  },
  methods: {
    getFullUtid(utidBase) {
      return this.$attrs.utid ? `${this.$attrs.utid}-${utidBase}` : utidBase;
    },
    handleMouseEnter() {
      this.hover = true;
      this.pauseTimer();
    },
    handleMouseLeave() {
      this.hover = false;
      this.startTimer();
    },
    itemInStage(item, index) {
      const length = this.items.length;
      if (index === length - 1 && item.inStage && this.items[0].active || item.inStage && this.items[index + 1] && this.items[index + 1].active) {
        return "left";
      } else if (index === 0 && item.inStage && this.items[length - 1].active || item.inStage && this.items[index - 1] && this.items[index - 1].active) {
        return "right";
      }
      return false;
    },
    handleButtonEnter(arrow) {
      if (this.direction === "vertical") {
        return;
      }
      this.items.forEach((item, index) => {
        if (arrow === this.itemInStage(item, index)) {
          item.hover = true;
        }
      });
    },
    handleButtonLeave() {
      if (this.direction === "vertical") {
        return;
      }
      this.items.forEach((item) => {
        item.hover = false;
      });
    },
    updateItems() {
      this.items = this.$children.filter((child) => child.$options.componentName === componentName.carouselItem);
    },
    resetItemPosition(oldIndex) {
      this.items.forEach((item, index) => {
        item.translateItem(index, this.activeIndex, oldIndex);
      });
    },
    playSlides() {
      if (this.activeIndex < this.items.length - 1) {
        this.activeIndex++;
      } else if (this.loop) {
        this.activeIndex = 0;
      }
    },
    pauseTimer() {
      if (this.timer) {
        clearInterval(this.timer);
        this.timer = null;
      }
    },
    startTimer() {
      if (this.interval <= 0 || !this.autoplay || this.timer) {
        return;
      }
      this.timer = setInterval(this.playSlides, this.interval);
    },
    setActiveItem(index) {
      if (typeof index === "string") {
        const filteredItems = this.items.filter((item) => item.name === index);
        if (filteredItems.length > 0) {
          index = this.items.indexOf(filteredItems[0]);
        }
      }
      index = Number(index);
      if (isNaN(index) || index !== Math.floor(index)) {
        return;
      }
      const length = this.items.length;
      const oldIndex = this.activeIndex;
      if (index < 0) {
        this.activeIndex = this.loop ? length - 1 : 0;
      } else if (index >= length) {
        this.activeIndex = this.loop ? 0 : length - 1;
      } else {
        this.activeIndex = index;
      }
      if (oldIndex === this.activeIndex) {
        this.resetItemPosition(oldIndex);
      }
    },
    prev() {
      this.setActiveItem(this.activeIndex - 1);
    },
    next() {
      this.setActiveItem(this.activeIndex + 1);
    },
    handleIndicatorClick(index) {
      this.activeIndex = index;
    },
    handleIndicatorHover(index) {
      if (this.trigger === "hover" && index !== this.activeIndex) {
        this.activeIndex = index;
      }
    },
    getPrefixedClassName
  }
};
const __vue_script__$2 = script$2;
var __vue_render__$2 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      class: _vm.carouselClasses,
      on: {
        mouseenter: function($event) {
          $event.stopPropagation();
          return _vm.handleMouseEnter($event);
        },
        mouseleave: function($event) {
          $event.stopPropagation();
          return _vm.handleMouseLeave($event);
        }
      }
    },
    [
      _c(
        "div",
        {
          class: _vm.getPrefixedClassName("el-carousel__container"),
          style: { height: _vm.height }
        },
        [
          _vm.arrowDisplay ? _c("transition", { attrs: { name: "carousel-arrow-left" } }, [
            _c(
              "button",
              {
                directives: [
                  {
                    name: "show",
                    rawName: "v-show",
                    value: (_vm.arrow === "always" || _vm.hover) && (_vm.loop || _vm.activeIndex > 0),
                    expression: "(arrow === 'always' || hover) && (loop || activeIndex > 0)"
                  }
                ],
                class: [
                  _vm.getPrefixedClassName("el-carousel__arrow"),
                  _vm.getPrefixedClassName("el-carousel__arrow--left")
                ],
                attrs: {
                  type: "button",
                  utid: _vm.getFullUtid("carousel-arrow-left")
                },
                on: {
                  mouseenter: function($event) {
                    return _vm.handleButtonEnter("left");
                  },
                  mouseleave: _vm.handleButtonLeave,
                  click: function($event) {
                    $event.stopPropagation();
                    return _vm.throttledArrowClick(_vm.activeIndex - 1);
                  }
                }
              },
              [_c("i", { staticClass: "iconfont vtv-icon-arrow-left" })]
            )
          ]) : _vm._e(),
          _vm._v(" "),
          _vm.arrowDisplay ? _c("transition", { attrs: { name: "carousel-arrow-right" } }, [
            _c(
              "button",
              {
                directives: [
                  {
                    name: "show",
                    rawName: "v-show",
                    value: (_vm.arrow === "always" || _vm.hover) && (_vm.loop || _vm.activeIndex < _vm.items.length - _vm.inline),
                    expression: "(arrow === 'always' || hover) && (loop || activeIndex < items.length - inline)"
                  }
                ],
                class: [
                  _vm.getPrefixedClassName("el-carousel__arrow"),
                  _vm.getPrefixedClassName("el-carousel__arrow--right")
                ],
                attrs: {
                  type: "button",
                  utid: _vm.getFullUtid("carousel-arrow-right")
                },
                on: {
                  mouseenter: function($event) {
                    return _vm.handleButtonEnter("right");
                  },
                  mouseleave: _vm.handleButtonLeave,
                  click: function($event) {
                    $event.stopPropagation();
                    return _vm.throttledArrowClick(_vm.activeIndex + 1);
                  }
                }
              },
              [_c("i", { staticClass: "iconfont vtv-icon-arrow-right" })]
            )
          ]) : _vm._e(),
          _vm._v(" "),
          _vm._t("default")
        ],
        2
      ),
      _vm._v(" "),
      _vm.indicatorPosition !== "none" ? _c(
        "ul",
        { class: _vm.indicatorsClasses },
        _vm._l(_vm.items, function(item, index) {
          return _c(
            "li",
            {
              key: index,
              class: [
                _vm.getPrefixedClassName("el-carousel__indicator"),
                _vm.getPrefixedClassName(
                  "el-carousel__indicator--" + _vm.direction
                ),
                { "is-active": index === _vm.activeIndex }
              ],
              attrs: { utid: _vm.getFullUtid("carousel-indicator") },
              on: {
                mouseenter: function($event) {
                  return _vm.throttledIndicatorHover(index);
                },
                click: function($event) {
                  $event.stopPropagation();
                  return _vm.handleIndicatorClick(index);
                }
              }
            },
            [
              _c(
                "button",
                { class: _vm.getPrefixedClassName("el-carousel__button") },
                [
                  _vm.hasLabel ? _c("span", [_vm._v(_vm._s(item.label))]) : _vm._e()
                ]
              )
            ]
          );
        }),
        0
      ) : _vm._e()
    ]
  );
};
var __vue_staticRenderFns__$2 = [];
__vue_render__$2._withStripped = true;
const __vue_inject_styles__$2 = void 0;
const __vue_scope_id__$2 = void 0;
const __vue_module_identifier__$2 = void 0;
const __vue_is_functional_template__$2 = false;
const __vue_component__$2 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$2, staticRenderFns: __vue_staticRenderFns__$2 },
  __vue_inject_styles__$2,
  __vue_script__$2,
  __vue_scope_id__$2,
  __vue_is_functional_template__$2,
  __vue_module_identifier__$2,
  false,
  void 0,
  void 0,
  void 0
);
var script$1 = {
  name: componentName.carouselInline,
  componentName: componentName.carouselInline,
  components: { SfCarousel: __vue_component__$2 },
  extends: __vue_component__$2,
  props: {
    type: {
      type: String,
      default: "inline"
    },
    loop: {
      type: Boolean,
      default: false
    },
    autoplay: {
      type: Boolean,
      default: false
    },
    arrow: {
      type: String,
      default: "never"
    },
    trigger: {
      type: String,
      default: "click"
    },
    indicatorPosition: {
      type: String,
      default: "none"
    },
    showBtn: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      activeInlineIndex: 0
    };
  },
  computed: {
    rightDisabeld() {
      let items = this.items;
      if (this.$refs.carousel) {
        items = this.$refs.carousel.items;
      }
      return this.activeInlineIndex >= items.length - this.inline;
    }
  },
  methods: {
    next() {
      this.$refs.carousel && this.$refs.carousel.next();
    },
    prev() {
      this.$refs.carousel && this.$refs.carousel.prev();
    },
    getPrefixedClassName
  }
};
const __vue_script__$1 = script$1;
var __vue_render__$1 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    { class: _vm.getPrefixedClassName("sf-carousel-inline_wrap") },
    [
      _c(
        "sf-carousel",
        _vm._b(
          {
            ref: "carousel",
            on: {
              change: function($event) {
                _vm.activeInlineIndex = arguments[0];
              }
            }
          },
          "sf-carousel",
          _vm.$props,
          false
        ),
        [_vm._t("default")],
        2
      ),
      _vm._v(" "),
      _c(
        "button",
        {
          directives: [
            {
              name: "show",
              rawName: "v-show",
              value: _vm.showBtn,
              expression: "showBtn"
            }
          ],
          class: [
            _vm.getPrefixedClassName("el-carousel__arrow"),
            _vm.getPrefixedClassName("el-carousel__arrow--left"),
            _vm.getPrefixedClassName("sf-carousel-inline_btn"),
            _vm.getPrefixedClassName("sf-carousel-inline_btn--left")
          ],
          attrs: { disabled: _vm.activeInlineIndex <= 0 },
          on: {
            click: function($event) {
              $event.stopPropagation();
              return _vm.prev();
            }
          }
        },
        [_c("i", { staticClass: "iconfont vtv-icon-arrow-left" })]
      ),
      _vm._v(" "),
      _c(
        "button",
        {
          directives: [
            {
              name: "show",
              rawName: "v-show",
              value: _vm.showBtn,
              expression: "showBtn"
            }
          ],
          class: [
            _vm.getPrefixedClassName("el-carousel__arrow"),
            _vm.getPrefixedClassName("el-carousel__arrow--right"),
            _vm.getPrefixedClassName("sf-carousel-inline_btn"),
            _vm.getPrefixedClassName("sf-carousel-inline_btn--right")
          ],
          attrs: { disabled: _vm.rightDisabeld },
          on: {
            click: function($event) {
              $event.stopPropagation();
              return _vm.next();
            }
          }
        },
        [_c("i", { staticClass: "iconfont vtv-icon-arrow-right" })]
      )
    ],
    1
  );
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
const CARD_SCALE = 0.83;
var script = {
  name: componentName.carouselItem,
  componentName: componentName.carouselItem,
  props: {
    name: String,
    label: {
      type: [String, Number],
      default: ""
    }
  },
  data() {
    return {
      hover: false,
      translate: 0,
      scale: 1,
      active: false,
      ready: false,
      inStage: false,
      animating: false
    };
  },
  computed: {
    parentDirection() {
      return this.$parent.direction;
    },
    itemStyle() {
      const translateType = this.parentDirection === "vertical" ? "translateY" : "translateX";
      const transformValue = `${translateType}(${this.translate}px) scale(${this.scale})`;
      const widthValue = this.$parent.type === "inline" ? { width: 100 / this.$parent.inline + "%" } : {};
      return {
        transform: transformValue,
        ...widthValue
      };
    }
  },
  created() {
    this.$parent && this.$parent.updateItems();
  },
  destroyed() {
    this.$parent && this.$parent.updateItems();
  },
  methods: {
    processIndex(index, activeIndex, length) {
      if (activeIndex === 0 && index === length - 1) {
        return -1;
      } else if (activeIndex === length - 1 && index === 0) {
        return length;
      } else if (index < activeIndex - 1 && activeIndex - index >= length / 2) {
        return length + 1;
      } else if (index > activeIndex + 1 && index - activeIndex >= length / 2) {
        return -2;
      }
      return index;
    },
    calcCardTranslate(index, activeIndex) {
      const parentWidth = this.$parent.$el.offsetWidth;
      if (this.inStage) {
        return parentWidth * ((2 - CARD_SCALE) * (index - activeIndex) + 1) / 4;
      } else if (index < activeIndex) {
        return -(1 + CARD_SCALE) * parentWidth / 4;
      }
      return (3 + CARD_SCALE) * parentWidth / 4;
    },
    calcInlineTranslate(index, activeIndex) {
      const distance = this.$parent.$el.offsetWidth / this.$parent.inline;
      return distance * (index - activeIndex);
    },
    calcTranslate(index, activeIndex, isVertical) {
      const distance = this.$parent.$el[isVertical ? "offsetHeight" : "offsetWidth"];
      return distance * (index - activeIndex);
    },
    translateItem(index, activeIndex, oldIndex) {
      const parentType = this.$parent.type;
      const parentDirection = this.parentDirection;
      const length = this.$parent.items.length;
      if (parentType !== "card" && typeof oldIndex !== "undefined") {
        if (parentType === "inline") {
          this.animating = true;
        } else {
          this.animating = index === activeIndex || index === oldIndex;
        }
      }
      if (index !== activeIndex && length > 2 && this.$parent.loop) {
        index = this.processIndex(index, activeIndex, length);
      }
      if (parentType === "card") {
        this.inStage = Math.round(Math.abs(index - activeIndex)) <= 1;
        this.active = index === activeIndex;
        this.translate = this.calcCardTranslate(index, activeIndex);
        this.scale = this.active ? 1 : CARD_SCALE;
      } else if (parentType === "inline") {
        this.active = index === activeIndex;
        this.translate = this.calcInlineTranslate(index, activeIndex);
      } else {
        this.active = index === activeIndex;
        this.translate = this.calcTranslate(index, activeIndex, parentDirection === "vertical");
      }
      this.ready = true;
    },
    handleItemClick() {
      const parent = this.$parent;
      if (parent && parent.type === "card") {
        parent.setActiveItem(parent.items.indexOf(this));
      }
    },
    getPrefixedClassName
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _obj;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      directives: [
        {
          name: "show",
          rawName: "v-show",
          value: _vm.ready,
          expression: "ready"
        }
      ],
      class: [
        _vm.getPrefixedClassName("el-carousel__item"),
        (_obj = {}, _obj[_vm.getPrefixedClassName("is-active")] = _vm.active, _obj[_vm.getPrefixedClassName("el-carousel__item--card")] = _vm.$parent.type === "card", _obj[_vm.getPrefixedClassName("is-in-stage")] = _vm.inStage, _obj[_vm.getPrefixedClassName("is-hover")] = _vm.hover, _obj[_vm.getPrefixedClassName("is-animating")] = _vm.animating, _obj)
      ],
      style: _vm.itemStyle,
      on: { click: _vm.handleItemClick }
    },
    [
      _vm.$parent.type === "card" ? _c("div", {
        directives: [
          {
            name: "show",
            rawName: "v-show",
            value: !_vm.active,
            expression: "!active"
          }
        ],
        class: _vm.getPrefixedClassName("el-carousel__mask")
      }) : _vm._e(),
      _vm._v(" "),
      _vm._t("default")
    ],
    2
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__$2 as SfCarousel, __vue_component__$1 as SfCarouselInline, __vue_component__ as SfCarouselItem };
