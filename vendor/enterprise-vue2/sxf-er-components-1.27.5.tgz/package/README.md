# Eresh

[playground](http://ui.sangfor.com.cn/common/docs/cloud/playground/)

## 快速上手

### 安装依赖

```bash
pnpm add @sxf/er-components @sxf/er-utils @sxf/er-widget @sxf/er-config @sxf/er-style @sxf/er-lib @sxf/er-validator
```

### 组件全量注册

```javascript
import Vue from 'vue';
// 国际化初始化，以项目为准，组件库只是需要一个 i18n 实例
import { createVueI18nIntl } from '@sxf/vue-intl';
// 【重要】组件库的全局配置
import { setLocale, updateGlobalConfig } from '@sxf/er-config';
// icon 前置依赖，以项目为准，组件库只是需要有这个东西
import '@sxf/vtv-icon';
// 【重要】引入组件库的核心样式
import '@sxf/er-style/core/themes/default.css';
// 【重要】引入组件样式
import '@sxf/er-components/default.min.css';
// 【按项目情况判断是否需要引入】重置浏览器默认样式，如 box-sizing 等
import '@sxf/er-style/reset/themes/default.css';

// 国际化初始化，以项目为准，组件库只是需要一个 i18n 实例
const i18nIntl = createVueI18nIntl({ messages: {}, locale: 'zh-CN' });

// 【重要】给组件库传入 i18n 实例和语言配置 
setLocale(i18nIntl, 'zh-CN');
// 【重要】给组件库传入 Vue，这里还可以把需要的自定义配置项传进去
updateGlobalConfig({
  VueConstructor: Vue,
});

async function main() {
  // 【重要】组件注册
  const ErComponents = await import('@sxf/er-components');
  Vue.use(ErComponents);

  const App = (await import('./src/App.vue')).default;
  new Vue({
    el: '#app',
    render(h) {
      return h(App);
    },
  });
}

main();
```

### 组件按需加载

> 这里示例是按需引入然后全局注册组件，也可以选择在使用到的模块中引入并局部注册组件，步骤都是引入组件和组件样式文件，然后注册。

```javascript
import Vue from 'vue';
// 国际化初始化，以项目为准，组件库只是需要一个 i18n 实例
import { createVueI18nIntl } from '@sxf/vue-intl';

// 【重要】组件库全局配置
import { setLocale, updateGlobalConfig } from '@sxf/er-config';
// 【重要】组件库核心样式，无论组件按需加载还是全量注册都需要引入
import '@sxf/er-style/core/themes/default.css';

// 假定需要使用下面的插件和组件，目前需要手动引入对应的主题样式
import '@sxf/er-components/_global/mask/style/themes/default.css';
import '@sxf/er-components/_global/notify/style/themes/default.css';
import '@sxf/er-components/flex/style/themes/default.css';
import '@sxf/er-components/window/style/themes/default.css';
import LoadMaskPlugin from '@sxf/er-components/_global/mask';
import NotifyPlugin from '@sxf/er-components/_global/notify';
import { SfWindow } from '@sxf/er-components/window';
import { SfFlex, SfFlexItem } from '@sxf/er-components/flex';

// 国际化初始化，以项目为准，组件库只是需要一个 i18n 实例
const i18nIntl = createVueI18nIntl({ messages: {}, locale: 'zh-CN' });

// 【重要】给组件库传入 i18n 实例和语言配置 
setLocale(i18nIntl, locale);
// 【重要】给组件库传入 Vue，这里还可以把需要的自定义配置项传进去
updateGlobalConfig({
    VueConstructor: Vue,
});

// 使用插件及注册组件
Vue.use(LoadMaskPlugin);
Vue.use(NotifyPlugin);
const components = [SfFlex, SfFlexItem, SfWindow];
components.forEach(component => {
    Vue.component(component.name, component);
});
```

### 用法示例

```js
// 注册组件
import NotifyPlugin from '@sxf/er-components/_global/notify';
import { SfWindow } from '@sxf/er-components/window';

Vue.use(NotifyPlugin);
Vue.component(SfWindow.name, SfWindow);
```

```js
// 使用一些组件方法
import { vueWindowCreator } from '@sxf/er-components/window'

vueWindowCreator(win).create().show();
```

### 全局修改组件前缀

在组件库全局注册之前，通过修改全局配置 `prefixComp` 实现

```js
import Vue from 'vue';
import '@sxf/vtv-icon';
import '@sxf/er-style/core/themes/default.css';

import ErComponents from '@sxf/er-components';
import { setLocale, updateGlobalConfig } from '@sxf/er-config';
import { createVueI18nIntl } from '@sxf/vue-intl';

import App from './src/App.vue';

const i18nIntl = createVueI18nIntl({ messages: {}, locale: 'zh-CN' });
setLocale(i18nIntl, 'zh-CN');
updateGlobalConfig({
  VueConstructor: Vue,
  // 传入 prefixComp
  prefixComp: 'El',
});

async function main() {
  Vue.use(ErComponents);
  new Vue({
    el: '#app',
    render(h) {
      return h(App);
    },
  });
}

main();

```

## 迁移指南

[从 vt-component 迁移](http://mq.code.sangfor.org/UED/CloudFE/Eresh/wikis/%E8%BF%81%E7%A7%BB%E6%8C%87%E5%8D%97)
