import $ from 'jquery';
import { componentName } from '@sxf/er-components/_const';
import { MgrServerMixin } from '@sxf/er-components/_mixins';
import { isPropEnabled } from '@sxf/er-components/_utils/vue-utils';
import { SfFlexItem, SfFlex } from '@sxf/er-components/flex';
import { getPrefixedClassName } from '@sxf/er-feature';
var Toolbar = {
  name: componentName.toolbar,
  componentName: componentName.toolbar,
  mixins: [MgrServerMixin],
  props: {
    disabled: Boolean,
    theme: {
      type: String,
      default: "default",
      validator: (theme) => ["default", "white", "block"].includes(theme)
    },
    noGapLeft: Boolean,
    noGapRight: Boolean,
    noPaddingX: {
      type: Boolean,
      default: true
    },
    noPaddingY: Boolean,
    borderTop: Boolean,
    borderBottom: Boolean,
    noLeftRightReplace: {
      type: Boolean,
      default: true
    }
  },
  provide() {
    return {
      toolbarDisabled: this.isDisabled
    };
  },
  computed: {
    hasPaddingX() {
      return typeof this.noPaddingX === "undefined" ? this.$parent.$options.componentName !== componentName.toolbarWrap : !isPropEnabled(this.noPaddingX);
    },
    cls() {
      return {
        [getPrefixedClassName("sf-toolbar--" + this.theme)]: this.theme,
        [getPrefixedClassName("has-padding-x")]: this.hasPaddingX,
        [getPrefixedClassName("has-padding-y")]: !isPropEnabled(this.noPaddingY),
        [getPrefixedClassName("has-border-top")]: isPropEnabled(this.borderTop),
        [getPrefixedClassName("has-border-bottom")]: isPropEnabled(this.borderBottom)
      };
    },
    defaultBoxCls() {
      return {
        [getPrefixedClassName("has-gap")]: !isPropEnabled(this.noGapLeft)
      };
    },
    rightBoxCls() {
      return {
        [getPrefixedClassName("has-gap")]: !isPropEnabled(this.noGapRight)
      };
    },
    isDisabled() {
      return isPropEnabled(this.disabled);
    }
  },
  render(createElem) {
    const isVnodeShow = (vnodes) => {
      if (!vnodes || !vnodes.length) {
        return false;
      }
      const tagVnodes = vnodes.filter((v) => !!v.tag);
      if (!tagVnodes.length) {
        return false;
      }
      return tagVnodes.some((v) => {
        var _a;
        const directives = ((_a = v == null ? void 0 : v.data) == null ? void 0 : _a.directives) || [];
        const showDirective = directives.find((d) => d.name === "show");
        if (showDirective) {
          return showDirective.value === true;
        }
        return true;
      });
    };
    const insertStretchEl = (arr) => {
      arr.push(
        createElem(
          SfFlexItem,
          {
            props: {
              flex: "1 1 1px"
            }
          },
          this.$slots.stretch
        )
      );
    };
    let needReplace = false;
    const box = ["default", "right"].reduce((arr, name) => {
      let vnodes;
      if (this.$slots[name]) {
        vnodes = this.$slots[name];
      } else if (this.$scopedSlots[name]) {
        vnodes = this.$scopedSlots[name]();
      }
      if (name === "right" && !needReplace) {
        insertStretchEl(arr);
      }
      $.makeArray(vnodes).forEach((vnode) => {
        if (vnode.tag) {
          arr.push(
            createElem(
              SfFlexItem,
              {
                class: [getPrefixedClassName(`sf-toolbar_${name}-box`), this[name + "BoxCls"]],
                props: {
                  flex: "0 0 auto"
                }
              },
              [vnode]
            )
          );
          if (needReplace && name === "right") {
            insertStretchEl(arr);
            needReplace = false;
          }
          return;
        }
        arr.push(vnode);
      });
      if (name === "default") {
        needReplace = this.noLeftRightReplace && !isVnodeShow(vnodes);
      }
      return arr;
    }, []);
    return createElem(
      SfFlex,
      {
        class: [getPrefixedClassName("sf-toolbar"), this.cls],
        props: {
          alignItems: "center"
        }
      },
      box
    );
  }
};
var ToolbarWrap = {
  name: componentName.toolbarWrap,
  componentName: componentName.toolbarWrap,
  props: {
    hasMaintain: {
      type: Boolean,
      default: true
    },
    theme: {
      type: String,
      default: "default",
      validator: (theme) => ["default", "white", "block"].includes(theme)
    }
  },
  computed: {
    cls: function() {
      return {
        [getPrefixedClassName("sf-toolbar-wrap--" + this.theme)]: this.theme,
        [getPrefixedClassName("maintain")]: this.hasMaintain
      };
    }
  },
  render(createElem) {
    return createElem(
      "div",
      {
        class: [getPrefixedClassName("sf-toolbar-wrap"), this.cls]
      },
      this.$slots.default
    );
  }
};
export { Toolbar as SfToolbar, ToolbarWrap as SfToolbarWrap };
