import $ from 'jquery';
import { componentName } from '@sxf/er-components/_const';
import { getPrefixedClassName } from '@sxf/er-feature';
import { fixscrollbar } from '@sxf/er-widget/scrollbar';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
var script = {
  name: componentName.scrollbar,
  componentName: componentName.scrollbar,
  props: {
    theme: {
      type: String,
      default: "bright-theme",
      validator: (theme) => ["bright-theme", "dark-theme"].includes(theme)
    }
  },
  mounted() {
    this.invokeScrollbar({
      scrollbarContainer: this.$refs.scrollbarWrap,
      scrollbarXRailContainer: this.$refs.scrollbarX,
      scrollbarYRailContainer: this.$refs.scrollbarY
    });
    this.bindEvent();
  },
  beforeDestroy() {
    this.destroy();
  },
  methods: {
    getPrefixedClassName,
    invokeScrollbar(...args) {
      fixscrollbar.call($(this.$refs.scrollbar), ...args);
    },
    update() {
      this.invokeScrollbar("update");
    },
    destroy() {
      this.unbindEvent();
      this.invokeScrollbar("destroy");
    },
    scrollXHandler(event) {
      this.$emit("scroll-x", event);
    },
    scrollYHandler(event) {
      this.$emit("scroll-y", event);
    },
    bindEvent() {
      const scrollbarEl = this.$refs.scrollbar;
      scrollbarEl.addEventListener("ps-scroll-y", this.scrollYHandler);
      scrollbarEl.addEventListener("ps-scroll-x", this.scrollXHandler);
    },
    unbindEvent() {
      const scrollbarEl = this.$refs.scrollbar;
      scrollbarEl.removeEventListener("ps-scroll-y", this.scrollYHandler);
      scrollbarEl.removeEventListener("ps-scroll-x", this.scrollXHandler);
    }
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      ref: "scrollbarWrap",
      class: [_vm.getPrefixedClassName("scrollbar"), _vm.theme]
    },
    [
      _c(
        "div",
        { ref: "scrollbar", class: _vm.getPrefixedClassName("scrollbar-body") },
        [_vm._t("default")],
        2
      ),
      _vm._v(" "),
      _c("div", {
        ref: "scrollbarX",
        class: _vm.getPrefixedClassName("scrollbar-x")
      }),
      _vm._v(" "),
      _c("div", {
        ref: "scrollbarY",
        class: _vm.getPrefixedClassName("scrollbar-y")
      })
    ]
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__ as SfScrollbar };
