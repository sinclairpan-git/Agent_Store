import { componentName } from '@sxf/er-components/_const';
import { vRepeatClick } from '@sxf/er-components/_directives';
import { FormFieldMixin, FormSizeMixin } from '@sxf/er-components/form';
import { getPrefixedClassName } from '@sxf/er-feature';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
var script = {
  name: componentName.inputNumber,
  componentName: componentName.inputNumber,
  directives: {
    repeatClick: vRepeatClick
  },
  mixins: [FormFieldMixin, FormSizeMixin],
  props: {
    value: [Number, String],
    name: {
      type: String
    },
    size: {
      type: String
    },
    disabled: Boolean,
    maxValue: {
      type: Number,
      default: Infinity
    },
    minValue: {
      type: Number,
      default: -Infinity
    },
    controlsPosition: {
      type: String,
      default: ""
    },
    step: {
      type: Number,
      default: 1
    },
    precision: {
      type: Number,
      validator(val) {
        return val >= 0 && val === parseInt(val, 10);
      }
    },
    stepStrictly: {
      type: Boolean,
      default: false
    },
    placeholder: {
      type: String,
      default: ""
    }
  },
  data() {
    return {
      currentValue: 0,
      initValue: null,
      focusing: false
    };
  },
  computed: {
    field() {
      return this.$refs.input;
    },
    bindOptions() {
      return { ...this.validateHintOptions };
    },
    isDisabled() {
      return this.disabled;
    },
    isDecreaseDisabled() {
      return this.isDisabled || this._decrease(this.displayValue, this.step) < this.minValue;
    },
    isIncreaseDisabled() {
      return this.isDisabled || this._increase(this.displayValue, this.step) > this.maxValue;
    },
    prefixIcon() {
      return `iconfont ${this.controlsPosition ? "vtv-icon-arrow-down" : "vtv-icon-ele-minus"}`;
    },
    suffixIcon() {
      return `iconfont ${this.controlsPosition ? "vtv-icon-arrow-up" : "vtv-icon-add"}`;
    },
    numPrecision() {
      const { value, step, getPrecision, precision } = this;
      const stepPrecision = getPrecision(step);
      if (precision !== void 0) {
        return precision;
      } else {
        return Math.max(getPrecision(value), stepPrecision);
      }
    },
    displayValue() {
      if (this.initValue !== null) {
        return this.initValue;
      }
      let currentValue = this.currentValue;
      if (typeof currentValue === "number") {
        if (this.stepStrictly) {
          const stepPrecision = this.getPrecision(this.step);
          const precisionFactor = Math.pow(10, stepPrecision);
          currentValue = Math.round(currentValue / this.step) * precisionFactor * this.step / precisionFactor;
        }
        if (this.precision !== void 0) {
          currentValue = currentValue.toFixed(this.precision);
        }
      }
      return currentValue;
    }
  },
  watch: {
    value: {
      immediate: true,
      handler(value) {
        let newVal = value === void 0 ? value : Number(value);
        if (newVal !== void 0) {
          if (isNaN(newVal)) {
            return;
          }
          if (this.stepStrictly) {
            const stepPrecision = this.getPrecision(this.step);
            const precisionFactor = Math.pow(10, stepPrecision);
            newVal = Math.round(newVal / this.step) * precisionFactor * this.step / precisionFactor;
          }
          if (this.precision !== void 0) {
            newVal = this.toPrecision(newVal, this.precision);
          }
        }
        if (newVal > this.maxValue) {
          newVal = this.maxValue;
        } else if (newVal < this.minValue) {
          newVal = this.minValue;
        }
        this.currentValue = newVal;
        this.initValue = null;
        this.$emit("input", newVal);
      }
    }
  },
  methods: {
    getFullUtid(utidBase) {
      return this.$attrs.utid ? `${this.$attrs.utid}-${utidBase}` : utidBase;
    },
    decrease() {
      if (this.isDecreaseDisabled) {
        return;
      }
      const value = this.value || 0;
      const newVal = this._decrease(value, this.step);
      this.setCurrentValue(newVal);
      this.validate();
    },
    increase() {
      if (this.isIncreaseDisabled) {
        return;
      }
      const value = this.value || 0;
      const newVal = this._increase(value, this.step);
      this.setCurrentValue(newVal);
      this.validate();
    },
    _increase(val, step) {
      if (typeof val !== "number" && val !== void 0) {
        return this.currentValue;
      }
      const precisionFactor = Math.pow(10, this.numPrecision);
      return this.toPrecision((precisionFactor * val + precisionFactor * step) / precisionFactor);
    },
    _decrease(val, step) {
      if (typeof val !== "number" && val !== void 0) {
        return this.currentValue;
      }
      const precisionFactor = Math.pow(10, this.numPrecision);
      return this.toPrecision((precisionFactor * val - precisionFactor * step) / precisionFactor);
    },
    processRule(rule) {
      rule.getFieldValue = () => this.currentValue;
      return rule;
    },
    handleBlur(event) {
      this.validate();
      this.$emit("blur", event);
      this.focusing = false;
    },
    handleFocus(event) {
      this.toggleValidError(this.field);
      this.$emit("focus", event);
      this.focusing = true;
    },
    handleInput(event) {
      var _a, _b;
      const value = (_b = (_a = event == null ? void 0 : event.target) == null ? void 0 : _a.value) != null ? _b : this.currentValue;
      this.initValue = value;
    },
    handleInputChange(event) {
      var _a, _b;
      const value = (_b = (_a = event == null ? void 0 : event.target) == null ? void 0 : _a.value) != null ? _b : this.currentValue;
      const newVal = value === "" ? void 0 : Number(value);
      if (!isNaN(newVal) || value === "") {
        this.setCurrentValue(newVal);
      }
      this.initValue = null;
    },
    handleKeydown(event) {
      if (event.key === "ArrowUp") {
        this.increase();
      } else if (event.key === "ArrowDown") {
        this.decrease();
      }
    },
    toPrecision(num, precision) {
      if (precision === void 0) {
        precision = this.numPrecision;
      }
      return parseFloat(Math.round(num * Math.pow(10, precision)) / Math.pow(10, precision));
    },
    getPrecision(value) {
      if (value === void 0) {
        return 0;
      }
      const valueString = value.toString();
      const dotPosition = valueString.indexOf(".");
      let precision = 0;
      if (dotPosition !== -1) {
        precision = valueString.length - dotPosition - 1;
      }
      return precision;
    },
    onValidate(ret) {
      this.setValidateState(ret);
      this.$emit(ret === true ? "valid" : "invalid", ret);
      this.$nextTick(() => {
        if (this.focusing) {
          this.toggleValidError(this.field);
        }
      });
    },
    clearValidateState() {
      this.setValidateState(true);
    },
    setCurrentValue(newVal) {
      const oldVal = this.currentValue;
      if (typeof newVal === "number" && this.precision !== void 0) {
        newVal = this.toPrecision(newVal, this.precision);
      }
      if (newVal > this.maxValue) {
        newVal = this.maxValue;
      } else if (newVal < this.minValue) {
        newVal = this.minValue;
      }
      if (oldVal === newVal) {
        return;
      }
      this.initValue = null;
      this.$emit("input", newVal);
      this.$emit("change", newVal, oldVal);
      this.currentValue = newVal;
    },
    getValue() {
      return this.currentValue;
    },
    setValue(value) {
      this.setCurrentValue(value);
      this.validate();
    },
    getPrefixedClassName
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _obj, _obj$1;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      class: [
        _vm.getPrefixedClassName("sf-input-number"),
        _vm.getPrefixedClassName("sf-input-number--" + _vm.currentSize),
        _vm.getPrefixedClassName(
          "sf-controls-position--" + _vm.controlsPosition
        )
      ],
      attrs: { utid: "sf-input-number" }
    },
    [
      _c(
        "span",
        {
          directives: [
            {
              name: "repeat-click",
              rawName: "v-repeat-click",
              value: _vm.decrease,
              expression: "decrease"
            }
          ],
          class: [
            _vm.getPrefixedClassName("sf-input-number__left"),
            (_obj = {}, _obj[_vm.getPrefixedClassName("sf-input-number--disabled")] = _vm.isDecreaseDisabled, _obj),
            _vm.getPrefixedClassName(
              "sf-input-number__btn--" + _vm.currentSize
            )
          ],
          attrs: { utid: _vm.getFullUtid("decrease-btn") }
        },
        [_vm._t("prefix", [_c("i", { class: _vm.prefixIcon })])],
        2
      ),
      _vm._v(" "),
      _c(
        "span",
        {
          directives: [
            {
              name: "repeat-click",
              rawName: "v-repeat-click",
              value: _vm.increase,
              expression: "increase"
            }
          ],
          class: [
            _vm.getPrefixedClassName("sf-input-number__right"),
            (_obj$1 = {}, _obj$1[_vm.getPrefixedClassName("sf-input-number--disabled")] = _vm.isIncreaseDisabled, _obj$1),
            _vm.getPrefixedClassName(
              "sf-input-number__btn--" + _vm.currentSize
            )
          ],
          attrs: { utid: _vm.getFullUtid("increase-btn") }
        },
        [_vm._t("suffix", [_c("i", { class: _vm.suffixIcon })])],
        2
      ),
      _vm._v(" "),
      _c(
        "input",
        _vm._b(
          {
            class: [
              _vm.getPrefixedClassName("sf-input-number__inner"),
              _vm.invalidCls,
              _vm.getPrefixedClassName(
                "sf-input-number__inner--" + _vm.currentSize
              )
            ],
            attrs: {
              id: _vm.fieldSelectorID,
              placeholder: _vm.placeholder,
              name: _vm.name,
              utid: _vm.getFullUtid("input-number"),
              "style-key": "input",
              disabled: _vm.isDisabled
            },
            domProps: { value: _vm.displayValue },
            on: {
              focus: _vm.handleFocus,
              input: _vm.handleInput,
              blur: _vm.handleBlur,
              change: _vm.handleInputChange,
              keydown: _vm.handleKeydown
            }
          },
          "input",
          _vm.bindOptions,
          false
        )
      )
    ]
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__ as SfInputNumber };
