import { VNode } from 'vue';

export interface SfInputNumberProps<T = string | number> {
  value: T;
  name: string;
  size: string;
  disabled: boolean;
  maxValue: number;
  minValue: number;
  controlsPosition: string;
  step: number;
  precision: number;
  stepStrictly: boolean;
  placeholder: string;
}

export interface SfInputNumberSlots {
  $slots: {
    prefix?: VNode[];
    suffix?: VNode[];
  };
}

export interface SfInputNumberEvents<T = string | number> {
  $emit(eventName: 'focus', event: FocusEvent): this;
  $emit(eventName: 'blur', event: UIEvent): this;
  $emit(eventName: 'input', value: T): this;
  $emit(eventName: 'change', value: T): this;
}

export interface SfInputNumberMethods {
  getValue: () => void;
  setValue: () => void;
}

export declare type SfInputNumber<T = string | number> = Readonly<
  SfInputNumberProps<T> & SfInputNumberSlots & SfInputNumberMethods
> &
  Vue;
