import $ from 'jquery';
import { componentName } from '@sxf/er-components/_const';
import { isPropEnabled } from '@sxf/er-components/_utils/vue-utils';
import { SfFlex, SfFlexItem } from '@sxf/er-components/flex';
import { getPrefixedClassName } from '@sxf/er-feature';
const fn = function() {
  return function e(t, n, r) {
    function s(o2, u) {
      if (!n[o2]) {
        if (!t[o2]) {
          var a = typeof require == "function" && require;
          if (!u && a)
            return a(o2, true);
          if (i)
            return i(o2, true);
          var f = new Error("Cannot find module '" + o2 + "'");
          throw f.code = "MODULE_NOT_FOUND", f;
        }
        var l = n[o2] = { exports: {} };
        t[o2][0].call(
          l.exports,
          function(e2) {
            var n2 = t[o2][1][e2];
            return s(n2 ? n2 : e2);
          },
          l,
          l.exports,
          e,
          t,
          n,
          r
        );
      }
      return n[o2].exports;
    }
    var i = typeof require == "function" && require;
    for (var o = 0; o < r.length; o++)
      s(r[o]);
    return s;
  }(
    {
      1: [
        function(req, module, exports) {
          var cache = {};
          var start = "(?:^|\\s)";
          var end = "(?:\\s|$)";
          function lookupClass(className) {
            var cached = cache[className];
            if (cached) {
              cached.lastIndex = 0;
            } else {
              cache[className] = cached = new RegExp(start + className + end, "g");
            }
            return cached;
          }
          function addClass(el, className) {
            var current = el.className;
            if (!current.length) {
              el.className = className;
            } else if (!lookupClass(className).test(current)) {
              el.className += " " + className;
            }
          }
          function rmClass(el, className) {
            el.className = el.className.replace(lookupClass(className), " ").trim();
          }
          module.exports = {
            add: addClass,
            rm: rmClass
          };
        },
        {}
      ],
      2: [
        function(req, module, exports) {
          (function(global2) {
            var emitter = req("contra/emitter");
            var crossvent = req("crossvent");
            var classes = req("./classes");
            var doc = document;
            var documentElement = doc.documentElement;
            function dragula(initialContainers, options) {
              var len = arguments.length;
              if (len === 1 && Array.isArray(initialContainers) === false) {
                options = initialContainers;
                initialContainers = [];
              }
              var _mirror;
              var _source;
              var _item;
              var _offsetX;
              var _offsetY;
              var _moveX;
              var _moveY;
              var _initialSibling;
              var _currentSibling;
              var _copy;
              var _renderTimer;
              var _lastDropTarget = null;
              var _grabbed;
              var o = options || {};
              if (o.moves === void 0) {
                o.moves = always;
              }
              if (o.accepts === void 0) {
                o.accepts = always;
              }
              if (o.invalid === void 0) {
                o.invalid = invalidTarget;
              }
              if (o.beforeRelease === void 0) {
                o.beforeRelease = always();
              }
              if (o.containers === void 0) {
                o.containers = initialContainers || [];
              }
              if (o.isContainer === void 0) {
                o.isContainer = never;
              }
              if (o.copy === void 0) {
                o.copy = false;
              }
              if (o.copySortSource === void 0) {
                o.copySortSource = false;
              }
              if (o.revertOnSpill === void 0) {
                o.revertOnSpill = false;
              }
              if (o.removeOnSpill === void 0) {
                o.removeOnSpill = false;
              }
              if (o.direction === void 0) {
                o.direction = "vertical";
              }
              if (o.ignoreInputTextSelection === void 0) {
                o.ignoreInputTextSelection = true;
              }
              if (o.mirrorContainer === void 0) {
                o.mirrorContainer = doc.body;
              }
              var drake = emitter({
                containers: o.containers,
                start: manualStart,
                end,
                cancel,
                remove,
                destroy,
                canMove,
                dragging: false
              });
              drake.options = o;
              if (o.removeOnSpill === true) {
                drake.on("over", spillOver).on("out", spillOut);
              }
              events();
              return drake;
              function isContainer(el) {
                return drake.containers.indexOf(el) !== -1 || o.isContainer(el);
              }
              function events(remove2) {
                var op = remove2 ? "remove" : "add";
                touchy(documentElement, op, "mousedown", grab);
                touchy(documentElement, op, "mouseup", release);
              }
              function eventualMovements(remove2) {
                var op = remove2 ? "remove" : "add";
                touchy(documentElement, op, "mousemove", startBecauseMouseMoved);
              }
              function movements(remove2) {
                var op = remove2 ? "remove" : "add";
                crossvent[op](documentElement, "selectstart", preventGrabbed);
                crossvent[op](documentElement, "click", preventGrabbed);
              }
              function destroy() {
                events(true);
                release({});
              }
              function preventGrabbed(e) {
                if (_grabbed) {
                  e.preventDefault();
                }
              }
              function grab(e) {
                _moveX = e.clientX;
                _moveY = e.clientY;
                var ignore = whichMouseButton(e) !== 1 || e.metaKey || e.ctrlKey;
                if (ignore) {
                  return;
                }
                var item = e.target;
                var context = canStart(item);
                if (!context) {
                  return;
                }
                _grabbed = context;
                eventualMovements();
                if (e.type === "mousedown") {
                  if (isInput(item)) {
                    item.focus();
                  } else {
                    e.preventDefault();
                  }
                }
              }
              function startBecauseMouseMoved(e) {
                if (!_grabbed) {
                  return;
                }
                if (whichMouseButton(e) === 0) {
                  release({});
                  return;
                }
                if (e.clientX !== void 0 && e.clientX === _moveX && e.clientY !== void 0 && e.clientY === _moveY) {
                  return;
                }
                if (o.ignoreInputTextSelection) {
                  var clientX = getCoord("clientX", e);
                  var clientY = getCoord("clientY", e);
                  var elementBehindCursor = doc.elementFromPoint(clientX, clientY);
                  if (isInput(elementBehindCursor)) {
                    return;
                  }
                }
                var grabbed = _grabbed;
                eventualMovements(true);
                movements();
                end();
                start(grabbed);
                var offset = getOffset(_item);
                _offsetX = getCoord("pageX", e) - offset.left;
                _offsetY = getCoord("pageY", e) - offset.top;
                classes.add(_copy || _item, "gu-transit");
                renderMirrorImage();
                drag(e);
              }
              function canStart(item) {
                if (drake.dragging && _mirror) {
                  return;
                }
                if (isContainer(item)) {
                  return;
                }
                var handle = item;
                while (getParent(item) && isContainer(getParent(item)) === false) {
                  if (o.invalid(item, handle)) {
                    return;
                  }
                  item = getParent(item);
                  if (!item) {
                    return;
                  }
                }
                var source = getParent(item);
                if (!source) {
                  return;
                }
                if (o.invalid(item, handle)) {
                  return;
                }
                var movable = o.moves(item, source, handle, nextEl(item));
                if (!movable) {
                  return;
                }
                return {
                  item,
                  source
                };
              }
              function canMove(item) {
                return !!canStart(item);
              }
              function manualStart(item) {
                var context = canStart(item);
                if (context) {
                  start(context);
                }
              }
              function start(context) {
                if (isCopy(context.item, context.source)) {
                  _copy = context.item.cloneNode(true);
                  drake.emit("cloned", _copy, context.item, "copy");
                }
                _source = context.source;
                _item = context.item;
                _initialSibling = _currentSibling = nextEl(context.item);
                drake.dragging = true;
                drake.emit("drag", _item, _source);
              }
              function invalidTarget() {
                return false;
              }
              function end() {
                if (!drake.dragging) {
                  return;
                }
                var item = _copy || _item;
                drop(item, getParent(item));
              }
              function ungrab() {
                _grabbed = false;
                eventualMovements(true);
                movements(true);
              }
              function release(e) {
                ungrab();
                if (!drake.dragging) {
                  return;
                }
                var item = _copy || _item;
                var clientX = getCoord("clientX", e);
                var clientY = getCoord("clientY", e);
                var elementBehindCursor = getElementBehindPoint(_mirror, clientX, clientY);
                var dropTarget = findDropTarget(elementBehindCursor, clientX, clientY);
                if (o.beforeRelease(item, dropTarget, _source) === false) {
                  cancel(true);
                  return;
                }
                if (dropTarget && (_copy && o.copySortSource || !_copy || dropTarget !== _source)) {
                  drop(item, dropTarget);
                } else if (o.removeOnSpill) {
                  remove();
                } else {
                  cancel();
                }
              }
              function drop(item, target) {
                var parent = getParent(item);
                if (_copy && o.copySortSource && target === _source) {
                  parent.removeChild(_item);
                }
                if (isInitialPlacement(target)) {
                  drake.emit("cancel", item, _source, _source);
                } else {
                  drake.emit("drop", item, target, _source, _currentSibling);
                }
                cleanup();
              }
              function remove() {
                if (!drake.dragging) {
                  return;
                }
                var item = _copy || _item;
                var parent = getParent(item);
                if (parent) {
                  parent.removeChild(item);
                }
                drake.emit(_copy ? "cancel" : "remove", item, parent, _source);
                cleanup();
              }
              function cancel(revert) {
                if (!drake.dragging) {
                  return;
                }
                var reverts = arguments.length > 0 ? revert : o.revertOnSpill;
                var item = _copy || _item;
                var parent = getParent(item);
                var initial = isInitialPlacement(parent);
                if (initial === false && reverts) {
                  if (_copy) {
                    if (parent) {
                      parent.removeChild(_copy);
                    }
                  } else {
                    _source.insertBefore(item, _initialSibling);
                  }
                }
                if (initial || reverts) {
                  drake.emit("cancel", item, _source, _source);
                } else {
                  drake.emit("drop", item, parent, _source, _currentSibling);
                }
                cleanup();
              }
              function cleanup() {
                var item = _copy || _item;
                ungrab();
                removeMirrorImage();
                if (item) {
                  classes.rm(item, "gu-transit");
                }
                if (_renderTimer) {
                  clearTimeout(_renderTimer);
                }
                drake.dragging = false;
                if (_lastDropTarget) {
                  drake.emit("out", item, _lastDropTarget, _source);
                }
                drake.emit("dragend", item);
                _source = _item = _copy = _initialSibling = _currentSibling = _renderTimer = _lastDropTarget = null;
              }
              function isInitialPlacement(target, s) {
                var sibling;
                if (s !== void 0) {
                  sibling = s;
                } else if (_mirror) {
                  sibling = _currentSibling;
                } else {
                  sibling = nextEl(_copy || _item);
                }
                return target === _source && sibling === _initialSibling;
              }
              function findDropTarget(elementBehindCursor, clientX, clientY) {
                var target = elementBehindCursor;
                while (target && !accepted()) {
                  target = getParent(target);
                }
                return target;
                function accepted() {
                  var droppable = isContainer(target);
                  if (droppable === false) {
                    return false;
                  }
                  var immediate = getImmediateChild(target, elementBehindCursor);
                  var reference = getReference(target, immediate, clientX, clientY);
                  var initial = isInitialPlacement(target, reference);
                  if (initial) {
                    return true;
                  }
                  return o.accepts(_item, target, _source, reference);
                }
              }
              function drag(e) {
                if (!_mirror) {
                  return;
                }
                e.preventDefault();
                var clientX = getCoord("clientX", e);
                var clientY = getCoord("clientY", e);
                var x = clientX - _offsetX;
                var y = clientY - _offsetY;
                _mirror.style.left = x + "px";
                _mirror.style.top = y + "px";
                var item = _copy || _item;
                var elementBehindCursor = getElementBehindPoint(_mirror, clientX, clientY);
                var dropTarget = findDropTarget(elementBehindCursor, clientX, clientY);
                var changed = dropTarget !== null && dropTarget !== _lastDropTarget;
                if (changed || dropTarget === null) {
                  out();
                  _lastDropTarget = dropTarget;
                  over();
                }
                var parent = getParent(item);
                if (dropTarget === _source && _copy && !o.copySortSource) {
                  if (parent) {
                    parent.removeChild(item);
                  }
                  return;
                }
                var reference;
                var immediate = getImmediateChild(dropTarget, elementBehindCursor);
                if (immediate !== null) {
                  reference = getReference(dropTarget, immediate, clientX, clientY);
                } else if (o.revertOnSpill === true && !_copy) {
                  reference = _initialSibling;
                  dropTarget = _source;
                } else {
                  if (_copy && parent) {
                    parent.removeChild(item);
                  }
                  return;
                }
                if (reference === null && changed || reference !== item && reference !== nextEl(item)) {
                  _currentSibling = reference;
                  dropTarget.insertBefore(item, reference);
                  drake.emit("shadow", item, dropTarget, _source);
                }
                function moved(type) {
                  drake.emit(type, item, _lastDropTarget, _source);
                }
                function over() {
                  if (changed) {
                    moved("over");
                  }
                }
                function out() {
                  if (_lastDropTarget) {
                    moved("out");
                  }
                }
              }
              function spillOver(el) {
                classes.rm(el, "gu-hide");
              }
              function spillOut(el) {
                if (drake.dragging) {
                  classes.add(el, "gu-hide");
                }
              }
              function renderMirrorImage() {
                if (_mirror) {
                  return;
                }
                var rect = _item.getBoundingClientRect();
                _mirror = _item.cloneNode(true);
                _mirror.style.width = getRectWidth(rect) + "px";
                _mirror.style.height = getRectHeight(rect) + "px";
                classes.rm(_mirror, "gu-transit");
                classes.add(_mirror, "gu-mirror");
                o.mirrorContainer.appendChild(_mirror);
                touchy(documentElement, "add", "mousemove", drag);
                classes.add(o.mirrorContainer, "gu-unselectable");
                drake.emit("cloned", _mirror, _item, "mirror");
              }
              function removeMirrorImage() {
                if (_mirror) {
                  classes.rm(o.mirrorContainer, "gu-unselectable");
                  touchy(documentElement, "remove", "mousemove", drag);
                  getParent(_mirror).removeChild(_mirror);
                  _mirror = null;
                }
              }
              function getImmediateChild(dropTarget, target) {
                var immediate = target;
                while (immediate !== dropTarget && getParent(immediate) !== dropTarget) {
                  immediate = getParent(immediate);
                }
                if (immediate === documentElement) {
                  return null;
                }
                return immediate;
              }
              function getReference(dropTarget, target, x, y) {
                var horizontal = o.direction === "horizontal";
                var reference = target !== dropTarget ? inside() : outside();
                return reference;
                function outside() {
                  var len2 = dropTarget.children.length;
                  var i;
                  var el;
                  var rect;
                  for (i = 0; i < len2; i++) {
                    el = dropTarget.children[i];
                    rect = el.getBoundingClientRect();
                    if (horizontal && rect.left + rect.width / 2 > x) {
                      return el;
                    }
                    if (!horizontal && rect.top + rect.height / 2 > y) {
                      return el;
                    }
                  }
                  return null;
                }
                function inside() {
                  var rect = target.getBoundingClientRect();
                  if (horizontal) {
                    return resolve(x > rect.left + getRectWidth(rect) / 2);
                  }
                  return resolve(y > rect.top + getRectHeight(rect) / 2);
                }
                function resolve(after) {
                  return after ? nextEl(target) : target;
                }
              }
              function isCopy(item, container) {
                return typeof o.copy === "boolean" ? o.copy : o.copy(item, container);
              }
            }
            function touchy(el, op, type, fn2) {
              var touch = {
                mouseup: "touchend",
                mousedown: "touchstart",
                mousemove: "touchmove"
              };
              var pointers = {
                mouseup: "pointerup",
                mousedown: "pointerdown",
                mousemove: "pointermove"
              };
              var microsoft = {
                mouseup: "MSPointerUp",
                mousedown: "MSPointerDown",
                mousemove: "MSPointerMove"
              };
              if (global2.navigator.pointerEnabled) {
                crossvent[op](el, pointers[type], fn2);
              } else if (global2.navigator.msPointerEnabled) {
                crossvent[op](el, microsoft[type], fn2);
              } else {
                crossvent[op](el, touch[type], fn2);
                crossvent[op](el, type, fn2);
              }
            }
            function whichMouseButton(e) {
              if (e.touches !== void 0) {
                return e.touches.length;
              }
              if (e.which !== void 0 && e.which !== 0) {
                return e.which;
              }
              if (e.buttons !== void 0) {
                return e.buttons;
              }
              var button = e.button;
              if (button !== void 0) {
                return button & 1 ? 1 : button & 2 ? 3 : button & 4 ? 2 : 0;
              }
            }
            function getOffset(el) {
              var rect = el.getBoundingClientRect();
              return {
                left: rect.left + getScroll("scrollLeft", "pageXOffset"),
                top: rect.top + getScroll("scrollTop", "pageYOffset")
              };
            }
            function getScroll(scrollProp, offsetProp) {
              if (typeof global2[offsetProp] !== "undefined") {
                return global2[offsetProp];
              }
              if (documentElement.clientHeight) {
                return documentElement[scrollProp];
              }
              return doc.body[scrollProp];
            }
            function getElementBehindPoint(point, x, y) {
              var p = point || {};
              var state = p.className;
              var el;
              p.className += " gu-hide";
              el = doc.elementFromPoint(x, y);
              p.className = state;
              return el;
            }
            function never() {
              return false;
            }
            function always() {
              return true;
            }
            function getRectWidth(rect) {
              return rect.width || rect.right - rect.left;
            }
            function getRectHeight(rect) {
              return rect.height || rect.bottom - rect.top;
            }
            function getParent(el) {
              return el.parentNode === doc ? null : el.parentNode;
            }
            function isInput(el) {
              return el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.tagName === "SELECT" || isEditable(el);
            }
            function isEditable(el) {
              if (!el) {
                return false;
              }
              if (el.contentEditable === "false") {
                return false;
              }
              if (el.contentEditable === "true") {
                return true;
              }
              return isEditable(getParent(el));
            }
            function nextEl(el) {
              return el.nextElementSibling || manually();
              function manually() {
                var sibling = el;
                do {
                  sibling = sibling.nextSibling;
                } while (sibling && sibling.nodeType !== 1);
                return sibling;
              }
            }
            function getEventHost(e) {
              if (e.targetTouches && e.targetTouches.length) {
                return e.targetTouches[0];
              }
              if (e.changedTouches && e.changedTouches.length) {
                return e.changedTouches[0];
              }
              return e;
            }
            function getCoord(coord, e) {
              var host = getEventHost(e);
              var missMap = {
                pageX: "clientX",
                pageY: "clientY"
              };
              if (coord in missMap && !(coord in host) && missMap[coord] in host) {
                coord = missMap[coord];
              }
              return host[coord];
            }
            module.exports = dragula;
          }).call(
            this,
            typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {}
          );
        },
        { "./classes": 1, "contra/emitter": 5, crossvent: 6 }
      ],
      3: [
        function(req, module, exports) {
          module.exports = function atoa(a, n) {
            return Array.prototype.slice.call(a, n);
          };
        },
        {}
      ],
      4: [
        function(req, module, exports) {
          var ticky = req("ticky");
          module.exports = function debounce(fn2, args, ctx) {
            if (!fn2) {
              return;
            }
            ticky(function run() {
              fn2.apply(ctx || null, args || []);
            });
          };
        },
        { ticky: 9 }
      ],
      5: [
        function(req, module, exports) {
          var atoa = req("atoa");
          var debounce = req("./debounce");
          module.exports = function emitter(thing, options) {
            var opts = options || {};
            var evt = {};
            if (thing === void 0) {
              thing = {};
            }
            thing.on = function(type, fn2) {
              if (!evt[type]) {
                evt[type] = [fn2];
              } else {
                evt[type].push(fn2);
              }
              return thing;
            };
            thing.once = function(type, fn2) {
              fn2._once = true;
              thing.on(type, fn2);
              return thing;
            };
            thing.off = function(type, fn2) {
              var c = arguments.length;
              if (c === 1) {
                delete evt[type];
              } else if (c === 0) {
                evt = {};
              } else {
                var et = evt[type];
                if (!et) {
                  return thing;
                }
                et.splice(et.indexOf(fn2), 1);
              }
              return thing;
            };
            thing.emit = function() {
              var args = atoa(arguments);
              return thing.emitterSnapshot(args.shift()).apply(this, args);
            };
            thing.emitterSnapshot = function(type) {
              var et = (evt[type] || []).slice(0);
              return function() {
                var args = atoa(arguments);
                var ctx = this || thing;
                if (type === "error" && opts.throws !== false && !et.length) {
                  throw args.length === 1 ? args[0] : args;
                }
                et.forEach(function emitter2(listen) {
                  if (opts.async) {
                    debounce(listen, args, ctx);
                  } else {
                    listen.apply(ctx, args);
                  }
                  if (listen._once) {
                    thing.off(type, listen);
                  }
                });
                return thing;
              };
            };
            return thing;
          };
        },
        { "./debounce": 4, atoa: 3 }
      ],
      6: [
        function(req, module, exports) {
          (function(global2) {
            var customEvent = req("custom-event");
            var eventmap = req("./eventmap");
            var doc = global2.document;
            var addEvent = addEventEasy;
            var removeEvent = removeEventEasy;
            var hardCache = [];
            if (!global2.addEventListener) {
              addEvent = addEventHard;
              removeEvent = removeEventHard;
            }
            module.exports = {
              add: addEvent,
              remove: removeEvent,
              fabricate: fabricateEvent
            };
            function addEventEasy(el, type, fn2, capturing) {
              return el.addEventListener(type, fn2, capturing);
            }
            function addEventHard(el, type, fn2) {
              return el.attachEvent("on" + type, wrap(el, type, fn2));
            }
            function removeEventEasy(el, type, fn2, capturing) {
              return el.removeEventListener(type, fn2, capturing);
            }
            function removeEventHard(el, type, fn2) {
              var listener = unwrap(el, type, fn2);
              if (listener) {
                return el.detachEvent("on" + type, listener);
              }
            }
            function fabricateEvent(el, type, model) {
              var e = eventmap.indexOf(type) === -1 ? makeCustomEvent() : makeClassicEvent();
              if (el.dispatchEvent) {
                el.dispatchEvent(e);
              } else {
                el.fireEvent("on" + type, e);
              }
              function makeClassicEvent() {
                var e2;
                if (doc.createEvent) {
                  e2 = doc.createEvent("Event");
                  e2.initEvent(type, true, true);
                } else if (doc.createEventObject) {
                  e2 = doc.createEventObject();
                }
                return e2;
              }
              function makeCustomEvent() {
                return new customEvent(type, { detail: model });
              }
            }
            function wrapperFactory(el, type, fn2) {
              return function wrapper(originalEvent) {
                var e = originalEvent || global2.event;
                e.target = e.target || e.srcElement;
                e.preventDefault = e.preventDefault || function preventDefault() {
                  e.returnValue = false;
                };
                e.stopPropagation = e.stopPropagation || function stopPropagation() {
                  e.cancelBubble = true;
                };
                e.which = e.which || e.keyCode;
                fn2.call(el, e);
              };
            }
            function wrap(el, type, fn2) {
              var wrapper = unwrap(el, type, fn2) || wrapperFactory(el, type, fn2);
              hardCache.push({
                wrapper,
                element: el,
                type,
                fn: fn2
              });
              return wrapper;
            }
            function unwrap(el, type, fn2) {
              var i = find(el, type, fn2);
              if (i) {
                var wrapper = hardCache[i].wrapper;
                hardCache.splice(i, 1);
                return wrapper;
              }
            }
            function find(el, type, fn2) {
              var i, item;
              for (i = 0; i < hardCache.length; i++) {
                item = hardCache[i];
                if (item.element === el && item.type === type && item.fn === fn2) {
                  return i;
                }
              }
            }
          }).call(
            this,
            typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {}
          );
        },
        { "./eventmap": 7, "custom-event": 8 }
      ],
      7: [
        function(req, module, exports) {
          (function(global2) {
            var eventmap = [];
            var eventname = "";
            var ron = /^on/;
            for (eventname in global2) {
              if (ron.test(eventname)) {
                eventmap.push(eventname.slice(2));
              }
            }
            module.exports = eventmap;
          }).call(
            this,
            typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {}
          );
        },
        {}
      ],
      8: [
        function(req, module, exports) {
          (function(global2) {
            var NativeCustomEvent = global2.CustomEvent;
            function useNative() {
              try {
                var p = new NativeCustomEvent("cat", { detail: { foo: "bar" } });
                return "cat" === p.type && "bar" === p.detail.foo;
              } catch (e) {
              }
              return false;
            }
            module.exports = useNative() ? NativeCustomEvent : "function" === typeof document.createEvent ? function CustomEvent(type, params) {
              var e = document.createEvent("CustomEvent");
              if (params) {
                e.initCustomEvent(type, params.bubbles, params.cancelable, params.detail);
              } else {
                e.initCustomEvent(type, false, false, void 0);
              }
              return e;
            } : function CustomEvent(type, params) {
              var e = document.createEventObject();
              e.type = type;
              if (params) {
                e.bubbles = Boolean(params.bubbles);
                e.cancelable = Boolean(params.cancelable);
                e.detail = params.detail;
              } else {
                e.bubbles = false;
                e.cancelable = false;
                e.detail = void 0;
              }
              return e;
            };
          }).call(
            this,
            typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {}
          );
        },
        {}
      ],
      9: [
        function(req, module, exports) {
          var si = typeof setImmediate === "function", tick;
          if (si) {
            tick = function(fn2) {
              setImmediate(fn2);
            };
          } else {
            tick = function(fn2) {
              setTimeout(fn2, 0);
            };
          }
          module.exports = tick;
        },
        {}
      ]
    },
    {},
    [2]
  )(2);
};
const Dragula = fn();
function createList(data) {
  return data.map((value) => ({
    value
  }));
}
function getSlot(component) {
  return component.$slots.default || component.$scopedSlots.default;
}
function parseSlot(slot, data) {
  if (!slot) {
    return null;
  }
  return typeof slot === "function" ? slot(data) : slot;
}
const EVENT_ID = Math.random().toString(32).replace(/\D/g, "");
var Drag = {
  name: componentName.drag,
  componentName: componentName.drag,
  props: $.extend(true, {}, SfFlex.props, {
    data: {
      required: true,
      type: Array
    },
    name: {},
    noReserveDom: {},
    flexDirection: {
      default: "column"
    },
    flex: {
      default: "none"
    },
    beforeDrag: {
      type: Function,
      default: $.noop
    },
    beforeDrop: {
      type: Function,
      default: $.noop
    },
    removeOnSpill: {}
  }),
  data() {
    return {
      list: createList(this.data)
    };
  },
  computed: {
    isNoReserveDom() {
      return isPropEnabled(this.noReserveDom);
    },
    isRemoveOnSpill() {
      return isPropEnabled(this.removeOnSpill);
    },
    direction() {
      return this.flexDirection !== "column" && this.flexDirection !== "column-reverse" ? "horizontal" : "vertical";
    }
  },
  watch: {
    data(arr, oldArr) {
      if (arr !== oldArr) {
        this.list = createList(this.data);
      } else {
        const list = [];
        const valueList = this.list.map((item) => item.value);
        arr.forEach((value, index) => {
          const valueIndex = valueList.indexOf(value);
          if (valueIndex < 0) {
            list[index] = {
              value
            };
          } else {
            list[index] = this.list[valueIndex];
          }
        });
        this.list = list;
      }
    }
  },
  created() {
    this.siblings = [];
    if (this.name) {
      this.eventName = `drag:${this.name}:${EVENT_ID}`;
      this.$vnode.context.$emit(this.eventName, this);
      this.siblingsEventHandler = (component) => {
        if (component.$options.componentName !== componentName.drag) {
          return;
        }
        this.register(component);
        component.register(this);
      };
      this.$vnode.context.$on(this.eventName, this.siblingsEventHandler);
    }
  },
  render(createElem) {
    return createElem(
      SfFlex,
      {
        class: getPrefixedClassName("sf-drag"),
        props: this.$props,
        ref: "flex"
      },
      this.list.map((item, index) => {
        const slotData = {
          value: item.value,
          index,
          data: this.data
        };
        const slot = item.slot ? item.slot : getSlot(this);
        return createElem(
          SfFlexItem,
          {
            class: getPrefixedClassName("sf-drag_item"),
            props: {
              flex: this.flex
            }
          },
          [parseSlot(slot, slotData)]
        );
      })
    );
  },
  mounted() {
    this.container = this.$refs.flex.$refs.inner;
    if (!this.drake) {
      for (let i = 0; i < this.siblings.length; i++) {
        const component = this.siblings[i];
        if (component.drake) {
          this.drake = component.drake;
          this.drake.containers.push(this.container);
          break;
        }
      }
    }
    if (this.drake) {
      return;
    }
    let indexFrom = -1;
    const drakeOptions = {
      beforeRelease: (el, target, source) => {
        const sourceComponent = this.findComponentByElem(source);
        if (!target) {
          sourceComponent.$emit("spill", {
            index: indexFrom,
            value: sourceComponent.data[indexFrom],
            data: sourceComponent.data
          });
          if (sourceComponent.isRemoveOnSpill) {
            sourceComponent.removeData(indexFrom);
          }
          return false;
        }
        const indexTo = $.makeArray(target.children).indexOf(el);
        const targetComponent = this.findComponentByElem(target);
        const eventData = {
          from: indexFrom,
          to: indexTo,
          value: sourceComponent.data[indexFrom],
          data: sourceComponent.data
        };
        const canDrop = this.beforeDrop(eventData) !== false;
        if (canDrop && targetComponent && sourceComponent) {
          const item = sourceComponent.removeData(indexFrom);
          targetComponent.insertData(sourceComponent, item, indexTo);
          this.$emit(
            "drop",
            $.extend({}, eventData, {
              changed: sourceComponent !== targetComponent || indexFrom !== indexTo
            })
          );
        }
        this.drake.cancel(true);
        return false;
      },
      moves: (item, source, eventTarget) => {
        const sourceComponent = this.findComponentByElem(source);
        indexFrom = $(eventTarget).closest(".sf-drag_item").index();
        return indexFrom >= 0 && this.beforeDrag({
          from: indexFrom,
          value: sourceComponent.data[indexFrom],
          data: sourceComponent.data,
          target: eventTarget
        }) !== false;
      }
    };
    this.drake = Dragula([this.container], drakeOptions);
    this.drake.on("dragend", () => {
      indexFrom = -1;
    });
  },
  methods: {
    register(component) {
      if (component.$options.componentName !== componentName.drag || this.siblings.indexOf(component) >= 0 || component === this) {
        return;
      }
      this.siblings.push(component);
    },
    unregister(component) {
      const index = this.siblings.indexOf(component);
      if (index < 0 || component === this) {
        return;
      }
      this.siblings.splice(index, 1);
    },
    removeData(index) {
      this.data.splice(index, 1);
      return this.list.splice(index, 1)[0];
    },
    insertData(component, sourceItem, indexTo) {
      this.data.splice(indexTo, 0, sourceItem.value);
      const item = {
        value: sourceItem.value
      };
      if (component !== this && !this.isNoReserveDom) {
        item.slot = sourceItem.slot || getSlot(component);
      }
      this.list.splice(indexTo, 0, item);
    },
    findComponentByElem(elem) {
      if (this.container === elem) {
        return this;
      }
      return this.siblings.filter((component) => {
        return component.container === elem;
      })[0];
    }
  },
  beforeDestroy() {
    if (this.eventName) {
      this.$vnode.context.$off(this.eventName, this.siblingsEventHandler);
    }
    if (!this.siblings.length) {
      this.drake.destroy();
      return;
    }
    const containers = this.drake.containers;
    const index = containers.indexOf(this.container);
    if (index >= 0) {
      this.drake.containers.splice(index, 1);
    }
    this.siblings.forEach((component) => {
      component.unregister(this);
    });
    this.siblings = [];
  }
};
export { Drag as SfDrag };
