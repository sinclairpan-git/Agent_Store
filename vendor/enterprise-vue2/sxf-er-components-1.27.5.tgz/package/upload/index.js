import { componentName } from '@sxf/er-components/_const';
import $ from 'jquery';
import { SfButton } from '@sxf/er-components/button';
import { SfProgress } from '@sxf/er-components/progress';
import { $i } from '@sxf/er-config';
import { getPrefixedClassName } from '@sxf/er-feature';
import { throttle } from '@sxf/er-utils/delay';
import format from '@sxf/er-utils/format';
import numberic from '@sxf/er-utils/numberic';
import uuid from '@sxf/er-utils/uuid';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
import { isFunction as isFunction$1 } from 'lodash-es';
import notify from '@sxf/er-widget/notify';
import require$$1 from 'vue';
import { sleep, clearSleep } from '@sxf/er-utils/timer';
var Color = { "--color-belarus-green-l70": "#edfcf2", "--color-belarus-green-l60": "#daf2e2", "--color-belarus-green-l50": "#c2f2d2", "--color-belarus-green-l40": "#8debac", "--color-belarus-green-l30": "#7ee5a1", "--color-belarus-green-l20": "#6cd990", "--color-belarus-green-l10": "#6c8", "--color-belarus-green": "#50b371", "--color-belarus-green-d10": "#3d995c", "--color-belarus-green-d20": "#2d8048", "--color-graphite-black-l70": "#637a99", "--color-graphite-black-l60": "#596a80", "--color-graphite-black-l50": "#505f73", "--color-graphite-black-l40": "#475466", "--color-graphite-black-l30": "#3e4a59", "--color-graphite-black-l20": "#36404d", "--color-graphite-black-l10": "#2d3540", "--color-graphite-black": "#242a33", "--color-graphite-black-d10": "#1b2026", "--color-graphite-black-d20": "#12161a", "--color-poseidon-blue-l70": "#f5f9ff", "--color-poseidon-blue-l60": "#e6f1ff", "--color-poseidon-blue-l50": "#c2d7f2", "--color-poseidon-blue-l40": "#91bbf2", "--color-poseidon-blue-l30": "#61a0f2", "--color-poseidon-blue-l20": "#197dff", "--color-poseidon-blue-l10": "#1876f2", "--color-poseidon-blue": "#1770e6", "--color-poseidon-blue-d10": "#156ad9", "--color-poseidon-blue-d20": "#1464cc", "--color-poseidon-blue-d30": "#1258b2", "--color-poseidon-blue-d40": "#0f458c", "--color-poseidon-blue-d50": "#0e458c", "--color-poseidon-blue-d60": "#0d3e80", "--color-sky-blue-l70": "#f5f9ff", "--color-sky-blue-l60": "#e6f1ff", "--color-sky-blue-l50": "#c2d7f2", "--color-sky-blue-l40": "#91bbf2", "--color-sky-blue-l30": "#61a0f2", "--color-sky-blue-l20": "#197dff", "--color-sky-blue-l10": "#1876f2", "--color-sky-blue": "#1770e6", "--color-sky-blue-d10": "#156ad9", "--color-sky-blue-d20": "#1464cc", "--color-sky-blue-d30": "#1258b2", "--color-sky-blue-d40": "#0f458c", "--color-sky-blue-d50": "#0e458c", "--color-sky-blue-d60": "#0d3e80", "--color-grass-green-l70": "#edfcf2", "--color-grass-green-l60": "#daf2e2", "--color-grass-green-l50": "#b8e6c7", "--color-grass-green-l40": "#8ae6a8", "--color-grass-green-l30": "#82d99f", "--color-grass-green-l20": "#73e699", "--color-grass-green-l10": "#6c8", "--color-grass-green": "#50b371", "--color-grass-green-d10": "#3d995c", "--color-grass-green-d20": "#2d8048", "--color-gray-l60": "#fff", "--color-gray-l50": "#f9f9f9", "--color-gray-l40": "#f6f6f6", "--color-gray-l30": "#f3f3f3", "--color-gray-l20": "#eee", "--color-gray-l10": "#ddd", "--color-gray": "#ccc", "--color-gray-d10": "#bbb", "--color-gray-d20": "#aaa", "--color-gray-d30": "#999", "--color-gray-d40": "#666", "--color-gray-d50": "#333", "--color-gray-d60": "#000", "--color-golden-yellow-l70": "#fff5e6", "--color-golden-yellow-l60": "#ffdfb3", "--color-golden-yellow-l50": "#ffca80", "--color-golden-yellow-l40": "#ffbf66", "--color-golden-yellow-l30": "#ffb54d", "--color-golden-yellow-l20": "#fa3", "--color-golden-yellow-l10": "#ffa019", "--color-golden-yellow": "#ff9500", "--color-golden-yellow-d10": "#e0870b", "--color-golden-yellow-d20": "#c70", "--color-lemon-yellow-l70": "#fffce6", "--color-lemon-yellow-l60": "#fff5b3", "--color-lemon-yellow-l50": "#ffee80", "--color-lemon-yellow-l40": "#ffeb66", "--color-lemon-yellow-l30": "#fae458", "--color-lemon-yellow-l20": "#ffe433", "--color-lemon-yellow-l10": "#fd0", "--color-lemon-yellow": "#ffd500", "--color-lemon-yellow-d10": "#e6c000", "--color-lemon-yellow-d20": "#bf9f00", "--color-lemon-yellow-d30": "#998000", "--color-lemon-yellow-d40": "#806a00", "--color-lemon-yellow-d50": "#650", "--color-classical-red-l70": "#fff2f2", "--color-classical-red-l60": "#fae1e1", "--color-classical-red-l50": "#fabbbb", "--color-classical-red-l40": "#f59393", "--color-classical-red-l30": "#f07878", "--color-classical-red-l20": "#eb5e5e", "--color-classical-red-l15": "#f59393", "--color-classical-red-l10": "#eb5252", "--color-classical-red": "#e64545", "--color-classical-red-d10": "#d92121", "--color-classical-red-d20": "#cc1414", "--color-classical-red-d30": "#b21212", "--color-classical-red-d40": "#800d0d", "--color-classical-red-d50": "#660a0a", "--color-blue-gray-l80": "#fcfcfd", "--color-blue-gray-l70": "#fafbfc", "--color-blue-gray-l60": "#f7f8fa", "--color-blue-gray-l50": "#f5f7fa", "--color-blue-gray-l40": "#f0f2f5", "--color-blue-gray-l30": "#ebedf0", "--color-blue-gray-l20": "#e1e5eb", "--color-blue-gray-l10": "#dce0e6", "--color-blue-gray": "#ccd2d9", "--color-blue-gray-d10": "#c0c5cc", "--color-blue-gray-d20": "#b4b9bf", "--color-blue-gray-d30": "#a8adb3", "--color-blue-gray-d40": "#9ca0a6", "--color-blue-gray-d50": "#909499", "--color-blue-gray-d60": "#84878c", "--color-blue-gray-d70": "#6c6f73", "--color-blue-70": "#204ed9", "--color-gold-10": "#fff7e6", "--color-gold-70": "#e0720b", "--color-yellow-80": "#ad6800", "--color-yellow-90": "#884c00", "--color-brand-red-l50": "#faf0f0", "--color-brand-red-l40": "#fad6d6", "--color-brand-red-l30": "#fab7b7", "--color-brand-red-l20": "#fa8e8e", "--color-brand-red-l10": "#f55151", "--color-brand-red": "#de1b1b", "--color-brand-red-d10": "#ba0d0d", "--color-brand-red-d20": "#900e0e", "--color-brand-red-d30": "#661414", "--color-brand-red-d40": "#451717", "--color-brand-lime-l50": "#f5f7fa", "--color-brand-lime-l40": "#ebeff5", "--color-brand-lime-l30": "#dee3ed", "--color-brand-lime-l20": "#c8d0e0", "--color-brand-lime-l10": "#aeb9cb", "--color-brand-lime": "#8d98aa", "--color-brand-lime-d10": "#707a89", "--color-brand-lime-d20": "#59616e", "--color-brand-lime-d30": "#444b55", "--color-brand-lime-d40": "#343a41", "--color-yellow-l50": "#fffbe6", "--color-yellow-l40": "#fef1b7", "--color-yellow-l30": "#ffe48f", "--color-yellow-l20": "#ffd665", "--color-yellow-l10": "#ffc53d", "--color-yellow0": "#ffb019", "--color-yellow-d10": "#e09106", "--color-yellow-d20": "#ad6800", "--color-yellow-d30": "#884c00", "--color-yellow-d40": "#603400", "--color-canary-l50": "#fcfbf0", "--color-canary-l40": "#fcf7d7", "--color-canary-l30": "#fcf1a4", "--color-canary-l20": "#fcea72", "--color-canary-l10": "#fcdd3f", "--color-canary": "#fcd200", "--color-canary-d10": "#d9ad00", "--color-canary-d20": "#a68503", "--color-canary-d30": "#806703", "--color-canary-d40": "#594802", "--color-canary-d50": "#332901", "--color-primary-l70": "#f5f9ff", "--color-primary-l60": "#e6f1ff", "--color-primary-l50": "#c2d7f2", "--color-primary-l40": "#91bbf2", "--color-primary-l30": "#61a0f2", "--color-primary-l20": "#197dff", "--color-primary-l10": "#1876f2", "--color-primary": "#1770e6", "--color-primary-d10": "#156ad9", "--color-primary-d20": "#1464cc", "--color-primary-table-hover": "#f5f9ff", "--color-primary-checkbox": "#1770e6", "--color-success": "#50b371", "--color-warning-l40": "#ffbf66", "--color-warning-l30": "#ffb54d", "--color-warning-l20": "#fa3", "--color-warning-l10": "#ffa019", "--color-warning": "#ff9500", "--color-warning-d10": "#e0870b", "--color-warning-border": "#f2dfc3", "--color-danger-bg": "#faf0f0", "--color-danger-l50": "#faf0f0", "--color-danger-l40": "#f59393", "--color-danger-l30": "#f07878", "--color-danger-l20": "#eb5e5e", "--color-danger-l10": "#eb5252", "--color-danger": "#e64545", "--color-danger-d10": "#d92121", "--color-danger-d20": "#900e0e", "--color-danger-d30": "#661414", "--color-danger-d40": "#451717", "--color-gray-lighter": "#f3f3f3", "--color-gray-deeper": "#aaa", "--color-gray-light": "#eee", "--color-link-l10": "#204ed9", "--color-link": "#204ed9", "--color-link-d10": "undefined", "--color-info-l20": "#f5f8fd", "--color-info-l10": "#edf3fb", "--color-info": "#596a80", "--color-info-d10": "#7a8896", "--color-info-d20": "#4e6484", "--color-white": "#fff", "--color-transparent": "transparent", "--color-black-ligher": "rgba(0,0,0,0.8)", "--color-black": "#14161a", "--color-leak-blue-lighter": "#acebff", "--color-leak-blue-light": "#59d6ff", "--color-leak-blue-dark": "#1e3459", "--font-family": '"Microsoft Yahei","PingFangSC","Source Sans Pro","SimSun","sans-serif"', "--font-family-en": '"Helvetica","Helvetica Neue","sans-serif","Verdana","Tahoma","Arial","serif"', "--font-size-8xl": "64px", "--font-size-7xl": "56px", "--font-size-6xl": "48px", "--font-size-5xl": "40px", "--font-size-4xl": "32px", "--font-size-3xl": "28px", "--font-size-2xl": "24px", "--font-size-xl": "20px", "--font-size-l": "16px", "--font-size-m": "14px", "--font-size-s": "12px", "--font-size-base": "12px", "--font-weight-normal": "400", "--font-weight-bold": "500", "--font-weight-bolder": "600" };
const UNIQUE_FILE_ID_PREFIX = "_sf_upload_unique_id_";
const FILE_STATUS = {
  UPLOADING: "uploading",
  DONE: "done",
  ERROR: "error",
  READY: "ready",
  DELETING: "deleting",
  LOADED: "loaded"
};
const PROGRESS_STROKE_COLOR = {
  [FILE_STATUS.UPLOADING]: Color["--color-primary"],
  [FILE_STATUS.ERROR]: Color["--color-danger"]
};
const PROGRESS_DELAY_STEP = 10;
const PROGRESS_DELAY_TIME = 500;
const PROGRESS_DELAY_NAME = `sf_image_upload_run_progress`;
const PROGRESS_MAX_PERCENT = 100;
const DEFAULT_MAX_COUNT = 1;
const FILE_SOURCE = {
  UPLOAD: "upload",
  DEFAULT: "default"
};
const UPLOAD_TYPE = {
  PICTURE_CARD: "picture-card",
  FILE_LIST: "file-list",
  DRAG: "drag"
};
function validateFileSize(maxSize, fileInfo, defaultTip) {
  if (fileInfo.file.size <= maxSize) {
    return true;
  }
  return defaultTip || $i("scp.vt_component.sf_widget.packages.upload.file_max_size_error_tip", {
    maxSize: format.fileSize(maxSize)
  });
}
function validateFileType(acceptTypes, fileInfo, defaultTip) {
  const fileName = fileInfo.file.name.toUpperCase();
  const isAllowType = acceptTypes.some((accept) => fileName.endsWith(accept));
  if (isAllowType) {
    return true;
  }
  return defaultTip || $i("scp.vt_component.sf_widget.packages.upload.file_accept_error_tip", {
    types: acceptTypes.join("/").replace(/\./g, "")
  });
}
function getImageRect(url) {
  return new Promise((resolve) => {
    const img = document.createElement("img");
    img.src = url;
    img.onload = () => {
      resolve({
        width: img.width,
        height: img.height
      });
    };
    img.onerror = () => {
      resolve({
        width: 0,
        height: 0
      });
    };
  });
}
function isFileReady(fileInfo) {
  if (!fileInfo) {
    return false;
  }
  return fileInfo.status === FILE_STATUS.READY;
}
function isFileUploaded(fileInfo) {
  if (!fileInfo) {
    return false;
  }
  return fileInfo.status === FILE_STATUS.DONE;
}
function isFileLoaded(fileInfo) {
  if (!fileInfo) {
    return false;
  }
  return fileInfo.status === FILE_STATUS.LOADED;
}
function isFileUploading(fileInfo) {
  if (!fileInfo) {
    return false;
  }
  return fileInfo.status === FILE_STATUS.UPLOADING;
}
function isFileError(fileInfo) {
  if (!fileInfo) {
    return true;
  }
  return fileInfo.status === FILE_STATUS.ERROR;
}
function isFileDeleting(fileInfo) {
  if (!fileInfo) {
    return false;
  }
  return fileInfo.status === FILE_STATUS.DELETING;
}
function isFailNotify(files, failNotify) {
  return typeof failNotify === "function" ? failNotify(files) : failNotify;
}
const M_AVERAGE_COUNT = 40;
function getNeedTimer() {
  let lastUploadSize = 0;
  let lastUploadTime = new Date().getTime();
  const unitUploadTime = [];
  const unitUploadSizes = [];
  const updateUnitUploadSizes = function(size) {
    if (unitUploadSizes.length < M_AVERAGE_COUNT) {
      unitUploadSizes.push(size);
    } else {
      unitUploadSizes.shift();
      unitUploadSizes.push(size);
    }
  }, updateUnitTime = function(unitTime) {
    if (unitUploadTime.length < M_AVERAGE_COUNT) {
      unitUploadTime.push(unitTime);
    } else {
      unitUploadTime.shift();
      unitUploadTime.push(unitTime);
    }
  }, getAverageSpeed = function() {
    let total = 0, usedTime = 0, i = 0;
    for (i = 0; i < unitUploadSizes.length; i++) {
      total += unitUploadSizes[i] || 0;
    }
    for (i = 0; i < unitUploadTime.length; i++) {
      usedTime += unitUploadTime[i] || 0;
    }
    if (!usedTime || !total || total < 0 || !unitUploadSizes.length) {
      return -1;
    } else {
      return total / (usedTime / 1e3);
    }
  };
  return {
    get: function(upload, total) {
      if (lastUploadSize) {
        updateUnitUploadSizes(upload - lastUploadSize);
      }
      lastUploadSize = upload;
      if (lastUploadTime) {
        updateUnitTime(new Date().getTime() - lastUploadTime);
      }
      lastUploadTime = new Date().getTime();
      const averageSpeed = getAverageSpeed();
      if (averageSpeed === -1) {
        return -1;
      } else {
        return (total - upload) / averageSpeed * 1e3;
      }
    }
  };
}
function getSpeeder() {
  let lastUploadSize = 0;
  let lastUploadTime = new Date().getTime();
  const unitUploadSizes = [];
  const unitUploadTime = [];
  const updateUnitUploadSizes = function(size) {
    if (unitUploadSizes.length < M_AVERAGE_COUNT) {
      unitUploadSizes.push(size);
    } else {
      unitUploadSizes.shift();
      unitUploadSizes.push(size);
    }
  }, updateUnitTime = function(unitTime) {
    if (unitUploadTime.length < M_AVERAGE_COUNT) {
      unitUploadTime.push(unitTime);
    } else {
      unitUploadTime.shift();
      unitUploadTime.push(unitTime);
    }
  }, getAverageSpeed = function() {
    let total = 0, usedTime = 0, i = 0;
    for (i = 0; i < unitUploadSizes.length; i++) {
      total += unitUploadSizes[i] || 0;
    }
    for (i = 0; i < unitUploadTime.length; i++) {
      usedTime += unitUploadTime[i] || 0;
    }
    if (!usedTime || !total || total < 0 || !unitUploadSizes.length) {
      return -1;
    } else {
      return total / (usedTime / 1e3);
    }
  };
  return {
    get: function(upload) {
      if (lastUploadSize) {
        updateUnitUploadSizes(upload - lastUploadSize);
      }
      lastUploadSize = upload;
      if (lastUploadTime) {
        updateUnitTime(new Date().getTime() - lastUploadTime);
      }
      lastUploadTime = new Date().getTime();
      const averageSpeed = getAverageSpeed();
      if (averageSpeed === -1) {
        return "-";
      } else {
        return numberic.byteSize(averageSpeed, 2).toString() + "/s";
      }
    }
  };
}
function beautifyTime(ms) {
  const s = parseInt(Number(ms) / 1e3, 10) || 0;
  return format.secToTime(s) || "-";
}
function getFileUrl(file) {
  if (!file) {
    return null;
  }
  return URL.createObjectURL(file);
}
function createUUID() {
  return uuid(UNIQUE_FILE_ID_PREFIX);
}
function createFileInfo(rawFile) {
  return {
    id: createUUID(),
    file: rawFile,
    status: FILE_STATUS.READY,
    name: rawFile.name,
    localUrl: "",
    url: "",
    errorMsg: "",
    progressInfo: {
      percent: 0
    },
    httpRequest: null,
    source: FILE_SOURCE.UPLOAD
  };
}
function getAccepts(accept) {
  if (!accept) {
    return [];
  }
  const accepts = Array.isArray(accept) ? accept : accept.split(",");
  return accepts.map((item) => item.trim().toUpperCase());
}
var script$5 = {
  name: "FileInputUpload",
  props: {
    accept: {
      type: [String, Array],
      default: "*"
    },
    multiple: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    supportAccept() {
      if (!Array.isArray(this.accept)) {
        return this.accept;
      }
      return this.accept.join(",");
    }
  },
  methods: {
    fileChange(evt) {
      const fileInputElem = evt.target;
      if (!fileInputElem) {
        return;
      }
      const files = Array.from(fileInputElem.files || []);
      if (!files.length) {
        return;
      }
      const fileInfoList = files.map((rawFile) => createFileInfo(rawFile));
      this.clearFiles();
      this.$emit("file-change", fileInfoList);
    },
    clearFiles() {
      const fileInputRef = this.$refs.fileInput;
      if (!fileInputRef) {
        return;
      }
      fileInputRef.value = "";
    },
    triggerFileUpload() {
      const fileInputRef = this.$refs.fileInput;
      if (!fileInputRef) {
        return;
      }
      fileInputRef.click();
    }
  }
};
const __vue_script__$5 = script$5;
var __vue_render__$5 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c("input", {
    ref: "fileInput",
    staticStyle: { display: "none" },
    attrs: { type: "file", accept: _vm.supportAccept, multiple: _vm.multiple },
    on: { change: _vm.fileChange }
  });
};
var __vue_staticRenderFns__$5 = [];
__vue_render__$5._withStripped = true;
const __vue_inject_styles__$5 = void 0;
const __vue_scope_id__$5 = void 0;
const __vue_module_identifier__$5 = void 0;
const __vue_is_functional_template__$5 = false;
const __vue_component__$5 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$5, staticRenderFns: __vue_staticRenderFns__$5 },
  __vue_inject_styles__$5,
  __vue_script__$5,
  __vue_scope_id__$5,
  __vue_is_functional_template__$5,
  __vue_module_identifier__$5,
  false,
  void 0,
  void 0,
  void 0
);
const FileStatusMixin = {
  methods: {
    isFileReadyStatus(fileInfo) {
      return isFileReady(fileInfo);
    },
    isFileErrorStatus(fileInfo) {
      return isFileError(fileInfo);
    },
    isFileDeletingStatus(fileInfo) {
      return isFileDeleting(fileInfo);
    },
    isFileUploadingStatus(fileInfo) {
      return isFileUploading(fileInfo);
    },
    isFileLoadedStatus(fileInfo) {
      return isFileLoaded(fileInfo);
    },
    isFileUploadedStatus(fileInfo) {
      return isFileUploaded(fileInfo);
    },
    isFailNotifyStatus(fileList, failNotify) {
      return isFailNotify(fileList, failNotify);
    }
  }
};
const UploadHookMixin = {
  props: {
    beforeUpload: {
      type: Function,
      default: $.noop
    },
    beforeRemove: {
      type: Function,
      default: $.noop
    },
    onProgress: {
      type: Function,
      default: () => {
      }
    },
    onSuccess: {
      type: Function,
      default: () => {
      }
    },
    onError: {
      type: Function,
      default: () => {
      }
    },
    onRemove: {
      type: Function,
      default: () => {
      }
    },
    onChange: {
      type: Function,
      default: () => {
      }
    }
  }
};
const MultiFileUploadMixin = {
  props: {
    defaultFileList: {
      type: Array,
      default: () => []
    },
    uploadApi: {
      type: Function,
      required: true
    },
    urlField: {
      type: String,
      default: "url"
    }
  },
  data() {
    return {
      uploadFileList: [],
      defaultUploadedFileList: [],
      uploadingFileList: /* @__PURE__ */ new Map()
    };
  },
  computed: {
    fileList() {
      return [...this.uploadFileList, ...this.defaultUploadedFileList];
    }
  },
  watch: {
    defaultFileList: {
      immediate: true,
      handler(v) {
        this.defaultUploadedFileList = v.map((item) => {
          return {
            ...item,
            id: item.id || createUUID(),
            status: item.status || FILE_STATUS.DONE,
            source: FILE_SOURCE.DEFAULT
          };
        });
      }
    }
  },
  methods: {
    getProgressInfo(e) {
      if (!e) {
        return e;
      }
      if (e.total > 0) {
        e.percent = e.loaded / e.total * 100;
      } else {
        e.percent = 0;
      }
      return e;
    },
    submit() {
      if (!this.fileList || !this.fileList.length) {
        return;
      }
      return this.fileList.map((fileInfo) => this.requestUploadFile(fileInfo));
    },
    requestUploadFile(fileInfo) {
      if (!fileInfo || !fileInfo.file || fileInfo.url || isFileError(fileInfo) || isFileUploaded(fileInfo)) {
        return;
      }
      if (this.uploadingFileList.get(fileInfo.id)) {
        return;
      }
      let currUpdateFileInfo = Object.assign({}, fileInfo);
      const requestParams = { fileInfo: currUpdateFileInfo };
      $.when(this.beforeUpload(currUpdateFileInfo, this.fileList)).then((result) => {
        if (result === false) {
          return;
        }
        if (result) {
          requestParams.beforeUploadResult = result;
        }
        this.uploadingFileList.set(fileInfo.id, fileInfo);
        const httpReq = this.uploadApi(requestParams).progress(
          throttle((e) => {
            if (isFileError(currUpdateFileInfo) || isFileUploaded(currUpdateFileInfo)) {
              return;
            }
            const progressInfo = this.getProgressInfo(e);
            currUpdateFileInfo = {
              ...currUpdateFileInfo,
              status: FILE_STATUS.UPLOADING,
              progressInfo
            };
            this.updateFileInfo(currUpdateFileInfo);
            this.onProgress(progressInfo, currUpdateFileInfo, this.fileList);
          }, 100)
        ).done((res) => {
          currUpdateFileInfo.status = FILE_STATUS.DONE;
          currUpdateFileInfo.localUrl = URL.createObjectURL(fileInfo.file);
          currUpdateFileInfo.url = res.data[this.urlField];
          this.updateFileInfo(currUpdateFileInfo);
          this.onChange(currUpdateFileInfo, this.fileList);
          this.onSuccess(res, currUpdateFileInfo, this.fileList);
          this.uploadingFileList.delete(fileInfo.id);
        }).fail((err) => {
          currUpdateFileInfo = {
            ...currUpdateFileInfo,
            status: FILE_STATUS.ERROR,
            errorMsg: err.message
          };
          this.updateFileInfo(currUpdateFileInfo);
          this.onChange(currUpdateFileInfo, this.fileList);
          this.onError(err, currUpdateFileInfo, this.fileList);
          this.uploadingFileList.delete(fileInfo.id);
        }).error((err) => {
          currUpdateFileInfo = {
            ...currUpdateFileInfo,
            status: FILE_STATUS.ERROR,
            errorMsg: err.message
          };
          this.updateFileInfo(currUpdateFileInfo);
          this.onChange(currUpdateFileInfo, this.fileList);
          this.onError(err, currUpdateFileInfo, this.fileList);
          this.uploadingFileList.delete(fileInfo.id);
        });
        currUpdateFileInfo.httpRequest = httpReq;
        this.updateFileInfo(currUpdateFileInfo);
      });
    },
    updateFileInfo(modifiedFileInfo) {
      if (!modifiedFileInfo || !modifiedFileInfo.id) {
        return;
      }
      if (modifiedFileInfo.source === FILE_SOURCE.UPLOAD) {
        const removeUploadFileIndex = this.uploadFileList.findIndex((fileInfo) => fileInfo.id === modifiedFileInfo.id);
        if (removeUploadFileIndex < 0) {
          return;
        }
        this.uploadFileList.splice(removeUploadFileIndex, 1, modifiedFileInfo);
        return;
      }
      const removeDefaultFileIndex = this.defaultUploadedFileList.findIndex(
        (fileInfo) => fileInfo.id === modifiedFileInfo.id
      );
      if (removeDefaultFileIndex < 0) {
        return;
      }
      this.defaultUploadedFileList.splice(removeDefaultFileIndex, 1, modifiedFileInfo);
    },
    removeFile(fileInfo) {
      if (!fileInfo || !fileInfo.id) {
        return;
      }
      if (fileInfo.source === FILE_SOURCE.UPLOAD) {
        const uploadFileIndex = this.uploadFileList.findIndex((item) => item.id === fileInfo.id);
        this.uploadFileList.splice(uploadFileIndex, 1);
        return;
      }
      const defaultFileIndex = this.defaultUploadedFileList.findIndex((item) => item.id === fileInfo.id);
      this.defaultUploadedFileList.splice(defaultFileIndex, 1);
    },
    deleteFile(fileInfo) {
      if (!fileInfo || !fileInfo.id) {
        return;
      }
      $.when(this.beforeRemove(fileInfo, this.fileList)).then((result) => {
        if (result === false) {
          return;
        }
        const originStatus = fileInfo.status;
        const defer = $.Deferred();
        const currFileInfo = Object.assign({}, fileInfo);
        const requestParams = { fileInfo: currFileInfo, ...result ? { beforeUploadResult: result } : {} };
        if (isFileUploading(currFileInfo) && currFileInfo.httpRequest) {
          currFileInfo.httpRequest.abort();
          defer.resolve();
        } else if (isFileUploaded(currFileInfo) && currFileInfo.url && isFunction$1(this.deleteApi)) {
          currFileInfo.status = FILE_STATUS.DELETING;
          this.updateFileInfo(currFileInfo);
          this.deleteApi(requestParams).done(() => {
            defer.resolve();
          }).fail(() => {
            currFileInfo.status = originStatus;
            this.updateFileInfo(currFileInfo);
            defer.reject();
          }).error(() => {
            currFileInfo.status = originStatus;
            this.updateFileInfo(currFileInfo);
            defer.reject();
          });
        } else {
          defer.resolve();
        }
        $.when(defer).done(() => {
          this.removeFile(currFileInfo);
          this.onRemove(currFileInfo, this.fileList);
          this.uploadingFileList.delete(fileInfo.id);
        });
      });
    }
  }
};
var script$4 = {
  name: componentName.dragUpload,
  componentName: componentName.dragUpload,
  components: {
    SfButton,
    SfProgress,
    RawUpload: __vue_component__$5
  },
  mixins: [UploadHookMixin],
  props: {
    maxSize: {
      type: Number,
      default: 2 * 1024 * 1024
    },
    accept: {
      type: [String, Array],
      default: () => [".jpeg", ".jpg", ".png"]
    },
    uploadApi: {
      type: Function,
      required: true
    },
    boxWidth: {
      type: String,
      default: "600px"
    },
    boxHeight: {
      type: String,
      default: "270px"
    },
    urlField: {
      type: String,
      default: "url"
    },
    statusTip: {
      type: Function,
      default: (fileInfo) => {
        if (isFileUploaded(fileInfo)) {
          return $i("scp.vt_component.sf_widget.packages.upload.drag_upload.success_tip", {
            filename: fileInfo.name
          });
        } else if (isFileError(fileInfo)) {
          return $i("scp.vt_component.sf_widget.packages.upload.drag_upload.error_tip", {
            errorMsg: fileInfo.errorMsg
          });
        } else if (isFileUploading(fileInfo)) {
          return $i("scp.vt_component.sf_widget.packages.upload.drag_upload.uploading_tip", {
            filename: fileInfo.name
          });
        }
        return "";
      }
    }
  },
  data() {
    return {
      isDragOver: false,
      fileInfo: null
    };
  },
  computed: {
    supportFileTip() {
      const tipSegments = [];
      if (this.acceptTypes.length) {
        tipSegments.push(
          $i("scp.vt_component.sf_widget.packages.upload.file_accept_tip", {
            types: this.acceptTypes.join("/").replace(/\./g, "")
          })
        );
      }
      if (this.maxSize) {
        tipSegments.push(
          $i("scp.vt_component.sf_widget.packages.upload.fie_max_size_tip", {
            maxSize: format.fileSize(this.maxSize)
          })
        );
      }
      if (!tipSegments.length) {
        return "";
      }
      return tipSegments.join($i("scp.vt_component.sf_widget.packages.upload.comma")) + $i("scp.vt_component.sf_widget.packages.upload.period");
    },
    acceptTypes() {
      return getAccepts(this.accept);
    },
    boxStyle() {
      return {
        width: this.boxWidth,
        height: this.boxHeight
      };
    },
    statusIconCls() {
      if (!this.fileInfo) {
        return "";
      }
      const statusIconClsMap = {
        [FILE_STATUS.DONE]: "vtv-icon-done",
        [FILE_STATUS.ERROR]: "vtv-icon-win-fail"
      };
      return statusIconClsMap[this.fileInfo.status] || "";
    },
    isShowUploadResult() {
      return isFileUploaded(this.fileInfo) || isFileError(this.fileInfo);
    },
    isFileUploadingStatus() {
      return isFileUploading(this.fileInfo);
    },
    isCanUpload() {
      return !this.fileInfo;
    },
    uploadResultTip() {
      if (!this.fileInfo) {
        return "";
      }
      return this.statusTip(this.fileInfo);
    },
    statusText() {
      if (!this.fileInfo) {
        return "";
      }
      const statusTextMap = {
        [FILE_STATUS.DONE]: $i("scp.vt_component.sf_widget.packages.upload.drag_upload.upload_success"),
        [FILE_STATUS.ERROR]: $i("scp.vt_component.sf_widget.packages.upload.drag_upload.upload_error")
      };
      return statusTextMap[this.fileInfo.status] || "";
    },
    progressTip() {
      if (!this.fileInfo) {
        return "";
      }
      return this.statusTip(this.fileInfo);
    },
    progressInfoData() {
      if (!this.fileInfo || !this.fileInfo.progressInfo) {
        return "";
      }
      const { speed = "-", uploadedSize = "-", totalSize = "-", needTime = "-" } = this.fileInfo.progressInfo;
      return $i("scp.vt_component.sf_widget.packages.upload.drag_upload.progress_tip", {
        speed,
        uploadedSize,
        totalSize,
        needTime
      });
    },
    addBtnText() {
      return $i("scp.vt_component.sf_widget.packages.upload.drag_upload.add_btn");
    },
    reUploadBtnText() {
      return $i("scp.vt_component.sf_widget.packages.upload.drag_upload.re_upload_btn");
    },
    cancelUploadBtnText() {
      return $i("scp.vt_component.sf_widget.packages.upload.drag_upload.cancel_btn");
    },
    fileList() {
      if (!this.fileInfo) {
        return [];
      }
      return [this.fileInfo];
    }
  },
  methods: {
    getPrefixedClassName,
    getFullUtid(utidBase) {
      return this.$attrs.utid ? `${this.$attrs.utid}-${utidBase}` : utidBase;
    },
    addChooseFile() {
      const rawFileUploadRef = this.$refs.rawUpload;
      if (!rawFileUploadRef) {
        return;
      }
      rawFileUploadRef.triggerFileUpload();
    },
    handleFileChange(fileInfoList) {
      if (!fileInfoList || !fileInfoList.length) {
        return;
      }
      const validatedFileInfo = this.getValidateFileInfoList(fileInfoList)[0];
      this.fileInfo = validatedFileInfo;
      this.onChange(validatedFileInfo, this.fileList);
      this.submit();
    },
    updateFileInfo(modifiedFileInfo) {
      if (!modifiedFileInfo || !modifiedFileInfo.id) {
        return;
      }
      this.fileInfo = {
        ...this.fileInfo,
        ...modifiedFileInfo
      };
    },
    submit() {
      this.requestUploadFile(this.fileInfo);
    },
    requestUploadFile(readyFileInfo) {
      if (!readyFileInfo || !readyFileInfo.file || readyFileInfo.url || isFileError(readyFileInfo) || isFileUploaded(readyFileInfo)) {
        return;
      }
      let currUpdateFileInfo = Object.assign({}, readyFileInfo);
      const requestParams = { fileInfo: currUpdateFileInfo };
      $.when(this.beforeUpload(currUpdateFileInfo, this.fileList)).then((result) => {
        if (result === false) {
          return;
        }
        const startTime = new Date();
        if (result) {
          requestParams.beforeUploadResult = result;
        }
        let needTimer = null;
        let speeder = null;
        currUpdateFileInfo.status = FILE_STATUS.UPLOADING;
        this.updateFileInfo(currUpdateFileInfo);
        const httpReq = this.uploadApi(requestParams).progress(
          throttle((e) => {
            if (isFileError(currUpdateFileInfo) || isFileUploaded(currUpdateFileInfo)) {
              return;
            }
            if (!needTimer) {
              needTimer = getNeedTimer();
            }
            if (!speeder) {
              speeder = getSpeeder();
            }
            const uploadedSize = e.loaded, totalSize = e.total, usedTime = new Date() - startTime, needTime = needTimer.get(uploadedSize, totalSize), speed = speeder.get(uploadedSize);
            if (e.total > 0) {
              e.percent = e.loaded / e.total * 100;
            } else {
              e.percent = 0;
            }
            e.totalSize = format.fileSize(totalSize);
            e.uploadedSize = format.fileSize(uploadedSize);
            e.speed = speed;
            e.usedTime = beautifyTime(usedTime);
            e.needTime = needTime > -1 ? beautifyTime(needTime) : "-";
            currUpdateFileInfo = {
              ...currUpdateFileInfo,
              status: FILE_STATUS.UPLOADING,
              progressInfo: e
            };
            this.updateFileInfo(currUpdateFileInfo);
            this.onProgress(e, currUpdateFileInfo, this.fileList);
          }, 100)
        ).done((res) => {
          currUpdateFileInfo.status = FILE_STATUS.DONE;
          currUpdateFileInfo.localUrl = URL.createObjectURL(this.fileInfo.file);
          currUpdateFileInfo.url = res.data[this.urlField];
          this.updateFileInfo(currUpdateFileInfo);
          this.onChange(currUpdateFileInfo, this.fileList);
          this.onSuccess(res, currUpdateFileInfo, this.fileList);
        }).fail((err) => {
          currUpdateFileInfo = {
            ...currUpdateFileInfo,
            status: FILE_STATUS.ERROR,
            errorMsg: err.message
          };
          this.updateFileInfo(currUpdateFileInfo);
          this.onChange(currUpdateFileInfo, this.fileList);
          this.onError(err, currUpdateFileInfo, this.fileList);
        }).error((err) => {
          currUpdateFileInfo = {
            ...currUpdateFileInfo,
            status: FILE_STATUS.ERROR,
            errorMsg: err.message
          };
          this.updateFileInfo(currUpdateFileInfo);
          this.onChange(currUpdateFileInfo, this.fileList);
          this.onError(err, currUpdateFileInfo, this.fileList);
        });
        currUpdateFileInfo.httpRequest = httpReq;
        this.updateFileInfo(currUpdateFileInfo);
      });
    },
    getValidateFileInfoList(fileInfoList) {
      return fileInfoList.map((fileItem) => {
        const invalidMsgs = this.validateFile(fileItem);
        if (!invalidMsgs.length) {
          return fileItem;
        }
        return {
          ...fileItem,
          status: FILE_STATUS.ERROR,
          errorMsg: $i("scp.vt_component.sf_widget.packages.upload.file_error_msg")
        };
      });
    },
    validateFile(fileInfo) {
      const validateFailMsgs = [];
      const validateTypeResult = validateFileType(this.acceptTypes, fileInfo);
      const validateSizeResult = validateFileSize(this.maxSize, fileInfo);
      validateTypeResult !== true && validateFailMsgs.push(validateTypeResult);
      validateSizeResult !== true && validateFailMsgs.push(validateSizeResult);
      return validateFailMsgs;
    },
    handleDragEnter() {
      if (!this.isCanUpload) {
        return;
      }
      this.isDragOver = true;
    },
    handleDragLeave() {
      this.isDragOver = false;
    },
    handleDragOver(evt) {
      evt.preventDefault();
    },
    handleDragDrop(evt) {
      if (!this.isCanUpload) {
        return;
      }
      evt.preventDefault();
      const files = Array.from(evt.dataTransfer.files || []);
      if (files && files.length) {
        if (!files.length) {
          return;
        }
        const fileInfoList = files.map((rawFile) => createFileInfo(rawFile));
        this.handleFileChange(fileInfoList);
      }
      this.handleDragLeave();
    },
    cancelUpload() {
      if (!isFileUploading(this.fileInfo)) {
        return;
      }
      this.deleteFile(this.fileInfo);
    },
    deleteFile(deletedFileInfo) {
      if (!deletedFileInfo || deletedFileInfo.id !== this.fileInfo.id) {
        return;
      }
      $.when(this.beforeRemove(this.fileInfo, this.fileList)).then((canRemove) => {
        if (canRemove === false) {
          return;
        }
        const httpReq = this.fileInfo.httpRequest;
        if (httpReq) {
          httpReq.abort();
        }
        this.fileInfo = null;
        this.onRemove(this.fileInfo, this.fileList);
      });
    }
  }
};
const __vue_script__$4 = script$4;
var __vue_render__$4 = function() {
  var _obj;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    { class: _vm.getPrefixedClassName("sf-drag-upload") },
    [
      _c("raw-upload", {
        ref: "rawUpload",
        attrs: { accept: _vm.accept },
        on: { "file-change": _vm.handleFileChange }
      }),
      _vm._v(" "),
      _c(
        "div",
        {
          class: (_obj = {}, _obj[_vm.getPrefixedClassName("sf-drag-upload__wrap")] = true, _obj[_vm.getPrefixedClassName("sf-drag-upload__wrap--drag-over")] = _vm.isDragOver, _obj[_vm.getPrefixedClassName("sf-drag-upload__wrap--uploading")] = _vm.isFileUploadingStatus, _obj),
          style: _vm.boxStyle,
          attrs: { draggable: true },
          on: {
            dragenter: _vm.handleDragEnter,
            dragleave: _vm.handleDragLeave,
            dragover: _vm.handleDragOver,
            drop: _vm.handleDragDrop
          }
        },
        [
          _vm._t("default", [
            _vm.isCanUpload ? _vm._t("upload", [
              _c(
                "div",
                {
                  class: _vm.getPrefixedClassName("sf-drag-upload__add"),
                  on: { click: _vm.addChooseFile }
                },
                [
                  _c("i", {
                    staticClass: "iconfont vtv-icon-ele-upload",
                    class: _vm.getPrefixedClassName(
                      "sf-drag-upload__add__icon"
                    )
                  }),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      class: _vm.getPrefixedClassName(
                        "sf-drag-upload__add__text"
                      )
                    },
                    [
                      _vm._v(
                        "\n            " + _vm._s(_vm.addBtnText) + "\n          "
                      )
                    ]
                  ),
                  _vm._v(" "),
                  _vm.supportFileTip || _vm.$slots.tip ? _c(
                    "div",
                    {
                      class: _vm.getPrefixedClassName(
                        "sf-drag-upload__add__support"
                      )
                    },
                    [
                      _vm._t("tip", [
                        _vm._v(_vm._s(_vm.supportFileTip))
                      ])
                    ],
                    2
                  ) : _vm._e()
                ]
              )
            ]) : _vm.isFileUploadingStatus ? _c(
              "div",
              {
                class: _vm.getPrefixedClassName("sf-drag-upload__progress"),
                style: _vm.boxStyle
              },
              [
                _vm.progressTip ? _c(
                  "div",
                  {
                    class: _vm.getPrefixedClassName(
                      "sf-drag-upload__progress__tip"
                    )
                  },
                  [_vm._v(_vm._s(_vm.progressTip))]
                ) : _vm._e(),
                _vm._v(" "),
                _c(
                  "div",
                  {
                    class: _vm.getPrefixedClassName(
                      "sf-drag-upload__progress__info"
                    )
                  },
                  [
                    _c(
                      "div",
                      {
                        class: _vm.getPrefixedClassName(
                          "sf-drag-upload__progress__info__data"
                        )
                      },
                      [_vm._v(_vm._s(_vm.progressInfoData))]
                    ),
                    _vm._v(" "),
                    _c("sf-progress", {
                      class: _vm.getPrefixedClassName(
                        "sf-drag-upload__progress__info__bar"
                      ),
                      attrs: {
                        "no-text": true,
                        "show-stripe": true,
                        "stroke-width": 8,
                        percentage: _vm.fileInfo.progressInfo.percent
                      }
                    })
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "sf-button",
                  {
                    class: _vm.getPrefixedClassName(
                      "sf-drag-upload__progress__opr"
                    ),
                    attrs: { utid: _vm.getFullUtid("delete-file") },
                    on: { click: _vm.cancelUpload }
                  },
                  [
                    _vm._v(
                      "\n          " + _vm._s(_vm.cancelUploadBtnText) + "\n        "
                    )
                  ]
                )
              ],
              1
            ) : _vm.isShowUploadResult ? _vm._t(
              "result",
              [
                _c(
                  "div",
                  {
                    class: _vm.getPrefixedClassName(
                      "sf-drag-upload__result"
                    )
                  },
                  [
                    _c("i", {
                      class: [
                        "iconfont",
                        _vm.getPrefixedClassName(
                          "sf-drag-upload__result__icon"
                        ),
                        _vm.getPrefixedClassName(
                          "sf-drag-upload__result__icon--" + _vm.fileInfo.status
                        ),
                        _vm.statusIconCls
                      ]
                    }),
                    _vm._v(" "),
                    _vm.statusText ? _c(
                      "div",
                      {
                        class: _vm.getPrefixedClassName(
                          "sf-drag-upload__result__text"
                        )
                      },
                      [_vm._v(_vm._s(_vm.statusText))]
                    ) : _vm._e(),
                    _vm._v(" "),
                    _vm.uploadResultTip ? _c(
                      "div",
                      {
                        class: _vm.getPrefixedClassName(
                          "sf-drag-upload__result__tip"
                        )
                      },
                      [
                        _vm._v(
                          "\n            " + _vm._s(_vm.uploadResultTip) + "\n          "
                        )
                      ]
                    ) : _vm._e(),
                    _vm._v(" "),
                    _c(
                      "sf-button",
                      {
                        class: _vm.getPrefixedClassName(
                          "sf-drag-upload__result__opr"
                        ),
                        on: { click: _vm.addChooseFile }
                      },
                      [
                        _vm._v(
                          "\n            " + _vm._s(_vm.reUploadBtnText) + "\n          "
                        )
                      ]
                    )
                  ],
                  1
                )
              ],
              { fileInfo: _vm.fileInfo }
            ) : _vm._e()
          ])
        ],
        2
      )
    ],
    1
  );
};
var __vue_staticRenderFns__$4 = [];
__vue_render__$4._withStripped = true;
const __vue_inject_styles__$4 = void 0;
const __vue_scope_id__$4 = void 0;
const __vue_module_identifier__$4 = void 0;
const __vue_is_functional_template__$4 = false;
const __vue_component__$4 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$4, staticRenderFns: __vue_staticRenderFns__$4 },
  __vue_inject_styles__$4,
  __vue_script__$4,
  __vue_scope_id__$4,
  __vue_is_functional_template__$4,
  __vue_module_identifier__$4,
  false,
  void 0,
  void 0,
  void 0
);
var script$3 = {
  name: componentName.fileListUpload,
  componentName: componentName.fileListUpload,
  components: {
    SfButton,
    SfProgress,
    RawUpload: __vue_component__$5
  },
  mixins: [UploadHookMixin, MultiFileUploadMixin, FileStatusMixin],
  props: {
    autoUpload: {
      type: Boolean,
      default: true
    },
    disabled: {
      type: Boolean,
      default: false
    },
    tip: {
      type: String,
      default: ""
    },
    deleteApi: Function,
    fileListWidth: {
      type: String,
      default: "557px"
    },
    accept: {
      type: [String, Array],
      default: () => [".jpeg", ".jpg", ".png"]
    },
    multiple: {
      type: Boolean,
      default: false
    },
    maxSize: {
      type: Number,
      default: 2 * 1024 * 1024
    },
    maxCount: {
      type: Number,
      default: DEFAULT_MAX_COUNT
    },
    statusTip: {
      type: Function,
      default: (fileInfo) => {
        if (isFileError(fileInfo)) {
          return fileInfo.errorMsg;
        }
        return "";
      }
    },
    failNotify: {
      type: Function | Boolean,
      default: true
    }
  },
  data() {
    return {
      illegalMessages: []
    };
  },
  computed: {
    acceptTypes() {
      return getAccepts(this.accept);
    },
    isOnlySupportSingleFile() {
      return this.maxCount === DEFAULT_MAX_COUNT;
    },
    isReachMaxCount() {
      return this.fileList.length >= this.maxCount;
    },
    disabledUploadBtn() {
      return !this.isOnlySupportSingleFile && this.isReachMaxCount || this.disabled;
    },
    isReUploadStatus() {
      return this.isOnlySupportSingleFile && this.isReachMaxCount;
    },
    uploadBtnText() {
      if (this.isReUploadStatus) {
        return $i("scp.vt_component.sf_widget.packages.upload.file_list_upload.re_upload_btn");
      }
      return $i("scp.vt_component.sf_widget.packages.upload.file_list_upload.upload_btn");
    },
    supportFileTip() {
      let prefixSegment = "";
      const tipSegments = [];
      if (this.maxCount > DEFAULT_MAX_COUNT) {
        prefixSegment = $i("scp.vt_component.sf_widget.packages.upload.file_max_count_tip", {
          maxCount: this.maxCount
        });
      }
      if (this.acceptTypes.length) {
        tipSegments.push(
          $i("scp.vt_component.sf_widget.packages.upload.file_accept_tip", {
            types: this.acceptTypes.join("/").replace(/\./g, "")
          })
        );
      }
      if (this.maxSize) {
        tipSegments.push(
          $i("scp.vt_component.sf_widget.packages.upload.fie_max_size_tip", {
            maxSize: format.fileSize(this.maxSize)
          })
        );
      }
      if (!tipSegments.length) {
        return prefixSegment;
      }
      return prefixSegment + (tipSegments.join($i("scp.vt_component.sf_widget.packages.upload.comma")) + $i("scp.vt_component.sf_widget.packages.upload.period"));
    },
    fileListStyle() {
      return {
        width: this.fileListWidth
      };
    },
    uploadErrorText() {
      return $i("scp.vt_component.sf_widget.packages.upload.file_list_upload.upload_error");
    },
    deleteBtnTip() {
      return $i("scp.vt_component.sf_widget.packages.upload.file_list_upload.delete_btn_tip");
    }
  },
  methods: {
    getPrefixedClassName,
    getFullUtid(utidBase) {
      return this.$attrs.utid ? `${this.$attrs.utid}-${utidBase}` : utidBase;
    },
    addChooseFile() {
      const rawFileUploadRef = this.$refs.rawUpload;
      if (!rawFileUploadRef) {
        return;
      }
      rawFileUploadRef.triggerFileUpload();
    },
    isOverMaxCount(files) {
      return files.length + this.fileList.length > this.maxCount;
    },
    async handleFileChange(fileInfoList) {
      if (!fileInfoList || !fileInfoList.length) {
        return;
      }
      this.illegalMessages = [];
      let files = fileInfoList;
      if (this.isOverMaxCount(files) && !this.isReUploadStatus) {
        const remainCount = this.maxCount - this.fileList.length;
        const abandonCount = this.fileList.length + files.length - this.maxCount;
        files = files.slice(0, remainCount);
        this.illegalMessages.push(
          $i("scp.vt_component.sf_widget.packages.upload.max_count_error_tip", {
            abandonCount,
            maxCount: this.maxCount
          })
        );
      }
      const validatedFileInfoList = this.getValidateFileInfoList(files);
      if (this.isFailNotifyStatus(fileInfoList, this.failNotify)) {
        this.notifyIllegalMessages(this.illegalMessages);
      }
      if (this.isReUploadStatus) {
        this.uploadFileList = validatedFileInfoList;
      } else {
        this.uploadFileList.unshift(...validatedFileInfoList);
      }
      validatedFileInfoList.forEach((fileInfo) => {
        this.onChange(fileInfo, this.fileList);
      });
      if (!this.autoUpload) {
        return;
      }
      this.submit();
    },
    getValidateFileInfoList(fileInfoList) {
      return fileInfoList.map((fileInfo) => {
        const invalidMsgs = this.validateFile(fileInfo);
        invalidMsgs.forEach((invalidMsg) => {
          this.illegalMessages.push(invalidMsg);
        });
        if (!invalidMsgs.length) {
          return fileInfo;
        }
        return {
          ...fileInfo,
          status: FILE_STATUS.ERROR,
          errorMsg: $i("scp.vt_component.sf_widget.packages.upload.file_error_msg")
        };
      });
    },
    validateFile(fileInfo) {
      const validateFailMsgs = [];
      const validateTypeResult = validateFileType(this.acceptTypes, fileInfo);
      const validateSizeResult = validateFileSize(this.maxSize, fileInfo);
      validateTypeResult !== true && validateFailMsgs.push(validateTypeResult);
      validateSizeResult !== true && validateFailMsgs.push(validateSizeResult);
      return validateFailMsgs;
    },
    getFileProgressPercent(fileInfo) {
      if (!fileInfo || !fileInfo.progressInfo) {
        return 0;
      }
      return fileInfo.progressInfo.percent || 0;
    },
    notifyIllegalMessages(messages) {
      if (!messages || !messages.length) {
        return;
      }
      const msgs = Array.from(new Set(messages));
      msgs.forEach((msg) => {
        setTimeout(() => {
          notify.fail(msg);
        });
      });
    }
  }
};
const __vue_script__$3 = script$3;
var __vue_render__$3 = function() {
  var _obj;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    { class: _vm.getPrefixedClassName("sf-file-list-upload") },
    [
      _c("raw-upload", {
        ref: "rawUpload",
        attrs: { accept: _vm.accept, multiple: _vm.multiple },
        on: { "file-change": _vm.handleFileChange }
      }),
      _vm._v(" "),
      _c(
        "sf-button",
        {
          attrs: {
            icon: "upload",
            disabled: _vm.disabledUploadBtn,
            tip: _vm.tip
          },
          on: { click: _vm.addChooseFile }
        },
        [_vm._v("\n    " + _vm._s(_vm.uploadBtnText) + "\n  ")]
      ),
      _vm._v(" "),
      _vm.fileList.length ? _c(
        "div",
        {
          class: (_obj = {}, _obj[_vm.getPrefixedClassName("sf-file-list-upload__list")] = _vm.fileList.length, _obj),
          style: _vm.fileListStyle
        },
        _vm._l(_vm.fileList, function(fileInfo) {
          var _obj2;
          return _c(
            "div",
            {
              key: fileInfo.id,
              class: _vm.getPrefixedClassName(
                "sf-file-list-upload__list-item"
              )
            },
            [
              _c("i", {
                class: (_obj2 = {
                  "iconfont vtv-icon-ele-clip": true
                }, _obj2[_vm.getPrefixedClassName(
                  "sf-file-list-upload__list-item__annex"
                )] = true, _obj2[_vm.getPrefixedClassName(
                  "sf-file-list-upload__list-item__annex--ready"
                )] = _vm.isFileReadyStatus(fileInfo), _obj2)
              }),
              _vm._v(" "),
              _c(
                "span",
                {
                  class: [
                    _vm.getPrefixedClassName(
                      "sf-file-list-upload__list-item__text"
                    ),
                    "ellipsis",
                    _vm.getPrefixedClassName(
                      "sf-file-list-upload__list-item__text--" + fileInfo.status
                    )
                  ],
                  attrs: { "data-tip": fileInfo.name }
                },
                [_vm._v("\n        " + _vm._s(fileInfo.name) + "\n      ")]
              ),
              _vm._v(" "),
              _c(
                "span",
                {
                  class: _vm.getPrefixedClassName(
                    "sf-file-list-upload__list-item__tip"
                  )
                },
                [
                  _vm.isFileErrorStatus(fileInfo) ? _c(
                    "span",
                    {
                      class: _vm.getPrefixedClassName(
                        "sf-file-list-upload__list-item__error-desc"
                      )
                    },
                    [
                      _c(
                        "span",
                        {
                          class: [
                            "ellipsis",
                            _vm.getPrefixedClassName(
                              "sf-file-list-upload__list-item__error-text"
                            )
                          ],
                          attrs: { "data-tip": _vm.uploadErrorText }
                        },
                        [
                          _vm._v(
                            "\n            " + _vm._s(_vm.uploadErrorText) + "\n          "
                          )
                        ]
                      ),
                      _vm._v(" "),
                      _c("i", {
                        staticClass: "iconfont vtv-icon-tip-info",
                        class: _vm.getPrefixedClassName(
                          "sf-file-list-upload__list-item__error-icon"
                        ),
                        attrs: { "data-tip": _vm.statusTip(fileInfo) }
                      })
                    ]
                  ) : _vm._e(),
                  _vm._v(" "),
                  !_vm.isFileDeletingStatus(fileInfo) ? _c("i", {
                    staticClass: "iconfont vtv-icon-line-delete",
                    class: _vm.getPrefixedClassName(
                      "sf-file-list-upload__list-item__delete-btn"
                    ),
                    attrs: {
                      "data-tip": _vm.deleteBtnTip,
                      utid: _vm.getFullUtid("delete-file")
                    },
                    on: {
                      click: function($event) {
                        return _vm.deleteFile(fileInfo);
                      }
                    }
                  }) : _c("i", {
                    staticClass: "iconfont vtv-icon-refresh",
                    class: _vm.getPrefixedClassName(
                      "sf-file-list-upload__list-item__deleting-loading"
                    )
                  })
                ]
              ),
              _vm._v(" "),
              _vm.isFileUploadingStatus(fileInfo) ? _c("sf-progress", {
                class: _vm.getPrefixedClassName(
                  "sf-file-list-upload__list-item__progress"
                ),
                attrs: {
                  "no-text": true,
                  percentage: _vm.getFileProgressPercent(fileInfo),
                  "show-stripe": true,
                  "stroke-width": 2
                }
              }) : _vm._e()
            ],
            1
          );
        }),
        0
      ) : _vm._e(),
      _vm._v(" "),
      _vm.supportFileTip || _vm.$slots.tip ? _c(
        "div",
        { class: _vm.getPrefixedClassName("sf-file-list-upload__bottom") },
        [
          _c(
            "div",
            {
              class: _vm.getPrefixedClassName(
                "sf-file-list-upload__bottom__tip"
              )
            },
            [_vm._t("tip", [_vm._v(_vm._s(_vm.supportFileTip))])],
            2
          )
        ]
      ) : _vm._e()
    ],
    1
  );
};
var __vue_staticRenderFns__$3 = [];
__vue_render__$3._withStripped = true;
const __vue_inject_styles__$3 = void 0;
const __vue_scope_id__$3 = void 0;
const __vue_module_identifier__$3 = void 0;
const __vue_is_functional_template__$3 = false;
const __vue_component__$3 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$3, staticRenderFns: __vue_staticRenderFns__$3 },
  __vue_inject_styles__$3,
  __vue_script__$3,
  __vue_scope_id__$3,
  __vue_is_functional_template__$3,
  __vue_module_identifier__$3,
  false,
  void 0,
  void 0,
  void 0
);
var commonjsGlobal = typeof globalThis !== "undefined" ? globalThis : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : {};
function getAugmentedNamespace(n) {
  if (n.__esModule)
    return n;
  var f = n.default;
  if (typeof f == "function") {
    var a = function a2() {
      if (this instanceof a2) {
        var args = [null];
        args.push.apply(args, arguments);
        var Ctor = Function.bind.apply(f, args);
        return new Ctor();
      }
      return f.apply(this, arguments);
    };
    a.prototype = f.prototype;
  } else
    a = {};
  Object.defineProperty(a, "__esModule", { value: true });
  Object.keys(n).forEach(function(k) {
    var d = Object.getOwnPropertyDescriptor(n, k);
    Object.defineProperty(a, k, d.get ? d : {
      enumerable: true,
      get: function() {
        return n[k];
      }
    });
  });
  return a;
}
var vViewerExports = {};
var vViewer = {
  get exports() {
    return vViewerExports;
  },
  set exports(v) {
    vViewerExports = v;
  }
};
function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);
  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    enumerableOnly && (symbols = symbols.filter(function(sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    })), keys.push.apply(keys, symbols);
  }
  return keys;
}
function _objectSpread2(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = null != arguments[i] ? arguments[i] : {};
    i % 2 ? ownKeys(Object(source), true).forEach(function(key) {
      _defineProperty(target, key, source[key]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function(key) {
      Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
    });
  }
  return target;
}
function _typeof(obj) {
  "@babel/helpers - typeof";
  return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj2) {
    return typeof obj2;
  } : function(obj2) {
    return obj2 && "function" == typeof Symbol && obj2.constructor === Symbol && obj2 !== Symbol.prototype ? "symbol" : typeof obj2;
  }, _typeof(obj);
}
function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor)
      descriptor.writable = true;
    Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor);
  }
}
function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps)
    _defineProperties(Constructor.prototype, protoProps);
  if (staticProps)
    _defineProperties(Constructor, staticProps);
  Object.defineProperty(Constructor, "prototype", {
    writable: false
  });
  return Constructor;
}
function _defineProperty(obj, key, value) {
  key = _toPropertyKey(key);
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }
  return obj;
}
function _toPrimitive(input, hint) {
  if (typeof input !== "object" || input === null)
    return input;
  var prim = input[Symbol.toPrimitive];
  if (prim !== void 0) {
    var res = prim.call(input, hint || "default");
    if (typeof res !== "object")
      return res;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (hint === "string" ? String : Number)(input);
}
function _toPropertyKey(arg) {
  var key = _toPrimitive(arg, "string");
  return typeof key === "symbol" ? key : String(key);
}
var DEFAULTS = {
  backdrop: true,
  button: true,
  navbar: true,
  title: true,
  toolbar: true,
  className: "",
  container: "body",
  filter: null,
  fullscreen: true,
  inheritedAttributes: ["crossOrigin", "decoding", "isMap", "loading", "referrerPolicy", "sizes", "srcset", "useMap"],
  initialCoverage: 0.9,
  initialViewIndex: 0,
  inline: false,
  interval: 5e3,
  keyboard: true,
  focus: true,
  loading: true,
  loop: true,
  minWidth: 200,
  minHeight: 100,
  movable: true,
  rotatable: true,
  scalable: true,
  zoomable: true,
  zoomOnTouch: true,
  zoomOnWheel: true,
  slideOnTouch: true,
  toggleOnDblclick: true,
  tooltip: true,
  transition: true,
  zIndex: 2015,
  zIndexInline: 0,
  zoomRatio: 0.1,
  minZoomRatio: 0.01,
  maxZoomRatio: 100,
  url: "src",
  ready: null,
  show: null,
  shown: null,
  hide: null,
  hidden: null,
  view: null,
  viewed: null,
  move: null,
  moved: null,
  rotate: null,
  rotated: null,
  scale: null,
  scaled: null,
  zoom: null,
  zoomed: null,
  play: null,
  stop: null
};
var TEMPLATE = '<div class="viewer-container" tabindex="-1" touch-action="none"><div class="viewer-canvas"></div><div class="viewer-footer"><div class="viewer-title"></div><div class="viewer-toolbar"></div><div class="viewer-navbar"><ul class="viewer-list" role="navigation"></ul></div></div><div class="viewer-tooltip" role="alert" aria-hidden="true"></div><div class="viewer-button" data-viewer-action="mix" role="button"></div><div class="viewer-player"></div></div>';
var IS_BROWSER = typeof window !== "undefined" && typeof window.document !== "undefined";
var WINDOW = IS_BROWSER ? window : {};
var IS_TOUCH_DEVICE = IS_BROWSER && WINDOW.document.documentElement ? "ontouchstart" in WINDOW.document.documentElement : false;
var HAS_POINTER_EVENT = IS_BROWSER ? "PointerEvent" in WINDOW : false;
var NAMESPACE = "viewer";
var ACTION_MOVE = "move";
var ACTION_SWITCH = "switch";
var ACTION_ZOOM = "zoom";
var CLASS_ACTIVE = "".concat(NAMESPACE, "-active");
var CLASS_CLOSE = "".concat(NAMESPACE, "-close");
var CLASS_FADE = "".concat(NAMESPACE, "-fade");
var CLASS_FIXED = "".concat(NAMESPACE, "-fixed");
var CLASS_FULLSCREEN = "".concat(NAMESPACE, "-fullscreen");
var CLASS_FULLSCREEN_EXIT = "".concat(NAMESPACE, "-fullscreen-exit");
var CLASS_HIDE = "".concat(NAMESPACE, "-hide");
var CLASS_HIDE_MD_DOWN = "".concat(NAMESPACE, "-hide-md-down");
var CLASS_HIDE_SM_DOWN = "".concat(NAMESPACE, "-hide-sm-down");
var CLASS_HIDE_XS_DOWN = "".concat(NAMESPACE, "-hide-xs-down");
var CLASS_IN = "".concat(NAMESPACE, "-in");
var CLASS_INVISIBLE = "".concat(NAMESPACE, "-invisible");
var CLASS_LOADING = "".concat(NAMESPACE, "-loading");
var CLASS_MOVE = "".concat(NAMESPACE, "-move");
var CLASS_OPEN = "".concat(NAMESPACE, "-open");
var CLASS_SHOW = "".concat(NAMESPACE, "-show");
var CLASS_TRANSITION = "".concat(NAMESPACE, "-transition");
var EVENT_CLICK = "click";
var EVENT_DBLCLICK = "dblclick";
var EVENT_DRAG_START = "dragstart";
var EVENT_FOCUSIN = "focusin";
var EVENT_KEY_DOWN = "keydown";
var EVENT_LOAD = "load";
var EVENT_ERROR = "error";
var EVENT_TOUCH_END = IS_TOUCH_DEVICE ? "touchend touchcancel" : "mouseup";
var EVENT_TOUCH_MOVE = IS_TOUCH_DEVICE ? "touchmove" : "mousemove";
var EVENT_TOUCH_START = IS_TOUCH_DEVICE ? "touchstart" : "mousedown";
var EVENT_POINTER_DOWN = HAS_POINTER_EVENT ? "pointerdown" : EVENT_TOUCH_START;
var EVENT_POINTER_MOVE = HAS_POINTER_EVENT ? "pointermove" : EVENT_TOUCH_MOVE;
var EVENT_POINTER_UP = HAS_POINTER_EVENT ? "pointerup pointercancel" : EVENT_TOUCH_END;
var EVENT_RESIZE = "resize";
var EVENT_TRANSITION_END = "transitionend";
var EVENT_WHEEL = "wheel";
var EVENT_READY = "ready";
var EVENT_SHOW = "show";
var EVENT_SHOWN = "shown";
var EVENT_HIDE = "hide";
var EVENT_HIDDEN = "hidden";
var EVENT_VIEW = "view";
var EVENT_VIEWED = "viewed";
var EVENT_MOVE = "move";
var EVENT_MOVED = "moved";
var EVENT_ROTATE = "rotate";
var EVENT_ROTATED = "rotated";
var EVENT_SCALE = "scale";
var EVENT_SCALED = "scaled";
var EVENT_ZOOM = "zoom";
var EVENT_ZOOMED = "zoomed";
var EVENT_PLAY = "play";
var EVENT_STOP = "stop";
var DATA_ACTION = "".concat(NAMESPACE, "Action");
var REGEXP_SPACES = /\s\s*/;
var BUTTONS = ["zoom-in", "zoom-out", "one-to-one", "reset", "prev", "play", "next", "rotate-left", "rotate-right", "flip-horizontal", "flip-vertical"];
function isString(value) {
  return typeof value === "string";
}
var isNaN = Number.isNaN || WINDOW.isNaN;
function isNumber(value) {
  return typeof value === "number" && !isNaN(value);
}
function isUndefined(value) {
  return typeof value === "undefined";
}
function isObject(value) {
  return _typeof(value) === "object" && value !== null;
}
var hasOwnProperty = Object.prototype.hasOwnProperty;
function isPlainObject(value) {
  if (!isObject(value)) {
    return false;
  }
  try {
    var _constructor = value.constructor;
    var prototype = _constructor.prototype;
    return _constructor && prototype && hasOwnProperty.call(prototype, "isPrototypeOf");
  } catch (error) {
    return false;
  }
}
function isFunction(value) {
  return typeof value === "function";
}
function forEach(data, callback) {
  if (data && isFunction(callback)) {
    if (Array.isArray(data) || isNumber(data.length)) {
      var length = data.length;
      var i;
      for (i = 0; i < length; i += 1) {
        if (callback.call(data, data[i], i, data) === false) {
          break;
        }
      }
    } else if (isObject(data)) {
      Object.keys(data).forEach(function(key) {
        callback.call(data, data[key], key, data);
      });
    }
  }
  return data;
}
var assign = Object.assign || function assign2(obj) {
  for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
    args[_key - 1] = arguments[_key];
  }
  if (isObject(obj) && args.length > 0) {
    args.forEach(function(arg) {
      if (isObject(arg)) {
        Object.keys(arg).forEach(function(key) {
          obj[key] = arg[key];
        });
      }
    });
  }
  return obj;
};
var REGEXP_SUFFIX = /^(?:width|height|left|top|marginLeft|marginTop)$/;
function setStyle(element, styles) {
  var style = element.style;
  forEach(styles, function(value, property) {
    if (REGEXP_SUFFIX.test(property) && isNumber(value)) {
      value += "px";
    }
    style[property] = value;
  });
}
function escapeHTMLEntities(value) {
  return isString(value) ? value.replace(/&(?!amp;|quot;|#39;|lt;|gt;)/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&#39;").replace(/</g, "&lt;").replace(/>/g, "&gt;") : value;
}
function hasClass(element, value) {
  if (!element || !value) {
    return false;
  }
  return element.classList ? element.classList.contains(value) : element.className.indexOf(value) > -1;
}
function addClass(element, value) {
  if (!element || !value) {
    return;
  }
  if (isNumber(element.length)) {
    forEach(element, function(elem) {
      addClass(elem, value);
    });
    return;
  }
  if (element.classList) {
    element.classList.add(value);
    return;
  }
  var className = element.className.trim();
  if (!className) {
    element.className = value;
  } else if (className.indexOf(value) < 0) {
    element.className = "".concat(className, " ").concat(value);
  }
}
function removeClass(element, value) {
  if (!element || !value) {
    return;
  }
  if (isNumber(element.length)) {
    forEach(element, function(elem) {
      removeClass(elem, value);
    });
    return;
  }
  if (element.classList) {
    element.classList.remove(value);
    return;
  }
  if (element.className.indexOf(value) >= 0) {
    element.className = element.className.replace(value, "");
  }
}
function toggleClass(element, value, added) {
  if (!value) {
    return;
  }
  if (isNumber(element.length)) {
    forEach(element, function(elem) {
      toggleClass(elem, value, added);
    });
    return;
  }
  if (added) {
    addClass(element, value);
  } else {
    removeClass(element, value);
  }
}
var REGEXP_HYPHENATE = /([a-z\d])([A-Z])/g;
function hyphenate(value) {
  return value.replace(REGEXP_HYPHENATE, "$1-$2").toLowerCase();
}
function getData(element, name) {
  if (isObject(element[name])) {
    return element[name];
  }
  if (element.dataset) {
    return element.dataset[name];
  }
  return element.getAttribute("data-".concat(hyphenate(name)));
}
function setData(element, name, data) {
  if (isObject(data)) {
    element[name] = data;
  } else if (element.dataset) {
    element.dataset[name] = data;
  } else {
    element.setAttribute("data-".concat(hyphenate(name)), data);
  }
}
var onceSupported = function() {
  var supported = false;
  if (IS_BROWSER) {
    var once = false;
    var listener = function listener2() {
    };
    var options = Object.defineProperty({}, "once", {
      get: function get() {
        supported = true;
        return once;
      },
      set: function set(value) {
        once = value;
      }
    });
    WINDOW.addEventListener("test", listener, options);
    WINDOW.removeEventListener("test", listener, options);
  }
  return supported;
}();
function removeListener(element, type, listener) {
  var options = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : {};
  var handler = listener;
  type.trim().split(REGEXP_SPACES).forEach(function(event) {
    if (!onceSupported) {
      var listeners = element.listeners;
      if (listeners && listeners[event] && listeners[event][listener]) {
        handler = listeners[event][listener];
        delete listeners[event][listener];
        if (Object.keys(listeners[event]).length === 0) {
          delete listeners[event];
        }
        if (Object.keys(listeners).length === 0) {
          delete element.listeners;
        }
      }
    }
    element.removeEventListener(event, handler, options);
  });
}
function addListener(element, type, listener) {
  var options = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : {};
  var _handler = listener;
  type.trim().split(REGEXP_SPACES).forEach(function(event) {
    if (options.once && !onceSupported) {
      var _element$listeners = element.listeners, listeners = _element$listeners === void 0 ? {} : _element$listeners;
      _handler = function handler() {
        delete listeners[event][listener];
        element.removeEventListener(event, _handler, options);
        for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
          args[_key2] = arguments[_key2];
        }
        listener.apply(element, args);
      };
      if (!listeners[event]) {
        listeners[event] = {};
      }
      if (listeners[event][listener]) {
        element.removeEventListener(event, listeners[event][listener], options);
      }
      listeners[event][listener] = _handler;
      element.listeners = listeners;
    }
    element.addEventListener(event, _handler, options);
  });
}
function dispatchEvent(element, type, data, options) {
  var event;
  if (isFunction(Event) && isFunction(CustomEvent)) {
    event = new CustomEvent(type, _objectSpread2({
      bubbles: true,
      cancelable: true,
      detail: data
    }, options));
  } else {
    event = document.createEvent("CustomEvent");
    event.initCustomEvent(type, true, true, data);
  }
  return element.dispatchEvent(event);
}
function getOffset(element) {
  var box = element.getBoundingClientRect();
  return {
    left: box.left + (window.pageXOffset - document.documentElement.clientLeft),
    top: box.top + (window.pageYOffset - document.documentElement.clientTop)
  };
}
function getTransforms(_ref) {
  var rotate2 = _ref.rotate, scaleX2 = _ref.scaleX, scaleY2 = _ref.scaleY, translateX = _ref.translateX, translateY = _ref.translateY;
  var values = [];
  if (isNumber(translateX) && translateX !== 0) {
    values.push("translateX(".concat(translateX, "px)"));
  }
  if (isNumber(translateY) && translateY !== 0) {
    values.push("translateY(".concat(translateY, "px)"));
  }
  if (isNumber(rotate2) && rotate2 !== 0) {
    values.push("rotate(".concat(rotate2, "deg)"));
  }
  if (isNumber(scaleX2) && scaleX2 !== 1) {
    values.push("scaleX(".concat(scaleX2, ")"));
  }
  if (isNumber(scaleY2) && scaleY2 !== 1) {
    values.push("scaleY(".concat(scaleY2, ")"));
  }
  var transform = values.length ? values.join(" ") : "none";
  return {
    WebkitTransform: transform,
    msTransform: transform,
    transform
  };
}
function getImageNameFromURL(url) {
  return isString(url) ? decodeURIComponent(url.replace(/^.*\//, "").replace(/[?&#].*$/, "")) : "";
}
var IS_SAFARI = WINDOW.navigator && /(Macintosh|iPhone|iPod|iPad).*AppleWebKit/i.test(WINDOW.navigator.userAgent);
function getImageNaturalSizes(image, options, callback) {
  var newImage = document.createElement("img");
  if (image.naturalWidth && !IS_SAFARI) {
    callback(image.naturalWidth, image.naturalHeight);
    return newImage;
  }
  var body = document.body || document.documentElement;
  newImage.onload = function() {
    callback(newImage.width, newImage.height);
    if (!IS_SAFARI) {
      body.removeChild(newImage);
    }
  };
  forEach(options.inheritedAttributes, function(name) {
    var value = image.getAttribute(name);
    if (value !== null) {
      newImage.setAttribute(name, value);
    }
  });
  newImage.src = image.src;
  if (!IS_SAFARI) {
    newImage.style.cssText = "left:0;max-height:none!important;max-width:none!important;min-height:0!important;min-width:0!important;opacity:0;position:absolute;top:0;z-index:-1;";
    body.appendChild(newImage);
  }
  return newImage;
}
function getResponsiveClass(type) {
  switch (type) {
    case 2:
      return CLASS_HIDE_XS_DOWN;
    case 3:
      return CLASS_HIDE_SM_DOWN;
    case 4:
      return CLASS_HIDE_MD_DOWN;
    default:
      return "";
  }
}
function getMaxZoomRatio(pointers) {
  var pointers2 = _objectSpread2({}, pointers);
  var ratios = [];
  forEach(pointers, function(pointer, pointerId) {
    delete pointers2[pointerId];
    forEach(pointers2, function(pointer2) {
      var x1 = Math.abs(pointer.startX - pointer2.startX);
      var y1 = Math.abs(pointer.startY - pointer2.startY);
      var x2 = Math.abs(pointer.endX - pointer2.endX);
      var y2 = Math.abs(pointer.endY - pointer2.endY);
      var z1 = Math.sqrt(x1 * x1 + y1 * y1);
      var z2 = Math.sqrt(x2 * x2 + y2 * y2);
      var ratio = (z2 - z1) / z1;
      ratios.push(ratio);
    });
  });
  ratios.sort(function(a, b) {
    return Math.abs(a) < Math.abs(b);
  });
  return ratios[0];
}
function getPointer(_ref2, endOnly) {
  var pageX = _ref2.pageX, pageY = _ref2.pageY;
  var end = {
    endX: pageX,
    endY: pageY
  };
  return endOnly ? end : _objectSpread2({
    timeStamp: Date.now(),
    startX: pageX,
    startY: pageY
  }, end);
}
function getPointersCenter(pointers) {
  var pageX = 0;
  var pageY = 0;
  var count = 0;
  forEach(pointers, function(_ref3) {
    var startX = _ref3.startX, startY = _ref3.startY;
    pageX += startX;
    pageY += startY;
    count += 1;
  });
  pageX /= count;
  pageY /= count;
  return {
    pageX,
    pageY
  };
}
var render = {
  render: function render2() {
    this.initContainer();
    this.initViewer();
    this.initList();
    this.renderViewer();
  },
  initBody: function initBody() {
    var ownerDocument = this.element.ownerDocument;
    var body = ownerDocument.body || ownerDocument.documentElement;
    this.body = body;
    this.scrollbarWidth = window.innerWidth - ownerDocument.documentElement.clientWidth;
    this.initialBodyPaddingRight = body.style.paddingRight;
    this.initialBodyComputedPaddingRight = window.getComputedStyle(body).paddingRight;
  },
  initContainer: function initContainer() {
    this.containerData = {
      width: window.innerWidth,
      height: window.innerHeight
    };
  },
  initViewer: function initViewer() {
    var options = this.options, parent = this.parent;
    var viewerData;
    if (options.inline) {
      viewerData = {
        width: Math.max(parent.offsetWidth, options.minWidth),
        height: Math.max(parent.offsetHeight, options.minHeight)
      };
      this.parentData = viewerData;
    }
    if (this.fulled || !viewerData) {
      viewerData = this.containerData;
    }
    this.viewerData = assign({}, viewerData);
  },
  renderViewer: function renderViewer() {
    if (this.options.inline && !this.fulled) {
      setStyle(this.viewer, this.viewerData);
    }
  },
  initList: function initList() {
    var _this = this;
    var element = this.element, options = this.options, list = this.list;
    var items = [];
    list.innerHTML = "";
    forEach(this.images, function(image, index) {
      var src = image.src;
      var alt = image.alt || getImageNameFromURL(src);
      var url = _this.getImageURL(image);
      if (src || url) {
        var item = document.createElement("li");
        var img = document.createElement("img");
        forEach(options.inheritedAttributes, function(name) {
          var value = image.getAttribute(name);
          if (value !== null) {
            img.setAttribute(name, value);
          }
        });
        if (options.navbar) {
          img.src = src || url;
        }
        img.alt = alt;
        img.setAttribute("data-original-url", url || src);
        item.setAttribute("data-index", index);
        item.setAttribute("data-viewer-action", "view");
        item.setAttribute("role", "button");
        if (options.keyboard) {
          item.setAttribute("tabindex", 0);
        }
        item.appendChild(img);
        list.appendChild(item);
        items.push(item);
      }
    });
    this.items = items;
    forEach(items, function(item) {
      var image = item.firstElementChild;
      var onLoad;
      var onError;
      setData(image, "filled", true);
      if (options.loading) {
        addClass(item, CLASS_LOADING);
      }
      addListener(image, EVENT_LOAD, onLoad = function onLoad2(event) {
        removeListener(image, EVENT_ERROR, onError);
        if (options.loading) {
          removeClass(item, CLASS_LOADING);
        }
        _this.loadImage(event);
      }, {
        once: true
      });
      addListener(image, EVENT_ERROR, onError = function onError2() {
        removeListener(image, EVENT_LOAD, onLoad);
        if (options.loading) {
          removeClass(item, CLASS_LOADING);
        }
      }, {
        once: true
      });
    });
    if (options.transition) {
      addListener(element, EVENT_VIEWED, function() {
        addClass(list, CLASS_TRANSITION);
      }, {
        once: true
      });
    }
  },
  renderList: function renderList() {
    var index = this.index;
    var item = this.items[index];
    if (!item) {
      return;
    }
    var next2 = item.nextElementSibling;
    var gutter = parseInt(window.getComputedStyle(next2 || item).marginLeft, 10);
    var offsetWidth = item.offsetWidth;
    var outerWidth = offsetWidth + gutter;
    setStyle(this.list, assign({
      width: outerWidth * this.length - gutter
    }, getTransforms({
      translateX: (this.viewerData.width - offsetWidth) / 2 - outerWidth * index
    })));
  },
  resetList: function resetList() {
    var list = this.list;
    list.innerHTML = "";
    removeClass(list, CLASS_TRANSITION);
    setStyle(list, getTransforms({
      translateX: 0
    }));
  },
  initImage: function initImage(done) {
    var _this2 = this;
    var options = this.options, image = this.image, viewerData = this.viewerData;
    var footerHeight = this.footer.offsetHeight;
    var viewerWidth = viewerData.width;
    var viewerHeight = Math.max(viewerData.height - footerHeight, footerHeight);
    var oldImageData = this.imageData || {};
    var sizingImage;
    this.imageInitializing = {
      abort: function abort() {
        sizingImage.onload = null;
      }
    };
    sizingImage = getImageNaturalSizes(image, options, function(naturalWidth, naturalHeight) {
      var aspectRatio = naturalWidth / naturalHeight;
      var initialCoverage = Math.max(0, Math.min(1, options.initialCoverage));
      var width = viewerWidth;
      var height = viewerHeight;
      _this2.imageInitializing = false;
      if (viewerHeight * aspectRatio > viewerWidth) {
        height = viewerWidth / aspectRatio;
      } else {
        width = viewerHeight * aspectRatio;
      }
      initialCoverage = isNumber(initialCoverage) ? initialCoverage : 0.9;
      width = Math.min(width * initialCoverage, naturalWidth);
      height = Math.min(height * initialCoverage, naturalHeight);
      var left = (viewerWidth - width) / 2;
      var top = (viewerHeight - height) / 2;
      var imageData = {
        left,
        top,
        x: left,
        y: top,
        width,
        height,
        oldRatio: 1,
        ratio: width / naturalWidth,
        aspectRatio,
        naturalWidth,
        naturalHeight
      };
      var initialImageData = assign({}, imageData);
      if (options.rotatable) {
        imageData.rotate = oldImageData.rotate || 0;
        initialImageData.rotate = 0;
      }
      if (options.scalable) {
        imageData.scaleX = oldImageData.scaleX || 1;
        imageData.scaleY = oldImageData.scaleY || 1;
        initialImageData.scaleX = 1;
        initialImageData.scaleY = 1;
      }
      _this2.imageData = imageData;
      _this2.initialImageData = initialImageData;
      if (done) {
        done();
      }
    });
  },
  renderImage: function renderImage(done) {
    var _this3 = this;
    var image = this.image, imageData = this.imageData;
    setStyle(image, assign({
      width: imageData.width,
      height: imageData.height,
      marginLeft: imageData.x,
      marginTop: imageData.y
    }, getTransforms(imageData)));
    if (done) {
      if ((this.viewing || this.moving || this.rotating || this.scaling || this.zooming) && this.options.transition && hasClass(image, CLASS_TRANSITION)) {
        var onTransitionEnd = function onTransitionEnd2() {
          _this3.imageRendering = false;
          done();
        };
        this.imageRendering = {
          abort: function abort() {
            removeListener(image, EVENT_TRANSITION_END, onTransitionEnd);
          }
        };
        addListener(image, EVENT_TRANSITION_END, onTransitionEnd, {
          once: true
        });
      } else {
        done();
      }
    }
  },
  resetImage: function resetImage() {
    if (this.viewing || this.viewed) {
      var image = this.image;
      if (this.viewing) {
        this.viewing.abort();
      }
      image.parentNode.removeChild(image);
      this.image = null;
    }
  }
};
var events = {
  bind: function bind() {
    var options = this.options, viewer = this.viewer, canvas = this.canvas;
    var document2 = this.element.ownerDocument;
    addListener(viewer, EVENT_CLICK, this.onClick = this.click.bind(this));
    addListener(viewer, EVENT_DRAG_START, this.onDragStart = this.dragstart.bind(this));
    addListener(canvas, EVENT_POINTER_DOWN, this.onPointerDown = this.pointerdown.bind(this));
    addListener(document2, EVENT_POINTER_MOVE, this.onPointerMove = this.pointermove.bind(this));
    addListener(document2, EVENT_POINTER_UP, this.onPointerUp = this.pointerup.bind(this));
    addListener(document2, EVENT_KEY_DOWN, this.onKeyDown = this.keydown.bind(this));
    addListener(window, EVENT_RESIZE, this.onResize = this.resize.bind(this));
    if (options.zoomable && options.zoomOnWheel) {
      addListener(viewer, EVENT_WHEEL, this.onWheel = this.wheel.bind(this), {
        passive: false,
        capture: true
      });
    }
    if (options.toggleOnDblclick) {
      addListener(canvas, EVENT_DBLCLICK, this.onDblclick = this.dblclick.bind(this));
    }
  },
  unbind: function unbind() {
    var options = this.options, viewer = this.viewer, canvas = this.canvas;
    var document2 = this.element.ownerDocument;
    removeListener(viewer, EVENT_CLICK, this.onClick);
    removeListener(viewer, EVENT_DRAG_START, this.onDragStart);
    removeListener(canvas, EVENT_POINTER_DOWN, this.onPointerDown);
    removeListener(document2, EVENT_POINTER_MOVE, this.onPointerMove);
    removeListener(document2, EVENT_POINTER_UP, this.onPointerUp);
    removeListener(document2, EVENT_KEY_DOWN, this.onKeyDown);
    removeListener(window, EVENT_RESIZE, this.onResize);
    if (options.zoomable && options.zoomOnWheel) {
      removeListener(viewer, EVENT_WHEEL, this.onWheel, {
        passive: false,
        capture: true
      });
    }
    if (options.toggleOnDblclick) {
      removeListener(canvas, EVENT_DBLCLICK, this.onDblclick);
    }
  }
};
var handlers = {
  click: function click(event) {
    var options = this.options, imageData = this.imageData;
    var target = event.target;
    var action = getData(target, DATA_ACTION);
    if (!action && target.localName === "img" && target.parentElement.localName === "li") {
      target = target.parentElement;
      action = getData(target, DATA_ACTION);
    }
    if (IS_TOUCH_DEVICE && event.isTrusted && target === this.canvas) {
      clearTimeout(this.clickCanvasTimeout);
    }
    switch (action) {
      case "mix":
        if (this.played) {
          this.stop();
        } else if (options.inline) {
          if (this.fulled) {
            this.exit();
          } else {
            this.full();
          }
        } else {
          this.hide();
        }
        break;
      case "hide":
        if (!this.pointerMoved) {
          this.hide();
        }
        break;
      case "view":
        this.view(getData(target, "index"));
        break;
      case "zoom-in":
        this.zoom(0.1, true);
        break;
      case "zoom-out":
        this.zoom(-0.1, true);
        break;
      case "one-to-one":
        this.toggle();
        break;
      case "reset":
        this.reset();
        break;
      case "prev":
        this.prev(options.loop);
        break;
      case "play":
        this.play(options.fullscreen);
        break;
      case "next":
        this.next(options.loop);
        break;
      case "rotate-left":
        this.rotate(-90);
        break;
      case "rotate-right":
        this.rotate(90);
        break;
      case "flip-horizontal":
        this.scaleX(-imageData.scaleX || -1);
        break;
      case "flip-vertical":
        this.scaleY(-imageData.scaleY || -1);
        break;
      default:
        if (this.played) {
          this.stop();
        }
    }
  },
  dblclick: function dblclick(event) {
    event.preventDefault();
    if (this.viewed && event.target === this.image) {
      if (IS_TOUCH_DEVICE && event.isTrusted) {
        clearTimeout(this.doubleClickImageTimeout);
      }
      this.toggle(event.isTrusted ? event : event.detail && event.detail.originalEvent);
    }
  },
  load: function load() {
    var _this = this;
    if (this.timeout) {
      clearTimeout(this.timeout);
      this.timeout = false;
    }
    var element = this.element, options = this.options, image = this.image, index = this.index, viewerData = this.viewerData;
    removeClass(image, CLASS_INVISIBLE);
    if (options.loading) {
      removeClass(this.canvas, CLASS_LOADING);
    }
    image.style.cssText = "height:0;" + "margin-left:".concat(viewerData.width / 2, "px;") + "margin-top:".concat(viewerData.height / 2, "px;") + "max-width:none!important;position:relative;width:0;";
    this.initImage(function() {
      toggleClass(image, CLASS_MOVE, options.movable);
      toggleClass(image, CLASS_TRANSITION, options.transition);
      _this.renderImage(function() {
        _this.viewed = true;
        _this.viewing = false;
        if (isFunction(options.viewed)) {
          addListener(element, EVENT_VIEWED, options.viewed, {
            once: true
          });
        }
        dispatchEvent(element, EVENT_VIEWED, {
          originalImage: _this.images[index],
          index,
          image
        }, {
          cancelable: false
        });
      });
    });
  },
  loadImage: function loadImage(event) {
    var image = event.target;
    var parent = image.parentNode;
    var parentWidth = parent.offsetWidth || 30;
    var parentHeight = parent.offsetHeight || 50;
    var filled = !!getData(image, "filled");
    getImageNaturalSizes(image, this.options, function(naturalWidth, naturalHeight) {
      var aspectRatio = naturalWidth / naturalHeight;
      var width = parentWidth;
      var height = parentHeight;
      if (parentHeight * aspectRatio > parentWidth) {
        if (filled) {
          width = parentHeight * aspectRatio;
        } else {
          height = parentWidth / aspectRatio;
        }
      } else if (filled) {
        height = parentWidth / aspectRatio;
      } else {
        width = parentHeight * aspectRatio;
      }
      setStyle(image, assign({
        width,
        height
      }, getTransforms({
        translateX: (parentWidth - width) / 2,
        translateY: (parentHeight - height) / 2
      })));
    });
  },
  keydown: function keydown(event) {
    var options = this.options;
    if (!options.keyboard) {
      return;
    }
    var keyCode = event.keyCode || event.which || event.charCode;
    switch (keyCode) {
      case 13:
        if (this.viewer.contains(event.target)) {
          this.click(event);
        }
        break;
    }
    if (!this.fulled) {
      return;
    }
    switch (keyCode) {
      case 27:
        if (this.played) {
          this.stop();
        } else if (options.inline) {
          if (this.fulled) {
            this.exit();
          }
        } else {
          this.hide();
        }
        break;
      case 32:
        if (this.played) {
          this.stop();
        }
        break;
      case 37:
        if (this.played && this.playing) {
          this.playing.prev();
        } else {
          this.prev(options.loop);
        }
        break;
      case 38:
        event.preventDefault();
        this.zoom(options.zoomRatio, true);
        break;
      case 39:
        if (this.played && this.playing) {
          this.playing.next();
        } else {
          this.next(options.loop);
        }
        break;
      case 40:
        event.preventDefault();
        this.zoom(-options.zoomRatio, true);
        break;
      case 48:
      case 49:
        if (event.ctrlKey) {
          event.preventDefault();
          this.toggle();
        }
        break;
    }
  },
  dragstart: function dragstart(event) {
    if (event.target.localName === "img") {
      event.preventDefault();
    }
  },
  pointerdown: function pointerdown(event) {
    var options = this.options, pointers = this.pointers;
    var buttons = event.buttons, button = event.button;
    this.pointerMoved = false;
    if (!this.viewed || this.showing || this.viewing || this.hiding || (event.type === "mousedown" || event.type === "pointerdown" && event.pointerType === "mouse") && (isNumber(buttons) && buttons !== 1 || isNumber(button) && button !== 0 || event.ctrlKey)) {
      return;
    }
    event.preventDefault();
    if (event.changedTouches) {
      forEach(event.changedTouches, function(touch) {
        pointers[touch.identifier] = getPointer(touch);
      });
    } else {
      pointers[event.pointerId || 0] = getPointer(event);
    }
    var action = options.movable ? ACTION_MOVE : false;
    if (options.zoomOnTouch && options.zoomable && Object.keys(pointers).length > 1) {
      action = ACTION_ZOOM;
    } else if (options.slideOnTouch && (event.pointerType === "touch" || event.type === "touchstart") && this.isSwitchable()) {
      action = ACTION_SWITCH;
    }
    if (options.transition && (action === ACTION_MOVE || action === ACTION_ZOOM)) {
      removeClass(this.image, CLASS_TRANSITION);
    }
    this.action = action;
  },
  pointermove: function pointermove(event) {
    var pointers = this.pointers, action = this.action;
    if (!this.viewed || !action) {
      return;
    }
    event.preventDefault();
    if (event.changedTouches) {
      forEach(event.changedTouches, function(touch) {
        assign(pointers[touch.identifier] || {}, getPointer(touch, true));
      });
    } else {
      assign(pointers[event.pointerId || 0] || {}, getPointer(event, true));
    }
    this.change(event);
  },
  pointerup: function pointerup(event) {
    var _this2 = this;
    var options = this.options, action = this.action, pointers = this.pointers;
    var pointer;
    if (event.changedTouches) {
      forEach(event.changedTouches, function(touch) {
        pointer = pointers[touch.identifier];
        delete pointers[touch.identifier];
      });
    } else {
      pointer = pointers[event.pointerId || 0];
      delete pointers[event.pointerId || 0];
    }
    if (!action) {
      return;
    }
    event.preventDefault();
    if (options.transition && (action === ACTION_MOVE || action === ACTION_ZOOM)) {
      addClass(this.image, CLASS_TRANSITION);
    }
    this.action = false;
    if (IS_TOUCH_DEVICE && action !== ACTION_ZOOM && pointer && Date.now() - pointer.timeStamp < 500) {
      clearTimeout(this.clickCanvasTimeout);
      clearTimeout(this.doubleClickImageTimeout);
      if (options.toggleOnDblclick && this.viewed && event.target === this.image) {
        if (this.imageClicked) {
          this.imageClicked = false;
          this.doubleClickImageTimeout = setTimeout(function() {
            dispatchEvent(_this2.image, EVENT_DBLCLICK, {
              originalEvent: event
            });
          }, 50);
        } else {
          this.imageClicked = true;
          this.doubleClickImageTimeout = setTimeout(function() {
            _this2.imageClicked = false;
          }, 500);
        }
      } else {
        this.imageClicked = false;
        if (options.backdrop && options.backdrop !== "static" && event.target === this.canvas) {
          this.clickCanvasTimeout = setTimeout(function() {
            dispatchEvent(_this2.canvas, EVENT_CLICK, {
              originalEvent: event
            });
          }, 50);
        }
      }
    }
  },
  resize: function resize() {
    var _this3 = this;
    if (!this.isShown || this.hiding) {
      return;
    }
    if (this.fulled) {
      this.close();
      this.initBody();
      this.open();
    }
    this.initContainer();
    this.initViewer();
    this.renderViewer();
    this.renderList();
    if (this.viewed) {
      this.initImage(function() {
        _this3.renderImage();
      });
    }
    if (this.played) {
      if (this.options.fullscreen && this.fulled && !(document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement)) {
        this.stop();
        return;
      }
      forEach(this.player.getElementsByTagName("img"), function(image) {
        addListener(image, EVENT_LOAD, _this3.loadImage.bind(_this3), {
          once: true
        });
        dispatchEvent(image, EVENT_LOAD);
      });
    }
  },
  wheel: function wheel(event) {
    var _this4 = this;
    if (!this.viewed) {
      return;
    }
    event.preventDefault();
    if (this.wheeling) {
      return;
    }
    this.wheeling = true;
    setTimeout(function() {
      _this4.wheeling = false;
    }, 50);
    var ratio = Number(this.options.zoomRatio) || 0.1;
    var delta = 1;
    if (event.deltaY) {
      delta = event.deltaY > 0 ? 1 : -1;
    } else if (event.wheelDelta) {
      delta = -event.wheelDelta / 120;
    } else if (event.detail) {
      delta = event.detail > 0 ? 1 : -1;
    }
    this.zoom(-delta * ratio, true, null, event);
  }
};
var methods = {
  show: function show() {
    var immediate = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : false;
    var element = this.element, options = this.options;
    if (options.inline || this.showing || this.isShown || this.showing) {
      return this;
    }
    if (!this.ready) {
      this.build();
      if (this.ready) {
        this.show(immediate);
      }
      return this;
    }
    if (isFunction(options.show)) {
      addListener(element, EVENT_SHOW, options.show, {
        once: true
      });
    }
    if (dispatchEvent(element, EVENT_SHOW) === false || !this.ready) {
      return this;
    }
    if (this.hiding) {
      this.transitioning.abort();
    }
    this.showing = true;
    this.open();
    var viewer = this.viewer;
    removeClass(viewer, CLASS_HIDE);
    viewer.setAttribute("role", "dialog");
    viewer.setAttribute("aria-labelledby", this.title.id);
    viewer.setAttribute("aria-modal", true);
    viewer.removeAttribute("aria-hidden");
    if (options.transition && !immediate) {
      var shown2 = this.shown.bind(this);
      this.transitioning = {
        abort: function abort() {
          removeListener(viewer, EVENT_TRANSITION_END, shown2);
          removeClass(viewer, CLASS_IN);
        }
      };
      addClass(viewer, CLASS_TRANSITION);
      viewer.initialOffsetWidth = viewer.offsetWidth;
      addListener(viewer, EVENT_TRANSITION_END, shown2, {
        once: true
      });
      addClass(viewer, CLASS_IN);
    } else {
      addClass(viewer, CLASS_IN);
      this.shown();
    }
    return this;
  },
  hide: function hide() {
    var _this = this;
    var immediate = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : false;
    var element = this.element, options = this.options;
    if (options.inline || this.hiding || !(this.isShown || this.showing)) {
      return this;
    }
    if (isFunction(options.hide)) {
      addListener(element, EVENT_HIDE, options.hide, {
        once: true
      });
    }
    if (dispatchEvent(element, EVENT_HIDE) === false) {
      return this;
    }
    if (this.showing) {
      this.transitioning.abort();
    }
    this.hiding = true;
    if (this.played) {
      this.stop();
    } else if (this.viewing) {
      this.viewing.abort();
    }
    var viewer = this.viewer, image = this.image;
    var hideImmediately = function hideImmediately2() {
      removeClass(viewer, CLASS_IN);
      _this.hidden();
    };
    if (options.transition && !immediate) {
      var onViewerTransitionEnd = function onViewerTransitionEnd2(event) {
        if (event && event.target === viewer) {
          removeListener(viewer, EVENT_TRANSITION_END, onViewerTransitionEnd2);
          _this.hidden();
        }
      };
      var onImageTransitionEnd = function onImageTransitionEnd2() {
        if (hasClass(viewer, CLASS_TRANSITION)) {
          addListener(viewer, EVENT_TRANSITION_END, onViewerTransitionEnd);
          removeClass(viewer, CLASS_IN);
        } else {
          hideImmediately();
        }
      };
      this.transitioning = {
        abort: function abort() {
          if (_this.viewed && hasClass(image, CLASS_TRANSITION)) {
            removeListener(image, EVENT_TRANSITION_END, onImageTransitionEnd);
          } else if (hasClass(viewer, CLASS_TRANSITION)) {
            removeListener(viewer, EVENT_TRANSITION_END, onViewerTransitionEnd);
          }
        }
      };
      if (this.viewed && hasClass(image, CLASS_TRANSITION)) {
        addListener(image, EVENT_TRANSITION_END, onImageTransitionEnd, {
          once: true
        });
        this.zoomTo(0, false, null, null, true);
      } else {
        onImageTransitionEnd();
      }
    } else {
      hideImmediately();
    }
    return this;
  },
  view: function view() {
    var _this2 = this;
    var index = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : this.options.initialViewIndex;
    index = Number(index) || 0;
    if (this.hiding || this.played || index < 0 || index >= this.length || this.viewed && index === this.index) {
      return this;
    }
    if (!this.isShown) {
      this.index = index;
      return this.show();
    }
    if (this.viewing) {
      this.viewing.abort();
    }
    var element = this.element, options = this.options, title = this.title, canvas = this.canvas;
    var item = this.items[index];
    var img = item.querySelector("img");
    var url = getData(img, "originalUrl");
    var alt = img.getAttribute("alt");
    var image = document.createElement("img");
    forEach(options.inheritedAttributes, function(name) {
      var value = img.getAttribute(name);
      if (value !== null) {
        image.setAttribute(name, value);
      }
    });
    image.src = url;
    image.alt = alt;
    if (isFunction(options.view)) {
      addListener(element, EVENT_VIEW, options.view, {
        once: true
      });
    }
    if (dispatchEvent(element, EVENT_VIEW, {
      originalImage: this.images[index],
      index,
      image
    }) === false || !this.isShown || this.hiding || this.played) {
      return this;
    }
    var activeItem = this.items[this.index];
    if (activeItem) {
      removeClass(activeItem, CLASS_ACTIVE);
      activeItem.removeAttribute("aria-selected");
    }
    addClass(item, CLASS_ACTIVE);
    item.setAttribute("aria-selected", true);
    if (options.focus) {
      item.focus();
    }
    this.image = image;
    this.viewed = false;
    this.index = index;
    this.imageData = {};
    addClass(image, CLASS_INVISIBLE);
    if (options.loading) {
      addClass(canvas, CLASS_LOADING);
    }
    canvas.innerHTML = "";
    canvas.appendChild(image);
    this.renderList();
    title.innerHTML = "";
    var onViewed = function onViewed2() {
      var imageData = _this2.imageData;
      var render3 = Array.isArray(options.title) ? options.title[1] : options.title;
      title.innerHTML = escapeHTMLEntities(isFunction(render3) ? render3.call(_this2, image, imageData) : "".concat(alt, " (").concat(imageData.naturalWidth, " \xD7 ").concat(imageData.naturalHeight, ")"));
    };
    var onLoad;
    var onError;
    addListener(element, EVENT_VIEWED, onViewed, {
      once: true
    });
    this.viewing = {
      abort: function abort() {
        removeListener(element, EVENT_VIEWED, onViewed);
        if (image.complete) {
          if (_this2.imageRendering) {
            _this2.imageRendering.abort();
          } else if (_this2.imageInitializing) {
            _this2.imageInitializing.abort();
          }
        } else {
          image.src = "";
          removeListener(image, EVENT_LOAD, onLoad);
          if (_this2.timeout) {
            clearTimeout(_this2.timeout);
          }
        }
      }
    };
    if (image.complete) {
      this.load();
    } else {
      addListener(image, EVENT_LOAD, onLoad = function onLoad2() {
        removeListener(image, EVENT_ERROR, onError);
        _this2.load();
      }, {
        once: true
      });
      addListener(image, EVENT_ERROR, onError = function onError2() {
        removeListener(image, EVENT_LOAD, onLoad);
        if (_this2.timeout) {
          clearTimeout(_this2.timeout);
          _this2.timeout = false;
        }
        removeClass(image, CLASS_INVISIBLE);
        if (options.loading) {
          removeClass(_this2.canvas, CLASS_LOADING);
        }
      }, {
        once: true
      });
      if (this.timeout) {
        clearTimeout(this.timeout);
      }
      this.timeout = setTimeout(function() {
        removeClass(image, CLASS_INVISIBLE);
        _this2.timeout = false;
      }, 1e3);
    }
    return this;
  },
  prev: function prev() {
    var loop = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : false;
    var index = this.index - 1;
    if (index < 0) {
      index = loop ? this.length - 1 : 0;
    }
    this.view(index);
    return this;
  },
  next: function next() {
    var loop = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : false;
    var maxIndex = this.length - 1;
    var index = this.index + 1;
    if (index > maxIndex) {
      index = loop ? 0 : maxIndex;
    }
    this.view(index);
    return this;
  },
  move: function move(x) {
    var y = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : x;
    var imageData = this.imageData;
    this.moveTo(isUndefined(x) ? x : imageData.x + Number(x), isUndefined(y) ? y : imageData.y + Number(y));
    return this;
  },
  moveTo: function moveTo(x) {
    var _this3 = this;
    var y = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : x;
    var _originalEvent = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : null;
    var element = this.element, options = this.options, imageData = this.imageData;
    x = Number(x);
    y = Number(y);
    if (this.viewed && !this.played && options.movable) {
      var oldX = imageData.x;
      var oldY = imageData.y;
      var changed = false;
      if (isNumber(x)) {
        changed = true;
      } else {
        x = oldX;
      }
      if (isNumber(y)) {
        changed = true;
      } else {
        y = oldY;
      }
      if (changed) {
        if (isFunction(options.move)) {
          addListener(element, EVENT_MOVE, options.move, {
            once: true
          });
        }
        if (dispatchEvent(element, EVENT_MOVE, {
          x,
          y,
          oldX,
          oldY,
          originalEvent: _originalEvent
        }) === false) {
          return this;
        }
        imageData.x = x;
        imageData.y = y;
        imageData.left = x;
        imageData.top = y;
        this.moving = true;
        this.renderImage(function() {
          _this3.moving = false;
          if (isFunction(options.moved)) {
            addListener(element, EVENT_MOVED, options.moved, {
              once: true
            });
          }
          dispatchEvent(element, EVENT_MOVED, {
            x,
            y,
            oldX,
            oldY,
            originalEvent: _originalEvent
          }, {
            cancelable: false
          });
        });
      }
    }
    return this;
  },
  rotate: function rotate(degree) {
    this.rotateTo((this.imageData.rotate || 0) + Number(degree));
    return this;
  },
  rotateTo: function rotateTo(degree) {
    var _this4 = this;
    var element = this.element, options = this.options, imageData = this.imageData;
    degree = Number(degree);
    if (isNumber(degree) && this.viewed && !this.played && options.rotatable) {
      var oldDegree = imageData.rotate;
      if (isFunction(options.rotate)) {
        addListener(element, EVENT_ROTATE, options.rotate, {
          once: true
        });
      }
      if (dispatchEvent(element, EVENT_ROTATE, {
        degree,
        oldDegree
      }) === false) {
        return this;
      }
      imageData.rotate = degree;
      this.rotating = true;
      this.renderImage(function() {
        _this4.rotating = false;
        if (isFunction(options.rotated)) {
          addListener(element, EVENT_ROTATED, options.rotated, {
            once: true
          });
        }
        dispatchEvent(element, EVENT_ROTATED, {
          degree,
          oldDegree
        }, {
          cancelable: false
        });
      });
    }
    return this;
  },
  scaleX: function scaleX(_scaleX) {
    this.scale(_scaleX, this.imageData.scaleY);
    return this;
  },
  scaleY: function scaleY(_scaleY) {
    this.scale(this.imageData.scaleX, _scaleY);
    return this;
  },
  scale: function scale(scaleX2) {
    var _this5 = this;
    var scaleY2 = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : scaleX2;
    var element = this.element, options = this.options, imageData = this.imageData;
    scaleX2 = Number(scaleX2);
    scaleY2 = Number(scaleY2);
    if (this.viewed && !this.played && options.scalable) {
      var oldScaleX = imageData.scaleX;
      var oldScaleY = imageData.scaleY;
      var changed = false;
      if (isNumber(scaleX2)) {
        changed = true;
      } else {
        scaleX2 = oldScaleX;
      }
      if (isNumber(scaleY2)) {
        changed = true;
      } else {
        scaleY2 = oldScaleY;
      }
      if (changed) {
        if (isFunction(options.scale)) {
          addListener(element, EVENT_SCALE, options.scale, {
            once: true
          });
        }
        if (dispatchEvent(element, EVENT_SCALE, {
          scaleX: scaleX2,
          scaleY: scaleY2,
          oldScaleX,
          oldScaleY
        }) === false) {
          return this;
        }
        imageData.scaleX = scaleX2;
        imageData.scaleY = scaleY2;
        this.scaling = true;
        this.renderImage(function() {
          _this5.scaling = false;
          if (isFunction(options.scaled)) {
            addListener(element, EVENT_SCALED, options.scaled, {
              once: true
            });
          }
          dispatchEvent(element, EVENT_SCALED, {
            scaleX: scaleX2,
            scaleY: scaleY2,
            oldScaleX,
            oldScaleY
          }, {
            cancelable: false
          });
        });
      }
    }
    return this;
  },
  zoom: function zoom(ratio) {
    var showTooltip = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : false;
    var pivot = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : null;
    var _originalEvent = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : null;
    var imageData = this.imageData;
    ratio = Number(ratio);
    if (ratio < 0) {
      ratio = 1 / (1 - ratio);
    } else {
      ratio = 1 + ratio;
    }
    this.zoomTo(imageData.width * ratio / imageData.naturalWidth, showTooltip, pivot, _originalEvent);
    return this;
  },
  zoomTo: function zoomTo(ratio) {
    var _this6 = this;
    var showTooltip = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : false;
    var pivot = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : null;
    var _originalEvent = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : null;
    var _zoomable = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : false;
    var element = this.element, options = this.options, pointers = this.pointers, imageData = this.imageData;
    var x = imageData.x, y = imageData.y, width = imageData.width, height = imageData.height, naturalWidth = imageData.naturalWidth, naturalHeight = imageData.naturalHeight;
    ratio = Math.max(0, ratio);
    if (isNumber(ratio) && this.viewed && !this.played && (_zoomable || options.zoomable)) {
      if (!_zoomable) {
        var minZoomRatio = Math.max(0.01, options.minZoomRatio);
        var maxZoomRatio = Math.min(100, options.maxZoomRatio);
        ratio = Math.min(Math.max(ratio, minZoomRatio), maxZoomRatio);
      }
      if (_originalEvent) {
        switch (_originalEvent.type) {
          case "wheel":
            if (options.zoomRatio >= 0.055 && ratio > 0.95 && ratio < 1.05) {
              ratio = 1;
            }
            break;
          case "pointermove":
          case "touchmove":
          case "mousemove":
            if (ratio > 0.99 && ratio < 1.01) {
              ratio = 1;
            }
            break;
        }
      }
      var newWidth = naturalWidth * ratio;
      var newHeight = naturalHeight * ratio;
      var offsetWidth = newWidth - width;
      var offsetHeight = newHeight - height;
      var oldRatio = imageData.ratio;
      if (isFunction(options.zoom)) {
        addListener(element, EVENT_ZOOM, options.zoom, {
          once: true
        });
      }
      if (dispatchEvent(element, EVENT_ZOOM, {
        ratio,
        oldRatio,
        originalEvent: _originalEvent
      }) === false) {
        return this;
      }
      this.zooming = true;
      if (_originalEvent) {
        var offset = getOffset(this.viewer);
        var center = pointers && Object.keys(pointers).length > 0 ? getPointersCenter(pointers) : {
          pageX: _originalEvent.pageX,
          pageY: _originalEvent.pageY
        };
        imageData.x -= offsetWidth * ((center.pageX - offset.left - x) / width);
        imageData.y -= offsetHeight * ((center.pageY - offset.top - y) / height);
      } else if (isPlainObject(pivot) && isNumber(pivot.x) && isNumber(pivot.y)) {
        imageData.x -= offsetWidth * ((pivot.x - x) / width);
        imageData.y -= offsetHeight * ((pivot.y - y) / height);
      } else {
        imageData.x -= offsetWidth / 2;
        imageData.y -= offsetHeight / 2;
      }
      imageData.left = imageData.x;
      imageData.top = imageData.y;
      imageData.width = newWidth;
      imageData.height = newHeight;
      imageData.oldRatio = oldRatio;
      imageData.ratio = ratio;
      this.renderImage(function() {
        _this6.zooming = false;
        if (isFunction(options.zoomed)) {
          addListener(element, EVENT_ZOOMED, options.zoomed, {
            once: true
          });
        }
        dispatchEvent(element, EVENT_ZOOMED, {
          ratio,
          oldRatio,
          originalEvent: _originalEvent
        }, {
          cancelable: false
        });
      });
      if (showTooltip) {
        this.tooltip();
      }
    }
    return this;
  },
  play: function play() {
    var _this7 = this;
    var fullscreen = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : false;
    if (!this.isShown || this.played) {
      return this;
    }
    var element = this.element, options = this.options;
    if (isFunction(options.play)) {
      addListener(element, EVENT_PLAY, options.play, {
        once: true
      });
    }
    if (dispatchEvent(element, EVENT_PLAY) === false) {
      return this;
    }
    var player = this.player;
    var onLoad = this.loadImage.bind(this);
    var list = [];
    var total = 0;
    var index = 0;
    this.played = true;
    this.onLoadWhenPlay = onLoad;
    if (fullscreen) {
      this.requestFullscreen(fullscreen);
    }
    addClass(player, CLASS_SHOW);
    forEach(this.items, function(item, i) {
      var img = item.querySelector("img");
      var image = document.createElement("img");
      image.src = getData(img, "originalUrl");
      image.alt = img.getAttribute("alt");
      image.referrerPolicy = img.referrerPolicy;
      total += 1;
      addClass(image, CLASS_FADE);
      toggleClass(image, CLASS_TRANSITION, options.transition);
      if (hasClass(item, CLASS_ACTIVE)) {
        addClass(image, CLASS_IN);
        index = i;
      }
      list.push(image);
      addListener(image, EVENT_LOAD, onLoad, {
        once: true
      });
      player.appendChild(image);
    });
    if (isNumber(options.interval) && options.interval > 0) {
      var prev2 = function prev3() {
        clearTimeout(_this7.playing.timeout);
        removeClass(list[index], CLASS_IN);
        index -= 1;
        index = index >= 0 ? index : total - 1;
        addClass(list[index], CLASS_IN);
        _this7.playing.timeout = setTimeout(prev3, options.interval);
      };
      var next2 = function next3() {
        clearTimeout(_this7.playing.timeout);
        removeClass(list[index], CLASS_IN);
        index += 1;
        index = index < total ? index : 0;
        addClass(list[index], CLASS_IN);
        _this7.playing.timeout = setTimeout(next3, options.interval);
      };
      if (total > 1) {
        this.playing = {
          prev: prev2,
          next: next2,
          timeout: setTimeout(next2, options.interval)
        };
      }
    }
    return this;
  },
  stop: function stop() {
    var _this8 = this;
    if (!this.played) {
      return this;
    }
    var element = this.element, options = this.options;
    if (isFunction(options.stop)) {
      addListener(element, EVENT_STOP, options.stop, {
        once: true
      });
    }
    if (dispatchEvent(element, EVENT_STOP) === false) {
      return this;
    }
    var player = this.player;
    clearTimeout(this.playing.timeout);
    this.playing = false;
    this.played = false;
    forEach(player.getElementsByTagName("img"), function(image) {
      removeListener(image, EVENT_LOAD, _this8.onLoadWhenPlay);
    });
    removeClass(player, CLASS_SHOW);
    player.innerHTML = "";
    this.exitFullscreen();
    return this;
  },
  full: function full() {
    var _this9 = this;
    var options = this.options, viewer = this.viewer, image = this.image, list = this.list;
    if (!this.isShown || this.played || this.fulled || !options.inline) {
      return this;
    }
    this.fulled = true;
    this.open();
    addClass(this.button, CLASS_FULLSCREEN_EXIT);
    if (options.transition) {
      removeClass(list, CLASS_TRANSITION);
      if (this.viewed) {
        removeClass(image, CLASS_TRANSITION);
      }
    }
    addClass(viewer, CLASS_FIXED);
    viewer.setAttribute("role", "dialog");
    viewer.setAttribute("aria-labelledby", this.title.id);
    viewer.setAttribute("aria-modal", true);
    viewer.removeAttribute("style");
    setStyle(viewer, {
      zIndex: options.zIndex
    });
    if (options.focus) {
      this.enforceFocus();
    }
    this.initContainer();
    this.viewerData = assign({}, this.containerData);
    this.renderList();
    if (this.viewed) {
      this.initImage(function() {
        _this9.renderImage(function() {
          if (options.transition) {
            setTimeout(function() {
              addClass(image, CLASS_TRANSITION);
              addClass(list, CLASS_TRANSITION);
            }, 0);
          }
        });
      });
    }
    return this;
  },
  exit: function exit() {
    var _this10 = this;
    var options = this.options, viewer = this.viewer, image = this.image, list = this.list;
    if (!this.isShown || this.played || !this.fulled || !options.inline) {
      return this;
    }
    this.fulled = false;
    this.close();
    removeClass(this.button, CLASS_FULLSCREEN_EXIT);
    if (options.transition) {
      removeClass(list, CLASS_TRANSITION);
      if (this.viewed) {
        removeClass(image, CLASS_TRANSITION);
      }
    }
    if (options.focus) {
      this.clearEnforceFocus();
    }
    viewer.removeAttribute("role");
    viewer.removeAttribute("aria-labelledby");
    viewer.removeAttribute("aria-modal");
    removeClass(viewer, CLASS_FIXED);
    setStyle(viewer, {
      zIndex: options.zIndexInline
    });
    this.viewerData = assign({}, this.parentData);
    this.renderViewer();
    this.renderList();
    if (this.viewed) {
      this.initImage(function() {
        _this10.renderImage(function() {
          if (options.transition) {
            setTimeout(function() {
              addClass(image, CLASS_TRANSITION);
              addClass(list, CLASS_TRANSITION);
            }, 0);
          }
        });
      });
    }
    return this;
  },
  tooltip: function tooltip() {
    var _this11 = this;
    var options = this.options, tooltipBox = this.tooltipBox, imageData = this.imageData;
    if (!this.viewed || this.played || !options.tooltip) {
      return this;
    }
    tooltipBox.textContent = "".concat(Math.round(imageData.ratio * 100), "%");
    if (!this.tooltipping) {
      if (options.transition) {
        if (this.fading) {
          dispatchEvent(tooltipBox, EVENT_TRANSITION_END);
        }
        addClass(tooltipBox, CLASS_SHOW);
        addClass(tooltipBox, CLASS_FADE);
        addClass(tooltipBox, CLASS_TRANSITION);
        tooltipBox.removeAttribute("aria-hidden");
        tooltipBox.initialOffsetWidth = tooltipBox.offsetWidth;
        addClass(tooltipBox, CLASS_IN);
      } else {
        addClass(tooltipBox, CLASS_SHOW);
        tooltipBox.removeAttribute("aria-hidden");
      }
    } else {
      clearTimeout(this.tooltipping);
    }
    this.tooltipping = setTimeout(function() {
      if (options.transition) {
        addListener(tooltipBox, EVENT_TRANSITION_END, function() {
          removeClass(tooltipBox, CLASS_SHOW);
          removeClass(tooltipBox, CLASS_FADE);
          removeClass(tooltipBox, CLASS_TRANSITION);
          tooltipBox.setAttribute("aria-hidden", true);
          _this11.fading = false;
        }, {
          once: true
        });
        removeClass(tooltipBox, CLASS_IN);
        _this11.fading = true;
      } else {
        removeClass(tooltipBox, CLASS_SHOW);
        tooltipBox.setAttribute("aria-hidden", true);
      }
      _this11.tooltipping = false;
    }, 1e3);
    return this;
  },
  toggle: function toggle() {
    var _originalEvent = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : null;
    if (this.imageData.ratio === 1) {
      this.zoomTo(this.imageData.oldRatio, true, null, _originalEvent);
    } else {
      this.zoomTo(1, true, null, _originalEvent);
    }
    return this;
  },
  reset: function reset() {
    if (this.viewed && !this.played) {
      this.imageData = assign({}, this.initialImageData);
      this.renderImage();
    }
    return this;
  },
  update: function update() {
    var _this12 = this;
    var element = this.element, options = this.options, isImg = this.isImg;
    if (isImg && !element.parentNode) {
      return this.destroy();
    }
    var images = [];
    forEach(isImg ? [element] : element.querySelectorAll("img"), function(image) {
      if (isFunction(options.filter)) {
        if (options.filter.call(_this12, image)) {
          images.push(image);
        }
      } else if (_this12.getImageURL(image)) {
        images.push(image);
      }
    });
    if (!images.length) {
      return this;
    }
    this.images = images;
    this.length = images.length;
    if (this.ready) {
      var changedIndexes = [];
      forEach(this.items, function(item, i) {
        var img = item.querySelector("img");
        var image = images[i];
        if (image && img) {
          if (image.src !== img.src || image.alt !== img.alt) {
            changedIndexes.push(i);
          }
        } else {
          changedIndexes.push(i);
        }
      });
      setStyle(this.list, {
        width: "auto"
      });
      this.initList();
      if (this.isShown) {
        if (this.length) {
          if (this.viewed) {
            var changedIndex = changedIndexes.indexOf(this.index);
            if (changedIndex >= 0) {
              this.viewed = false;
              this.view(Math.max(Math.min(this.index - changedIndex, this.length - 1), 0));
            } else {
              var activeItem = this.items[this.index];
              addClass(activeItem, CLASS_ACTIVE);
              activeItem.setAttribute("aria-selected", true);
            }
          }
        } else {
          this.image = null;
          this.viewed = false;
          this.index = 0;
          this.imageData = {};
          this.canvas.innerHTML = "";
          this.title.innerHTML = "";
        }
      }
    } else {
      this.build();
    }
    return this;
  },
  destroy: function destroy() {
    var element = this.element, options = this.options;
    if (!element[NAMESPACE]) {
      return this;
    }
    this.destroyed = true;
    if (this.ready) {
      if (this.played) {
        this.stop();
      }
      if (options.inline) {
        if (this.fulled) {
          this.exit();
        }
        this.unbind();
      } else if (this.isShown) {
        if (this.viewing) {
          if (this.imageRendering) {
            this.imageRendering.abort();
          } else if (this.imageInitializing) {
            this.imageInitializing.abort();
          }
        }
        if (this.hiding) {
          this.transitioning.abort();
        }
        this.hidden();
      } else if (this.showing) {
        this.transitioning.abort();
        this.hidden();
      }
      this.ready = false;
      this.viewer.parentNode.removeChild(this.viewer);
    } else if (options.inline) {
      if (this.delaying) {
        this.delaying.abort();
      } else if (this.initializing) {
        this.initializing.abort();
      }
    }
    if (!options.inline) {
      removeListener(element, EVENT_CLICK, this.onStart);
    }
    element[NAMESPACE] = void 0;
    return this;
  }
};
var others = {
  getImageURL: function getImageURL(image) {
    var url = this.options.url;
    if (isString(url)) {
      url = image.getAttribute(url);
    } else if (isFunction(url)) {
      url = url.call(this, image);
    } else {
      url = "";
    }
    return url;
  },
  enforceFocus: function enforceFocus() {
    var _this = this;
    this.clearEnforceFocus();
    addListener(document, EVENT_FOCUSIN, this.onFocusin = function(event) {
      var viewer = _this.viewer;
      var target = event.target;
      if (target === document || target === viewer || viewer.contains(target)) {
        return;
      }
      while (target) {
        if (target.getAttribute("tabindex") !== null || target.getAttribute("aria-modal") === "true") {
          return;
        }
        target = target.parentElement;
      }
      viewer.focus();
    });
  },
  clearEnforceFocus: function clearEnforceFocus() {
    if (this.onFocusin) {
      removeListener(document, EVENT_FOCUSIN, this.onFocusin);
      this.onFocusin = null;
    }
  },
  open: function open() {
    var body = this.body;
    addClass(body, CLASS_OPEN);
    if (this.scrollbarWidth > 0) {
      body.style.paddingRight = "".concat(this.scrollbarWidth + (parseFloat(this.initialBodyComputedPaddingRight) || 0), "px");
    }
  },
  close: function close() {
    var body = this.body;
    removeClass(body, CLASS_OPEN);
    if (this.scrollbarWidth > 0) {
      body.style.paddingRight = this.initialBodyPaddingRight;
    }
  },
  shown: function shown() {
    var element = this.element, options = this.options, viewer = this.viewer;
    this.fulled = true;
    this.isShown = true;
    this.render();
    this.bind();
    this.showing = false;
    if (options.focus) {
      viewer.focus();
      this.enforceFocus();
    }
    if (isFunction(options.shown)) {
      addListener(element, EVENT_SHOWN, options.shown, {
        once: true
      });
    }
    if (dispatchEvent(element, EVENT_SHOWN) === false) {
      return;
    }
    if (this.ready && this.isShown && !this.hiding) {
      this.view(this.index);
    }
  },
  hidden: function hidden() {
    var element = this.element, options = this.options, viewer = this.viewer;
    if (options.fucus) {
      this.clearEnforceFocus();
    }
    this.fulled = false;
    this.viewed = false;
    this.isShown = false;
    this.close();
    this.unbind();
    addClass(viewer, CLASS_HIDE);
    viewer.removeAttribute("role");
    viewer.removeAttribute("aria-labelledby");
    viewer.removeAttribute("aria-modal");
    viewer.setAttribute("aria-hidden", true);
    this.resetList();
    this.resetImage();
    this.hiding = false;
    if (!this.destroyed) {
      if (isFunction(options.hidden)) {
        addListener(element, EVENT_HIDDEN, options.hidden, {
          once: true
        });
      }
      dispatchEvent(element, EVENT_HIDDEN, null, {
        cancelable: false
      });
    }
  },
  requestFullscreen: function requestFullscreen(options) {
    var document2 = this.element.ownerDocument;
    if (this.fulled && !(document2.fullscreenElement || document2.webkitFullscreenElement || document2.mozFullScreenElement || document2.msFullscreenElement)) {
      var documentElement = document2.documentElement;
      if (documentElement.requestFullscreen) {
        if (isPlainObject(options)) {
          documentElement.requestFullscreen(options);
        } else {
          documentElement.requestFullscreen();
        }
      } else if (documentElement.webkitRequestFullscreen) {
        documentElement.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT);
      } else if (documentElement.mozRequestFullScreen) {
        documentElement.mozRequestFullScreen();
      } else if (documentElement.msRequestFullscreen) {
        documentElement.msRequestFullscreen();
      }
    }
  },
  exitFullscreen: function exitFullscreen() {
    var document2 = this.element.ownerDocument;
    if (this.fulled && (document2.fullscreenElement || document2.webkitFullscreenElement || document2.mozFullScreenElement || document2.msFullscreenElement)) {
      if (document2.exitFullscreen) {
        document2.exitFullscreen();
      } else if (document2.webkitExitFullscreen) {
        document2.webkitExitFullscreen();
      } else if (document2.mozCancelFullScreen) {
        document2.mozCancelFullScreen();
      } else if (document2.msExitFullscreen) {
        document2.msExitFullscreen();
      }
    }
  },
  change: function change(event) {
    var options = this.options, pointers = this.pointers;
    var pointer = pointers[Object.keys(pointers)[0]];
    if (!pointer) {
      return;
    }
    var offsetX = pointer.endX - pointer.startX;
    var offsetY = pointer.endY - pointer.startY;
    switch (this.action) {
      case ACTION_MOVE:
        if (offsetX !== 0 || offsetY !== 0) {
          this.pointerMoved = true;
          this.move(offsetX, offsetY, event);
        }
        break;
      case ACTION_ZOOM:
        this.zoom(getMaxZoomRatio(pointers), false, null, event);
        break;
      case ACTION_SWITCH: {
        this.action = "switched";
        var absoluteOffsetX = Math.abs(offsetX);
        if (absoluteOffsetX > 1 && absoluteOffsetX > Math.abs(offsetY)) {
          this.pointers = {};
          if (offsetX > 1) {
            this.prev(options.loop);
          } else if (offsetX < -1) {
            this.next(options.loop);
          }
        }
        break;
      }
    }
    forEach(pointers, function(p) {
      p.startX = p.endX;
      p.startY = p.endY;
    });
  },
  isSwitchable: function isSwitchable() {
    var imageData = this.imageData, viewerData = this.viewerData;
    return this.length > 1 && imageData.x >= 0 && imageData.y >= 0 && imageData.width <= viewerData.width && imageData.height <= viewerData.height;
  }
};
var AnotherViewer = WINDOW.Viewer;
var getUniqueID = function(id) {
  return function() {
    id += 1;
    return id;
  };
}(-1);
var Viewer = /* @__PURE__ */ function() {
  function Viewer2(element) {
    var options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    _classCallCheck(this, Viewer2);
    if (!element || element.nodeType !== 1) {
      throw new Error("The first argument is required and must be an element.");
    }
    this.element = element;
    this.options = assign({}, DEFAULTS, isPlainObject(options) && options);
    this.action = false;
    this.fading = false;
    this.fulled = false;
    this.hiding = false;
    this.imageClicked = false;
    this.imageData = {};
    this.index = this.options.initialViewIndex;
    this.isImg = false;
    this.isShown = false;
    this.length = 0;
    this.moving = false;
    this.played = false;
    this.playing = false;
    this.pointers = {};
    this.ready = false;
    this.rotating = false;
    this.scaling = false;
    this.showing = false;
    this.timeout = false;
    this.tooltipping = false;
    this.viewed = false;
    this.viewing = false;
    this.wheeling = false;
    this.zooming = false;
    this.pointerMoved = false;
    this.id = getUniqueID();
    this.init();
  }
  _createClass(Viewer2, [{
    key: "init",
    value: function init() {
      var _this = this;
      var element = this.element, options = this.options;
      if (element[NAMESPACE]) {
        return;
      }
      element[NAMESPACE] = this;
      if (options.focus && !options.keyboard) {
        options.focus = false;
      }
      var isImg = element.localName === "img";
      var images = [];
      forEach(isImg ? [element] : element.querySelectorAll("img"), function(image) {
        if (isFunction(options.filter)) {
          if (options.filter.call(_this, image)) {
            images.push(image);
          }
        } else if (_this.getImageURL(image)) {
          images.push(image);
        }
      });
      this.isImg = isImg;
      this.length = images.length;
      this.images = images;
      this.initBody();
      if (isUndefined(document.createElement(NAMESPACE).style.transition)) {
        options.transition = false;
      }
      if (options.inline) {
        var count = 0;
        var progress = function progress2() {
          count += 1;
          if (count === _this.length) {
            var timeout;
            _this.initializing = false;
            _this.delaying = {
              abort: function abort() {
                clearTimeout(timeout);
              }
            };
            timeout = setTimeout(function() {
              _this.delaying = false;
              _this.build();
            }, 0);
          }
        };
        this.initializing = {
          abort: function abort() {
            forEach(images, function(image) {
              if (!image.complete) {
                removeListener(image, EVENT_LOAD, progress);
                removeListener(image, EVENT_ERROR, progress);
              }
            });
          }
        };
        forEach(images, function(image) {
          if (image.complete) {
            progress();
          } else {
            var onLoad;
            var onError;
            addListener(image, EVENT_LOAD, onLoad = function onLoad2() {
              removeListener(image, EVENT_ERROR, onError);
              progress();
            }, {
              once: true
            });
            addListener(image, EVENT_ERROR, onError = function onError2() {
              removeListener(image, EVENT_LOAD, onLoad);
              progress();
            }, {
              once: true
            });
          }
        });
      } else {
        addListener(element, EVENT_CLICK, this.onStart = function(_ref) {
          var target = _ref.target;
          if (target.localName === "img" && (!isFunction(options.filter) || options.filter.call(_this, target))) {
            _this.view(_this.images.indexOf(target));
          }
        });
      }
    }
  }, {
    key: "build",
    value: function build() {
      if (this.ready) {
        return;
      }
      var element = this.element, options = this.options;
      var parent = element.parentNode;
      var template = document.createElement("div");
      template.innerHTML = TEMPLATE;
      var viewer = template.querySelector(".".concat(NAMESPACE, "-container"));
      var title = viewer.querySelector(".".concat(NAMESPACE, "-title"));
      var toolbar = viewer.querySelector(".".concat(NAMESPACE, "-toolbar"));
      var navbar = viewer.querySelector(".".concat(NAMESPACE, "-navbar"));
      var button = viewer.querySelector(".".concat(NAMESPACE, "-button"));
      var canvas = viewer.querySelector(".".concat(NAMESPACE, "-canvas"));
      this.parent = parent;
      this.viewer = viewer;
      this.title = title;
      this.toolbar = toolbar;
      this.navbar = navbar;
      this.button = button;
      this.canvas = canvas;
      this.footer = viewer.querySelector(".".concat(NAMESPACE, "-footer"));
      this.tooltipBox = viewer.querySelector(".".concat(NAMESPACE, "-tooltip"));
      this.player = viewer.querySelector(".".concat(NAMESPACE, "-player"));
      this.list = viewer.querySelector(".".concat(NAMESPACE, "-list"));
      viewer.id = "".concat(NAMESPACE).concat(this.id);
      title.id = "".concat(NAMESPACE, "Title").concat(this.id);
      addClass(title, !options.title ? CLASS_HIDE : getResponsiveClass(Array.isArray(options.title) ? options.title[0] : options.title));
      addClass(navbar, !options.navbar ? CLASS_HIDE : getResponsiveClass(options.navbar));
      toggleClass(button, CLASS_HIDE, !options.button);
      if (options.keyboard) {
        button.setAttribute("tabindex", 0);
      }
      if (options.backdrop) {
        addClass(viewer, "".concat(NAMESPACE, "-backdrop"));
        if (!options.inline && options.backdrop !== "static") {
          setData(canvas, DATA_ACTION, "hide");
        }
      }
      if (isString(options.className) && options.className) {
        options.className.split(REGEXP_SPACES).forEach(function(className) {
          addClass(viewer, className);
        });
      }
      if (options.toolbar) {
        var list = document.createElement("ul");
        var custom = isPlainObject(options.toolbar);
        var zoomButtons = BUTTONS.slice(0, 3);
        var rotateButtons = BUTTONS.slice(7, 9);
        var scaleButtons = BUTTONS.slice(9);
        if (!custom) {
          addClass(toolbar, getResponsiveClass(options.toolbar));
        }
        forEach(custom ? options.toolbar : BUTTONS, function(value, index) {
          var deep = custom && isPlainObject(value);
          var name = custom ? hyphenate(index) : value;
          var show2 = deep && !isUndefined(value.show) ? value.show : value;
          if (!show2 || !options.zoomable && zoomButtons.indexOf(name) !== -1 || !options.rotatable && rotateButtons.indexOf(name) !== -1 || !options.scalable && scaleButtons.indexOf(name) !== -1) {
            return;
          }
          var size = deep && !isUndefined(value.size) ? value.size : value;
          var click2 = deep && !isUndefined(value.click) ? value.click : value;
          var item = document.createElement("li");
          if (options.keyboard) {
            item.setAttribute("tabindex", 0);
          }
          item.setAttribute("role", "button");
          addClass(item, "".concat(NAMESPACE, "-").concat(name));
          if (!isFunction(click2)) {
            setData(item, DATA_ACTION, name);
          }
          if (isNumber(show2)) {
            addClass(item, getResponsiveClass(show2));
          }
          if (["small", "large"].indexOf(size) !== -1) {
            addClass(item, "".concat(NAMESPACE, "-").concat(size));
          } else if (name === "play") {
            addClass(item, "".concat(NAMESPACE, "-large"));
          }
          if (isFunction(click2)) {
            addListener(item, EVENT_CLICK, click2);
          }
          list.appendChild(item);
        });
        toolbar.appendChild(list);
      } else {
        addClass(toolbar, CLASS_HIDE);
      }
      if (!options.rotatable) {
        var rotates = toolbar.querySelectorAll('li[class*="rotate"]');
        addClass(rotates, CLASS_INVISIBLE);
        forEach(rotates, function(rotate2) {
          toolbar.appendChild(rotate2);
        });
      }
      if (options.inline) {
        addClass(button, CLASS_FULLSCREEN);
        setStyle(viewer, {
          zIndex: options.zIndexInline
        });
        if (window.getComputedStyle(parent).position === "static") {
          setStyle(parent, {
            position: "relative"
          });
        }
        parent.insertBefore(viewer, element.nextSibling);
      } else {
        addClass(button, CLASS_CLOSE);
        addClass(viewer, CLASS_FIXED);
        addClass(viewer, CLASS_FADE);
        addClass(viewer, CLASS_HIDE);
        setStyle(viewer, {
          zIndex: options.zIndex
        });
        var container = options.container;
        if (isString(container)) {
          container = element.ownerDocument.querySelector(container);
        }
        if (!container) {
          container = this.body;
        }
        container.appendChild(viewer);
      }
      if (options.inline) {
        this.render();
        this.bind();
        this.isShown = true;
      }
      this.ready = true;
      if (isFunction(options.ready)) {
        addListener(element, EVENT_READY, options.ready, {
          once: true
        });
      }
      if (dispatchEvent(element, EVENT_READY) === false) {
        this.ready = false;
        return;
      }
      if (this.ready && options.inline) {
        this.view(this.index);
      }
    }
  }], [{
    key: "noConflict",
    value: function noConflict() {
      window.Viewer = AnotherViewer;
      return Viewer2;
    }
  }, {
    key: "setDefaults",
    value: function setDefaults(options) {
      assign(DEFAULTS, isPlainObject(options) && options);
    }
  }]);
  return Viewer2;
}();
assign(Viewer.prototype, render, events, handlers, methods, others);
var viewer_esm = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  default: Viewer
});
var require$$0 = /* @__PURE__ */ getAugmentedNamespace(viewer_esm);
(function(module, exports) {
  (function webpackUniversalModuleDefinition(root, factory) {
    module.exports = factory(require$$0, require$$1);
  })(commonjsGlobal, function(__WEBPACK_EXTERNAL_MODULE_0__, __WEBPACK_EXTERNAL_MODULE_2__) {
    return function(modules) {
      var installedModules = {};
      function __webpack_require__(moduleId) {
        if (installedModules[moduleId]) {
          return installedModules[moduleId].exports;
        }
        var module2 = installedModules[moduleId] = {
          i: moduleId,
          l: false,
          exports: {}
        };
        modules[moduleId].call(module2.exports, module2, module2.exports, __webpack_require__);
        module2.l = true;
        return module2.exports;
      }
      __webpack_require__.m = modules;
      __webpack_require__.c = installedModules;
      __webpack_require__.i = function(value) {
        return value;
      };
      __webpack_require__.d = function(exports2, name, getter) {
        if (!__webpack_require__.o(exports2, name)) {
          Object.defineProperty(exports2, name, {
            configurable: false,
            enumerable: true,
            get: getter
          });
        }
      };
      __webpack_require__.n = function(module2) {
        var getter = module2 && module2.__esModule ? function getDefault() {
          return module2["default"];
        } : function getModuleExports() {
          return module2;
        };
        __webpack_require__.d(getter, "a", getter);
        return getter;
      };
      __webpack_require__.o = function(object, property) {
        return Object.prototype.hasOwnProperty.call(object, property);
      };
      __webpack_require__.p = "";
      return __webpack_require__(__webpack_require__.s = 6);
    }([
      function(module2, exports2) {
        module2.exports = __WEBPACK_EXTERNAL_MODULE_0__;
      },
      function(module2, __webpack_exports__, __webpack_require__) {
        __webpack_exports__["a"] = extend;
        function extend() {
          var extended = {};
          var deep = false;
          var i = 0;
          var length = arguments.length;
          if (Object.prototype.toString.call(arguments[0]) === "[object Boolean]") {
            deep = arguments[0];
            i++;
          }
          function merge(obj2) {
            for (var prop in obj2) {
              if (Object.prototype.hasOwnProperty.call(obj2, prop)) {
                if (deep && Object.prototype.toString.call(obj2[prop]) === "[object Object]") {
                  extended[prop] = extend(true, extended[prop], obj2[prop]);
                } else {
                  extended[prop] = obj2[prop];
                }
              }
            }
          }
          for (; i < length; i++) {
            var obj = arguments[i];
            merge(obj);
          }
          return extended;
        }
      },
      function(module2, exports2) {
        module2.exports = __WEBPACK_EXTERNAL_MODULE_2__;
      },
      function(module2, __webpack_exports__, __webpack_require__) {
        var __WEBPACK_IMPORTED_MODULE_0_viewerjs__ = __webpack_require__(0);
        var __WEBPACK_IMPORTED_MODULE_0_viewerjs___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_viewerjs__);
        var __WEBPACK_IMPORTED_MODULE_1__utils__ = __webpack_require__(1);
        var __WEBPACK_IMPORTED_MODULE_2_vue__ = __webpack_require__(2);
        var __WEBPACK_IMPORTED_MODULE_2_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_vue__);
        var api = function api2() {
          var _ref = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, _ref$images = _ref.images, images = _ref$images === void 0 ? [] : _ref$images, _ref$options = _ref.options, options = _ref$options === void 0 ? {} : _ref$options;
          options = __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_1__utils__["a"])(options, {
            inline: false
          });
          var ViewerToken = __WEBPACK_IMPORTED_MODULE_2_vue___default.a.extend({
            render: function render3(h) {
              return h("div", {
                style: {
                  display: "none"
                },
                class: ["__viewer-token"]
              }, images.map(function(attr) {
                return h("img", {
                  attrs: typeof attr === "string" ? { src: attr } : attr
                });
              }));
            }
          });
          var token = new ViewerToken();
          token.$mount();
          document.body.appendChild(token.$el);
          var $viewer = new __WEBPACK_IMPORTED_MODULE_0_viewerjs___default.a(token.$el, options);
          var $destroy = $viewer.destroy.bind($viewer);
          $viewer.destroy = function() {
            $destroy();
            token.$destroy();
            document.body.removeChild(token.$el);
            return $viewer;
          };
          $viewer.show();
          token.$el.addEventListener("hidden", function() {
            if (this.viewer === $viewer) {
              $viewer.destroy();
            }
          });
          return $viewer;
        };
        __webpack_exports__["a"] = api;
      },
      function(module2, __webpack_exports__, __webpack_require__) {
        (function(global2) {
          var __WEBPACK_IMPORTED_MODULE_0_viewerjs__ = __webpack_require__(0);
          var __WEBPACK_IMPORTED_MODULE_0_viewerjs___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_viewerjs__);
          var __WEBPACK_IMPORTED_MODULE_1_throttle_debounce__ = __webpack_require__(7);
          __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_throttle_debounce__);
          var __WEBPACK_IMPORTED_MODULE_2_vue__ = __webpack_require__(2);
          var __WEBPACK_IMPORTED_MODULE_2_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_vue__);
          var directive = function directive2() {
            var _ref = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, _ref$name = _ref.name, name = _ref$name === void 0 ? "viewer" : _ref$name, _ref$debug = _ref.debug, debug = _ref$debug === void 0 ? false : _ref$debug;
            function createViewer(el, options) {
              var rebuild = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : false;
              var observer = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : false;
              __WEBPACK_IMPORTED_MODULE_2_vue___default.a.nextTick(function() {
                if (observer && !imageDiff(el))
                  return;
                if (rebuild || !el["$" + name]) {
                  destroyViewer(el);
                  el["$" + name] = new __WEBPACK_IMPORTED_MODULE_0_viewerjs___default.a(el, options);
                  log("Viewer created");
                } else {
                  el["$" + name].update();
                  log("Viewer updated");
                }
              });
            }
            function imageDiff(el) {
              var imageContent = el.innerHTML.match(/<img([\w\W]+?)[\\/]?>/g);
              var viewerImageText = imageContent ? imageContent.join("") : void 0;
              if (el.__viewerImageDiffCache === viewerImageText) {
                log("Element change detected, but image(s) has not changed");
                return false;
              } else {
                log("Image change detected");
                el.__viewerImageDiffCache = viewerImageText;
                return true;
              }
            }
            function createObserver(el, options, debouncedCreateViewer, rebuild) {
              destroyObserver(el);
              var MutationObserver = global2.MutationObserver || global2.WebKitMutationObserver || global2.MozMutationObserver;
              if (!MutationObserver) {
                log("Observer not supported");
                return;
              }
              var observer = new MutationObserver(function(mutations) {
                mutations.forEach(function(mutation) {
                  log("Viewer mutation:" + mutation.type);
                  debouncedCreateViewer(el, options, rebuild, true);
                });
              });
              var config = { attributes: true, childList: true, characterData: true, subtree: true };
              observer.observe(el, config);
              el.__viewerMutationObserver = observer;
              log("Observer created");
            }
            function createWatcher(el, _ref2, vnode, debouncedCreateViewer) {
              var expression = _ref2.expression;
              var simplePathRE = /^[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*|\['[^']*?']|\["[^"]*?"]|\[\d+]|\[[A-Za-z_$][\w$]*])*$/;
              if (!expression || !simplePathRE.test(expression)) {
                log("Only simple dot-delimited paths can create watcher");
                return;
              }
              el.__viewerUnwatch = vnode.context.$watch(expression, function(newVal, oldVal) {
                log("Change detected by watcher: ", expression);
                debouncedCreateViewer(el, newVal, true);
              }, {
                deep: true
              });
              log("Watcher created, expression: ", expression);
            }
            function destroyViewer(el) {
              if (!el["$" + name]) {
                return;
              }
              el["$" + name].destroy();
              delete el["$" + name];
              log("Viewer destroyed");
            }
            function destroyObserver(el) {
              if (!el.__viewerMutationObserver) {
                return;
              }
              el.__viewerMutationObserver.disconnect();
              delete el.__viewerMutationObserver;
              log("Observer destroyed");
            }
            function destroyWatcher(el) {
              if (!el.__viewerUnwatch) {
                return;
              }
              el.__viewerUnwatch();
              delete el.__viewerUnwatch;
              log("Watcher destroyed");
            }
            function log() {
              var _console;
              debug && (_console = console).log.apply(_console, arguments);
            }
            var directive3 = {
              bind: function bind2(el, binding, vnode) {
                log("Viewer bind");
                var debouncedCreateViewer = __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_1_throttle_debounce__["debounce"])(50, createViewer);
                debouncedCreateViewer(el, binding.value);
                createWatcher(el, binding, vnode, debouncedCreateViewer);
                if (!binding.modifiers.static) {
                  createObserver(el, binding.value, debouncedCreateViewer, binding.modifiers.rebuild);
                }
              },
              unbind: function unbind2(el, binding) {
                log("Viewer unbind");
                destroyObserver(el);
                destroyWatcher(el);
                destroyViewer(el);
              }
            };
            return directive3;
          };
          __webpack_exports__["a"] = directive;
        }).call(__webpack_exports__, __webpack_require__(9));
      },
      function(module2, exports2, __webpack_require__) {
        var Component = __webpack_require__(10)(
          __webpack_require__(8),
          __webpack_require__(11),
          null,
          null
        );
        Component.options.__file = "/Volumes/public/Workspace/web/v-viewer/src/component.vue";
        if (Component.esModule && Object.keys(Component.esModule).some(function(key) {
          return key !== "default" && key !== "__esModule";
        })) {
          console.error("named exports are not supported in *.vue files.");
        }
        if (Component.options.functional) {
          console.error("[vue-loader] component.vue: functional components are not supported with templates, they should use render functions.");
        }
        module2.exports = Component.exports;
      },
      function(module2, __webpack_exports__, __webpack_require__) {
        Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
        var __WEBPACK_IMPORTED_MODULE_0__utils__ = __webpack_require__(1);
        var __WEBPACK_IMPORTED_MODULE_1_viewerjs__ = __webpack_require__(0);
        var __WEBPACK_IMPORTED_MODULE_1_viewerjs___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_viewerjs__);
        var __WEBPACK_IMPORTED_MODULE_2__component_vue__ = __webpack_require__(5);
        var __WEBPACK_IMPORTED_MODULE_2__component_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2__component_vue__);
        var __WEBPACK_IMPORTED_MODULE_3__directive__ = __webpack_require__(4);
        var __WEBPACK_IMPORTED_MODULE_4__api__ = __webpack_require__(3);
        __webpack_require__.d(__webpack_exports__, "component", function() {
          return __WEBPACK_IMPORTED_MODULE_2__component_vue___default.a;
        });
        __webpack_require__.d(__webpack_exports__, "directive", function() {
          return __WEBPACK_IMPORTED_MODULE_3__directive__["a"];
        });
        __webpack_require__.d(__webpack_exports__, "api", function() {
          return __WEBPACK_IMPORTED_MODULE_4__api__["a"];
        });
        __webpack_require__.d(__webpack_exports__, "Viewer", function() {
          return __WEBPACK_IMPORTED_MODULE_1_viewerjs___default.a;
        });
        __webpack_exports__["default"] = {
          install: function install(Vue) {
            var _ref = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, _ref$name = _ref.name, name = _ref$name === void 0 ? "viewer" : _ref$name, _ref$debug = _ref.debug, debug = _ref$debug === void 0 ? false : _ref$debug, defaultOptions = _ref.defaultOptions;
            __WEBPACK_IMPORTED_MODULE_1_viewerjs___default.a.setDefaults(defaultOptions);
            Vue.component(name, __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_0__utils__["a"])(__WEBPACK_IMPORTED_MODULE_2__component_vue___default.a, { name }));
            Vue.directive(name, __webpack_require__.i(__WEBPACK_IMPORTED_MODULE_3__directive__["a"])({ name, debug }));
            Vue.prototype["$" + name + "Api"] = __WEBPACK_IMPORTED_MODULE_4__api__["a"];
          },
          setDefaults: function setDefaults(defaultOptions) {
            __WEBPACK_IMPORTED_MODULE_1_viewerjs___default.a.setDefaults(defaultOptions);
          }
        };
      },
      function(module2, exports2, __webpack_require__) {
        var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;
        var _typeof2 = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function(obj) {
          return typeof obj;
        } : function(obj) {
          return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
        };
        (function(global2, factory) {
          _typeof2(exports2) === "object" && typeof module2 !== "undefined" ? factory(exports2) : !(__WEBPACK_AMD_DEFINE_ARRAY__ = [exports2], __WEBPACK_AMD_DEFINE_FACTORY__ = factory, __WEBPACK_AMD_DEFINE_RESULT__ = typeof __WEBPACK_AMD_DEFINE_FACTORY__ === "function" ? __WEBPACK_AMD_DEFINE_FACTORY__.apply(exports2, __WEBPACK_AMD_DEFINE_ARRAY__) : __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_RESULT__ !== void 0 && (module2.exports = __WEBPACK_AMD_DEFINE_RESULT__));
        })(this, function(exports3) {
          function throttle2(delay, noTrailing, callback, debounceMode) {
            var timeoutID;
            var cancelled = false;
            var lastExec = 0;
            function clearExistingTimeout() {
              if (timeoutID) {
                clearTimeout(timeoutID);
              }
            }
            function cancel() {
              clearExistingTimeout();
              cancelled = true;
            }
            if (typeof noTrailing !== "boolean") {
              debounceMode = callback;
              callback = noTrailing;
              noTrailing = void 0;
            }
            function wrapper() {
              for (var _len = arguments.length, arguments_ = new Array(_len), _key = 0; _key < _len; _key++) {
                arguments_[_key] = arguments[_key];
              }
              var self2 = this;
              var elapsed = Date.now() - lastExec;
              if (cancelled) {
                return;
              }
              function exec() {
                lastExec = Date.now();
                callback.apply(self2, arguments_);
              }
              function clear() {
                timeoutID = void 0;
              }
              if (debounceMode && !timeoutID) {
                exec();
              }
              clearExistingTimeout();
              if (debounceMode === void 0 && elapsed > delay) {
                exec();
              } else if (noTrailing !== true) {
                timeoutID = setTimeout(debounceMode ? clear : exec, debounceMode === void 0 ? delay - elapsed : delay);
              }
            }
            wrapper.cancel = cancel;
            return wrapper;
          }
          function debounce(delay, atBegin, callback) {
            return callback === void 0 ? throttle2(delay, atBegin, false) : throttle2(delay, callback, atBegin !== false);
          }
          exports3.debounce = debounce;
          exports3.throttle = throttle2;
          Object.defineProperty(exports3, "__esModule", { value: true });
        });
      },
      function(module2, __webpack_exports__, __webpack_require__) {
        Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
        var __WEBPACK_IMPORTED_MODULE_0_viewerjs__ = __webpack_require__(0);
        var __WEBPACK_IMPORTED_MODULE_0_viewerjs___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_viewerjs__);
        __webpack_exports__["default"] = {
          props: {
            images: {
              type: Array
            },
            rebuild: {
              type: Boolean,
              default: false
            },
            trigger: {},
            options: {
              type: Object
            }
          },
          data: function data() {
            return {};
          },
          computed: {},
          methods: {
            onChange: function onChange() {
              if (this.rebuild) {
                this.rebuildViewer();
              } else {
                this.updateViewer();
              }
            },
            rebuildViewer: function rebuildViewer() {
              this.destroyViewer();
              this.createViewer();
            },
            updateViewer: function updateViewer() {
              if (this.$viewer) {
                this.$viewer.update();
                this.$emit("inited", this.$viewer);
              } else {
                this.createViewer();
              }
            },
            destroyViewer: function destroyViewer() {
              this.$viewer && this.$viewer.destroy();
            },
            createViewer: function createViewer() {
              this.$viewer = new __WEBPACK_IMPORTED_MODULE_0_viewerjs___default.a(this.$el, this.options);
              this.$emit("inited", this.$viewer);
            }
          },
          watch: {
            images: function images() {
              var _this = this;
              this.$nextTick(function() {
                _this.onChange();
              });
            },
            trigger: {
              handler: function handler() {
                var _this2 = this;
                this.$nextTick(function() {
                  _this2.onChange();
                });
              },
              deep: true
            },
            options: {
              handler: function handler() {
                var _this3 = this;
                this.$nextTick(function() {
                  _this3.rebuildViewer();
                });
              },
              deep: true
            }
          },
          mounted: function mounted() {
            this.createViewer();
          },
          destroyed: function destroyed() {
            this.destroyViewer();
          }
        };
      },
      function(module2, exports2) {
        var _typeof2 = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function(obj) {
          return typeof obj;
        } : function(obj) {
          return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
        };
        var g;
        g = function() {
          return this;
        }();
        try {
          g = g || Function("return this")() || (1, eval)("this");
        } catch (e) {
          if ((typeof window === "undefined" ? "undefined" : _typeof2(window)) === "object")
            g = window;
        }
        module2.exports = g;
      },
      function(module2, exports2) {
        module2.exports = function normalizeComponent(rawScriptExports, compiledTemplate, scopeId, cssModules) {
          var esModule;
          var scriptExports = rawScriptExports = rawScriptExports || {};
          var type = typeof rawScriptExports.default;
          if (type === "object" || type === "function") {
            esModule = rawScriptExports;
            scriptExports = rawScriptExports.default;
          }
          var options = typeof scriptExports === "function" ? scriptExports.options : scriptExports;
          if (compiledTemplate) {
            options.render = compiledTemplate.render;
            options.staticRenderFns = compiledTemplate.staticRenderFns;
          }
          if (scopeId) {
            options._scopeId = scopeId;
          }
          if (cssModules) {
            var computed = Object.create(options.computed || null);
            Object.keys(cssModules).forEach(function(key) {
              var module3 = cssModules[key];
              computed[key] = function() {
                return module3;
              };
            });
            options.computed = computed;
          }
          return {
            esModule,
            exports: scriptExports,
            options
          };
        };
      },
      function(module2, exports2, __webpack_require__) {
        module2.exports = { render: function() {
          var _vm = this;
          var _h = _vm.$createElement;
          var _c = _vm._self._c || _h;
          return _c("div", [_vm._t("default", null, {
            "images": _vm.images,
            "options": _vm.options
          })], 2);
        }, staticRenderFns: [] };
        module2.exports.render._withStripped = true;
      }
    ]);
  });
})(vViewer);
var script$2 = {
  name: "ImageUploadStatus",
  components: {
    SfProgress
  },
  props: {
    fileInfo: {
      type: Object,
      required: true
    },
    statusTip: Function
  },
  computed: {
    isUploading() {
      return isFileUploading(this.fileInfo);
    },
    strokeColor() {
      return PROGRESS_STROKE_COLOR[this.fileInfo.status];
    },
    statusText() {
      const statusTextMap = {
        [FILE_STATUS.UPLOADING]: $i("scp.vt_component.sf_widget.packages.upload.image_upload.uploading_text"),
        [FILE_STATUS.ERROR]: $i("scp.vt_component.sf_widget.packages.upload.image_upload.error_text")
      };
      return statusTextMap[this.fileInfo.status] || "";
    },
    statusMessageTip() {
      return this.statusTip(this.fileInfo);
    },
    progressPercentage() {
      return this.fileInfo.progressInfo && this.fileInfo.progressInfo.percent || 0;
    }
  },
  methods: {
    getPrefixedClassName
  }
};
const __vue_script__$2 = script$2;
var __vue_render__$2 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      class: [
        _vm.getPrefixedClassName("sf-image-upload-status"),
        _vm.getPrefixedClassName(
          "sf-image-upload-status--" + _vm.fileInfo.status
        )
      ],
      attrs: { title: _vm.statusMessageTip }
    },
    [
      _vm.statusText ? _c(
        "div",
        {
          class: _vm.getPrefixedClassName("sf-image-upload-status__msg") + " ellipsis"
        },
        [_vm._v("\n    " + _vm._s(_vm.statusText) + "\n  ")]
      ) : _vm._e(),
      _vm._v(" "),
      _c("sf-progress", {
        class: _vm.getPrefixedClassName("sf-image-upload-status__progress-bar"),
        attrs: {
          "no-text": true,
          percentage: _vm.progressPercentage,
          "show-stripe": _vm.isUploading,
          "stroke-width": 3,
          "stroke-color": _vm.strokeColor
        }
      })
    ],
    1
  );
};
var __vue_staticRenderFns__$2 = [];
__vue_render__$2._withStripped = true;
const __vue_inject_styles__$2 = void 0;
const __vue_scope_id__$2 = void 0;
const __vue_module_identifier__$2 = void 0;
const __vue_is_functional_template__$2 = false;
const __vue_component__$2 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$2, staticRenderFns: __vue_staticRenderFns__$2 },
  __vue_inject_styles__$2,
  __vue_script__$2,
  __vue_scope_id__$2,
  __vue_is_functional_template__$2,
  __vue_module_identifier__$2,
  false,
  void 0,
  void 0,
  void 0
);
const IMG_BG_CLS = {
  GRAY: "gray",
  LATTICE: "lattice"
};
const IMG_BG_CLS_MAP = {
  [IMG_BG_CLS.GRAY]: "sf-image-upload__display-image-bg--gray",
  [IMG_BG_CLS.LATTICE]: "sf-image-upload__display-image-bg--lattice"
};
const VIEWER_OPTIONS = {
  className: "sf-image-upload-viewer",
  navbar: false,
  title: false,
  inline: false,
  toolbar: {
    zoomIn: true,
    zoomOut: true,
    verticalLine: true,
    prev: true,
    next: true,
    oneToOne: true
  }
};
var script$1 = {
  name: componentName.imageUpload,
  componentName: componentName.imageUpload,
  components: {
    RawUpload: __vue_component__$5,
    UploadStatus: __vue_component__$2
  },
  directives: {
    viewer: vViewerExports.directive()
  },
  mixins: [UploadHookMixin, MultiFileUploadMixin, FileStatusMixin],
  props: {
    boxWidth: {
      type: String,
      default: "94px"
    },
    boxHeight: {
      type: String,
      default: "94px"
    },
    accept: {
      type: [String, Array],
      default: () => [".jpeg", ".jpg", ".png"]
    },
    multiple: {
      type: Boolean,
      default: false
    },
    minWidth: {
      type: Number,
      default: 0
    },
    minHeight: {
      type: Number,
      default: 0
    },
    limitWidth: {
      type: Number,
      default: 0
    },
    limitHeight: {
      type: Number,
      default: 0
    },
    imageBgCls: {
      type: String,
      default: IMG_BG_CLS.GRAY
    },
    autoUpload: {
      type: Boolean,
      default: true
    },
    maxSize: {
      type: Number,
      default: 2 * 1024 * 1024
    },
    maxCount: {
      type: Number,
      default: DEFAULT_MAX_COUNT
    },
    deleteApi: Function,
    statusTip: {
      type: Function,
      default: (fileInfo) => {
        if (isFileUploading(fileInfo)) {
          return $i("scp.vt_component.sf_widget.packages.upload.image_upload.uploading_tip", {
            filename: fileInfo.name
          });
        } else if (isFileError(fileInfo)) {
          if (!fileInfo.errorMsg) {
            return $i("scp.vt_component.sf_widget.packages.upload.image_upload.error_tip", { filename: fileInfo.name });
          }
          return $i("scp.vt_component.sf_widget.packages.upload.image_upload.error_width_reason_tip", {
            errorMsg: fileInfo.errorMsg,
            filename: fileInfo.name
          });
        }
        return "";
      }
    },
    failNotify: {
      type: Function | Boolean,
      default: true
    }
  },
  data() {
    return {
      illegalMessages: [],
      viewerOptions: VIEWER_OPTIONS
    };
  },
  computed: {
    acceptTypes() {
      return getAccepts(this.accept);
    },
    boxStyle() {
      return {
        width: this.boxWidth,
        height: this.boxHeight
      };
    },
    supportImageTip() {
      let prefixTipSegment = "";
      const tipSegments = [];
      if (this.maxCount > DEFAULT_MAX_COUNT) {
        prefixTipSegment = $i("scp.vt_component.sf_widget.packages.upload.image_max_count_tip", {
          maxCount: this.maxCount
        });
      }
      if (this.acceptTypes.length) {
        tipSegments.push(
          $i("scp.vt_component.sf_widget.packages.upload.image_accept_tip", {
            types: this.acceptTypes.join("/").replace(/\./g, "")
          })
        );
      }
      if (this.maxSize) {
        tipSegments.push(
          $i("scp.vt_component.sf_widget.packages.upload.image_max_size_tip", {
            maxSize: format.fileSize(this.maxSize)
          })
        );
      }
      if (this.limitWidth || this.limitHeight) {
        tipSegments.push(
          $i("scp.vt_component.sf_widget.packages.upload.image_limit_dimension_tip", {
            limitWidth: this.limitWidth,
            limitHeight: this.limitHeight
          })
        );
      }
      if (this.minWidth || this.minHeight) {
        tipSegments.push(
          $i("scp.vt_component.sf_widget.packages.upload.image_min_dimension_tip", {
            minWidth: this.minWidth,
            minHeight: this.minHeight
          })
        );
      }
      if (!tipSegments.length) {
        return prefixTipSegment;
      }
      return prefixTipSegment + (tipSegments.join($i("scp.vt_component.sf_widget.packages.upload.comma")) + $i("scp.vt_component.sf_widget.packages.upload.period"));
    },
    isReachMaxCount() {
      return this.fileList.length >= this.maxCount;
    },
    addUploadTip() {
      return $i("scp.vt_component.sf_widget.packages.upload.image_upload.add_tip");
    },
    deleteBtnTip() {
      return $i("scp.vt_component.sf_widget.packages.upload.image_upload.delete_tip");
    },
    viewImageTip() {
      return $i("scp.vt_component.sf_widget.packages.upload.image_upload.view_image_tip");
    }
  },
  methods: {
    getFullUtid(utidBase) {
      return this.$attrs.utid ? `${this.$attrs.utid}-${utidBase}` : utidBase;
    },
    addChooseFile() {
      const rawFileUploadRef = this.$refs.rawUpload;
      if (!rawFileUploadRef) {
        return;
      }
      rawFileUploadRef.triggerFileUpload();
    },
    isOverMaxCount(files) {
      return files.length + this.fileList.length > this.maxCount;
    },
    async handleFileChange(fileInfoList) {
      if (!fileInfoList || !fileInfoList.length) {
        return;
      }
      this.illegalMessages = [];
      let files = fileInfoList;
      if (this.isOverMaxCount(files)) {
        const remainCount = this.maxCount - this.fileList.length;
        const abandonCount = files.length - this.maxCount;
        files = files.slice(0, remainCount);
        this.illegalMessages.push(
          $i("scp.vt_component.sf_widget.packages.upload.image_max_count_error_tip", {
            abandonCount,
            maxCount: this.maxCount
          })
        );
      }
      const validatedFileInfoList = await this.getValidateImageInfoList(files);
      this.uploadFileList.unshift(...validatedFileInfoList);
      validatedFileInfoList.forEach((fileInfo) => {
        this.onChange(fileInfo, this.fileList);
      });
      if (this.isFailNotifyStatus(fileInfoList, this.failNotify)) {
        this.notifyIllegalMessages(this.illegalMessages);
      }
      if (!this.autoUpload) {
        this.loadLocalImageList(validatedFileInfoList);
        return;
      }
      this.submit();
    },
    loadLocalImageList(imageInfoList) {
      if (!imageInfoList || !imageInfoList.length) {
        return;
      }
      imageInfoList.forEach((imageInfo) => this.loadLocalImage(imageInfo));
    },
    startFadeProgress(imageInfo, callback, stopCallback) {
      const delayName = `${PROGRESS_DELAY_NAME}_${imageInfo.id}`;
      const runProgress = () => {
        sleep(delayName, Math.floor(PROGRESS_DELAY_TIME / (PROGRESS_MAX_PERCENT / PROGRESS_DELAY_STEP))).then(() => {
          clearSleep(delayName);
          if (!this.isProgressDone(imageInfo)) {
            isFunction$1(callback) && callback(imageInfo.progressInfo.percent + PROGRESS_DELAY_STEP);
            runProgress();
          } else {
            if (!imageInfo.localUrl && !this.isFileErrorStatus(imageInfo)) {
              runProgress();
              return;
            }
            isFunction$1(stopCallback) && stopCallback();
          }
        });
      };
      runProgress();
    },
    loadLocalImage(imageInfo) {
      if (!this.isFileReadyStatus(imageInfo)) {
        return;
      }
      const currentImageInfo = Object.assign({}, imageInfo);
      currentImageInfo.status = FILE_STATUS.UPLOADING;
      this.updateFileInfo(currentImageInfo);
      const runningProgressCallback = (percent) => {
        currentImageInfo.progressInfo.percent = percent;
        this.updateFileInfo(currentImageInfo);
      };
      const stopProgressCallback = () => {
        if (this.isFileErrorStatus(currentImageInfo)) {
          return;
        }
        currentImageInfo.status = FILE_STATUS.LOADED;
        this.updateFileInfo(currentImageInfo);
      };
      this.startFadeProgress(currentImageInfo, runningProgressCallback, stopProgressCallback);
      const localUrl = getFileUrl(currentImageInfo.file);
      if (localUrl) {
        currentImageInfo.localUrl = localUrl;
      } else {
        currentImageInfo.status = FILE_STATUS.ERROR;
        currentImageInfo.errorMsg = $i("scp.vt_component.sf_widget.packages.upload.image_upload.upload_error_msg");
      }
      this.updateFileInfo(currentImageInfo);
    },
    async getValidateImageInfoList(imageInfoList) {
      const validImageInfoList = [];
      const validatePromises = imageInfoList.map(async (imageInfo) => {
        const invalidMsgs = await this.validateImage(imageInfo);
        invalidMsgs.forEach((invalidMsg) => {
          this.illegalMessages.push(invalidMsg);
        });
        validImageInfoList.push({
          ...imageInfo,
          ...invalidMsgs.length ? { status: FILE_STATUS.ERROR, errorMsg: $i("scp.vt_component.sf_widget.packages.upload.image_error_msg") } : {}
        });
      });
      await Promise.all(validatePromises);
      return validImageInfoList;
    },
    async validateImage(imageInfo) {
      const validateFailMsgs = [];
      const validateTypeResult = validateFileType(
        this.acceptTypes,
        imageInfo,
        $i("scp.vt_component.sf_widget.packages.upload.image_type_error_tip", {
          types: this.acceptTypes.join("/").replace(/\./g, "")
        })
      );
      const validateSizeResult = validateFileSize(
        this.maxSize,
        imageInfo,
        $i("scp.vt_component.sf_widget.packages.upload.image_size_error_tip", {
          maxSize: format.fileSize(this.maxSize)
        })
      );
      const validateDimensionResult = await this.validateImageDimension(imageInfo);
      validateTypeResult !== true && validateFailMsgs.push(validateTypeResult);
      validateSizeResult !== true && validateFailMsgs.push(validateSizeResult);
      validateDimensionResult !== true && validateFailMsgs.push(validateDimensionResult);
      return validateFailMsgs;
    },
    isProgressDone(imageInfo) {
      if (!imageInfo.progressInfo) {
        return true;
      }
      return imageInfo.progressInfo.percent >= PROGRESS_MAX_PERCENT;
    },
    isShowImage(imageInfo) {
      return this.isFileLoadedStatus(imageInfo) || this.isFileUploadedStatus(imageInfo) || this.isFileDeletingStatus(imageInfo);
    },
    viewImage(imageIndex) {
      const viewer2 = this.$refs.sfImageUploadWrap.$viewer;
      if (!viewer2) {
        return;
      }
      viewer2.show();
      viewer2.view(imageIndex);
    },
    notifyIllegalMessages(messages) {
      if (!messages || !messages.length) {
        return;
      }
      const msgs = Array.from(new Set(messages));
      msgs.forEach((msg) => {
        setTimeout(() => {
          notify.fail(msg);
        });
      });
    },
    getDisplayImageBgCls(imageInfo) {
      if (!this.isShowImage(imageInfo)) {
        return "";
      }
      return IMG_BG_CLS_MAP[this.imageBgCls] || this.imageBgCls;
    },
    async validateImageDimension(imageInfo) {
      const fileUrl = getFileUrl(imageInfo.file);
      if (!fileUrl) {
        return $i("scp.vt_component.sf_widget.packages.upload.image_upload.upload_error_msg");
      }
      const imageRect = await getImageRect(fileUrl);
      if (this.minWidth && imageRect.width < this.minWidth || this.minHeight && imageRect.height < this.minHeight) {
        return $i("scp.vt_component.sf_widget.packages.upload.image_min_dimension_error_tip", {
          minWidth: this.minWidth,
          minHeight: this.minHeight
        });
      }
      if (this.limitWidth && imageRect.width !== this.limitWidth || this.limitHeight && imageRect.height !== this.limitHeight) {
        return $i("scp.vt_component.sf_widget.packages.upload.image_limit_dimension_error_tip", {
          limitWidth: this.limitWidth,
          limitHeight: this.limitHeight
        });
      }
      return true;
    },
    getPrefixedClassName
  }
};
const __vue_script__$1 = script$1;
var __vue_render__$1 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    { class: _vm.getPrefixedClassName("sf-image-upload") },
    [
      _c("raw-upload", {
        ref: "rawUpload",
        attrs: { accept: _vm.accept, multiple: _vm.multiple },
        on: { "file-change": _vm.handleFileChange }
      }),
      _vm._v(" "),
      _c(
        "div",
        {
          directives: [
            {
              name: "viewer",
              rawName: "v-viewer",
              value: _vm.viewerOptions,
              expression: "viewerOptions"
            }
          ],
          ref: "sfImageUploadWrap",
          class: _vm.getPrefixedClassName("sf-image-upload__wrap")
        },
        [
          !_vm.isReachMaxCount ? _c(
            "div",
            {
              class: _vm.getPrefixedClassName("sf-image-upload__add"),
              style: _vm.boxStyle,
              attrs: { title: _vm.addUploadTip },
              on: { click: _vm.addChooseFile }
            },
            [
              _c("i", {
                staticClass: "iconfont vtv-icon-upload-image",
                class: _vm.getPrefixedClassName(
                  "sf-image-upload__add-icon"
                )
              })
            ]
          ) : _vm._e(),
          _vm._v(" "),
          _vm._l(_vm.fileList, function(imageInfo, imageIndex) {
            return _c(
              "div",
              {
                key: imageInfo.id,
                class: [
                  _vm.getPrefixedClassName("sf-image-upload__display-image"),
                  _vm.getPrefixedClassName(
                    "sf-image-upload__display-image--" + imageInfo.status
                  ),
                  _vm.getDisplayImageBgCls(imageInfo)
                ],
                style: _vm.boxStyle
              },
              [
                _vm.isFileUploadingStatus(imageInfo) || _vm.isFileErrorStatus(imageInfo) ? _c("upload-status", {
                  class: _vm.getPrefixedClassName(
                    "sf-image-upload__progress-status"
                  ),
                  attrs: {
                    "file-info": imageInfo,
                    "status-tip": _vm.statusTip
                  }
                }) : _vm._e(),
                _vm._v(" "),
                !_vm.isFileDeletingStatus(imageInfo) ? _c("i", {
                  staticClass: "iconfont vtv-icon-line-delete",
                  class: _vm.getPrefixedClassName(
                    "sf-image-upload__delete-icon"
                  ),
                  attrs: {
                    title: _vm.deleteBtnTip,
                    utid: _vm.getFullUtid("delete-file")
                  },
                  on: {
                    click: function($event) {
                      return _vm.deleteFile(imageInfo);
                    }
                  }
                }) : _c("i", {
                  staticClass: "iconfont vtv-icon-refresh",
                  class: _vm.getPrefixedClassName(
                    "sf-image-upload__deleting-icon"
                  )
                }),
                _vm._v(" "),
                _vm.isShowImage(imageInfo) ? _c("div", {
                  class: _vm.getPrefixedClassName(
                    "sf-image-upload__image-mask"
                  ),
                  attrs: { title: _vm.viewImageTip },
                  on: {
                    click: function($event) {
                      return _vm.viewImage(imageIndex);
                    }
                  }
                }) : _vm._e(),
                _vm._v(" "),
                _vm.isShowImage(imageInfo) ? _c(
                  "div",
                  {
                    class: _vm.getPrefixedClassName(
                      "sf-image-upload__loaded-image"
                    )
                  },
                  [
                    _c("img", {
                      attrs: { src: imageInfo.localUrl || imageInfo.url }
                    })
                  ]
                ) : _vm._e()
              ],
              1
            );
          })
        ],
        2
      ),
      _vm._v(" "),
      _vm.supportImageTip || _vm.$slots.tip ? _c(
        "div",
        { class: _vm.getPrefixedClassName("sf-image-upload__bottom") },
        [
          _c(
            "div",
            {
              class: _vm.getPrefixedClassName(
                "sf-image-upload__bottom__tip"
              )
            },
            [_vm._t("tip", [_vm._v(_vm._s(_vm.supportImageTip))])],
            2
          )
        ]
      ) : _vm._e()
    ],
    1
  );
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
var script = {
  name: componentName.upload,
  mixins: [UploadHookMixin],
  componentName: componentName.upload,
  props: {
    type: {
      type: String,
      default: UPLOAD_TYPE.PICTURE_CARD,
      validator: (type) => [UPLOAD_TYPE.PICTURE_CARD, UPLOAD_TYPE.FILE_LIST, UPLOAD_TYPE.DRAG].includes(type)
    },
    autoUpload: {
      type: Boolean,
      default: true
    },
    disabled: {
      type: Boolean,
      default: false
    },
    tip: {
      type: String,
      default: ""
    },
    deleteApi: Function,
    fileListWidth: String,
    accept: [String, Array],
    multiple: Boolean,
    maxSize: Number,
    maxCount: Number,
    statusTip: Function,
    boxWidth: String,
    boxHeight: String,
    minWidth: Number,
    minHeight: Number,
    limitWidth: Number,
    limitHeight: Number,
    imageBgCls: String,
    defaultFileList: Array,
    uploadApi: {
      type: Function,
      required: true
    },
    urlField: String,
    failNotify: {
      type: Function | Boolean,
      default: true
    }
  },
  computed: {
    renderComponent() {
      const uploadComponentMap = {
        [UPLOAD_TYPE.PICTURE_CARD]: __vue_component__$1,
        [UPLOAD_TYPE.FILE_LIST]: __vue_component__$3,
        [UPLOAD_TYPE.DRAG]: __vue_component__$4
      };
      return uploadComponentMap[this.type];
    },
    isDragComponent() {
      return this.type === UPLOAD_TYPE.DRAG;
    },
    commonProps() {
      return {
        maxSize: this.maxSize,
        accept: this.accept,
        uploadApi: this.uploadApi,
        urlField: this.urlField,
        statusTip: this.statusTip,
        beforeUpload: this.beforeUpload,
        beforeRemove: this.beforeRemove,
        onProgress: this.onProgress,
        onSuccess: this.onSuccess,
        onError: this.onError,
        onRemove: this.onRemove,
        onChange: this.onChange,
        disabled: this.disabled,
        tip: this.tip
      };
    },
    multiFileProps() {
      return {
        defaultFileList: this.defaultFileList,
        maxCount: this.maxCount,
        multiple: this.multiple
      };
    },
    specialProps() {
      const specialPropsMap = {
        [UPLOAD_TYPE.PICTURE_CARD]: {
          failNotify: this.failNotify,
          boxWidth: this.boxWidth,
          boxHeight: this.boxHeight,
          minWidth: this.minWidth,
          minHeight: this.minHeight,
          limitWidth: this.limitWidth,
          limitHeight: this.limitHeight,
          imageBgCls: this.imageBgCls,
          autoUpload: this.autoUpload,
          deleteApi: this.deleteApi
        },
        [UPLOAD_TYPE.FILE_LIST]: {
          failNotify: this.failNotify,
          autoUpload: this.autoUpload,
          deleteApi: this.deleteApi,
          fileListWidth: this.fileListWidth
        },
        [UPLOAD_TYPE.DRAG]: {
          boxWidth: this.boxWidth,
          boxHeight: this.boxHeight
        }
      };
      return specialPropsMap[this.type] || {};
    },
    componentProps() {
      return {
        ...this.commonProps,
        ...this.specialProps,
        ...this.isDragComponent ? {} : this.multiFileProps
      };
    }
  },
  methods: {
    getUploader() {
      return this.$refs.innerUploader;
    },
    submit() {
      const uploader = this.getUploader();
      if (!uploader) {
        return;
      }
      return uploader.submit();
    },
    triggerUpload() {
      const uploader = this.getUploader();
      if (!uploader) {
        return;
      }
      return uploader.addChooseFile();
    },
    getFileList() {
      const uploader = this.getUploader();
      if (!uploader) {
        return [];
      }
      return uploader.fileList;
    },
    removeFile(fileInfo) {
      const uploader = this.getUploader();
      if (!uploader) {
        return;
      }
      uploader.deleteFile(fileInfo);
    }
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    _vm.renderComponent,
    _vm._b(
      {
        ref: "innerUploader",
        tag: "component",
        scopedSlots: _vm._u(
          [
            {
              key: "result",
              fn: function(props) {
                return _vm._t("result", null, null, props);
              }
            }
          ],
          null,
          true
        )
      },
      "component",
      _vm.componentProps,
      false
    ),
    [
      _vm._t("tip", null, { slot: "tip" }),
      _vm._v(" "),
      _vm._t("default", null, { slot: "default" }),
      _vm._v(" "),
      _vm._t("upload", null, { slot: "upload" })
    ],
    2
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__ as SfUpload };
