import type { SfGridStore, SfGridStoreModel } from './store';

import Vue, { VNode } from 'vue';

type SfGridColumnCeilTip<T = any> =
  | boolean
  | 'auto'
  | ((text: string, record: SfGridStoreModel<T>, row: number, col: number, store: SfGridStore<T>) => string);

export interface SfGridColumnProps<T = any> {
  /**
   * 设置列标题
   */
  header: string;

  /**
   * 给列标题设置data-hint
   */
  headerCeilTip?: true | string;

  /**
   * 设置列标题文字对齐方式
   *
   * @default 'left''
   */
  headerAlign?: 'left' | 'center' | 'right';

  /**
   * 设置列对齐方式
   *
   * @default 'left'
   */
  align?: 'left' | 'center' | 'right';

  /**
   * 给列标题设置类名
   */
  headerCls?: string;

  /**
   * 设置需要显示的数据域
   */
  dataIndex?: string;

  /**
   * 设置需要显示的数据域，同dataIndex
   */
  field?: string;

  /**
   * 设置列宽度，如'200px'
   */
  width?: string;

  /**
   * 设置列最小宽度，如'200px'
   */
  minWidth?: string;

  /**
   * 同tip，设置单元格出现提示
   *
   * @default false
   */
  ceilTip?: SfGridColumnCeilTip<T>;

  /**
   * 同ceilTip，设置单元格出现提示
   *
   * @default false
   */
  tip?: SfGridColumnCeilTip<T>;

  /**
   * 设置可排序列，需要和sortable插件一起用
   */
  sortable?: boolean;

  /**
   * 给列单元格的icon元素添加类
   */
  iconCls?: string;

  /**
   * 是否使用ellipsis类名
   *
   * @default true
   */
  ellipsis?: boolean;

  /**
   * 设置列标题tip的图标
   *
   * @default 'vtv-icon-tip-info'
   */
  headerTipIcon?: string;

  /**
   * 设置列标题tip的图标
   *
   * @default 'vtv-icon-filter'
   */
  headerFilterIcon?: string;

  /**
   * tip的css类名
   */
  tipCls?: string;

  /**
   * 排序的回调函数
   */
  sortFn?: (pre: T, next: T, direct: 'ASC' | 'DESC') => number;

  /**
   * 是否隐藏列
   */
  hidden?: boolean;

  // 自定义渲染函数
  renderer?: (
    renderText: string,
    record: SfGridStoreModel<T>,
    row: number,
    col: number,
    store: SfGridStore<T>,
  ) => string;
}

export interface SfGridColumnSlots {
  $slots: {
    'header-tip'?: VNode[];
  };
}

export declare type SfGridColumn = Readonly<SfGridColumnProps & SfGridColumnSlots> & Vue;
