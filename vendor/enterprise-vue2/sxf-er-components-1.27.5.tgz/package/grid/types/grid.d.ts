import type {
  SfGridActionPlugin,
  SfGridAutoRefreshPlugin,
  SfGridCheckSelectionPlugin,
  SfGridCustomColumnPlugin,
  SfGridFixedColumnPlugin,
  SfGridGroupPlugin,
  SfGridPagingBarPlugin,
  SfGridPluginConfig,
  SfGridPluginType,
  SfGridRadioGroupSelectionPlugin,
  SfGridRadioSelectionPlugin,
  SfGridResizeablePlugin,
  SfGridSelectionPlugin,
  SfGridSortablePlugin,
  SfGridTreePlugin,
} from './plugins';
import type { SfGridSearchOptions, SfGridStoreModel, SfGridStoreOptions } from './store';

import Vue, { VNode } from 'vue';

interface SfGridHeaderGroupItem {
  /**
   * 当前表头分组的名称
   */
  title?: string;
  /**
   * 当前表头分组的列或者下级分组
   * 类型是 string 时应该对应列的 field
   * 类型是 SfGridHeaderGroupItem[] 时表示继续分组
   */
  children?: (string | SfGridHeaderGroupItem)[];
}

type SfGridHeaderGroupConfig = SfGridHeaderGroupItem[];

/** 表格配置项 */
export interface SfGridOptions<T = any> {
  /**
   * 跟height一样，但如果配置成“auto”则表示表格的高度跟记录的条数一致，会自动撑大，可以配合minWidth使用
   *
   * @default 'auto'
   */
  width?: number | string | 'auto';

  /**
   * 跟width一样，但如果配置成“auto”则表示表格的高度跟记录的条数一致，会自动撑大，可以配合minHeight使用
   *
   * @default '100%'
   */
  height?: number | string | 'auto';

  /**
   * 样式在最外层的dom上面
   *
   * @default ''
   */
  cls?: string;

  /**
   * 当height配置成auto时有效
   */
  minHeight?: number | string | 'auto';

  /**
   * 当height配置成auto时有效
   */
  maxHeight?: number | string | 'auto';

  /**
   * minRows 当height配置成auto时有效
   * 最小显示行数，minHeight未配置时有效
   */
  minRows?: number;

  /**
   * maxRows 当height配置成auto时有效
   * 最大显示行数，maxHeight未配置时有效
   */
  maxRows?: number;

  /**
   * 每行记录的高度，计算bufferView时使用，特别是表格中包含图片时，要保证这个值与行的真实高度一致
   * render后，会自动再获取最真实的高度重新计算，外部也要不管这个配置
   *
   * @default 40
   */
  rowHeight?: number;

  /**
   * 表格的size，配置之后会覆盖rowHeight
   * 'normal' | 'small' | 'large' | 'xlarge' | 'xxlarge'
   */
  size?: 'normal' | 'small' | 'large' | 'xlarge' | 'xxlarge';

  /**
   * 表格头的size
   */
  headerSize?: 'small' | '';

  /**
   * 单元格中的空白字符处理，如果配置成true，td下面的元素会加上white-space: pre，谨慎使用
   * 如果内容包含\n，会导致行的高度变化，跟rowHeight冲突！
   *
   * @default false
   */
  encodeWhiteSpace?: boolean;

  /**
   * 配置是否监听`行双击事件`默认关闭。可得到参数（grid, record, event）
   *
   * @default false
   */
  enableRowDblClick?: boolean;

  /**
   * 当column.dataIndex取到的值为Empty时的默认显示。（判断方法使用Lang.isEmpty）
   *
   * @default ''
   */
  dftColumnText?: string;

  /**
   * 当表格数据为空时，表格显示的文本
   *
   * @default '空'
   */
  noDataText?: string;

  /**
   * 当表格数据为空时，表格显示的文本是否统一编码
   *
   * @default true
   */
  noDataTextEncode?: boolean;

  /**
   * 是否带边框
   * 默认不带边框，header左侧没有边框，body也没有边框
   */
  border?: boolean;

  /**
   * 每列是否带边框
   *
   * @default true
   */
  colBorder?: boolean;

  /**
   * 搜索配置
   */
  search?: SfGridSearchOptions<T>;

  /**
   * 第一次加载显示loadMask
   *
   * @default false
   */
  autoLoadMask?: boolean;

  /**
   * 隐藏头部，默认false
   *
   * @default false
   */
  noHeader?: boolean;

  /**
   * 给每行添加class
   *
   * @default ''
   */
  rowCls?: string | ((record: T) => string);

  /**
   * 是否使用bufferView 的方式渲染表格，默认false
   * 为true时，不使用，则渲染时渲染全部数据
   *
   * @default false
   */
  noBufferView?: boolean;

  /**
   * 表格滚动条宽度，非WebKit浏览器不支持设置滚动条宽度
   *
   * @default 18
   */
  scrollWidth?: number;

  /**
   * 插件列表
   */
  plugins?: (SfGridPluginConfig<T> | SfGridPluginType)[];

  /**
   * store
   */
  store?: SfGridStoreOptions;

  /**
   * 表格列配置
   */
  column?: any[];

  /**
   * 监听函数
   */
  listeners?: Record<string, Function>;

  /**
   * 多级表头配置
   */
  headerGroup?: SfGridHeaderGroupConfig;

  /**
   * 不管是不是隐藏状态都会renderView
   *
   * @default true
   */
  alwaysRenderView?: boolean;

  /**
   * vue表格渲染插槽的上限
   *
   * @default 40
   */
  renderSlotLimit?: number;
}

/** 表格slot数据 */
export interface SfGridSlotData<T> {
  dataIndex: string;
  record: T;
  value: T[keyof T];
  row: number;
  col: number;
  number: number;
  groupText: string;
  isGroup: boolean;
  isEmpty: boolean;
}

export interface SfGridEvents<T = any> {
  /**
   * 行单击事件
   */
  $emit(eventName: 'cell-click', slotData: SfGridSlotData<T>): this;

  /**
   * 行双击事件
   */
  $emit(eventName: 'cell-dblclick', slotData: SfGridSlotData<T>): this;

  /**
   * grid widget 事件
   */
  $emit(eventName: 'render' | 'afterrender' | 'updateoption' | 'viewready' | 'rowdblclick', ...args: any[]): this;
}

export interface SfGridSlots {
  $slots: {
    default: VNode[];
    empty?: VNode[];
    header?: VNode[];
    footer?: VNode[];
  };
}

export interface SfGridProps<T = any> {
  /**
   * 传入Grid配置，详情见common/widget/Grid.js
   * - 不支持options.column，请使用sf-grid-column
   * - options.store支持直接传入store配置，不需要new
   * - 不允许设置options.ceilTip为函数，请使用作用域插槽
   * - 默认会为所有的单元格渲染加上ellipsis类名
   * - plugins支持传入如下形式的配置项，不需要传入插件构造函数 {
   *     pluginID: 'Group', // 插件id
   *     pluginOption1: xxx,  // 插件配置
   *     pluginOption2: xxx // 插件配置
   *   }
   */
  options: SfGridOptions<T>;

  /**
   * 默认的表格配置，用来给组件配置统一的默认值
   */
  defaultOptions: SfGridOptions<T>;

  /**
   * 默认在toolbar中自动查找搜索框组件并绑定搜索事件，支持：
   * - true, 自动查找
   * - false，关闭自动处理
   * - 搜索框组件的ref名，根据ref在上下文自动寻找搜索框组件
   *
   * @default true
   */
  autoSearch: boolean;

  /**
   * 统一设置每列宽度
   *
   * @default 'auto'
   */
  columnWidth: number | string;

  /**
   * 统一配置每列头部是否需要鼠标浮动提示列标题
   *
   * @default true
   */
  headerCeilTip: boolean;

  /**
   * 数据为空时表格内显示的类型，image为使用sf-empty的图标加文本
   *
   * @default 'image'
   * @type string
   */
  emptyTheme: 'text' | 'image';

  /**
   * 数据为空时的配置,
   * emptyTheme为image时可配置正常与异常显示的文本与图标
   * 若配置abnormalText，则会覆盖后台返回的异常显示文本
   */
  emptyConfig: {
    icon?: string;
    text?: string;
    abnormalIcon: string;
    abnormalText: string;
  };

  /**
   * 是否禁用
   */
  readonly disabled: boolean;
}

export interface SfGridMethods<T = any> {
  /**
   * 可以覆盖掉原有的参数
   *
   * @param option
   * @param keepLastData 值不为true时，使用的是浅拷贝，如果option传入{data: {}}，则整个data都会被替换掉，
   * 导致原有data中的其他旧数据丢失，如分页的参数或其他原有参数。传入true时，则会保留原有的旧参数
   */
  reload(option?: any, keepLastData?: boolean): any;

  /**
   * 加载表格的数据
   */
  loadData(data: T[]): void;

  getPageStartIndex(): number;

  getIdProperty(): string;

  updateOption(): void;

  /** ------------grid widget的方法------------- */

  /**
   * 获取view宽度
   */
  getViewWidth(): number;

  /**
   * 获取view高度
   */
  getViewHeight(): number;

  /**
   * 获取数据
   */
  getData(): T[];

  /**
   * 获取表格元素id
   */
  getId(): string;

  /**
   * 获取表格元素
   */
  getGridEl(): HTMLElement;

  /**
   * 设置表格最小高度，调用后自动将height设置为auto
   */
  setMinHeight(minHeight?: number): void;

  /**
   * 获取表格body元素高度，可传入整个表格的高度值，否则使用clientHeight值
   */
  getBodyElSize(gridElHeight?: number): number;

  /**
   * 修改元素body元素高度，height为auto无效
   */
  updateElSize(): void;

  /**
   * 获取数据项个数
   */
  getStoreCount(): number;

  /**
   * 添加记录
   */
  add(records: SfGridStoreModel<T> | SfGridStoreModel<T>[]): boolean;

  /**
   * 删除记录
   */
  insert(records: SfGridStoreModel<T> | SfGridStoreModel<T>[], index: number): boolean | string;

  /**
   * 删除记录
   */
  remove(records: SfGridStoreModel<T> | SfGridStoreModel<T>[]): void;

  /**
   * 获取插件实例
   */
  getPlugin(pluginId: 'Action'): SfGridActionPlugin;
  getPlugin(pluginId: 'AutoRefresh'): SfGridAutoRefreshPlugin;
  getPlugin(pluginId: 'Resizeable'): SfGridResizeablePlugin;
  getPlugin(pluginId: 'Group'): SfGridGroupPlugin<T>;
  getPlugin(pluginId: 'Tree'): SfGridTreePlugin<T>;
  getPlugin(pluginId: 'PagingBar'): SfGridPagingBarPlugin;
  getPlugin(pluginId: 'Selection'): SfGridSelectionPlugin<T>;
  getPlugin(pluginId: 'RadioSelection'): SfGridRadioSelectionPlugin<T>;
  getPlugin(pluginId: 'CheckSelection'): SfGridCheckSelectionPlugin<T>;
  getPlugin(pluginId: 'RadioGroupSelection'): SfGridRadioGroupSelectionPlugin<T>;
  getPlugin(pluginId: 'Sortable'): SfGridSortablePlugin;
  getPlugin(pluginId: 'CustomColumn'): SfGridCustomColumnPlugin;
  getPlugin(pluginId: 'FixedColumn'): SfGridFixedColumnPlugin;
  getPlugin(pluginId: SfGridPluginType): any;

  /**
   * 刷新表格，一般用于手动更改了store里的内容，调用refresh可以重新渲染出html
   * 等价于renderView
   */
  refresh(): void;

  /**
   * 调用store.search
   */
  search(str?: string, options?: SfGridSearchOptions): void;

  /**
   * 调用store.endSearch
   */
  endSearch(): void;

  /**
   * 调用store.forceReload
   * 给表格添加强制刷新数据的标识
   *
   * @param {Object} option - 新请求参数，同表格store.reload
   * @param {Boolean} keepLastData - 可选项，如果新参数option中无对应的项，是否将上次请求的参数深copy到新参数option，默认copy
   */
  forceReload(option?: any, keepLastData?: boolean): any;

  renderView(start?: number, limit?: number): void;

  /**
   * 渲染DOM初始化
   */
  render(sel: HTMLElement): void;

  /**
   * 表格重绘方法，会重新计算高度和重绘表格内容，以下情况应当调用redraw方法：
   * - 初始化时表格元素隐藏，当显示之后
   * - 表格自适应父元素高度，当父元素高度改变之后
   */
  redraw(): void;

  destroy(): void;

  /** ------------grid widget的方法 end------------- */
}

export declare type SfGrid<T = any> = Readonly<SfGridProps<T> & SfGridEvents<T> & SfGridSlots & SfGridMethods<T>> & Vue;
