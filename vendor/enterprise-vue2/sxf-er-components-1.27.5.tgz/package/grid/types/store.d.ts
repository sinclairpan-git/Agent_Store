/**
 * @file grid store
 */

export interface SfGridStoreModel<T = any> {
  data: T;

  get(key: keyof T): T[keyof T];

  set(key: keyof T | Record<keyof T, T>, suspend?: boolean): void;
}

export type SfGridStoreRecords<T> = T | SfGridStoreModel<T> | (T | SfGridStoreModel<T>)[];

/**
 * gridStore监听函数
 */
interface SfGridStoreListeners<T = any> {
  /**
   * 当数据初始化前触发
   */
  beforeinitdata?: (me: SfGridStore, data: T[]) => boolean | undefined;

  /**
   * 当数据初始化后触发
   */
  initdata?: (me: SfGridStore, data: T[]) => void;

  /**
   * 当数据发生改变前触发
   */
  beforedatachange?: (me: SfGridStore, records: SfGridStoreModel<T>[]) => boolean | undefined;

  /**
   * 当数据发生改变时触发
   */
  datachange?: (me: SfGridStore, records: SfGridStoreModel<T>[]) => void;

  /**
   * 发请求前触发
   */
  beforeload?: (me: SfGridStore, ajaxOptions: any) => void;

  /**
   * 发请求时触发
   */
  load?: (success: boolean, json?: any, args?: any) => void;

  loaderror?: (msg: string) => void;

  add?: (model: SfGridStoreModel<T>) => void;

  remove?: (model: SfGridStoreModel<T>) => void;

  search?: () => void;

  'end-search'?: () => void;
}

export interface SfGridSearchOptions<T = any> {
  /**
   * 是否匹配大小写
   *
   * @default false
   */
  matchCase?: boolean;

  /**
   * 传入字段数组 或者 函数
   *
   * @default ['name']
   */
  match?: (keyof T)[] | ((record: SfGridStoreModel<T>, strReg?: RegExp, str?: string) => boolean);
}

/**
 * gridStore配置
 */
export interface SfGridStoreOptions<T = any> {
  /**
   * 外部传进来的record是一个 [{id: 'xx', name: 'fdsa'}, {}...]
   */
  data?: T[];

  /**
   * 指明哪个字段是id
   *
   * @default 'id'
   */
  idProperty?: keyof T;

  /**
   * 数据根节点字段
   *
   * @default 'data'
   */
  root?: string;

  /**
   * 数据总数字段
   *
   * @default 'count'
   */
  totalProperty?: string;

  /**
   * 接收ajax配置
   *
   * @default null
   */
  ajax?: any;

  /**
   * 跨页勾选状态保存
   *
   * @default false
   */
  keepLostSelectedData?: Boolean;

  listeners?: SfGridStoreListeners<T>;

  /**
   * 是否开启数据 diff，防止数据未更新进行额外渲染
   *
   * @default false
   */
  diffData?: boolean;
}

export class SfGridStore<T = any> {
  constructor(options?: SfGridStoreOptions<T>);

  init(): void;

  load(option: any): any;

  /**
   * 可以覆盖掉原有的参数
   *
   * @param {any} option
   * @param {boolean} [keepLastData]
   * 值不为true时，使用的是浅拷贝，如果option传入{data: {}}，则整个data都会被替换掉，
   * 导致原有data中的其他旧数据丢失，如分页的参数或其他原有参数。传入true时，则会保留原有的旧参数
   *
   * @returns {any}
   */
  reload(option: any, keepLastData?: boolean): any;

  getTotalSize(): number;

  loadData(data: T[]): void;

  reloadData(): void;

  /**
   * 给表格添加强制刷新数据的标识，同reload
   *
   * @param {any} option
   * @param {boolean} [keepLastData]
   * @returns {any}
   */
  forceReload(option: any, keepLastData?: boolean): any;

  /**
   *
   * 添加记录
   *
   * @param {(SfGridStoreModel<T> | SfGridStoreModel<T>[])} records
   * @returns {boolean}
   */
  add(records: SfGridStoreModel<T> | SfGridStoreModel<T>[]): boolean;

  /**
   * 插入记录
   *
   * @param {(SfGridStoreModel<T> | SfGridStoreModel<T>[])} records
   * @param {number} index
   * @returns {(boolean | string)} 插入的id或者插入失败
   */
  insert(records: SfGridStoreModel<T> | SfGridStoreModel<T>[], index: number): boolean | string;

  /**
   * 删除记录
   *
   * @param {(SfGridStoreModel<T> | SfGridStoreModel<T>[])} records
   * @memberof GridStore
   */
  remove(records: SfGridStoreModel<T> | SfGridStoreModel<T>[]): void;

  get(key: string): SfGridStoreModel<T>;

  /**
   * 返回数据的所有ID
   */
  getAllKeys(records: SfGridStoreRecords<T>): string[];

  getKeys(records: SfGridStoreRecords<T>): SfGridStoreModel<T>[];

  /**
   * 获取数据项的Model实例
   */
  toModels(records: SfGridStoreRecords<T>): SfGridStoreModel<T>[];

  /**
   * 获取数据项的Model实例，如果没有model，则创建model返回
   */
  toAllModels(records: SfGridStoreRecords<T>): SfGridStoreModel<T>[];

  /**
   * 重新触发搜索
   */
  searchAgain(): void;

  search(str?: string, options?: SfGridSearchOptions): void;

  endSearch(): void;

  getVisibleRecords(): SfGridStoreModel<T>[];

  getData(): T[];

  getCount(): number;

  /**
   * 取消当前的请求
   */
  stop(): void;

  destroy(): void;
}

export interface SfGridStoreApiParams extends Record<string, any> {
  start?: number;
  limit?: number;
  sort?: string;
  direct?: string;
  keywords?: string;
  refresh?: number;
  query?: string;
}
