/**
 * @file 表格分组插件
 */

import type { SfGridPlugin, SfGridPluginOptions } from './base';
import type { SfGridStoreModel } from '../store';

export interface SfGridGroupOptions<T = any> extends SfGridPluginOptions {
  readonly pluginId?: 'Group';

  readonly pluginID?: 'Group';

  /**
   * 以哪一项进行分组，如果不配置，则不分组
   */
  groupField?: string | undefined;

  /**
   * 配置分组可以单独选择，适用于当父项也有自己的数据时
   * grid.loadData(data)的数据data格式改为[{a: 1, children: [{}]}]
   *
   * @default false
   */
  isTreeGroup?: boolean;

  /**
   * 分组的子项字段
   * 当且仅当options.isTreeGroup为true时才有效
   *
   * @default 'children'
   */
  childrenField?: string;

  /**
   * 格式化显示分组的标题
   */
  renderer?: Function | undefined;

  /**
   * 当表格配置了Sortable后生效，排序的时候会用排序组，组内部排序仍然使用Sortable里面的
   */
  sortFn?: Function | undefined;

  /**
   * 是否记录上次展开的状态，展开的记录在保存在expandedList里面
   *
   * @default true
   */
  autoExpand?: boolean;

  /**
   * 指明哪些值默认要展开 autoExpand 为true时有效
   */
  expandedList?: string[];

  /**
   * 是否合并所有列
   *
   * @default false
   */
  colspan?: boolean;

  /**
   * 非合并所有列时，非第一列的格式化函数
   */
  minorRenderer?: (fieldTitle: string, record: SfGridStoreModel<T>, row: number, col: number, store: any) => string;

  /**
   * group行不可选时，自定义renderer
   */
  unSelectAbleRenderer?: (record: SfGridStoreModel<T>) => string;

  /**
   * group行不可选时，自定义data-tip的renderer
   */
  unSelectableTipFn?: (record: SfGridStoreModel<T>) => string;

  /**
   * 哪一列显示展开收缩的箭头，不配置默认第一列
   *
   * @default 0
   */
  groupArwCol?: number;

  /**
   * 是否支持对分组进行排序
   *
   * @default true
   */
  sortable?: boolean;

  /**
   * 自动展开全部
   *
   * @default false
   */
  autoExpandAll?: boolean;

  /**
   * 是否需要切换icon
   *
   * @default false
   */
  needToggleIcon?: boolean;

  /**
   * 是否需要启用分步加载（懒加载子节点）
   *
   * @default false
   */
  stepLoad?: boolean;

  /**
   * 是否需要加载子节点
   */
  shouldLoadNodeChildren?: (record: SfGridStoreModel<T>, isNodeLoaded: boolean) => boolean;
}

/** 表格分组插件 */
export class SfGridGroupPlugin<T = any> extends SfGridPlugin {
  constructor(options?: SfGridGroupOptions<T>);

  /**
   * 获取数据项中groupField对应的值
   */
  getGroupText(record: SfGridStoreModel<T> | T): string;

  /**
   * 检测当前数据是否可见
   */
  isRecordVisible(id: string): boolean;

  /**
   * 展开
   * data 为 groupField 对应的值
   */
  expand(data?: string): void;

  /**
   * 收起
   * data 为 groupField 对应的值
   */
  collapse(data?: string): void;

  /**
   * 展开全部
   */
  expandAll(): void;

  /**
   * 收起全部
   */
  collapseAll(): void;

  /**
   * 修改分组的字段
   */
  groupBy(groupField: string): void;

  /**
   * 清除分组字段
   */
  clearGroup(): void;

  /**
   * 刷新，重新loadData
   */
  refresh(): void;

  /**
   * 配置stepLoad后生效，懒加载子节点后需要调用此函数更新子节点，返回值可用于判断节点更新是否成功
   */
  updateGroupNodeData: (record: SfGridStoreModel<T>, childData: T[]) => boolean;
}
