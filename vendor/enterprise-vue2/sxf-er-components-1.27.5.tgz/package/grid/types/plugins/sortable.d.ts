/**
 * @file 表格排序插件
 */

import type { SfGridPlugin, SfGridPluginOptions } from './base';

type directionKeyType = 'ASC' | 'DESC';

export interface SfGridSortableOptions extends SfGridPluginOptions {
  readonly pluginId?: 'Sortable';

  readonly pluginID?: 'Sortable';

  /**
   * 是否远程排序
   *
   * @default false
   */
  remoteSort?: boolean;

  /**
   * 排序时发到后面的字段名，只在remoteSort: true时有效
   *
   * @default 'sort'
   */
  sortKey?: string;

  /**
   * 默认以哪些字段进行排序
   *
   * @default ''
   */
  sortField?: string;

  /**
   *
   * @default 'direct'
   */
  directionKey?: string;

  /**
   * @default 'ASC'
   */
  sortDirection?: directionKeyType;

  /**
   * 第一次排序某一列时，默认的排序方向
   *
   * @default 'ASC'
   */
  defaultDirection?: directionKeyType;

  /**
   * 候选排序字段，用来实现第二、第三关键字，接受字符串或字符串的数组
   *
   * @default []
   */
  candidateField?: string | string[];

  /**
   * 候选排序时，采用的排序方向。空则使用点击的排序方向
   *
   * @default []
   */
  candidateDirection?: directionKeyType | directionKeyType[];
}

/** 表格排序插件 */
export class SfGridSortablePlugin extends SfGridPlugin {
  constructor(options?: SfGridSortableOptions);

  getLastSortCfg(): {
    sortField: string;
    sortDirection: directionKeyType;
  } | null;

  clearSortCfg(): void;
}
