/**
 * @file 表格选择插件
 */

import type { SfGridPlugin, SfGridPluginOptions } from './base';
import type { SfGridStoreModel } from '../store';

interface SfGridStoreNoSelection<T = any> {
  key?: string;
  value?: any | any[];
  checkFn?: (record: SfGridSelectionRecord<T>) => boolean;

  renderer?: () => string;

  rowTip?: (record: T) => string;
}

type SfGridRecordParam<T> = string | string[] | T | T[];

export type SfGridSelectionRecord<T> = SfGridStoreModel<T> & {
  selectAble?: boolean;
  selected?: boolean;
  selectDisabled?: boolean;
};

export interface SfGridSelectMethodParams {
  /**
   * 强制选择
   *
   * @default false
   */
  force?: boolean;

  /**
   * 不触发事件
   *
   * @default false
   */
  noEvent?: boolean;

  /**
   * 结束后renderView
   *
   * @default true
   */
  redraw?: boolean;
}

interface SfGridBaseSelectionOptions<T = any> extends SfGridPluginOptions {
  /**
   * 自动 选择 上次勾选的数据
   *
   * @default true
   */
  autoSelectLastRecord?: boolean;

  /**
   * checkbox是否跟随在数据旁边
   *
   * @default true
   */
  checkboxInTreeField?: boolean;

  /**
   * record.selectAble === false时，也可以选中，仅仅是样式的选中控制
   *
   * @default false
   */
  selectDisabledRecord?: boolean;

  /**
   * 配置单个或多个是“或”关系
   * [{
   *     key: 'fieldName',        //
   *     value: ['a', 'b'],       // 只要fieldName的值是 a 或者 b，那么这一行就不可选择
   *     checkFn: function(record){ return record.get('xx');} //返回真则代表不可选择，与上面的key-value判断是“或”的关系，不建议同时配，不好理解，只配checkFn就能满足
   *     renderer: function () {} // 默认是显示成"-"
   * }, {}, ...]
   *
   * 如果要动态设置，则在store的 initdata、beforedatachange 这里修改record
   * record.selectAble = false;
   */
  noSelections?: SfGridStoreNoSelection<T>[] | SfGridStoreNoSelection<T>;

  /**
   * 是否只能选每个父类的勾选框，以组别来选。默认儿子都有勾选框，不想渲染子的勾选框自行配置为 true
   *
   * @default false
   */
  noChildSelection?: boolean;

  listeners?: {
    selectall?: () => void;
    unselectall?: () => void;
    select?: (record: SfGridSelectionRecord<T>) => void;
    unselect?: (record: SfGridSelectionRecord<T>) => void;

    /**
     * change事件，选中状态改变即会触发
     */
    change?: (plugin: any, records: SfGridSelectionRecord<T>[]) => void;
  };
}

export interface SfGridSelectionOptions<T = any> extends SfGridBaseSelectionOptions<T> {
  readonly pluginId?: 'Selection';

  readonly pluginID?: 'Selection';

  /**
   * single 点击单行的时候，会自动把其它行的选择状态去掉
   * multi 点击时自动选中，再次点击去掉选中状态
   *
   * @default 'single'
   */
  mode?: 'single' | 'multi';
}

/** 表格勾选插件 */
export class SfGridSelectionPlugin<T = any> extends SfGridPlugin {
  constructor(options?: SfGridSelectionOptions<T>);

  setDisabled(record: SfGridRecordParam<T>, disabled: boolean): void;

  setTitle(record: SfGridRecordParam<T>, title: string): void;

  select(record: SfGridRecordParam<T>, options?: SfGridSelectMethodParams): void;

  unSelect(record: SfGridRecordParam<T>, options?: SfGridSelectMethodParams): void;

  unSelectAll(options?: SfGridSelectMethodParams): void;

  selectAll(options?: SfGridSelectMethodParams): void;

  /**
   * 获取选中数据
   */
  getSelections(): SfGridSelectionRecord<T>[];

  /**
   * 获取未选中数据
   */
  getUnSelections(): SfGridSelectionRecord<T>[];

  getDisabledSelect(): SfGridSelectionRecord<T>[];
}

export interface SfGridRadioSelectionOptions<T = any> extends SfGridBaseSelectionOptions<T> {
  readonly pluginId?: 'RadioSelection';

  readonly pluginID?: 'RadioSelection';

  /**
   * single 点击单行的时候，会自动把其它行的选择状态去掉
   * multi 点击时自动选中，再次点击去掉选中状态
   *
   * @default 'single'
   */
  mode?: 'single' | 'multi';

  beforeSelect?: (record: SfGridSelectionRecord<T>) => Promise<boolean> | boolean;
}

/** 表格radio选择插件 */
export class SfGridRadioSelectionPlugin<T = any> extends SfGridSelectionPlugin<T> {
  constructor(options?: SfGridRadioSelectionOptions<T>);
}

export interface SfGridCheckSelectionOptions<T = any> extends SfGridBaseSelectionOptions<T> {
  readonly pluginId?: 'CheckSelection';

  readonly pluginID?: 'CheckSelection';

  /**
   * single 点击单行的时候，会自动把其它行的选择状态去掉
   * multi 点击时自动选中，再次点击去掉选中状态
   * simple 只能点击勾选框才会触发勾选事件
   *
   * @default 'multi'
   */
  mode?: 'multi' | 'single' | 'simple';

  /**
   * 勾选列的宽度
   *
   * @default '36px'
   */
  width?: string;

  /**
   * 是否支持全选
   *
   * @default true
   */
  canSelectAll?: boolean;

  /**
   * Function 渲染提示的函数 record => {};
   *
   * @default null
   */
  tipFn?: (record: SfGridSelectionRecord<T>) => string | null;

  disabled?: SfGridStoreNoSelection<T>[];

  beforeSelect?: (record: SfGridSelectionRecord<T>) => Promise<boolean> | boolean;

  /**
   * selectIllegalRecord 是否允许选择非法数据，及不在表格内的数据也触发 select
   *
   * @default false
   */
  selectIllegalRecord?: boolean;
}

/** 表格checkbox选择插件 */
export class SfGridCheckSelectionPlugin<T = any> extends SfGridSelectionPlugin<T> {
  constructor(options?: SfGridCheckSelectionOptions<T>);
}

export interface SfGridRadioGroupSelectionOptions<T = any> extends SfGridBaseSelectionOptions<T> {
  readonly pluginId?: 'RadioGroupSelection';

  readonly pluginID?: 'RadioGroupSelection';

  /**
   * single 点击单行的时候，会自动把其它行的选择状态去掉
   * multi 点击时自动选中，再次点击去掉选中状态
   *
   * @default 'single'
   */
  mode?: 'single' | 'multi';
}

/** 表格radio group选择插件 */
export class SfGridRadioGroupSelectionPlugin<T = any> extends SfGridSelectionPlugin<T> {
  constructor(options?: SfGridRadioGroupSelectionOptions<T>);

  /** 选中第一项 */
  selectFirst: () => void;

  /** 选中指定分组 */
  selectGroup: (record: SfGridSelectionRecord<T>) => boolean;
}
