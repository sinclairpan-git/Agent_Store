/**
 * @file 表格自定义列插件
 */

import type { SfGridPlugin, SfGridPluginOptions } from './base';

interface DefaultColumnsConfig {
  dataIndex: string;
  showType: 'always' | 'show' | 'unshow';
  customColumnGroup: string;
}

/** 自定义列配置 */
interface CustomColumnConfig {
  /** 列的唯一标识符 */
  columnKey: string;
  /** 列的显示名称 */
  columnName: string;
  /** 指示该列是否为必需 */
  must: boolean;
  /** 指示该列是否被选中 */
  selected: boolean;
}

export interface SfGridCustomColumnOptions extends SfGridPluginOptions {
  readonly pluginId?: 'CustomColumn';

  readonly pluginID?: 'CustomColumn';

  /** 点击恢复默认配置的时候读取 */
  defaultColumnsConfig?: DefaultColumnsConfig[] | (() => DefaultColumnsConfig[]);

  /** 配置是否分组展示 */
  mode?: 'group' | 'normal';

  /** 在浮窗关闭时触发 */
  onConfirmConfig?: Function;

  /** 在配置修改时触发 */
  onConfigChange?: Function;

  /** 列表项的分组名称 */
  groupNameRender?: (groupKey: string) => string;

  /** @default '全选' */
  selectAllText?: string;

  /** 触发自定义列展示面板 */
  customWorkbench?: (
    /** 表格所有列的展示配置 */
    columnConfigs: CustomColumnConfig[],
    /** 表格自定义列插件实例 */
    customColumnPluginInstance: SfGridCustomColumnPlugin,
  ) => void;
}

/** 表格自定义列插件 */
export class SfGridCustomColumnPlugin extends SfGridPlugin {
  constructor(options?: SfGridCustomColumnOptions);

  /**
   * 切换列的显示和隐藏
   *
   * @param {string[]} dataIndex 列的dataIndex
   */
  toggleColumn(dataIndex: string[]): void;

  /**
   * 自定义显示的列
   *
   * @param {string[]} columnsShown dataIndex 的数组  只展示数据内的列
   */
  customColumns(columnsShown: string[]): void;
}
