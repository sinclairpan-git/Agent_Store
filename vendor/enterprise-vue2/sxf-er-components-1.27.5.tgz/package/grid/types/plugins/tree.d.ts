/**
 * @file 表格树插件
 */

import type { SfGridPlugin, SfGridPluginOptions } from './base';
import type { SfGridStoreModel, SfGridStoreRecords } from '../store';

export interface SfGridTreeOptions<T = any> extends SfGridPluginOptions {
  readonly pluginId?: 'Tree';

  readonly pluginID?: 'Tree';

  /**
   * 树表格节点名称字段
   *
   * @default 'name'
   */
  treeField?: string;

  /**
   * 孩子数据的指定字段
   *
   * @default 'data'
   */
  childrenField?: string;
  /**
   * 是否需要用个根节点将树表格数据包起来
   *
   * @default true
   */
  needRoot?: boolean;

  /**
   * 根目录显示文字，默认为 '/'
   *
   * @default '云主机'
   *
   */
  rootText?: string;

  /**
   * 树表格配置 CheckSelection 后，是否显示 checkbox 框
   *
   * @default false
   */
  hideCheckbox?: boolean;
  /**
   * 是否隐藏掉分组前面的那个三角形符号
   *
   * @default false
   */
  hideGroupArw?: boolean;

  /**
   * 组的节点的渲染方式，如果不配置，默认也会给上个文件夹滴
   */
  renderer?: Function;

  /**
   * 对于组，是否仅仅显示组那一列
   *
   * @default true
   */
  isGroupSingleCol?: boolean;

  /**
   * 多选时是否只对当前节点有反应，跟父节点和子节点没关系，默认是false，代表选中/取消选中某项时，会影响父节点和子节点的选中状态；为'child'时，只影响子节点，不影响父节点
   *
   * @default false
   */
  isSelectAlone?: boolean;
  /**
   * 即使勾选所有子孩子依然不会勾选父节点
   * 使用场景：选择虚拟机分组， 因为虚拟机组除了包含子分组外还包含虚拟机，勾选所有子分组和勾选父分组不等价
   *
   * @default false
   */
  partialSelect?: boolean;

  /**
   * 是否默认展开所有节点
   *
   * @default false
   */
  autoExpandAll?: boolean;

  /**
   * 当配置了表格单选 radioSelection 时，如果配置了 true，那么树表格组也可以被勾上。
   *
   * @default false
   */
  radioCanSelectGroup?: boolean;

  /**
   * 第一次加载树表格时排序方式，配合 treeSortFn 使用
   *
   * @default 'ASC'
   */
  autoSortdirect?: 'ASC' | 'DESC';

  /**
   * 主题
   *
   * @default ''
   */
  treeBgTheme?: 'bright-theme' | '';

  /**
   * 初始化加载时是否对组排序一下，默认不排
   *
   * @default false
   */
  autoSortGroup?: boolean;

  /**
   * 初始化加载时是否对叶子排序一下，默认不排
   *
   * @default false
   */
  autoSortLeaf?: boolean;

  /**
   * 同一级别中组的排序规则，如果不配置，则以 localeCompare 的方式来排
   * 仅针对组节点之间的排序，如果是同级别有组节点叶子节点，那么组节点优先排在前面
   * 叶子节点的排序规则是在 column 中的 sortFn 中配置的，所以这里不加该配置项了
   *
   * @default null
   */
  groupSortFn?: (data1: T, data2: T, direct: 'ASC' | 'DESC') => boolean;

  /**
   * 判断数据是不是分组
   *
   * @default data => data.type === 'group';
   */
  isGroupFn?: (data: T) => boolean;

  /**
   * 自定义添加的行的 cls，可直接配置，也可以是个函数，接受 record, 返回 cls
   *
   * @default ''
   */
  rowCls?: string | ((record: SfGridStoreModel<T>) => string);

  /**
   * 树表格分组节点的收起状态的图标
   *
   * @default 'sfis-grid-tree-arw'
   */
  treeArwCls?: string;

  /**
   * @cfg 树表格分组节点的展开状态的图标
   * @default 'sfis-grid-tree-arw-expand'
   */
  treeArwExpandCls?: string;

  /**
   * 用于配置某个节点是否可勾选，返回 true 表示可以
   */
  selectAbleFn?: boolean | ((record: SfGridStoreModel<T>) => string);

  /**
   * 是否支持多根节点显示，根节点之间没有连线
   *
   * @default false
   */
  multiRoot?: boolean;

  /**
   * 是否隐藏默认图标
   *
   * @default false
   */
  hiddenIcon?: boolean;

  /**
   * 隐藏鼠标节点收起展开状态图标并且不监听事件
   *
   * @default false
   */
  hiddenTreeArw?: boolean;

  /**
   * 是否需要切换icon
   *
   * @default true
   */
  needToggleIcon?: boolean;
}

interface SfGridTreeSearchOptions {
  /**
   * 是否匹配组节点的名称，默认不包括
   *
   * @default false
   */
  includeGroup?: boolean;

  /**
   * 是否区分大小写，默认不区分
   *
   * @default false
   */
  matchCase?: boolean;
}

/** 表格树插件 */
export class SfGridTreePlugin<T = any> extends SfGridPlugin {
  constructor(options?: SfGridTreeOptions<T>);

  /**
   * 切换为仅显示叶子节点
   */
  clearTree(): void;

  /**
   * 切换为显示所有的组节点
   */
  groupTree(): void;

  /**
   * 本地搜素树表格
   */
  search(str: string, options?: SfGridTreeSearchOptions): void;

  /**
   * 退出搜索状态
   */
  clearSearch(): void;

  /**
   * 结束搜素，显示全部节点
   */
  endSearch(): void;

  /**
   * 获取树表格选中的节点
   */
  getSelections(): SfGridStoreModel<T>[];

  /**
   * 从数据中 过滤 或 反过滤 指定的叶子节点（其父元素会被一并过滤出来）
   *
   * @param {(SfGridStoreRecords<T>)} records 被过滤的记录
   * @param {boolean} [toBeShow] 被过滤的记录是显示还是隐藏
   * 注意：要使用这个函数，必须先加载好全部的表格数据才能用，推荐 在绑定 store 的 onload 事件的回调中使用
   */
  filter(records: SfGridStoreRecords<T>, toBeShow?: boolean): void;

  /**
   * 从数据中 过滤 或 反过滤 指定的组节点（其孩子元素会被一并过滤出来）
   */
  filterGroup(records: SfGridStoreRecords<T>, toBeShow?: boolean): void;

  /**
   * 选中或者不选中或半选中某个组节点的父亲爷爷太公太太公节点
   */
  doParentsSelect(record: SfGridStoreModel<T> | string): void;

  /**
   * 选中或者不选中某个组节点下的孩子节点
   */
  doChildrenSelect(record: SfGridStoreModel<T> | string): void;

  /**
   * 展开组：传入某个组节点的 id, 置为展开状态
   */
  expand(id: string): void;

  /**
   * 展开到哪个节点：传入某个节点的 id, 将它所有的父亲节点都置为展开状态
   */
  expandTo(ids: SfGridStoreModel<T> | string): void;

  expandBy(options: { level?: number; filter?: (record: SfGridStoreModel<T>) => boolean }): void;

  /**
   * 收起组：传入某个组节点的 id, 置为收起状态
   */
  collapse(id?: string): void;

  /**
   * 全部展开
   */
  expandAll(): void;

  /**
   * 全部收起
   */
  collapseAll(): void;

  setSelect(
    records: SfGridStoreRecords<T>,
    isSelected?: boolean,
    options?:
      | boolean
      | {
          noEvent?: boolean;
          force?: boolean;
          isSelectAlone?: boolean;
        },
  ): void;

  setDisabled(records: SfGridStoreRecords<T>, disabled: boolean): void;

  setParentDisabled(record: SfGridStoreModel<T>, disabled: boolean): void;

  /**
   * 选中某 组 或 叶子节点
   */
  select(records?: SfGridStoreRecords<T>, force?: boolean): void;

  /**
   * 不选中某 组 或 叶子节点
   */
  unSelect(records?: SfGridStoreRecords<T>, force?: boolean): void;

  /**
   * 调用可以将树表格所有的节点选中
   */
  selectAll(force?: boolean): void;

  /**
   * 调用可以将树表格所有的节点不选中
   */
  unSelectAll(force?: boolean): void;

  /**
   * 销毁列表
   */
  destroy(): void;
}
