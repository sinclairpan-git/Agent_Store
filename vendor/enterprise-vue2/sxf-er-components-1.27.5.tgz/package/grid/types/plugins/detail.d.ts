/**
 * @file 表格 detail 插件
 */

import type { SfGridPlugin, SfGridPluginOptions } from './base';

export interface SfGridDetailOptions extends SfGridPluginOptions {
  readonly pluginId?: 'Detail';

  readonly pluginID?: 'Detail';

  width?: string;
  rowDetailCls?: string | ((record: any) => {});
  detailPadding?: boolean;
  autoExpand?: boolean;
  autoExpandAll?: boolean;
  needToggleIcon?: boolean;

  /** 手风琴模式 */
  accordion?: boolean;
}

export class SfGridDetailPlugin extends SfGridPlugin {
  constructor(options?: SfGridDetailOptions);
  /**
   * 展开
   * data 为 groupField 对应的值
   */
  expand(data: string): void;

  /**
   * 展开全部
   */
  expandAll(): void;

  /**
   * 获取展开的全部元素
   */
  getExpandList(): string[];

  /**
   * 收起
   * data 为 groupField 对应的值
   */
  collapse(data: string): void;

  /**
   * 收起全部
   */
  collapseAll(): void;
}
