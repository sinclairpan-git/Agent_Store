/**
 * @file 表格分页插件
 */

import type { SfGridPlugin, SfGridPluginOptions } from './base';

export interface SfGridFixedColumnOptions extends SfGridPluginOptions {
  readonly pluginId?: 'FixedColumn';

  readonly pluginID?: 'FixedColumn';
}

/** 表格分页插件 */
export class SfGridFixedColumnPlugin extends SfGridPlugin {
  constructor(options?: SfGridFixedColumnOptions);
}
