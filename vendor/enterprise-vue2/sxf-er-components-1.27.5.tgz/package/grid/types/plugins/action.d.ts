/**
 * @file 表格action插件
 */

import type { SfGridPlugin, SfGridPluginOptions } from './base';

export interface SfGridActionOptions extends SfGridPluginOptions {
  readonly pluginId?: 'Action';

  readonly pluginID?: 'Action';

  remoteSort?: boolean;
}

/** 表格鼠标事件插件 */
export class SfGridActionPlugin extends SfGridPlugin {
  constructor(options?: SfGridActionOptions);
}
