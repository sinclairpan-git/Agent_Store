/**
 * @file 表格列伸缩插件
 */

import type { SfGridPlugin, SfGridPluginOptions } from './base';

export interface SfGridResizeableOptions extends SfGridPluginOptions {
  readonly pluginId?: 'Resizeable';

  readonly pluginID?: 'Resizeable';

  /**
   * 调整浏览器窗口，是否设置表格的列宽为初始列宽，防止出现滚动条（调小时有问题，调大时没有问题）
   * 注意，如果是combo-grid，宽度固定的，不要设置为true！
   *
   * @default true
   */
  reInitColumnWidthOnResize?: boolean;
}

/** 表格列伸缩插件 */
export class SfGridResizeablePlugin extends SfGridPlugin {
  constructor(options?: SfGridResizeableOptions);

  /**
   * 设置列宽为初始化的宽度
   */
  reInitColumnWidth(): void;
}
