/**
 * @file 表格分页插件
 */

import type { SfGridPlugin, SfGridPluginOptions } from './base';

export interface SfGridPagingBarOptions extends SfGridPluginOptions {
  readonly pluginId?: 'PagingBar';

  readonly pluginID?: 'PagingBar';

  /**
   * 分页个数
   *
   * @default 50
   */
  pageSize?: number;

  /**
   * 是否是简化版分页
   *
   * @default false
   */
  isSimple?: boolean;

  /**
   * 配置pagingbar尺寸
   *
   * @default 'small'
   */
  size?: string;

  /**
   * 默认显示“每页”和“前往”，在弹窗下分情况，业务自己覆盖
   *
   * @default true
   */
  showMore?: boolean;

  /**
   * 是否为本地分页
   *
   * @default false
   */
  isLocal?: boolean;

  /**
   * 页面跳转后是否自动滚动到顶部
   *
   * @default true
   */
  isAutoScrollTop?: boolean;

  /**
   * 分页个数列表
   *
   * @default [20, 50]
   */
  pageSizeList?: number[];

  /**
   * pagingbar组件首次加载是否自动调用表格的ajax请求
   *
   * @default true
   */
  isAutoLoadFirst?: boolean;
}

/** 表格分页插件 */
export class SfGridPagingBarPlugin extends SfGridPlugin {
  constructor(options?: SfGridPagingBarOptions);

  move(callback?: Function): void;

  moveFirst(callback?: Function): void;

  movePrev(): void;
  moveNext(): void;
  moveLast(): void;
}
