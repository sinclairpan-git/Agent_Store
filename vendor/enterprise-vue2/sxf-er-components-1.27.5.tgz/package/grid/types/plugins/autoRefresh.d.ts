/**
 * @file 表格自动刷新插件
 */

import type { SfGridPlugin, SfGridPluginOptions } from './base';

export interface SfGridAutoRefreshOptions extends SfGridPluginOptions {
  readonly pluginId?: 'AutoRefresh';

  readonly pluginID?: 'AutoRefresh';

  /**
   * 刷新间隔
   *
   * @default 5000
   */
  interval?: number;

  /**
   * 是否自动开始
   *
   * @default false
   */
  autoLoad?: boolean;
}

/** 表格自动刷新插件 */
export class SfGridAutoRefreshPlugin extends SfGridPlugin {
  constructor(options?: SfGridAutoRefreshOptions);

  load(): void;
  reloadTask(): void;

  start(delay?: boolean): void;
  stop(): void;
  suspend(): void;
  resume(): void;
  setIntervalTime(): void;
}
