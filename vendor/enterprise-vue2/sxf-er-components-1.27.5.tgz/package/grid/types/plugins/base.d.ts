/**
 * @file 表格插件基础类型
 */

export interface SfGridPluginOptions {
  listeners?: Record<string, Function>;
}

export class SfGridPlugin {
  constructor();
  init(grid: any): void;
  getId(): string;

  destroy(): void;
}
