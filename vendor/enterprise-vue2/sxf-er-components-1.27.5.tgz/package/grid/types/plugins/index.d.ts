/**
 * @file 表格插件列表
 */

import type { SfGridActionOptions, SfGridActionPlugin } from './action';
import type { SfGridAutoRefreshOptions, SfGridAutoRefreshPlugin } from './autoRefresh';
import type { SfGridCustomColumnOptions, SfGridCustomColumnPlugin } from './customColumn';
import type { SfGridDetailOptions, SfGridDetailPlugin } from './detail';
import type { SfGridFixedColumnOptions, SfGridFixedColumnPlugin } from './fixedColumn';
import type { SfGridGroupOptions, SfGridGroupPlugin } from './group';
import type { SfGridPagingBarOptions, SfGridPagingBarPlugin } from './pagingBar';
import type { SfGridResizeableOptions, SfGridResizeablePlugin } from './resizeable';
import type {
  SfGridCheckSelectionOptions,
  SfGridCheckSelectionPlugin,
  SfGridRadioGroupSelectionOptions,
  SfGridRadioGroupSelectionPlugin,
  SfGridRadioSelectionOptions,
  SfGridRadioSelectionPlugin,
  SfGridSelectionOptions,
  SfGridSelectionPlugin,
  SfGridSelectionRecord,
} from './selection';
import type { SfGridSortableOptions, SfGridSortablePlugin } from './sortable';
import type { SfGridTreeOptions, SfGridTreePlugin } from './tree';

/** 表格插件类型 */
export type SfGridPluginType =
  | 'Action'
  | 'AutoRefresh'
  | 'Resizeable'
  | 'Group'
  | 'Tree'
  | 'PagingBar'
  | 'Selection'
  | 'RadioSelection'
  | 'CheckSelection'
  | 'RadioGroupSelection'
  | 'Sortable'
  | 'CustomColumn'
  | 'FixedColumn'
  | 'Detail';

/** 表格插件配置 */
export type SfGridPluginConfig<T = any> =
  | SfGridPagingBarOptions
  | SfGridActionOptions
  | SfGridAutoRefreshOptions
  | SfGridCustomColumnOptions
  | SfGridSelectionOptions<T>
  | SfGridCheckSelectionOptions<T>
  | SfGridRadioSelectionOptions<T>
  | SfGridRadioGroupSelectionOptions<T>
  | SfGridGroupOptions<T>
  | SfGridTreeOptions<T>
  | SfGridResizeableOptions
  | SfGridSortableOptions
  | SfGridFixedColumnOptions
  | SfGridDetailOptions;

export {
  SfGridSelectionRecord,
  SfGridPagingBarPlugin,
  SfGridActionPlugin,
  SfGridAutoRefreshPlugin,
  SfGridCustomColumnPlugin,
  SfGridSelectionPlugin,
  SfGridRadioSelectionPlugin,
  SfGridCheckSelectionPlugin,
  SfGridRadioGroupSelectionPlugin,
  SfGridGroupPlugin,
  SfGridTreePlugin,
  SfGridResizeablePlugin,
  SfGridSortablePlugin,
  SfGridFixedColumnPlugin,
  SfGridDetailPlugin,
};

export {
  SfGridPagingBarOptions,
  SfGridActionOptions,
  SfGridAutoRefreshOptions,
  SfGridCustomColumnOptions,
  SfGridSelectionOptions,
  SfGridCheckSelectionOptions,
  SfGridRadioSelectionOptions,
  SfGridRadioGroupSelectionOptions,
  SfGridGroupOptions,
  SfGridTreeOptions,
  SfGridResizeableOptions,
  SfGridSortableOptions,
  SfGridFixedColumnOptions,
  SfGridDetailOptions,
};
