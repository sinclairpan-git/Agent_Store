import $ from 'jquery';
import { componentName as componentName$4 } from '@sxf/er-components/_const';
import { SfPopover } from '@sxf/er-components/popover';
import { globalConfig, $i } from '@sxf/er-config';
import { getPrefixedClassName, featureConfig } from '@sxf/er-feature';
import Grid$1, { gridEventName, gridPluginId, Action, AutoRefresh, CheckSelection, Detail, FixedColumn, Group, RadioGroupSelection, RadioSelection, Resizeable, Selection, Sortable, Tree, Store } from '@sxf/er-widget/grid';
export { Action, AutoRefresh, CheckSelection, Detail, FixedColumn, Group, RadioGroupSelection, RadioSelection, Resizeable, Selection, Sortable, Tree, gridEventName, gridPluginId } from '@sxf/er-widget/grid';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
import { get } from 'lodash-es';
import { EmitterMixin, AddComponentMixin } from '@sxf/er-components/_mixins';
import { isPropEnabled, findVnodeComponent } from '@sxf/er-components/_utils/vue-utils';
import { SfEmpty } from '@sxf/er-components/empty';
import { SfSpace } from '@sxf/er-components/space';
import { getAjaxMessage } from '@sxf/er-utils/ajax';
import { debounce, throttle } from '@sxf/er-utils/delay';
import LoadMask from '@sxf/er-widget/mask';
import { SfButton } from '@sxf/er-components/button';
import format from '@sxf/er-utils/format';
import Logger from '@sxf/er-utils/logger';
import Observable from '@sxf/er-utils/observable';
import oop from '@sxf/er-utils/oop';
import { SfCheckbox } from '@sxf/er-components/checkbox';
import { SfDrag } from '@sxf/er-components/drag';
import { SfLayer } from '@sxf/er-components/layer';
import { SfPagination } from '@sxf/er-components/pagination';
import apply from '@sxf/er-utils/apply';
import { SfSearchTip } from '@sxf/er-components/search-tip';
const COLUMN_UPDATE_WAIT = 10;
const SEARCH_WAIT = 500;
const defaultActionColZhWidth = "54px";
const defaultActionColEnWidth = "80px";
const { render, afterRender, updateOption, viewReady, rowDblClick } = gridEventName.grid;
const events$1 = [render, afterRender, updateOption, viewReady, rowDblClick];
const searchComponentEvent = {
  input: "input",
  trigger: "trigger",
  end: "end"
};
const columnProps = {
  header: true,
  headerCeilTip: true,
  headerAlign: true,
  align: true,
  headerCls: true,
  dataIndex: true,
  width: true,
  minWidth: true,
  ceilTip: true,
  sortable: Boolean,
  iconCls: true,
  groupIconCls: {
    type: [Function, String, Boolean],
    default: ""
  },
  ellipsis: {
    default: true
  },
  headerTipIcon: {
    type: String,
    default: "vtv-icon-tip-info"
  },
  headerFilterIcon: {
    type: String,
    default: "vtv-icon-filter"
  },
  tip: true,
  tipCls: {
    default: ""
  },
  field: true,
  sortFn: {
    type: Function
  },
  hidden: {
    type: Boolean,
    default: false
  },
  renderer: {
    type: Function
  },
  headerTipConfig: {
    type: Object,
    default: () => ({})
  },
  headerFilterConfig: {
    type: Object,
    default: () => ({})
  },
  hasSpace: {
    type: Boolean,
    default: false
  },
  isAction: {
    type: Boolean,
    default: false
  },
  isAutoFitWidth: {
    type: Boolean,
    default: false
  },
  showType: {
    type: String,
    validator: function(val) {
      return ["show", "unshow", "always"].indexOf(val) !== -1;
    },
    default: "show"
  },
  customColumnGroup: {
    type: String
  },
  fixed: {
    type: String,
    default: ""
  },
  spanCell: {
    type: Function
  }
};
const columnEvent = {
  columnChange: "column-change",
  cellClick: "cell-click",
  cellDblclick: "cell-dblclick"
};
var script$4 = {
  name: componentName$4.gridColumn,
  componentName: componentName$4.gridColumn,
  components: { SfPopover },
  props: $.extend(true, {}, columnProps),
  computed: {
    grid() {
      let parent = this.$parent;
      while (parent && parent.$options.componentName !== componentName$4.grid) {
        parent = parent.$parent;
      }
      return parent;
    },
    popoverConfig() {
      return $.extend(
        true,
        {
          trigger: "hover",
          align: "bt-rl",
          offsetX: -4,
          anchorHide: false
        },
        this.headerTipConfig
      );
    },
    filterPopoverConfig() {
      return $.extend(
        true,
        {
          trigger: "click",
          align: "bt-rl",
          offsetX: -4,
          anchorHide: false,
          isFilter: false
        },
        this.headerFilterConfig
      );
    }
  },
  watch: {
    hidden: function() {
      this.grid.$emit(columnEvent.columnChange);
    }
  },
  methods: {
    getConfig: function() {
      const vm = this;
      const config = Object.keys(columnProps).reduce(function(configValue, key) {
        configValue[key] = vm.$props[key];
        return configValue;
      }, {});
      if (typeof vm.tip !== "undefined") {
        config.ceilTip = vm.tip;
        config.ceilTipCls = vm.tipCls;
      }
      if (typeof vm.field !== "undefined") {
        config.dataIndex = vm.field;
      }
      if (this.grid && !config.minWidth) {
        config.minWidth = this.grid.columnMinWidth;
      }
      if (this.grid && !config.width) {
        if (config.isAction) {
          config.width = globalConfig.isLocaleZhCN ? defaultActionColZhWidth : defaultActionColEnWidth;
        } else {
          config.width = this.grid.columnWidth;
        }
      }
      if (this.grid && typeof config.headerCeilTip === "undefined") {
        config.headerCeilTip = this.grid.headerCeilTip;
      }
      config.isAutoFitWidth = config.isAction || config.isAutoFitWidth;
      delete config.tip;
      delete config.tipCls;
      delete config.field;
      return config;
    },
    onFilterHidden() {
      this.$nextTick(() => {
        const bindTargetList = this.$refs.headerFilterRef.getBindTarget();
        bindTargetList.forEach((item) => {
          const $item = $(item);
          if ($item.hasClass("sfis-grid-column-filter-icon")) {
            if ($item.hasClass("column-filter-active") && !this.filterPopoverConfig.isFilter) {
              $item.removeClass(getPrefixedClassName("column-filter-active"));
            }
          }
        });
      });
    },
    hideHeaderFilter() {
      var _a;
      (_a = this.$refs.headerFilterRef) == null ? void 0 : _a.hide();
    },
    getPrefixedClassName
  }
};
const __vue_script__$4 = script$4;
var __vue_render__$4 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    [
      _vm.$slots["header-content-right"] ? _c(
        "span",
        {
          ref: "headerContentRightRef",
          class: _vm.getPrefixedClassName(
            "sfis-grid-column-content--right"
          )
        },
        [_vm._t("header-content-right")],
        2
      ) : _vm._e(),
      _vm._v(" "),
      _vm.$slots["header-tip"] ? _c(
        "sf-popover",
        _vm._b(
          { ref: "headerTipRef" },
          "sf-popover",
          _vm.popoverConfig,
          false
        ),
        [_vm._t("header-tip")],
        2
      ) : _vm._e(),
      _vm._v(" "),
      _vm.$slots["header-filter"] ? _c(
        "sf-popover",
        _vm._b(
          { ref: "headerFilterRef", on: { hidden: _vm.onFilterHidden } },
          "sf-popover",
          _vm.filterPopoverConfig,
          false
        ),
        [_vm._t("header-filter")],
        2
      ) : _vm._e()
    ],
    1
  );
};
var __vue_staticRenderFns__$4 = [];
__vue_render__$4._withStripped = true;
const __vue_inject_styles__$4 = void 0;
const __vue_scope_id__$4 = void 0;
const __vue_module_identifier__$4 = void 0;
const __vue_is_functional_template__$4 = false;
const __vue_component__$4 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$4, staticRenderFns: __vue_staticRenderFns__$4 },
  __vue_inject_styles__$4,
  __vue_script__$4,
  __vue_scope_id__$4,
  __vue_is_functional_template__$4,
  __vue_module_identifier__$4,
  false,
  void 0,
  void 0,
  void 0
);
const events = {
  selectAll: "select-all",
  reverseSelections: "reverse-selections",
  clearSelections: "clear-selections",
  visibilityChange: "visibility-change"
};
const componentName$3 = "CheckSelectionBar";
var script$3 = {
  name: componentName$3,
  componentName: componentName$3,
  components: { SfButton },
  data() {
    return { currentSelections: [] };
  },
  computed: {
    visible() {
      return !!this.currentSelectionCount;
    },
    currentSelectionCount() {
      return this.currentSelections.length;
    },
    currentSelectionCountText() {
      const currentSelectionCount = this.currentSelectionCount;
      return $i("scp.vt_component.common.widget.Grid.plugins.CheckSelectionBar.currentSelectionCount", {
        currentSelectionCount
      });
    },
    selectAllText() {
      return $i("scp.vt_component.common.widget.Grid.plugins.CheckSelectionBar.selectAll");
    },
    reverseSelectionText() {
      return $i("scp.vt_component.common.widget.Grid.plugins.CheckSelectionBar.reverseSelection");
    },
    clearSelectionText() {
      return $i("scp.vt_component.common.widget.Grid.plugins.CheckSelectionBar.clearSelection");
    },
    eventName() {
      return events;
    }
  },
  watch: {
    visible() {
      this.$nextTick(() => {
        this.$emit(this.eventName.visibilityChange);
      });
    }
  },
  methods: {
    setCurrentSelections(selections) {
      this.currentSelections = selections;
    },
    getPrefixedClassName,
    getFullUtid(utidBase) {
      return this.utid ? `${this.utid}-${utidBase}` : utidBase;
    }
  }
};
const __vue_script__$3 = script$3;
var __vue_render__$3 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      directives: [
        {
          name: "show",
          rawName: "v-show",
          value: _vm.visible,
          expression: "visible"
        }
      ],
      class: _vm.getPrefixedClassName("check-selection-bar")
    },
    [
      _c(
        "span",
        { class: _vm.getPrefixedClassName("check-selection-bar-tips") },
        [_vm._v("\n    " + _vm._s(_vm.currentSelectionCountText) + "\n  ")]
      ),
      _vm._v(" "),
      _c(
        "sf-button",
        {
          class: _vm.getPrefixedClassName(
            "check-selection-bar__csb-select-all"
          ),
          attrs: {
            type: "icon",
            utid: _vm.getFullUtid("csb-select-all"),
            size: "small"
          },
          on: {
            click: function($event) {
              return _vm.$emit(_vm.eventName.selectAll);
            }
          }
        },
        [_vm._v("\n    " + _vm._s(_vm.selectAllText) + "\n  ")]
      ),
      _vm._v(" "),
      _c(
        "sf-button",
        {
          class: _vm.getPrefixedClassName(
            "check-selection-bar__csb-reverse-selection"
          ),
          attrs: {
            type: "icon",
            utid: _vm.getFullUtid("csb-reverse-selection"),
            size: "small"
          },
          on: {
            click: function($event) {
              return _vm.$emit(_vm.eventName.reverseSelections);
            }
          }
        },
        [_vm._v("\n    " + _vm._s(_vm.reverseSelectionText) + "\n  ")]
      ),
      _vm._v(" "),
      _c(
        "sf-button",
        {
          class: _vm.getPrefixedClassName(
            "check-selection-bar__csb-clear-selection"
          ),
          attrs: {
            type: "icon",
            utid: _vm.getFullUtid("csb-clear-selection"),
            size: "small"
          },
          on: {
            click: function($event) {
              return _vm.$emit(_vm.eventName.clearSelections);
            }
          }
        },
        [_vm._v("\n    " + _vm._s(_vm.clearSelectionText) + "\n  ")]
      )
    ],
    1
  );
};
var __vue_staticRenderFns__$3 = [];
__vue_render__$3._withStripped = true;
const __vue_inject_styles__$3 = void 0;
const __vue_scope_id__$3 = void 0;
const __vue_module_identifier__$3 = void 0;
const __vue_is_functional_template__$3 = false;
const __vue_component__$3 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$3, staticRenderFns: __vue_staticRenderFns__$3 },
  __vue_inject_styles__$3,
  __vue_script__$3,
  __vue_scope_id__$3,
  __vue_is_functional_template__$3,
  __vue_module_identifier__$3,
  false,
  void 0,
  void 0,
  void 0
);
function initCheckSelectionBar(checkSelectionPlugin, containerEl) {
  const CheckSelectionBarApp = new (globalConfig.VueConstructor.extend(__vue_component__$3))();
  CheckSelectionBarApp.utid = checkSelectionPlugin.grid.getGridUtid();
  CheckSelectionBarApp.$mount();
  const globallyOperateSelections = checkSelectionPlugin.globallyOperateSelections.bind(checkSelectionPlugin);
  const checkSelectionBarVisibilityChanged = checkSelectionPlugin.checkSelectionBarVisibilityChanged.bind(checkSelectionPlugin);
  CheckSelectionBarApp.$on(events.visibilityChange, checkSelectionBarVisibilityChanged);
  CheckSelectionBarApp.$on(events.selectAll, () => globallyOperateSelections("selectAll"));
  CheckSelectionBarApp.$on(events.reverseSelections, () => globallyOperateSelections("reverseSelections"));
  CheckSelectionBarApp.$on(events.clearSelections, () => globallyOperateSelections("clearSelections"));
  containerEl.append(CheckSelectionBarApp.$el);
  CheckSelectionBarApp.destroy = () => {
    CheckSelectionBarApp.$destroy();
  };
  return CheckSelectionBarApp;
}
const SHOW_TYPE = {
  SHOW: "show",
  UNSHOW: "unshow",
  ALWAYS: "always"
};
const PLUGIN_MODE = {
  GROUP: "group",
  NORMAL: "normal"
};
const defaultConfigs = {
  pluginId: gridPluginId.customColumn,
  mode: PLUGIN_MODE.NORMAL
};
const componentName$2 = "WorkbenchMain";
const OPTION_TEXT_MAX_WIDTH = 104;
const OPTION_TEXT_MAX_WIDTH_GROUP = 136;
var script$2 = {
  name: componentName$2,
  componentName: componentName$2,
  components: {
    SfLayer,
    SfCheckbox,
    SfDrag,
    SfButton
  },
  mixins: [EmitterMixin],
  inject: ["gridUtid"],
  props: {
    trigger: {
      type: [String, HTMLElement],
      default: ""
    },
    triggerProvider: {
      type: Function
    },
    columns: {
      type: Array,
      required: true
    },
    mode: {
      validator: function(value) {
        return ["normal", "group"].indexOf(value) !== -1;
      },
      required: true
    },
    selectAllText: {
      type: String,
      required: true
    }
  },
  data() {
    return {
      optionTextStyle: {},
      hasScrollbar: false
    };
  },
  computed: {
    allSelected: {
      get: function() {
        const unselectedColumns = this.columns.filter(function(item) {
          return item.selected === false;
        });
        return unselectedColumns.length === 0;
      },
      set: function() {
        if (this.allSelected) {
          this.dispatch("WorkbenchRoot", "clear-all-optional-select");
        } else {
          this.dispatch("WorkbenchRoot", "select-all");
        }
      }
    },
    indeterminate: function() {
      const selectedColumns = this.columns.filter(function(item) {
        return item.selected === true;
      });
      return selectedColumns.length !== 0 && !this.allSelected;
    },
    groupMode: function() {
      return this.mode === "group";
    },
    allGroups: function() {
      const groupSet = [];
      const res = [];
      this.columns.forEach((column) => {
        if (groupSet.indexOf(column.groupKey) === -1) {
          groupSet.push(column.groupKey);
          res.push({
            groupKey: column.groupKey,
            groupName: column.groupName
          });
        }
      });
      return res;
    },
    allNonOperable: function() {
      return this.columns.filter(function(column) {
        return column.must;
      });
    },
    restoreText: function() {
      return $i("scp.vt_component.common.widget.Grid.plugins.CustomColumn.restore");
    },
    optionTextMaxWidth() {
      return this.groupMode ? OPTION_TEXT_MAX_WIDTH_GROUP : OPTION_TEXT_MAX_WIDTH;
    },
    contentOptionCls() {
      return {
        [getPrefixedClassName("grid-custom-column-workbench-content-option")]: true,
        [getPrefixedClassName("grid-custom-column-workbench-content-option--scroll")]: this.hasScrollbar
      };
    },
    layerCls() {
      return ["sfis-grid", "grid-custom-column-workbench"].map((cls) => getPrefixedClassName(cls)).join(" ");
    }
  },
  watch: {
    columns: {
      deep: true,
      handler: function(newVal) {
        this.dispatch("WorkbenchRoot", "on-column-setting-change", [newVal]);
      }
    }
  },
  methods: {
    getFullUtid(utidBase) {
      return this.gridUtid ? `${this.gridUtid}-${utidBase}` : utidBase;
    },
    groupedColumns: function(groupKey) {
      return this.columns.filter(function(column) {
        return column.groupKey === groupKey;
      });
    },
    adjustOptionTextStyle() {
      this.$nextTick(() => {
        const scrollBarWidth = this.$refs.contentRef.offsetWidth - this.$refs.contentRef.scrollWidth;
        this.hasScrollbar = !!scrollBarWidth;
      });
    },
    getPrefixedClassName
  }
};
const __vue_script__$2 = script$2;
var __vue_render__$2 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "sf-layer",
    {
      attrs: {
        offset: "8,10",
        anchor: "bottom-end",
        "target-provider": _vm.triggerProvider,
        "default-target": _vm.trigger,
        "max-height": 400,
        "default-width": 180,
        cls: _vm.layerCls,
        utid: _vm.getFullUtid("custom-column-workbench")
      },
      on: {
        hide: function($event) {
          return _vm.dispatch("WorkbenchRoot", "on-workbench-closed");
        },
        show: _vm.adjustOptionTextStyle
      }
    },
    [
      _c(
        "div",
        {
          class: _vm.getPrefixedClassName("grid-custom-column-workbench-title")
        },
        [
          _c(
            "sf-checkbox",
            {
              attrs: {
                indeterminate: _vm.indeterminate,
                utid: _vm.getFullUtid("custom-column-select-all")
              },
              model: {
                value: _vm.allSelected,
                callback: function($$v) {
                  _vm.allSelected = $$v;
                },
                expression: "allSelected"
              }
            },
            [_vm._v(_vm._s(_vm.selectAllText))]
          ),
          _vm._v(" "),
          _c(
            "sf-button",
            {
              attrs: {
                type: "icon",
                utid: _vm.getFullUtid("custom-column-restore")
              },
              on: {
                click: function($event) {
                  return _vm.dispatch("WorkbenchRoot", "on-restore");
                }
              }
            },
            [_vm._v(_vm._s(_vm.restoreText))]
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "div",
        {
          ref: "contentRef",
          class: _vm.getPrefixedClassName(
            "grid-custom-column-workbench-content"
          )
        },
        [
          !_vm.groupMode ? [
            _vm._l(_vm.allNonOperable, function(column) {
              return _c(
                "div",
                { key: column.columnKey, class: _vm.contentOptionCls },
                [
                  _c(
                    "sf-checkbox",
                    {
                      attrs: {
                        utid: _vm.getFullUtid(
                          "custom-column-checkbox-" + column.columnKey
                        ),
                        disabled: ""
                      },
                      model: {
                        value: column.selected,
                        callback: function($$v) {
                          _vm.$set(column, "selected", $$v);
                        },
                        expression: "column.selected"
                      }
                    },
                    [
                      _c(
                        "span",
                        {
                          class: _vm.getPrefixedClassName(
                            "grid-custom-column-workbench-content-option-text-wrapper"
                          ),
                          attrs: { "data-tip": column.columnName }
                        },
                        [_vm._v(_vm._s(column.columnName))]
                      )
                    ]
                  )
                ],
                1
              );
            }),
            _vm._v(" "),
            _c("sf-drag", {
              attrs: { data: _vm.columns },
              scopedSlots: _vm._u(
                [
                  {
                    key: "default",
                    fn: function(record) {
                      var _obj;
                      return !record.value.must ? [
                        _c(
                          "div",
                          { class: _vm.contentOptionCls },
                          [
                            _c(
                              "sf-checkbox",
                              {
                                attrs: {
                                  utid: _vm.getFullUtid(
                                    "custom-column-checkbox-" + record.value.columnKey
                                  )
                                },
                                model: {
                                  value: record.value.selected,
                                  callback: function($$v) {
                                    _vm.$set(
                                      record.value,
                                      "selected",
                                      $$v
                                    );
                                  },
                                  expression: "record.value.selected"
                                }
                              },
                              [
                                _c(
                                  "span",
                                  {
                                    class: [
                                      _vm.getPrefixedClassName(
                                        "grid-custom-column-workbench-content-option-text-wrapper"
                                      ),
                                      (_obj = {}, _obj[_vm.getPrefixedClassName(
                                        "workbench-content--scroll"
                                      )] = _vm.hasScrollbar, _obj)
                                    ],
                                    attrs: {
                                      "data-tip": record.value.columnName
                                    }
                                  },
                                  [
                                    _vm._v(
                                      _vm._s(record.value.columnName)
                                    )
                                  ]
                                )
                              ]
                            ),
                            _c("i", {
                              staticClass: "icon iconfont vtv-icon-ele-drag",
                              class: _vm.getPrefixedClassName(
                                "grid-custom-column-workbench-content-option-icon"
                              )
                            })
                          ],
                          1
                        )
                      ] : void 0;
                    }
                  }
                ],
                null,
                true
              )
            })
          ] : _vm._l(_vm.allGroups, function(group) {
            return _c(
              "div",
              {
                key: group.groupKey,
                class: _vm.getPrefixedClassName(
                  "grid-custom-column-workbench-content-group"
                )
              },
              [
                _c(
                  "div",
                  {
                    class: _vm.getPrefixedClassName(
                      "grid-custom-column-workbench-content-group-name"
                    )
                  },
                  [
                    _vm._v(
                      "\n          " + _vm._s(group.groupName) + "\n        "
                    )
                  ]
                ),
                _vm._v(" "),
                _vm._l(
                  _vm.groupedColumns(group.groupKey),
                  function(column) {
                    return _c(
                      "div",
                      {
                        key: column.columnKey,
                        class: _vm.contentOptionCls
                      },
                      [
                        _c(
                          "sf-checkbox",
                          {
                            attrs: {
                              utid: _vm.getFullUtid(
                                "custom-column-checkbox-" + column.columnKey
                              ),
                              disabled: column.must
                            },
                            model: {
                              value: column.selected,
                              callback: function($$v) {
                                _vm.$set(column, "selected", $$v);
                              },
                              expression: "column.selected"
                            }
                          },
                          [
                            _c(
                              "span",
                              {
                                class: _vm.getPrefixedClassName(
                                  "grid-custom-column-workbench-content-option-text-wrapper"
                                ),
                                style: _vm.optionTextStyle,
                                attrs: { "data-tip": column.columnName }
                              },
                              [_vm._v(_vm._s(column.columnName))]
                            )
                          ]
                        )
                      ],
                      1
                    );
                  }
                )
              ],
              2
            );
          })
        ],
        2
      )
    ]
  );
};
var __vue_staticRenderFns__$2 = [];
__vue_render__$2._withStripped = true;
const __vue_inject_styles__$2 = void 0;
const __vue_scope_id__$2 = void 0;
const __vue_module_identifier__$2 = void 0;
const __vue_is_functional_template__$2 = false;
const __vue_component__$2 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$2, staticRenderFns: __vue_staticRenderFns__$2 },
  __vue_inject_styles__$2,
  __vue_script__$2,
  __vue_scope_id__$2,
  __vue_is_functional_template__$2,
  __vue_module_identifier__$2,
  false,
  void 0,
  void 0,
  void 0
);
const componentName$1 = "WorkbenchCustom";
var script$1 = {
  name: componentName$1,
  componentName: componentName$1,
  components: {
    WorkbenchMain: __vue_component__$2
  },
  props: {
    columns: {
      type: Array,
      required: true
    },
    mode: {
      validator: function(value) {
        return ["normal", "group"].indexOf(value) !== -1;
      },
      required: true
    },
    selectAllText: {
      type: String,
      required: true
    },
    trigger: {
      required: true
    }
  }
};
const __vue_script__$1 = script$1;
var __vue_render__$1 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c("workbench-main", {
    attrs: {
      trigger: _vm.trigger,
      columns: _vm.columns,
      mode: _vm.mode,
      selectAllText: _vm.selectAllText
    }
  });
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
const componentName = "CustomColumnWorkbench";
var script = {
  name: componentName,
  componentName,
  components: {
    WorkbenchCustom: __vue_component__$1
  },
  props: {
    columns: {
      type: Array,
      default: () => []
    },
    mode: {
      validator: function(value) {
        return ["normal", "group"].indexOf(value) !== -1;
      },
      default: "normal"
    },
    selectAllText: {
      type: String,
      default: () => $i("scp.vt_component.common.widget.Grid.plugins.CustomColumn.select_all_text")
    },
    trigger: {
      required: false
    }
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c("workbench-custom", {
    attrs: {
      columns: _vm.columns,
      mode: _vm.mode,
      selectAllText: _vm.selectAllText,
      trigger: _vm.trigger
    }
  });
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
const eventName = {
  onWorkbenchClosed: "on-workbench-closed",
  onColumnSettingChange: "on-column-setting-change",
  onRestore: "on-restore",
  clearAllOptionalSelect: "clear-all-optional-select",
  selectAll: "select-all"
};
function initCustomColumnWorkbench(customColumnPlugin, containerElement) {
  const { mode, selectAllText } = customColumnPlugin.options;
  const gridUtid = customColumnPlugin.grid.getGridUtid();
  const componentName2 = "WorkbenchRoot";
  const workbenchApp = new globalConfig.VueConstructor({
    name: componentName2,
    componentName: componentName2,
    components: {
      CustomColumnWorkbench: __vue_component__
    },
    provide: {
      gridUtid
    },
    data: function() {
      return {
        selectAllText,
        trigger: containerElement,
        columnsConfig: customColumnPlugin.getInitialColumnsConfig()
      };
    },
    mounted() {
      const vm = this;
      vm.$on(eventName.onWorkbenchClosed, vm.onWorkbenchClosed);
      vm.$on(eventName.onColumnSettingChange, vm.handleChange);
      vm.$on(eventName.onRestore, vm.restoreDefaultConfig);
      vm.$on(eventName.clearAllOptionalSelect, vm.handleClearAllOptionalSelect);
      vm.$on(eventName.selectAll, vm.handleSelectAll);
    },
    methods: {
      onWorkbenchClosed: function() {
        const vm = this;
        customColumnPlugin.confirmConfig(vm.columnsConfig);
      },
      handleChange: function(newConfig) {
        customColumnPlugin.updateColumnOptions(newConfig);
        customColumnPlugin.redrawGrid();
        customColumnPlugin.handleConfigChange(newConfig);
      },
      restoreDefaultConfig: function() {
        const vm = this;
        $.when(customColumnPlugin.getDefaultColumnsConfig()).then(function(config) {
          vm.columnsConfig = config;
        });
      },
      handleSelectAll: function() {
        const vm = this;
        const newConfig = vm.columnsConfig.map(function(item) {
          return $.extend(true, {}, item, { selected: true });
        });
        vm.columnsConfig = newConfig;
      },
      handleClearAllOptionalSelect: function() {
        const vm = this;
        const newConfig = vm.columnsConfig.map(function(item) {
          return $.extend(true, {}, item, { selected: item.must });
        });
        vm.columnsConfig = newConfig;
      },
      updateColumnsConfig: function(config) {
        const vm = this;
        vm.columnsConfig = config;
      }
    },
    template: getTemplate(mode),
    beforeDestroy() {
      const vm = this;
      vm.$off(eventName.onWorkbenchClosed, vm.onWorkbenchClosed);
      vm.$off(eventName.onColumnSettingChange, vm.handleChange);
      vm.$off(eventName.onRestore, vm.restoreDefaultConfig);
      vm.$off(eventName.clearAllOptionalSelect, vm.handleClearAllOptionalSelect);
      vm.$off(eventName.selectAll, vm.handleSelectAll);
    }
  }).$mount();
  customColumnPlugin._workbench = workbenchApp;
  containerElement.appendChild(workbenchApp.$el);
}
function getTemplate(mode) {
  return `
  <custom-column-workbench
      mode="${mode}"
      :selectAllText="selectAllText"
      :trigger="trigger"
      :columns="columnsConfig"
  ></custom-column-workbench>`;
}
const customColumnLogger = Logger("CustomColumn");
const { grid } = gridEventName;
const ASIDE_WIDTH = 24;
const CustomColumn = oop.extend(Observable, {
  constructor: function(options) {
    this.options = $.extend(true, {}, defaultConfigs, options);
    this.listeners = this.options.listeners;
    CustomColumn.superclass.constructor.apply(this, arguments);
  },
  init: function(grid2) {
    if (!grid2) {
      customColumnLogger.error(`cant't find grid, CustomColumn do not work`);
      return;
    }
    this.grid = grid2;
    this.grid._asideWidth = ASIDE_WIDTH;
    this.grid.getCeilAsideHtml = this.getCeilAsideHtml;
    this.bindEvents();
    this.groupMode = this.options.mode === PLUGIN_MODE.GROUP;
    this.groupNameRender = this.defaultGroupNameRender;
    if (this.groupMode && typeof this.options.groupNameRender === "function") {
      this.groupNameRender = this.options.groupNameRender;
    }
    this._mapColumnIndex();
    this._refactorColumn();
  },
  getCeilAsideHtml: function(rowSpan = 1) {
    if (rowSpan === 0) {
      return "";
    }
    const classList = ["sfis-grid-column-aside", "grid-custom-column"].map((className) => getPrefixedClassName(className)).join(" ");
    return format.format(`<td style="width:{0}px;" class="${classList}" rowspan={1}></td>`, ASIDE_WIDTH, rowSpan);
  },
  bindEvents: function() {
    const me = this;
    this.headerSettingBtn = $(
      `<i class="iconfont vtv-icon-set ${getPrefixedClassName("grid-custom-column_btn")}"></i>`
    );
    this.grid.on(grid.viewReady, function() {
      const headerSettingBtnWrapper = me.grid.headerEl.find(".sfis-grid-column-aside");
      headerSettingBtnWrapper.show();
      headerSettingBtnWrapper.append(me.headerSettingBtn);
      me.grid.viewEl.find(".sfis-grid-column-aside").show();
      const { customWorkbench } = me.options;
      if (typeof customWorkbench === "function") {
        me.headerSettingBtn.off("click");
        me.headerSettingBtn.on("click", function() {
          customWorkbench(me._getGridColumnConfig(), me);
        });
        return;
      }
      const workbench = me._getWorkbench();
      if (workbench) {
        return;
      }
      me._initWorkbench(me.headerSettingBtn[0]);
    });
    this.grid.on(grid.updateOption, function(_, params) {
      var _a, _b;
      const forceRefactorColumn = !!(params == null ? void 0 : params.options);
      if (forceRefactorColumn) {
        me._refactorColumn();
        (_b = (_a = me._getWorkbench()) == null ? void 0 : _a.updateColumnsConfig) == null ? void 0 : _b.call(_a, me.getInitialColumnsConfig());
      }
    });
  },
  _getGridColumnConfig: function() {
    const initialColumnConfig = this.getInitialColumnsConfig();
    const gridColumnStatus = this.grid.options.column.reduce((statusMap, column) => {
      statusMap[column.dataIndex] = column.hidden;
      return statusMap;
    }, {});
    return initialColumnConfig.map((item) => {
      item.selected = !gridColumnStatus[item.columnKey];
      return item;
    });
  },
  _mapColumnIndex: function() {
    const originIndexMap = {};
    this.grid.options.column.forEach((column, originIndex) => {
      originIndexMap[column.id] = originIndex;
    });
    this._originIndexMap = originIndexMap;
  },
  _getOriginIndexById: function(columnID) {
    return this._originIndexMap[columnID];
  },
  _refactorColumn: function() {
    const me = this;
    const originColumns = me.grid.options.column;
    const ghostColumns = [];
    const actionColumns = [];
    const customizableColumns = [];
    let forbidAlways = false;
    originColumns.forEach(function(column) {
      column.originIndex = me._getOriginIndexById(column.id);
      if (column.isAction) {
        actionColumns.push(column);
        return;
      }
      if (column.hidden === true) {
        ghostColumns.push(column);
        return;
      }
      column.hidden = column.showType === SHOW_TYPE.UNSHOW;
      if (column.showType === SHOW_TYPE.ALWAYS && forbidAlways) {
        customColumnLogger.warn("\u5FC5\u9009\u5217\u5E94\u5F53\u5168\u90E8\u524D\u7F6E, @", column.dataIndex, "-", column.header);
      }
      if (column.showType !== SHOW_TYPE.ALWAYS && !me.groupMode) {
        forbidAlways = true;
      }
      customizableColumns.push(column);
    });
    me._nonCustomizableColumns = ghostColumns.concat(actionColumns);
    me._customizableColumnKeys = customizableColumns.map(function(column) {
      return column.dataIndex;
    });
    me.setInitialColumnsConfig(customizableColumns);
    me._resetGridColumnOption(customizableColumns);
  },
  _resetGridColumnOption: function(customizableColumns) {
    this.grid.options.column = customizableColumns.concat(this._nonCustomizableColumns);
  },
  updateGridColumnView: function(columnsConfig) {
    this.updateColumnOptions(columnsConfig);
    this.redrawGrid();
    this.handleConfigChange(columnsConfig);
  },
  setInitialColumnsConfig: function(columns) {
    this._initialColumnsConfig = this._processColumnsConfig(columns);
  },
  getInitialColumnsConfig: function() {
    return this._initialColumnsConfig.map(function(item) {
      return $.extend(true, {}, item);
    });
  },
  _processColumnsConfig: function(columnsConfig, external) {
    const me = this;
    let processor = function(item) {
      const res = {
        must: item.showType === SHOW_TYPE.ALWAYS,
        selected: item.showType === SHOW_TYPE.ALWAYS || item.showType !== SHOW_TYPE.UNSHOW,
        columnName: item.columnName || me.findColumnHeaderByDataIndex(item.dataIndex),
        columnKey: item.dataIndex
      };
      if (me.groupMode) {
        res.groupKey = item.customColumnGroup;
        res.groupName = me.groupNameRender(item.customColumnGroup);
      }
      return res;
    };
    if (external) {
      processor = function(item) {
        const res = {
          dataIndex: item.columnKey,
          showType: me.getColumnShowType(item)
        };
        if (me.groupMode) {
          res.customColumnGroup = item.groupKey;
        }
        return res;
      };
    }
    return columnsConfig.map(processor);
  },
  getColumnShowType: function(columnConfig) {
    if (columnConfig.must) {
      return SHOW_TYPE.ALWAYS;
    }
    return columnConfig.selected ? SHOW_TYPE.SHOW : SHOW_TYPE.UNSHOW;
  },
  findColumnHeaderByDataIndex: function(dataIndex) {
    let target = null;
    const allColumns = this.grid.options.column;
    for (let i = 0, len = allColumns.length; i < len; i++) {
      if (dataIndex === allColumns[i].dataIndex) {
        target = allColumns[i];
        break;
      }
    }
    if (target) {
      return target.header;
    }
    return dataIndex;
  },
  defaultGroupNameRender: function(groupKey) {
    return groupKey;
  },
  getDefaultColumnsConfig: function() {
    const me = this;
    const defaultColumnsConfig = me.options.defaultColumnsConfig;
    const columnsConfigProcessor = function(columnsConfig) {
      const filteredConfig = columnsConfig.filter(function(item) {
        return me._customizableColumnKeys.indexOf(item.dataIndex) !== -1;
      });
      return me._processColumnsConfig(filteredConfig);
    };
    if (typeof defaultColumnsConfig === "function") {
      return $.when(defaultColumnsConfig()).then(columnsConfigProcessor);
    }
    if (Array.isArray(defaultColumnsConfig)) {
      return columnsConfigProcessor(defaultColumnsConfig);
    }
    return me.getInitialColumnsConfig();
  },
  _initWorkbench: function(containerEl) {
    const customColumn = this;
    initCustomColumnWorkbench(customColumn, containerEl);
  },
  _getWorkbench: function() {
    return this._workbench;
  },
  _destoryWorkbench: function() {
    if (this._workbench) {
      this._workbench.$destroy();
      this._workbench = null;
    }
  },
  updateColumnOptions: function(columnsConfig) {
    const me = this, newColumns = [], previousColumns = me.grid.options.column;
    columnsConfig.forEach(function(config) {
      const item = previousColumns.filter(function(column) {
        return column.dataIndex === config.columnKey;
      })[0];
      item.hidden = !(config.must || config.selected);
      newColumns.push(item);
    });
    me._resetGridColumnOption(newColumns);
  },
  redrawGrid() {
    this.grid.updateOption();
  },
  confirmConfig: function(columnsConfig) {
    const me = this;
    const external = true;
    typeof me.options.onConfirmConfig === "function" && me.options.onConfirmConfig(me._processColumnsConfig(columnsConfig, external));
  },
  handleConfigChange: function(columnsConfig) {
    const me = this;
    const external = true;
    typeof me.options.onConfigChange === "function" && me.options.onConfigChange(me._processColumnsConfig(columnsConfig, external));
  },
  getId: function() {
    return this.options.pluginId;
  },
  destroy: function() {
    this._destoryWorkbench();
    this.headerSettingBtn.off("click");
    this.purgeListeners();
    delete this.grid;
  }
});
const PAGINATION_SIZE = {
  normal: "normal",
  small: "small"
};
const getDefaultConfigs = () => ({
  pluginId: gridPluginId.pagingBar,
  pageSize: 50,
  pageSizeList: ["20", "50"],
  size: PAGINATION_SIZE.small,
  isAutoLoadFirst: true,
  showMore: true,
  isSimple: false,
  isLocal: false,
  isAutoScrollTop: true
});
const { grid: gridEvent, store: storeEvent$1 } = gridEventName;
const GridPagingBarLogger = Logger("GridPagingBar");
const PagingBar = oop.extend(Observable, {
  constructor: function(options) {
    this.options = {
      ...getDefaultConfigs(),
      ...options
    };
    this.listeners = this.options.listeners;
    if (this.options.isSimple) {
      this.options.showMore = false;
    }
    PagingBar.superclass.constructor.apply(this, arguments);
  },
  init: function(grid2) {
    if (!grid2) {
      GridPagingBarLogger.error("cant't find grid, PagingBar do not work");
      return;
    }
    this.grid = grid2;
    this.bindGridEvent();
  },
  renderBBar: function() {
    const paginationAppId = this.grid.getId() + "-sf-pagination-app";
    const html = this.getBBarHtml(paginationAppId);
    const bbarEl = this.grid.bbarEl;
    bbarEl.html(html);
    const container = bbarEl.find(`#${paginationAppId}`)[0];
    this.mountPaginationApp(container);
  },
  getBBarHtml: function(paginationAppId) {
    const ret = `
      <div class="${getPrefixedClassName("page-size")}" id="${paginationAppId}"></div>
      <div class="clearfix"></div>
    `;
    return ret;
  },
  mountPaginationApp: function(container) {
    const pagingBar = this;
    const paginationAppOptions = {
      render: function(h) {
        const self = this;
        return h(SfPagination, {
          ref: "gridPagination",
          class: getPrefixedClassName("page-size"),
          props: {
            pageIndex: self.pageIndex,
            total: self.totalSize,
            pageSize: self.pageSize,
            pageSizeList: self.pageSizeList,
            simple: self.simple,
            showMore: self.showMore,
            size: self.size
          },
          on: {
            "page-size-change": self.setPageSize,
            "input.page-index": (val) => self.pageIndex = val,
            change: (currentPageIndex, currentPageSize) => pagingBar.realMove(currentPageIndex - 1, currentPageSize)
          }
        });
      },
      data() {
        return {
          totalSize: 0,
          pageIndex: 1,
          pageSize: this.transformToNumber(pagingBar.options.pageSize),
          pageSizeList: pagingBar.options.pageSizeList.map((pageSize) => this.transformToNumber(pageSize)),
          simple: pagingBar.options.isSimple,
          showMore: pagingBar.options.showMore,
          size: pagingBar.options.size
        };
      },
      methods: {
        transformToNumber(val) {
          return Number(val);
        },
        setPageSize(val) {
          this.pageSize = this.transformToNumber(val);
          this.fireChangeEvent();
        },
        getPageSize() {
          return this.pageSize;
        },
        setPageIndex(val) {
          this.pageIndex = this.transformToNumber(val);
          this.fireChangeEvent();
        },
        getPageIndex() {
          return this.pageIndex;
        },
        setTotalSize(val) {
          this.totalSize = this.transformToNumber(val);
          this.fireChangeEvent();
        },
        getTotalSize() {
          return this.totalSize;
        },
        setPageSizeList(val) {
          this.pageSizeList = val;
        },
        fireChangeEvent() {
          pagingBar.fireEvent("change", {
            pageIndex: this.getPageIndex(),
            pageSize: this.getPageSize(),
            totalSize: this.getTotalSize()
          });
        }
      }
    };
    this.paginationApp = new globalConfig.VueConstructor(paginationAppOptions).$mount(container);
  },
  getPaginationApp: function() {
    return this.paginationApp;
  },
  getId: function() {
    return this.options.pluginId;
  },
  getCurrentPageIndex: function() {
    return this.getPaginationApp().getPageIndex();
  },
  getCurrentPageSize: function() {
    const paginationApp = this.getPaginationApp();
    return paginationApp ? paginationApp.getPageSize() : this.options.pageSize;
  },
  bindGridEvent: function() {
    const me = this, store = this.grid.store;
    this.grid.on(
      gridEvent.viewReady,
      function() {
        const totalSize = store.getTotalSize();
        const pageSize = me.getCurrentPageSize();
        let start, limit;
        if (store.lastOption) {
          start = store.lastOption.data && store.lastOption.data.start || 0;
          limit = store.lastOption.data && store.lastOption.data.limit || pageSize;
        } else {
          start = 0;
          limit = pageSize;
        }
        if (me.options.isLocal) {
          store.setInnerStart(start);
          store.setInnerLimit(limit);
        }
        me.updatePageBarVal(start, limit, totalSize);
        const bbarCls = me.options.isSimple ? getPrefixedClassName("sfis-grid-bbar--simple") : getPrefixedClassName("sfis-grid-bbar--" + me.options.size);
        me.grid.bbarEl.addClass(bbarCls);
      },
      this
    );
    this.grid.on(
      gridEvent.render,
      function() {
        me.grid.gridEl.addClass(getPrefixedClassName("sfis-grid-paging"));
      },
      this
    );
    this.grid.on(
      gridEvent.afterRender,
      function() {
        if (this.options.isAutoLoadFirst) {
          this.realMove(0);
        }
      },
      this
    );
    this.grid.store.on(
      storeEvent$1.beforeLoad,
      function(store2, option) {
        option.data = option.data || {};
        option.data.start = store2.lastOption && store2.lastOption.data && store2.lastOption.data.start || 0;
        option.data.limit = store2.lastOption && store2.lastOption.data && store2.lastOption.data.limit || me.getCurrentPageSize();
      },
      this
    );
    this.grid.on(gridEvent.renderFooter, () => {
      me.renderBBar.call(me);
    });
  },
  updatePageBarVal: function(start, limit, totalSize) {
    const paginationApp = this.getPaginationApp();
    let pageIndex = Math.floor(start / limit) + 1;
    if (start && totalSize < start + 1) {
      pageIndex = Math.max(Math.ceil(totalSize / limit), 1);
    }
    paginationApp.setTotalSize(totalSize);
    paginationApp.setPageIndex(pageIndex);
    paginationApp.setPageSize(limit);
    this.options.pageSize = limit;
    return;
  },
  realMove: function(pageStart, pageSize) {
    const paginationApp = this.getPaginationApp();
    pageSize = pageSize || paginationApp.pageSize;
    const me = this, data = {
      start: pageStart * pageSize,
      limit: pageSize
    }, lastOption = this.grid.store.lastOption || {};
    lastOption.data = lastOption.data || {};
    apply.applyIf(data, lastOption.data);
    const autoScrollTop = () => {
      if (me.grid.scrollYEl && me.options.isAutoScrollTop) {
        me.grid.scrollYEl.scrollTop(0);
      }
    };
    const afterMoveCallback = function() {
      if (typeof me.__afterMove === "function") {
        me.__afterMove();
        me.__afterMove = null;
      }
    };
    if (this.options.isLocal) {
      this.grid.store.changePagingInfo(data);
      autoScrollTop();
      afterMoveCallback();
    } else {
      this.grid.store.reload({
        data,
        callback: function() {
          autoScrollTop();
          afterMoveCallback();
        }
      });
    }
  },
  move: function(pageStart, callback) {
    const paginationApp = this.getPaginationApp();
    if (typeof callback === "function") {
      this.__afterMove = callback;
    }
    const currentPageIndex = this.getCurrentPageIndex();
    if (currentPageIndex === pageStart + 1) {
      this.realMove(pageStart);
      return;
    }
    paginationApp.setPageIndex(pageStart + 1);
  },
  moveFirst: function(callback) {
    this.move(0, callback);
  },
  movePrev: function() {
    const store = this.grid.store;
    let start = store.lastOption && store.lastOption.data && store.lastOption.data.start || 0;
    if (!start) {
      return;
    }
    const pageSize = this.getCurrentPageSize();
    start = Math.floor(Math.max(0, start - pageSize) / pageSize);
    this.move(start);
  },
  moveNext: function() {
    const store = this.grid.store, start = store.lastOption && store.lastOption.data && store.lastOption.data.start || 0;
    const pageSize = this.getCurrentPageSize();
    if (start + pageSize > store.getTotalSize()) {
      return;
    }
    this.move(start / pageSize + 1);
  },
  moveLast: function() {
    const store = this.grid.store;
    const pageSize = this.getCurrentPageSize();
    let pageStart = Math.ceil(store.getTotalSize() / pageSize) - 1;
    pageStart = pageStart || 0;
    pageStart = Math.max(pageStart, 0);
    this.move(pageStart);
  },
  destroy: function() {
    var _a;
    (_a = this.getPaginationApp()) == null ? void 0 : _a.$destroy();
    this.purgeListeners();
    delete this.grid;
  }
});
PagingBar.pluginId = gridPluginId.pagingBar;
var pluginMap = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  Action,
  AutoRefresh,
  CheckSelection,
  CustomColumn,
  Detail,
  FixedColumn,
  Group,
  PagingBar,
  RadioGroupSelection,
  RadioSelection,
  Resizeable,
  Selection,
  Sortable,
  Tree,
  gridPluginId
});
function parseGridPlugins(plugins) {
  if ($.isPlainObject(plugins)) {
    plugins = Object.keys(plugins).sort((pluginA) => {
      return pluginA === "Tree" ? 1 : 0;
    }).filter((pluginName) => plugins[pluginName]).map((pluginName) => ({
      ...plugins[pluginName],
      pluginID: pluginName
    }));
  }
  return (plugins || []).map(function(plugin) {
    let config;
    let pluginID;
    if ($.isPlainObject(plugin)) {
      config = plugin;
      pluginID = plugin.pluginID;
    } else if (typeof plugin === "string") {
      pluginID = plugin;
    }
    const Plugin = pluginMap[pluginID];
    if (!Plugin) {
      throw new Error("invalid grid plugin " + pluginID);
    }
    if (pluginID === gridPluginId.checkSelection && config && config.showSelectionBar) {
      config.checkSelectionBarFactory = initCheckSelectionBar;
    }
    return config ? new Plugin(config) : new Plugin();
  });
}
function isPercent(str) {
  str = String(str);
  const num = parseFloat(str);
  return !isNaN(num) && str.slice(String(num).length) === "%";
}
function getGridWidgetMethods() {
  return Object.keys(Grid$1.prototype).reduce(function(map, name) {
    if (typeof Grid$1.prototype[name] === "function" && name !== "constructor") {
      map[name] = function() {
        return this.grid[name].apply(this.grid, arguments);
      };
    }
    return map;
  }, {});
}
const methods = getGridWidgetMethods();
var Grid = {
  name: componentName$4.grid,
  componentName: componentName$4.grid,
  mixins: [AddComponentMixin],
  props: {
    options: {
      type: Object,
      default: () => ({})
    },
    defaultOptions: {
      type: Object,
      default: () => ({})
    },
    autoSearch: {
      default: true
    },
    columnMinWidth: {
      type: [Number, String],
      default: "auto"
    },
    headerCeilTip: {
      type: Boolean,
      default: true
    },
    emptyTheme: {
      type: String,
      default: "image",
      validator: (value) => ["image", "text"].includes(value)
    },
    emptyConfig: {
      type: Object,
      default: () => ({
        icon: "empty",
        text: $i("scp.vt_component.sf_widget.packages.grid.empty_text"),
        abnormalIcon: "",
        abnormalText: ""
      })
    },
    disabled: {}
  },
  data() {
    return {
      records: [],
      columns: [],
      emptyInfo: {
        icon: "",
        description: ""
      },
      destroyed: false
    };
  },
  watch: {
    records: {
      handler() {
        this.renderView();
      }
    },
    disabled() {
      this[this.isDisabled ? "disable" : "enable"]();
    },
    "options.height"() {
      this.setHeight(this.__fixOptionsHeight(this.options.height));
    }
  },
  computed: {
    isDisabled() {
      return isPropEnabled(this.disabled);
    },
    style() {
      const style = {};
      if (isPercent(this.options.height)) {
        style.height = this.options.height;
      }
      return style;
    }
  },
  render(createElem) {
    const vm = this, columns = this.columns, idProperty = vm.getIdProperty(), columnChildren = vm.__getColumnChildren();
    let recordSlot = this.records.map(function(record) {
      return columns.map(function(column, col) {
        if (columnChildren[col].renderer) {
          return [];
        }
        const list = [], slotData = {
          dataIndex: column.dataIndex,
          record,
          value: record[column.dataIndex],
          row: record.__recordRow,
          col,
          number: vm.getPageStartIndex() + record.__recordRow,
          groupText: record.__fieldTitle,
          isGroup: record.__isGroup || record.__type === "group",
          isEmpty: !record[column.dataIndex] && record[column.dataIndex] !== 0
        };
        const isAction = column.isAction;
        const isAutoFitWidth = column.isAutoFitWidth;
        const hasSpace = column.hasSpace || isAction || isAutoFitWidth;
        const getChildren = () => {
          if (columnChildren[col].$scopedSlots.default) {
            return columnChildren[col].$scopedSlots.default(slotData);
          }
          if (slotData.isEmpty) {
            return "-";
          }
          return slotData.value;
        };
        list.push(
          createElem(
            hasSpace ? SfSpace : "div",
            {
              ref: "ceil_" + record[idProperty] + "_" + col,
              props: {
                inline: true,
                size: 4
              },
              class: {
                [getPrefixedClassName("is-action-column")]: isAction,
                [getPrefixedClassName("is-auto-fit-width-column")]: isAutoFitWidth,
                ellipsis: !isAction && !isAutoFitWidth && column.ellipsis
              },
              on: $.extend({}, columnChildren[col].$listeners, {
                click(e) {
                  if (columnChildren[col].$listeners.click) {
                    columnChildren[col].$listeners.click($.extend({}, slotData), e);
                  }
                  vm.$emit(columnEvent.cellClick, $.extend({}, slotData), e);
                },
                dblclick(e) {
                  if (columnChildren[col].$listeners.dblclick) {
                    columnChildren[col].$listeners.dblclick($.extend({}, slotData), e);
                  }
                  vm.$emit(columnEvent.cellDblclick, $.extend({}, slotData), e);
                }
              })
            },
            [getChildren()]
          )
        );
        if (columnChildren[col].$scopedSlots.tip) {
          list.push(
            createElem(
              "div",
              {
                ref: "tip_" + record[idProperty] + "_" + col
              },
              [columnChildren[col].$scopedSlots.tip(slotData)]
            )
          );
        }
        return list;
      });
    });
    let detailSlot = [];
    if (this.$scopedSlots.detail) {
      detailSlot = this.records.map((record) => {
        const list = [];
        const slotData = {
          record,
          row: record.__recordRow
        };
        list.push(
          createElem(
            "div",
            {
              ref: "detail_" + record[idProperty]
            },
            [this.$scopedSlots.detail(slotData)]
          )
        );
        return list;
      });
    }
    recordSlot = [].concat(recordSlot, detailSlot);
    let emptyEl = null;
    if (this.$slots.empty) {
      emptyEl = createElem(
        "div",
        {
          ref: "empty",
          class: getPrefixedClassName("sf-grid-empty")
        },
        [this.$slots.empty]
      );
    } else if (this.emptyTheme === "image") {
      emptyEl = createElem(SfEmpty, {
        ref: "empty",
        class: getPrefixedClassName("sf-grid-empty"),
        props: {
          icon: this.emptyInfo.icon,
          tip: this.emptyInfo.description
        }
      });
    }
    const headerEl = this.$slots.header;
    let hasDefaultToolbar = false;
    if (headerEl) {
      hasDefaultToolbar = !headerEl[0].elm || $(headerEl[0].elm).hasClass("sf-toolbar");
      if (hasDefaultToolbar && headerEl[0].componentOptions) {
        headerEl[0].componentOptions.propsData["noPaddingY"] = true;
        headerEl[0].componentOptions.propsData["noPaddingX"] = true;
      }
    }
    const renderHeaderSlot = () => {
      if (this.$slots.header) {
        return createElem(
          "div",
          {
            ref: "header",
            class: [
              getPrefixedClassName("sfis-grid-outer-header"),
              {
                [getPrefixedClassName("sfis-grid-outer-header--default-toolbar")]: hasDefaultToolbar
              }
            ]
          },
          [this.$slots.header]
        );
      }
      return null;
    };
    const renderFooterSlot = () => {
      if (this.$slots.footer) {
        return createElem(
          "div",
          {
            ref: "footer"
          },
          [this.$slots.footer]
        );
      }
      if (typeof this.renderComboFooter === "function") {
        const comboFooter = this.renderComboFooter(createElem);
        if (comboFooter) {
          return createElem(
            "div",
            {
              ref: "footer"
            },
            [comboFooter]
          );
        }
      }
      return null;
    };
    return createElem(
      "div",
      {
        ref: "grid",
        style: this.style
      },
      [
        createElem(
          "div",
          {
            class: {
              [getPrefixedClassName("sfis-grid_hidden-wrap")]: true
            }
          },
          [this.$slots.default, renderHeaderSlot(), renderFooterSlot(), emptyEl].concat(recordSlot)
        )
      ]
    );
  },
  created() {
    const vm = this;
    this.$on(gridEventName.grid.afterRenderDetail, (detailContainerSelector) => {
      const detailContainer = $(detailContainerSelector)[0];
      if (detailContainer && $.contains(detailContainer, vm.$el)) {
        requestAnimationFrame(() => {
          var _a;
          (_a = vm.grid) == null ? void 0 : _a.resetScrollPosition();
        });
      }
    });
  },
  mounted() {
    const me = this;
    me.__initLoadMask();
    this.__init();
    this.$on(
      columnEvent.columnChange,
      debounce(function() {
        if (!me.destroyed) {
          me.updateOption();
        }
      }, COLUMN_UPDATE_WAIT)
    );
    this.$loadMask.on({
      show() {
        if (me.grid.isShowMsg) {
          me.showInfo("");
        }
      }
    });
  },
  updated() {
    this.__bindSearchEvent();
  },
  methods: $.extend({}, methods, {
    reload() {
      return this.grid.store.reload.apply(this.grid.store, arguments);
    },
    loadData() {
      return this.grid.store.loadData.apply(this.grid.store, arguments);
    },
    __ensureRender() {
      this.$nextTick(() => this.grid.__redrawIfNeed());
    },
    getPageStartIndex() {
      return this.grid.getPageStartIndex.apply(this.grid, arguments);
    },
    getIdProperty() {
      return this.grid && this.grid.store.options.idProperty;
    },
    updateElSize(immediately) {
      const updateElSize = () => {
        this.grid.updateElSize();
      };
      if (immediately) {
        updateElSize();
        return;
      }
      this.$nextTick(updateElSize);
    },
    renderView(immediately) {
      const renderView = () => {
        this.grid.renderView();
      };
      if (immediately) {
        renderView();
        return;
      }
      this.$nextTick(renderView);
    },
    updateOption() {
      this.grid.updateOption(this._createGridOptions());
    },
    __init() {
      const vm = this;
      vm.grid = new Grid$1(vm._createGridOptions());
      vm.store = vm.grid.store;
      if (vm.store.options.data && !vm.grid.isPluginExist("PagingBar")) {
        vm.store.initDataHash(vm.store.options.data);
      }
      vm._bindGridEvent();
      vm.__bindSearchEvent();
      vm.grid.render(vm.$refs.grid);
    },
    __initLoadMask() {
      const vm = this;
      let loadMask;
      Object.defineProperty(vm, "$loadMask", {
        configurable: true,
        get() {
          if (loadMask) {
            return loadMask;
          }
          vm.__loadMaskInited = true;
          const { target, option } = vm.__getLoadMaskConfig();
          loadMask = new LoadMask(target, option);
          return loadMask;
        }
      });
      Object.defineProperty(vm, "$gridLoadMask", {
        configurable: true,
        get() {
          return vm.$loadMask;
        }
      });
    },
    __getLoadMaskConfig() {
      const vm = this;
      return {
        target: vm.$el,
        option: {
          cls: getPrefixedClassName("sfis-grid-mask"),
          align: "horizontal"
        }
      };
    },
    __destroyLoadMask() {
      if (this.__loadMaskInited) {
        this.$loadMask.destroy();
      }
    },
    __bindSearchEvent() {
      const vm = this;
      let toolbar;
      if (!this.autoSearch || this.searchComponent) {
        return;
      }
      if (typeof this.autoSearch === "string") {
        this.searchComponent = this.$vnode && this.$vnode.context && this.$vnode.context.$refs[this.autoSearch];
      } else {
        toolbar = findVnodeComponent(this.$vnode, (vnodeComponent) => {
          return vnodeComponent.componentOptions.Ctor.options.componentName === componentName$4.toolbar;
        })[0];
        if (toolbar) {
          this.searchComponent = findVnodeComponent(toolbar, (vnodeComponent) => {
            return vnodeComponent.componentOptions.Ctor.options.componentName === componentName$4.searchTrigger;
          })[0];
          this.searchComponent = this.searchComponent && this.searchComponent.componentInstance;
        }
      }
      if (!this.searchComponent) {
        return;
      }
      this.searchComponent.$on(
        [searchComponentEvent.input, searchComponentEvent.trigger],
        throttle(function(value) {
          vm.grid.search(value);
        }, SEARCH_WAIT)
      );
      this.searchComponent.$on(
        searchComponentEvent.end,
        throttle(function() {
          vm.grid.endSearch();
        }, SEARCH_WAIT)
      );
    },
    _getRecordsChangeMapHandler(store) {
      return (key, rowIndex) => {
        const record = store.dataHash[key];
        return $.extend({}, record.data, {
          __recordRow: rowIndex,
          __parent: null,
          __children: null
        });
      };
    },
    _bindGridEvent() {
      const vm = this;
      if (this.options.noBufferView) {
        this.grid.store.on(gridEventName.store.dataChange, (store) => {
          this.records = $.extend(true, [], Object.keys(store.dataHash).map(this._getRecordsChangeMapHandler(store)));
        });
      } else {
        this.grid.on(gridEventName.grid.renderGridRecords, ({ store, recordKeys }) => {
          if (!this.records.length && !recordKeys.length) {
            return;
          }
          this.records = recordKeys.map(this._getRecordsChangeMapHandler(store));
        });
      }
      if (this.options.height !== "auto") {
        this.grid.store.on(gridEventName.store.afterLoadData, () => {
          this.__ensureRender();
        });
      }
      events$1.forEach(function(event) {
        vm.grid.on(event, function() {
          vm.$emit(event, arguments);
        });
      });
      this.grid.on(gridEventName.grid.afterRenderDetail, (detailContainerSelector) => {
        vm.broadcast(componentName$4.grid, gridEventName.grid.afterRenderDetail, [detailContainerSelector]);
      });
    },
    _createGridOptions() {
      var _a;
      const vm = this;
      const options = $.extend(
        true,
        {
          enableRowDblClick: false,
          utid: (_a = vm.$attrs.utid) != null ? _a : ""
        },
        vm.defaultOptions,
        vm.options
      );
      if (options.enableRowDblClick) {
        throw new Error('"options.enableRowDblClick" is not allowed, binding events directly to scopeSlot instead');
      }
      if (options.listeners) {
        throw new Error(`"options.listeners" is not allowed, use Vue's event binding instead`);
      }
      if (options.dftColumnText) {
        throw new Error('"options.dftColumnText" is not allowed, using "empty" scopeSlot instead');
      }
      if (options.tbar || options.tbarWrap) {
        throw new Error('"options.tbar" is not allowed, using "toolbar" component instead');
      }
      options.plugins = parseGridPlugins(options.plugins);
      $.makeArray(options.plugins).forEach(function(plugin) {
        if (plugin === Action || plugin instanceof Action) {
          throw new Error('"Action" plugin is not allowed, binding events directly to scopeSlot instead');
        }
        if (plugin instanceof Group && plugin.options.renderer) {
          throw new Error('"Group.options.renderer" is not allowed, using scopeSlot instead');
        }
        if (plugin instanceof Group && plugin.options.minorRenderer) {
          throw new Error('"Group.options.minorRenderer" is not allowed, using scopeSlot instead');
        }
      });
      options.column = vm.__getColumnChildren().map(function(child) {
        const column = child.getConfig();
        if (typeof column.ceilTip === "function") {
          throw new TypeError('"column.ceilTip" is not allowed to be function, using <template slot="tip"> instead');
        }
        if (child.$scopedSlots.tip) {
          column.ceilTip = (value, record, row, col) => {
            const idProperty = vm.getIdProperty();
            const tipWrapRef = vm.$refs[`tip_${record.get(idProperty)}_${col}`];
            return ((tipWrapRef == null ? void 0 : tipWrapRef.innerHTML) || "").trim();
          };
        }
        if (child.$slots["header-content-right"]) {
          column.headerContentRightRef = child.$refs.headerContentRightRef;
        }
        if (child.$slots["header-tip"]) {
          column.headerTipRef = child.$refs.headerTipRef;
        }
        if (child.$slots["header-filter"]) {
          column.headerFilterRef = child.$refs.headerFilterRef;
        }
        if (!column.renderer) {
          column.renderElem = function(value, record, row, col) {
            const idProperty = vm.getIdProperty();
            const refKey = "ceil_" + record.get(idProperty) + "_" + col;
            if (!vm.$refs[refKey]) {
              return "";
            }
            return vm.$refs[refKey].$el || vm.$refs[refKey];
          };
        }
        return column;
      });
      vm.columns = $.extend(true, [], options.column);
      if ($.isPlainObject(options.store)) {
        options.store = new Store(options.store);
      } else if (!options.store) {
        options.store = new Store();
      }
      options.disabled = vm.isDisabled;
      options.tbarWrap = vm.$refs.header;
      if (vm.$refs.footer) {
        options.renderFooterOther = () => vm.$refs.footer;
      }
      if (vm.$refs.empty) {
        options.renderEmpty = (msg, isAbnormal) => {
          if (!msg) {
            return "";
          }
          const globalEmptyConfig = get(featureConfig, "componentConfig.grid.emptyConfig", {});
          const emptyConfig = vm.emptyConfig;
          if (isAbnormal) {
            vm.emptyInfo.icon = emptyConfig.abnormalIcon || globalEmptyConfig.abnormalIcon || "win-alert";
            vm.emptyInfo.description = emptyConfig.abnormalText || globalEmptyConfig.abnormalText || getAjaxMessage(msg);
          } else {
            vm.emptyInfo.icon = emptyConfig.icon || globalEmptyConfig.icon || "empty";
            vm.emptyInfo.description = emptyConfig.text || globalEmptyConfig.text || msg;
          }
          return vm.$refs.empty.$el || vm.$refs.empty;
        };
      }
      if (vm.$scopedSlots.detail) {
        options.renderDetail = function(record) {
          const refKey = "detail_" + record.get(vm.getIdProperty());
          if (!vm.$refs[refKey]) {
            return "";
          }
          return vm.$refs[refKey].$el || vm.$refs[refKey];
        };
      }
      options.height = vm.__fixOptionsHeight(options.height);
      return options;
    },
    __getColumnChildren() {
      return this.$children.filter((child) => {
        return child.$options.componentName === componentName$4.gridColumn;
      });
    },
    __fixOptionsHeight(height) {
      return isPercent(height) ? "100%" : height;
    },
    hideHeaderFilter() {
      this.__getColumnChildren().forEach((column) => column.hideHeaderFilter());
    }
  }),
  beforeDestroy() {
    this.__destroyLoadMask();
    (this.columns || []).forEach((item) => {
      if (item.headerTipRef && typeof item.headerTipRef.$destroy === "function") {
        item.headerTipRef.$destroy();
      }
      if (item.headerFilterRef && typeof item.headerFilterRef.$destroy === "function") {
        item.headerFilterRef.$destroy();
      }
      if (item.headerContentRightRef && typeof item.headerContentRightRef.$destroy === "function") {
        item.headerContentRightRef.$destroy();
      }
    });
    if (this.searchComponent && typeof this.searchComponent.$destroy === "function") {
      this.searchComponent.$destroy();
    }
    this.searchComponent = null;
    if (this.grid && typeof this.grid.destroy === "function") {
      this.grid.destroy();
    }
    this.grid = null;
    this.columns = null;
    this.records = null;
    this.emptyInfo = null;
    this.destroyed = true;
  }
};
const { store: storeEvent } = gridEventName;
var GridSearchTip = {
  name: componentName$4.gridSearchTip,
  componentName: componentName$4.gridSearchTip,
  extends: SfSearchTip,
  props: {
    gridName: {
      type: String,
      default: "grid"
    },
    params: {
      type: Object,
      default: () => ({})
    }
  },
  computed: {
    grid() {
      return this.$vnode.context.$refs[this.gridName];
    }
  },
  mounted() {
    if (this.grid) {
      this.__initEvent();
    }
  },
  methods: {
    __initEvent() {
      const me = this;
      this.grid.$on("render", function(args) {
        const store = args[0].store;
        store.on(storeEvent.load, (success, json) => {
          if (!me.__hasValue(me.params)) {
            return;
          }
          if (success) {
            me.onSuccess(json.count || 0);
          } else {
            me.onFail();
          }
        });
      });
    },
    __hasValue(data) {
      for (const key in data) {
        if (data.hasOwnProperty(key)) {
          if (data[key]) {
            return true;
          }
        }
      }
      return false;
    }
  },
  watch: {
    params: {
      handler(v) {
        if (this.__hasValue(v)) {
          this.show();
        }
      },
      deep: true
    }
  }
};
export { CustomColumn, PagingBar, Grid as SfGrid, __vue_component__$4 as SfGridColumn, GridSearchTip as SfGridSearchTip };
