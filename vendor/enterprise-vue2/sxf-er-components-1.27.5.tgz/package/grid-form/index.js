import { intersectionBy, differenceWith, isEqual } from 'lodash-es';
import { componentName } from '@sxf/er-components/_const';
import { SfButton } from '@sxf/er-components/button';
import { SfForm, SfFormItem } from '@sxf/er-components/form';
import { SfGrid, SfGridColumn } from '@sxf/er-components/grid';
import { SfSearch } from '@sxf/er-components/search';
import { SfSpace } from '@sxf/er-components/space';
import { SfToolbar } from '@sxf/er-components/toolbar';
import { $i } from '@sxf/er-config';
import { getPrefixedClassName } from '@sxf/er-feature';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
var script$1 = {
  name: componentName.gridForm,
  componentName: componentName.gridForm,
  components: { SfButton, SfForm, SfGrid, SfGridColumn, SfSpace, SfToolbar, SfSearch },
  props: {
    value: Array,
    options: {
      type: Object,
      default: () => ({
        height: "auto",
        size: "normal"
      })
    },
    disableDeleteTip: {
      type: Function,
      default: () => ""
    },
    disableAddTip: {
      type: Function,
      default: () => ""
    },
    hideWhileEmpty: {
      type: Boolean,
      default: true
    },
    disableAdd: {
      type: Boolean,
      default: false
    },
    disableDelete: {
      type: Function,
      default: () => false
    },
    beforeDelete: {
      type: Function,
      default: () => true
    },
    beforeAdd: {
      type: Function,
      default: () => true
    },
    showOperation: {
      type: Boolean,
      default: true
    },
    showFooter: {
      type: Boolean,
      default: true
    },
    formProps: {
      type: Object,
      default: () => ({})
    },
    addButtonDes: {
      type: String,
      default: ""
    },
    showSearch: {
      type: Boolean,
      default: false
    },
    searchOptions: {
      type: Object,
      default: () => ({})
    }
  },
  data() {
    return {
      datas: this.value || [],
      dataKeys: []
    };
  },
  computed: {
    isEmpty() {
      return this.datas.length === 0;
    },
    showGrid() {
      return !(this.isEmpty && this.hideWhileEmpty);
    },
    colunmOperationHeader() {
      return $i("scp.vt_component.sf_widget.packages.grid_form.colunm_operation");
    },
    colunmOperationHeaderDeleteBtnText() {
      return $i("scp.vt_component.sf_widget.packages.grid_form.colunm_operation_delete_btn");
    },
    footerAddBtnText() {
      return $i("scp.vt_component.sf_widget.packages.grid_form.footer_add_btn");
    },
    isShowToolbar() {
      return this.$slots["toolbar-operation"] || this.showSearch;
    }
  },
  watch: {
    datas: {
      handler() {
        this.$nextTick(() => {
          this.loadData(this.datas);
          this.$emit("input", this.datas);
        });
      },
      immediate: true
    },
    value: {
      handler() {
        this.syncGridStoreData(this.value);
        this.datas = this.value;
      },
      deep: true
    }
  },
  mounted() {
    const dataKeys = [];
    this.$refs.grid.columns.forEach((v) => {
      if (v.dataIndex) {
        dataKeys.push(v.dataIndex);
      }
    });
    this.dataKeys = dataKeys;
  },
  methods: {
    getFullUtid(utidBase) {
      return this.$attrs.utid ? `${this.$attrs.utid}-${utidBase}` : utidBase;
    },
    loadData(data) {
      this.$refs.grid.loadData(data.map((v, index) => ({ id: index, ...v })));
    },
    validate() {
      return this.$refs.form.validate();
    },
    async deleteItem(props) {
      const ok = await this.beforeDelete(props);
      if (!ok) {
        return;
      }
      const data = this.datas.splice(props.row, 1);
      this.$emit("delete-success", data);
    },
    async addItem() {
      const ok = await this.beforeAdd();
      if (!ok) {
        return;
      }
      const obj = {};
      this.dataKeys.forEach((key) => {
        obj[key] = null;
      });
      this.datas.push(obj);
      this.$emit("add-success", obj);
    },
    getPrefixedClassName,
    syncGridStoreData() {
      const idProperty = this.$refs.grid.options.idProperty || "id";
      const dataHash = this.$refs.grid.getData();
      const commonIdRecord = intersectionBy(this.value, dataHash, idProperty);
      const diffList = differenceWith(commonIdRecord, dataHash, isEqual);
      for (const node of diffList) {
        this.$refs.grid.store.updateData(node.id, node);
      }
    }
  }
};
const __vue_script__$1 = script$1;
var __vue_render__$1 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "sf-form",
    _vm._b(
      {
        ref: "form",
        class: _vm.getPrefixedClassName("sf-grid-form"),
        attrs: { "auto-label-width": false }
      },
      "sf-form",
      _vm.formProps,
      false
    ),
    [
      _vm.isShowToolbar ? _c(
        "sf-toolbar",
        { ref: "toolbar", attrs: { "no-left-right-replace": false } },
        [
          _vm._t("toolbar-operation"),
          _vm._v(" "),
          _c(
            "template",
            { slot: "right" },
            [
              _vm.showSearch ? _c(
                "sf-search",
                _vm._b(
                  {
                    ref: "gridFormSearchRef",
                    attrs: {
                      utid: _vm.getFullUtid("grid-form-search")
                    }
                  },
                  "sf-search",
                  _vm.searchOptions,
                  false
                )
              ) : _vm._e()
            ],
            1
          )
        ],
        2
      ) : _vm._e(),
      _vm._v(" "),
      _c(
        "sf-grid",
        _vm._g(
          _vm._b(
            {
              directives: [
                {
                  name: "show",
                  rawName: "v-show",
                  value: _vm.showGrid,
                  expression: "showGrid"
                }
              ],
              ref: "grid",
              class: _vm.getPrefixedClassName("sf-grid-form__grid"),
              attrs: {
                options: _vm.options,
                "auto-search": "gridFormSearchRef"
              }
            },
            "sf-grid",
            _vm.$attrs,
            false
          ),
          _vm.$listeners
        ),
        [
          _vm._t("default"),
          _vm._v(" "),
          _vm.showOperation ? _c("sf-grid-column", {
            attrs: { header: _vm.colunmOperationHeader, "is-action": true },
            scopedSlots: _vm._u(
              [
                {
                  key: "default",
                  fn: function(props) {
                    return [
                      _vm._t(
                        "operate",
                        [
                          _vm._t("operate-inner", null, null, props),
                          _vm._v(" "),
                          _c(
                            "sf-button",
                            {
                              class: _vm.getPrefixedClassName(
                                "sf-grid-form__delete"
                              ),
                              attrs: {
                                size: "small",
                                utid: _vm.getFullUtid("delete"),
                                disabled: _vm.disableDelete(props),
                                tip: _vm.disableDeleteTip(props)
                              },
                              on: {
                                click: function($event) {
                                  return _vm.deleteItem(props);
                                }
                              }
                            },
                            [
                              _vm._v(
                                "\n            " + _vm._s(
                                  _vm.colunmOperationHeaderDeleteBtnText
                                ) + "\n          "
                              )
                            ]
                          )
                        ],
                        null,
                        props
                      )
                    ];
                  }
                }
              ],
              null,
              true
            )
          }) : _vm._e()
        ],
        2
      ),
      _vm._v(" "),
      _vm.showFooter ? _c(
        "div",
        { class: _vm.getPrefixedClassName("sf-grid-form__footer") },
        [
          _vm._t("footer", [
            _c(
              "sf-space",
              [
                _c(
                  "sf-button",
                  {
                    class: _vm.getPrefixedClassName("sf-grid-form__add"),
                    attrs: {
                      icon: "add",
                      utid: _vm.getFullUtid("add"),
                      disabled: _vm.disableAdd,
                      tip: _vm.disableAddTip()
                    },
                    on: {
                      click: function($event) {
                        return _vm.addItem();
                      }
                    }
                  },
                  [_c("span", [_vm._v(_vm._s(_vm.footerAddBtnText))])]
                ),
                _vm._v(" "),
                _vm._t("footer-right", [
                  _vm.addButtonDes ? _c(
                    "span",
                    {
                      class: _vm.getPrefixedClassName(
                        "sf-grid-form__footer--right"
                      )
                    },
                    [
                      _vm._v(
                        "\n            " + _vm._s(_vm.addButtonDes) + "\n          "
                      )
                    ]
                  ) : _vm._e()
                ])
              ],
              2
            )
          ])
        ],
        2
      ) : _vm._e()
    ],
    1
  );
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
var script = {
  name: componentName.gridFormColumn,
  componentName: componentName.gridFormColumn,
  inject: {
    components: {
      default: {
        SfGridColumn,
        SfFormItem
      }
    }
  }
};
const __vue_script__ = script;
var __vue_render__ = function(_h, _vm) {
  var _c = _vm._c;
  return _c(
    _vm.injections.components.SfGridColumn,
    _vm._b(
      {
        tag: "component",
        scopedSlots: _vm._u(
          [
            {
              key: "default",
              fn: function(props) {
                return [
                  _vm.data.attrs["is-form-item"] !== false ? _c(
                    _vm.injections.components.SfFormItem,
                    {
                      tag: "component",
                      attrs: {
                        "show-label": false,
                        label: _vm.data.attrs.header
                      }
                    },
                    [_vm._t("default", null, null, props)],
                    2
                  ) : [_vm._t("default", null, null, props)]
                ];
              }
            }
          ],
          null,
          true
        )
      },
      "component",
      _vm.data.attrs,
      false
    ),
    [
      _vm.$slots["header-tip"] ? _c("template", { slot: "header-tip" }, [_vm._t("header-tip")], 2) : _vm._e()
    ],
    2
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = true;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__$1 as SfGridForm, __vue_component__ as SfGridFormColumn };
