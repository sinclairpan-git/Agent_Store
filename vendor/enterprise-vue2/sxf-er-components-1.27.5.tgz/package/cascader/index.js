import { isEqual } from 'lodash-es';
import { componentName } from '@sxf/er-components/_const';
import { vClickoutside, vOnShow } from '@sxf/er-components/_directives';
import { EmitterMixin, MultipleSelectMixin } from '@sxf/er-components/_mixins';
import { VuePopper } from '@sxf/er-components/_utils/popper';
import { FormSizeMixin, FormFieldMixin } from '@sxf/er-components/form';
import { SfInput } from '@sxf/er-components/input';
import { SfSpace } from '@sxf/er-components/space';
import { SfTag } from '@sxf/er-components/tag';
import { $i } from '@sxf/er-config';
import { getPrefixedClassName } from '@sxf/er-feature';
import { debounce } from '@sxf/er-utils/delay';
import erStringUtils from '@sxf/er-utils/string';
import { SfCheckbox } from '@sxf/er-components/checkbox';
import { scrollIntoView } from '@sxf/er-utils/dom';
import uuid from '@sxf/er-utils/uuid';
import Logger from '@sxf/er-utils/logger';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
const cascaderLogger = Logger("Cascader");
const VALUE_SPLIT = "__ER_CASCADER_SPLIT__";
function getFullPathKey(v) {
  if (Array.isArray(v)) {
    return v.join(VALUE_SPLIT);
  }
  return v;
}
function removeFromCheckedKeys(halfCheckedKeys, checkedKeys) {
  const filteredKeys = /* @__PURE__ */ new Set();
  halfCheckedKeys.forEach(function(key) {
    if (!checkedKeys.has(key)) {
      filteredKeys.add(key);
    }
  });
  return filteredKeys;
}
function isCheckDisabled(node) {
  const r = node || {};
  const disabled = r.disabled;
  return !!disabled;
}
function fillConductCheck(keys, levelEntities, maxLevel) {
  const checkedKeys = new Set(keys);
  const halfCheckedKeys = /* @__PURE__ */ new Set();
  for (let l = 0; l <= maxLevel; l++) {
    const entities = levelEntities.get(l);
    entities.forEach((entity) => {
      const key = entity.fullPathKey;
      const node = entity.node;
      if (!entity.isLeaf && checkedKeys.has(key) && !isCheckDisabled(node)) {
        entity.children.filter((cE) => !isCheckDisabled(cE.node)).forEach((cE) => {
          checkedKeys.add(cE.fullPathKey);
        });
      }
    });
  }
  const visitedKeys = /* @__PURE__ */ new Set();
  for (let l = maxLevel; l >= 0; l--) {
    const entities = levelEntities.get(l);
    entities.forEach((entity) => {
      const parent = entity.parent;
      const node = entity.node;
      if (!parent || visitedKeys.has(parent.fullPathKey)) {
        return;
      }
      if (isCheckDisabled(node)) {
        if (checkedKeys.has(entity.fullPathKey)) {
          halfCheckedKeys.add(parent.fullPathKey);
        }
        return;
      }
      if (isCheckDisabled(parent.node)) {
        visitedKeys.add(parent.fullPathKey);
        return;
      }
      let allChecked = true;
      let partialChecked = false;
      (parent.children || []).filter((cE) => !isCheckDisabled(cE.node)).forEach((cE) => {
        const key = cE.fullPathKey;
        const checked = checkedKeys.has(key);
        if (allChecked && !checked) {
          allChecked = false;
        }
        if (!partialChecked && (checked || halfCheckedKeys.has(key))) {
          partialChecked = true;
        }
      });
      if (allChecked) {
        checkedKeys.add(parent.fullPathKey);
      }
      if (partialChecked) {
        halfCheckedKeys.add(parent.fullPathKey);
      }
      visitedKeys.add(parent.fullPathKey);
    });
  }
  return {
    checkedKeys: Array.from(checkedKeys),
    halfCheckedKeys: Array.from(removeFromCheckedKeys(halfCheckedKeys, checkedKeys))
  };
}
function cleanConductCheck(keys, halfKeys, levelEntities, maxLevel) {
  const checkedKeys = new Set(keys);
  let halfCheckedKeys = new Set(halfKeys);
  for (let l = 0; l <= maxLevel; l++) {
    const entities = levelEntities.get(l);
    entities.forEach((entity) => {
      const key = entity.fullPathKey;
      if (!entity.isLeaf && !checkedKeys.has(key) && !halfCheckedKeys.has(key) && !isCheckDisabled(entity.node)) {
        entity.children.filter((cE) => !isCheckDisabled(cE.node)).forEach((cE) => {
          checkedKeys.delete(cE.fullPathKey);
        });
      }
    });
  }
  halfCheckedKeys = /* @__PURE__ */ new Set();
  const visitedKeys = /* @__PURE__ */ new Set();
  for (let l = maxLevel; l >= 0; l--) {
    const entities = levelEntities.get(l);
    entities.forEach((entity) => {
      const parent = entity.parent;
      const node = entity.node;
      if (!parent || visitedKeys.has(parent.fullPathKey)) {
        return;
      }
      if (isCheckDisabled(node)) {
        if (checkedKeys.has(entity.fullPathKey)) {
          halfCheckedKeys.add(parent.fullPathKey);
        }
        return;
      }
      if (isCheckDisabled(parent.node)) {
        visitedKeys.add(parent.fullPathKey);
        return;
      }
      let allChecked = true;
      let partialChecked = false;
      (parent.children || []).filter((cE) => !isCheckDisabled(cE.node)).forEach((childrenEntity) => {
        const key = childrenEntity.fullPathKey;
        const checked = checkedKeys.has(key);
        if (allChecked && !checked) {
          allChecked = false;
        }
        if (!partialChecked && (checked || halfCheckedKeys.has(key))) {
          partialChecked = true;
        }
      });
      if (!allChecked) {
        checkedKeys.delete(parent.fullPathKey);
      }
      if (partialChecked) {
        halfCheckedKeys.add(parent.fullPathKey);
      }
      visitedKeys.add(parent.key);
    });
  }
  return {
    checkedKeys: Array.from(checkedKeys),
    halfCheckedKeys: Array.from(removeFromCheckedKeys(halfCheckedKeys, checkedKeys))
  };
}
function conductCheck(keyList, status, keyEntities, halfDataSet = []) {
  const warningMissKeys = [];
  const keys = new Set(
    keyList.filter((key) => {
      const hasEntity = keyEntities[key];
      if (!hasEntity) {
        warningMissKeys.push(key);
      }
      return hasEntity;
    })
  );
  if (warningMissKeys.length) {
    cascaderLogger.error(
      "Tree missing follow keys: ".concat(
        warningMissKeys.slice(0, 100).map((key) => "'".concat(key, "'")).join(", ")
      )
    );
  }
  const levelEntities = /* @__PURE__ */ new Map();
  let maxLevel = 0;
  Object.keys(keyEntities).forEach(function(key) {
    const entity = keyEntities[key];
    const level = entity.level;
    let levelSet = levelEntities.get(level);
    if (!levelSet) {
      levelSet = /* @__PURE__ */ new Set();
      levelEntities.set(level, levelSet);
    }
    levelSet.add(entity);
    maxLevel = Math.max(maxLevel, level);
  });
  let result;
  if (status === true) {
    result = fillConductCheck(keys, levelEntities, maxLevel);
  } else {
    result = cleanConductCheck(keys, halfDataSet, levelEntities, maxLevel);
  }
  return result;
}
function calculateDepth(data, childrenField = "children") {
  if (!Array.isArray(data) || data.length === 0) {
    return 0;
  }
  let maxDepth = 0;
  for (let i = 0; i < data.length; i++) {
    if (data[i][childrenField]) {
      const depth = calculateDepth(data[i][childrenField], childrenField);
      if (depth > maxDepth) {
        maxDepth = depth;
      }
    }
  }
  return maxDepth + 1;
}
const CONFIGURABLE_PROPS = ["__IS__FLAT__OPTIONS", "label", "value", "disabled", "tip"];
const CHILDREN_PROP_DEFAULT = "children";
const KEY_CODES = {
  UP: 38,
  DOWN: 40,
  LEFT: 37,
  RIGHT: 39,
  ENTER: 13,
  TAB: 9,
  ESC: 27
};
function isDef(val) {
  return val !== void 0 && val !== null;
}
const copyArray = (arr, props) => {
  if (!arr || !Array.isArray(arr) || !props) {
    return arr;
  }
  const result = [];
  const childrenProp = props.children || CHILDREN_PROP_DEFAULT;
  arr.forEach((item) => {
    const itemCopy = {};
    CONFIGURABLE_PROPS.forEach((prop) => {
      let name = props[prop];
      let value = item[name];
      if (typeof value === "undefined") {
        name = prop;
        value = item[name];
      }
      if (typeof value !== "undefined") {
        itemCopy[name] = value;
      }
    });
    if (item.pureTextLabel) {
      itemCopy.pureTextLabel = item.pureTextLabel;
    }
    if (Array.isArray(item[childrenProp])) {
      itemCopy[childrenProp] = copyArray(item[childrenProp], props);
    }
    result.push(itemCopy);
  });
  return result;
};
var SfCascaderMenu = {
  name: "CascaderMenu",
  props: {
    filterable: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      inputWidth: 0,
      options: [],
      originOptions: [],
      props: {},
      visible: false,
      activeValue: [],
      value: [],
      expandTrigger: "click",
      changeOnSelect: false,
      popperClass: "",
      hoverTimer: 0,
      clicking: false,
      size: "",
      menuWidth: 0,
      multiple: false,
      valueSet: /* @__PURE__ */ new Set(),
      halfStateValueSet: /* @__PURE__ */ new Set(),
      searchValue: ""
    };
  },
  computed: {
    activeOptions: {
      cache: false,
      get() {
        const activeValue = this.activeValue;
        const formatOptions = (options, fullPath = []) => {
          options.forEach((option) => {
            if (option.__IS__FLAT__OPTIONS) {
              if (Array.isArray(option.value)) {
                option.fullPathKey = getFullPathKey(option.value);
              }
              return;
            }
            CONFIGURABLE_PROPS.forEach((prop) => {
              const value = option[this.props[prop] || prop];
              if (typeof value !== "undefined") {
                option[prop] = value;
              }
            });
            const newFullPath = fullPath.concat(option.value);
            option.fullPathKey = getFullPathKey(newFullPath);
            if (Array.isArray(option.children)) {
              formatOptions(option.children, newFullPath);
            }
          });
        };
        const loadActiveOptions = (options, activeOptions = []) => {
          const level = activeOptions.length;
          activeOptions[level] = options;
          const active = activeValue[level];
          if (isDef(active)) {
            options = options.filter((option) => option.value === active)[0];
            if (options && options.children) {
              loadActiveOptions(options.children, activeOptions);
            }
          }
          return activeOptions;
        };
        const optionsCopy = copyArray(this.options, this.props);
        formatOptions(optionsCopy);
        return loadActiveOptions(optionsCopy);
      }
    },
    enhancedOptionsWithNode() {
      const formatOptions = (nodes, parent, fullPath = [], level = 0) => {
        return nodes.map((node) => {
          CONFIGURABLE_PROPS.forEach((prop) => {
            const value = node[this.props[prop] || prop];
            if (typeof value !== "undefined") {
              node[prop] = value;
            }
          });
          const newFullPath = fullPath.concat(node.value);
          const isLeaf = !Array.isArray(node.children);
          const option = {
            node,
            level,
            isLeaf,
            fullPath: newFullPath,
            fullPathKey: getFullPathKey(newFullPath),
            parent
          };
          if (!isLeaf) {
            option.children = formatOptions(node.children, option, newFullPath, level + 1);
          }
          return option;
        });
      };
      const optionCopy = copyArray(this.originOptions, this.props);
      return formatOptions(optionCopy);
    },
    fullPathKeyEntities() {
      const flat = (options) => {
        return options.reduce((r, n) => {
          return { ...r, [n.fullPathKey]: n, ...n.isLeaf ? [] : flat(n.children) };
        }, {});
      };
      return flat(this.enhancedOptionsWithNode);
    },
    id() {
      return uuid();
    },
    currentLevel() {
      return this.activeValue.length;
    },
    searchInputWidth() {
      return !this.currentLevel ? this.menuWidth + "px" : "100%";
    }
  },
  watch: {
    visible(value) {
      if (value && this.$refs.searchInputRef) {
        this.$nextTick(() => this.$refs.searchInputRef.focus());
      }
      this.handleValue(true, this.value.map(getFullPathKey));
      this.activeValue = this.getActiveOfValue();
    },
    value: {
      immediate: true,
      handler() {
        this.handleValue(true, this.value.map(getFullPathKey));
        this.activeValue = this.getActiveOfValue();
      }
    },
    currentLevel(level) {
      this.$emit("level-changed", level);
    }
  },
  methods: {
    getFullUtid(utidBase) {
      return this.$attrs.utid ? `${this.$attrs.utid}-${utidBase}` : utidBase;
    },
    select(item, menuIndex) {
      if (item.__IS__FLAT__OPTIONS) {
        this.activeValue = item.value;
      } else if (menuIndex) {
        this.activeValue.splice(menuIndex, this.activeValue.length - 1, item.value);
      } else {
        this.activeValue = [item.value];
      }
      if (this.multiple) {
        this.selectMultiple(!this.valueSet.has(item.fullPathKey), item);
        return;
      }
      this.$emit("pick", this.activeValue.slice());
    },
    selectMultiple(checked, item) {
      if (checked === true) {
        this.valueSet.add(item.fullPathKey);
      } else {
        this.valueSet.delete(item.fullPathKey);
      }
      this.handleValue(checked, Array.from(this.valueSet));
      this.emitPickMulti();
    },
    formatStrategyValues(fullPathKeys) {
      return fullPathKeys.filter((keys) => {
        const entity = this.fullPathKeyEntities[keys];
        const children = entity ? entity.children : null;
        return !children;
      });
    },
    getActiveOfValue() {
      var _a;
      if (this.multiple) {
        return (((_a = this.value) == null ? void 0 : _a[0]) || []).slice(0);
      }
      return this.value.slice(0);
    },
    getValueByKeyPath(keys) {
      return keys.map((key) => {
        const entity = this.fullPathKeyEntities[key];
        return entity.fullPath;
      });
    },
    handleValue(checked, v) {
      if (!this.multiple) {
        return;
      }
      const { checkedKeys, halfCheckedKeys } = conductCheck(
        v,
        checked,
        this.fullPathKeyEntities,
        Array.from(this.halfStateValueSet)
      );
      this.valueSet = new Set(checkedKeys);
      this.halfStateValueSet = new Set(halfCheckedKeys);
    },
    handleMenuLeave() {
      this.$emit("menuLeave");
    },
    emitPickMulti() {
      const checkedKeys = Array.from(this.valueSet);
      const deDuplicatedKeys = this.formatStrategyValues(checkedKeys);
      const nextCheckedValue = this.getValueByKeyPath(deDuplicatedKeys);
      this.$emit("pickMulti", nextCheckedValue);
    },
    activeItem(item, menuIndex) {
      const len = this.activeOptions.length;
      this.activeValue.splice(menuIndex, len, item.value);
      this.activeOptions.splice(menuIndex + 1, len, item.children);
      if (this.changeOnSelect) {
        this.$emit("pick", this.activeValue.slice(), false);
      } else {
        this.$emit("activeItemChange", this.activeValue);
      }
    },
    scrollMenu(menu) {
      scrollIntoView(menu, menu.getElementsByClassName("is-active")[0]);
    },
    handleMenuEnter() {
      this.$nextTick(() => this.$refs.menus.forEach((menu) => this.scrollMenu(menu)));
    }
  },
  render(h) {
    var _a;
    const { activeValue, activeOptions, visible, expandTrigger, popperClass, hoverThreshold, size, menuWidth } = this;
    let itemID = null;
    let itemIndex = 0;
    const isEmpty = !((_a = this.options) == null ? void 0 : _a.length);
    const empty = h(
      "li",
      {
        class: {
          [getPrefixedClassName("sf-cascader-menu__empty-item")]: true
        }
      },
      [$i("scp.vt_component.sf_widget.packages.cascader.no_match")]
    );
    let hoverMenuRefs = {};
    const hoverMenuHandler = (e) => {
      const activeMenu = hoverMenuRefs.activeMenu;
      if (!activeMenu) {
        return;
      }
      const offsetX = e.offsetX;
      const width = activeMenu.offsetWidth;
      const height = activeMenu.offsetHeight;
      if (e.target === hoverMenuRefs.activeItem) {
        clearTimeout(this.hoverTimer);
        const { activeItem } = hoverMenuRefs;
        const offsetYTop = activeItem.offsetTop;
        const offsetYBottom = offsetYTop + activeItem.offsetHeight;
        hoverMenuRefs.hoverZone.innerHTML = `
            <path style="pointer-events: auto;" fill="transparent" d="M${offsetX} ${offsetYTop} L${width} 0 V${offsetYTop} Z" />
            <path style="pointer-events: auto;" fill="transparent" d="M${offsetX} ${offsetYBottom} L${width} ${height} V${offsetYBottom} Z" />
          `;
      } else {
        if (!this.hoverTimer) {
          this.hoverTimer = setTimeout(() => {
            hoverMenuRefs.hoverZone.innerHTML = "";
          }, hoverThreshold);
        }
      }
    };
    const menus = this._l(activeOptions, (menu, menuIndex) => {
      let isFlat = false;
      const menuID = `menu-${this.id}-${menuIndex}`;
      const ownsID = `menu-${this.id}-${menuIndex + 1}`;
      const items = this._l(menu, (item) => {
        const events = {
          on: {}
        };
        if (item.__IS__FLAT__OPTIONS) {
          isFlat = true;
        }
        if (!item.disabled) {
          events.on.keydown = (ev) => {
            const keyCode = ev.keyCode;
            if (Object.values(KEY_CODES).indexOf(keyCode) < 0) {
              return;
            }
            ev.stopPropagation();
            ev.preventDefault();
            const currentEle = ev.target;
            const parentEle = this.$refs.menus[menuIndex];
            const menuItemList = parentEle.querySelectorAll(`[tabindex='-1']`);
            const currentIndex = Array.prototype.indexOf.call(menuItemList, currentEle);
            let nextIndex, nextMenu;
            if ([KEY_CODES.UP, KEY_CODES.DOWN].indexOf(keyCode) > -1) {
              if (keyCode === KEY_CODES.UP) {
                nextIndex = currentIndex !== 0 ? currentIndex - 1 : currentIndex;
              } else if (keyCode === KEY_CODES.DOWN) {
                nextIndex = currentIndex !== menuItemList.length - 1 ? currentIndex + 1 : currentIndex;
              }
              menuItemList[nextIndex].focus();
            } else if (keyCode === KEY_CODES.LEFT) {
              if (menuIndex !== 0) {
                const previousMenu = this.$refs.menus[menuIndex - 1];
                previousMenu.querySelector("[aria-expanded=true]").focus();
              }
            } else if (keyCode === KEY_CODES.RIGHT) {
              if (item.children) {
                nextMenu = this.$refs.menus[menuIndex + 1];
                nextMenu.querySelectorAll(`[tabindex='-1']`)[0].focus();
              }
            } else if (keyCode === KEY_CODES.ENTER) {
              if (!item.children) {
                const id = currentEle.getAttribute("id");
                parentEle.setAttribute("aria-activedescendant", id);
                this.select(item, menuIndex);
                this.$nextTick(() => this.scrollMenu(this.$refs.menus[menuIndex]));
              }
            } else if (keyCode === KEY_CODES.TAB || keyCode === KEY_CODES.ESC) {
              this.$emit("closeInside");
            }
          };
          if (item.children) {
            const triggerEvent = {
              click: "click",
              hover: "mouseenter"
            }[expandTrigger];
            const triggerHandler = () => {
              this.activeItem(item, menuIndex);
              this.$nextTick(() => {
                this.scrollMenu(this.$refs.menus[menuIndex]);
                this.scrollMenu(this.$refs.menus[menuIndex + 1]);
              });
            };
            events.on[triggerEvent] = triggerHandler;
            events.on["mousedown"] = () => {
              this.clicking = true;
            };
            events.on["focus"] = () => {
              if (this.clicking) {
                this.clicking = false;
                return;
              }
              triggerHandler();
            };
          } else {
            events.on.click = () => {
              this.select(item, menuIndex);
              this.$nextTick(() => this.scrollMenu(this.$refs.menus[menuIndex]));
            };
          }
        }
        if (!item.disabled && !item.children) {
          itemID = `${menuID}-${itemIndex}`;
          itemIndex++;
        }
        const dataTip = item.disabled && item.tip ? item.tip : item.pureTextLabel || item.label;
        const checkboxValue = this.valueSet.has(item.fullPathKey);
        const halfBoxValue = this.halfStateValueSet.has(item.fullPathKey);
        const checkbox = h(SfCheckbox, {
          props: {
            value: checkboxValue,
            indeterminate: halfBoxValue,
            disabled: item.disabled
          },
          nativeOn: {
            click: (event) => {
              event.stopPropagation();
            }
          },
          on: {
            input: (v) => {
              this.selectMultiple(v, item);
            }
          }
        });
        return h(
          "li",
          {
            class: {
              [getPrefixedClassName("sf-cascader-menu__item")]: true,
              [getPrefixedClassName("sf-cascader-menu__item--extensible")]: item.children,
              [getPrefixedClassName("is-active")]: item.value === activeValue[menuIndex],
              [getPrefixedClassName("is-disabled")]: item.disabled
            },
            style: { width: menuWidth + "px" },
            ref: item.value === activeValue[menuIndex] ? "activeItem" : null,
            on: events.on,
            attrs: {
              tabindex: item.disabled ? null : -1,
              role: "menuitem",
              "data-tip": dataTip,
              "data-hint-offsets": "20, 0",
              "aria-haspopup": !!item.children,
              "aria-expanded": item.value === activeValue[menuIndex],
              id: itemID,
              utid: this.getFullUtid(`sf-cascader-menu__item-${item.value}`),
              "aria-owns": !item.children ? null : ownsID
            }
          },
          [
            this.multiple && item.value ? checkbox : null,
            item.label,
            h("i", {
              class: {
                "iconfont vtv-icon-arrow-right": item.children
              }
            })
          ]
        );
      });
      const menuStyle = {};
      if (isFlat || isEmpty) {
        menuStyle.width = this.menuWidth + "px";
      }
      const isHoveredMenu = expandTrigger === "hover" && activeValue.length - 1 === menuIndex;
      const hoverMenuEvent = {
        on: {}
      };
      if (isHoveredMenu) {
        hoverMenuEvent.on.mousemove = hoverMenuHandler;
        menuStyle.position = "relative";
      }
      const svg = h("svg", {
        ref: "hoverZone",
        style: {
          position: "absolute",
          top: 0,
          height: "100%",
          width: "100%",
          left: 0,
          pointerEvents: "none"
        }
      });
      return h(
        "div",
        {
          class: getPrefixedClassName("sf-cascader-menu-shell"),
          attrs: {
            size
          }
        },
        [
          h(
            "ul",
            {
              class: {
                [getPrefixedClassName("sf-cascader-menu")]: true,
                [getPrefixedClassName("sf-cascader-menu--flexible")]: isFlat
              },
              on: hoverMenuEvent.on,
              refInFor: true,
              ref: "menus",
              style: menuStyle,
              attrs: {
                role: "menu",
                id: menuID
              }
            },
            isEmpty ? [empty] : [items, isHoveredMenu ? svg : null]
          )
        ]
      );
    });
    let searchToolbar = null;
    if (this.filterable) {
      searchToolbar = h(
        "div",
        {
          class: getPrefixedClassName("sf-cascader-menu__search")
        },
        [
          h("i", {
            class: `${getPrefixedClassName("sf-cascader-menu__search-icon")} iconfont vtv-icon-comp-search`
          }),
          h("input", {
            ref: "searchInputRef",
            class: getPrefixedClassName("sf-cascader-menu__search-input"),
            style: {
              width: this.searchInputWidth
            },
            attrs: {
              type: "text",
              placeholder: $i("scp.vt_component.common.plugins.jquery.fixselect.view.search_placeholder")
            },
            on: {
              input: (e) => {
                const value = e.target.value;
                this.searchValue = value;
                this.$emit("search", value);
              }
            }
          })
        ]
      );
    }
    if (expandTrigger === "hover") {
      this.$nextTick(() => {
        const activeItem = this.$refs.activeItem;
        if (activeItem) {
          const activeMenu = activeItem.parentElement;
          const hoverZone = this.$refs.hoverZone;
          hoverMenuRefs = {
            activeMenu,
            activeItem,
            hoverZone
          };
        } else {
          hoverMenuRefs = {};
        }
      });
    }
    return h(
      "transition",
      {
        props: {
          name: "el-zoom-in-top"
        },
        on: {
          beforeEnter: this.handleMenuEnter,
          afterLeave: this.handleMenuLeave
        }
      },
      [
        h(
          "div",
          {
            class: [getPrefixedClassName("sf-cascader-menus"), getPrefixedClassName("sf-popper"), popperClass],
            ref: "wrapper",
            directives: [
              {
                name: "show",
                value: visible
              }
            ],
            on: {
              keydown: (e) => {
                this.$emit("keydown", e);
              }
            }
          },
          [
            searchToolbar,
            h(
              "div",
              {
                class: [getPrefixedClassName("sf-cascader-menus-wrap")]
              },
              menus
            )
          ]
        )
      ]
    );
  },
  mounted() {
    if (this.visible && this.$refs.searchInputRef) {
      this.$nextTick(() => this.$refs.searchInputRef.focus());
    }
  }
};
const { escapeRegex } = erStringUtils;
const DEFAULT_M_INPUT_WIDTH = 24;
const popperMixin = {
  props: {
    placement: {
      type: String,
      default: "bottom-start"
    },
    appendToBody: VuePopper.props.appendToBody,
    arrowOffset: VuePopper.props.arrowOffset,
    offset: VuePopper.props.offset,
    boundariesPadding: VuePopper.props.boundariesPadding,
    popperOptions: VuePopper.props.popperOptions,
    visibleArrow: VuePopper.props.visibleArrow
  },
  methods: VuePopper.methods,
  data: VuePopper.data,
  beforeDestroy: VuePopper.beforeDestroy
};
var script = {
  name: componentName.cascader,
  componentName: componentName.cascader,
  directives: {
    clickoutside: vClickoutside,
    "on-show": vOnShow
  },
  components: {
    SfInput,
    SfSpace,
    SfTag
  },
  mixins: [popperMixin, EmitterMixin, FormSizeMixin, FormFieldMixin, MultipleSelectMixin],
  props: {
    options: {
      type: Array,
      required: true
    },
    props: {
      type: Object,
      default() {
        return {
          children: "children",
          label: "label",
          value: "value",
          disabled: "disabled"
        };
      },
      validator(val) {
        const propsAttrs = ["children", "label", "value", "disabled"];
        if (typeof val !== "object") {
          return false;
        }
        for (const attr of propsAttrs) {
          if (val.hasOwnProperty(attr) && typeof val[attr] !== "string") {
            return false;
          }
        }
        return true;
      }
    },
    multiple: {
      type: Boolean,
      default: false
    },
    value: {
      type: Array,
      default() {
        return [];
      }
    },
    separator: {
      type: String,
      default: "/"
    },
    allowBlank: {
      type: Boolean,
      default: false
    },
    placeholder: {
      type: String,
      default() {
        return "";
      }
    },
    beforeSelect: {
      type: Function,
      default: () => true
    },
    disabled: Boolean,
    clearable: {
      type: Boolean,
      default: false
    },
    changeOnSelect: Boolean,
    popperClass: String,
    expandTrigger: {
      type: String,
      default: "click",
      validator(value) {
        return ["click", "hover"].includes(value);
      }
    },
    filterable: {
      type: Boolean,
      default: false
    },
    size: {
      type: String,
      validator(value) {
        return ["small"].includes(value);
      }
    },
    showAllLevels: {
      type: Boolean,
      default: true
    },
    debounce: {
      type: Number,
      default: 300
    },
    beforeFilter: {
      type: Function,
      default: () => () => {
      }
    },
    hoverThreshold: {
      type: Number,
      default: 500
    },
    width: {
      type: [String, Number],
      default: "100%"
    },
    autoTrim: {
      type: Boolean,
      default: false
    },
    multipleDisplayType: {
      validator(val) {
        return ["tag", "text"].includes(val);
      },
      default: "tag"
    }
  },
  data() {
    return {
      currentValue: this.value || [],
      menu: null,
      debouncedInputChange() {
      },
      menuVisible: false,
      inputHover: false,
      inputValue: "",
      mInputValue: "",
      flatOptions: null,
      showLabelTip: true,
      labelStyle: null,
      mInputFocusStatus: false,
      mInputWidth: DEFAULT_M_INPUT_WIDTH,
      isEmpty: false
    };
  },
  computed: {
    cascaderWidth() {
      const WIDTH_VALUE = this.width;
      if (typeof WIDTH_VALUE === "number" || !isNaN(Number(WIDTH_VALUE))) {
        return `${WIDTH_VALUE}px`;
      }
      return WIDTH_VALUE;
    },
    labelKey() {
      return this.props.label || "label";
    },
    valueKey() {
      return this.props.value || "value";
    },
    childrenKey() {
      return this.props.children || "children";
    },
    currentLabels() {
      const { currentValue } = this;
      if (this.multiple) {
        return currentValue.map(this.valueToLabel);
      }
      return this.valueToLabel(currentValue);
    },
    isCheckedEmptyLabel() {
      if (this.multiple) {
        return this.mInputValue || this.currentLabels.length > 0;
      } else {
        return this.currentLabels.labels.length > 0;
      }
    },
    cascaderSize() {
      return this.currentSize;
    },
    disabledStatus() {
      return this.disabled;
    },
    visibleTags() {
      var _a, _b;
      if (!this.multiple) {
        return;
      }
      return ((_b = (_a = this.currentLabels) == null ? void 0 : _a.slice) == null ? void 0 : _b.call(_a, 0, this.safeTagNumber)) || [];
    },
    invisibleTagsCount() {
      var _a, _b;
      if (!this.multiple || !((_a = this.currentLabels) == null ? void 0 : _a.length)) {
        return 0;
      }
      return ((_b = this.currentLabels) == null ? void 0 : _b.length) - this.safeTagNumber;
    },
    noPlaceholder() {
      return { text: "" };
    },
    tagContainerRefName() {
      return "tagContainer";
    },
    tagNumberCeil() {
      var _a, _b;
      return (_b = (_a = this.currentValue) == null ? void 0 : _a.length) != null ? _b : 0;
    },
    depth() {
      return calculateDepth(this.options, this.childrenKey);
    }
  },
  watch: {
    menuVisible(value) {
      this.$refs.input.$refs.input.setAttribute("aria-expanded", value);
      value ? this.showMenu() : this.hideMenu();
    },
    value(value) {
      this.currentValue = value;
    },
    mInputValue() {
      this.safeTagNumber = 0;
      this.mInputWidth = DEFAULT_M_INPUT_WIDTH;
      this.$nextTick(() => {
        const { scrollWidth } = this.$refs.mInputRef;
        this.mInputWidth = scrollWidth;
        this.$nextTick(() => {
          this.calcMaxSafeTagNumber();
          this.calcMaxMInputWidth();
        });
      });
    },
    currentLabels: {
      handler(value, oldVal) {
        let inputLabel = "";
        if (this.multiple) {
          inputLabel = (this.showAllLevels ? value.map((i) => i.labels.join("/")) : value.map((i) => i.labels[i.labels.length - 1])).join(",");
          if (!isEqual(value, oldVal)) {
            this.safeTagNumber = 0;
            if (this.filterable) {
              this.mInputWidth = DEFAULT_M_INPUT_WIDTH;
            }
            this.$nextTick(() => this.calcMaxSafeTagNumber());
          }
        } else {
          inputLabel = this.showAllLevels ? value.labels.join("/") : value.labels[value.labels.length - 1];
        }
        this.$refs.input.$refs.input.setAttribute("value", inputLabel);
      }
    },
    options: {
      deep: true,
      handler(value) {
        if (!this.menu) {
          this.initMenu();
        }
        this.flatOptions = this.flattenOptions(this.options);
        this.menu.options = value;
        this.menu.originOptions = this.options;
      }
    },
    cascaderWidth() {
      this.$nextTick(() => {
        this.menu.menuWidth = this.getMenuWidth();
      });
    }
  },
  created() {
    this.debouncedInputChange = debounce((value) => {
      const before = this.beforeFilter(value);
      if (before && before.then) {
        this.menu.options = [
          {
            __IS__FLAT__OPTIONS: true,
            label: "",
            value: "",
            disabled: true
          }
        ];
        before.then(() => {
          this.$nextTick(() => {
            this.handleInputChange(value);
          });
        });
      } else if (before !== false) {
        this.$nextTick(() => {
          this.handleInputChange(value);
          this.updateMenuWidth();
        });
      }
    }, this.debounce);
  },
  mounted() {
    this.flatOptions = this.flattenOptions(this.options);
  },
  beforeDestroy() {
    if (this.menu) {
      this.menu.$destroy();
      this.menu = null;
    }
  },
  methods: {
    getPrefixedClassName,
    getFullUtid(utidBase) {
      return this.$attrs.utid ? `${this.$attrs.utid}-${utidBase}` : utidBase;
    },
    checkValidateEnabled(enable) {
      return !this.disabledStatus && enable;
    },
    emitCascaderBlur() {
      this.validate();
    },
    processRule(rule) {
      rule.getFieldValue = () => this.currentValue.length ? this.currentValue : "";
      return rule;
    },
    onValidate(ret) {
      this.setValidateState(ret);
      this.showLabelTip = ret === true;
    },
    getMenuWidth(reset = false) {
      let menuWidth;
      const refWidth = this.$refs.reference.clientWidth;
      if (!reset && (this.menu.searchValue || this.isEmpty || !this.options.length)) {
        menuWidth = refWidth;
      } else {
        menuWidth = Math.floor(refWidth / this.depth);
      }
      return Math.max(160, menuWidth) - 2;
    },
    initMenu() {
      const Vue = this.constructor.super;
      const SfCascaderMenuConstructor = Vue.extend(SfCascaderMenu);
      this.menu = new SfCascaderMenuConstructor({
        propsData: {
          filterable: this.filterable
        }
      }).$mount();
      this.menu.size = this.cascaderSize || "normal";
      this.menu.options = this.options;
      this.menu.originOptions = this.options;
      this.menu.props = this.props;
      this.menu.expandTrigger = this.expandTrigger;
      this.menu.changeOnSelect = this.changeOnSelect;
      this.menu.popperClass = this.popperClass;
      this.menu.hoverThreshold = this.hoverThreshold;
      this.menu.multiple = this.multiple;
      this.menu.placeholder = this.placeholder;
      this.menu.menuWidth = this.getMenuWidth();
      this.popperElm = this.menu.$el;
      this.menu.$refs.menus[0].setAttribute("id", `cascader-menu-${this.id}`);
      this.menu.$on("pick", this.handlePick);
      this.menu.$on("pickMulti", this.handleMultiPick);
      this.menu.$on("activeItemChange", this.handleActiveItemChange);
      this.menu.$on("menuLeave", this.doDestroy);
      this.menu.$on("closeInside", this.handleClickoutside);
      this.menu.$on("search", this.debouncedInputChange);
      this.menu.$on("keydown", this.handleKeydown);
    },
    updateMenuWidth() {
      this.menu.menuWidth = this.getMenuWidth();
    },
    showMenu() {
      if (!this.menu) {
        this.initMenu();
      }
      this.menu.value = this.currentValue;
      this.menu.visible = true;
      this.menu.options = this.options;
      this.menu.originOptions = this.options;
      this.$nextTick(() => {
        this.updatePopper();
      });
    },
    hideMenu() {
      this.inputValue = "";
      this.mInputValue = "";
      this.menu.visible = false;
      this.$refs.input.blur();
      if (this.depth) {
        this.menu.menuWidth = this.getMenuWidth(true);
      }
      this.emitCascaderBlur();
    },
    handleActiveItemChange(value) {
      this.$nextTick(() => {
        this.updatePopper();
      });
      this.$emit("active-item-change", value);
    },
    handleKeydown(e) {
      const keyCode = e.keyCode;
      if (keyCode === 40) {
        this.menuVisible = true;
        setTimeout(() => {
          const firstMenu = this.popperElm.querySelectorAll(".sf-cascader-menu")[0];
          firstMenu.querySelectorAll(`[tabindex='-1']`)[0].focus();
        });
        e.stopPropagation();
        e.preventDefault();
      } else if (keyCode === 27 || keyCode === 9) {
        this.inputValue = "";
        if (this.menu) {
          this.menu.visible = false;
        }
      }
    },
    async handleBeforeSelect(value) {
      if (!this.beforeSelect) {
        return true;
      }
      return await this.beforeSelect(value);
    },
    async handlePick(value, close = true) {
      const beforeSelectRes = await this.handleBeforeSelect(value);
      if (!beforeSelectRes) {
        return;
      }
      const oldValue = this.currentValue;
      this.currentValue = value;
      this.$emit("input", value);
      this.$emit("change", value, oldValue);
      if (close) {
        this.menuVisible = false;
      } else {
        this.$nextTick(this.updatePopper);
      }
    },
    handleMultiPick(v) {
      this.handlePick(v, false);
    },
    handleInputChange(value) {
      if (!this.menuVisible) {
        return;
      }
      const flatOptions = this.flatOptions;
      if (!value) {
        this.menu.options = this.options;
        this.isEmpty = false;
        this.$nextTick(this.updatePopper);
        return;
      }
      let filteredFlatOptions = flatOptions.filter((optionsStack) => {
        return optionsStack.some((option) => new RegExp(escapeRegex(value), "i").test(option[this.labelKey]));
      });
      if (filteredFlatOptions.length > 0) {
        filteredFlatOptions = filteredFlatOptions.map((optionStack) => {
          const { pureTextLabel } = this.renderFilteredOptionLabel(value, optionStack);
          return {
            __IS__FLAT__OPTIONS: true,
            value: optionStack.map((item) => item[this.valueKey]),
            label: pureTextLabel,
            pureTextLabel
          };
        });
        this.isEmpty = false;
      } else {
        this.isEmpty = true;
        filteredFlatOptions = [
          {
            __IS__FLAT__OPTIONS: true,
            label: $i("scp.vt_component.sf_widget.packages.cascader.no_match"),
            value: "",
            disabled: true
          }
        ];
      }
      this.menu.options = filteredFlatOptions;
      this.$nextTick(this.updatePopper);
    },
    renderFilteredOptionLabel(inputValue, optionsStack) {
      const pureTextLabel = [];
      const styledLabel = optionsStack.map((option, index) => {
        const label = option[this.labelKey];
        pureTextLabel.push(label);
        const keywordIndex = label.toLowerCase().indexOf(inputValue.toLowerCase());
        const labelPart = label.slice(keywordIndex, inputValue.length + keywordIndex);
        const node = keywordIndex > -1 ? this.highlightKeyword(label, labelPart) : label;
        return index === 0 ? node : [" / ", node];
      });
      return { styledLabel, pureTextLabel: pureTextLabel.join(" / ") };
    },
    highlightKeyword(label, keyword) {
      const h = this._c;
      return label.split(keyword).map(
        (node, index) => index === 0 ? node : [
          h(
            "span",
            {
              class: {
                [getPrefixedClassName("sf-cascader-menu__item__keyword")]: true
              }
            },
            [this._v(keyword)]
          ),
          node
        ]
      );
    },
    flattenOptions(options, ancestor = []) {
      let flatOptions = [];
      options.forEach((option) => {
        const optionsStack = ancestor.concat(option);
        if (!option[this.childrenKey]) {
          flatOptions.push(optionsStack);
        } else {
          if (this.changeOnSelect) {
            flatOptions.push(optionsStack);
          }
          flatOptions = flatOptions.concat(this.flattenOptions(option[this.childrenKey], optionsStack));
        }
      });
      return flatOptions;
    },
    clearValue(ev) {
      ev.stopPropagation();
      this.handlePick([], true);
      this.emitCascaderBlur();
    },
    handleClickoutside() {
      this.mInputFocusStatus = false;
      this.menuVisible = false;
    },
    handleClick() {
      if (this.disabledStatus) {
        return;
      }
      this.mInputFocusStatus = true;
      this.menuVisible = !this.menuVisible;
    },
    handleFocus(event) {
      this.$emit("focus", event);
    },
    handleMInputFocus(e) {
      this.mInputFocusStatus = true;
      this.handleFocus(e);
    },
    handleBlur(event) {
      this.$emit("blur", event);
    },
    handleMInputBlur(e) {
      this.mInputFocusStatus = false;
      this.handleBlur(e);
    },
    checkIsDisabled() {
      return this.disabledStatus;
    },
    syncPrefixSpace(param) {
      const { paddingLeft } = param;
      if (paddingLeft) {
        this.labelStyle = { paddingLeft };
      }
    },
    calcMaxMInputWidth() {
      const calcFn = () => {
        const isDanger2 = this.isTagOverflow();
        if (!isDanger2) {
          this.mInputWidth = this.mInputWidth + 1;
          this.$nextTick(() => calcFn());
        } else {
          this.mInputWidth = Math.max(this.mInputWidth - 1, DEFAULT_M_INPUT_WIDTH);
        }
      };
      const isDanger = this.isTagOverflow();
      if (!isDanger) {
        if (this.safeTagNumber + 1 > this.currentLabels.length) {
          calcFn();
        }
      } else {
        if (this.safeTagNumber === 0) {
          this.mInputWidth = DEFAULT_M_INPUT_WIDTH;
        }
        this.$nextTick(() => calcFn());
      }
    },
    valueToLabel(v) {
      let { options } = this;
      const labels = [];
      let valueIndex = 0;
      let disabled = false;
      for (const value of v) {
        const targetOption = options && options.find((option) => option[this.valueKey] === value);
        if (targetOption) {
          valueIndex++;
          labels.push(targetOption[this.labelKey]);
          options = targetOption[this.childrenKey];
          if (targetOption.disabled) {
            disabled = targetOption.disabled;
          }
        } else {
          break;
        }
      }
      const currentValueLen = v.length;
      for (; valueIndex < currentValueLen; valueIndex++) {
        labels.push(v[valueIndex]);
      }
      return {
        value: v,
        labels,
        presentText: this.showAllLevels ? labels.join(this.separator) : labels[labels.length - 1],
        disabled
      };
    },
    cleanSignChecked(v) {
      const newValue = this.currentValue.filter((item) => !item.every((val, index) => val === v[index]));
      if (this.menu) {
        this.menu.value = newValue;
      }
      this.handleMultiPick(newValue);
    }
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _obj, _obj$1, _obj$2;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "span",
    _vm._b(
      {
        directives: [
          {
            name: "clickoutside",
            rawName: "v-clickoutside",
            value: _vm.handleClickoutside,
            expression: "handleClickoutside"
          }
        ],
        ref: "reference",
        class: [
          _vm.getPrefixedClassName("sf-cascader"),
          (_obj = {}, _obj[_vm.getPrefixedClassName("is-opened")] = _vm.menuVisible, _obj[_vm.getPrefixedClassName("is-disabled")] = _vm.disabledStatus, _obj),
          _vm.getPrefixedClassName(
            _vm.cascaderSize ? "sf-cascader--" + _vm.cascaderSize : ""
          ),
          _vm.invalidCls
        ],
        style: { width: _vm.cascaderWidth },
        attrs: { cascaderSize: _vm.cascaderSize ? _vm.cascaderSize : "normal" },
        on: {
          click: _vm.handleClick,
          mouseenter: function($event) {
            _vm.inputHover = true;
          },
          focus: function($event) {
            _vm.inputHover = true;
          },
          mouseleave: function($event) {
            _vm.inputHover = false;
          },
          blur: function($event) {
            _vm.inputHover = false;
          }
        }
      },
      "span",
      _vm.validateHintOptions,
      false
    ),
    [
      _c(
        "sf-input",
        {
          ref: "input",
          class: (_obj$1 = {}, _obj$1[_vm.getPrefixedClassName("sf-cascader__m-input-focus")] = _vm.mInputFocusStatus, _obj$1),
          attrs: {
            readonly: true,
            placeholder: _vm.isCheckedEmptyLabel ? _vm.noPlaceholder : _vm.placeholder,
            "allow-blank": _vm.allowBlank,
            "validate-event": false,
            size: _vm.size,
            "add-to-form": false,
            disabled: _vm.disabledStatus
          },
          on: {
            focus: _vm.handleFocus,
            blur: _vm.handleBlur,
            "after-calc-slot-fix": _vm.syncPrefixSpace
          },
          model: {
            value: _vm.inputValue,
            callback: function($$v) {
              _vm.inputValue = $$v;
            },
            expression: "inputValue"
          }
        },
        [
          _c("template", { slot: "suffix" }, [
            _vm.clearable && _vm.inputHover && _vm.isCheckedEmptyLabel && !_vm.disabledStatus ? _c("i", {
              key: "1",
              class: [
                "iconfont vtv-icon-comp-tip-close",
                _vm.getPrefixedClassName("sf-cascader_icon"),
                _vm.getPrefixedClassName("sf-cascader__clear-icon")
              ],
              on: { click: _vm.clearValue }
            }) : _c("i", {
              key: "2",
              staticClass: "iconfont",
              class: (_obj$2 = {}, _obj$2[_vm.getPrefixedClassName("sf-cascader_icon")] = true, _obj$2["vtv-icon-comp-angle-down"] = !_vm.menuVisible, _obj$2["vtv-icon-comp-angle-up"] = _vm.menuVisible, _obj$2[_vm.getPrefixedClassName("sf-cascader_icon_disabled")] = _vm.disabledStatus, _obj$2)
            })
          ]),
          _vm._v(" "),
          _vm._t("prefix", null, { slot: "prefix" })
        ],
        2
      ),
      _vm._v(" "),
      !_vm.multiple ? [
        _c(
          "span",
          {
            directives: [
              {
                name: "show",
                rawName: "v-show",
                value: _vm.inputValue === "",
                expression: "inputValue === ''"
              }
            ],
            class: _vm.getPrefixedClassName("sf-cascader__label"),
            style: _vm.labelStyle
          },
          [
            _c(
              "span",
              {
                class: _vm.getPrefixedClassName("sf-cascader__label-inner"),
                attrs: {
                  "data-tip": _vm.showLabelTip ? _vm.currentLabels.labels.join(_vm.separator) : false
                }
              },
              [
                _vm._v(
                  "\n        " + _vm._s(_vm.currentLabels.presentText) + "\n      "
                )
              ]
            )
          ]
        )
      ] : _vm._e(),
      _vm._v(" "),
      _vm.multiple ? _c("div", { class: _vm.getPrefixedClassName("sf-cascader__label") }, [
        _c(
          "div",
          {
            ref: "tagContainer",
            class: _vm.getPrefixedClassName(
              "sf-cascader__multiple-container"
            )
          },
          [
            _c(
              "sf-space",
              {
                directives: [
                  {
                    name: "on-show",
                    rawName: "v-on-show",
                    value: _vm.tagController,
                    expression: "tagController"
                  }
                ],
                attrs: { size: 2, inline: "", align: "center" }
              },
              [
                _c(
                  "sf-space",
                  { attrs: { size: 2, inline: "", align: "center" } },
                  [
                    _vm._l(_vm.visibleTags, function(tag) {
                      return _c(
                        "sf-tag",
                        {
                          key: "sf-cascader__input-tag-" + tag.value.join("-"),
                          class: _vm.getPrefixedClassName("sf-cascader__tag"),
                          attrs: {
                            utid: _vm.getFullUtid(
                              "sf-cascader__input-tag-" + tag.value.join("-")
                            ),
                            closeable: !_vm.disabledStatus && !tag.disabled
                          },
                          on: {
                            close: function($event) {
                              return _vm.cleanSignChecked(tag.value);
                            }
                          }
                        },
                        [_c("span", [_vm._v(_vm._s(tag.presentText))])]
                      );
                    }),
                    _vm._v(" "),
                    _vm.invisibleTagsCount > 0 ? _c(
                      "sf-tag",
                      {
                        class: _vm.getPrefixedClassName("sf-cascader__tag")
                      },
                      [
                        _c("span", [
                          _vm._v(
                            "+" + _vm._s(_vm.invisibleTagsCount) + "..."
                          )
                        ])
                      ]
                    ) : _vm._e()
                  ],
                  2
                ),
                _vm._v(" "),
                _c("input", {
                  directives: [
                    {
                      name: "show",
                      rawName: "v-show",
                      value: _vm.filterable,
                      expression: "filterable"
                    },
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.mInputValue,
                      expression: "mInputValue"
                    }
                  ],
                  ref: "mInputRef",
                  class: _vm.getPrefixedClassName("sf-cascader__m-input"),
                  style: { width: _vm.mInputWidth + "px" },
                  attrs: { readonly: !_vm.filterable, type: "text" },
                  domProps: { value: _vm.mInputValue },
                  on: {
                    input: [
                      function($event) {
                        if ($event.target.composing) {
                          return;
                        }
                        _vm.mInputValue = $event.target.value;
                      },
                      _vm.debouncedInputChange
                    ],
                    focus: _vm.handleMInputFocus,
                    blur: _vm.handleMInputBlur
                  }
                })
              ],
              1
            )
          ],
          1
        )
      ]) : _vm._e()
    ],
    2
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__ as SfCascader };
