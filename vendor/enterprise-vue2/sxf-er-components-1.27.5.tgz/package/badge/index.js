import { componentName } from '@sxf/er-components/_const';
import { getPrefixedClassName } from '@sxf/er-feature';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
var script$1 = {
  name: componentName.badge,
  componentName: componentName.badge,
  computed: {
    rootCls() {
      return getPrefixedClassName("sf-badge");
    },
    contentCls() {
      return getPrefixedClassName("sf-badge_content");
    }
  }
};
const __vue_script__$1 = script$1;
var __vue_render__$1 = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c("div", { class: _vm.rootCls }, [
    _vm.$slots.default ? _c("span", { class: _vm.contentCls }, [_vm._t("default")], 2) : _vm._e()
  ]);
};
var __vue_staticRenderFns__$1 = [];
__vue_render__$1._withStripped = true;
const __vue_inject_styles__$1 = void 0;
const __vue_scope_id__$1 = void 0;
const __vue_module_identifier__$1 = void 0;
const __vue_is_functional_template__$1 = false;
const __vue_component__$1 = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__$1, staticRenderFns: __vue_staticRenderFns__$1 },
  __vue_inject_styles__$1,
  __vue_script__$1,
  __vue_scope_id__$1,
  __vue_is_functional_template__$1,
  __vue_module_identifier__$1,
  false,
  void 0,
  void 0,
  void 0
);
var script = {
  name: componentName.numberBadge,
  componentName: componentName.numberBadge,
  components: {
    SfBadge: __vue_component__$1
  },
  props: {
    min: {
      type: Number,
      default: 0
    },
    max: {
      type: Number,
      default: Infinity
    },
    value: {
      type: Number,
      default: 0
    },
    autoHide: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      active: true,
      currentValue: Number(this.value)
    };
  },
  computed: {
    currentMax() {
      return Number(this.max);
    },
    currentMin() {
      return Number(this.min);
    },
    num() {
      let result = Math.max(this.currentValue, this.currentMin);
      if (result > this.currentMax) {
        result = this.currentMax + "+";
      }
      return result;
    }
  },
  watch: {
    value(v) {
      this.currentValue = Number(v);
    }
  },
  mounted() {
    this._autoHide();
    this.$watch(
      function() {
        return [this.autoHide, this.currentValue, this.currentMin];
      },
      this._autoHide,
      {
        deep: true
      }
    );
  },
  methods: {
    show() {
      this.active = true;
    },
    hide() {
      this.active = false;
    },
    _autoHide() {
      if (this.autoHide && this.num <= this.currentMin) {
        this.hide();
      } else {
        this.show();
      }
    }
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "sf-badge",
    {
      directives: [
        {
          name: "show",
          rawName: "v-show",
          value: _vm.active,
          expression: "active"
        }
      ]
    },
    [
      _vm._t("default", [_vm._v("\n    " + _vm._s(_vm.num) + "\n  ")], {
        value: _vm.currentValue,
        text: _vm.num,
        min: _vm.currentMin,
        max: _vm.currentMax
      })
    ],
    2
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__$1 as SfBadge, __vue_component__ as SfNumberBadge };
