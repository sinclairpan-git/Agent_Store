import { componentName } from '@sxf/er-components/_const';
import { getPrefixedClassName } from '@sxf/er-feature';
import __vue_normalize__ from 'vue-runtime-helpers/dist/normalize-component.mjs';
var script = {
  name: componentName.switch,
  componentName: componentName.switch,
  props: {
    activeTextShowType: {
      type: String,
      default: ""
    },
    size: {
      type: String,
      default: ""
    },
    value: {
      type: [Boolean, String, Number],
      default: false
    },
    disabled: {
      type: Boolean,
      default: false
    },
    width: {
      type: Number,
      default: 32
    },
    activeIconClass: {
      type: String,
      default: ""
    },
    inactiveIconClass: {
      type: String,
      default: ""
    },
    activeChildrenText: String,
    inactiveChildrenText: String,
    activeText: String,
    inactiveText: String,
    activeColor: {
      type: String,
      default: ""
    },
    inactiveColor: {
      type: String,
      default: ""
    },
    activeValue: {
      type: [Boolean, String, Number],
      default: true
    },
    inactiveValue: {
      type: [Boolean, String, Number],
      default: false
    },
    name: {
      type: String,
      default: ""
    },
    id: String,
    isTextSwitch: {
      type: Boolean,
      default: false
    },
    textSwitchTheme: {
      type: String,
      default: "dark-theme"
    },
    textSwitchText: {
      type: Array,
      default: () => []
    },
    showTextSwitchTip: {
      type: Function,
      default: () => ""
    }
  },
  data() {
    return {
      coreWidth: this.width
    };
  },
  computed: {
    checked() {
      return this.value === this.activeValue;
    },
    switchDisabled() {
      return this.disabled;
    },
    textSwitchItems() {
      const textSwitchText = this.textSwitchText, leftText = textSwitchText[0] || "", rightText = textSwitchText[1] || "";
      return [
        {
          id: "left",
          isActive: !this.checked,
          text: leftText,
          title: this.checked ? this.showTextSwitchTip(leftText) : ""
        },
        {
          id: "right",
          isActive: this.checked,
          text: rightText,
          title: this.checked ? "" : this.showTextSwitchTip(rightText)
        }
      ];
    },
    switchSizeCls() {
      return this.size ? `el-switch-${this.size}` : "";
    }
  },
  watch: {
    checked() {
      this.$refs.input.checked = this.checked;
      if (this.activeColor || this.inactiveColor) {
        this.setBackgroundColor();
      }
    }
  },
  created() {
    if (!~[this.activeValue, this.inactiveValue].indexOf(this.value)) {
      this.$emit("input", this.inactiveValue);
    }
  },
  mounted() {
    this.coreWidth = this.width || 40;
    if (this.activeColor || this.inactiveColor) {
      this.setBackgroundColor();
    }
    this.$refs.input.checked = this.checked;
  },
  methods: {
    handleChange() {
      this.$emit("input", !this.checked ? this.activeValue : this.inactiveValue);
      this.$emit("change", !this.checked ? this.activeValue : this.inactiveValue);
      this.$nextTick(() => {
        var _a;
        const inputEl = (_a = this == null ? void 0 : this.$refs) == null ? void 0 : _a.input;
        if (inputEl) {
          inputEl.checked = this.checked;
        }
      });
    },
    setBackgroundColor() {
      const newColor = this.checked ? this.activeColor : this.inactiveColor;
      this.$refs.core.style.borderColor = newColor;
      this.$refs.core.style.backgroundColor = newColor;
    },
    switchValue() {
      !this.switchDisabled && this.handleChange();
    },
    getPrefixedClassName
  }
};
const __vue_script__ = script;
var __vue_render__ = function() {
  var _obj;
  var _vm = this;
  var _h = _vm.$createElement;
  var _c = _vm._self._c || _h;
  return _c(
    "div",
    {
      class: [
        _vm.getPrefixedClassName("el-switch"),
        _vm.switchSizeCls,
        (_obj = {}, _obj[_vm.getPrefixedClassName("is-disabled")] = _vm.switchDisabled, _obj[_vm.getPrefixedClassName("is-checked")] = _vm.checked, _obj)
      ],
      attrs: {
        role: "switch",
        "aria-checked": _vm.checked,
        "aria-disabled": _vm.switchDisabled
      },
      on: { click: _vm.switchValue }
    },
    [
      _c("input", {
        ref: "input",
        class: _vm.getPrefixedClassName("el-switch__input"),
        attrs: {
          id: _vm.id,
          type: "checkbox",
          "style-key": "checkbox",
          name: _vm.name,
          "true-value": _vm.activeValue,
          "false-value": _vm.inactiveValue,
          disabled: _vm.switchDisabled
        },
        on: {
          change: _vm.handleChange,
          keydown: function($event) {
            if (!$event.type.indexOf("key") && _vm._k($event.keyCode, "enter", 13, $event.key, "Enter")) {
              return null;
            }
            return _vm.switchValue($event);
          }
        }
      }),
      _vm._v(" "),
      (_vm.inactiveIconClass || _vm.inactiveText) && _vm.activeTextShowType === "both" ? _c(
        "span",
        {
          class: [
            _vm.getPrefixedClassName("el-switch__label"),
            _vm.getPrefixedClassName("el-switch__label--left"),
            !_vm.checked ? _vm.getPrefixedClassName("is-active") : ""
          ]
        },
        [
          _vm.inactiveIconClass ? _c("i", { class: [_vm.inactiveIconClass] }) : _vm._e(),
          _vm._v(" "),
          !_vm.inactiveIconClass && _vm.inactiveText ? _c("span", { attrs: { "aria-hidden": _vm.checked } }, [
            _vm._v(_vm._s(_vm.inactiveText))
          ]) : _vm._e()
        ]
      ) : _vm._e(),
      _vm._v(" "),
      _vm.isTextSwitch ? [
        _c(
          "span",
          {
            ref: "core",
            class: [
              _vm.getPrefixedClassName("el-text-switch-core"),
              _vm.getPrefixedClassName(_vm.textSwitchTheme)
            ]
          },
          _vm._l(_vm.textSwitchItems, function(item) {
            var _obj2;
            return _c(
              "span",
              {
                key: item.id,
                class: [
                  _vm.getPrefixedClassName("el-text-switch-inner"),
                  _vm.getPrefixedClassName(
                    "el-text-switch-inner__" + item.id
                  ),
                  (_obj2 = {}, _obj2[_vm.getPrefixedClassName("is-active")] = item.isActive, _obj2)
                ],
                attrs: { title: item.title }
              },
              [_vm._v("\n        " + _vm._s(item.text) + "\n      ")]
            );
          }),
          0
        )
      ] : [
        _c(
          "span",
          {
            ref: "core",
            class: _vm.getPrefixedClassName("el-switch__core"),
            style: { "min-width": _vm.coreWidth + "px" }
          },
          [
            _vm.$slots.inner || _vm.$scopedSlots.inner || _vm.activeChildrenText || _vm.inactiveChildrenText ? _c(
              "span",
              { class: _vm.getPrefixedClassName("el-switch__inner") },
              [
                _vm._t(
                  "inner",
                  [
                    _vm._v(
                      "\n          " + _vm._s(
                        _vm.checked ? _vm.activeChildrenText : _vm.inactiveChildrenText
                      ) + "\n        "
                    )
                  ],
                  { checked: _vm.checked }
                )
              ],
              2
            ) : _vm._e()
          ]
        )
      ],
      _vm._v(" "),
      (_vm.activeIconClass || _vm.activeText) && _vm.activeTextShowType === "both" ? _c(
        "span",
        {
          class: [
            _vm.getPrefixedClassName("el-switch__label"),
            _vm.getPrefixedClassName("el-switch__label--right"),
            _vm.checked ? _vm.getPrefixedClassName("is-active") : ""
          ]
        },
        [
          _vm.activeIconClass ? _c("i", { class: [_vm.activeIconClass] }) : _vm._e(),
          _vm._v(" "),
          !_vm.activeIconClass && _vm.activeText ? _c("span", { attrs: { "aria-hidden": !_vm.checked } }, [
            _vm._v(_vm._s(_vm.activeText))
          ]) : _vm._e()
        ]
      ) : _vm._e(),
      _vm._v(" "),
      !_vm.activeTextShowType ? _c(
        "span",
        {
          class: [
            _vm.getPrefixedClassName("el-switch__label"),
            _vm.getPrefixedClassName("el-switch__label--right")
          ]
        },
        [
          _vm._v(
            "\n    " + _vm._s(_vm.checked ? _vm.activeText : _vm.inactiveText) + "\n  "
          )
        ]
      ) : _vm._e()
    ],
    2
  );
};
var __vue_staticRenderFns__ = [];
__vue_render__._withStripped = true;
const __vue_inject_styles__ = void 0;
const __vue_scope_id__ = void 0;
const __vue_module_identifier__ = void 0;
const __vue_is_functional_template__ = false;
const __vue_component__ = /* @__PURE__ */ __vue_normalize__(
  { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
  __vue_inject_styles__,
  __vue_script__,
  __vue_scope_id__,
  __vue_is_functional_template__,
  __vue_module_identifier__,
  false,
  void 0,
  void 0,
  void 0
);
export { __vue_component__ as SfSwitch };
