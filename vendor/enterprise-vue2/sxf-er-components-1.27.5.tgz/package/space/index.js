import { componentName } from '@sxf/er-components/_const';
import { getPrefixedClassName } from '@sxf/er-feature';
const spaceSize = {
  small: 8,
  middle: 16,
  large: 24
};
function isEmptyElement(c) {
  return !(c.tag || c.text && c.text.trim() !== "");
}
function filterEmpty(children = []) {
  return children.filter((c) => !isEmptyElement(c));
}
var Space = {
  name: componentName.space,
  componentName: componentName.space,
  props: {
    size: {
      type: [String, Number],
      default: "small",
      validator: (val) => {
        if (typeof val === "number") {
          return true;
        }
        return ["small", "middle", "large"].includes(val);
      }
    },
    inline: {
      type: Boolean,
      default: false
    },
    direction: {
      type: String,
      default: "horizontal",
      validator: (val) => {
        return ["horizontal", "vertical"].includes(val);
      }
    },
    align: {
      type: String,
      default: "",
      validator: (val) => {
        return ["", "start", "end", "center", "baseline"].includes(val);
      }
    }
  },
  render(createElem) {
    const { default: children } = this.$slots;
    const { align, size, direction, inline } = this.$props;
    const items = filterEmpty(children);
    const len = items.length;
    if (len === 0) {
      return null;
    }
    const mergedAlign = !align && direction === "horizontal" ? "center" : align;
    const classes = {
      [getPrefixedClassName("sf-space")]: true,
      [getPrefixedClassName("sf-space-inline")]: inline,
      [getPrefixedClassName(`sf-space-${direction}`)]: true,
      [getPrefixedClassName(`sf-space-align-${mergedAlign}`)]: mergedAlign
    };
    function getItemStyles(i) {
      if (i === len - 1) {
        return {};
      }
      const dirKey = direction === "vertical" ? "marginBottom" : "marginRight";
      return {
        [dirKey]: typeof size === "string" ? `${spaceSize[size]}px` : `${size}px`
      };
    }
    return createElem(
      "div",
      { class: classes },
      items.map((child, i) => {
        return createElem(
          "div",
          {
            class: getPrefixedClassName("sf-space-item"),
            key: `sf-space-item-${i}`,
            style: getItemStyles(i)
          },
          [child]
        );
      })
    );
  }
};
export { Space as SfSpace };
