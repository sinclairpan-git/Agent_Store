import { VNode } from 'vue';

interface LoadMask {
  init(): void;
  show(force?: boolean): void;
  show(options: { force?: boolean; text?: string }): void;
  hide(): void;
  text(text: string, type?: '' | 'error'): void;
  toggleStatus(type?: '' | 'error'): void;
  html(html?: string): void;
  destroy(): void;
}

interface NotifyOptions {
  /**
   * 类型
   *
   * @default 'ok'
   */
  type?: 'ok' | 'warn' | 'info' | 'fail' | 'email';

  /**
   * 标题
   */
  title?: string;

  /**
   * 内容
   */
  msg: string;

  /**
   * 是否encode
   * 为false的话不调用htmlEncode
   */
  autoEncode?: boolean;

  /**
   * 显示查看详情
   * 为false不显示
   */
  detailMsg?: string;
}

/**
 * 通知提示
 */
interface Notify {
  /**
   * 提示
   *
   * @param {(string | NotifyOptions)} [opt]
   * @returns {JQuery<HTMLElement>}
   */
  show(opt: string | NotifyOptions): JQuery<HTMLElement>;

  /**
   * 成功提示
   *
   * @param {(string | NotifyOptions)} [opt]
   * @returns {JQuery<HTMLElement>}
   */
  ok(opt: string | NotifyOptions): JQuery<HTMLElement>;

  /**
   * 失败提示
   *
   * @param {string} msg
   * @returns {JQuery<HTMLElement>}
   */
  fail(msg: string): JQuery<HTMLElement>;

  /**
   * 告警提示
   *
   * @param {string} msg
   * @returns {JQuery<HTMLElement>}
   */
  warn(msg: string): JQuery<HTMLElement>;

  /**
   * 信息提示
   *
   * @param {string} msg
   * @returns {JQuery<HTMLElement>}
   */
  info(msg: string): JQuery<HTMLElement>;

  /**
   * 邮件提示
   *
   * @param {(string | NotifyOptions)} msg
   * @param {string} [title]
   * @returns {JQuery<HTMLElement>}
   */
  message(msg: string | NotifyOptions, title?: string): JQuery<HTMLElement>;
}

type AjaxReturnType = any;

interface IAsyncOptions {
  /**
   * 支持自定义传入loadMask或者使用组件注入的$loadMask，不传则不使用遮罩；
   */
  mask?: LoadMask | boolean;

  /**
   * 是否立即显示遮罩，用于处理请求之间切换遮罩导致的闪屏；
   */
  maskImmediate?: boolean;

  /**
   * 自定义请求信息，没传就是不提示；自定义请求信息，没传就是不提示；
   */
  notify?: notifyType;

  /**
   * 自定义monitor回调，(success, json) => {}；
   */
  callback?: (success: boolean, json: any) => void;

  /**
   * 操作名称，用于提示信息，如XX操作成功或者失败
   */
  actionText?: string;

  monitorOptions?: any;
}

type notifyType =
  | 'post'
  | 'delete'
  | 'put'
  | 'sync'
  | 'async'
  | 'load'
  | 'get'
  | { okText?: string; failText?: string };

/**
 * 请求函数的封装，集成提示、遮罩和异步任务轮询处理
 */
interface ISimpleRequestOptions {
  /**
   * 请求接口，传入数组则会调用simpleWhen，传入函数会配合下面参数ajaxParams执行，建议直接传入defer；
   */
  request: AjaxReturnType | ((...args: any) => AjaxReturnType);

  /**
   * 请求参数，历史遗留，当request是函数的时候作为参数使用；
   */
  ajaxParams?: any;

  /**
   * 自定义请求信息，没传就是不提示；
   */
  notify?: notifyType;

  /**
   * 是否使用loadmask，或直接传入mask；
   */
  mask?: LoadMask | boolean;
  /**
   * 自定义 maskText，用于自定义遮罩提示文本，如果 mask 是 LoadMask 实例，则会覆盖 LoadMask 实例初始化的 msg（如有）
   */
  maskText?: string;

  /**
   * 使用abort掉上一个重复请求，一般get的情况下使用；
   */
  abortLast?: boolean;

  /**
   * 操作名称，用于提示信息，如XX操作成功或者失败；
   */
  actionText?: string;

  /**
   * 异步请求monitor配置，回调、提示和遮罩等，传true则使用默认配置；
   */
  withMonitor?: boolean | IAsyncOptions;

  /**
   * 是否立即显示遮罩，用于处理请求之间切换遮罩导致的闪屏；
   */
  maskImmediate?: boolean;
}

interface ISimpleWhenOptions {
  notify?: notifyType;
  mask?: LoadMask | boolean;
  maskImmediate?: boolean;
  request: AjaxReturnType[];
}

interface SimpleRequestMixin {
  /**
   * 请求函数的封装，集成提示、遮罩和异步任务轮询处理
   */
  $simpleRequest: (options: ISimpleRequestOptions) => AjaxReturnType;

  /**
   * $.when函数的封装，集成提示和遮罩处理
   */
  $simpleWhen: (options: ISimpleWhenOptions) => AjaxReturnType;

  /**
   * monitor函数的封装，集成提示和遮罩处理
   */
  $simpleMonitor: (pid?: string | AjaxReturnType, asyncOptions?: IAsyncOptions) => AjaxReturnType;
}

interface SfWindowProps {
  width?: number | 'auto';
  height?: number | 'auto';
  maxHeight?: number | 'auto';
  minHeight?: number | 'auto';
  autoHeight?: boolean;
  title?: string;
  overtop?: HTMLElement;
  cls?: string;
  showHelp?: string;
  noHeader?: boolean;
  noFooter?: boolean;
  noClose?: boolean;
  noCancel?: boolean;
  noSubmit?: boolean;
  cancelDisabled?: boolean;
  submitDisabled?: boolean;
  buttonAlign?: string;
  submitText?: string;
  cancelText?: string;
  noPrev?: boolean;
  steps?: string;
  path?: Array<string>;
  beforeSubmit?: Function | boolean;
  beforeCancel?: Function | boolean;
  beforeClose?: Function | boolean;
  beforeHide?: Function | boolean;
}

interface SfWindowSlots {
  $slots: {
    default?: VNode[];
    top?: VNode[];
    header?: VNode[];
    'header-inner'?: VNode[];
    bodyInner?: VNode[];
  };
  $scopedSlots: {
    footer?: (props: SfWindowFooterProps) => VNode[];
  };
}

interface SfWindowFooterProps {
  submit: () => void;
  cancel: () => void;
  submitText: string;
  cancelText: string;
  align: string;
  noSubmit: boolean;
  noCancel: boolean;
  nextDisabled: boolean;
  preDisabled: boolean;
  submitDisabled: boolean;
  cancelDisabled: boolean;
}

interface SfWindowEvents {
  $emit(eventName: 'show'): this;
  $emit(eventName: 'hide'): this;
  $emit(eventName: 'resize'): this;
  $emit(eventName: 'submit'): this;
  $emit(eventName: 'cancel'): this;
}

interface SfWindowMethods {
  prev: () => void;
  next: () => void;
  setTitle: (title: string) => void;
  setWidth: (width: string | number) => void;
  setHeight: (height: string | number) => void;
  getWidth: () => number;
  getHeight: () => number;
  show: () => void;
  hide: () => void;
  toFront: () => void;
  hideHeader: () => void;
  showHeader: () => void;
  hideMask: () => void;
  showMask: () => void;
  getBodySel: () => JQuery<HTMLElement>;
}

declare type SfWindow = Readonly<SfWindowProps & SfWindowSlots & SfWindowEvents & SfWindowMethods> & Vue;

/**
 * 弹窗组件的 props
 */
type SfMessageBoxProps = SfWindowProps & {
  /**
   * 弹窗标题
   *
   * @default 提示
   */
  title?: string;

  /**
   * 子标题
   */
  subtitle?: string | string[];

  /**
   * 消息内容
   */
  content?: string | string[];

  /**
   * 输入OK确认弹窗
   */
  withOk?: boolean;

  /**
   * 输入密码确认弹窗
   */
  withPassword?: boolean;

  /**
   * 内容块是否使用html
   */
  contentUseHtml?: boolean;

  /**
   * 图标
   */
  icon?: boolean;
};

interface SfMessageBoxSlots {
  $slots: {
    default: VNode[];
    icon?: VNode[];
    subtitle?: VNode[];
    footer?: VNode[];
    'sub-footer'?: VNode[];
  };
}

/**
 * 弹窗组件的类型定义
 */
type SfMessageBox = Readonly<SfMessageBoxProps & SfMessageBoxSlots> & SfWindow & Vue;

type SfConfirmWindow = SfMessageBox;
type SfWarnWindow = SfMessageBox;
type SfInfoWindow = SfMessageBox;
type SfSuccessWindow = SfMessageBox;
type SfDangerWindow = SfMessageBox;
type SfErrorWindow = SfMessageBox;
type SfDeleteWindow = SfMessageBox;

/**
 * @file vue原型上挂载
 */


interface MessageBoxMixin {
  $confirmWindow(propsData: SfMessageBoxProps): SfConfirmWindow;
  $infoWindow(propsData: SfMessageBoxProps): SfInfoWindow;
  $warnWindow(propsData: SfMessageBoxProps): SfWarnWindow;
  $successWindow(propsData: SfMessageBoxProps): SfSuccessWindow;
  $errorWindow(propsData: SfMessageBoxProps): SfErrorWindow;
  $dangerWindow(propsData: SfMessageBoxProps): SfDangerWindow;
  $deleteWindow(propsData: SfMessageBoxProps): SfDeleteWindow;
}

interface GlobalMixin extends MessageBoxMixin, SimpleRequestMixin {
  $notify: Notify;
  $loadMask: LoadMask;
  $isDestroyed(): boolean;
}

declare function install(Vue: any): void;

declare namespace _default {
  export { install };
}

export { GlobalMixin, _default as default, install };
