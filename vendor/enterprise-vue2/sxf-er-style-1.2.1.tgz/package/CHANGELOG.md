# @sxf/er-style

## 1.2.1 (2025-10-14)

### Patch Changes

- 0b54142f: fix(style): 修复复选框与文字垂直居中对齐

## 1.2.0 (2025-07-18)

### Minor Changes

- chore: 统一更新主线版本

## 1.1.0-xaas-patch.5 (2025-03-29)

### Patch Changes

- 5556adb3: fix(style): 明确定义 .btn.iconfont 的 font-size，避免样式加载顺序导致按钮字体大小不对

## 1.1.0-xaas-patch.4 (2025-03-26)

### Patch Changes

- ace60bc9: fix(style): style 打包产物还是打一份主题库的 css 变量进去

## 1.1.0-xaas-patch.3 (2025-03-26)

### Patch Changes

- 1d34e695: fix(comp:\*):所有不加前缀的样式内容挪入 style 包里面

## 1.1.0-xaas-patch.2 (2025-03-22)

### Patch Changes

- 93366e6d: fix: 修复由于跨组件引用 css 变量, 打包时没有提供全局 css 变量, less math 配置不是 strict 导致的样式打包产物有误

## 1.1.0-xaas-patch.1 (2025-03-19)

### Patch Changes

- chore: 合入 xaas 变更后更新版本号，统一升级

## 1.0.4-scp-6111-patch.7 (2025-03-27)

### Patch Changes

- a58e6eac: fix(style): 明确定义 .btn.iconfont 的 font-size，避免样式加载顺序导致按钮字体大小不对

## 1.0.4-scp-6111-patch.6 (2025-03-26)

### Patch Changes

- 13e5b43d: fix(style): style 打包产物还是打一份主题库的 css 变量进去

## 1.0.4-scp-6111-patch.5 (2025-03-25)

### Patch Changes

- 44cf2805: fix(comp:\*):所有不加前缀的样式内容挪入 style 包里面

## 1.0.4-scp-6111-patch.4 (2025-03-21)

### Patch Changes

- 7a7cd79a: fix: 修复由于跨组件引用 css 变量, 打包时没有提供全局 css 变量, less math 配置不是 strict 导致的样式打包产物有误

## 1.0.4-scp-6111-patch.3 (2025-03-13)

### Patch Changes

- da55c293: refactor: 所有 postCSS 语法定义的 mixin 修改为 less 语法，color-mod 替换为 fade
- b36cd956: fix(comp:\*): 修复 fade 函数透明度参数错误

## 1.1.0 (2025-02-13)

### Minor Changes

- 14788914: chore: 更新主线包发布版本号

## 1.0.4-scp-6111-patch.2 (2024-12-25)

### Patch Changes

- 390c4989: 给 body 元素添加定位，修复 tip 的定位问题

## 1.0.4-scp-6111-patch.1 (2024-12-17)

### Patch Changes

- 86f0b200: fix(style:select): 修复 Safari 浏览器初始化动画问题

## 1.0.4 (2024-07-16)

### Patch Changes

- a50d9c08: fix: 更新 peer 中声明的图标库版本到 1.0.175

## 1.0.3 (2024-07-02)

### Patch Changes

- eedb2fa0: fix(style): 依据规范更新字重变量定义，变量名与规范保持一致，原有变量名保留

## 1.0.2 (2024-06-01)

### Patch Changes

- f1c4f46b: fix: 升级主题库版本到 0.2.5

## 1.0.1 (2024-05-28)

### Patch Changes

- 4d6fa893: fix(style): 根据规范调整 caret mixin 中 right 为 4px

## 1.0.0 (2024-05-13)

### Major Changes

- 7875a24a: feat: eresh1.0 正式版发布

### Minor Changes

- a967b9ce: feat(style): 更新 @sxf/sf-theme 版本
- 412e46fe: feat(style): 新增 collapse-arrow mixin，用于折叠面板箭头样式控制
- e0667d4d: feat(style:button): button 增加 medium 尺寸
- 90a1aeb4: feat(style:\*): 更新 @sxf/sf-theme 到 "^0.2.4" 版本
- 9ae0232d: feat(style): 新增表单元素不同状态下 label 色值变量

### Patch Changes

- db72cf0e: fix(style): 修复表单小 i 图标的默认颜色
- 6260bb87: fix(comp:select): 根据交互规范修复 select 样式，文案
- d97114b4: fix(comp:select): select、comboGrid、treeSelect 的异步加载图标改为“vtv-icon-comp-loading”，颜色#CCC
- 1c5c403a: fix(style): 修改校验失败字体颜色
- f1b494db: fix(style): 按照规范调整表单元素 placeholder 色值
- 99e5e591: feat(style): 悬浮提示 footer 上下内边距由 12px 变更为 14px
- b5ad2304: fix(style): select、comboGrid、treeSelect、tree 远程加载图标旋转动画速率调整
- 7d885378: fix(style): 修复小 i 未居中问题
- 5b6ecb52: feat(style): 悬浮提示 footer 左右内边距由 4px 变更为 0

## 1.0.0-beta.7 (2024-03-29)

### Patch Changes

- 932d447c: feat(style): 悬浮提示 footer 左右内边距由 4px 变更为 0

## 1.0.0-beta.6 (2024-03-26)

### Minor Changes

- 99d05ae6: feat(style:button): button 增加 medium 尺寸

### Patch Changes

- ad4e5664: fix(comp:select): 根据交互规范修复 select 样式，文案
- 7287d0e7: feat(style): 悬浮提示 footer 上下内边距由 12px 变更为 14px

## 1.0.0-beta.5 (2024-03-18)

### Patch Changes

- d327d7ca: fix(style): 修改校验失败字体颜色
- 3349d851: fix(style): 修复小 i 未居中问题

## 1.0.0-beta.4 (2024-03-11)

### Patch Changes

- 3ce96289: fix(comp:select): select、comboGrid、treeSelect 的异步加载图标改为“vtv-icon-comp-loading”，颜色#CCC
- 68c5d043: fix(style): select、comboGrid、treeSelect、tree 远程加载图标旋转动画速率调整

## 1.0.0-beta.3 (2024-03-06)

### Minor Changes

- 6ded0919: feat(style): 新增 collapse-arrow mixin，用于折叠面板箭头样式控制

### Patch Changes

- a0572afe: fix(style): 修复表单小 i 图标的默认颜色

## 1.0.0-beta.2 (2024-01-31)

### Minor Changes

- cafe7732: feat(style): 更新 @sxf/sf-theme 版本
- 882f1449: feat(style:\*): 更新 @sxf/sf-theme 到 "^0.2.4" 版本

## 1.0.0-beta.1 (2024-01-22)

### Minor Changes

- ef71407e: feat(style): 新增表单元素不同状态下 label 色值变量

### Patch Changes

- ff9bb78c: fix(style): 按照规范调整表单元素 placeholder 色值

## 1.0.0-beta.0 (2024-01-17)

### Major Changes

- 0b0e74eb: chore: init beta version release

## 0.2.0 (2024-01-12)

### Minor Changes

- 55fdeeeb: feat(style): 图标库 peer 依赖由 @sxf/cloud-iconfont 变更为 @sxf/vtv-icon

## 0.1.1 (2023-10-27)

### Patch Changes

- e6ce7fd: fix(style): 组件 loading 恢复使用 gif 图，移除相关变量

## 0.1.0 (2023-07-06)

### Minor Changes

- 4be47e3: feat: 打包样式保留变量

## 0.0.7 (2023-05-25)

### Patch Changes

- 6e981d7: fix: 补齐下拉框的 loading 状态

## 0.0.6 (2023-04-18)

### Patch Changes

- 27b7cda: feat(style): 添加 reset 样式打包

## 0.0.5 (2023-04-14)

### Patch Changes

- 64edf2c: fix(style): 修复字体文件没打包进去的问题

## 0.0.4 (2023-04-13)

### Patch Changes

- eefe9b7: style: 新增 TG-TYPE 字体，全局引入

## 0.0.3 (2023-04-03)

### Patch Changes

- c08a1e1: fix: 修复图片打包问题，移除没有用的样式

## 0.0.2 (2023-03-29)

### Patch Changes

- release

## 0.0.1 (2023-03-29)

### Patch Changes

- chore: release
