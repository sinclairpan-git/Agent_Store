// packages/utils/_private/event/index.js
import DelayedTask from "@sxf/er-utils/delayedTask";
var TRUE = true;
var FALSE = false;
function EventEmitter(obj, name) {
  this.name = name;
  this.obj = obj;
  this.listeners = [];
}
EventEmitter.prototype = {
  /**
   * 添加事件监听器
   *
   * @function
   * @param {Function} fn - 事件处理函数
   * @param {Object} [scope=this.obj] - 事件处理函数的作用域
   * @param {Object} [options] - 事件处理函数的选项
   * @param {Object} [options.target] - 事件处理函数的目标对象
   * @param {number} [options.delay] - 事件处理函数的延迟时间
   * @param {boolean} [options.single] - 事件处理函数是否只执行一次
   * @param {number} [options.buffer] - 事件处理函数的缓冲时间
   */
  addListener(fn, scope, options) {
    let me = this, l;
    scope = scope || me.obj;
    if (!me.isListening(fn, scope)) {
      l = me.createListener(fn, scope, options);
      if (me.firing) {
        me.listeners = me.listeners.slice(0);
      }
      me.listeners.push(l);
    }
  },
  /**
   * 创建事件监听器
   *
   * @function
   * @param {Function} fn - 事件处理函数
   * @param {Object} [scope=this.obj] - 事件处理函数的作用域
   * @param {Object} [o] - 事件处理函数的选项
   * @param {Object} [o.target] - 事件处理函数的目标对象
   * @param {number} [o.delay] - 事件处理函数的延迟时间
   * @param {boolean} [o.single] - 事件处理函数是否只执行一次
   * @param {number} [o.buffer] - 事件处理函数的缓冲时间
   * @returns {Object} - 事件监听器对象
   */
  createListener(fn, scope, o) {
    o = o || {};
    scope = scope || this.obj;
    let l = {
      fn,
      scope,
      options: o
    }, h = fn;
    if (o.target) {
      h = createTargeted(h, o, scope);
    }
    if (o.delay) {
      h = createDelayed(h, o, l, scope);
    }
    if (o.single) {
      h = createSingle(h, this, fn, scope);
    }
    if (o.buffer) {
      h = createBuffered(h, o, l, scope);
    }
    l.fireFn = h;
    return l;
  },
  /**
   * 查找事件监听器
   *
   * @function
   * @param {Function} fn - 事件处理函数
   * @param {Object} [scope=this.obj] - 事件处理函数的作用域
   * @returns {number} - 事件监听器的索引，如果不存在则返回 -1
   */
  findListener(fn, scope) {
    let list = this.listeners, i = list.length, l;
    scope = scope || this.obj;
    while (i--) {
      l = list[i];
      if (l) {
        if (l.fn == fn && l.scope == scope) {
          return i;
        }
      }
    }
    return -1;
  },
  /**
   * 判断是否已经添加了事件监听器
   *
   * @function
   * @param {Function} fn - 事件处理函数
   * @param {Object} [scope=this.obj] - 事件处理函数的作用域
   * @returns {boolean} - 是否已经添加了事件监听器
   */
  isListening(fn, scope) {
    return this.findListener(fn, scope) != -1;
  },
  /**
   * 移除事件监听器
   *
   * @function
   * @param {Function} fn - 事件处理函数
   * @param {Object} [scope=this.obj] - 事件处理函数的作用域
   * @returns {boolean} - 是否成功移除事件监听器
   */
  removeListener(fn, scope) {
    let index, l, k, me = this, ret = FALSE;
    if ((index = me.findListener(fn, scope)) != -1) {
      if (me.firing) {
        me.listeners = me.listeners.slice(0);
      }
      l = me.listeners[index];
      if (l.task) {
        l.task.cancel();
        delete l.task;
      }
      k = l.tasks && l.tasks.length;
      if (k) {
        while (k--) {
          l.tasks[k].cancel();
        }
        delete l.tasks;
      }
      me.listeners.splice(index, 1);
      ret = TRUE;
    }
    return ret;
  },
  /**
   * 清空所有事件监听器
   *
   * @function
   */
  clearListeners() {
    let me = this, l = me.listeners, i = l.length;
    while (i--) {
      me.removeListener(l[i].fn, l[i].scope);
    }
  },
  /**
   * 触发事件
   *
   * @function
   * @returns {boolean} - 是否成功触发事件
   */
  fire() {
    let me = this, listeners = me.listeners, len = listeners.length, i = 0, l;
    delete me.result;
    if (len > 0) {
      me.firing = TRUE;
      const args = Array.prototype.slice.call(arguments, 0);
      for (; i < len; i++) {
        l = listeners[i];
        if (l) {
          me.result = l.fireFn.apply(l.scope || me.obj || window, args);
          if (me.result === FALSE) {
            return me.firing = FALSE;
          }
        }
      }
    }
    me.firing = FALSE;
    return TRUE;
  }
};
function createTargeted(h, o, scope) {
  return function() {
    if (o.target == arguments[0]) {
      h.apply(scope, Array.prototype.slice.call(arguments, 0));
    }
  };
}
function createBuffered(h, o, l, scope) {
  l.task = new DelayedTask();
  return function() {
    l.task.delay(o.buffer, h, scope, Array.prototype.slice.call(arguments, 0));
  };
}
function createSingle(h, e, fn, scope) {
  return function() {
    e.removeListener(fn, scope);
    return h.apply(scope, arguments);
  };
}
function createDelayed(h, o, l, scope) {
  return function() {
    const task = new DelayedTask(), args = Array.prototype.slice.call(arguments, 0);
    if (!l.tasks) {
      l.tasks = [];
    }
    l.tasks.push(task);
    task.delay(
      o.delay || 10,
      function() {
        l.tasks.remove(task);
        h.apply(scope, args);
      },
      scope
    );
  };
}
EventEmitter.prototype.on = EventEmitter.prototype.addListener;
EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
EventEmitter.prototype.emit = EventEmitter.prototype.fire;
EventEmitter.prototype.clear = EventEmitter.prototype.clearListeners;
var event_default = EventEmitter;
export {
  event_default as default
};
