/**
 * 事件触发器
 *
 * @class
 * @param {Object} obj - 事件触发器所属的对象
 * @param {string} name - 事件触发器的名称
 */
declare function EventEmitter(obj: Object, name: string): void;
declare class EventEmitter {
    /**
     * 事件触发器
     *
     * @class
     * @param {Object} obj - 事件触发器所属的对象
     * @param {string} name - 事件触发器的名称
     */
    constructor(obj: Object, name: string);
    name: string;
    obj: Object;
    listeners: any[];
    on: (fn: Function, scope?: Object | undefined, options?: {
        target?: Object | undefined;
        delay?: number | undefined;
        single?: boolean | undefined;
        buffer?: number | undefined;
    } | undefined) => void;
    off: (fn: Function, scope?: Object | undefined) => boolean;
    emit: (...args: any[]) => boolean;
    clear: () => void;
    /**
     * 添加事件监听器
     *
     * @function
     * @param {Function} fn - 事件处理函数
     * @param {Object} [scope=this.obj] - 事件处理函数的作用域
     * @param {Object} [options] - 事件处理函数的选项
     * @param {Object} [options.target] - 事件处理函数的目标对象
     * @param {number} [options.delay] - 事件处理函数的延迟时间
     * @param {boolean} [options.single] - 事件处理函数是否只执行一次
     * @param {number} [options.buffer] - 事件处理函数的缓冲时间
     */
    addListener(fn: Function, scope?: Object | undefined, options?: {
        target?: Object | undefined;
        delay?: number | undefined;
        single?: boolean | undefined;
        buffer?: number | undefined;
    } | undefined): void;
    /**
     * 创建事件监听器
     *
     * @function
     * @param {Function} fn - 事件处理函数
     * @param {Object} [scope=this.obj] - 事件处理函数的作用域
     * @param {Object} [o] - 事件处理函数的选项
     * @param {Object} [o.target] - 事件处理函数的目标对象
     * @param {number} [o.delay] - 事件处理函数的延迟时间
     * @param {boolean} [o.single] - 事件处理函数是否只执行一次
     * @param {number} [o.buffer] - 事件处理函数的缓冲时间
     * @returns {Object} - 事件监听器对象
     */
    createListener(fn: Function, scope?: Object | undefined, o?: {
        target?: Object | undefined;
        delay?: number | undefined;
        single?: boolean | undefined;
        buffer?: number | undefined;
    } | undefined): Object;
    /**
     * 查找事件监听器
     *
     * @function
     * @param {Function} fn - 事件处理函数
     * @param {Object} [scope=this.obj] - 事件处理函数的作用域
     * @returns {number} - 事件监听器的索引，如果不存在则返回 -1
     */
    findListener(fn: Function, scope?: Object | undefined): number;
    /**
     * 判断是否已经添加了事件监听器
     *
     * @function
     * @param {Function} fn - 事件处理函数
     * @param {Object} [scope=this.obj] - 事件处理函数的作用域
     * @returns {boolean} - 是否已经添加了事件监听器
     */
    isListening(fn: Function, scope?: Object | undefined): boolean;
    /**
     * 移除事件监听器
     *
     * @function
     * @param {Function} fn - 事件处理函数
     * @param {Object} [scope=this.obj] - 事件处理函数的作用域
     * @returns {boolean} - 是否成功移除事件监听器
     */
    removeListener(fn: Function, scope?: Object | undefined): boolean;
    /**
     * 清空所有事件监听器
     *
     * @function
     */
    clearListeners(): void;
    /**
     * 触发事件
     *
     * @function
     * @returns {boolean} - 是否成功触发事件
     */
    fire(...args: any[]): boolean;
    firing: boolean | undefined;
}

export { EventEmitter as default };
