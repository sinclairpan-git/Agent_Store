// packages/utils/_private/detectPageStatus/index.js
var hiddenProperty = "hidden" in document ? "hidden" : "webkitHidden" in document ? "webkitHidden" : "mozHidden" in document ? "mozHidden" : "msHidden" in document ? "msHidden" : "";
var isPageHidden = document[hiddenProperty];
var visibilityChangeEvent = hiddenProperty.replace(/hidden/i, "visibilitychange");
var onVisibilityChange = function() {
  isPageHidden = document[hiddenProperty];
};
if (hiddenProperty) {
  document.addEventListener(visibilityChangeEvent, onVisibilityChange);
} else {
  isPageHidden = false;
}
var getPageStatus = () => {
  return isPageHidden;
};
export {
  getPageStatus
};
