declare function getPageStatus(): boolean;

export { getPageStatus };
