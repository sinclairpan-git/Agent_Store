declare function setTimeout(...args: any[]): any;
declare function clearTimeout(...args: any[]): any;
declare function setInterval(...args: any[]): any;
declare function clearInterval(...args: any[]): any;

/**
 * setTimeout 接口Promise化
 *
 * @param {String} name 指定名称，clearTimeout 的时候会用到
 * @param {Number} ms 延迟多少毫秒
 * @returns {Promise} 返回 Promise 对象
 */
declare function sleep(name: string, ms: number, ...args: any[]): Promise<any>;
/**
 * clearTimeout 接口，需要把名称传进来
 *
 * @param {String} name setTimeout 的名称
 * @return {Boolean} 是否成功
 */
declare function clearSleep(name: string): boolean;

export { clearInterval, clearSleep, clearTimeout, setInterval, setTimeout, sleep };
