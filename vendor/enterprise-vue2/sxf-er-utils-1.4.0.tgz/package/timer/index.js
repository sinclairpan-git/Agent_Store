// packages/utils/timer/index.js
import logger from "@sxf/er-utils/logger";
import uuid from "@sxf/er-utils/uuid";

// packages/utils/timer/timerProxy.js
var g = function() {
  return this || window;
}();
function createProxy(method) {
  return function(...args) {
    return g[method].call(g, ...args);
  };
}
var setTimeout = createProxy("setTimeout");
var clearTimeout = createProxy("clearTimeout");
var setInterval = createProxy("setInterval");
var clearInterval = createProxy("clearInterval");

// packages/utils/timer/index.js
var timeoutMap = /* @__PURE__ */ new Map();
var timerLogger = logger("timer");
function sleep(name, ms) {
  if (arguments.length === 1 && typeof name === "number") {
    ms = name;
    name = uuid();
  }
  return new Promise(function(resolve) {
    const id = window.setTimeout(() => {
      if (timeoutMap.has(name)) {
        resolve(name);
        timeoutMap.delete(name);
      } else {
        timerLogger.error("[timer] reject: " + name);
      }
    }, ms);
    timeoutMap.set(name, id);
  });
}
function clearSleep(name) {
  if (timeoutMap.has(name)) {
    window.clearTimeout(timeoutMap.get(name));
    timeoutMap.delete(name);
    return true;
  }
  return false;
}
export {
  clearInterval,
  clearSleep,
  clearTimeout,
  setInterval,
  setTimeout,
  sleep
};
