/**
 * Copies all the properties of config to obj.
 *
 * @function
 * @param {object} obj - The receiver of the properties.
 * @param {object} config - The source of the properties.
 * @param {object} [defaults] - A different object that will also be applied for default values.
 * @return {object} - Returns obj.
 * @example
 * // Copy properties from config to obj
 * const obj = { a: 1 };
 * const config = { b: 2 };
 * x(obj, config); // { a: 1, b: 2 }
 *
 * // Copy properties from config and defaults to obj
 * const defaults = { c: 3 };
 * x(obj, config, defaults); // { a: 1, b: 2, c: 3 }
 */
declare function x(o: any, c: any, defaults?: object | undefined): object;
declare namespace x {
    /**
     * Copies all the properties of config to obj only if the property does not already exist in obj.
     *
     * @function
     * @param {object} obj - The receiver of the properties.
     * @param {object} config - The source of the properties.
     * @return {object} - Returns obj.
     * @example
     * // Copy properties from config to obj only if the property does not already exist in obj
     * const obj = { a: 1 };
     * const config = { b: 2 };
     * x.applyIf(obj, config); // { a: 1, b: 2 }
     *
     * // Do not copy properties from config to obj if the property already exists in obj
     * const obj2 = { a: 1 };
     * const config2 = { a: 2 };
     * x.applyIf(obj2, config2); // { a: 1 }
     */
    function applyIf(o: any, c: any): object;
}

export { x as default };
