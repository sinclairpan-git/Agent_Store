// packages/utils/apply/index.js
var x = function(o, c, defaults) {
  if (defaults) {
    x(o, defaults);
  }
  if (o && c && typeof c === "object") {
    for (const p in c) {
      o[p] = c[p];
    }
  }
  return o;
};
x.applyIf = function(o, c) {
  if (o) {
    for (const p in c) {
      if (typeof o[p] === "undefined") {
        o[p] = c[p];
      }
    }
  }
  return o;
};
var apply_default = x;
export {
  apply_default as default
};
