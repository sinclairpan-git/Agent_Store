// packages/utils/textMetrics/index.js
import $ from "jquery";
var shared = null;
var TextMetrics = class {
  /**
   * 测量指定文本的大小
   *
   * @param {String|HTMLElement} el - 用于复制现有 CSS 样式的元素、DOM 节点或 ID，这些样式可能会影响呈现的文本大小
   * @param {String} text - 要测量的文本
   * @param {Number} [maxWidth] - 如果文本将是多行的，则必须设置最大宽度以准确测量文本高度
   * @return {TextSize} 包含文本大小的对象 {width: (width), height: (height)}
   * @example
   * const size = TextMetrics.measure('myElement', 'Hello World', 200);
   * console.log(size.width, size.height);
   */
  static measure(el, text, maxWidth) {
    if (!shared) {
      shared = new TextMetrics.Instance(el, maxWidth);
    }
    if (typeof el === "string") {
      maxWidth = text;
      text = el;
      el = null;
    }
    shared.bind(el || document.body);
    shared.setMaxWidth(maxWidth || "auto");
    return shared.getSize(text);
  }
  /**
   * 返回一个唯一的 TextMetrics 实例，可以直接绑定到元素并重复使用。
   * 这减少了多次调用以初始化每个测量上的样式属性的开销。
   *
   * @param {String|HTMLElement} el - 将实例绑定到的元素、DOM 节点或 ID
   * @param {Number} [maxWidth] - 如果文本将是多行的，则必须设置最大宽度以准确测量文本高度
   * @return {TextMetrics.Instance} 新实例
   * @example
   * const instance = TextMetrics.createInstance('myElement', 200);
   * const size = instance.getSize('Hello World');
   * console.log(size.width, size.height);
   */
  static createInstance(el, maxWidth) {
    return new TextMetrics.Instance(el, maxWidth);
  }
};
TextMetrics.Instance = class {
  constructor(bindTo, maxWidth) {
    this.ml = $("<div>").appendTo(document.body);
    this.ml.css({
      position: "absolute",
      left: -1e3,
      top: -1e3
    });
    this.ml.hide();
    if (maxWidth) {
      this.setMaxWidth(maxWidth);
    }
    this.bind(bindTo);
  }
  /**
   * 返回基于内部元素的样式和宽度属性的指定文本的大小
   *
   * @param {String} text - 要测量的文本
   * @return {TextSize} 包含文本大小的对象 {width: (width), height: (height)}
   * @example
   * const instance = TextMetrics.createInstance('myElement', 200);
   * const size = instance.getSize('Hello World');
   * console.log(size.width, size.height);
   */
  getSize(text) {
    this.ml.html(`<span style="white-space: pre;">${text}</span>`);
    const fs = parseInt(this.ml.css("font-size"), 10);
    const s = {
      /**
       * TextMetrics在计算元素的宽度的时候，jQuery的width会把后面的小数去掉，导致宽度不够，会显示换行，手动补偿
       *
       * http://code.sangfor.org/UED/FE-COMMON/vt-component/merge_requests/1617#
       */
      width: this.ml.width() + 1,
      height: Math.ceil(this.ml.height() / fs) * fs
    };
    this.ml.html("");
    return s;
  }
  /**
   * 将此 TextMetrics 实例绑定到一个元素，从中复制现有 CSS 样式，这些样式可能会影响呈现的文本大小
   *
   * @param {String/HTMLElement} el - 元素、DOM 节点或 ID
   * @example
   * const instance = TextMetrics.createInstance('myElement', 200);
   * instance.bind('anotherElement');
   */
  bind(el) {
    el = $(el);
    this.ml.css({
      "font-size": el.css("font-size"),
      "font-style": el.css("font-style"),
      "font-weight": el.css("font-weight"),
      "font-family": el.css("font-family"),
      "line-height": el.css("line-height"),
      "text-transform": el.css("text-transform"),
      "letter-spacing": el.css("letter-spacing")
    });
  }
  /**
   * 在内部测量元素上设置最大宽度。如果文本将是多行的，则必须设置最大宽度以准确测量文本高度。
   *
   * @param {Number} width - 要设置在元素上的宽度
   * @example
   * const instance = TextMetrics.createInstance('myElement', 200);
   * instance.setMaxWidth(300);
   */
  setMaxWidth(width) {
    this.ml.css("max-width", width);
  }
  /**
   * 返回指定文本的测量宽度
   *
   * @param {String} text - 要测量的文本
   * @return {Number} 宽度（以像素为单位）
   * @example
   * const instance = TextMetrics.createInstance('myElement', 200);
   * const width = instance.getWidth('Hello World');
   * console.log(width);
   */
  getWidth(text) {
    this.ml.width("auto");
    return this.getSize(text).width;
  }
  /**
   * 返回指定文本的测量高度。对于多行文本，请确保在必要时调用 {@link #setMaxWidth}。
   *
   * @param {String} text - 要测量的文本
   * @return {Number} 高度（以像素为单位）
   * @example
   * const instance = TextMetrics.createInstance('myElement', 200);
   * const height = instance.getHeight('Hello World');
   * console.log(height);
   */
  getHeight(text) {
    return this.getSize(text).height;
  }
};
export {
  TextMetrics as default
};
