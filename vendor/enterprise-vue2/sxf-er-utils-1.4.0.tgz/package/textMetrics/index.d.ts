/**
 * 提供文本块的精确像素测量，以便您可以确定给定文本块的高度和宽度（以像素为单位）。
 * 注意，在测量文本时，它应该是纯文本，不应包含任何 HTML，否则可能无法正确测量。
 *
 * @singleton
 */
/**
 * @typedef {Object} TextSize
 * @property {number} width - 文本的宽度（以像素为单位）
 * @property {number} height - 文本的高度（以像素为单位）
 */
declare class TextMetrics {
    /**
     * 测量指定文本的大小
     *
     * @param {String|HTMLElement} el - 用于复制现有 CSS 样式的元素、DOM 节点或 ID，这些样式可能会影响呈现的文本大小
     * @param {String} text - 要测量的文本
     * @param {Number} [maxWidth] - 如果文本将是多行的，则必须设置最大宽度以准确测量文本高度
     * @return {TextSize} 包含文本大小的对象 {width: (width), height: (height)}
     * @example
     * const size = TextMetrics.measure('myElement', 'Hello World', 200);
     * console.log(size.width, size.height);
     */
    static measure(el: string | HTMLElement, text: string, maxWidth?: number | undefined): TextSize;
    /**
     * 返回一个唯一的 TextMetrics 实例，可以直接绑定到元素并重复使用。
     * 这减少了多次调用以初始化每个测量上的样式属性的开销。
     *
     * @param {String|HTMLElement} el - 将实例绑定到的元素、DOM 节点或 ID
     * @param {Number} [maxWidth] - 如果文本将是多行的，则必须设置最大宽度以准确测量文本高度
     * @return {TextMetrics.Instance} 新实例
     * @example
     * const instance = TextMetrics.createInstance('myElement', 200);
     * const size = instance.getSize('Hello World');
     * console.log(size.width, size.height);
     */
    static createInstance(el: string | HTMLElement, maxWidth?: number | undefined): {
        ml: JQuery<HTMLElement>;
        /**
         * 返回基于内部元素的样式和宽度属性的指定文本的大小
         *
         * @param {String} text - 要测量的文本
         * @return {TextSize} 包含文本大小的对象 {width: (width), height: (height)}
         * @example
         * const instance = TextMetrics.createInstance('myElement', 200);
         * const size = instance.getSize('Hello World');
         * console.log(size.width, size.height);
         */
        getSize(text: string): TextSize;
        /**
         * 将此 TextMetrics 实例绑定到一个元素，从中复制现有 CSS 样式，这些样式可能会影响呈现的文本大小
         *
         * @param {String/HTMLElement} el - 元素、DOM 节点或 ID
         * @example
         * const instance = TextMetrics.createInstance('myElement', 200);
         * instance.bind('anotherElement');
         */
        bind(el: any): void;
        /**
         * 在内部测量元素上设置最大宽度。如果文本将是多行的，则必须设置最大宽度以准确测量文本高度。
         *
         * @param {Number} width - 要设置在元素上的宽度
         * @example
         * const instance = TextMetrics.createInstance('myElement', 200);
         * instance.setMaxWidth(300);
         */
        setMaxWidth(width: number): void;
        /**
         * 返回指定文本的测量宽度
         *
         * @param {String} text - 要测量的文本
         * @return {Number} 宽度（以像素为单位）
         * @example
         * const instance = TextMetrics.createInstance('myElement', 200);
         * const width = instance.getWidth('Hello World');
         * console.log(width);
         */
        getWidth(text: string): number;
        /**
         * 返回指定文本的测量高度。对于多行文本，请确保在必要时调用 {@link #setMaxWidth}。
         *
         * @param {String} text - 要测量的文本
         * @return {Number} 高度（以像素为单位）
         * @example
         * const instance = TextMetrics.createInstance('myElement', 200);
         * const height = instance.getHeight('Hello World');
         * console.log(height);
         */
        getHeight(text: string): number;
    };
}
declare namespace TextMetrics {
    export { Instance };
}

type TextSize = {
    /**
     * - 文本的宽度（以像素为单位）
     */
    width: number;
    /**
     * - 文本的高度（以像素为单位）
     */
    height: number;
};
declare class Instance {
    constructor(bindTo: any, maxWidth: any);
    ml: JQuery<HTMLElement>;
    /**
     * 返回基于内部元素的样式和宽度属性的指定文本的大小
     *
     * @param {String} text - 要测量的文本
     * @return {TextSize} 包含文本大小的对象 {width: (width), height: (height)}
     * @example
     * const instance = TextMetrics.createInstance('myElement', 200);
     * const size = instance.getSize('Hello World');
     * console.log(size.width, size.height);
     */
    getSize(text: string): TextSize;
    /**
     * 将此 TextMetrics 实例绑定到一个元素，从中复制现有 CSS 样式，这些样式可能会影响呈现的文本大小
     *
     * @param {String/HTMLElement} el - 元素、DOM 节点或 ID
     * @example
     * const instance = TextMetrics.createInstance('myElement', 200);
     * instance.bind('anotherElement');
     */
    bind(el: any): void;
    /**
     * 在内部测量元素上设置最大宽度。如果文本将是多行的，则必须设置最大宽度以准确测量文本高度。
     *
     * @param {Number} width - 要设置在元素上的宽度
     * @example
     * const instance = TextMetrics.createInstance('myElement', 200);
     * instance.setMaxWidth(300);
     */
    setMaxWidth(width: number): void;
    /**
     * 返回指定文本的测量宽度
     *
     * @param {String} text - 要测量的文本
     * @return {Number} 宽度（以像素为单位）
     * @example
     * const instance = TextMetrics.createInstance('myElement', 200);
     * const width = instance.getWidth('Hello World');
     * console.log(width);
     */
    getWidth(text: string): number;
    /**
     * 返回指定文本的测量高度。对于多行文本，请确保在必要时调用 {@link #setMaxWidth}。
     *
     * @param {String} text - 要测量的文本
     * @return {Number} 高度（以像素为单位）
     * @example
     * const instance = TextMetrics.createInstance('myElement', 200);
     * const height = instance.getHeight('Hello World');
     * console.log(height);
     */
    getHeight(text: string): number;
}

export { TextSize, TextMetrics as default };
