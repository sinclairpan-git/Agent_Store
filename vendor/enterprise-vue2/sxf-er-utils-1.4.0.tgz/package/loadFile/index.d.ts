/**
 * 统一的接口下载文件
 *
 * @method loadFile
 * @param params
 * @param urlParser
 * @param cancelCallback 给IE浏览器增加的取消函数
 */
declare function Loader(params: any, urlParser: any, cancelCallback: any): void;
declare namespace Loader {
    export const url: string;
    export { getLoadUrl };
}
declare function getLoadUrl(params: any): string;

export { Loader as default };
