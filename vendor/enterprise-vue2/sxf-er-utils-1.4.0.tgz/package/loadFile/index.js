// packages/utils/loadFile/index.js
import $ from "jquery";
import { $i } from "@sxf/er-config";
import cluster from "@sxf/er-utils/cluster";
import { toQueryString } from "@sxf/er-utils/object";
import ua from "@sxf/er-utils/ua";
import MB from "@sxf/er-widget/messageBox";
var loadfileIframe = null;
var Loader = function(params, urlParser, cancelCallback) {
  let url = getLoadUrl(params);
  if (urlParser && typeof urlParser === "function") {
    url = urlParser(url);
  }
  if (!ua.isIE) {
    if (!loadfileIframe) {
      loadfileIframe = $(
        "<iframe frameBorder=0 width=0 height=0 style='display:none;visibility:hidden;height:0px'></iframe>"
      ).appendTo($("body"));
    }
    loadfileIframe.attr("src", url);
  } else {
    MB.showInfo({
      title: $i("scp.vt_component.common.util.loadFile.download_info_title"),
      cls: "download-info-cls_IE",
      msg: '<div style="text-decoration: underline;" class="sim-link" action="downloadForIe">' + $i("scp.vt_component.common.util.loadFile.download_info_msg") + "</div>",
      buttons: [
        {
          text: $i("scp.vt_component.common.util.loadFile.download_info_confirm_btn"),
          action: "cancel"
        }
      ],
      buttonAlign: "center"
    });
    const cancelParam = {
      params,
      callback: cancelCallback
    };
    initIeDownLoadEvent(url, cancelParam);
  }
};
function initIeDownLoadEvent(url, cancelParam) {
  const $downLoadWin = $(document).find(".download-info-cls_IE");
  $downLoadWin.find('[action="downloadForIe"]').on("click", function() {
    MB.destroy();
    window.open(url);
  });
  $downLoadWin.find('[action="cancel"]').on("click", function() {
    if (typeof cancelParam.callback === "function") {
      cancelParam.callback.call(null, cancelParam.params);
    }
  });
}
function getLoadUrl(params) {
  let url = Loader.url;
  params = toQueryString(params || {});
  if (params) {
    url += "?" + params;
  }
  return url;
}
Loader.url = "/download";
if (cluster.isClusterPath(location.pathname)) {
  Loader.url = "./download";
}
Loader.getLoadUrl = getLoadUrl;
var loadFile_default = Loader;
export {
  loadFile_default as default
};
