declare namespace cookies {
    export { get };
    export { set };
    export { clear };
}
/**
 * Retrieves cookies that are accessible by the current page. If a cookie does not exist, `get()` returns null. The
 * following example retrieves the cookie called "valid" and stores the String value in the variable validStatus.
 *
 *     var validStatus = Ext.util.Cookies.get("valid");
 *
 * @param {String} name The name of the cookie to get
 * @return {Object} Returns the cookie value for the specified name;
 * null if the cookie name does not exist.
 */
declare function get(name: string): Object;
/**
 * Creates a cookie with the specified name and value. Additional settings for the cookie may be optionally specified
 * (for example: expiration, access restriction, SSL).
 *
 * @param {String} name The name of the cookie to set.
 * @param {Object|string} value The value to set for the cookie.
 * @param {Object} [expires] Specify an expiration date the cookie is to persist until. Note that the specified Date
 * object will be converted to Greenwich Mean Time (GMT).
 * @param {String} [path] Setting a path on the cookie restricts access to pages that match that path. Defaults to all
 * pages ('/').
 * @param {String} [domain] Setting a domain restricts access to pages on a given domain (typically used to allow
 * cookie access across subdomains). For example, "sencha.com" will create a cookie that can be accessed from any
 * subdomain of sencha.com, including www.sencha.com, support.sencha.com, etc.
 * @param {Boolean} [secure] Specify true to indicate that the cookie should only be accessible via SSL on a page
 * using the HTTPS protocol. Defaults to false. Note that this will only work if the page calling this code uses the
 * HTTPS protocol, otherwise the cookie will be created with default options.
 */
declare function set(name: string, value: Object | string, ...args: any[]): void;
/**
 * Removes a cookie with the provided name from the browser
 * if found by setting its expiration date to sometime in the past.
 *
 * @param {String} name The name of the cookie to remove
 * @param {String} [path] The path for the cookie.
 * This must be included if you included a path while setting the cookie.
 */
declare function clear(name: string, path?: string | undefined): void;

export { cookies as default };
