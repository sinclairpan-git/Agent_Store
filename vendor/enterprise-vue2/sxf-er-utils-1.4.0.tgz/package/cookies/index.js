// packages/utils/cookies/index.js
function set(name, value) {
  const argv = arguments, argc = arguments.length, expires = argc > 2 ? argv[2] : null, path = argc > 3 ? argv[3] : "/", domain = argc > 4 ? argv[4] : null, secure = argc > 5 ? argv[5] : false;
  document.cookie = name + "=" + escape(value) + (expires === null ? "" : "; expires=" + expires.toGMTString()) + (path === null ? "" : "; path=" + path) + (domain === null ? "" : "; domain=" + domain) + (secure === true ? "; secure" : "");
}
function get(name) {
  const arg = name + "=", alen = arg.length, clen = document.cookie.length;
  let i = 0, j = 0;
  while (i < clen) {
    j = i + alen;
    if (document.cookie.substring(i, j) === arg) {
      return getCookieVal(j);
    }
    i = document.cookie.indexOf(" ", i) + 1;
    if (i === 0) {
      break;
    }
  }
  return null;
}
function clear(name, path) {
  if (get(name)) {
    path = path || "/";
    document.cookie = name + "=; expires=Thu, 01-Jan-70 00:00:01 GMT; path=" + path;
  }
}
function getCookieVal(offset) {
  let endstr = document.cookie.indexOf(";", offset);
  if (endstr === -1) {
    endstr = document.cookie.length;
  }
  return unescape(document.cookie.substring(offset, endstr));
}
var cookies = {
  get,
  set,
  clear
};
var cookies_default = cookies;
export {
  cookies_default as default
};
