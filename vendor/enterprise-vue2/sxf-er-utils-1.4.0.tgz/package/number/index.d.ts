declare function toFixed(value: any, precision: any): any;
declare function correctFloat(n: any): number;

export { correctFloat, toFixed };
