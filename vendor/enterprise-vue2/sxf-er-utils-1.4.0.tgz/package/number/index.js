// packages/utils/number/index.js
var _isToFixedBroken = 0.9 .toFixed() !== "1";
var backupToFixed = (value, precision) => {
  precision = precision || 0;
  const pow = Math.pow(10, precision);
  return (Math.round(value * pow) / pow).toFixed(precision);
};
var originToFixed = (value, precision) => {
  return value.toFixed(precision);
};
var toFixed = _isToFixedBroken ? backupToFixed : originToFixed;
var correctFloat = function(n) {
  return parseFloat(n.toPrecision(14));
};
export {
  correctFloat,
  toFixed
};
