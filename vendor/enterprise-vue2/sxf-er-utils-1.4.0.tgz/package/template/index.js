// packages/utils/template/index.js
import Format from "@sxf/er-utils/format";
var { format } = Format;
var isObj = function(obj) {
  return obj && typeof obj === "object" && Object.prototype.toString.call(obj) !== "[object Array]";
};
var config = {
  encode: Format.htmlEncode
};
var iconFn = function() {
  const baseCls = "sf-ico";
  const tpl = '<span class="{0}" style="display:inline;display:inline-block;margin-bottom:0;{2}" data-hint="{1}" {3}>&#160;&#160;&#160;&#160;</span>';
  return function(iconCls, tip, cls, style, attr) {
    if (isObj(iconCls)) {
      tip = iconCls.tip;
      cls = iconCls.cls;
      style = iconCls.style;
      attr = iconCls.attr;
      iconCls = iconCls.iconCls;
    }
    cls = cls || baseCls;
    return format(tpl, [cls, iconCls].join(" "), tip || "", style || "", attr || "");
  };
}();
var iconActionFn = function() {
  const baseCls = "sf-ico";
  const tpl = '<span class="{0}" action="{3}" style="display:inline;display:inline-block;margin-bottom:0;{2}" data-hint="{1}" {3}>&#160;&#160;&#160;&#160;</span>';
  return function(iconCls, action, tip, cls, style) {
    if (isObj(iconCls)) {
      tip = iconCls.tip;
      cls = iconCls.cls;
      style = iconCls.style;
      action = iconCls.action;
      iconCls = iconCls.iconCls;
    }
    cls = cls || baseCls;
    return format(tpl, [cls, iconCls].join(" "), tip || "", style || "", action || "");
  };
}();
var iconTextFn = function() {
  const baseStyle = "height:16px;line-height:16px;";
  const tpl = '<div class="{0}" style="' + baseStyle + '{1}" {2}>{3}&#160;{4}</div>';
  return function(textArgs) {
    if (typeof textArgs === "string") {
      textArgs = { text: textArgs };
    }
    const iconArgs = Array.prototype.slice.call(arguments, 1);
    let text = textArgs.text;
    const textTip = textArgs.tip || text;
    text = "<span " + (textArgs.action ? 'class="sim-link" action="' + textArgs.action + '"' : "") + ' data-hint="' + config.encode(textTip) + '">' + text + "</span>";
    return format(
      tpl,
      textArgs.cls || "",
      textArgs.style || "",
      textArgs.attr || "",
      iconFn.apply(this, iconArgs),
      text
    );
  };
}();
export {
  iconActionFn,
  iconFn,
  iconTextFn
};
