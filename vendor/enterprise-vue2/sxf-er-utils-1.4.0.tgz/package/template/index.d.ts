declare function iconFn(iconCls: any, tip: any, cls: any, style: any, attr: any): string;
declare function iconActionFn(iconCls: any, action: any, tip: any, cls: any, style: any): string;
declare function iconTextFn(textArgs: any, ...args: any[]): string;

export { iconActionFn, iconFn, iconTextFn };
