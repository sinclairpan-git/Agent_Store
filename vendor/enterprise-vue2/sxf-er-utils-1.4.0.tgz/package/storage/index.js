// packages/utils/storage/index.js
import logger from "@sxf/er-utils/logger";
var storageLogger = logger("storage");
var ls = null;
try {
  const _mod = "window.localStorage";
  ls = window.localStorage;
  ls.setItem(_mod, _mod);
  ls.removeItem(_mod);
} catch (e) {
  storageLogger.error("the browser don't support localStorage");
  ls = null;
}
var NS = location.pathname.replace(/\/[^\/]*$/, "") || "/";
var cache = {};
function getKey(key, ns) {
  ns = ns || NS;
  const d = cache[ns] || getStorageItem(ns);
  if (!d) {
    return;
  }
  cache[ns] = d;
  if (!key || !key.length) {
    return cache[ns];
  }
  const arrKey = key.split(".");
  let i = arrKey[0] === ns ? 1 : 0, c = cache[ns];
  for (; i < arrKey.length; i++) {
    if (!c[arrKey[i]] && c[arrKey[i]] !== 0) {
      storageLogger.debug(arrKey[i] + " is undefined");
      return null;
    }
    c = c[arrKey[i]];
  }
  return c;
}
function getStorageItem(ns) {
  let res = null;
  try {
    res = JSON.parse(ls.getItem(ns));
  } catch (e) {
    storageLogger.debug(e);
  }
  return res;
}
function getAllData(ns) {
  ns = ns || NS;
  return getKey(false, ns);
}
function setKey(key, value, ns) {
  if (!key) {
    return;
  }
  ns = ns || NS;
  cache[ns] = cache[ns] || {};
  const arrKey = key.split(".");
  let i = arrKey[0] === ns ? 1 : 0, c = cache[ns];
  try {
    JSON.stringify(value);
  } catch (e) {
    storageLogger.debug(value + "is not an illegal value");
    return;
  }
  for (; i < arrKey.length - 1; i++) {
    if (!c[arrKey[i]]) {
      if (value === void 0 || value === null) {
        storageLogger.debug(arrKey[i] + " not exist");
        return void 0;
      }
      storageLogger.debug(arrKey[i] + " create {}");
      c[arrKey[i]] = {};
    }
    c = c[arrKey[i]];
  }
  const lv = c[arrKey[i]];
  if (value === void 0 || value === null) {
    delete c[arrKey[i]];
  } else {
    c[arrKey[i]] = value;
  }
  return lv;
}
function saveModify(ns) {
  ns = ns || NS;
  if (cache[ns]) {
    if (ls.getItem(ns)) {
      storageLogger.debug(ns + " is not defined, create {}");
    }
    ls.setItem(ns, JSON.stringify(cache[ns]));
  } else {
    delete ls[ns];
  }
}
function clearCacheFn(ns) {
  ns = ns || NS;
  delete cache[ns];
}
function setDefaultNameSpace(ns) {
  NS = ns;
}
function empty() {
}
var get = ls ? getKey : empty;
var getAll = ls ? getAllData : empty;
var set = ls ? setKey : empty;
var save = ls ? saveModify : empty;
var clearCache = ls ? clearCacheFn : empty;
var setDeafultNameSpace = ls ? setDefaultNameSpace : empty;
export {
  clearCache,
  get,
  getAll,
  save,
  set,
  setDeafultNameSpace
};
