/**
 * 获取key的值
 *
 * @param {string} [key] - 键名，不传则返回所有
 * @param {string} [ns] - 命名空间，默认为 '/'
 * @returns {null|*}
 * @example
 * // 返回 VMP.a.b.c 的值
 * get('a.b.c')
 *
 * // 返回 VMP 的值
 * get()
 */
declare function get(key?: string | undefined, ns?: string | undefined): null | any;
/**
 * 返回命名空间的数据
 *
 * @param {string} [ns] - 命名空间，默认为 '/'
 * @returns {null|*}
 */
declare function getAll(ns?: string | undefined): null | any;
/**
 * 设置键值，在调用save后才写入localstorage
 *
 * @param {string} key - 完整变量名，'console.name' or 'VMP.console.name'，不存在则创建
 * @param {*} value - 设置的值，为null or undefined 则删除变量
 * @param {string} [ns] - 命名空间，默认为 '/'
 * @returns {undefined | *}
 * @example
 * // 设置 VMP.a.b.c 的值为 1
 * set('a.b.c', 1)
 *
 * // 删除 VMP.a.b.c
 * set('a.b.c', null)
 */
declare function set(key: string, value: any, ns?: string | undefined): undefined | any;
/**
 * 保存修改到localStorage
 *
 * @param {string} [ns] - 命名空间，默认为 '/'
 */
declare function save(ns?: string | undefined): void;
/**
 * 删除从localStorage[ns]读取到的保存在内存中的值，调用save才会保存
 *
 * @param {string} [ns] - 命名空间，默认为 '/'
 */
declare function clearCache(ns?: string | undefined): void;
/**
 * 设置默认命名空间
 *
 * @param {string} ns - 命名空间，默认为 '/'
 */
declare function setDeafultNameSpace(ns: string): void;

export { clearCache, get, getAll, save, set, setDeafultNameSpace };
