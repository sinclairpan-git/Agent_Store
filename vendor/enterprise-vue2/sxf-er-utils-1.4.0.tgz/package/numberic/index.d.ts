declare function byteSize(v: number, decimal?: number | string | undefined, sizeHandle?: string | undefined, level?: string | undefined): Data;
declare function Bps(v: number, decimal?: number | string | undefined, sizeHandle?: string | undefined, level?: string | undefined): Data;
declare function bitRate(v: number, decimal?: number | string | undefined, sizeHandle?: string | undefined, level?: string | undefined): Data;
declare function bps(v: number, decimal?: number | string | undefined, sizeHandle?: string | undefined, level?: string | undefined): Data;
declare function xybps(v: number, decimal?: number | string | undefined, sizeHandle?: string | undefined, level?: string | undefined): Data;
declare function hertz(v: number, decimal?: number | string | undefined, sizeHandle?: string | undefined, level?: string | undefined): Data;
declare function Mhertz(v: number, d?: number | undefined, sizeHandle?: string | undefined): Data;
type DataSizeFunction = (v: number, decimal?: number | string | undefined, sizeHandle?: string | undefined, level?: string | undefined) => Data;
/**
 * 数据类型构造函数
 *
 * @param n 显示的数值部分
 * @param l 显示的数量级
 * @param u 显示的单位
 * @param v 原始数值
 * @param s 原始数值进制
 * @param sizeHandle 处理数值的方法
 * @param levels 进制的单位
 * @param decimal 保留小数位数
 * @returns {Data}
 * @constructor
 */
declare function Data(n: any, l: any, u: any, v: any, s: any, sizeHandle: any, levels: any, decimal: any): Data;
declare class Data {
    /**
     * 数据类型构造函数
     *
     * @param n 显示的数值部分
     * @param l 显示的数量级
     * @param u 显示的单位
     * @param v 原始数值
     * @param s 原始数值进制
     * @param sizeHandle 处理数值的方法
     * @param levels 进制的单位
     * @param decimal 保留小数位数
     * @returns {Data}
     * @constructor
     */
    constructor(n: any, l: any, u: any, v: any, s: any, sizeHandle: any, levels: any, decimal: any);
    number: any;
    level: any;
    unit: any;
    value: any;
    step: any;
    sizeHandle: any;
    levels: any;
    decimal: any;
    times: number | undefined;
    /**
     * 计算并返回带单位的数值字符串
     *
     * @param {string} [level] - 给定单位级别，默认为Numberic实例当前级别下的数值
     * @param {number} [decimal] - 默认为实例当前保留小数点位数
     * @param {string} [sizeHandle] - 处理数据保留小数位的方法
     * @param {boolean} [reserveDecimal] - 表示是否保留小数
     * @returns {string}
     */
    toString(level?: string | undefined, decimal?: number | undefined, sizeHandle?: string | undefined, reserveDecimal?: boolean | undefined): string;
    /**
     * 计算并返回指定级别的数值
     *
     * @param {string} [level] - 给定单位级别，默认为Numberic实例当前级别下的数值
     * @param {number} [decimal] - 默认为实例当前保留小数点位数
     * @param {string} [sizeHandle] - 处理数据保留小数位的方法
     * @returns {Number}
     */
    toNumber(level?: string | undefined, decimal?: number | undefined, sizeHandle?: string | undefined): number;
    /**
     * 计算并返回指定最小级别的数值字符串
     *
     * @param {string} minLevel - 【必选】 给定单位级别，表示转化的最小单位
     * @param {number} [decimal] - 给定保留小数位数
     * @param {string} [sizeHandle] - 处理数据保留小数位的方法
     * @param {boolean} [reserveDecimal] - 表示是否保留小数
     * @returns {string}
     */
    toLevelString(minLevel: string, decimal?: number | undefined, sizeHandle?: string | undefined, reserveDecimal?: boolean | undefined): string;
    levelIndex(): any;
}
/**
 * @callback DataSizeFunction
 * @param {number} v - 待转换的数值
 * @param {number|string|undefined} [decimal] - 保留小数位数或单位
 * @param {string} [sizeHandle] - 大小写处理方式
 * @param {string} [level] - 转换后的单位等级
 * @returns {Data} 转换结果
 */
/**
 *
 * @param {string} _unit 转换后的单位
 * @param {number} _step 转换单位的步长
 * @param {string[]} _levels 单位等级列表
 * @returns {DataSizeFunction} 转换函数
 */
declare function dataSize(_unit: string, _step: number, _levels: string[]): DataSizeFunction;
declare namespace dataSize {
    const UNRECOGNIZE: string;
    const autoTrim: boolean;
    function byteSize(v: number, decimal?: string | number | undefined, sizeHandle?: string | undefined, level?: string | undefined): Data;
    function Bps(v: number, decimal?: string | number | undefined, sizeHandle?: string | undefined, level?: string | undefined): Data;
    function bitRate(v: number, decimal?: string | number | undefined, sizeHandle?: string | undefined, level?: string | undefined): Data;
    function bps(v: number, decimal?: string | number | undefined, sizeHandle?: string | undefined, level?: string | undefined): Data;
    function xybps(v: number, decimal?: string | number | undefined, sizeHandle?: string | undefined, level?: string | undefined): Data;
    function hertz(v: number, decimal?: string | number | undefined, sizeHandle?: string | undefined, level?: string | undefined): Data;
    function Mhertz(v: number, d?: number | undefined, sizeHandle?: string | undefined): Data;
}

export { Bps, DataSizeFunction, Mhertz, bitRate, bps, byteSize, dataSize, dataSize as default, hertz, xybps };
