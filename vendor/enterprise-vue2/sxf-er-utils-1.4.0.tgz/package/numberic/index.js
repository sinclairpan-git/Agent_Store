// packages/utils/numberic/dataSize.js
var NAN = {};
var NumberRegex = /^\d+(?:\.\d+)?$/;
var LEVELS = [
  "",
  "K",
  "M",
  "G",
  "T",
  "P"
  /*, "E", "Z", "Y", "B"*/
];
var preProcess = function(v) {
  if (!NumberRegex.test(String(v))) {
    return NAN;
  }
  v = parseFloat(v);
  return isNaN(v) ? NAN : v;
};
var handle = function(value, precision, sizeHandle) {
  if (typeof precision !== "number") {
    precision = 2;
  }
  precision = Math.pow(10, precision);
  sizeHandle = Math[sizeHandle || "round"];
  return sizeHandle(value * precision) / precision;
};
function Data(n, l, u, v, s, sizeHandle, levels, decimal) {
  if (!(this instanceof Data)) {
    return new Data(n, l, u, v, s, sizeHandle, levels, decimal);
  }
  this.number = n;
  this.level = l;
  this.unit = u;
  this.value = v;
  this.step = s;
  this.sizeHandle = sizeHandle;
  this.levels = levels || LEVELS;
  this.decimal = decimal || 2;
  this.times = Math.pow(this.step, this.levelIndex());
}
Data.prototype.toString = function(level, decimal, sizeHandle, reserveDecimal) {
  const unit = this.levels.indexOf(level) >= 0 ? level + this.unit : this.level + this.unit;
  const number = this.toNumber(level, decimal, sizeHandle);
  return (reserveDecimal ? number.toFixed(decimal) : number) + " " + unit;
};
Data.prototype.toNumber = function(level, decimal, sizeHandle) {
  let value = this.value;
  let levelIndex = 0;
  const targetLevelIndex = this.levels.indexOf(level);
  if (targetLevelIndex < 0) {
    return this.number;
  }
  if (typeof this.value === "undefined") {
    return 0;
  }
  while (levelIndex < targetLevelIndex) {
    value = value / this.step;
    levelIndex++;
  }
  return handle(
    value,
    typeof decimal !== "undefined" ? decimal : this.decimal,
    typeof sizeHandle !== "undefined" ? sizeHandle : this.sizeHandle
  );
};
Data.prototype.toLevelString = function(minLevel, decimal, sizeHandle, reserveDecimal) {
  const number = this.toNumber(minLevel);
  const level = number <= this.step ? minLevel : this.level;
  return this.toString(level, decimal, sizeHandle, reserveDecimal);
};
Data.prototype.levelIndex = function() {
  return this.levels.indexOf(this.level);
};
var dataSize = function(_unit, _step, _levels) {
  _levels = _levels || LEVELS;
  return function(v, decimal, sizeHandle, level) {
    v = preProcess(v);
    if (NAN === v) {
      v = 0;
    }
    if (typeof decimal === "string" && !level) {
      level = decimal;
      decimal = null;
    }
    if (typeof sizeHandle === "string" && !level) {
      level = sizeHandle;
      sizeHandle = null;
    }
    if (level) {
      level = level.toUpperCase();
    }
    let pi = 0;
    const len = _levels.length;
    let levelIndex = _levels.indexOf(level);
    levelIndex = Math.max(levelIndex, 0);
    v = v * Math.pow(_step, levelIndex);
    const oriValue = v;
    while (v >= _step && pi + 1 < len) {
      v /= _step;
      pi++;
    }
    v = handle(v, decimal, sizeHandle);
    if (dataSize.autoTrim) {
      v = parseFloat(v);
    }
    return new Data(v, _levels[pi], _unit, oriValue, _step, sizeHandle, _levels, decimal);
  };
};
dataSize.UNRECOGNIZE = "-";
dataSize.autoTrim = true;
dataSize.byteSize = dataSize("B", 1024);
dataSize.Bps = dataSize("Bps", 1024);
dataSize.bitRate = dataSize("b", 1e3);
dataSize.bps = dataSize("bps", 1e3);
dataSize.xybps = dataSize("bps", 1024);
dataSize.hertz = dataSize("Hz", 1e3);
dataSize.Mhertz = function() {
  const hertz2 = dataSize.hertz;
  return function(v, d, sizeHandle) {
    return hertz2(v, d, sizeHandle, "M");
  };
}();
var byteSize = dataSize.byteSize;
var Bps = dataSize.Bps;
var bitRate = dataSize.bitRate;
var bps = dataSize.bps;
var xybps = dataSize.xybps;
var hertz = dataSize.hertz;
var Mhertz = dataSize.Mhertz;

// packages/utils/numberic/index.js
var numberic_default = dataSize;
export {
  Bps,
  Mhertz,
  bitRate,
  bps,
  byteSize,
  dataSize,
  numberic_default as default,
  hertz,
  xybps
};
