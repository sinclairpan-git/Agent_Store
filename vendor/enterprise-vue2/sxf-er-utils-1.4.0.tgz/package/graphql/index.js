// packages/utils/graphql/hooks/index.js
var linkHooks = [];
var addGraphqlHook = (link) => {
  linkHooks.push(link);
};
export {
  addGraphqlHook,
  linkHooks
};
