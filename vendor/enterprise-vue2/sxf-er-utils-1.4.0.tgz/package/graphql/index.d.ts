/**
 * @file graphql添加hook的通用函数，可以拓展给其他应用使用
 */
declare const linkHooks: any[];
declare function addGraphqlHook(link: any): void;

export { addGraphqlHook, linkHooks };
