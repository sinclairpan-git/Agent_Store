/**
 * 解析IPv4，返回一个ipaddr库定义的IPv4地址对象，可以使用其中对IPv4进行处理或校验的方法
 *
 * @param {string} ip
 * @returns {object} IPv4
 */
declare function parse$1(ip: string): object;
/**
 * 将IPv4格式的网络掩码转换成前缀长度
 *
 * @param {object} ip IPv4
 * @returns {number} 前缀长度
 */
declare function prefixLengthFromSubnetMask(ip: object): number;
/**
 * 将前缀长度转换成IPv4格式的网络掩码
 *
 * @param {number} prefixLen 前缀长度
 * @returns {string} IPv4网络掩码
 */
declare function subnetMaskFromPrefixLength(prefixLen: number): string;

declare const ipParse_prefixLengthFromSubnetMask: typeof prefixLengthFromSubnetMask;
declare const ipParse_subnetMaskFromPrefixLength: typeof subnetMaskFromPrefixLength;
declare namespace ipParse {
  export {
    parse$1 as parse,
    ipParse_prefixLengthFromSubnetMask as prefixLengthFromSubnetMask,
    ipParse_subnetMaskFromPrefixLength as subnetMaskFromPrefixLength,
  };
}

/**
 * 解析ipv6
 *
 * @param {string} ip
 * @returns {object} IPv6
 */
declare function parse(ip: string): object;
/**
 * 比较两个ip的大小
 * -1： left > right
 * 1： left < right
 * 0: ip 相等
 * false : ip 转化失败，或者无法比较，或者ipv4 ipv6混合比较
 *
 * @param {string} left ip
 * @param {string} right ip
 * @returns {boolean|number} 比较结果
 */
declare function compareIp(left: string, right: string): boolean | number;
/**
 * 判断ipv6地址是否处于同网段
 *
 * @param {*} ip
 * @param {*} prefix 前缀长度
 * @param {*} gateway
 */
declare function isSameSegment(ip: any, prefix: any, gateway: any): any;

declare const ipv6Parse_compareIp: typeof compareIp;
declare const ipv6Parse_isSameSegment: typeof isSameSegment;
declare const ipv6Parse_parse: typeof parse;
declare namespace ipv6Parse {
  export {
    ipv6Parse_compareIp as compareIp,
    ipv6Parse_isSameSegment as isSameSegment,
    ipv6Parse_parse as parse,
  };
}

declare function ip(options: any): RegExp;
declare namespace ip {
    function v4(options: any): RegExp;
    function v6(options: any): RegExp;
}

export { ipParse, ip as ipRegex, ipv6Parse };
