# @sxf/er-utils

各种业务相关的工具库，包括 ajax 等...

```js
// 格式化相关方法
import format from '@sxf/er-utils/format';

format.ip2bit('192.168.1.1'); // '11000000101010000000000100000001'
```

```js
import { defineRequest } from '@sxf/er-utils/request';

const fn = defineRequest({
  url: '/req/{id}',
  type: 'get',
  urlParams(params) {
    return {
      id: params.id,
    };
  },
});

fn();
```