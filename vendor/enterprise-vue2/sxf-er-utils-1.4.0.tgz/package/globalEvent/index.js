// packages/utils/globalEvent/index.js
import cookies from "@sxf/er-utils/cookies";
import logger from "@sxf/er-utils/logger";
import Observable from "@sxf/er-utils/observable";
var globalEventLogger = logger("global event");
var ACTION_PREFIX = "a_";
var GlobalManager = class extends Observable {
  /**
   * 触发action
   *
   * @function
   * @param {string} action - 操作名
   * @param {...*} [args] - 参数列表
   * @example
   * globalMgr.emitAction('click', 'button');
   */
  emitAction(action, ...args) {
    return this.emit(action, ...args);
  }
  /**
   * 添加action
   *
   * @function
   * @param {string} action - 操作名
   * @param {function} listener - 监听器
   * @example
   * globalMgr.onAction('click', function(button) {
   *   console.log('clicked', button);
   * });
   */
  onAction(action, ...args) {
    return this.on(action, ...args);
  }
  /**
   * 添加Cookies
   *
   * @function
   * @param {string} action - 操作名
   * @param {Object} [param={ noParam: 1 }] - 参数对象
   * @returns {void}
   * @example
   * globalMgr.globalEmit('click', { button: 'submit' });
   */
  globalEmit(action, param = { noParam: 1 }) {
    cookies.set(ACTION_PREFIX + action, JSON.stringify(param));
  }
  /**
   * 检测Cookies后清除cookie
   *
   * @function
   * @param {string} action - 操作名
   * @param {function} fn - 回调函数
   * @returns {void}
   * @example
   * globalMgr.globalOn('click', function(param) {
   *   console.log('clicked', param.button);
   * });
   */
  globalOn(action, fn) {
    let param = cookies.get(ACTION_PREFIX + action);
    if (param) {
      param = JSON.parse(param);
      if (param.noParam) {
        fn();
      } else {
        fn(param);
      }
    }
    cookies.clear(ACTION_PREFIX + action);
  }
  /**
   * 带有日志记录的触发action
   *
   * @function
   * @param {string} name - 操作名
   * @param {...*} [args] - 参数列表
   * @example
   * globalMgr.emitActionWithLogging('click', 'button');
   */
  emitActionWithLogging(name, ...args) {
    globalEventLogger.debug("from ", name);
    return this.emitAction(...args);
  }
};
var globalEvent_default = new GlobalManager();
export {
  globalEvent_default as default
};
