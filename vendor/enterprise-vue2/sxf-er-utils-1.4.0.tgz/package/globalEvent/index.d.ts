import Observable from '../observable/index.js';

declare const _default: GlobalManager;

declare class GlobalManager extends Observable {
    /**
     * 触发action
     *
     * @function
     * @param {string} action - 操作名
     * @param {...*} [args] - 参数列表
     * @example
     * globalMgr.emitAction('click', 'button');
     */
    emitAction(action: string, ...args?: any[] | undefined): boolean;
    /**
     * 添加action
     *
     * @function
     * @param {string} action - 操作名
     * @param {function} listener - 监听器
     * @example
     * globalMgr.onAction('click', function(button) {
     *   console.log('clicked', button);
     * });
     */
    onAction(action: string, ...args: any[]): Observable;
    /**
     * 添加Cookies
     *
     * @function
     * @param {string} action - 操作名
     * @param {Object} [param={ noParam: 1 }] - 参数对象
     * @returns {void}
     * @example
     * globalMgr.globalEmit('click', { button: 'submit' });
     */
    globalEmit(action: string, param?: Object | undefined): void;
    /**
     * 检测Cookies后清除cookie
     *
     * @function
     * @param {string} action - 操作名
     * @param {function} fn - 回调函数
     * @returns {void}
     * @example
     * globalMgr.globalOn('click', function(param) {
     *   console.log('clicked', param.button);
     * });
     */
    globalOn(action: string, fn: Function): void;
    /**
     * 带有日志记录的触发action
     *
     * @function
     * @param {string} name - 操作名
     * @param {...*} [args] - 参数列表
     * @example
     * globalMgr.emitActionWithLogging('click', 'button');
     */
    emitActionWithLogging(name: string, ...args?: any[] | undefined): boolean;
}

export { _default as default };
