declare namespace x {
    function isEmpty(v: any, allowBlank: boolean): boolean;
    const isArray: (arg: any) => arg is any[];
    function isDate(obj: any): boolean;
    function isObject(obj: any): boolean;
    function isPrimitive(value: unknown): boolean;
    function isFunction(value: unknown): boolean;
    function isNumber(v: any): boolean;
    function isNumeric(value: Object): boolean;
    function isString(v: any): boolean;
    function isBoolean(v: any): boolean;
    function isElement(value: unknown): boolean;
    function isTextNode(value: Object): boolean;
    function isDefined(v: any): boolean;
    function isIterable(value: Object): boolean;
    function isNull(obj: any): boolean;
}

export { x as default };
