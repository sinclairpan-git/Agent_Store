// packages/utils/lang/index.js
function toString(obj) {
  return Object.prototype.toString.call(obj);
}
function isType(type) {
  return function(obj) {
    return toString(obj) === "[object " + type + "]";
  };
}
var isObject = isType("Object");
var polyfill = function(value) {
  return value !== null && value !== void 0 && isObject(value) && value.ownerDocument === void 0;
};
var x = {
  /**
   * <p>Returns true if the passed value is empty.</p>
   * <p>The value is deemed to be empty if it is<div class="mdetail-params"><ul>
   * <li>null</li>
   * <li>undefined</li>
   * <li>an empty array</li>
   * <li>a zero length string (Unless the <tt>allowBlank</tt> parameter is <tt>true</tt>)</li>
   * </ul></div>
   *
   * @param {unknown} value The value to test
   * @param {Boolean} allowBlank (optional) true to allow empty strings (defaults to false)
   * @return {Boolean}
   */
  isEmpty: function(v, allowBlank) {
    return v === null || v === void 0 || x.isArray(v) && !v.length || (!allowBlank ? v === "" : false);
  },
  /**
   * Returns true if the passed value is a JavaScript array, otherwise false.
   *
   * @param {unknown} value The value to test
   * @return {Boolean}
   */
  isArray: Array.isArray || isType("Array"),
  /**
   * Returns true if the passed object is a JavaScript date object, otherwise false.
   *
   * @param {Object} object The object to test
   * @return {Boolean}
   */
  isDate: isType("Date"),
  /**
   * Returns true if the passed value is a JavaScript Object, otherwise false.
   *
   * @param {unknown} value The value to test
   * @return {Boolean}
   */
  isObject: isObject(null) ? polyfill : isObject,
  /**
   * Returns true if the passed value is a JavaScript 'primitive', a string, number, boolean, undefined, null or symbol.
   *
   * @param {unknown} value The value to test
   * @return {Boolean}
   */
  isPrimitive: function(value) {
    const type = typeof value;
    if (value === null) {
      return true;
    }
    if (type === "number") {
      return x.isNumeric(value);
    }
    return type === "string" || type === "boolean" || type === "undefined" || type === "symbol";
  },
  /**
   * Returns true if the passed value is a JavaScript Function, otherwise false.
   *
   * @param {unknown} value The value to test
   * @return {Boolean}
   */
  isFunction: function(value) {
    return typeof value === "function";
  },
  /**
   * Returns true if the passed value is a number. Returns false for non-finite numbers.
   *
   * @param {unknown} value The value to test
   * @return {Boolean}
   */
  isNumber: function(v) {
    return typeof v === "number" && isFinite(v);
  },
  /**
   * Validates that a value is numeric.
   *
   * @param {Object} value Examples: 1, '1', '2.34'
   * @return {Boolean} True if numeric, false otherwise
   */
  isNumeric: function(value) {
    return !isNaN(parseFloat(value)) && isFinite(value);
  },
  /**
   * Returns true if the passed value is a string.
   *
   * @param {unknown} value The value to test
   * @return {Boolean}
   */
  isString: function(v) {
    return typeof v === "string";
  },
  /**
   * Returns true if the passed value is a boolean.
   *
   * @param {unknown} value The value to test
   * @return {Boolean}
   */
  isBoolean: function(v) {
    return typeof v === "boolean";
  },
  /**
   * Returns true if the passed value is an HTMLElement
   *
   * @param {unknown} value The value to test
   * @return {Boolean}
   */
  isElement: function(value) {
    return value ? value.nodeType === 1 : false;
  },
  /**
   * Returns true if the passed value is a TextNode
   *
   * @param {Object} value The value to test
   * @return {Boolean}
   */
  isTextNode: function(value) {
    return value ? value.nodeName === "#text" : false;
  },
  /**
   * Returns true if the passed value is not undefined.
   *
   * @param {unknown} value The value to test
   * @return {Boolean}
   */
  isDefined: function(v) {
    return typeof v !== "undefined";
  },
  /**
   * Returns true if the passed value is iterable, false otherwise
   *
   * @param {Object} value The value to test
   * @return {Boolean}
   */
  isIterable: function(value) {
    if (value === null || value === void 0) {
      return false;
    }
    return typeof value[Symbol.iterator] === "function";
  },
  isNull: isType("Null")
};
var lang_default = x;
export {
  lang_default as default
};
