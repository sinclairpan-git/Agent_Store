// packages/utils/ua/index.js
function initBrowser(ua, doc, win) {
  ua = (ua || "").toLowerCase();
  const check = function(regex) {
    return regex.test(ua);
  }, isStrict = doc.compatMode == "CSS1Compat", version = function(is, regex) {
    let m;
    return is && (m = regex.exec(ua)) ? parseFloat(m[1]) : 0;
  }, docMode = doc.documentMode, isOpera = check(/opera/), isOpera10_5 = isOpera && check(/version\/10\.5/), isChrome = check(/\bchrome\b/), isWebKit = check(/webkit/), isSafari = !isChrome && check(/safari/), isSafari2 = isSafari && check(/applewebkit\/4/), isSafari3 = isSafari && check(/version\/3/), isSafari4 = isSafari && check(/version\/4/), isSafari5_0 = isSafari && check(/version\/5\.0/), isSafari5 = isSafari && check(/version\/5/), isIE = !isOpera && (check(/msie/) || check(/trident\/\d\.\d/) || check(/edge\/\d+\.\d+/)), isIE7 = isIE && (check(/msie 7/) && [8, 9, 10, 11].indexOf(docMode) < 0 || docMode == 7), isIE8 = isIE && (check(/msie 8/) && [7, 9, 10, 11].indexOf(docMode) < 0 || docMode == 8), isIE9 = isIE && (check(/msie 9/) && [7, 8, 10, 11].indexOf(docMode) < 0 || docMode == 9), isIE10 = isIE && (check(/msie 10/) && [7, 8, 9, 11].indexOf(docMode) < 0 || docMode == 10), isIE11 = isIE && check(/trident\/7.0/) && check(/rv:11/) && [7, 8, 9, 10].indexOf(docMode) < 0 || docMode == 11, isIE6 = isIE && check(/msie 6/), isGecko = !isWebKit && check(/gecko/) && !isIE, isGecko3 = isGecko && check(/rv:1\.9/), isGecko4 = isGecko && check(/rv:2\.0/), isGecko5 = isGecko && check(/rv:5\./), isGecko10 = isGecko && check(/rv:10\./), isFF3_0 = isGecko3 && check(/rv:1\.9\.0/), isFF3_5 = isGecko3 && check(/rv:1\.9\.1/), isFF3_6 = isGecko3 && check(/rv:1\.9\.2/), isWindows = check(/windows|win32/), isMac = check(/macintosh|mac os x/), isBorderBox = isIE && !isStrict, isLinux = check(/linux/), chromeVersion = version(true, /\bchrome\/(\d+\.\d+)/), firefoxVersion = version(true, /\bfirefox\/(\d+\.\d+)/), ieVersion = isIE11 ? 11 : version(isIE, /msie (\d+\.\d+)/), operaVersion = version(isOpera, /version\/(\d+\.\d+)/), safariVersion = version(isSafari, /version\/(\d+\.\d+)/), webKitVersion = version(isWebKit, /webkit\/(\d+\.\d+)/), isSecure = /^https/i.test(win.location.protocol);
  return {
    /**
     * @property {String} SSL_SECURE_URL
     * URL to a blank file used by Ext when in secure mode for iframe src and onReady src
     * to prevent the IE insecure content warning (`'about:blank'`, except for IE
     * in secure mode, which is `'javascript:""'`).
     */
    /*jshint scripturl:true*/
    SSL_SECURE_URL: isSecure && isIE ? "javascript:''" : "about:blank",
    isStrict,
    // IE10p quirks behaves like Gecko/WebKit quirks, so don't include it here
    isIEQuirks: isIE && !isStrict && (isIE6 || isIE7 || isIE8 || isIE9),
    /**
     * True if the detected browser is Opera.
     *
     * @type Boolean
     */
    isOpera,
    /**
     * True if the detected browser is Opera 10.5x.
     *
     * @type Boolean
     */
    isOpera10_5,
    /**
     * True if the detected browser uses WebKit.
     *
     * @type Boolean
     */
    isWebKit,
    /**
     * True if the detected browser is Chrome.
     *
     * @type Boolean
     */
    isChrome,
    /**
     * True if the detected browser is Safari.
     *
     * @type Boolean
     */
    isSafari,
    /**
     * True if the detected browser is Safari 3.x.
     *
     * @type Boolean
     */
    isSafari3,
    /**
     * True if the detected browser is Safari 4.x.
     *
     * @type Boolean
     */
    isSafari4,
    /**
     * True if the detected browser is Safari 5.x.
     *
     * @type Boolean
     */
    isSafari5,
    /**
     * True if the detected browser is Safari 5.0.x.
     *
     * @type Boolean
     */
    isSafari5_0,
    /**
     * True if the detected browser is Safari 2.x.
     *
     * @type Boolean
     */
    isSafari2,
    /**
     * True if the detected browser is Internet Explorer.
     *
     * @type Boolean
     */
    isIE,
    /**
     * True if the detected browser is Internet Explorer 6.x.
     *
     * @type Boolean
     */
    isIE6,
    /**
     * True if the detected browser is Internet Explorer 7.x.
     *
     * @type Boolean
     */
    isIE7,
    /**
     * True if the detected browser is Internet Explorer 7.x or lower.
     *
     * @type Boolean
     */
    isIE7m: isIE6 || isIE7,
    /**
     * True if the detected browser is Internet Explorer 7.x or higher.
     *
     * @type Boolean
     */
    isIE7p: isIE && !isIE6,
    /**
     * True if the detected browser is Internet Explorer 8.x.
     *
     * @type Boolean
     */
    isIE8,
    /**
     * True if the detected browser is Internet Explorer 8.x or lower.
     *
     * @type Boolean
     */
    isIE8m: isIE6 || isIE7 || isIE8,
    /**
     * True if the detected browser is Internet Explorer 8.x or higher.
     *
     * @type Boolean
     */
    isIE8p: isIE && !(isIE6 || isIE7),
    /**
     * True if the detected browser is Internet Explorer 9.x.
     *
     * @type Boolean
     */
    isIE9,
    /**
     * True if the detected browser is Internet Explorer 9.x or lower.
     *
     * @type Boolean
     */
    isIE9m: isIE6 || isIE7 || isIE8 || isIE9,
    /**
     * True if the detected browser is Internet Explorer 9.x or higher.
     *
     * @type Boolean
     */
    isIE9p: isIE && !(isIE6 || isIE7 || isIE8),
    /**
     * True if the detected browser is Internet Explorer 10.x.
     *
     * @type Boolean
     */
    isIE10,
    /**
     * True if the detected browser is Internet Explorer 10.x or lower.
     *
     * @type Boolean
     */
    isIE10m: isIE6 || isIE7 || isIE8 || isIE9 || isIE10,
    /**
     * True if the detected browser is Internet Explorer 10.x or higher.
     *
     * @type Boolean
     */
    isIE10p: isIE && !(isIE6 || isIE7 || isIE8 || isIE9),
    /**
     * True if the detected browser is Internet Explorer 11.x.
     *
     * @type Boolean
     */
    isIE11,
    /**
     * True if the detected browser is Internet Explorer 11.x or lower.
     *
     * @type Boolean
     */
    isIE11m: isIE6 || isIE7 || isIE8 || isIE9 || isIE10 || isIE11,
    /**
     * True if the detected browser is Internet Explorer 11.x or higher.
     *
     * @type Boolean
     */
    isIE11p: isIE && !(isIE6 || isIE7 || isIE8 || isIE9 || isIE10),
    /**
     * True if the detected browser uses the Gecko layout engine (e.g. Mozilla, Firefox).
     *
     * @type Boolean
     */
    isGecko,
    /**
     * True if the detected browser uses a Gecko 1.9+ layout engine (e.g. Firefox 3.x).
     *
     * @type Boolean
     */
    isGecko3,
    /**
     * True if the detected browser uses a Gecko 2.0+ layout engine (e.g. Firefox 4.x).
     *
     * @type Boolean
     */
    isGecko4,
    /**
     * True if the detected browser uses a Gecko 5.0+ layout engine (e.g. Firefox 5.x).
     *
     * @type Boolean
     */
    isGecko5,
    /**
     * True if the detected browser uses a Gecko 5.0+ layout engine (e.g. Firefox 5.x).
     *
     * @type Boolean
     */
    isGecko10,
    /**
     * True if the detected browser uses FireFox 3.0
     *
     * @type Boolean
     */
    isFF3_0,
    /**
     * True if the detected browser uses FireFox 3.5
     *
     * @type Boolean
     */
    isFF3_5,
    /**
     * True if the detected browser uses FireFox 3.6
     *
     * @type Boolean
     */
    isFF3_6,
    /**
     * True if the detected browser uses FireFox 4
     *
     * @type Boolean
     */
    isFF4: 4 <= firefoxVersion && firefoxVersion < 5,
    /**
     * True if the detected browser uses FireFox 5
     *
     * @type Boolean
     */
    isFF5: 5 <= firefoxVersion && firefoxVersion < 6,
    /**
     * True if the detected browser uses FireFox 10
     *
     * @type Boolean
     */
    isFF10: 10 <= firefoxVersion && firefoxVersion < 11,
    /**
     * True if the detected platform is Linux.
     *
     * @type Boolean
     */
    isLinux,
    /**
     * True if the detected platform is Windows.
     *
     * @type Boolean
     */
    isWindows,
    /**
     * True if the detected platform is Mac OS.
     *
     * @type Boolean
     */
    isMac,
    /**
     * The current version of Chrome (0 if the browser is not Chrome).
     *
     * @type Number
     */
    chromeVersion,
    /**
     * The current version of Firefox (0 if the browser is not Firefox).
     *
     * @type Number
     */
    firefoxVersion,
    /**
     * The current version of IE (0 if the browser is not IE). This does not account
     * for the documentMode of the current page, which is factored into {@link #isIE7},
     * {@link #isIE8} and {@link #isIE9}. Thus this is not always true:
     *
     *     Ext.isIE8 == (Ext.ieVersion == 8)
     *
     * @type Number
     */
    ieVersion,
    /**
     * The current version of Opera (0 if the browser is not Opera).
     *
     * @type Number
     */
    operaVersion,
    /**
     * The current version of Safari (0 if the browser is not Safari).
     *
     * @type Number
     */
    safariVersion,
    /**
     * The current version of WebKit (0 if the browser does not use WebKit).
     *
     * @type Number
     */
    webKitVersion,
    /**
     * True if the page is running over SSL
     *
     * @type Boolean
     */
    isSecure,
    isBorderBox
  };
}
var ua_default = initBrowser(navigator.userAgent, document, window);
export {
  ua_default as default
};
