// packages/utils/browser/index.js
var opr = {};
opr.closeWin = function() {
  window.open("", "_self").close();
};
var browser_default = opr;
export {
  browser_default as default
};
