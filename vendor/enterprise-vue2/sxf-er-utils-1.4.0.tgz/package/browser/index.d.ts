declare namespace opr {
    function closeWin(): void;
}

export { opr as default };
