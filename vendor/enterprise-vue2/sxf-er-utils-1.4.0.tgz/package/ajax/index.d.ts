declare function isInstanceofAjax(obj: any): boolean;
declare const Ajax: typeof AjaxWrapper$1;
declare namespace apiType {
    const v2: string;
}
/**
 * AjaxWrapper构造函数
 *
 * @class
 * @param deferred - jQuery的deferred对象
 * @param options - ajax请求的配置项
 */
declare function AjaxWrapper$1(deferred: any, options: any): AjaxWrapper$1;
declare class AjaxWrapper$1 {
    /**
     * AjaxWrapper构造函数
     *
     * @class
     * @param deferred - jQuery的deferred对象
     * @param options - ajax请求的配置项
     */
    constructor(deferred: any, options: any);
    tid: number | undefined;
    ajaxOptions: any;
    _deferred: any;
    _progressDeferred: JQuery.Deferred<any, any, any> | undefined;
    /**
     * 请求返回成功
     *
     * @function
     * @param fn - 成功回调函数
     * @param context - 回调函数的上下文
     * @returns AjaxWrapper实例
     */
    done(fn: any, context: any): AjaxWrapper$1;
    /**
     * 请求返回错误
     *
     * @function
     * @param fn - 错误回调函数
     * @param context - 回调函数的上下文
     * @returns AjaxWrapper实例
     */
    fail(fn: any, context: any): AjaxWrapper$1;
    /**
     * 请求未返回
     *
     * @function
     * @param fn - 错误回调函数
     * @param context - 回调函数的上下文
     * @returns AjaxWrapper实例
     */
    error(fn: any, context: any): AjaxWrapper$1;
    /**
     * 请求结束
     *
     * @function
     * @param fn - 结束回调函数
     * @param context - 回调函数的上下文
     * @returns AjaxWrapper实例
     */
    always(fn: any, context: any): AjaxWrapper$1;
    /**
     * 撤销请求
     *
     * @function
     * @returns {void}
     */
    abort(): void;
    /**
     * 转换为defer对象
     *
     * @function
     * @returns jQuery的deferred对象
     */
    promise(): JQuery.Promise<any, any, any>;
    /**
     * 添加then方法
     *
     * @function
     * @returns AjaxWrapper实例
     */
    then(...args: any[]): AjaxWrapper$1;
    /**
     * 添加progress方法
     *
     * @function
     * @returns AjaxWrapper实例
     */
    progress(...args: any[]): AjaxWrapper$1;
    [ajaxWrapperSymbol]: boolean;
}
/**
 * 将新规范返回数据包装成原来的样子
 *
 * @function
 * @param data - 新规范返回的数据
 * @returns 包装后的数据
 */
declare function formatResData(data: any): {
    success: number;
    count: any;
    data: any;
    message: any;
};
/**
 * http请求错误的默认提示信息
 */
declare function getHttpErrorMessage(): string;
declare const ajaxWrapperSymbol: unique symbol;

declare function ajax$1(url: string | Object, options?: Object | undefined): AjaxWrapper$1;
declare function get(url: string, data?: Object | Function | undefined, callback?: Function | undefined, type?: string | undefined): AjaxWrapper$1;
declare function post(url: string, data?: Object | Function | undefined, callback?: Function | undefined, type?: string | undefined): AjaxWrapper$1;

/**
 * 添加全局钩子函数
 *
 * @function
 * @param {string} type - 钩子函数类型
 * @param {...Function} args - 钩子函数列表
 */
declare const addGlobalHook: any;
/**
 * 移除全局钩子函数
 *
 * @function
 * @param {string} type - 钩子函数类型
 * @param {Function} fn - 钩子函数
 */
declare const removeGlobalHook: any;
/**
 * 添加ajax设置钩子函数
 *
 * @function
 * @param {Function} fn - 钩子函数
 */
declare const addAjaxSettingHook: any;
/**
 * 移除ajax设置钩子函数
 *
 * @function
 * @param {Function} fn - 钩子函数
 */
declare const removeAjaxSettingHook: any;
declare const addResponseInterceptors: any;
declare const removeResponseInterceptors: any;

/**
 * 基于 jQuery 的 Promise.all,用于多个请求，支持 abort
 *
 * @param {ajax[] | ajax} ajx1 - 第一个 ajax 请求或 ajax 请求数组
 * @param {...ajax} ajx2 - 其他 ajax 请求
 * @returns 返回一个 Deferred 对象，支持 abort 方法
 *
 * @example
 *
 * // 单个 ajax 请求
 * const ajax1 = $.ajax({
 *   url: '/api/data1',
 *   type: 'GET',
 *   dataType: 'json'
 * });
 *
 * multiAjax(ajax1).then((data) => {
 *   console.log(data);
 * }).fail((error) => {
 *   console.error(error);
 * });
 *
 * // 多个 ajax 请求
 * const ajax2 = $.ajax({
 *   url: '/api/data2',
 *   type: 'GET',
 *   dataType: 'json'
 * });
 *
 * multiAjax(ajax1, ajax2).then((data1, data2) => {
 *   console.log(data1, data2);
 * }).fail((error1, error2) => {
 *   console.error(error1, error2);
 * });
 */
declare function multiAjax(ajx1: ajax[] | ajax, ...args: any[]): JQuery.Deferred<any, any, any> | undefined;

declare function checkNoNotify(message: string): boolean;
declare function filterNoNotifyPrefix(message: string): string;
declare function getAjaxMessage(message: string, options?: {
    defaultMessage: string;
    defaultNoNotifyMessage: string;
}): string | undefined;

declare const _default: {
    addGlobalHook: any;
    removeGlobalHook: any;
    addAjaxSettingHook: any;
    removeAjaxSettingHook: any;
    addResponseInterceptors: any;
    removeResponseInterceptors: any;
    ajax: (url: string | Object, options?: Object | undefined) => AjaxWrapper.AjaxWrapper;
    get: (url: string, data?: Object | Function | undefined, callback?: Function | undefined, type?: string | undefined) => AjaxWrapper.AjaxWrapper;
    post: (url: string, data?: Object | Function | undefined, callback?: Function | undefined, type?: string | undefined) => AjaxWrapper.AjaxWrapper;
    isInstanceofAjax: (obj: any) => boolean;
    Ajax: typeof AjaxWrapper.AjaxWrapper;
    apiType: {
        v2: string;
    };
    AjaxWrapper: typeof AjaxWrapper.AjaxWrapper;
    formatResData: typeof AjaxWrapper.formatResData;
    getHttpErrorMessage: () => string;
};

export { Ajax, AjaxWrapper$1 as AjaxWrapper, addAjaxSettingHook, addGlobalHook, addResponseInterceptors, ajax$1 as ajax, apiType, checkNoNotify, _default as default, filterNoNotifyPrefix, formatResData, get, getAjaxMessage, getHttpErrorMessage, isInstanceofAjax, multiAjax, post, removeAjaxSettingHook, removeGlobalHook, removeResponseInterceptors };
