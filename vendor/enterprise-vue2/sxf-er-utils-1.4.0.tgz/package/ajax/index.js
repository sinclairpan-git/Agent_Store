var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// packages/utils/ajax/config.js
import { $i, globalConfig } from "@sxf/er-config";
var getConfig = () => {
  var _a, _b, _c, _d, _e, _f, _g;
  const ajaxGlobalConfig = (_a = globalConfig.ajax) != null ? _a : {};
  return {
    contentTypeJson: (_b = ajaxGlobalConfig.contentTypeJson) != null ? _b : true,
    remoteDebugPrefix: (_c = ajaxGlobalConfig.remoteDebugPrefix) != null ? _c : true,
    tokenKey: (_d = ajaxGlobalConfig.tokenKey) != null ? _d : "CSRFPreventionToken",
    ticket: (_e = ajaxGlobalConfig.ticket) != null ? _e : "",
    sid: (_f = ajaxGlobalConfig.sid) != null ? _f : "",
    loginType: (_g = ajaxGlobalConfig.loginType) != null ? _g : ""
  };
};
var NO_NOTIFY = "[er-no-notify]";
var checkNoNotify = (message) => message.toString().startsWith(NO_NOTIFY);
var filterNoNotifyPrefix = (message) => message.toString().split(NO_NOTIFY)[1];
var getAjaxMessage = (message, options = {
  /** message 为空时默认展示的信息 */
  defaultMessage: "",
  /** 静默状态默认展示的信息 */
  defaultNoNotifyMessage: ""
}) => {
  const { defaultMessage, defaultNoNotifyMessage } = options;
  if (typeof checkNoNotify === "function" && checkNoNotify(message)) {
    return filterNoNotifyPrefix(message) || defaultNoNotifyMessage || $i("scp.vt_component.common.util.ajax.empty_text");
  }
  return message || defaultMessage;
};

// packages/utils/ajax/lib/hook.js
var hook_exports = {};
__export(hook_exports, {
  addAjaxSettingHook: () => addAjaxSettingHook,
  addGlobalHook: () => addGlobalHook,
  addResponseInterceptors: () => addResponseInterceptors,
  removeAjaxSettingHook: () => removeAjaxSettingHook,
  removeGlobalHook: () => removeGlobalHook,
  removeResponseInterceptors: () => removeResponseInterceptors
});

// packages/utils/ajax/lib/ajaxWrapper.js
var ajaxWrapper_exports = {};
__export(ajaxWrapper_exports, {
  Ajax: () => Ajax,
  AjaxWrapper: () => AjaxWrapper,
  apiType: () => apiType,
  formatResData: () => formatResData,
  getHttpErrorMessage: () => getHttpErrorMessage,
  isInstanceofAjax: () => isInstanceofAjax
});
import $ from "jquery";
import { $i as $i2 } from "@sxf/er-config";
import clone from "@sxf/er-utils/clone";
import lang from "@sxf/er-utils/lang";
import logger from "@sxf/er-utils/logger";
var ajaxLogger = logger("ajax");
var getHttpErrorMessage = () => $i2("scp.vt_component.common.util.ajax.http_error_msg");
var ajaxSeed = 0;
var API_TYPE = {
  v2: "v2"
  // v2版本接口规范，成功不返回code，直接返回内容，失败返回code和message字段
};
function formatResData(data) {
  const result = {};
  result.success = typeof data.code === "undefined" || data.code === 200 ? 1 : 0;
  if (data.count) {
    result.count = data.count;
  }
  if (result.success) {
    result.data = clone(data);
  } else {
    result.message = data.message || getHttpErrorMessage();
  }
  return result;
}
var ajaxWrapperSymbol = Symbol("AjaxWrapper");
function AjaxWrapper(deferred, options) {
  if (!(this instanceof AjaxWrapper)) {
    return new AjaxWrapper(deferred);
  }
  this.tid = ++ajaxSeed;
  this.ajaxOptions = options;
  this._deferred = deferred;
  this._progressDeferred = $.Deferred();
  this[ajaxWrapperSymbol] = true;
}
AjaxWrapper.prototype.done = function(fn, context) {
  const self = this;
  self._deferred.done(function(data) {
    const args = [].slice.call(arguments, 0);
    if (self.ajaxOptions.apiType === API_TYPE.v2) {
      data = formatResData(data);
    }
    if (data && !data.success) {
      return;
    }
    fn.call(context || this, data, args);
  });
  return self;
};
var processStat = /^(?:400|401|403|5\d{2})$/;
function checkIsAbort(statusText) {
  return statusText === "abort";
}
AjaxWrapper.prototype.fail = function(fn, context) {
  const self = this;
  if (!self.failHandlers) {
    self.failHandlers = [];
  }
  self.failHandlers.push(function(data, statusText, args) {
    fn.call(context || this, data, statusText, args);
  });
  self._deferred.done(function(data, statusText) {
    const args = [].slice.call(arguments, 0);
    if (self.ajaxOptions.apiType === API_TYPE.v2) {
      data = formatResData(data);
    }
    if (!data || data.success || this.dataType === "html" || !self.failHandlers) {
      return;
    }
    for (let i = 0; i < self.failHandlers.length; i++) {
      self.failHandlers[i](data, statusText, args);
    }
    self.failHandlers = null;
  });
  self._deferred.fail(function(xhr, statusText) {
    const args = [].slice.call(arguments, 0);
    let data = null;
    if (xhr.readyState === 4 && processStat.test(xhr.status)) {
      data = xhr.responseJSON || {};
      data.message = data.message || getHttpErrorMessage();
      fn.call(context || this, data, statusText, args);
      ajaxLogger.warn("jquery request fail\uFF1A" + data.message);
    }
  });
  return self;
};
AjaxWrapper.prototype.error = function(fn, context) {
  const self = this;
  self._deferred.fail(function(xhr) {
    var _a;
    const args = [].slice.call(arguments, 0);
    if (xhr.readyState !== 4 || !processStat.test(xhr.status)) {
      const statusText = xhr.statusText;
      let data = lang.isFunction((_a = self.ajaxOptions) == null ? void 0 : _a.requestErrorCallback) ? self.ajaxOptions.requestErrorCallback(xhr) : { message: getHttpErrorMessage() };
      if (checkIsAbort(statusText)) {
        data = statusText;
      }
      fn.call(context || this, data, args);
      ajaxLogger.error("jquery request error\uFF1A" + statusText);
    }
  });
  return self;
};
AjaxWrapper.prototype.always = function(fn, context) {
  const self = this;
  self.done(function(json, args) {
    fn.call(context || this, true, json, args);
  }).fail(function(json, statusText, args) {
    fn.call(context || this, false, json, args);
  }).error(function(statusText, args) {
    fn.call(context || this, false, checkIsAbort(statusText) ? null : statusText, args);
  });
  return self;
};
AjaxWrapper.prototype.abort = function() {
  const self = this;
  if (self._deferred) {
    self._deferred.abort();
  }
};
AjaxWrapper.prototype.promise = function() {
  const self = this;
  const defer = $.Deferred();
  self.done(function(json) {
    defer.resolve(json);
  }).fail(function(json) {
    defer.reject(json);
  }).error(function() {
    defer.reject();
  });
  return defer.promise();
};
AjaxWrapper.prototype.then = function() {
  const defer = this._deferred.then.apply(this._deferred, arguments);
  defer.abort = this._deferred.abort;
  const ajaxDefer = new AjaxWrapper(defer, this.ajaxOptions);
  ajaxDefer._progressDeferred = this._progressDeferred;
  return ajaxDefer;
};
AjaxWrapper.prototype.progress = function() {
  this._progressDeferred.progress.apply(this._progressDeferred, arguments);
  return this;
};
var isInstanceofAjax = (obj) => {
  return lang.isObject(obj) && obj[ajaxWrapperSymbol] === true;
};
var Ajax = AjaxWrapper;
var apiType = API_TYPE;

// packages/utils/ajax/lib/hook.js
AjaxWrapper.addHook = function(type) {
  const args = [].slice.call(arguments, 1), Ajax2 = AjaxWrapper;
  if (!Ajax2.hook) {
    Ajax2.hook = {};
  }
  if (!Ajax2.hook[type]) {
    Ajax2.hook[type] = [];
  }
  args.forEach(function(item) {
    if (typeof item === "function") {
      Ajax2.hook[type].push(item);
    }
  });
};
AjaxWrapper.removeHook = function(type, fn) {
  const Ajax2 = AjaxWrapper;
  if (!Ajax2.hook || !Ajax2.hook[type]) {
    return;
  }
  Ajax2.hook[type].forEach(function(item, idx) {
    if (item === fn) {
      Ajax2.hook[type].splice(idx, 1);
    }
  });
};
AjaxWrapper.addResponseInterceptors = function() {
  const args = [...arguments];
  const Ajax2 = AjaxWrapper;
  if (!Ajax2.interceptors) {
    Ajax2.interceptors = {};
  }
  if (!Ajax2.interceptors.response) {
    Ajax2.interceptors.response = [];
  }
  args.forEach(function(item) {
    if (typeof item === "function") {
      Ajax2.interceptors.response.push(item);
    }
  });
};
AjaxWrapper.removeResponseInterceptors = function(fn) {
  var _a, _b;
  const Ajax2 = AjaxWrapper;
  if (!((_b = (_a = Ajax2.interceptors) == null ? void 0 : _a.response) == null ? void 0 : _b.length)) {
    return;
  }
  Ajax2.interceptors.response.forEach(function(item, idx) {
    if (item === fn) {
      Ajax2.interceptors.response.splice(idx, 1);
    }
  });
};
AjaxWrapper.addAjaxSettingHook = function(fn) {
  const Ajax2 = AjaxWrapper;
  if (!Ajax2.settingHook) {
    Ajax2.settingHook = [];
  }
  Ajax2.settingHook.push(fn);
};
AjaxWrapper.removeAjaxSettingHook = function(fn) {
  const Ajax2 = AjaxWrapper;
  if (!Ajax2.settingHook || !Ajax2.settingHook.length) {
    return;
  }
  Ajax2.settingHook.forEach(function(item, idx) {
    if (item === fn) {
      Ajax2.settingHook.splice(idx, 1);
    }
  });
};
AjaxWrapper.resetHook = function() {
  delete AjaxWrapper.settingHook;
  delete AjaxWrapper.hook;
};
var addGlobalHook = AjaxWrapper.addHook;
var removeGlobalHook = AjaxWrapper.removeHook;
var addAjaxSettingHook = AjaxWrapper.addAjaxSettingHook;
var removeAjaxSettingHook = AjaxWrapper.removeAjaxSettingHook;
var addResponseInterceptors = AjaxWrapper.addResponseInterceptors;
var removeResponseInterceptors = AjaxWrapper.removeResponseInterceptors;

// packages/utils/ajax/hooks/contentType.js
var addContentTypeHook = () => {
  addAjaxSettingHook((apiUrl, options) => {
    if (getConfig().contentTypeJson !== false && typeof options.contentType === "undefined") {
      options.contentType = "application/json; charset=utf-8";
    }
    if (options.dataType === "json" && !options.contentType) {
      options.contentType = "application/json; charset=utf-8";
    }
  });
};

// packages/utils/ajax/hooks/header.js
import $2 from "jquery";
var addHeaderHook = () => {
  let hasSetup = false;
  addAjaxSettingHook((apiUrl, options) => {
    const settings = $2.ajaxSettings;
    const { ticket, sid, tokenKey } = getConfig();
    if (hasSetup && !options.needSetHeader) {
      return;
    }
    settings.headers = settings.headers || {};
    settings.headers[tokenKey] = ticket;
    settings.headers.sid = sid;
    if (ticket) {
      hasSetup = true;
    }
    settings.mimeType = "text/json";
  });
};

// packages/utils/ajax/hooks/localLogin.js
import $3 from "jquery";
import cookies from "@sxf/er-utils/cookies";
var isLocalLogin = () => {
  const localLogin = "local";
  const { loginType } = getConfig();
  return !loginType || loginType === localLogin;
};
var addLocalLoginHook = () => {
  addAjaxSettingHook(() => {
    if (!isLocalLogin()) {
      const settings = $3.ajaxSettings;
      settings.headers.Login_Coc = true;
      cookies.set("recent_uri", location.href);
    }
  });
};

// packages/utils/ajax/hooks/url.js
var addURLHook = () => {
  addAjaxSettingHook((url) => {
    const isCluster = /^\/cluster-/.test(location.pathname);
    const vapiRe = /^\.?(\/vapi)/;
    url = (url || "").trim().replace(vapiRe, isCluster ? ".$1" : "$1");
    if (window.DEBUG) {
      url = url[0] !== "/" ? "/" + url : url;
      if (!url.match(vapiRe)) {
        url = "/vapi/" + url.replace(/^\//, "");
      }
      if (window.REMOTE && getConfig().remoteDebugPrefix !== false) {
        url = url.replace("/vapi", "/remote");
      }
    }
    return url;
  });
};

// packages/utils/ajax/hooks/index.js
var addFullHook = () => {
  addHeaderHook();
  addLocalLoginHook();
  addURLHook();
  addContentTypeHook();
};

// packages/utils/ajax/lib/ajax.js
var ajax_exports = {};
__export(ajax_exports, {
  ajax: () => ajax,
  get: () => get,
  post: () => post
});
import $4 from "jquery";
var handleResponseInterceptors = async function(deferred, options) {
  const successStatus = ["success", "notmodified", "nocontent"];
  const deferredResultCallback = function(opts = { isRetryRequest: false }) {
    if (!opts.isRetryRequest) {
      const { textStatus } = options;
      if (!successStatus.includes(textStatus)) {
        const { dataOrJqXHR: jqXHRInstance, jqXHROrErrorThrown: errorThrownStr } = options;
        deferred.reject(jqXHRInstance, textStatus, errorThrownStr);
      } else {
        const { dataOrJqXHR: data, jqXHROrErrorThrown: jqXHRInstance } = options;
        deferred.resolve(data, textStatus, jqXHRInstance);
      }
      return;
    }
    $4.ajax(options.url, options.ajaxConfig).always((dataOrJqXHR, textStatus, jqXHROrErrorThrown) => {
      if (!successStatus.includes(textStatus)) {
        deferred.reject(dataOrJqXHR, textStatus, jqXHROrErrorThrown);
      } else {
        deferred.resolve(dataOrJqXHR, textStatus, jqXHROrErrorThrown);
      }
    });
  };
  const fns = AjaxWrapper.interceptors.response.filter((hook) => typeof hook === "function");
  await Promise.all(
    fns.map((fn) => {
      return fn(
        {
          dataOrJqXHR: options.dataOrJqXHR,
          textStatus: options.textStatus,
          jqXHROrErrorThrown: options.jqXHROrErrorThrown
        },
        deferredResultCallback
      );
    })
  );
};
var ajax = function(url, options) {
  var _a, _b;
  if (typeof url === "object") {
    options = url;
    url = void 0;
  }
  options = options || {};
  url = url || options.url;
  options.type = (options.type || options.method || "get").toLowerCase();
  const callbacks = {
    done: options.success,
    fail: options.failure,
    error: options.error,
    always: options.callback
  };
  let isApiAjaxInstance = false;
  options.success = options.failure = options.error = options.callback = null;
  if (AjaxWrapper.settingHook) {
    let apiUrl = url || "";
    for (let i = 0; i < AjaxWrapper.settingHook.length; i++) {
      const hookRet = AjaxWrapper.settingHook[i](apiUrl, options);
      if (hookRet !== null && typeof hookRet !== "undefined") {
        apiUrl = hookRet;
      }
    }
    url = apiUrl;
  }
  if (typeof options.contentType === "string" && options.contentType.match(/application\/json;/) && ["post", "put", "patch", "delete"].indexOf(options.type) >= 0) {
    options.data = typeof options.data === "string" ? options.data : JSON.stringify(options.data);
  }
  let deferred, apiDefer;
  options.xhr = function() {
    const xhr = new window.XMLHttpRequest();
    xhr.upload.addEventListener(
      "progress",
      function(evt) {
        deferred._progressDeferred.notify(evt);
      },
      false
    );
    xhr.addEventListener(
      "progress",
      function(evt) {
        deferred._progressDeferred.notify(evt);
      },
      false
    );
    return xhr;
  };
  if ($4.isFunction(options.api)) {
    apiDefer = options.api(options.data);
    if (!(apiDefer instanceof AjaxWrapper)) {
      apiDefer.abort = function() {
        if (apiDefer.reject) {
          apiDefer.reject({
            statusText: "abort"
          });
        }
      };
      deferred = new AjaxWrapper(apiDefer, options);
    } else {
      deferred = apiDefer;
      isApiAjaxInstance = true;
    }
  } else {
    if ((_b = (_a = AjaxWrapper.interceptors) == null ? void 0 : _a.response) == null ? void 0 : _b.length) {
      const getDeferredXHR = () => {
        const customDeferred = $4.Deferred();
        const jqXHR = $4.ajax(url, options);
        jqXHR.always((dataOrJqXHR, textStatus, jqXHROrErrorThrown) => {
          handleResponseInterceptors(customDeferred, {
            dataOrJqXHR,
            textStatus,
            jqXHROrErrorThrown,
            url,
            ajaxConfig: options
          });
        });
        const deferredPromise = customDeferred.promise();
        return new Proxy(deferredPromise, {
          get(target, prop) {
            if (prop in target) {
              return target[prop];
            } else {
              return jqXHR[prop];
            }
          }
        });
      };
      deferred = new AjaxWrapper(getDeferredXHR(), options);
    } else {
      deferred = new AjaxWrapper($4.ajax(url, options), options);
    }
  }
  deferred.callbacks = callbacks;
  if (AjaxWrapper.hook && !isApiAjaxInstance) {
    Object.keys(AjaxWrapper.hook).forEach(function(key) {
      const fns = AjaxWrapper.hook[key] || [];
      if (typeof deferred[key] === "function") {
        fns.forEach(function(fn) {
          deferred[key](fn);
        });
      }
    });
  }
  $4.each(callbacks, function(k, fn) {
    if (!fn) {
      return;
    }
    deferred[k](function() {
      fn.apply(this, arguments);
    });
  });
  return deferred;
};
var get = function(url, data, callback, type) {
  if ($4.isFunction(data)) {
    type = type || callback;
    callback = data;
    data = void 0;
  }
  return ajax({
    url,
    type: "get",
    dataType: type,
    data,
    success: callback
  });
};
var post = function(url, data, callback, type) {
  if ($4.isFunction(data)) {
    type = type || callback;
    callback = data;
    data = void 0;
  }
  return ajax({
    url,
    type: "post",
    dataType: type,
    data,
    success: callback
  });
};

// packages/utils/ajax/lib/multiAjax.js
import $5 from "jquery";
function multiAjax(ajx1) {
  if (!ajx1) {
    return;
  }
  const ajxArr = Array.isArray(ajx1) ? ajx1 : arguments;
  const deferred = $5.Deferred();
  let ajxRetArgs = [], ajxRetJsons = [], ajxRetsCnt = 0, allSuccess = true, _defer, ajaxDefer = [];
  $5.each(ajxArr, function(index, ajx) {
    _defer = ajx.always(function(success, json, args) {
      if (!success) {
        allSuccess = false;
      }
      ajxRetsCnt++;
      ajxRetArgs[index] = { success, json, args };
      ajxRetJsons[index] = json;
      if (ajxRetsCnt === ajxArr.length) {
        if (allSuccess) {
          deferred.resolve.apply(deferred, ajxRetJsons);
        } else {
          deferred.reject.apply(deferred, ajxRetArgs);
        }
        ajxRetArgs = null;
        ajxRetJsons = null;
        ajaxDefer = null;
      }
    });
    ajaxDefer.push(_defer);
  });
  deferred.abort = function() {
    if (!ajaxDefer) {
      return;
    }
    ajaxDefer.forEach(function(defer) {
      defer.abort();
    });
    ajaxDefer = null;
  };
  return deferred;
}

// packages/utils/ajax/index.js
addFullHook();
var ajax_default = {
  ...ajaxWrapper_exports,
  ...ajax_exports,
  ...hook_exports
};
export {
  Ajax,
  AjaxWrapper,
  addAjaxSettingHook,
  addGlobalHook,
  addResponseInterceptors,
  ajax,
  apiType,
  checkNoNotify,
  ajax_default as default,
  filterNoNotifyPrefix,
  formatResData,
  get,
  getAjaxMessage,
  getHttpErrorMessage,
  isInstanceofAjax,
  multiAjax,
  post,
  removeAjaxSettingHook,
  removeGlobalHook,
  removeResponseInterceptors
};
