// packages/utils/logger/index.js
import { globalConfig } from "@sxf/er-config";
function Logger(name) {
  this.name = name ? "[" + name + "]" : "";
}
Logger.prototype.log = _logger("log");
Logger.prototype.warn = _logger("warn");
Logger.prototype.error = _logger("error");
Logger.prototype.debug = _logger("debug");
Logger.prototype.info = _logger("info");
function _logger(type) {
  return function() {
    const enabled = globalConfig.debug;
    const args = [].slice.call(arguments, 0);
    const prefix = this.name ? this.name + " " : "";
    args[0] = prefix + (args[0] || "");
    window.console && enabled && console[type || (type = "log")] && // Call native method of console
    console[type].apply && console[type].apply(console, args);
  };
}
var logger_default = (name) => new Logger(name);
export {
  logger_default as default
};
