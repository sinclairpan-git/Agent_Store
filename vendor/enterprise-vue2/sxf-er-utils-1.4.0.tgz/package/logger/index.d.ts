declare function _default(name: any): Logger;

declare function Logger(name: any): void;
declare class Logger {
    constructor(name: any);
    name: string;
    log: (...args: any[]) => void;
    warn: (...args: any[]) => void;
    error: (...args: any[]) => void;
    debug: (...args: any[]) => void;
    info: (...args: any[]) => void;
}

export { _default as default };
