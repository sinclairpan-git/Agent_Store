// packages/utils/cluster/index.js
var x = {
  getClusterIdFromPath: function(pathname) {
    const reg = pathname.match(/\/(cluster-[^\/]+)\//i);
    return reg && reg[1];
  },
  getClusterIdCodeFromPath: function(pathname) {
    pathname = pathname ? pathname : location.pathname;
    const ret = pathname.match(/cluster-([^\/]+)/);
    return ret && ret[1] || "";
  },
  isClusterPath: function(pathname) {
    return x.getClusterIdFromPath(pathname);
  }
};
var cluster_default = x;
export {
  cluster_default as default
};
