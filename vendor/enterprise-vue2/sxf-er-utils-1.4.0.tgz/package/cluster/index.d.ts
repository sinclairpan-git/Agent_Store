declare namespace x {
    function getClusterIdFromPath(pathname: any): any;
    function getClusterIdCodeFromPath(pathname: any): any;
    function isClusterPath(pathname: any): any;
}

export { x as default };
