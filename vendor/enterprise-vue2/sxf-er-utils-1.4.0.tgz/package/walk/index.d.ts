/**
 * Vue 组件
 */
interface VueComponent {
  $children: VueComponent[];
  cascadeWithoutChildren?: boolean;
}

/**
 * 遍历 Vue 组件
 *
 * @param root VueComponent 根节点
 * @param callback 回调函数，返回 false 时，遍历会被中止
 * @returns 是否全部遍历完成
 */
declare function cascadeComponent(root: VueComponent, callback: Function): boolean;

/**
 * 遍历树状结构数据
 *
 * @param data 树状结构数据
 * @param callback 回调函数
 * @param childKey 表示孩子节点数据的字段，默认为 'data'
 */
declare function cascadeTree(data: any[], callback: Function, childKey?: string): void;

export { cascadeComponent, cascadeTree };
