// packages/utils/walk/index.js
function cascadeComponent(root, callback) {
  if (root) {
    if (typeof callback === "function") {
      const ret = callback(root);
      if (ret === false) {
        return ret;
      }
    }
    if (Array.isArray(root.$children) && root.cascadeWithoutChildren !== true) {
      return root.$children.every(function(component) {
        return cascadeComponent(component, callback);
      });
    }
  }
  return true;
}
function cascadeTree(data, callback, childKey) {
  childKey = childKey || "data";
  const parents = [];
  const visited = /* @__PURE__ */ new Set();
  const cascade = (data2, callback2) => {
    if (!Array.isArray(data2)) {
      return;
    }
    data2.forEach((item, index) => {
      if (visited.has(item)) {
        return;
      }
      visited.add(item);
      if (callback2(item, index, data2, parents.slice()) === false) {
        return;
      }
      if (Array.isArray(item[childKey]) && item[childKey].length) {
        parents.unshift(item);
        cascade(item[childKey], callback2);
        parents.shift(item);
      }
    });
  };
  return cascade(data, callback);
}
export {
  cascadeComponent,
  cascadeTree
};
