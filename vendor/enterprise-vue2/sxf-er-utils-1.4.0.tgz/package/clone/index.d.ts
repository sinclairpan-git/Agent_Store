declare function _clone(item: any): any;

export { _clone as default };
