// packages/utils/clone/index.js
var toString = Object.prototype.toString;
var _clone = function(item) {
  let i, clone, key;
  if (item === null || item === void 0) {
    return item;
  }
  if (item.nodeType && item.cloneNode) {
    return item.cloneNode(true);
  }
  const type = toString.call(item);
  if (type === "[object Date]") {
    return new Date(item.getTime());
  }
  if (type === "[object Array]") {
    i = item.length;
    clone = [];
    while (i--) {
      clone[i] = _clone(item[i]);
    }
  } else if (type === "[object Object]" && item.constructor === Object) {
    clone = {};
    for (key in item) {
      clone[key] = _clone(item[key]);
    }
  }
  return clone || item;
};
var clone_default = _clone;
export {
  clone_default as default
};
