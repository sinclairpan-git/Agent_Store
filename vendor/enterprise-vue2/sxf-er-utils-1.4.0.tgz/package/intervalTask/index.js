// packages/utils/intervalTask/index.js
import { getPageStatus } from "@sxf/er-utils/_private/detectPageStatus";
var STATE = {
  stopped: 1,
  // 停止状态
  running: 2,
  // 运行状态
  waiting: 3
  // 等待状态
};
var Task = class {
  /**
   * @param {Object} opt - 任务配置选项
   * @param {number} [opt.interval=0] - 任务执行间隔时间
   * @param {number} [opt.inactiveInterval=0] - 页面未激活时的轮询间隔时间
   * @param {boolean} [opt.skipFirst=false] - 是否跳过第一次执行
   * @param {Function} opt.fn - 任务执行函数
   * @param {Object} [opt.scope] - 任务执行函数的作用域
   * @param {boolean} [opt.isNeverHidden=false] - 是否在页面未激活时保持轮询
   * @param {boolean} [opt.autoStart=false] - 是否自动启动任务
   */
  constructor(opt) {
    opt = opt || {};
    this.interval = opt.interval || 0;
    this.inactiveInterval = opt.inactiveInterval || 0;
    this.skipFirst = !!opt.skipFirst;
    this.fn = opt.fn;
    this.scope = opt.scope;
    this.state = STATE.stopped;
    this.isNeverHidden = opt.inactiveInterval ? true : opt.isNeverHidden || false;
    this.tid = null;
    if (opt.autoStart) {
      this.start(this.skipFirst);
    }
  }
  /**
   * 启动任务
   *
   * @param {boolean} [skipFirst=false] - 是否跳过第一次执行
   * @example
   * task.start();
   */
  start(skipFirst = false) {
    if (this.state === STATE.stopped) {
      this.state = STATE.waiting;
      $callback(this)(!!skipFirst);
    }
  }
  /**
   * 停止任务
   *
   * @example
   * task.stop();
   */
  stop() {
    if (this.tid) {
      clearTimeout(this.tid);
      this.tid = null;
    }
    this.state = STATE.stopped;
  }
  /**
   * 继续执行任务
   *
   * @example
   * task.next();
   */
  next() {
    let interval = this.interval;
    if (this.inactiveInterval) {
      interval = getPageStatus() ? this.inactiveInterval : this.interval;
    }
    if (this.state === STATE.running) {
      this.state = STATE.waiting;
      this.tid = setTimeout(() => {
        this.isNeverHidden || !getPageStatus() ? $callback(this)() : $callback(this)(true);
      }, interval);
    }
  }
  /**
   * 动态修改定时时间
   *
   * @param {number} [interval] - 任务执行间隔时间
   * @param {boolean} [skipFirst=false] - 是否跳过第一次执行
   * @example
   * task.changeInterval(2000);
   */
  changeInterval(interval, skipFirst = false) {
    this.interval = interval || this.interval;
    if (skipFirst) {
      return;
    }
    this.stop();
    this.start();
  }
};
Task.STATE = STATE;
function $callback(task) {
  const next = function(success) {
    if (success === false) {
      task.stop();
    } else {
      task.next();
    }
  };
  return function(skipFirst) {
    task.state = STATE.running;
    if (skipFirst) {
      next(true);
    } else {
      task.fn.call(task.scope || task, next);
    }
  };
}
export {
  Task as default
};
