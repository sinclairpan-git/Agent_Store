/**
 * 任务构造函数
 *
 * @example
 * const task = new Task({
 *   interval: 1000,
 *   fn: () => console.log('task is running'),
 *   autoStart: true,
 * });
 */
declare class Task {
    /**
     * @param {Object} opt - 任务配置选项
     * @param {number} [opt.interval=0] - 任务执行间隔时间
     * @param {number} [opt.inactiveInterval=0] - 页面未激活时的轮询间隔时间
     * @param {boolean} [opt.skipFirst=false] - 是否跳过第一次执行
     * @param {Function} opt.fn - 任务执行函数
     * @param {Object} [opt.scope] - 任务执行函数的作用域
     * @param {boolean} [opt.isNeverHidden=false] - 是否在页面未激活时保持轮询
     * @param {boolean} [opt.autoStart=false] - 是否自动启动任务
     */
    constructor(opt: {
        interval?: number | undefined;
        inactiveInterval?: number | undefined;
        skipFirst?: boolean | undefined;
        fn: Function;
        scope?: Object | undefined;
        isNeverHidden?: boolean | undefined;
        autoStart?: boolean | undefined;
    });
    /**
     * 任务执行间隔时间
     *
     * @type {number}
     */
    interval: number;
    /**
     * 页面未激活时的轮询间隔时间
     *
     * @type {number}
     */
    inactiveInterval: number;
    /**
     * 是否跳过第一次执行
     *
     * @type {boolean}
     */
    skipFirst: boolean;
    /**
     * 任务执行函数
     *
     * @type {Function}
     */
    fn: Function;
    scope: Object | undefined;
    /**
     * 任务状态
     *
     * @type {number}
     */
    state: number;
    isNeverHidden: boolean;
    /**
     * 定时器 ID
     *
     * @type {number}
     */
    tid: number;
    /**
     * 启动任务
     *
     * @param {boolean} [skipFirst=false] - 是否跳过第一次执行
     * @example
     * task.start();
     */
    start(skipFirst?: boolean | undefined): void;
    /**
     * 停止任务
     *
     * @example
     * task.stop();
     */
    stop(): void;
    /**
     * 继续执行任务
     *
     * @example
     * task.next();
     */
    next(): void;
    /**
     * 动态修改定时时间
     *
     * @param {number} [interval] - 任务执行间隔时间
     * @param {boolean} [skipFirst=false] - 是否跳过第一次执行
     * @example
     * task.changeInterval(2000);
     */
    changeInterval(interval?: number | undefined, skipFirst?: boolean | undefined): void;
}
declare namespace Task {
    export { STATE };
}

/**
 * *
 */
type STATE = number;
declare namespace STATE {
    const stopped: number;
    const running: number;
    const waiting: number;
}

export { Task as default };
