declare namespace UtilFormat {
    const thousandSeparator: string;
    const decimalSeparator: string;
    function undef(value: any): string;
    function defaultValue(value: any, defaultValue: any): any;
    function substr(value: any, start: any, length: any): string;
    function lowercase(value: any): string;
    function uppercase(value: any): string;
    function stripTags(v: string): string;
    function stripScripts(v: string): string;
    function fileSize(size: any): string;
    function round(value: number, precision?: number | undefined): number;
    function plural(v: number, s: string, p?: string | undefined): string;
    function nl2br(v: string): string;
    function xformat(str: string, map: Object): string;
    const capitalize: (string: string) => string;
    const ellipsis: (value: string, len: number, word?: boolean | undefined) => string;
    const format: (format: string, ...args: any[]) => string;
    const htmlDecode: (value: string) => string;
    const htmlEncode: (value: string) => string;
    const htmlTextEncode: (value: any) => any;
    const htmlDoubleEncode: (value: string) => string;
    const leftPad: (string: string, size: number, character?: string | undefined) => string;
    const trim: (string: string) => string;
    function parseBox(box: any): {
        top: number;
        right: number;
        bottom: number;
        left: number;
    };
    function escapeRegex(s: any): any;
    function getTime(date: string, time: string): number;
    function getTimeZone(): number;
    function date(date: string | number | Date, format?: string | undefined): string;
    function dateInstance(date: string | number | Date): Date;
    const dateFmtRegex: RegExp;
    namespace dateFmtFun {
        function Y(date: any): any;
        function m(date: any): string;
        function d(date: any): string;
        function H(date: any): string;
        function i(date: any): string;
        function s(date: any): string;
    }
    function dateRenderer(format: string): Function;
    function getDateFromNow(number: string | number): Date;
    function getDateRangeFromNow(number: string | number, format?: string | boolean | undefined): Date[];
    function formatToVMPTime(serverTime: string | number, format?: string | undefined): string;
    function ip2int(ip: string): number;
    function int2ip(num: string | number): string;
    function int2bit(n: number): string;
    function ip2bit(ip: string): string;
    function mask2int(mask: string | number): number;
    function int2mask(num: string | number): string;
    function networkSegmentToDefaultIpRange(networkSegment: string): {
        ipStart: number;
        ipEnd: number;
    };
    function transformIpRange(ipValue: string): {
        singleIps: string[];
        ipRanges: string[][];
    };
    function secToDate(value: number, level: string): string;
    function secToTime(time: number): string;
    function utf8Length(s: string): number;
    function limitString(str: string, limit: number, useUTF8Len: boolean): string;
    function commaDivide(num: number): string;
    function getRecentMonthDays(count: number): number;
    function getLines(str: string): any[];
    function getContentTip(tip: string | any[]): string;
}

export { UtilFormat as default };
