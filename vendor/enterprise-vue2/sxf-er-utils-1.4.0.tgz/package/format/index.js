// packages/utils/format/index.js
import { $i, globalConfig } from "@sxf/er-config";
import _String from "@sxf/er-utils/string";
var stripTagsRE = /<\/?[^>]+>/gi;
var stripScriptsRe = /(?:<script.*?>)((\n|\r|.)*?)(?:<\/script>)/gi;
var nl2brRe = /\r?\n/g;
var substrPolyfill = function(value, start, length) {
  const str = String(value);
  return start < 0 ? str.substr(Math.max(str.length + start, 0), length) : str.substr(start, length);
};
var substrOriginal = function(value, start, length) {
  return String(value).substr(start, length);
};
var UtilFormat = {
  thousandSeparator: ",",
  decimalSeparator: ".",
  /**
   * 返回一个非 undefined 的值，如果 value 为 undefined，则返回空字符串
   *
   * @param {*} value - 任意类型的值
   * @returns {string} - 返回一个字符串
   * @example
   * undef(undefined); // ''
   * undef(null); // null
   * undef('hello'); // 'hello'
   */
  undef: function(value) {
    return value !== void 0 ? value : "";
  },
  /**
   * 如果 value 不是 undefined 或空字符串，则返回 value，否则返回 defaultValue
   *
   * @param {*} value - 任意类型的值
   * @param {*} defaultValue - 任意类型的默认值
   * @returns {*} - 返回一个值
   * @example
   * defaultValue(undefined, 'default'); // 'default'
   * defaultValue(null, 'default'); // null
   * defaultValue('', 'default'); // 'default'
   * defaultValue('hello', 'default'); // 'hello'
   */
  defaultValue: function(value, defaultValue) {
    return value !== void 0 && value !== "" ? value : defaultValue;
  },
  substr: "ab".substr(-1) !== "b" ? substrPolyfill : substrOriginal,
  lowercase: function(value) {
    return String(value).toLowerCase();
  },
  uppercase: function(value) {
    return String(value).toUpperCase();
  },
  /**
   * 去除字符串中的 HTML 标签
   *
   * @param {string} v - 要处理的字符串
   * @returns {string} - 返回处理后的字符串
   * @example
   * stripTags('<p>hello</p>'); // 'hello'
   */
  stripTags: function(v) {
    return !v ? v : String(v).replace(stripTagsRE, "");
  },
  /**
   * 去除字符串中的 JavaScript 代码
   *
   * @param {string} v - 要处理的字符串
   * @returns {string} - 返回处理后的字符串
   * @example
   * stripScripts('<script>alert("hello");</script>'); // 'alert("hello");'
   */
  stripScripts: function(v) {
    return !v ? v : String(v).replace(stripScriptsRe, "");
  },
  /**
   * 将文件大小转换为易读的格式
   *
   * @param {number} size - 文件大小，单位为字节
   * @returns {string} - 返回易读的文件大小字符串
   * @example
   * fileSize(1024); // '1 KB'
   * fileSize(1048576); // '1 MB'
   * fileSize(1073741824); // '1 GB'
   * fileSize(1099511627776); // '1 TB'
   */
  fileSize: function() {
    const byteLimit = 1024, kbLimit = 1048576, mbLimit = 1073741824, gbLimit = mbLimit * 1024;
    return function(size) {
      let out;
      if (size < byteLimit) {
        if (size === 1) {
          out = "1 byte";
        } else {
          out = size + " bytes";
        }
      } else if (size < kbLimit) {
        out = Math.round(size * 10 / byteLimit) / 10 + " KB";
      } else if (size < mbLimit) {
        out = Math.round(size * 10 / kbLimit) / 10 + " MB";
      } else if (size < gbLimit) {
        out = Math.round(size * 10 / mbLimit) / 10 + " GB";
      } else {
        out = Math.round(size * 10 / gbLimit) / 10 + " TB";
      }
      return out;
    };
  }(),
  /**
   * 对数字进行四舍五入
   *
   * @param {number} value - 要处理的数字
   * @param {number} [precision] - 精度，保留小数点后几位
   * @returns {number} - 返回处理后的数字
   * @example
   * round(1.2345); // 1
   * round(1.2345, 2); // 1.23
   */
  round: function(value, precision) {
    let result = Number(value);
    if (typeof precision === "number") {
      precision = Math.pow(10, precision);
      result = Math.round(value * precision) / precision;
    }
    return result;
  },
  /**
   * 根据数量返回单数或复数形式的字符串
   *
   * @param {number} v - 数量
   * @param {string} s - 单数形式的字符串
   * @param {string} [p] - 复数形式的字符串，如果未提供，则在 s 后面加上 's'
   * @returns {string} - 返回单数或复数形式的字符串
   * @example
   * plural(1, 'apple', 'apples'); // '1 apple'
   * plural(2, 'apple', 'apples'); // '2 apples'
   * plural(0, 'apple', 'apples'); // '0 apples'
   */
  plural: function(v, s, p) {
    return v + " " + (v === 1 ? s : p ? p : s + "s");
  },
  /**
   * 将字符串中的换行符转换为 <br/> 标签
   *
   * @param {string} v - 要处理的字符串
   * @returns {string} - 返回处理后的字符串
   * @example
   * nl2br('hello\nworld'); // 'hello<br/>world'
   */
  nl2br: function(v) {
    return !v ? "" : v.replace(nl2brRe, "<br/>");
  },
  /**
   * 格式化字符串，将字符串中的占位符替换为对应的值
   *
   * @param {string} str - 要格式化的字符串
   * @param {Object} map - 包含占位符对应值的对象
   * @returns {string} - 返回格式化后的字符串
   * @example
   * xformat('hello {name}', { name: 'world' }); // 'hello world'
   */
  xformat: function(str, map) {
    if (!map) {
      return str;
    }
    return str.replace(/\{([^}]+)\}/g, function(m, keysStr) {
      const keys = keysStr.replace(/#[^#]*$/, "").split(".");
      let val = map, key;
      while (val && (key = keys.shift())) {
        val = val[key];
      }
      return val;
    });
  },
  capitalize: _String.capitalize,
  ellipsis: _String.ellipsis,
  format: _String.format,
  htmlDecode: _String.htmlDecode,
  htmlEncode: _String.htmlEncode,
  htmlTextEncode: _String.htmlTextEncode,
  htmlDoubleEncode: _String.htmlDoubleEncode,
  leftPad: _String.leftPad,
  trim: _String.trim,
  parseBox: function(box) {
    box = box || 0;
    if (typeof box === "number") {
      return {
        top: box,
        right: box,
        bottom: box,
        left: box
      };
    }
    const parts = box.split(" "), ln = parts.length;
    if (ln === 1) {
      parts[1] = parts[2] = parts[3] = parts[0];
    } else if (ln === 2) {
      parts[2] = parts[0];
      parts[3] = parts[1];
    } else if (ln === 3) {
      parts[3] = parts[1];
    }
    return {
      top: parseInt(parts[0], 10) || 0,
      right: parseInt(parts[1], 10) || 0,
      bottom: parseInt(parts[2], 10) || 0,
      left: parseInt(parts[3], 10) || 0
    };
  },
  escapeRegex: function(s) {
    return s.replace(/([-.*+?^${}()|[\]/\\])/g, "\\$1");
  },
  /**
   * 获取时间戳
   *
   * @param {string} date - 日期字符串 以-分隔
   * @param {string} time - 时间字符串 以:分隔
   * @returns {number} - 时间戳
   * @example
   * UtilFormat.getTime('2000-11-11', '11:11:11'); // 973084271000
   */
  getTime: function(date, time) {
    const times = [];
    date = date || "";
    time = time || "";
    date.split("-").forEach(function(item, i) {
      item = parseInt(item, 10);
      if (i === 1) {
        item -= 1;
      }
      times.push(item);
    });
    time.split(":").forEach(function(item) {
      item = parseInt(item, 10);
      times.push(item);
    });
    return new Date(times[0] || 0, times[1] || 0, times[2] || 0, times[3] || 0, times[4] || 0, times[5] || 0).getTime();
  },
  /**
   * 获取当前时区
   *
   * @returns {number} - 当前时区
   * @example
   * UtilFormat.getTimeZone(); // 8
   */
  getTimeZone: function() {
    if (!globalConfig.timeZone && globalConfig.timeZone !== 0) {
      return (/* @__PURE__ */ new Date()).getTimezoneOffset() / -60;
    } else {
      return Number(globalConfig.timeZone) + (globalConfig.timeZoneOffset || 0);
    }
  },
  /**
   * 时间格式化的函数 简化实现，只支持YmdHis几种关键字
   *
   * @param {Date|string|number} date - 日期对象，或者时间戳（可以是数字或者字符串）,分割符/将被替换成-
   * ```
   *              2018-[0]5-31
   *              2018-[0]5-31 [0]8:30
   *              2018-[0]5-31 [0]8:30:[0]5
   *              2018-[0]5-31T[0]8:30:[0]5Z
   *              2018-[0]5-31T[0]8:30:[0]5+[0]8
   *              2018-[0]5-31T[0]8:30:[0]5+[0]8:00
   *              2018-[0]5-31T[0]8:30:[0]5+0800
   * ```
   * @param {string} [format='Y-m-d H:i:s'] - 时间格式字符串
   * @returns {string} - 格式化后的时间字符串
   * @example
   * UtilFormat.date(new Date(), 'Y-m-d'); // '2023-04-11'
   */
  date: function(date, format) {
    const type = typeof date;
    if (!date && date !== 0) {
      return "";
    }
    if (type === "string" || type === "number") {
      if (/^\d+$/.test(String(date))) {
        date = String(date).length === 10 ? date * 1e3 : date;
      }
      date = UtilFormat.dateInstance(date);
    }
    const func = UtilFormat.dateFmtFun;
    return (format || "Y-m-d H:i:s").replace(UtilFormat.dateFmtRegex, function(m) {
      return func[m] ? func[m](date) : m;
    });
  },
  /** 将后台返回的以下格式的日期对象，处理返回new Date,该函数是为了兼容chrome 56.0.2924.87(64-bit)
   *
   * @param {Date|string|number} date - 日期对象，或者时间戳（可以是数字或者字符串）,分割符/将被替换成-
   * @returns {Date} - 处理后的日期对象
   * @example
   * UtilFormat.dateInstance('2018-05-31 08:30:05'); // Date('2018-05-31T00:30:05.000Z')
   */
  dateInstance: function(date) {
    const type = typeof date;
    let timeZone, timeZoneArr;
    if (type === "string") {
      date = UtilFormat.trim(date).replace("/", "-").replace(/\s/, "T").replace(/\d(?!\d)/g, function(char, index, str) {
        const preChar = str[index - 1];
        if (!Number(preChar) && preChar !== "0") {
          return "0" + char;
        }
        return char;
      });
      if (!/T\d{2}:\d{2}/.test(date)) {
        date += !/T$/.test(date) ? "T00:00" : "00:00";
      }
      if (!/(Z$|\+|-\d{2}$|-\d{4}$|-\d{2}:\d{2}$)/.test(date)) {
        timeZone = UtilFormat.getTimeZone();
        timeZoneArr = timeZone.toString().split(".");
        timeZone = UtilFormat.format(
          "{0}{1}:{2}",
          timeZone < 0 ? "-" : "+",
          UtilFormat.leftPad(Math.abs(timeZoneArr[0]), 2, "0"),
          timeZoneArr[1] ? UtilFormat.leftPad(Math.abs(parseInt((timeZone - Number(timeZoneArr[0])) * 60, 10)), 2, "0") : "00"
        );
        date = UtilFormat.format("{0}{1}", date, timeZone);
      } else if (/(\+|-)\d{2}$/.test(date)) {
        date += ":00";
      }
      if (/\d{4}$/.test(date)) {
        date = date.replace(/(\d{2}$)/, ":$1");
      }
    }
    return new Date(date);
  },
  dateFmtRegex: /[YmdHis]/g,
  dateFmtFun: {
    Y: function(date) {
      return date.getFullYear();
    },
    m: function(date) {
      const m = date.getMonth() + 1;
      return UtilFormat.leftPad(m, 2, "0");
    },
    d: function(date) {
      const d = date.getDate();
      return UtilFormat.leftPad(d, 2, "0");
    },
    H: function(date) {
      const h = date.getHours();
      return UtilFormat.leftPad(h, 2, "0");
    },
    i: function(date) {
      const h = date.getMinutes();
      return UtilFormat.leftPad(h, 2, "0");
    },
    s: function(date) {
      const h = date.getSeconds();
      return UtilFormat.leftPad(h, 2, "0");
    }
  },
  /**
   * 时间格式化的函数，返回统一格式的时间处理函数
   *
   * @param {string} format - 时间格式字符串
   * @returns {Function} - 统一格式的时间处理函数
   * @example
   * const renderer = UtilFormat.dateRenderer('Y-m-d');
   * renderer(new Date()); // '2023-04-11'
   */
  dateRenderer: function(format) {
    return function(date) {
      return UtilFormat.date(date, format);
    };
  },
  /**
   * 根据相隔的天数返回日期
   *
   * @param {string|number} number - 相隔的天数
   * @returns {Date} - 日期对象
   * @example
   * UtilFormat.getDateFromNow(-1); // Date('2023-04-10T16:00:00.000Z')
   */
  getDateFromNow: function(number) {
    number = parseInt(number, 10) || 0;
    const date = /* @__PURE__ */ new Date();
    date.setDate(date.getDate() + number);
    return date;
  },
  /**
   * 根据相隔的天数返回日期范围
   *
   * @param {string|number} number - 相隔的天数
   * @param {string|boolean} [format=false] - 时间格式字符串，不传不进行格式化，传true为默认format.date的默认值
   * @returns {Date[]} - 日期范围数组
   * @example
   * UtilFormat.getDateRangeFromNow(0, true); // ['2023-04-11', '2023-04-11']
   */
  getDateRangeFromNow: function(number, format) {
    number = parseInt(number, 10) || 0;
    let end = /* @__PURE__ */ new Date();
    let start = UtilFormat.getDateFromNow(number);
    if (format) {
      format = typeof format === "string" ? format : "";
      start = UtilFormat.date(start, format);
      end = UtilFormat.date(end, format);
    }
    return [start, end];
  },
  /**
   * 把后台返回的时间戳转化成对应的时间格式
   *
   * @param {number|string} serverTime - 后台返回的时间戳
   * @param {string} [format='Y-m-d H:i:s'] - 时间格式字符串
   * @returns {string} - 格式化后的时间字符串
   * @example
   * UtilFormat.formatToVMPTime(123456456); // '1970-12-12 11:01:58'
   */
  formatToVMPTime: function(serverTime, format) {
    if (!serverTime) {
      return "";
    }
    format = format || "Y-m-d H:i:s";
    const curComputerTimeZone = (/* @__PURE__ */ new Date()).getTimezoneOffset() / -60;
    const curServerTimeZone = globalConfig.timeZone || curComputerTimeZone;
    serverTime = parseInt(serverTime, 10) - (curComputerTimeZone - curServerTimeZone) * 3600;
    return this.date(serverTime * 1e3, format);
  },
  /**
   * 把IPV4转换成Int32的形式
   *
   * @param {string} ip - IPV4地址
   * @return {number} - 转换后的Int32形式
   * @example
   * UtilFormat.ip2int('192.168.1.1'); // 3232235777
   */
  ip2int: function(ip) {
    const text = this.trim(ip.toString());
    const a = text.split(".");
    return parseInt(a[0], 10) * 256 * 256 * 256 + parseInt(a[1], 10) * 256 * 256 + parseInt(a[2], 10) * 256 + parseInt(a[3], 10);
  },
  /**
   * 把Int32转换成IPV4的形式
   *
   * @param {string|number} num - Int32形式的IP地址
   * @return {string} - 转换后的IPV4地址
   * @example
   * UtilFormat.int2ip(3232235777); // '192.168.1.1'
   */
  int2ip: function(num) {
    let ipInt = parseInt(this.trim(num.toString()), 10), ip = "";
    ip += Math.floor(ipInt / (256 * 256 * 256)) + ".";
    ipInt = ipInt % (256 * 256 * 256);
    ip += Math.floor(ipInt / (256 * 256)) + ".";
    ipInt = ipInt % (256 * 256);
    ip += Math.floor(ipInt / 256) + ".";
    ipInt = ipInt % 256;
    ip += Math.floor(ipInt);
    return ip;
  },
  /**
   * 把int型整数转换为2进制数
   *
   * @param {number} n - 整数
   * @returns {string} - 转换后的2进制数
   * @example
   * UtilFormat.int2bit(10); // '00001010'
   */
  int2bit: function(n) {
    let i = 8;
    let b = 255;
    const s = [];
    while (i--) {
      b /= 2;
      if (n >= b) {
        n -= b;
        s.push(1);
      } else {
        s.push(0);
      }
    }
    return s.join("");
  },
  /**
   * 将ip转换为32位2进制串
   *
   * @param {string} ip - IPV4地址
   * @returns {string} - 转换后的32位2进制串
   * @example
   * UtilFormat.ip2bit('192.168.1.1'); // '11000000101010000000000100000001'
   */
  ip2bit: function(ip) {
    ip = ip.split(".");
    const s = [];
    for (let i = 0; i < 4; ++i) {
      s.push(UtilFormat.int2bit(parseInt(ip[i], 10)));
    }
    return s.join("");
  },
  /**
   * 将掩码转换为Int32的形式
   *
   * @param {string|number} mask - 掩码
   * @returns {number} - 转换后的Int32形式
   * @example
   * UtilFormat.mask2int('255.255.255.0'); // 4294967040
   */
  mask2int: function(mask) {
    let num = 0;
    mask = String(mask);
    if (mask.match(/^\d+$/)) {
      num = -1 << 32 - mask;
      num >>>= 0;
    } else {
      num = UtilFormat.ip2int(mask);
    }
    return num;
  },
  /**
   * 将Int的形式转换为掩码ip
   *
   * @param {string|number} num - Int32形式的掩码
   * @returns {string} - 转换后的掩码IPV4地址
   * @example
   * UtilFormat.int2mask(4294967040); // '255.255.255.0'
   */
  int2mask: function(num) {
    return UtilFormat.int2ip(UtilFormat.mask2int(num));
  },
  /**
   * 网段生成默认IP范围 ipStart(最大值) ipEnd(最小值)
   *
   * @param {string} networkSegment - 网络地址和掩码
   * @returns {{ipStart: number, ipEnd: number}} - IP范围
   * @example
   * UtilFormat.networkSegmentToDefaultIpRange('192.168.1.0/24'); // { ipStart: 3232235776, ipEnd: 3232236031 }
   */
  networkSegmentToDefaultIpRange: function(networkSegment) {
    if (!networkSegment) {
      return;
    }
    const networkSegmentArr = networkSegment.split("/"), netIP = networkSegmentArr[0], netMasklen = Number(networkSegmentArr[1]), maskInt = UtilFormat.mask2int(netMasklen), maskMin = (UtilFormat.ip2int(netIP) & maskInt) >>> 0, ipStart = maskMin, ipEnd = maskMin + ~maskInt;
    return {
      ipStart,
      ipEnd
    };
  },
  /**
   * 把ip范围输入值去重后，转化成ip形式的，单ip数组和ip范围的二维数组
   * 如：singleIps: ['192.168.1.1']，ipRanges:[['192.168.1.1', '192.168.1.10']]
   *
   * @param {string} ipValue - IP地址范围输入值
   * @returns {{singleIps: string[], ipRanges: string[][]}} - 转换后的IP地址数组
   * @example
   * UtilFormat.transformIpRange('192.168.1.1, 192.168.1.2-192.168.1.10\n192.168.1.1'); // { singleIps: ['192.168.1.1'], ipRanges: [['192.168.1.2', '192.168.1.10']] }
   */
  transformIpRange: function(ipValue) {
    ipValue = ipValue.replace(/(\n)+?/g, ",");
    let singleIps = [];
    let ipRanges = [];
    const tempIps = ipValue.split(",").map((item) => item.trim());
    const lastIndex = tempIps.length - 1;
    if (!tempIps[lastIndex]) {
      tempIps.splice(lastIndex, 1);
    }
    tempIps.forEach((ip) => {
      if (ip.indexOf("-") > -1) {
        const ipRangeList = ip.split("-").map((item) => item.trim());
        ipRanges.push([ipRangeList[0], ipRangeList[1]]);
      } else {
        singleIps.push(ip);
      }
    });
    singleIps = Array.from(new Set(singleIps));
    if (ipRanges.length) {
      ipRanges = ipRanges.map(([leftIP, rightIP]) => [UtilFormat.ip2int(leftIP), UtilFormat.ip2int(rightIP)]).sort((a, b) => a[0] - b[0]);
      ipRanges = ipRanges.reduce(
        (ipRangesArr, currArr) => {
          const preIndex = ipRangesArr.length - 1;
          const preRight = ipRangesArr[preIndex][1];
          const [currLeft, currRight] = currArr;
          if (preRight < currLeft) {
            ipRangesArr.push(currArr);
          } else {
            ipRangesArr[preIndex][1] = Math.max(currRight, preRight);
          }
          return ipRangesArr;
        },
        [ipRanges[0]]
      );
      for (let i = singleIps.length - 1; i >= 0; i--) {
        const ipInt = UtilFormat.ip2int(singleIps[i]);
        const isExist = ipRanges.some(([leftIP, rightIP]) => ipInt <= rightIP && ipInt >= leftIP);
        if (isExist) {
          singleIps.splice(i, 1);
        }
      }
      ipRanges = ipRanges.map(([leftIP, rightIP]) => [UtilFormat.int2ip(leftIP), UtilFormat.int2ip(rightIP)]);
    }
    return {
      singleIps,
      ipRanges
    };
  },
  /**
   * 把秒数转化成 X天X小时X分X秒 的形式
   *
   * @param {number} value - 秒数
   * @param {string} level - 精确度(day || hour || minute || second)
   * @return {string} - X天X小时X分X秒 的形式
   * @example
   * secToDate(3600, 'hour') // '1小时'
   */
  secToDate: function(value, level) {
    let val = 0;
    const aMinute = 60, aHour = aMinute * 60, aDate = aHour * 24, text = [], levelMap = {
      day: 1,
      hour: 2,
      minute: 3,
      second: 4
    };
    value = value || 0;
    level = levelMap[level] || 4;
    if (level >= 1 && value >= aDate) {
      val = Math.floor(value / aDate);
      text.push(
        val,
        val > 1 ? $i("scp.vt_component.common.util.Format.days") : $i("scp.vt_component.common.util.Format.day")
      );
    }
    if (level >= 2) {
      value = value % aDate;
      if (value >= aHour) {
        val = Math.floor(value / aHour);
        text.push(
          val,
          val > 1 ? $i("scp.vt_component.common.util.Format.hours") : $i("scp.vt_component.common.util.Format.hour")
        );
      }
    }
    if (level >= 3) {
      value = value % aHour;
      if (value >= aMinute) {
        val = Math.floor(value / aMinute);
        text.push(
          val,
          val > 1 ? $i("scp.vt_component.common.util.Format.minutes") : $i("scp.vt_component.common.util.Format.minute")
        );
      }
    }
    if (level >= 4) {
      value = value % aMinute;
      if (value !== 0 || !text.length) {
        text.push(
          value,
          value > 1 ? $i("scp.vt_component.common.util.Format.seconds") : $i("scp.vt_component.common.util.Format.second")
        );
      }
    }
    return text.join($i("scp.vt_component.common.util.Format.level_text"));
  },
  /**
   * 把秒数转化成：“00:01:23” 时分秒的形式
   *
   * @param {number} time - 秒数
   * @return {string} - “00:01:23” 时分秒的形式
   * @example
   * secToTime(123) // '00:02:03'
   */
  secToTime: function(time) {
    const amin = 60, ahour = 60 * amin, ret = [];
    const h = Math.floor(time / ahour);
    if (h) {
      if (h > 9) {
        ret.push(String(h));
      } else {
        ret.push("0" + String(h));
      }
    } else {
      ret.push("00");
    }
    time = time % ahour;
    const min = Math.floor(time / amin);
    if (min) {
      if (min > 9) {
        ret.push(String(min));
      } else {
        ret.push("0" + String(min));
      }
    } else {
      ret.push("00");
    }
    time = time % amin;
    if (time) {
      if (time > 9) {
        ret.push(String(time));
      } else {
        ret.push("0" + String(time));
      }
    } else {
      ret.push("00");
    }
    return ret.join(":");
  },
  /**
   * 计算字符串的utf8字节数
   *
   * @param {string} s - 要计算的字符串
   * @return {number} - utf8字节数
   * @example
   * utf8Length('你好') // 6
   */
  utf8Length: function(s) {
    let totalLength = 0;
    let i;
    let charCode;
    s = String(s);
    for (i = 0; i < s.length; i++) {
      charCode = s.charCodeAt(i);
      if (charCode < 127) {
        totalLength = totalLength + 1;
      } else if (128 <= charCode && charCode <= 2047) {
        totalLength += 2;
      } else if (2048 <= charCode && charCode <= 65535) {
        totalLength += 3;
      }
    }
    return totalLength;
  },
  /**
   * 获取指定长度limit的字符串
   *
   * @param {string} str - 需要处理的字符串
   * @param {number} limit - 字符串长度限制
   * @param {boolean} useUTF8Len - 是否使用utf8长度
   * @return {string} - 处理后的字符串
   * @example
   * limitString('hello world', 5) // 'hello'
   */
  limitString: function(str, limit, useUTF8Len) {
    const normalGetLength = (value) => value.length;
    const getLength = useUTF8Len ? UtilFormat.utf8Length : normalGetLength;
    let len = 0, i;
    for (i = 0; i < str.length; i++) {
      len += getLength(str[i]);
      if (len > limit) {
        return str.substring(0, i);
      }
    }
    return str;
  },
  /**
   * 大数值每三位隔一逗号
   *
   * @param {number} num - 要计算的数值
   * @return {string} - 每三位隔一逗号字符串的字符串
   * @example
   * commaDivide(1234567) // '1,234,567'
   */
  commaDivide: function(num) {
    const str = num.toString();
    return str.replace(/\d(?=(?:\d{3})+\b)/g, "$&,");
  },
  /**
   * 获取近几个月的总天数
   *
   * @param {number} count - 要计算的近几个月数量
   * @return {number} - 近几个月的天数总和
   * @example
   * getRecentMonthDays(3) // 91
   */
  getRecentMonthDays: function(count) {
    const nowDate = /* @__PURE__ */ new Date(), currYear = nowDate.getFullYear(), currentMonth = nowDate.getMonth() + 1;
    let days = 0;
    for (let i = 0; i < count; i++) {
      let year = currYear, month = currentMonth - i;
      if (i >= currentMonth) {
        year = currYear - 1 - Math.floor((i - currentMonth) / 12);
        month = 12 - (i - currentMonth) % 12;
        days += new Date(year, month, 0).getDate();
        continue;
      }
      days += new Date(year, month, 0).getDate();
    }
    return days;
  },
  /**
   * 将文本分行
   *
   * @param {string} str - 要处理的文本
   * @return {Array} - 返回每一行的数组
   * @example
   * getLines('hello\nworld') // ['hello', 'world']
   */
  getLines: function(str) {
    return str.split(/(?:[\s\uFEFF\xA0]*\r?\n[\s\uFEFF\xA0]*)+/);
  },
  /**
   * 将提示内容转换为HTML格式的字符串
   *
   * @param {string | Array} tip - 提示内容，可以是字符串或字符串数组
   * @returns {string} - 返回HTML格式的字符串
   * @example
   * getContentTip('这是一条提示信息') // '这是一条提示信息'
   * getContentTip(['这是第一行', '这是第二行']) // '这是第一行<br />这是第二行'
   */
  getContentTip: function(tip) {
    if (!Array.isArray(tip)) {
      return UtilFormat.htmlEncode(tip);
    }
    return tip.reduce((target, content) => {
      if (typeof content === "string") {
        target.push(UtilFormat.htmlEncode(content));
      }
      return target;
    }, []).join("<br />");
  }
};
var format_default = UtilFormat;
export {
  format_default as default
};
