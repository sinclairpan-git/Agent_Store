/**
 * 生成唯一的自增 id
 *
 * @param {String} [prefix='x-gen'] - id 前缀，默认为 "x-gen"
 * @return {String} 生成的 id。
 *
 * @example
 *
 * uuid(); // "x-gen1"
 * uuid('my-prefix-'); // "my-prefix-2"
 */
declare function uuid(prefix?: string | undefined): string;

export { uuid as default };
