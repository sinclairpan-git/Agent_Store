// packages/utils/uuid/index.js
var idSeed = 0;
function uuid(prefix) {
  return (prefix || "x-gen") + ++idSeed;
}
var uuid_default = uuid;
export {
  uuid_default as default
};
