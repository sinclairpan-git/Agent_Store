// packages/utils/when/index.js
import $ from "jquery";
function when(...args) {
  const deferreds = args.map((arg) => {
    if (typeof arg === "function") {
      arg = arg();
    }
    if (arg instanceof Promise) {
      const deferred = $.Deferred();
      arg.then(deferred.resolve, deferred.reject);
      return deferred;
    } else {
      return arg;
    }
  });
  return $.when(...deferreds);
}
export {
  when
};
