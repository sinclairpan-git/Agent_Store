/**
 * 封装一个新的 when 方法，函数与 $.when 保持一致，支持传入 Promise 对象
 *
 * @function
 * @param {...(Promise|JQuery.Deferred|*)} args - 一个或多个 Promise 对象或普通值
 * @returns {JQuery.Promise} - 返回一个 JQuery.Promise 对象
 * @example
 * // 使用示例
 * const promise1 = Promise.resolve(3);
 * const promise2 = new Promise((resolve, reject) => setTimeout(resolve, 100, 'foo'));
 * const promise3 = $.ajax({ url: '/api/data', method: 'GET' });
 *
 * when(promise1, promise2, promise3).then((result1, result2, result3) => {
 *   console.log(result1); // 3
 *   console.log(result2); // 'foo'
 *   console.log(result3); // ajax 返回的数据
 * });
 */
declare function when(...args: (Promise<any> | JQuery.Deferred<any, any, any> | any)[]): JQuery.Promise<any, any, any>;

export { when };
