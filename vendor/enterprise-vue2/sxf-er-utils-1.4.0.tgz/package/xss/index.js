var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/.pnpm/cssfilter@0.0.10/node_modules/cssfilter/lib/default.js
var require_default = __commonJS({
  "node_modules/.pnpm/cssfilter@0.0.10/node_modules/cssfilter/lib/default.js"(exports) {
    function getDefaultWhiteList() {
      var whiteList2 = {};
      whiteList2["align-content"] = false;
      whiteList2["align-items"] = false;
      whiteList2["align-self"] = false;
      whiteList2["alignment-adjust"] = false;
      whiteList2["alignment-baseline"] = false;
      whiteList2["all"] = false;
      whiteList2["anchor-point"] = false;
      whiteList2["animation"] = false;
      whiteList2["animation-delay"] = false;
      whiteList2["animation-direction"] = false;
      whiteList2["animation-duration"] = false;
      whiteList2["animation-fill-mode"] = false;
      whiteList2["animation-iteration-count"] = false;
      whiteList2["animation-name"] = false;
      whiteList2["animation-play-state"] = false;
      whiteList2["animation-timing-function"] = false;
      whiteList2["azimuth"] = false;
      whiteList2["backface-visibility"] = false;
      whiteList2["background"] = true;
      whiteList2["background-attachment"] = true;
      whiteList2["background-clip"] = true;
      whiteList2["background-color"] = true;
      whiteList2["background-image"] = true;
      whiteList2["background-origin"] = true;
      whiteList2["background-position"] = true;
      whiteList2["background-repeat"] = true;
      whiteList2["background-size"] = true;
      whiteList2["baseline-shift"] = false;
      whiteList2["binding"] = false;
      whiteList2["bleed"] = false;
      whiteList2["bookmark-label"] = false;
      whiteList2["bookmark-level"] = false;
      whiteList2["bookmark-state"] = false;
      whiteList2["border"] = true;
      whiteList2["border-bottom"] = true;
      whiteList2["border-bottom-color"] = true;
      whiteList2["border-bottom-left-radius"] = true;
      whiteList2["border-bottom-right-radius"] = true;
      whiteList2["border-bottom-style"] = true;
      whiteList2["border-bottom-width"] = true;
      whiteList2["border-collapse"] = true;
      whiteList2["border-color"] = true;
      whiteList2["border-image"] = true;
      whiteList2["border-image-outset"] = true;
      whiteList2["border-image-repeat"] = true;
      whiteList2["border-image-slice"] = true;
      whiteList2["border-image-source"] = true;
      whiteList2["border-image-width"] = true;
      whiteList2["border-left"] = true;
      whiteList2["border-left-color"] = true;
      whiteList2["border-left-style"] = true;
      whiteList2["border-left-width"] = true;
      whiteList2["border-radius"] = true;
      whiteList2["border-right"] = true;
      whiteList2["border-right-color"] = true;
      whiteList2["border-right-style"] = true;
      whiteList2["border-right-width"] = true;
      whiteList2["border-spacing"] = true;
      whiteList2["border-style"] = true;
      whiteList2["border-top"] = true;
      whiteList2["border-top-color"] = true;
      whiteList2["border-top-left-radius"] = true;
      whiteList2["border-top-right-radius"] = true;
      whiteList2["border-top-style"] = true;
      whiteList2["border-top-width"] = true;
      whiteList2["border-width"] = true;
      whiteList2["bottom"] = false;
      whiteList2["box-decoration-break"] = true;
      whiteList2["box-shadow"] = true;
      whiteList2["box-sizing"] = true;
      whiteList2["box-snap"] = true;
      whiteList2["box-suppress"] = true;
      whiteList2["break-after"] = true;
      whiteList2["break-before"] = true;
      whiteList2["break-inside"] = true;
      whiteList2["caption-side"] = false;
      whiteList2["chains"] = false;
      whiteList2["clear"] = true;
      whiteList2["clip"] = false;
      whiteList2["clip-path"] = false;
      whiteList2["clip-rule"] = false;
      whiteList2["color"] = true;
      whiteList2["color-interpolation-filters"] = true;
      whiteList2["column-count"] = false;
      whiteList2["column-fill"] = false;
      whiteList2["column-gap"] = false;
      whiteList2["column-rule"] = false;
      whiteList2["column-rule-color"] = false;
      whiteList2["column-rule-style"] = false;
      whiteList2["column-rule-width"] = false;
      whiteList2["column-span"] = false;
      whiteList2["column-width"] = false;
      whiteList2["columns"] = false;
      whiteList2["contain"] = false;
      whiteList2["content"] = false;
      whiteList2["counter-increment"] = false;
      whiteList2["counter-reset"] = false;
      whiteList2["counter-set"] = false;
      whiteList2["crop"] = false;
      whiteList2["cue"] = false;
      whiteList2["cue-after"] = false;
      whiteList2["cue-before"] = false;
      whiteList2["cursor"] = false;
      whiteList2["direction"] = false;
      whiteList2["display"] = true;
      whiteList2["display-inside"] = true;
      whiteList2["display-list"] = true;
      whiteList2["display-outside"] = true;
      whiteList2["dominant-baseline"] = false;
      whiteList2["elevation"] = false;
      whiteList2["empty-cells"] = false;
      whiteList2["filter"] = false;
      whiteList2["flex"] = false;
      whiteList2["flex-basis"] = false;
      whiteList2["flex-direction"] = false;
      whiteList2["flex-flow"] = false;
      whiteList2["flex-grow"] = false;
      whiteList2["flex-shrink"] = false;
      whiteList2["flex-wrap"] = false;
      whiteList2["float"] = false;
      whiteList2["float-offset"] = false;
      whiteList2["flood-color"] = false;
      whiteList2["flood-opacity"] = false;
      whiteList2["flow-from"] = false;
      whiteList2["flow-into"] = false;
      whiteList2["font"] = true;
      whiteList2["font-family"] = true;
      whiteList2["font-feature-settings"] = true;
      whiteList2["font-kerning"] = true;
      whiteList2["font-language-override"] = true;
      whiteList2["font-size"] = true;
      whiteList2["font-size-adjust"] = true;
      whiteList2["font-stretch"] = true;
      whiteList2["font-style"] = true;
      whiteList2["font-synthesis"] = true;
      whiteList2["font-variant"] = true;
      whiteList2["font-variant-alternates"] = true;
      whiteList2["font-variant-caps"] = true;
      whiteList2["font-variant-east-asian"] = true;
      whiteList2["font-variant-ligatures"] = true;
      whiteList2["font-variant-numeric"] = true;
      whiteList2["font-variant-position"] = true;
      whiteList2["font-weight"] = true;
      whiteList2["grid"] = false;
      whiteList2["grid-area"] = false;
      whiteList2["grid-auto-columns"] = false;
      whiteList2["grid-auto-flow"] = false;
      whiteList2["grid-auto-rows"] = false;
      whiteList2["grid-column"] = false;
      whiteList2["grid-column-end"] = false;
      whiteList2["grid-column-start"] = false;
      whiteList2["grid-row"] = false;
      whiteList2["grid-row-end"] = false;
      whiteList2["grid-row-start"] = false;
      whiteList2["grid-template"] = false;
      whiteList2["grid-template-areas"] = false;
      whiteList2["grid-template-columns"] = false;
      whiteList2["grid-template-rows"] = false;
      whiteList2["hanging-punctuation"] = false;
      whiteList2["height"] = true;
      whiteList2["hyphens"] = false;
      whiteList2["icon"] = false;
      whiteList2["image-orientation"] = false;
      whiteList2["image-resolution"] = false;
      whiteList2["ime-mode"] = false;
      whiteList2["initial-letters"] = false;
      whiteList2["inline-box-align"] = false;
      whiteList2["justify-content"] = false;
      whiteList2["justify-items"] = false;
      whiteList2["justify-self"] = false;
      whiteList2["left"] = false;
      whiteList2["letter-spacing"] = true;
      whiteList2["lighting-color"] = true;
      whiteList2["line-box-contain"] = false;
      whiteList2["line-break"] = false;
      whiteList2["line-grid"] = false;
      whiteList2["line-height"] = false;
      whiteList2["line-snap"] = false;
      whiteList2["line-stacking"] = false;
      whiteList2["line-stacking-ruby"] = false;
      whiteList2["line-stacking-shift"] = false;
      whiteList2["line-stacking-strategy"] = false;
      whiteList2["list-style"] = true;
      whiteList2["list-style-image"] = true;
      whiteList2["list-style-position"] = true;
      whiteList2["list-style-type"] = true;
      whiteList2["margin"] = true;
      whiteList2["margin-bottom"] = true;
      whiteList2["margin-left"] = true;
      whiteList2["margin-right"] = true;
      whiteList2["margin-top"] = true;
      whiteList2["marker-offset"] = false;
      whiteList2["marker-side"] = false;
      whiteList2["marks"] = false;
      whiteList2["mask"] = false;
      whiteList2["mask-box"] = false;
      whiteList2["mask-box-outset"] = false;
      whiteList2["mask-box-repeat"] = false;
      whiteList2["mask-box-slice"] = false;
      whiteList2["mask-box-source"] = false;
      whiteList2["mask-box-width"] = false;
      whiteList2["mask-clip"] = false;
      whiteList2["mask-image"] = false;
      whiteList2["mask-origin"] = false;
      whiteList2["mask-position"] = false;
      whiteList2["mask-repeat"] = false;
      whiteList2["mask-size"] = false;
      whiteList2["mask-source-type"] = false;
      whiteList2["mask-type"] = false;
      whiteList2["max-height"] = true;
      whiteList2["max-lines"] = false;
      whiteList2["max-width"] = true;
      whiteList2["min-height"] = true;
      whiteList2["min-width"] = true;
      whiteList2["move-to"] = false;
      whiteList2["nav-down"] = false;
      whiteList2["nav-index"] = false;
      whiteList2["nav-left"] = false;
      whiteList2["nav-right"] = false;
      whiteList2["nav-up"] = false;
      whiteList2["object-fit"] = false;
      whiteList2["object-position"] = false;
      whiteList2["opacity"] = false;
      whiteList2["order"] = false;
      whiteList2["orphans"] = false;
      whiteList2["outline"] = false;
      whiteList2["outline-color"] = false;
      whiteList2["outline-offset"] = false;
      whiteList2["outline-style"] = false;
      whiteList2["outline-width"] = false;
      whiteList2["overflow"] = false;
      whiteList2["overflow-wrap"] = false;
      whiteList2["overflow-x"] = false;
      whiteList2["overflow-y"] = false;
      whiteList2["padding"] = true;
      whiteList2["padding-bottom"] = true;
      whiteList2["padding-left"] = true;
      whiteList2["padding-right"] = true;
      whiteList2["padding-top"] = true;
      whiteList2["page"] = false;
      whiteList2["page-break-after"] = false;
      whiteList2["page-break-before"] = false;
      whiteList2["page-break-inside"] = false;
      whiteList2["page-policy"] = false;
      whiteList2["pause"] = false;
      whiteList2["pause-after"] = false;
      whiteList2["pause-before"] = false;
      whiteList2["perspective"] = false;
      whiteList2["perspective-origin"] = false;
      whiteList2["pitch"] = false;
      whiteList2["pitch-range"] = false;
      whiteList2["play-during"] = false;
      whiteList2["position"] = false;
      whiteList2["presentation-level"] = false;
      whiteList2["quotes"] = false;
      whiteList2["region-fragment"] = false;
      whiteList2["resize"] = false;
      whiteList2["rest"] = false;
      whiteList2["rest-after"] = false;
      whiteList2["rest-before"] = false;
      whiteList2["richness"] = false;
      whiteList2["right"] = false;
      whiteList2["rotation"] = false;
      whiteList2["rotation-point"] = false;
      whiteList2["ruby-align"] = false;
      whiteList2["ruby-merge"] = false;
      whiteList2["ruby-position"] = false;
      whiteList2["shape-image-threshold"] = false;
      whiteList2["shape-outside"] = false;
      whiteList2["shape-margin"] = false;
      whiteList2["size"] = false;
      whiteList2["speak"] = false;
      whiteList2["speak-as"] = false;
      whiteList2["speak-header"] = false;
      whiteList2["speak-numeral"] = false;
      whiteList2["speak-punctuation"] = false;
      whiteList2["speech-rate"] = false;
      whiteList2["stress"] = false;
      whiteList2["string-set"] = false;
      whiteList2["tab-size"] = false;
      whiteList2["table-layout"] = false;
      whiteList2["text-align"] = true;
      whiteList2["text-align-last"] = true;
      whiteList2["text-combine-upright"] = true;
      whiteList2["text-decoration"] = true;
      whiteList2["text-decoration-color"] = true;
      whiteList2["text-decoration-line"] = true;
      whiteList2["text-decoration-skip"] = true;
      whiteList2["text-decoration-style"] = true;
      whiteList2["text-emphasis"] = true;
      whiteList2["text-emphasis-color"] = true;
      whiteList2["text-emphasis-position"] = true;
      whiteList2["text-emphasis-style"] = true;
      whiteList2["text-height"] = true;
      whiteList2["text-indent"] = true;
      whiteList2["text-justify"] = true;
      whiteList2["text-orientation"] = true;
      whiteList2["text-overflow"] = true;
      whiteList2["text-shadow"] = true;
      whiteList2["text-space-collapse"] = true;
      whiteList2["text-transform"] = true;
      whiteList2["text-underline-position"] = true;
      whiteList2["text-wrap"] = true;
      whiteList2["top"] = false;
      whiteList2["transform"] = false;
      whiteList2["transform-origin"] = false;
      whiteList2["transform-style"] = false;
      whiteList2["transition"] = false;
      whiteList2["transition-delay"] = false;
      whiteList2["transition-duration"] = false;
      whiteList2["transition-property"] = false;
      whiteList2["transition-timing-function"] = false;
      whiteList2["unicode-bidi"] = false;
      whiteList2["vertical-align"] = false;
      whiteList2["visibility"] = false;
      whiteList2["voice-balance"] = false;
      whiteList2["voice-duration"] = false;
      whiteList2["voice-family"] = false;
      whiteList2["voice-pitch"] = false;
      whiteList2["voice-range"] = false;
      whiteList2["voice-rate"] = false;
      whiteList2["voice-stress"] = false;
      whiteList2["voice-volume"] = false;
      whiteList2["volume"] = false;
      whiteList2["white-space"] = false;
      whiteList2["widows"] = false;
      whiteList2["width"] = true;
      whiteList2["will-change"] = false;
      whiteList2["word-break"] = true;
      whiteList2["word-spacing"] = true;
      whiteList2["word-wrap"] = true;
      whiteList2["wrap-flow"] = false;
      whiteList2["wrap-through"] = false;
      whiteList2["writing-mode"] = false;
      whiteList2["z-index"] = false;
      return whiteList2;
    }
    function onAttr(name, value, options) {
    }
    function onIgnoreAttr(name, value, options) {
    }
    var REGEXP_URL_JAVASCRIPT = /javascript\s*\:/img;
    function safeAttrValue(name, value) {
      if (REGEXP_URL_JAVASCRIPT.test(value))
        return "";
      return value;
    }
    exports.whiteList = getDefaultWhiteList();
    exports.getDefaultWhiteList = getDefaultWhiteList;
    exports.onAttr = onAttr;
    exports.onIgnoreAttr = onIgnoreAttr;
    exports.safeAttrValue = safeAttrValue;
  }
});

// node_modules/.pnpm/cssfilter@0.0.10/node_modules/cssfilter/lib/util.js
var require_util = __commonJS({
  "node_modules/.pnpm/cssfilter@0.0.10/node_modules/cssfilter/lib/util.js"(exports, module) {
    module.exports = {
      indexOf: function(arr, item) {
        var i, j;
        if (Array.prototype.indexOf) {
          return arr.indexOf(item);
        }
        for (i = 0, j = arr.length; i < j; i++) {
          if (arr[i] === item) {
            return i;
          }
        }
        return -1;
      },
      forEach: function(arr, fn, scope) {
        var i, j;
        if (Array.prototype.forEach) {
          return arr.forEach(fn, scope);
        }
        for (i = 0, j = arr.length; i < j; i++) {
          fn.call(scope, arr[i], i, arr);
        }
      },
      trim: function(str) {
        if (String.prototype.trim) {
          return str.trim();
        }
        return str.replace(/(^\s*)|(\s*$)/g, "");
      },
      trimRight: function(str) {
        if (String.prototype.trimRight) {
          return str.trimRight();
        }
        return str.replace(/(\s*$)/g, "");
      }
    };
  }
});

// node_modules/.pnpm/cssfilter@0.0.10/node_modules/cssfilter/lib/parser.js
var require_parser = __commonJS({
  "node_modules/.pnpm/cssfilter@0.0.10/node_modules/cssfilter/lib/parser.js"(exports, module) {
    var _ = require_util();
    function parseStyle(css, onAttr) {
      css = _.trimRight(css);
      if (css[css.length - 1] !== ";")
        css += ";";
      var cssLength = css.length;
      var isParenthesisOpen = false;
      var lastPos = 0;
      var i = 0;
      var retCSS = "";
      function addNewAttr() {
        if (!isParenthesisOpen) {
          var source = _.trim(css.slice(lastPos, i));
          var j2 = source.indexOf(":");
          if (j2 !== -1) {
            var name = _.trim(source.slice(0, j2));
            var value = _.trim(source.slice(j2 + 1));
            if (name) {
              var ret = onAttr(lastPos, retCSS.length, name, value, source);
              if (ret)
                retCSS += ret + "; ";
            }
          }
        }
        lastPos = i + 1;
      }
      for (; i < cssLength; i++) {
        var c = css[i];
        if (c === "/" && css[i + 1] === "*") {
          var j = css.indexOf("*/", i + 2);
          if (j === -1)
            break;
          i = j + 1;
          lastPos = i + 1;
          isParenthesisOpen = false;
        } else if (c === "(") {
          isParenthesisOpen = true;
        } else if (c === ")") {
          isParenthesisOpen = false;
        } else if (c === ";") {
          if (isParenthesisOpen) {
          } else {
            addNewAttr();
          }
        } else if (c === "\n") {
          addNewAttr();
        }
      }
      return _.trim(retCSS);
    }
    module.exports = parseStyle;
  }
});

// node_modules/.pnpm/cssfilter@0.0.10/node_modules/cssfilter/lib/css.js
var require_css = __commonJS({
  "node_modules/.pnpm/cssfilter@0.0.10/node_modules/cssfilter/lib/css.js"(exports, module) {
    var DEFAULT = require_default();
    var parseStyle = require_parser();
    var _ = require_util();
    function isNull(obj) {
      return obj === void 0 || obj === null;
    }
    function shallowCopyObject(obj) {
      var ret = {};
      for (var i in obj) {
        ret[i] = obj[i];
      }
      return ret;
    }
    function FilterCSS(options) {
      options = shallowCopyObject(options || {});
      options.whiteList = options.whiteList || DEFAULT.whiteList;
      options.onAttr = options.onAttr || DEFAULT.onAttr;
      options.onIgnoreAttr = options.onIgnoreAttr || DEFAULT.onIgnoreAttr;
      options.safeAttrValue = options.safeAttrValue || DEFAULT.safeAttrValue;
      this.options = options;
    }
    FilterCSS.prototype.process = function(css) {
      css = css || "";
      css = css.toString();
      if (!css)
        return "";
      var me = this;
      var options = me.options;
      var whiteList2 = options.whiteList;
      var onAttr = options.onAttr;
      var onIgnoreAttr = options.onIgnoreAttr;
      var safeAttrValue = options.safeAttrValue;
      var retCSS = parseStyle(css, function(sourcePosition, position, name, value, source) {
        var check = whiteList2[name];
        var isWhite = false;
        if (check === true)
          isWhite = check;
        else if (typeof check === "function")
          isWhite = check(value);
        else if (check instanceof RegExp)
          isWhite = check.test(value);
        if (isWhite !== true)
          isWhite = false;
        value = safeAttrValue(name, value);
        if (!value)
          return;
        var opts = {
          position,
          sourcePosition,
          source,
          isWhite
        };
        if (isWhite) {
          var ret = onAttr(name, value, opts);
          if (isNull(ret)) {
            return name + ":" + value;
          } else {
            return ret;
          }
        } else {
          var ret = onIgnoreAttr(name, value, opts);
          if (!isNull(ret)) {
            return ret;
          }
        }
      });
      return retCSS;
    };
    module.exports = FilterCSS;
  }
});

// node_modules/.pnpm/cssfilter@0.0.10/node_modules/cssfilter/lib/index.js
var require_lib = __commonJS({
  "node_modules/.pnpm/cssfilter@0.0.10/node_modules/cssfilter/lib/index.js"(exports, module) {
    var DEFAULT = require_default();
    var FilterCSS = require_css();
    function filterCSS(html, options) {
      var xss = new FilterCSS(options);
      return xss.process(html);
    }
    exports = module.exports = filterCSS;
    exports.FilterCSS = FilterCSS;
    for (i in DEFAULT)
      exports[i] = DEFAULT[i];
    var i;
    if (typeof window !== "undefined") {
      window.filterCSS = module.exports;
    }
  }
});

// node_modules/.pnpm/xss@1.0.14/node_modules/xss/lib/util.js
var require_util2 = __commonJS({
  "node_modules/.pnpm/xss@1.0.14/node_modules/xss/lib/util.js"(exports, module) {
    module.exports = {
      indexOf: function(arr, item) {
        var i, j;
        if (Array.prototype.indexOf) {
          return arr.indexOf(item);
        }
        for (i = 0, j = arr.length; i < j; i++) {
          if (arr[i] === item) {
            return i;
          }
        }
        return -1;
      },
      forEach: function(arr, fn, scope) {
        var i, j;
        if (Array.prototype.forEach) {
          return arr.forEach(fn, scope);
        }
        for (i = 0, j = arr.length; i < j; i++) {
          fn.call(scope, arr[i], i, arr);
        }
      },
      trim: function(str) {
        if (String.prototype.trim) {
          return str.trim();
        }
        return str.replace(/(^\s*)|(\s*$)/g, "");
      },
      spaceIndex: function(str) {
        var reg = /\s|\n|\t/;
        var match = reg.exec(str);
        return match ? match.index : -1;
      }
    };
  }
});

// node_modules/.pnpm/xss@1.0.14/node_modules/xss/lib/default.js
var require_default2 = __commonJS({
  "node_modules/.pnpm/xss@1.0.14/node_modules/xss/lib/default.js"(exports) {
    var FilterCSS = require_lib().FilterCSS;
    var getDefaultCSSWhiteList = require_lib().getDefaultWhiteList;
    var _ = require_util2();
    function getDefaultWhiteList() {
      return {
        a: ["target", "href", "title"],
        abbr: ["title"],
        address: [],
        area: ["shape", "coords", "href", "alt"],
        article: [],
        aside: [],
        audio: [
          "autoplay",
          "controls",
          "crossorigin",
          "loop",
          "muted",
          "preload",
          "src"
        ],
        b: [],
        bdi: ["dir"],
        bdo: ["dir"],
        big: [],
        blockquote: ["cite"],
        br: [],
        caption: [],
        center: [],
        cite: [],
        code: [],
        col: ["align", "valign", "span", "width"],
        colgroup: ["align", "valign", "span", "width"],
        dd: [],
        del: ["datetime"],
        details: ["open"],
        div: [],
        dl: [],
        dt: [],
        em: [],
        figcaption: [],
        figure: [],
        font: ["color", "size", "face"],
        footer: [],
        h1: [],
        h2: [],
        h3: [],
        h4: [],
        h5: [],
        h6: [],
        header: [],
        hr: [],
        i: [],
        img: ["src", "alt", "title", "width", "height"],
        ins: ["datetime"],
        li: [],
        mark: [],
        nav: [],
        ol: [],
        p: [],
        pre: [],
        s: [],
        section: [],
        small: [],
        span: [],
        sub: [],
        summary: [],
        sup: [],
        strong: [],
        strike: [],
        table: ["width", "border", "align", "valign"],
        tbody: ["align", "valign"],
        td: ["width", "rowspan", "colspan", "align", "valign"],
        tfoot: ["align", "valign"],
        th: ["width", "rowspan", "colspan", "align", "valign"],
        thead: ["align", "valign"],
        tr: ["rowspan", "align", "valign"],
        tt: [],
        u: [],
        ul: [],
        video: [
          "autoplay",
          "controls",
          "crossorigin",
          "loop",
          "muted",
          "playsinline",
          "poster",
          "preload",
          "src",
          "height",
          "width"
        ]
      };
    }
    var defaultCSSFilter = new FilterCSS();
    function onTag(tag, html, options) {
    }
    function onIgnoreTag(tag, html, options) {
    }
    function onTagAttr(tag, name, value) {
    }
    function onIgnoreTagAttr(tag, name, value) {
    }
    function escapeHtml(html) {
      return html.replace(REGEXP_LT, "&lt;").replace(REGEXP_GT, "&gt;");
    }
    function safeAttrValue(tag, name, value, cssFilter) {
      value = friendlyAttrValue(value);
      if (name === "href" || name === "src") {
        value = _.trim(value);
        if (value === "#")
          return "#";
        if (!(value.substr(0, 7) === "http://" || value.substr(0, 8) === "https://" || value.substr(0, 7) === "mailto:" || value.substr(0, 4) === "tel:" || value.substr(0, 11) === "data:image/" || value.substr(0, 6) === "ftp://" || value.substr(0, 2) === "./" || value.substr(0, 3) === "../" || value[0] === "#" || value[0] === "/")) {
          return "";
        }
      } else if (name === "background") {
        REGEXP_DEFAULT_ON_TAG_ATTR_4.lastIndex = 0;
        if (REGEXP_DEFAULT_ON_TAG_ATTR_4.test(value)) {
          return "";
        }
      } else if (name === "style") {
        REGEXP_DEFAULT_ON_TAG_ATTR_7.lastIndex = 0;
        if (REGEXP_DEFAULT_ON_TAG_ATTR_7.test(value)) {
          return "";
        }
        REGEXP_DEFAULT_ON_TAG_ATTR_8.lastIndex = 0;
        if (REGEXP_DEFAULT_ON_TAG_ATTR_8.test(value)) {
          REGEXP_DEFAULT_ON_TAG_ATTR_4.lastIndex = 0;
          if (REGEXP_DEFAULT_ON_TAG_ATTR_4.test(value)) {
            return "";
          }
        }
        if (cssFilter !== false) {
          cssFilter = cssFilter || defaultCSSFilter;
          value = cssFilter.process(value);
        }
      }
      value = escapeAttrValue(value);
      return value;
    }
    var REGEXP_LT = /</g;
    var REGEXP_GT = />/g;
    var REGEXP_QUOTE = /"/g;
    var REGEXP_QUOTE_2 = /&quot;/g;
    var REGEXP_ATTR_VALUE_1 = /&#([a-zA-Z0-9]*);?/gim;
    var REGEXP_ATTR_VALUE_COLON = /&colon;?/gim;
    var REGEXP_ATTR_VALUE_NEWLINE = /&newline;?/gim;
    var REGEXP_DEFAULT_ON_TAG_ATTR_4 = /((j\s*a\s*v\s*a|v\s*b|l\s*i\s*v\s*e)\s*s\s*c\s*r\s*i\s*p\s*t\s*|m\s*o\s*c\s*h\s*a):/gi;
    var REGEXP_DEFAULT_ON_TAG_ATTR_7 = /e\s*x\s*p\s*r\s*e\s*s\s*s\s*i\s*o\s*n\s*\(.*/gi;
    var REGEXP_DEFAULT_ON_TAG_ATTR_8 = /u\s*r\s*l\s*\(.*/gi;
    function escapeQuote(str) {
      return str.replace(REGEXP_QUOTE, "&quot;");
    }
    function unescapeQuote(str) {
      return str.replace(REGEXP_QUOTE_2, '"');
    }
    function escapeHtmlEntities(str) {
      return str.replace(REGEXP_ATTR_VALUE_1, function replaceUnicode(str2, code) {
        return code[0] === "x" || code[0] === "X" ? String.fromCharCode(parseInt(code.substr(1), 16)) : String.fromCharCode(parseInt(code, 10));
      });
    }
    function escapeDangerHtml5Entities(str) {
      return str.replace(REGEXP_ATTR_VALUE_COLON, ":").replace(REGEXP_ATTR_VALUE_NEWLINE, " ");
    }
    function clearNonPrintableCharacter(str) {
      var str2 = "";
      for (var i = 0, len = str.length; i < len; i++) {
        str2 += str.charCodeAt(i) < 32 ? " " : str.charAt(i);
      }
      return _.trim(str2);
    }
    function friendlyAttrValue(str) {
      str = unescapeQuote(str);
      str = escapeHtmlEntities(str);
      str = escapeDangerHtml5Entities(str);
      str = clearNonPrintableCharacter(str);
      return str;
    }
    function escapeAttrValue(str) {
      str = escapeQuote(str);
      str = escapeHtml(str);
      return str;
    }
    function onIgnoreTagStripAll() {
      return "";
    }
    function StripTagBody(tags, next) {
      if (typeof next !== "function") {
        next = function() {
        };
      }
      var isRemoveAllTag = !Array.isArray(tags);
      function isRemoveTag(tag) {
        if (isRemoveAllTag)
          return true;
        return _.indexOf(tags, tag) !== -1;
      }
      var removeList = [];
      var posStart = false;
      return {
        onIgnoreTag: function(tag, html, options) {
          if (isRemoveTag(tag)) {
            if (options.isClosing) {
              var ret = "[/removed]";
              var end = options.position + ret.length;
              removeList.push([
                posStart !== false ? posStart : options.position,
                end
              ]);
              posStart = false;
              return ret;
            } else {
              if (!posStart) {
                posStart = options.position;
              }
              return "[removed]";
            }
          } else {
            return next(tag, html, options);
          }
        },
        remove: function(html) {
          var rethtml = "";
          var lastPos = 0;
          _.forEach(removeList, function(pos) {
            rethtml += html.slice(lastPos, pos[0]);
            lastPos = pos[1];
          });
          rethtml += html.slice(lastPos);
          return rethtml;
        }
      };
    }
    function stripCommentTag(html) {
      var retHtml = "";
      var lastPos = 0;
      while (lastPos < html.length) {
        var i = html.indexOf("<!--", lastPos);
        if (i === -1) {
          retHtml += html.slice(lastPos);
          break;
        }
        retHtml += html.slice(lastPos, i);
        var j = html.indexOf("-->", i);
        if (j === -1) {
          break;
        }
        lastPos = j + 3;
      }
      return retHtml;
    }
    function stripBlankChar(html) {
      var chars = html.split("");
      chars = chars.filter(function(char) {
        var c = char.charCodeAt(0);
        if (c === 127)
          return false;
        if (c <= 31) {
          if (c === 10 || c === 13)
            return true;
          return false;
        }
        return true;
      });
      return chars.join("");
    }
    exports.whiteList = getDefaultWhiteList();
    exports.getDefaultWhiteList = getDefaultWhiteList;
    exports.onTag = onTag;
    exports.onIgnoreTag = onIgnoreTag;
    exports.onTagAttr = onTagAttr;
    exports.onIgnoreTagAttr = onIgnoreTagAttr;
    exports.safeAttrValue = safeAttrValue;
    exports.escapeHtml = escapeHtml;
    exports.escapeQuote = escapeQuote;
    exports.unescapeQuote = unescapeQuote;
    exports.escapeHtmlEntities = escapeHtmlEntities;
    exports.escapeDangerHtml5Entities = escapeDangerHtml5Entities;
    exports.clearNonPrintableCharacter = clearNonPrintableCharacter;
    exports.friendlyAttrValue = friendlyAttrValue;
    exports.escapeAttrValue = escapeAttrValue;
    exports.onIgnoreTagStripAll = onIgnoreTagStripAll;
    exports.StripTagBody = StripTagBody;
    exports.stripCommentTag = stripCommentTag;
    exports.stripBlankChar = stripBlankChar;
    exports.cssFilter = defaultCSSFilter;
    exports.getDefaultCSSWhiteList = getDefaultCSSWhiteList;
  }
});

// node_modules/.pnpm/xss@1.0.14/node_modules/xss/lib/parser.js
var require_parser2 = __commonJS({
  "node_modules/.pnpm/xss@1.0.14/node_modules/xss/lib/parser.js"(exports) {
    var _ = require_util2();
    function getTagName(html) {
      var i = _.spaceIndex(html);
      var tagName;
      if (i === -1) {
        tagName = html.slice(1, -1);
      } else {
        tagName = html.slice(1, i + 1);
      }
      tagName = _.trim(tagName).toLowerCase();
      if (tagName.slice(0, 1) === "/")
        tagName = tagName.slice(1);
      if (tagName.slice(-1) === "/")
        tagName = tagName.slice(0, -1);
      return tagName;
    }
    function isClosing(html) {
      return html.slice(0, 2) === "</";
    }
    function parseTag(html, onTag, escapeHtml) {
      "use strict";
      var rethtml = "";
      var lastPos = 0;
      var tagStart = false;
      var quoteStart = false;
      var currentPos = 0;
      var len = html.length;
      var currentTagName = "";
      var currentHtml = "";
      chariterator:
        for (currentPos = 0; currentPos < len; currentPos++) {
          var c = html.charAt(currentPos);
          if (tagStart === false) {
            if (c === "<") {
              tagStart = currentPos;
              continue;
            }
          } else {
            if (quoteStart === false) {
              if (c === "<") {
                rethtml += escapeHtml(html.slice(lastPos, currentPos));
                tagStart = currentPos;
                lastPos = currentPos;
                continue;
              }
              if (c === ">" || currentPos === len - 1) {
                rethtml += escapeHtml(html.slice(lastPos, tagStart));
                currentHtml = html.slice(tagStart, currentPos + 1);
                currentTagName = getTagName(currentHtml);
                rethtml += onTag(
                  tagStart,
                  rethtml.length,
                  currentTagName,
                  currentHtml,
                  isClosing(currentHtml)
                );
                lastPos = currentPos + 1;
                tagStart = false;
                continue;
              }
              if (c === '"' || c === "'") {
                var i = 1;
                var ic = html.charAt(currentPos - i);
                while (ic.trim() === "" || ic === "=") {
                  if (ic === "=") {
                    quoteStart = c;
                    continue chariterator;
                  }
                  ic = html.charAt(currentPos - ++i);
                }
              }
            } else {
              if (c === quoteStart) {
                quoteStart = false;
                continue;
              }
            }
          }
        }
      if (lastPos < len) {
        rethtml += escapeHtml(html.substr(lastPos));
      }
      return rethtml;
    }
    var REGEXP_ILLEGAL_ATTR_NAME = /[^a-zA-Z0-9\\_:.-]/gim;
    function parseAttr(html, onAttr) {
      "use strict";
      var lastPos = 0;
      var lastMarkPos = 0;
      var retAttrs = [];
      var tmpName = false;
      var len = html.length;
      function addAttr(name, value) {
        name = _.trim(name);
        name = name.replace(REGEXP_ILLEGAL_ATTR_NAME, "").toLowerCase();
        if (name.length < 1)
          return;
        var ret = onAttr(name, value || "");
        if (ret)
          retAttrs.push(ret);
      }
      for (var i = 0; i < len; i++) {
        var c = html.charAt(i);
        var v, j;
        if (tmpName === false && c === "=") {
          tmpName = html.slice(lastPos, i);
          lastPos = i + 1;
          lastMarkPos = html.charAt(lastPos) === '"' || html.charAt(lastPos) === "'" ? lastPos : findNextQuotationMark(html, i + 1);
          continue;
        }
        if (tmpName !== false) {
          if (i === lastMarkPos) {
            j = html.indexOf(c, i + 1);
            if (j === -1) {
              break;
            } else {
              v = _.trim(html.slice(lastMarkPos + 1, j));
              addAttr(tmpName, v);
              tmpName = false;
              i = j;
              lastPos = i + 1;
              continue;
            }
          }
        }
        if (/\s|\n|\t/.test(c)) {
          html = html.replace(/\s|\n|\t/g, " ");
          if (tmpName === false) {
            j = findNextEqual(html, i);
            if (j === -1) {
              v = _.trim(html.slice(lastPos, i));
              addAttr(v);
              tmpName = false;
              lastPos = i + 1;
              continue;
            } else {
              i = j - 1;
              continue;
            }
          } else {
            j = findBeforeEqual(html, i - 1);
            if (j === -1) {
              v = _.trim(html.slice(lastPos, i));
              v = stripQuoteWrap(v);
              addAttr(tmpName, v);
              tmpName = false;
              lastPos = i + 1;
              continue;
            } else {
              continue;
            }
          }
        }
      }
      if (lastPos < html.length) {
        if (tmpName === false) {
          addAttr(html.slice(lastPos));
        } else {
          addAttr(tmpName, stripQuoteWrap(_.trim(html.slice(lastPos))));
        }
      }
      return _.trim(retAttrs.join(" "));
    }
    function findNextEqual(str, i) {
      for (; i < str.length; i++) {
        var c = str[i];
        if (c === " ")
          continue;
        if (c === "=")
          return i;
        return -1;
      }
    }
    function findNextQuotationMark(str, i) {
      for (; i < str.length; i++) {
        var c = str[i];
        if (c === " ")
          continue;
        if (c === "'" || c === '"')
          return i;
        return -1;
      }
    }
    function findBeforeEqual(str, i) {
      for (; i > 0; i--) {
        var c = str[i];
        if (c === " ")
          continue;
        if (c === "=")
          return i;
        return -1;
      }
    }
    function isQuoteWrapString(text) {
      if (text[0] === '"' && text[text.length - 1] === '"' || text[0] === "'" && text[text.length - 1] === "'") {
        return true;
      } else {
        return false;
      }
    }
    function stripQuoteWrap(text) {
      if (isQuoteWrapString(text)) {
        return text.substr(1, text.length - 2);
      } else {
        return text;
      }
    }
    exports.parseTag = parseTag;
    exports.parseAttr = parseAttr;
  }
});

// node_modules/.pnpm/xss@1.0.14/node_modules/xss/lib/xss.js
var require_xss = __commonJS({
  "node_modules/.pnpm/xss@1.0.14/node_modules/xss/lib/xss.js"(exports, module) {
    var FilterCSS = require_lib().FilterCSS;
    var DEFAULT = require_default2();
    var parser = require_parser2();
    var parseTag = parser.parseTag;
    var parseAttr = parser.parseAttr;
    var _ = require_util2();
    function isNull(obj) {
      return obj === void 0 || obj === null;
    }
    function getAttrs(html) {
      var i = _.spaceIndex(html);
      if (i === -1) {
        return {
          html: "",
          closing: html[html.length - 2] === "/"
        };
      }
      html = _.trim(html.slice(i + 1, -1));
      var isClosing = html[html.length - 1] === "/";
      if (isClosing)
        html = _.trim(html.slice(0, -1));
      return {
        html,
        closing: isClosing
      };
    }
    function shallowCopyObject(obj) {
      var ret = {};
      for (var i in obj) {
        ret[i] = obj[i];
      }
      return ret;
    }
    function keysToLowerCase(obj) {
      var ret = {};
      for (var i in obj) {
        if (Array.isArray(obj[i])) {
          ret[i.toLowerCase()] = obj[i].map(function(item) {
            return item.toLowerCase();
          });
        } else {
          ret[i.toLowerCase()] = obj[i];
        }
      }
      return ret;
    }
    function FilterXSS(options) {
      options = shallowCopyObject(options || {});
      if (options.stripIgnoreTag) {
        if (options.onIgnoreTag) {
          console.error(
            'Notes: cannot use these two options "stripIgnoreTag" and "onIgnoreTag" at the same time'
          );
        }
        options.onIgnoreTag = DEFAULT.onIgnoreTagStripAll;
      }
      if (options.whiteList || options.allowList) {
        options.whiteList = keysToLowerCase(options.whiteList || options.allowList);
      } else {
        options.whiteList = DEFAULT.whiteList;
      }
      options.onTag = options.onTag || DEFAULT.onTag;
      options.onTagAttr = options.onTagAttr || DEFAULT.onTagAttr;
      options.onIgnoreTag = options.onIgnoreTag || DEFAULT.onIgnoreTag;
      options.onIgnoreTagAttr = options.onIgnoreTagAttr || DEFAULT.onIgnoreTagAttr;
      options.safeAttrValue = options.safeAttrValue || DEFAULT.safeAttrValue;
      options.escapeHtml = options.escapeHtml || DEFAULT.escapeHtml;
      this.options = options;
      if (options.css === false) {
        this.cssFilter = false;
      } else {
        options.css = options.css || {};
        this.cssFilter = new FilterCSS(options.css);
      }
    }
    FilterXSS.prototype.process = function(html) {
      html = html || "";
      html = html.toString();
      if (!html)
        return "";
      var me = this;
      var options = me.options;
      var whiteList2 = options.whiteList;
      var onTag = options.onTag;
      var onIgnoreTag = options.onIgnoreTag;
      var onTagAttr = options.onTagAttr;
      var onIgnoreTagAttr = options.onIgnoreTagAttr;
      var safeAttrValue = options.safeAttrValue;
      var escapeHtml = options.escapeHtml;
      var cssFilter = me.cssFilter;
      if (options.stripBlankChar) {
        html = DEFAULT.stripBlankChar(html);
      }
      if (!options.allowCommentTag) {
        html = DEFAULT.stripCommentTag(html);
      }
      var stripIgnoreTagBody = false;
      if (options.stripIgnoreTagBody) {
        stripIgnoreTagBody = DEFAULT.StripTagBody(
          options.stripIgnoreTagBody,
          onIgnoreTag
        );
        onIgnoreTag = stripIgnoreTagBody.onIgnoreTag;
      }
      var retHtml = parseTag(
        html,
        function(sourcePosition, position, tag, html2, isClosing) {
          var info = {
            sourcePosition,
            position,
            isClosing,
            isWhite: Object.prototype.hasOwnProperty.call(whiteList2, tag)
          };
          var ret = onTag(tag, html2, info);
          if (!isNull(ret))
            return ret;
          if (info.isWhite) {
            if (info.isClosing) {
              return "</" + tag + ">";
            }
            var attrs = getAttrs(html2);
            var whiteAttrList = whiteList2[tag];
            var attrsHtml = parseAttr(attrs.html, function(name, value) {
              var isWhiteAttr = _.indexOf(whiteAttrList, name) !== -1;
              var ret2 = onTagAttr(tag, name, value, isWhiteAttr);
              if (!isNull(ret2))
                return ret2;
              if (isWhiteAttr) {
                value = safeAttrValue(tag, name, value, cssFilter);
                if (value) {
                  return name + '="' + value + '"';
                } else {
                  return name;
                }
              } else {
                ret2 = onIgnoreTagAttr(tag, name, value, isWhiteAttr);
                if (!isNull(ret2))
                  return ret2;
                return;
              }
            });
            html2 = "<" + tag;
            if (attrsHtml)
              html2 += " " + attrsHtml;
            if (attrs.closing)
              html2 += " /";
            html2 += ">";
            return html2;
          } else {
            ret = onIgnoreTag(tag, html2, info);
            if (!isNull(ret))
              return ret;
            return escapeHtml(html2);
          }
        },
        escapeHtml
      );
      if (stripIgnoreTagBody) {
        retHtml = stripIgnoreTagBody.remove(retHtml);
      }
      return retHtml;
    };
    module.exports = FilterXSS;
  }
});

// node_modules/.pnpm/xss@1.0.14/node_modules/xss/lib/index.js
var require_lib2 = __commonJS({
  "node_modules/.pnpm/xss@1.0.14/node_modules/xss/lib/index.js"(exports, module) {
    var DEFAULT = require_default2();
    var parser = require_parser2();
    var FilterXSS = require_xss();
    function filterXSS2(html, options) {
      var xss = new FilterXSS(options);
      return xss.process(html);
    }
    exports = module.exports = filterXSS2;
    exports.filterXSS = filterXSS2;
    exports.FilterXSS = FilterXSS;
    (function() {
      for (var i in DEFAULT) {
        exports[i] = DEFAULT[i];
      }
      for (var j in parser) {
        exports[j] = parser[j];
      }
    })();
    if (typeof window !== "undefined") {
      window.filterXSS = module.exports;
    }
    function isWorkerEnv() {
      return typeof self !== "undefined" && typeof DedicatedWorkerGlobalScope !== "undefined" && self instanceof DedicatedWorkerGlobalScope;
    }
    if (isWorkerEnv()) {
      self.filterXSS = module.exports;
    }
  }
});

// packages/utils/xss/index.js
var import_xss = __toESM(require_lib2());
var whiteList = [/er-webc-.*/, /br/];
var xssFilter = (msg) => {
  return (0, import_xss.filterXSS)(msg, {
    onTag: (tag, html) => {
      const hasWhite = whiteList.some((reg) => {
        if (reg.test(tag)) {
          return true;
        }
        return false;
      });
      if (hasWhite) {
        return html;
      }
    }
  });
};
export {
  whiteList,
  xssFilter
};
