declare const whiteList: RegExp[];
declare function xssFilter(msg: any): string;

export { whiteList, xssFilter };
