declare function localeCompare(str1: any, str2: any): number;
declare namespace _default {
    export { localeCompare };
}

export { _default as default, localeCompare };
