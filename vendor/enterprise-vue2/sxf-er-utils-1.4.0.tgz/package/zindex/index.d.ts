/**
 * @returns {Number} 返回最新一层的 zindex
 */
declare function getZIndex(): number;

export { getZIndex as default };
