// packages/utils/zindex/index.js
var zindex = 100;
function getZIndex() {
  return zindex++;
}
export {
  getZIndex as default
};
