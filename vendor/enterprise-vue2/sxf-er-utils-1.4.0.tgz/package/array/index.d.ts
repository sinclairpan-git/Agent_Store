declare function unique(array: any[]): any[];
declare function equals(array1: any[], array2: any[]): boolean;

export { equals, unique };
