// packages/utils/array/index.js
var unique = (array) => {
  const clone = [];
  const ln = array.length;
  let i = 0;
  let item;
  for (; i < ln; i++) {
    item = array[i];
    if (clone.indexOf(item) === -1) {
      clone.push(item);
    }
  }
  return clone;
};
var equals = (array1, array2) => {
  const len1 = array1.length;
  const len2 = array2.length;
  let i;
  if (array1 === array2) {
    return true;
  }
  if (len1 !== len2) {
    return false;
  }
  for (i = 0; i < len1; ++i) {
    if (array1[i] !== array2[i]) {
      return false;
    }
  }
  return true;
};
export {
  equals,
  unique
};
