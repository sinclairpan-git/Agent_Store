// packages/utils/observable/index.js
import _Event from "@sxf/er-utils/event";
function Observable() {
  const e = this.events;
  this.filterOptRe = /^(?:scope|delay|buffer|single)$/;
  this.events = e || {};
  if (this.listeners) {
    this.addListener(this.listeners);
    delete this.listeners;
  }
}
Observable.prototype.fireEvent = function(eventName, ...args) {
  let ret = true;
  const ename = eventName.toLowerCase();
  const ce = this.events[ename];
  let cc, c, q;
  if (this.eventsSuspended === true) {
    if (q = this.eventQueue) {
      q.push([ename, ...args]);
    }
  } else if (typeof ce === "object") {
    if (ce.bubble) {
      if (ce.fire(...args) === false) {
        return false;
      }
      c = this.getBubbleTarget && this.getBubbleTarget();
      if (c && c.enableBubble) {
        cc = c.events[ename];
        if (!cc || typeof cc !== "object" || !cc.bubble) {
          c.enableBubble(ename);
        }
        return c.fireEvent(...[ename, ...args]);
      }
    } else {
      ret = ce.fire(...args);
    }
  }
  return ret;
};
Observable.prototype.addListener = function(eventName, fn, scope, o) {
  if (typeof eventName === "object") {
    o = eventName;
    for (const e in o) {
      if (o.hasOwnProperty(e)) {
        const oe = o[e];
        if (!this.filterOptRe.test(e)) {
          this.addListener(e, oe.fn || oe, oe.scope || o.scope, oe.fn ? oe : o);
        }
      }
    }
  } else {
    const eventNames = eventName.toLowerCase().trim().split(/[\s\uFEFF\xA0]+/g);
    for (let i = 0; i < eventNames.length; i++) {
      const ce = this.events[eventNames[i]] || true;
      if (typeof ce === "boolean") {
        this.events[eventNames[i]] = new _Event(this, eventNames[i]);
      }
      this.events[eventNames[i]].addListener(fn, scope, typeof o === "object" ? o : {});
    }
  }
  return this;
};
Observable.prototype.removeListener = function(eventName, fn, scope) {
  const ce = this.events[eventName.toLowerCase()];
  if (typeof ce === "object") {
    ce.removeListener(fn, scope);
  }
  return this;
};
Observable.prototype.purgeListeners = function() {
  for (const key in this.events) {
    if (this.events.hasOwnProperty(key)) {
      const evt = this.events[key];
      if (typeof evt === "object") {
        evt.clearListeners();
      }
    }
  }
};
Observable.prototype.addEvents = function(o) {
  this.events = this.events || {};
  if (typeof o === "string") {
    const a = arguments;
    for (let i = 0; i < a.length; i++) {
      this.events[a[i]] = this.events[a[i]] || true;
    }
  } else {
    _applyIf(this.events, o);
  }
};
Observable.prototype.hasListener = function(eventName) {
  const e = this.events[eventName.toLowerCase()];
  return typeof e === "object" && e.listeners.length > 0;
};
Observable.prototype.suspendEvents = function(queueSuspended) {
  this.eventsSuspended = true;
  if (queueSuspended && !this.eventQueue) {
    this.eventQueue = [];
  }
};
Observable.prototype.resumeEvents = function() {
  const queued = this.eventQueue || [];
  this.eventsSuspended = false;
  delete this.eventQueue;
  queued.forEach((e) => {
    this.fireEvent(...e);
  });
};
Observable.prototype.on = function(eventName, fn, scope, o) {
  return this.addListener(eventName, fn, scope, o);
};
Observable.prototype.off = function(eventName, fn, scope) {
  return this.removeListener(eventName, fn, scope);
};
Observable.prototype.emit = function(eventName, ...args) {
  return this.fireEvent(eventName, ...args);
};
Observable.prototype.clear = function() {
  return this.purgeListeners();
};
function _applyIf(o, c) {
  if (o) {
    for (const p in c) {
      if (typeof o[p] === "undefined") {
        o[p] = c[p];
      }
    }
  }
  return o;
}
var observable_default = Observable;
export {
  observable_default as default
};
