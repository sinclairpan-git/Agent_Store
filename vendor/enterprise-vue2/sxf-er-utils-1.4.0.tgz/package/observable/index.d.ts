/**
 * 事件机制的实现类
 */
declare function Observable(): void;
declare class Observable {
    filterOptRe: RegExp;
    events: {};
    /**
     * 触发事件
     *
     * @param {string} eventName - 事件名
     * @param {*} args - 事件参数
     * @returns {boolean} - 是否成功触发事件
     */
    fireEvent(eventName: string, ...args: any): boolean;
    /**
     * 添加事件监听器
     *
     * @param {string|Object.<string, function>} eventName - 事件名或一组事件名和处理函数
     * @param {function} [fn] - 事件处理函数
     * @param {*} [scope] - 事件处理函数的作用域
     * @param {Object} [o] - 其他选项
     * @returns {Observable} - 当前对象
     */
    addListener(eventName: string | {
        [x: string]: Function;
    }, fn?: Function | undefined, scope?: any, o?: Object | undefined): Observable;
    /**
     * 移除事件监听器
     *
     * @param {string} eventName - 事件名
     * @param {function} fn - 事件处理函数
     * @param {*} scope - 事件处理函数的作用域
     * @returns {Observable} - 当前对象
     */
    removeListener(eventName: string, fn: Function, scope: any): Observable;
    /**
     * 清除所有事件监听器
     */
    purgeListeners(): void;
    /**
     * 添加一组事件
     *
     * @param {string|Object.<string, boolean>} o - 事件名或一组事件名
     */
    addEvents(o: string | {
        [x: string]: boolean;
    }, ...args: any[]): void;
    /**
     * 判断是否有指定事件的监听器
     *
     * @param {string} eventName - 事件名
     * @returns {boolean} - 是否有监听器
     */
    hasListener(eventName: string): boolean;
    /**
     * 暂停事件监听器
     *
     * @param {boolean} queueSuspended - 是否缓存事件
     */
    suspendEvents(queueSuspended: boolean): void;
    eventsSuspended: boolean | undefined;
    eventQueue: any[] | undefined;
    /**
     * 恢复事件监听器
     */
    resumeEvents(): void;
    /**
     * 别名
     *
     * @param {string} eventName - 事件名
     * @param {function} fn - 事件处理函数
     * @param {*} [scope] - 事件处理函数的作用域
     * @param {Object} [o] - 其他选项
     * @returns {Observable} - 当前对象
     */
    on(eventName: string, fn: Function, scope?: any, o?: Object | undefined): Observable;
    /**
     * 别名
     *
     * @param {string} eventName - 事件名
     * @param {function} fn - 事件处理函数
     * @param {*} [scope] - 事件处理函数的作用域
     * @returns {Observable} - 当前对象
     */
    off(eventName: string, fn: Function, scope?: any): Observable;
    /**
     * 别名
     *
     * @param {string} eventName - 事件名
     * @param {*} args - 事件参数
     * @returns {boolean} - 是否成功触发事件
     */
    emit(eventName: string, ...args: any): boolean;
    /**
     * 别名
     */
    clear(): void;
}

export { Observable as default };
