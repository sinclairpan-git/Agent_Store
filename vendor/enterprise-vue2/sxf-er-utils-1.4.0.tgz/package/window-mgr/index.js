// packages/utils/window-mgr/index.js
import $ from "jquery";
import Observable from "@sxf/er-utils/observable";
var DOC = $(document.documentElement);
var WindowMGR = class extends Observable {
  constructor() {
    super();
    this.init();
  }
  init() {
    this.winHash = {};
    this.showSet = /* @__PURE__ */ new Set();
    this._inc = 0;
  }
  add(win) {
    if (!this.winHash[win.id]) {
      this.winHash[win.id] = win;
      win.on("hide", this.onhide.bind(this, win)).on("show", this.onshow.bind(this, win));
      this.emit("after-add", win);
    }
  }
  get(win) {
    if (typeof win === "string") {
      win = this.winHash[win];
    }
    return win;
  }
  remove(win) {
    win = this.get(win);
    if (win) {
      delete this.winHash[win.id];
      this.showSet.delete(win);
    }
    this.emit("after-remove", win);
  }
  onshow(win) {
    if (!this.getShowCount()) {
      DOC.addClass("noscroll");
    }
    this.showSet.add(win);
    this.emit("after-show", win);
  }
  onhide(win) {
    this.showSet.delete(win);
    if (!this.getShowCount()) {
      DOC.removeClass("noscroll");
    }
    this.emit("after-hide", win);
  }
  getShowCount() {
    return this.showSet.size;
  }
  getAllWin() {
    return this.winHash;
  }
  getNewId() {
    return "sfis-window-id-" + this._inc++;
  }
};
var window_mgr_default = new WindowMGR();
export {
  window_mgr_default as default
};
