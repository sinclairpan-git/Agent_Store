import Observable from '../observable/index.js';

declare const _default: WindowMGR;

declare class WindowMGR extends Observable {
    init(): void;
    winHash: {} | undefined;
    showSet: Set<any> | undefined;
    _inc: number | undefined;
    add(win: any): void;
    get(win: any): any;
    remove(win: any): void;
    onshow(win: any): void;
    onhide(win: any): void;
    getShowCount(): number;
    getAllWin(): {} | undefined;
    getNewId(): string;
}

export { _default as default };
