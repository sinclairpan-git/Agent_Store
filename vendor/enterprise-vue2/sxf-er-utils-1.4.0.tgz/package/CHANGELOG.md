# @sxf/er-utils

## 1.4.0 (2025-12-25)

### Minor Changes

- 766c3b79: feat: 处理组件库内存泄漏问题

## 1.3.2 (2025-11-17)

### Patch Changes

- caad89bd: feat(utils:format): 新增 formatToData 方法的导出

  feat(comp:cover-window): 处理 coverWindow 组件上下步不会随步骤变更的问题

## 1.3.1 (2025-09-18)

### Patch Changes

- 847ec332: fix(utils:textMetrics): 优化文本测量计算逻辑

## 1.3.0 (2025-09-02) (2025-09-02)

### Minor Changes

- caaadbb0: feat(comp:base-info): 修复 baseInfo 的 label 宽度计算错误

## 1.2.0 (2025-07-18)

### Minor Changes

- chore: 统一更新主线版本

### Patch Changes

- ed65bfb4: feat: 优化 textMetrics 文本测量逻辑
- Updated dependencies
  - @sxf/er-config@2.0.0

## 1.1.0-xaas-patch.1 (2025-03-19)

### Patch Changes

- chore: 合入 xaas 变更后更新版本号，统一升级

## 1.0.4-scp-6111-patch.9 (2025-03-13)

### Minor Changes

- b36cd956: refactor(widget:window): windowMgr 作为 utils 包的独立模块对外提供

## 1.1.0-scp-6112-patch.2 (2025-02-20)

### Patch Changes

- 4fcbd803: fix: 修复 checkNoNotify 逻辑容错

## 1.1.0-scp-6112-patch.1 (2025-02-20)

### Patch Changes

- 202cc597: fix: 修复高版本控制台报错问题

## 1.1.0 (2025-02-13)

### Minor Changes

- 14788914: chore: 更新主线包发布版本号

## 1.0.5 (2024-12-26)

### Patch Changes

- chore: release 分支合入后更新 latest

## 1.0.4-aipaas-patch.2 (2024-11-20)

### Minor Changes

- 889f4dde: feat: 下拉框添加前缀类型属性配置，删除图片类型判断函数

## 1.0.4-aipaas-patch.1 (2024-11-18)

### Minor Changes

- e1deaab8: feat: 添加图片类型判断方法

## 1.0.4-scp-6111-patch.8 (2025-01-07)

### Minor Changes

- d1f27830: refactor: scrollManager 移动到 utils 包 dom 目录下对外导出

## 1.0.4-scp-6111-patch.7 (2025-01-04)

### Patch Changes

- 8fa9b943: feat(comp:window): 支持过滤 '[er-no-notify]' 前缀

## 1.0.4-scp-6111-patch.6 (2024-12-26)

### Minor Changes

- d9ee6fbd: update(utils: xss)：去掉 br 的前后正则校验，避免其出现在中间区域

## 1.0.4-scp-6111-patch.5 (2024-12-25)

### Patch Changes

- d7b1c908: fix(widget:notify): 补充 notify option 缺失的类型说明

## 1.0.4-scp-6111-patch.4 (2024-12-25)

### Minor Changes

- aa163dd0: feat(utils: graphql): 新增 graphql 统一的 link 钩子

## 1.0.4-scp-6111-patch.3 (2024-12-24)

### Minor Changes

- 1ea568d7: feat(widget:notify): 增加关闭操作回调功能 & 优化 er-no-notify 逻辑

## 1.0.4-scp-6111-patch.2 (2024-12-10)

### Minor Changes

- 94e8634f: feat(component:window): 添加 xss 处理的 content 和 subtitle

### Patch Changes

- 9a08db5e: fix(utils:numberic): 修正 decimal 参数 jsdoc 类型为 string|number

## 1.0.4-scp-6111-patch.1 (2024-12-07)

### Minor Changes

- 0f2e7e37: feat(notify)：添加 er-webc-\*的转换规则

## 1.0.4 (2024-08-29)

### Patch Changes

- 82d9b225: fix(utils:format): 修复时区为字符串偏移计算有误问题

## 1.0.3 (2024-08-28)

### Patch Changes

- f1ae0605: fix(utils:format): 获取当前时区添加时区偏移配置

## 1.0.2 (2024-07-29)

### Patch Changes

- abc32178: fix(utils:when): 修复 when 返回值类型错误

## 1.0.1 (2024-05-14)

### Patch Changes

- e2dcec86: 修复系统时区 timeZone 为 0 取了本地时区的问题

## 1.0.0 (2024-05-13)

### Major Changes

- 7875a24a: feat: eresh1.0 正式版发布

### Patch Changes

- Updated dependencies [ba95de09]
- Updated dependencies [8197c813]
- Updated dependencies [db191806]
- Updated dependencies [77719cfb]
- Updated dependencies [6e39bddc]
- Updated dependencies [6260bb87]
- Updated dependencies [59e243b3]
- Updated dependencies [b049d503]
- Updated dependencies [a3ae5ee0]
- Updated dependencies [e86f9574]
- Updated dependencies [6533c596]
- Updated dependencies [63818025]
- Updated dependencies [95ed3396]
- Updated dependencies [72650ffa]
- Updated dependencies [d97114b4]
- Updated dependencies [7875a24a]
- Updated dependencies [0a66303a]
- Updated dependencies [4145c62f]
  - @sxf/er-config@1.0.0

## 1.0.0-beta.0 (2024-01-17)

### Major Changes

- 0b0e74eb: chore: init beta version release

### Patch Changes

- Updated dependencies [0b0e74eb]
  - @sxf/er-config@1.0.0-beta.0

## 0.5.1 (2024-02-23)

### Patch Changes

- b670da5e: fix(utils:ajax): 新增'notmodified', 'nocontent'的请求成功状态

## 0.5.0 (2024-01-23)

### Minor Changes

- 33f33ab5: 增加 ajax 对于 error 请求，错误信息自定义回调处理

## 0.4.0 (2023-12-26)

### Minor Changes

- 20c5906b: feat(utils:ajax): 新增 preHook 钩子

## 0.3.0 (2023-12-08)

### Minor Changes

- c9f5e0cf: feat(utils): jquery 和 Eresh 子包之间的依赖全部声明成 peer

## 0.2.1 (2023-09-28)

### Patch Changes

- cdca5348: fix(utils:numberic): 修复类型校验

## 0.2.0 (2023-09-22)

### Minor Changes

- 6305306: feat(utils): 新增将提示内容转换为 HTML 格式的字符串函数

### Patch Changes

- 48954f5: fix(utils:ajax): 修复返回数据问题

## 0.1.2 (2023-09-12)

### Patch Changes

- fix(utils:ajax): 修复 AjaxSettings 缺失 mimeType 字段的问题

## 0.1.1 (2023-09-08)

### Patch Changes

- b5aa8c7: 完善 request 类型
- 30fc775: fix: 修复 numberic 类型报错

## 0.1.0 (2023-08-18)

### Minor Changes

- b597743: build: er-config 和 er-style 改为 peer 依赖

## 0.0.15 (2023-07-11)

### Patch Changes

- 5f48871: feat: 修改 workspace 依赖包版本

## 0.0.14 (2023-06-28)

### Patch Changes

- 9ba3d17: fix: 修改 ajax 的实例判断

  针对子应用非共享包的场景，不能使用 instanceof 的判断

## 0.0.13 (2023-06-09)

### Patch Changes

- feat: 添加 module 字段

## 0.0.12 (2023-05-25)

### Patch Changes

- 21629e5: fix(utils:ajax): 修复 ajax 配置错误的 contentType 导致的报错

## 0.0.11 (2023-05-16)

### Patch Changes

- 62f2915: fix(utils:ajax): 修复调用 hook 时 url 可能为空的情况

## 0.0.10 (2023-05-15)

### Patch Changes

- 57f95f2: feat(utils:ip): 把 validator 中的 ip 解析相关内容放到 utils/ip 包下
- 25abf45: refactor(comp:form): 表单校验重构

  - SfForm 取消绑定 vtype，实现脱离 dom 元素校验
  - 各表单组件校验失败的红显逻辑放在组件内部实现

- e4dab5f: feat(utils:when): when 方法加上支持传入函数

## 0.0.9 (2023-05-12)

### Patch Changes

- a119fa7: feat: 新增一个 when 方法，在 $.when 基础上封装，兼容 Promise

## 0.0.8 (2023-04-23)

### Patch Changes

- Updated dependencies [7e2d09e]
  - @sxf/er-config@0.0.7

## 0.0.7 (2023-04-17)

### Patch Changes

- Updated dependencies [b1158d4]
  - @sxf/er-config@0.0.6

## 0.0.6 (2023-04-14)

### Patch Changes

- 9e25dc7: fix(utils:\*): 修复 jsdoc 注释导致生成类型错误的问题

## 0.0.5 (2023-04-13)

### Patch Changes

- 80ecd83: fix: 修复构建 external 问题
- Updated dependencies [80ecd83]
  - @sxf/er-config@0.0.5

## 0.0.4 (2023-04-12)

### Patch Changes

- bde581a: refactor(utils:\*): pick 部分业余依赖的 utils

  - browser
  - clone
  - cluster，移除业务中没有使用的 login 相关部分
  - event（由\_private 改为正式向外暴露）
  - template
  - timer

- 9876ea5: refactor(utils:ajax): 把 ajax 全局配置抽离成 hook 注入
- 9dedad4: feat: 新增部分 types，满足 hooks 包的依赖
- c769e65: refactor(utils:typeof): pick typeof

  - typeof 仅保留业务中使用的 isNull，放在 utils/lang 中提供
  - widget/tip 统一 cfg 处理方式

- 95ce2b0: refactor(utils:dom): pick dom utils

  - 调整 @er/utils/dom 文件结构
  - 搬运依赖到的 dom utils：fireEvent, getSubmitData
  - 修复 setSubmitData 针对 radio 无法正确设置值的 bug
  - repaint 内置到 fixfieldset 中

- be1fa10: refactor(utils:\*): pick 部分业务依赖的 utils

  - mul-ajax 搬运到 @er/utils/ajax 下，以 multiAjax 具名导出
  - storage
  - loadFile

- dfce2dc: refactor: 对 utils 库里的内容加完整注释
- Updated dependencies [dfce2dc]
  - @sxf/er-config@0.0.4

## 0.0.3 (2023-04-03)

### Patch Changes

- f467d2f: build: 使用 tsup 打包 utils, validator 等纯 js 包，生成 d.ts 文件
- 1daafc1: refactor: 去除所有的全局 VMP 与 install 接口
- 419340c: refactor: 将所有获取国际化词条的配置内容不在初始化执行
- Updated dependencies [f467d2f]
- Updated dependencies [1daafc1]
  - @sxf/er-config@0.0.3

## 0.0.2 (2023-03-29)

### Patch Changes

- release
- Updated dependencies
  - @sxf/er-config@0.0.2

## 0.0.1 (2023-03-29)

### Patch Changes

- chore: release
- Updated dependencies
  - @sxf/er-config@0.0.1
