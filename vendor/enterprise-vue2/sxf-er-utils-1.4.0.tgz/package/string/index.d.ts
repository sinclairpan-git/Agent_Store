declare namespace _String {
    function insert(s: string, value: string, index: number): string;
    function startsWith(s: string, start: string, ignoreCase?: boolean | undefined): boolean;
    function endsWith(s: string, end: string, ignoreCase?: boolean | undefined): boolean;
    function createVarName(s: string): string;
    function htmlEncode(value: string): string;
    function htmlTextEncode(value: any): any;
    function htmlDoubleEncode(value: string): string;
    function htmlDecode(value: string): string;
    function addCharacterEntities(newEntities: Object): void;
    function resetCharacterEntities(): void;
    function urlAppend(url: string, string: string): string;
    function trim(string: string): string;
    function capitalize(string: string): string;
    function uncapitalize(string: string): string;
    function ellipsis(value: string, len: number, word?: boolean | undefined): string;
    function escapeRegex(string: string): string;
    function escape(string: string): string;
    function toggle(string: string, value: string, other: string): string;
    function leftPad(string: string, size: number, character?: string | undefined): string;
    function format(format: string, ...args: any[]): string;
    function repeat(pattern: string, count: number, sep: string): string;
    function splitWords(words: any): any;
}

export { _String as default };
