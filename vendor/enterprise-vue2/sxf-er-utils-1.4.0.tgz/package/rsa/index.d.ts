declare function encrypt(msg: any): any;
declare function setPublic(publicKey: any): void;

export { encrypt, setPublic };
