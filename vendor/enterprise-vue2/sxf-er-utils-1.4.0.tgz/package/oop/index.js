// packages/utils/oop/index.js
import apply from "@sxf/er-utils/apply";
import ua from "@sxf/er-utils/ua";
var isIE = ua.isIE;
var override = function(origclass, overrides) {
  if (overrides) {
    const p = origclass.prototype;
    apply(p, overrides);
    if (isIE && overrides.hasOwnProperty("toString")) {
      p.toString = overrides.toString;
    }
  }
};
var extend = function() {
  const io = function(o) {
    for (const m in o) {
      this[m] = o[m];
    }
  };
  const oc = Object.prototype.constructor;
  return function(sb, sp, overrides) {
    if (typeof sp === "object") {
      overrides = sp;
      sp = sb;
      const fn = function(...args) {
        sp.apply(this, args);
      };
      sb = overrides.constructor !== oc ? overrides.constructor : fn;
    }
    const F = function() {
    };
    const spp = sp.prototype;
    F.prototype = spp;
    const sbp = sb.prototype = new F();
    sbp.constructor = sb;
    sb.superclass = spp;
    if (spp.constructor === oc) {
      spp.constructor = sp;
    }
    sb.override = function(o) {
      override(sb, o);
    };
    sbp.superclass = sbp.supr = function() {
      return spp;
    };
    sbp.override = io;
    override(sb, overrides);
    sb.extend = function(o) {
      return extend.extend(sb, o);
    };
    return sb;
  };
}();
var oop_default = { extend, override };
export {
  oop_default as default,
  extend,
  override
};
