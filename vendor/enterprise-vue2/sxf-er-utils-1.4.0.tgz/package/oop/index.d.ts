declare function override(origclass: Function, overrides: Object): void;
declare function extend(sb: any, sp: any, overrides: any): any;
declare namespace _default {
    export { extend };
    export { override };
}

export { _default as default, extend, override };
