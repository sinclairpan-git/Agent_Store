// packages/utils/dom/lib/style.js
var SPECIAL_CHARS_REGEXP = /([\:\-\_]+(.))/g;
var MOZ_HACK_REGEXP = /^moz([A-Z])/;
var ieVersion = Number(document.documentMode);
var camelCase = function(name) {
  return name.replace(SPECIAL_CHARS_REGEXP, function(_, separator, letter, offset) {
    return offset ? letter.toUpperCase() : letter;
  }).replace(MOZ_HACK_REGEXP, "Moz$1");
};
function getStyleLowVersion(element, styleName) {
  if (!element || !styleName) {
    return null;
  }
  styleName = camelCase(styleName);
  if (styleName === "float") {
    styleName = "styleFloat";
  }
  try {
    switch (styleName) {
      case "opacity":
        try {
          return element.filters.item("alpha").opacity / 100;
        } catch (e) {
          return 1;
        }
      default:
        return element.style[styleName] || element.currentStyle ? element.currentStyle[styleName] : null;
    }
  } catch (e) {
    return element.style[styleName];
  }
}
function getStyleNormalVersion(element, styleName) {
  if (!element || !styleName) {
    return null;
  }
  styleName = camelCase(styleName);
  if (styleName === "float") {
    styleName = "cssFloat";
  }
  try {
    const computed = document.defaultView.getComputedStyle(element, "");
    return element.style[styleName] || computed ? computed[styleName] : null;
  } catch (e) {
    return element.style[styleName];
  }
}
var getStyle = ieVersion < 9 ? getStyleLowVersion : getStyleNormalVersion;
function setStyle(element, styleName, value) {
  if (!element || !styleName) {
    return;
  }
  if (typeof styleName === "object") {
    for (const prop in styleName) {
      if (styleName.hasOwnProperty(prop)) {
        setStyle(element, prop, styleName[prop]);
      }
    }
  } else {
    styleName = camelCase(styleName);
    if (styleName === "opacity" && ieVersion < 9) {
      element.style.filter = isNaN(value) ? "" : "alpha(opacity=" + value * 100 + ")";
    } else {
      element.style[styleName] = value;
    }
  }
}
function getStyleComputedProperty(element, property) {
  const css = getComputedStyle(element, null);
  return css[property];
}

// packages/utils/dom/lib/scroll.js
function getScrollParent(element) {
  const parent = element && element.parentNode;
  if (!parent) {
    return element;
  }
  if (parent === document) {
    if (document.body.scrollTop) {
      return document.body;
    } else {
      return document.documentElement;
    }
  }
  if (["scroll", "auto"].indexOf(getStyleComputedProperty(parent, "overflow")) !== -1 || ["scroll", "auto"].indexOf(getStyleComputedProperty(parent, "overflow-x")) !== -1 || ["scroll", "auto"].indexOf(getStyleComputedProperty(parent, "overflow-y")) !== -1) {
    return parent;
  }
  return getScrollParent(element.parentNode);
}
function getScrollParentList(element) {
  const targets = [];
  let scrollParent = getScrollParent(element);
  while (scrollParent) {
    targets.push(scrollParent);
    const isLast = scrollParent.nodeName === "BODY" || scrollParent === document.body || scrollParent === document.documentElement;
    if (isLast) {
      break;
    }
    scrollParent = getScrollParent(scrollParent);
  }
  return targets;
}
var scrollBarWidth;
function getScrollBarWidth() {
  if (scrollBarWidth !== void 0) {
    return scrollBarWidth;
  }
  const outer = document.createElement("div");
  outer.style.visibility = "hidden";
  outer.style.width = "100px";
  outer.style.height = "100%";
  outer.style.position = "absolute";
  outer.style.top = "-9999px";
  document.body.appendChild(outer);
  const widthNoScroll = outer.offsetWidth;
  outer.style.overflow = "scroll";
  const inner = document.createElement("div");
  inner.style.width = "100%";
  outer.appendChild(inner);
  const widthWithScroll = inner.offsetWidth;
  outer.parentNode.removeChild(outer);
  scrollBarWidth = widthNoScroll - widthWithScroll;
  return scrollBarWidth;
}
function scrollIntoView(container, selected) {
  if (!selected) {
    container.scrollTop = 0;
    return;
  }
  const top = selected.offsetTop;
  const bottom = selected.offsetTop + selected.offsetHeight;
  const viewRectTop = container.scrollTop;
  const viewRectBottom = viewRectTop + container.clientHeight;
  if (top < viewRectTop) {
    container.scrollTop = top;
  } else if (bottom > viewRectBottom) {
    container.scrollTop = bottom - container.clientHeight;
  }
}

// packages/utils/dom/lib/scrollWidth.js
var needsPoly = featureDetect();
function featureDetect() {
  let needsPoly2 = false;
  const overrideStyles = [
    {
      name: "float",
      value: "left"
    },
    {
      name: "paddingLeft",
      value: "0px"
    },
    {
      name: "paddingRight",
      value: "0px"
    },
    {
      name: "position",
      value: "absolute"
    },
    {
      name: "width",
      value: "0px"
    },
    {
      name: "borderRightWidth",
      value: "0px"
    },
    {
      name: "borderLeftWidth",
      value: "0px"
    },
    {
      name: "visibility",
      value: "hidden"
    }
  ];
  const ghostMeasureInput = createGhostElement("input", null, overrideStyles, "Test", true);
  if (ghostMeasureInput.scrollWidth == 0) {
    needsPoly2 = true;
  }
  return needsPoly2;
}
function createGhostElement(elType, computedStyles, overrideStyles, content, callScrollWidth) {
  elType = elType.toLowerCase();
  const id = "swMeasure-" + Date.now();
  let el = document.createElement(elType);
  el.id = id;
  const initStyle = el.style;
  if (computedStyles !== null) {
    const csKeys = Object.keys(computedStyles.__proto__);
    csKeys.forEach(function(prop) {
      initStyle[prop] = computedStyles[prop];
    });
    el.style = initStyle;
  }
  overrideStyles.forEach(function(overrideStyle) {
    el.style[overrideStyle.name] = overrideStyle.value;
  });
  if (elType == "input" || elType == "textarea") {
    el.value = content;
  } else {
    el.textContent = content;
  }
  document.getElementsByTagName("body")[0].appendChild(el);
  el = document.getElementById(id);
  const ghostMeasure = {
    scrollWidth: callScrollWidth ? el.scrollWidth : 0,
    clientWidth: parseInt(el.clientWidth, 10)
  };
  el.outerHTML = "";
  el = null;
  return ghostMeasure;
}
function getScrollWidth(element) {
  if (!needsPoly) {
    return element.scrollWidth;
  }
  const self = element;
  let width = "auto";
  const computedStyles = window.getComputedStyle(self, null);
  if (self.nodeName == "TEXTAREA") {
    width = computedStyles.width;
  }
  const overrideStyles = [
    {
      name: "position",
      value: "absolute"
    },
    {
      name: "float",
      value: "left"
    },
    {
      name: "visibility",
      value: "hidden"
    },
    // We don't want the width set
    {
      name: "width",
      value: width
    }
  ];
  const ghost = createGhostElement("div", computedStyles, overrideStyles, self.value, false);
  return Math.max(parseInt(computedStyles.width), ghost.clientWidth);
}

// packages/utils/dom/lib/class.js
var trim = function(string) {
  return (string || "").replace(/^[\s\uFEFF]+|[\s\uFEFF]+$/g, "");
};
function hasClass(el, cls) {
  if (!el || !cls) {
    return false;
  }
  if (cls.indexOf(" ") !== -1) {
    throw new Error("className should not contain space.");
  }
  if (el.classList) {
    return el.classList.contains(cls);
  } else {
    return (" " + el.className + " ").indexOf(" " + cls + " ") > -1;
  }
}
function addClass(el, cls) {
  if (!el) {
    return;
  }
  let curClass = el.className;
  const classes = (cls || "").split(" ");
  for (let i = 0, j = classes.length; i < j; i++) {
    const clsName = classes[i];
    if (!clsName) {
      continue;
    }
    if (el.classList) {
      el.classList.add(clsName);
    } else {
      if (!hasClass(el, clsName)) {
        curClass += " " + clsName;
      }
    }
  }
  if (!el.classList) {
    el.className = curClass;
  }
}
function removeClass(el, cls) {
  if (!el || !cls) {
    return;
  }
  const classes = cls.split(" ");
  let curClass = " " + el.className + " ";
  for (let i = 0, j = classes.length; i < j; i++) {
    const clsName = classes[i];
    if (!clsName) {
      continue;
    }
    if (el.classList) {
      el.classList.remove(clsName);
    } else {
      if (hasClass(el, clsName)) {
        curClass = curClass.replace(" " + clsName + " ", " ");
      }
    }
  }
  if (!el.classList) {
    el.className = trim(curClass);
  }
}

// packages/utils/dom/lib/event.js
import $ from "jquery";
import apply from "@sxf/er-utils/apply";
var on = function() {
  return function(element, event, handler) {
    if (element && event && handler) {
      element.addEventListener(event, handler, false);
    }
  };
}();
var off = function() {
  return function(element, event, handler) {
    if (element && event) {
      element.removeEventListener(event, handler, false);
    }
  };
}();
var once = function(el, event, fn) {
  const listener = function() {
    if (fn) {
      fn.apply(this, arguments);
    }
    off(el, event, listener);
  };
  on(el, event, listener);
};
var getEventPath = function(event) {
  if ("composedPath" in event) {
    return event.composedPath();
  }
  if ("path" in event) {
    return event.path;
  }
  const path = [];
  let currentElem = event.target;
  do {
    path.push(currentElem);
    currentElem = currentElem.parentElement;
  } while (currentElem && currentElem !== document.body);
  return path;
};
var fireEvent = function(dom, eventName, data) {
  let ev;
  $(dom).each(function(idx, d) {
    if (document.createEvent) {
      ev = document.createEvent("HTMLEvents");
      ev.initEvent(eventName, true, false);
      ev = apply(ev, data);
      d.dispatchEvent(ev);
    } else if (document.createEventObject) {
      ev = document.createEventObject();
      ev = apply(ev, data);
      d.fireEvent("on" + eventName, ev);
    }
  });
};

// packages/utils/dom/lib/submitData.js
import $2 from "jquery";
var getSubmitData = function(dom, attr, fn) {
  const ret = {};
  attr = attr || "data-submit-name";
  $2("[" + attr + "]", $2(dom)).each(function(idx, d) {
    d = $2(d);
    const key = $2(d).attr(attr);
    if (typeof fn === "function") {
      fn.call(this, d, key, ret);
    } else if ($2(d).is("input[type=checkbox]") || $2(d).is("input[type=radio]")) {
      ret[key] = $2(d).get(0).checked ? 1 : 0;
    } else {
      ret[key] = $2(d).val();
    }
  });
  return ret;
};
var setSubmitData = function(dom, value, attr, fn) {
  const v = $2.extend(true, {}, value);
  attr = attr || "data-submit-name";
  $2("[" + attr + "]", $2(dom)).each(function(idx, d) {
    d = $2(d);
    const key = $2(d).attr(attr);
    if (v[key] !== void 0 && v[key] !== null) {
      if (typeof fn === "function") {
        fn.call(this, d, key, v[key], v);
      } else if ($2(d).is("input[type=checkbox]")) {
        $2(d).get(0).checked = !!v[key];
      } else if ($2(d).is("input[type=radio]")) {
        if ($2(d).attr("value") === v[key]) {
          $2(d).get(0).checked = true;
        }
      } else if ($2(d).is("select")) {
        $2(d).fixselect("value", v[key]);
      } else {
        $2(d).val(v[key]);
      }
    }
  });
};

// packages/utils/dom/lib/scrollManager.js
import $3 from "jquery";
import { throttle } from "@sxf/er-utils/delay";
function getFixScrollbarElement(element) {
  var _a;
  const className = ".ps.ps--active-y";
  return (_a = element.closest) == null ? void 0 : _a.call(element, className);
}
var THROTTLE_TIME = 200;
var ScrollManager = class {
  /**
   * 构造函数
   *
   * @param {Object} options - 配置选项
   * @param {Function} options.onScroll - 滚动事件处理函数
   * @param {number} [options.throttleTime=THROTTLE_TIME] - 节流时间
   */
  constructor(options) {
    var _a;
    this.lastScrollParent = null;
    this.lastFixScrollbar = null;
    this.isDestroyed = false;
    this.scrollHandler = throttle((scrollEvent) => {
      var _a2;
      if (this.isDestroyed) {
        return;
      }
      if (!((_a2 = this.lastScrollParent) == null ? void 0 : _a2.includes(scrollEvent.target)) && scrollEvent.target !== this.lastFixScrollbar) {
        return;
      }
      this.removeScrollEvent();
      options.onScroll(scrollEvent);
    }, (_a = options.throttleTime) != null ? _a : THROTTLE_TIME);
  }
  updateScrollParents(element) {
    this.removeScrollEvent();
    this.lastScrollParent = getScrollParentList(element);
    this.lastFixScrollbar = getFixScrollbarElement(element);
    this.setupScrollEvent();
  }
  setupScrollEvent() {
    if (this.lastScrollParent) {
      this.lastScrollParent.forEach((el) => {
        $3(el).on("scroll", this.scrollHandler);
      });
    }
    if (this.lastFixScrollbar) {
      this.lastFixScrollbar.addEventListener("ps-scroll-y", this.scrollHandler);
    }
  }
  removeScrollEvent() {
    if (this.lastScrollParent) {
      this.lastScrollParent.forEach((el) => {
        $3(el).off("scroll", this.scrollHandler);
      });
    }
    if (this.lastFixScrollbar) {
      this.lastFixScrollbar.removeEventListener("ps-scroll-y", this.scrollHandler);
    }
  }
  /**
   * 清空滚动父元素和固定滚动条引用，并移除所有滚动事件监听
   * 用于外部需要重置状态或避免内存泄漏的场景
   */
  clear() {
    this.removeScrollEvent();
    this.lastScrollParent = null;
    this.lastFixScrollbar = null;
  }
  /**
   * 销毁 ScrollManager 实例，清理所有事件监听器和引用
   */
  destroy() {
    if (this.isDestroyed) {
      return;
    }
    this.removeScrollEvent();
    this.lastScrollParent = null;
    this.lastFixScrollbar = null;
    this.scrollHandler = null;
    this.isDestroyed = true;
  }
};
export {
  ScrollManager,
  addClass,
  fireEvent as emit,
  fireEvent,
  getSubmitData as get,
  getEventPath,
  getScrollBarWidth,
  getScrollParent,
  getScrollParentList,
  getScrollWidth,
  getStyle,
  getStyleComputedProperty,
  getSubmitData,
  hasClass,
  off,
  on,
  once,
  removeClass,
  scrollIntoView,
  setSubmitData as set,
  setStyle,
  setSubmitData
};
