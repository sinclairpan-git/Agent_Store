/**
 * Returns the scrolling parent of the given element
 *
 * @function
 * @argument {Element} element
 * @returns {Element} offset parent
 */
declare function getScrollParent(element: Element): Element;
/**
 * Returns the scrolling parent of the given element
 *
 * @function
 * @argument {Element} element
 * @returns {Element[]} offset parent
 */
declare function getScrollParentList(element: Element): Element[];
declare function getScrollBarWidth(): any;
declare function scrollIntoView(container: any, selected: any): void;

declare function getScrollWidth(element: any): any;

/**
 * 判断元素是否包含指定类名
 *
 * @param {Element} el - 待判断的元素
 * @param {string} cls - 待判断的类名
 * @returns {boolean} 元素是否包含指定类名
 * @throws {Error} 类名中包含空格时抛出错误
 * @example
 * hasClass(document.body, 'container') // true
 */
declare function hasClass(el: Element, cls: string): boolean;
/**
 * 给元素添加类名
 *
 * @param {Element} el - 待添加类名的元素
 * @param {string} cls - 待添加的类名，多个类名用空格分隔
 * @example
 * addClass(document.body, 'container') // <body class="container">
 */
declare function addClass(el: Element, cls: string): void;
/**
 * 给元素移除类名
 *
 * @param {Element} el - 待移除类名的元素
 * @param {string} cls - 待移除的类名，多个类名用空格分隔
 * @example
 * removeClass(document.body, 'container') // <body class="">
 */
declare function removeClass(el: Element, cls: string): void;

declare function on(element: any, event: any, handler: any): void;
declare function off(element: any, event: any, handler: any): void;
declare function once(el: HTMLElement, event: string, fn: Function): void;
declare function getEventPath(event: Object): Element[];
declare function fireEvent(dom: JQueryStatic, eventName: string, data: Object): void;

declare function setStyle(element: any, styleName: any, value: any): void;
/**
 * Get CSS computed property of the given element
 *
 * @function
 * @argument {Element} element
 * @argument {String} property
 */
declare function getStyleComputedProperty(element: Element, property: string): any;
declare function getStyle(element: any, styleName: any): any;

declare function getSubmitData(dom: HTMLElement, attr?: string | undefined, fn?: Function | undefined): Object;
declare function setSubmitData(dom: HTMLElement, value: Object, attr?: string | undefined, fn?: Function | undefined): void;

declare class ScrollManager {
    /**
     * 构造函数
     *
     * @param {Object} options - 配置选项
     * @param {Function} options.onScroll - 滚动事件处理函数
     * @param {number} [options.throttleTime=THROTTLE_TIME] - 节流时间
     */ constructor(options: {
        onScroll: Function;
        throttleTime?: number | undefined;
    });
    lastScrollParent: Element[] | null;
    lastFixScrollbar: any;
    isDestroyed: boolean;
    scrollHandler: Function;
    updateScrollParents(element: any): void;
    setupScrollEvent(): void;
    removeScrollEvent(): void;
    /**
     * 清空滚动父元素和固定滚动条引用，并移除所有滚动事件监听
     * 用于外部需要重置状态或避免内存泄漏的场景
     */
    clear(): void;
    /**
     * 销毁 ScrollManager 实例，清理所有事件监听器和引用
     */
    destroy(): void;
}

export { ScrollManager, addClass, fireEvent as emit, fireEvent, getSubmitData as get, getEventPath, getScrollBarWidth, getScrollParent, getScrollParentList, getScrollWidth, getStyle, getStyleComputedProperty, getSubmitData, hasClass, off, on, once, removeClass, scrollIntoView, setSubmitData as set, setStyle, setSubmitData };
