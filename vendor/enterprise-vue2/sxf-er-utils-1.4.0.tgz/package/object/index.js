// packages/utils/object/index.js
import Lang from "@sxf/er-utils/lang";
var toQueryString = function(object, recursive) {
  const params = [];
  let paramObjects = [];
  let i;
  let j;
  let ln;
  let paramObject;
  let value;
  for (i in object) {
    if (object.hasOwnProperty(i)) {
      paramObjects = paramObjects.concat(toQueryObjects(i, object[i], recursive));
    }
  }
  for (j = 0, ln = paramObjects.length; j < ln; j++) {
    paramObject = paramObjects[j];
    value = paramObject.value;
    if (Lang.isEmpty(value)) {
      value = "";
    } else if (Lang.isDate(value)) {
      value = _dateToString(value);
    }
    params.push(encodeURIComponent(paramObject.name) + "=" + encodeURIComponent(String(value)));
  }
  return params.join("&");
};
var toQueryObjects = function(name, value, recursive) {
  let objects = [];
  let i;
  let ln;
  if (Lang.isArray(value)) {
    for (i = 0, ln = value.length; i < ln; i++) {
      if (recursive) {
        objects = objects.concat(toQueryObjects(name + "[" + i + "]", value[i], true));
      } else {
        objects.push({
          name,
          value: value[i]
        });
      }
    }
  } else if (Lang.isObject(value)) {
    for (i in value) {
      if (value.hasOwnProperty(i)) {
        if (recursive) {
          objects = objects.concat(toQueryObjects(name + "[" + i + "]", value[i], true));
        } else {
          objects.push({
            name,
            value: value[i]
          });
        }
      }
    }
  } else {
    objects.push({
      name,
      value
    });
  }
  return objects;
};
var fromQueryString = function(queryString, recursive) {
  const index = queryString.indexOf("?");
  let parts = [];
  const object = {};
  let temp;
  let components;
  let name;
  let value;
  let i;
  let ln;
  let part;
  let j;
  let subLn;
  let matchedKeys;
  let matchedName;
  let keys;
  let key;
  let nextKey;
  if (index !== -1) {
    queryString = queryString.substr(index);
  }
  parts = queryString.replace(/^\?/, "").split("&");
  for (i = 0, ln = parts.length; i < ln; i++) {
    part = parts[i];
    if (part.length > 0) {
      components = part.split("=");
      name = decodeURIComponent(components[0]);
      value = components[1] !== void 0 ? decodeURIComponent(components[1]) : "";
      if (!recursive) {
        if (object.hasOwnProperty(name)) {
          if (!Lang.isArray(object[name])) {
            object[name] = [object[name]];
          }
          object[name].push(value);
        } else {
          object[name] = value;
        }
      } else {
        matchedKeys = name.match(/(\[):?([^\]]*)\]/g);
        matchedName = name.match(/^([^\[]+)/);
        name = matchedName[0];
        keys = [];
        if (matchedKeys === null) {
          object[name] = value;
          continue;
        }
        for (j = 0, subLn = matchedKeys.length; j < subLn; j++) {
          key = matchedKeys[j];
          key = key.length === 2 ? "" : key.substring(1, key.length - 1);
          keys.push(key);
        }
        keys.unshift(name);
        temp = object;
        for (j = 0, subLn = keys.length; j < subLn; j++) {
          key = keys[j];
          if (j === subLn - 1) {
            if (Lang.isArray(temp) && key === "") {
              temp.push(value);
            } else {
              temp[key] = value;
            }
          } else {
            if (temp[key] === void 0 || typeof temp[key] === "string") {
              nextKey = keys[j + 1];
              temp[key] = Lang.isNumeric(nextKey) || nextKey === "" ? [] : {};
            }
            temp = temp[key];
          }
        }
      }
    }
  }
  return object;
};
var _dateToString = function(date) {
  return date.getFullYear() + "-" + _leftPad(date.getMonth() + 1) + "-" + _leftPad(date.getDate()) + "T" + _leftPad(date.getHours()) + ":" + _leftPad(date.getMinutes()) + ":" + _leftPad(date.getSeconds());
};
var _leftPad = function(d, maxLength = 2, fillString = "0") {
  return `${d}`.padStart(maxLength, fillString);
};
export {
  fromQueryString,
  toQueryObjects,
  toQueryString
};
