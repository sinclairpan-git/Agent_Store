declare function toQueryString(object: Object, recursive?: boolean | undefined): string;
declare function toQueryObjects(name: string, value: any, recursive?: boolean | undefined): any[];
declare function fromQueryString(queryString: string, recursive?: boolean | undefined): Object;

export { fromQueryString, toQueryObjects, toQueryString };
