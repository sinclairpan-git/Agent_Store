/**
 * 定义请求函数
 *
 * @param {Object} config 请求配置
 * @param {string} config.url 请求的 URL
 * @param {string} [config.type] 请求的类型，可选
 * @param {string} [config.dataType] 返回的数据类型，可选
 * @param {Function} [config.params] 构造请求数据的函数，接收一个参数，返回一个对象，可选
 * @param {Object} [config.urlParams] 构造 URL 参数的对象或函数，接收一个参数，返回一个对象，可选
 * @param {Object} [config.structure] 结构化数据的格式用于格式化返回数据，可选
 * @param {string} [config.apiType='v2'] API 的类型，可选，默认为 'v2'
 * @param {Object} [config.mock] 模拟数据，可选
 * @param {Function} [config.headers] 构造请求头的函数，可选，返回一个对象
 * @returns {(params?: any) => any} 请求函数，返回一个 Promise 对象
 */
declare function defineRequest(config: {
    url: string;
    type?: string | undefined;
    dataType?: string | undefined;
    params?: Function | undefined;
    urlParams?: Object | undefined;
    structure?: Object | undefined;
    apiType?: string | undefined;
    mock?: Object | undefined;
    headers?: Function | undefined;
}): (params?: any) => any;
declare function getRequestID(data: Object): number;
declare function getRequest(idParam: number): Function;
declare function removeRequestById(idParam: number): void;

/**
 * 表格参数
 *
 * @param {{}} params
 * @returns {{}} 表格参数
 */
declare function gridParams(params: {}): {};
declare function toInt(data: any): number;
declare function toString(data: any): string;
declare function toNumber(value: any): number;
declare function toBoolean(value: any): boolean;
/**
 * 格式化数据的函数
 *
 * @param {*} data 要格式化的数据
 * @param {*} [format] 格式化的格式，可选
 * @param {boolean} [strict] 是否严格按照格式化的格式进行格式化，可选
 * @param {*} [formatParams] 格式化参数，根据不同的格式有不同的参数，可选
 * @returns {*} 格式化后的数据
 */
declare function dataFormat(data: any, format?: any, strict?: boolean | undefined, formatParams?: any): any;
declare function formatToData(format: any, currentData: any, strict: any, formatParams: any): any;

export { dataFormat, defineRequest, formatToData, getRequest, getRequestID, gridParams, removeRequestById, toBoolean, toInt, toNumber, toString };
