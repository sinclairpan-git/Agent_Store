// packages/utils/request/format.js
function gridParams(params) {
  const data = {
    start: toInt(params.start),
    limit: toInt(params.limit),
    sort: toString(params.sort),
    direct: toString(params.direct),
    keywords: toString(params.keywords),
    refresh: toInt(params.refresh)
  };
  Object.keys(data).map((key) => {
    if (!params.hasOwnProperty(key)) {
      delete data[key];
    }
  });
  if (!data.keywords) {
    delete data.keywords;
  }
  return data;
}
function toInt(data) {
  return parseInt(toNumber(data), 10) || 0;
}
function toString(data) {
  return data || data === 0 ? String(data) : "";
}
function toNumber(value) {
  return Number(value) || 0;
}
function toBoolean(value) {
  return Boolean(value) || false;
}
function dataFormat(data, format, strict, formatParams) {
  if (!format) {
    return data;
  }
  if (Array.isArray(data) && Array.isArray(format)) {
    return data.map((item) => dataFormat(item, format[0], strict, formatParams));
  }
  if (isObject(data) && isObject(format)) {
    const obj = {};
    for (const prop of Object.keys(data)) {
      if (strict && format.hasOwnProperty(prop) || !strict) {
        obj[prop] = dataFormat(data[prop], format[prop], strict, formatParams);
      }
    }
    for (const prop of Object.keys(format)) {
      if (strict && format[prop] === true && !data.hasOwnProperty(prop)) {
        continue;
      }
      if (!data.hasOwnProperty(prop)) {
        obj[prop] = dataFormat(data[prop], format[prop], strict, formatParams);
      }
    }
    return obj;
  }
  return formatToData(format, data, strict, formatParams);
}
function isEmpty(data) {
  return !data && data !== 0 && data !== false;
}
function isObject(data) {
  return typeof data === "object" && data;
}
function formatToData(format, currentData, strict, formatParams) {
  if (typeof format === "function") {
    if (formatParams) {
      return format(currentData, formatParams);
    }
    return format(currentData);
  }
  if (!isEmpty(currentData)) {
    return currentData;
  }
  if (Array.isArray(format)) {
    return [];
  }
  if (typeof format === "object" && format) {
    const obj = {};
    for (const prop of Object.keys(format)) {
      if (strict && format[prop] === true) {
        continue;
      }
      obj[prop] = formatToData(format[prop], (currentData || {})[prop], strict, formatParams);
    }
    return obj;
  }
  return currentData;
}

// packages/utils/request/defineRequest.js
import $ from "jquery";
import { globalConfig } from "@sxf/er-config";
import { ajax, apiType, formatResData } from "@sxf/er-utils/ajax";
import formatUtil from "@sxf/er-utils/format";
var requestMap = {};
var id = 1;
var ID_FIELD = "__defineRequestID";
var getRequestID = (data) => {
  return data && data[ID_FIELD];
};
var getRequest = (idParam) => {
  return requestMap[idParam];
};
var removeRequestById = (idParam) => {
  delete requestMap[idParam];
};
function defineRequest(config) {
  const ID = id++;
  const func = function(params = {}) {
    var _a;
    const data = $.isFunction(config.params) ? config.params(params) : {};
    const formatParams = data;
    const urlParams = $.isFunction(config.urlParams) ? config.urlParams(params, data) : config.urlParams || params || {};
    const headers = $.isFunction(config.headers) ? config.headers() : config.headers;
    const ajaxConfig = $.extend({}, config, {
      url: formatUtil.xformat(config.url, urlParams),
      data,
      headers,
      /**
       * 记录下当前ID标识
       */
      [ID_FIELD]: ID,
      /**
       * 去掉无用参数，不允许设置回调
       */
      params: null,
      urlParams: null,
      structure: null,
      complete: null,
      error: null,
      success: null,
      failure: null,
      callback: null
    });
    if ((_a = globalConfig.apiConfig) == null ? void 0 : _a.progressData) {
      ajaxConfig.data = globalConfig.apiConfig.progressData(ajaxConfig.data);
    }
    return ajax(ajaxConfig).then(function(...args) {
      if (config.structure) {
        args[0] = dataFormat(args[0], config.structure, false, formatParams);
      }
      if (config.apiType === apiType.v2) {
        args[0] = formatResData(args[0]);
      }
      return $.Deferred().resolveWith(this, args);
    });
  };
  func[ID_FIELD] = ID;
  requestMap[ID] = func;
  if (config.structure) {
    Object.defineProperty(func, "STRUCTURE", {
      get() {
        return clone(config.structure);
      }
    });
    const data = formatToData(config.structure);
    Object.defineProperty(func, "DATA", {
      get() {
        return clone(data);
      }
    });
  }
  return func;
}
function clone(data) {
  if (data && typeof data === "object") {
    return Array.isArray(data) ? $.extend(true, [], data) : $.extend(true, {}, data);
  }
  return data;
}
export {
  dataFormat,
  defineRequest,
  formatToData,
  getRequest,
  getRequestID,
  gridParams,
  removeRequestById,
  toBoolean,
  toInt,
  toNumber,
  toString
};
