/**
 * 延迟执行任务的构造函数
 *
 * @param {Function} fn - 要执行的函数
 * @param {Object} [scope] - 函数执行时的作用域
 * @param {Array} [args] - 函数执行时的参数
 * @constructor
 */
declare function DelayedTask(fn: Function, scope?: Object | undefined, args?: any[] | undefined): void;
declare class DelayedTask {
    /**
     * 延迟执行任务的构造函数
     *
     * @param {Function} fn - 要执行的函数
     * @param {Object} [scope] - 函数执行时的作用域
     * @param {Array} [args] - 函数执行时的参数
     * @constructor
     */
    constructor(fn: Function, scope?: Object | undefined, args?: any[] | undefined);
    /**
     * 延迟执行任务
     *
     * @param {Number} delay - 延迟的毫秒数
     * @param {Function} [newFn] - 要执行的新函数，可选
     * @param {Object} [newScope] - 新函数执行时的作用域，可选。如果未指定，则默认为浏览器窗口。
     * @param {Array} [newArgs] - 新函数执行时的参数，可选
     * @example
     * const task = new DelayedTask(() => {
     *   console.log('Hello, world!');
     * });
     * task.delay(1000); // 1秒后输出 "Hello, world!"
     */
    delay: (delay: number, newFn?: Function | undefined, newScope?: Object | undefined, newArgs?: any[] | undefined) => void;
    /**
     * 取消上一个延迟任务
     *
     * @example
     * const task = new DelayedTask(() => {
     *   console.log('Hello, world!');
     * });
     * task.delay(1000); // 1秒后输出 "Hello, world!"
     * task.cancel(); // 取消延迟任务
     */
    cancel: () => void;
}

export { DelayedTask as default };
