// packages/utils/_private/detectPageStatus/index.js
var hiddenProperty = "hidden" in document ? "hidden" : "webkitHidden" in document ? "webkitHidden" : "mozHidden" in document ? "mozHidden" : "msHidden" in document ? "msHidden" : "";
var isPageHidden = document[hiddenProperty];
var visibilityChangeEvent = hiddenProperty.replace(/hidden/i, "visibilitychange");
var onVisibilityChange = function() {
  isPageHidden = document[hiddenProperty];
};
if (hiddenProperty) {
  document.addEventListener(visibilityChangeEvent, onVisibilityChange);
} else {
  isPageHidden = false;
}
var getPageStatus = () => {
  return isPageHidden;
};

// packages/utils/delayedTask/index.js
function DelayedTask(fn, scope, args) {
  const call = function() {
    if (!getPageStatus()) {
      clearInterval(id);
      id = null;
      fn.apply(scope, args || []);
    }
  };
  let id;
  this.delay = function(delay, newFn, newScope, newArgs) {
    this.cancel();
    fn = newFn || fn;
    scope = newScope || scope;
    args = newArgs || args;
    id = setInterval(call, delay);
  };
  this.cancel = function() {
    if (id) {
      clearInterval(id);
      id = null;
    }
  };
}
var delayedTask_default = DelayedTask;
export {
  delayedTask_default as default
};
