/**
 * 防抖函数-空闲控制 当高频率连续调用某函数停下来时，才会真正地去执行它
 * 抄 underscore.js 的，具体用法请看 _.debounce
 *
 * @param {Function} func - 需要防抖的函数
 * @param {number} wait - 等待时间，单位毫秒
 * @param {boolean} [immediate] - 是否在开始时立即执行一次函数
 * @returns {Function} - 返回一个新的函数
 *
 * @example
 *
 * function save() {
 *   console.log('save');
 * }
 *
 * const debouncedSave = debounce(save, 1000);
 *
 * setInterval(debouncedSave, 100);
 */
declare function debounce(func: Function, wait: number, immediate?: boolean | undefined): Function;
/**
 * 节流函数-频率控制 用于将高频率连续调用某函数控制为低频率
 * 抄 underscore.js 的，具体用法请看 _.throttle
 *
 * @param {Function} func - 需要节流的函数
 * @param {number} wait - 等待时间，单位毫秒
 * @param {Object} [options] - 可选参数
 * @param {boolean} [options.leading=true] - 是否在开始时立即执行一次函数
 * @param {boolean} [options.trailing=true] - 是否在结束时执行一次函数
 * @returns {Function} - 返回一个新的函数
 *
 * @example
 *
 * function update() {
 *   console.log('update');
 * }
 *
 * const throttledUpdate = throttle(update, 1000);
 *
 * setInterval(throttledUpdate, 100);
 */
declare function throttle(func: Function, wait: number, options?: {
    leading?: boolean | undefined;
    trailing?: boolean | undefined;
} | undefined): Function;

export { debounce, throttle };
