import { VueI18nIntl } from '@sxf/vue-intl';

declare const LANGUAGE: {
    readonly 'zh-CN': "zh-CN";
    readonly 'en-US': "en-US";
};
type LanguageValue = (typeof LANGUAGE)[keyof typeof LANGUAGE];

declare let $i: VueI18nIntl['i'];
declare let $iDate: VueI18nIntl['iDate'];
declare let $in: VueI18nIntl['in'];
declare let $irt: VueI18nIntl['irt'];
declare let $it: VueI18nIntl['it'];
declare const setLocale: (i18nIntl: VueI18nIntl, locale?: LanguageValue) => void;

export { $i, $iDate, $in, $irt, $it, setLocale };
