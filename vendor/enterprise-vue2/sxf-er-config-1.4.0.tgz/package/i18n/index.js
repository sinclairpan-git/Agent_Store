// packages/config/i18n/index.ts
import { LANGUAGE, addMessages } from "@sxf/er-feature";

// packages/config/global/index.ts
var defaultConfig = {
  isInternational: false,
  isLocaleZhCN: true,
  rootContainer: "#body",
  search: {}
};
var globalConfig = {
  ...defaultConfig
};
var updateGlobalConfig = (config) => {
  Object.assign(globalConfig, config);
};

// packages/config/i18n/index.ts
var $i;
var $iDate;
var $in;
var $irt;
var $it;
var setLocale = (i18nIntl, locale = LANGUAGE["zh-CN"]) => {
  addMessages(i18nIntl, locale);
  $i = i18nIntl.i;
  $iDate = i18nIntl.iDate;
  $in = i18nIntl.in;
  $irt = i18nIntl.irt;
  $it = i18nIntl.it;
  updateGlobalConfig({
    isLocaleZhCN: locale === LANGUAGE["zh-CN"]
  });
};
export {
  $i,
  $iDate,
  $in,
  $irt,
  $it,
  setLocale
};
