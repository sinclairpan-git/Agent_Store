// packages/config/global/index.ts
var defaultConfig = {
  isInternational: false,
  isLocaleZhCN: true,
  rootContainer: "#body",
  search: {}
};
var globalConfig = {
  ...defaultConfig
};
var updateGlobalConfig = (config) => {
  Object.assign(globalConfig, config);
};
export {
  globalConfig,
  updateGlobalConfig
};
