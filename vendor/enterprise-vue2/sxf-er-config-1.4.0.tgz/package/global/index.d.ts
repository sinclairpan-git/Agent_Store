import Vue, { VueConstructor } from 'vue';
import VueRouter from 'vue-router';

type MessageBoxConfig = {
    /** The message box 校验密码API函数 */
    verifyPasswordApi?: Function;
};
type SearchConfig = {
    /** 搜索限制字符数 */
    limit?: number;
    /** 是否使用 utf8 计算长度 */
    useUTF8Len?: boolean;
};
type MonitorArrayTaskConfig = {
    /** 批量请求接口 */
    api?: Function;
    /** 批量轮询时正在运行任务接口数据中id的key值 */
    dataKey?: string;
};
type MonitorConfig = {
    /** 接口的upid值的key */
    dataKey?: string;
    /** 接口的进度的key */
    processKey?: string;
    /** 轮询接口参数的key */
    logKey?: string;
    /** 请求接口 */
    api?: Function;
    /** 批量任务配置 */
    arrayTask?: MonitorArrayTaskConfig;
};
type ApiConfig = {
    /** 预处理请求数据 */
    progressData?: Function;
    /** 异步轮询请求配置 */
    monitor?: MonitorConfig;
};
type Config = {
    /** The Vue constructor to be used. */
    VueConstructor: VueConstructor<Vue>;
    /** 组件前缀 */
    prefixComp?: string;
    /** The message box configuration. */
    messageBox?: MessageBoxConfig;
    /** The search configuration. */
    search: SearchConfig;
    /** api 处理 */
    apiConfig?: ApiConfig;
    /** 是否是国际版 */
    isInternational?: boolean;
    /** i18n是否是中文 */
    isLocaleZhCN?: boolean;
    /** 根容器，默认值 #body */
    rootContainer?: string;
    /** router 实例， coverWindow 有用到 */
    router?: VueRouter;
    /** username (VMP.data.username） */
    username?: string;
    /** RSA 加密公钥 (VMP.data.RSAModulus）*/
    RSAModulus?: string;
    ajax: {
        /** ajax token 头 (VMP.data.ticket) */
        ticket?: string;
        /** ajax token 的 key 值 */
        tokenKey?: string;
        /** user_id (VMP.data.user_id) */
        sid?: string;
        /** summary 接口返回的login字段 (VMP.data.loginType) */
        loginType?: string;
        contentTypeJson?: boolean;
        remoteDebugPrefix?: boolean;
    };
    /** 时区 (VMP.data.timeZone) */
    timeZone?: string;
    /** 时区偏移配置（VMP.data.timeZoneOffset */
    timeZoneOffset?: number;
    /** 是否是 debug 模式 （主要控制 logger 模块输出） */
    debug?: boolean;
};
declare const globalConfig: Config;
declare const updateGlobalConfig: (config: Partial<Config>) => void;

export { globalConfig, updateGlobalConfig };
