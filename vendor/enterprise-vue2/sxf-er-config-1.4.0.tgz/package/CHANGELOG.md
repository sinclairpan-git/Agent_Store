# @sxf/er-config

## 1.4.0 (2025-07-18)

### Minor Changes

- chore: 统一更新主线版本

### Patch Changes

- Updated dependencies [021b7ffc]
- Updated dependencies
  - @sxf/er-feature@0.1.0

## 1.3.0-xaas-patch.1 (2025-03-19)

### Patch Changes

- chore: 合入 xaas 变更后更新版本号，统一升级

## 1.2.4-scp-6111-patch.4 (2025-03-13)

### Minor Changes

- cced609b: refactor(config): 将词条迁移至 feature 包
- a5044929: feat(config): 移除 componentConfig，组件全局配置放在 feature 包

## 1.3.0 (2025-02-13)

### Minor Changes

- 14788914: chore: 更新主线包发布版本号

### Patch Changes

- dbd0f03e: feat: release/scc-devops 分支合入主线更新版本号

## 1.2.5 (2024-12-26)

### Patch Changes

- chore: release 分支合入后更新 latest

## 1.2.4-aipaas-patch.1 (2024-11-08)

### Patch Changes

- b7c63f78: feat(pro:base-info): 扩展 BaseInfo 组件支持纵向布局和折叠功能

## 1.2.4-scc-devops-patch.1 (2024-12-25)

### Patch Changes

- 960a094c: fix(comp:input): 修复 http 校验英文报错信息报错

## 1.2.4-scp-6111-patch.3 (2024-12-24)

### Minor Changes

- 1ea568d7: feat(widget:notify): 增加关闭操作回调功能 & 优化 er-no-notify 逻辑

## 1.2.4-scp-6111-patch.2 (2024-12-17)

### Patch Changes

- eb920e13: fix(config): 调整输入框的 username validType 的英文文案

## 1.2.4-scp-6111-patch.1 (2024-11-20)

### Minor Changes

- 05bdad0b: feat(comp:combo): 添加搜索规范

## 1.2.4 (2024-09-29)

### Patch Changes

- 962b2a3d: fix(pro:transfer-select): 支持业务自定义表格配置、已选限制、隐藏搜索等功能，优化组件体验问题
  fix(config): 将待选文案与括号进行拆分，方便设置括号颜色

## 1.2.3

### Patch Changes

- 1de1bbfe: fix(pro:transfer-select): 优化操作列宽度在英文场景下设置的逻辑
  feat(config): 增加 isLocaleZhCN 配置，标注当前系统的语言环境

## 1.2.2 (2024-09-10)

### Patch Changes

- 8ab40be1: fix(pro:tree-transfer-select): 修复国际版下右侧表格操作栏文案展示不全问题

## 1.2.1 (2024-09-05)

### Patch Changes

- 3d7c6461: fix(comp:\_utils): 适配 monitor 被取消后，没有返回后台定义的 description 场景

## 1.2.0 (2024-08-29)

### Minor Changes

- 33d141b0: feat(config): 新增 componentConfig 配置，用于配置全局组件

## 1.1.2 (2024-08-28)

### Patch Changes

- 5ceba54e: fix(comp:grid): 移除不符合规范的分页组件文案 "加载中..."
- f1ae0605: fix(utils:format): 获取当前时区添加时区偏移配置

## 1.1.1 (2024-08-22)

### Patch Changes

- a381787a: fix(comp:radio): 单选组校验写死了错误信息

## 1.1.0 (2024-06-01)

### Minor Changes

- 8b9487c0: feat(config): 移除内部没有在使用的词条

## 1.0.1 (2024-05-28)

### Patch Changes

- 70010a95: fix(config): 词条翻译

## 1.0.0 (2024-05-13)

### Major Changes

- 7875a24a: feat: eresh1.0 正式版发布

### Minor Changes

- 8197c813: feat(comp:upload): 增加 upload 组件
- 6e39bddc: feat(config): 新增 tree-transfer-select 树表格穿梭框组件相关词条
- 59e243b3: feat(config): 替换 upload 组件的英文词条
- b049d503: feat(comp:timepicker): 添加 timepicker 组件相关翻译
- a3ae5ee0: feat(config): 新增 combo 底部新增按钮词条
- e86f9574: feat(config): 新增竖向筛选组件 vertical-filter 相关词条
- 6533c596: feat(config):添加 date-picker 组件翻译
- 63818025: feat(config): 增加图表全屏组件词条
- 95ed3396: feat(config): 新增 quick-date-picker 组件国际化翻译
- 72650ffa: feat(config): 新增穿梭框词条
- 0a66303a: feat(config): add filter-conditions translated entries
- 4145c62f: feat: 新增穿梭框右侧表格两个禁用提示词条

### Patch Changes

- ba95de09: fix(config): 分页器中文词条更新
- db191806: fix(config): 更新 components-grid 组件-自定义列悬浮层词条
- 77719cfb: feat(confg:mask): 修改 mask 的默认消息
- 6260bb87: fix(comp:select): 根据交互规范修复 select 样式，文案
- d97114b4: fix(comp:select): 选择器下拉加载文案改为“加载中...”

## 1.0.0-beta.10 (2024-04-17)

### Minor Changes

- d01213a3: feat(config):添加 date-picker 组件翻译
- c8273926: feat: 新增穿梭框右侧表格两个禁用提示词条

## 1.0.0-beta.9 (2024-04-12)

### Minor Changes

- a64cebe9: feat(config): 新增 quick-date-picker 组件国际化翻译

## 1.0.0-beta.8 (2024-04-09)

### Patch Changes

- 3e64fa3e: fix(config): 更新 components-grid 组件-自定义列悬浮层词条

## 1.0.0-beta.7 (2024-04-03)

### Minor Changes

- 022cdffd: feat(config): 新增 combo 底部新增按钮词条
- 1e25c394: feat(config): 增加图表全屏组件词条

## 1.0.0-beta.6 (2024-03-28)

### Minor Changes

- c613d67e: feat(config): 新增 tree-transfer-select 树表格穿梭框组件相关词条

## 1.0.0-beta.5 (2024-03-26)

### Minor Changes

- d9c180c3: feat(comp:timepicker): 添加 timepicker 组件相关翻译
- 93687b6f: feat(config): add filter-conditions translated entries

### Patch Changes

- e65d886b: feat(confg:mask): 修改 mask 的默认消息
- ad4e5664: fix(comp:select): 根据交互规范修复 select 样式，文案

## 1.0.0-beta.4 (2024-03-18)

### Minor Changes

- 064e2ef1: feat(config): 新增穿梭框词条

## 1.0.0-beta.3 (2024-03-11)

### Minor Changes

- f4bc459f: feat(config): 替换 upload 组件的英文词条

### Patch Changes

- 3ce96289: fix(comp:select): 选择器下拉加载文案改为“加载中...”

## 1.0.0-beta.2 (2024-03-06)

### Minor Changes

- e1bef167: feat(comp:upload): 增加 upload 组件

## 1.0.0-beta.1 (2024-03-01)

### Minor Changes

- 38763c7f: feat(config): 新增竖向筛选组件 vertical-filter 相关词条

### Patch Changes

- d7bb078d: fix(config): 分页器中文词条更新

## 1.0.0-beta.0 (2024-01-17)

### Major Changes

- 0b0e74eb: chore: init beta version release

## 0.5.1-scp-6105-patch.1

### Patch Changes

- d6d603e6: fix(comp:\_utils): 适配 monitor 被取消后，没有返回后台定义的 description 场景

## 0.5.1 (2024-03-19)

### Patch Changes

- 7634bbd0: fix(config): 解决有效 ip 校验文本中英文例子不一致问题

## 0.5.0 (2024-02-29)

### Minor Changes

- 0b654f14: feat(config): 新增级联组件空搜索结果词条

## 0.4.0 (2024-01-12)

### Minor Changes

- aa6ac6da: feat(config): 移除无用的词条

## 0.3.0 (2024-01-11)

### Minor Changes

- 78c91e53: feat(config): 更新 pro 组件词条

## 0.2.1 (2023-11-24)

### Patch Changes

- 542ae705: 英文版请求 notify 提示文案修改

## 0.2.0 (2023-10-20)

### Minor Changes

- 1c89619: feat(pro): 新增 fold-card (折叠卡片) 组件
- 700ab67: feat(config): pro 包 i18n 词条统一格式：er.pro.组件名.xx
- a01675b: feat(config): 新增 BaseInfo 组件词条

## 0.1.1 (2023-09-08)

### Patch Changes

- fix(config): 更新 vmname 校验结果词条

## 0.1.0 (2023-08-17)

### Minor Changes

- 23eda20: feat(config): 全局配置新增配置项 prefixComp，用于注册组件前缀

## 0.0.9 (2023-06-09)

### Patch Changes

- 4701fcb: feat: 添加 module 字段导出

## 0.0.8 (2023-05-26)

### Patch Changes

- fix(pro): 修复 ActionCard 词条不存在的问题

## 0.0.7 (2023-04-23)

### Patch Changes

- 7e2d09e: refactor(config:global): 移除 createGlobalConfig 方法，新增 updateGlobalConfig 方法

## 0.0.6 (2023-04-17)

### Patch Changes

- b1158d4: fix: 修复全局配置的类型定义

## 0.0.5 (2023-04-13)

### Patch Changes

- 80ecd83: fix: 修复构建 external 问题

## 0.0.4 (2023-04-12)

### Patch Changes

- dfce2dc: refactor: 优化部分代码

  1. 去除 VMP.router，在 globalConfig.router 配置
  2. 依赖外层的 #body 容器，改成 globalConfig.rootContainer
  3. props 明确类型定义

## 0.0.3 (2023-04-03)

### Patch Changes

- f467d2f: build: 使用 tsup 打包 utils, validator 等纯 js 包，生成 d.ts 文件
- 1daafc1: refactor: 去除所有的全局 VMP 与 install 接口

## 0.0.2 (2023-03-29)

### Patch Changes

- release

## 0.0.1 (2023-03-29)

### Patch Changes

- chore: release
